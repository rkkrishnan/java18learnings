# PriceService Scripts

Scripts for deployment and management of price service
