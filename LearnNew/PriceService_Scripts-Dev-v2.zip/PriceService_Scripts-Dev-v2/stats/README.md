#Stats script

Awk script to produce weekly stats.

To use, download and extract all nginx log files to sub folders. Don't just download the files named after days wanted as the log rolling doesn't correspond exactly to each day.

Example usage:

```
awk -f "stats.awk" */nginx* > week.csv
```

The script runs over all files and extracts just those days for the previous week (Monday - Sunday inclusive).

Example output (csv):

| Date                       | BULK count | Avg. Response (ms) | Response > 1Sec (%) | Request Error (4xx) | Server Error (5xx) | SINGLE count | Avg. Response (ms) | Response > 1Sec (%) | Request Error (4xx) | Server Error (5xx) |
|----------------------------|------------|--------------------|---------------------|---------------------|--------------------|--------------|--------------------|---------------------|---------------------|--------------------|
| Monday 15 February 2016    | 213348     | 79.79              | 0.3656              | 30                  | 0                  | 11658        | 12.6               | 0                   | 44                  | 0                  |
| Tuesday 16 February 2016   | 754647     | 53.48              | 0.0046              | 46                  | 0                  | 11326        | 14.4               | 0.0088              | 16                  | 2                  |
| Wednesday 17 February 2016 | 745836     | 53.67              | 0.0032              | 65                  | 0                  | 11203        | 15.07              | 0.0803              | 43                  | 3                  |
| Thursday 18 February 2016  | 648582     | 54.34              | 0.0048              | 38                  | 0                  | 42156        | 11.56              | 0                   | 231                 | 0                  |
| Friday 19 February 2016    | 762340     | 53.59              | 0.0033              | 82                  | 0                  | 15643        | 10.78              | 0                   | 17                  | 0                  |
| Saturday 20 February 2016  | 652904     | 51.03              | 0.002               | 78                  | 0                  | 14225        | 11.68              | 0                   | 8                   | 0                  |
| Sunday 21 February 2016    | 624612     | 52.29              | 0.0022              | 78                  | 0                  | 7124         | 12.93              | 0                   | 5                   | 0                  |
| --                         |            |                    |                     |                     |                    |              |                    |                     |                     |                    |
| 15 Feb - 21 Feb            | 4402269    | 54.4               | 0.0209              | 417                 | 0                  | 113335       | 12.29              | 0.0088              | 364                 | 5                  |
