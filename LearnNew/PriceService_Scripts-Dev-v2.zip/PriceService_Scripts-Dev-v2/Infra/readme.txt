This folder would contain the installables: 
1) jvm
2) supervisor
3) python distributions
4) APM installations (monitoring)
5) Nginx (if required)
