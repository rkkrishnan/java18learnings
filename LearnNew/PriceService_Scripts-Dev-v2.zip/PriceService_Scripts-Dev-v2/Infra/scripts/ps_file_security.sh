#!/bin/bash
. $HOME/.bash_profile
. $PSHOME/profile

# Sourcing the config file
. $PSHOME/usr/local/scripts/config.sh
RC=$?
if [[ "$RC" -ne "0" ]]; then
   echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Failed to source config.sh script. Please check..!!"
   exit 1
fi

STAMP=`date +"%Y%m%d"`
PROG_NAME=$(basename $0 .sh)
USER="$(id -u -n)"

LOG_FILE=$LOG_PATH/${PROG_NAME}_log_${STAMP}.log

if [[ ! -d "$LOG_PATH" ]];
then
   echo "Log path is not set. Please set the LOG_PATH."
   exit 1
fi

return_code()
{
   local rc=$1
   local path=$2
   if [[ "$rc" -ne "0" ]] ;
   then
      echo "-----------------------------------------------------------------------------------------" | tee -a $LOG_FILE
      echo "$(date '+%Y-%m-%d %T') : INFO :Unable to provide the permission to $path path..." | tee -a $LOG_FILE
	  echo "-----------------------------------------------------------------------------------------" | tee -a $LOG_FILE
   else
      echo "$(date '+%Y-%m-%d %T') : Permission granted to $path path..." | tee -a $LOG_FILE
   fi
}

change_dir_permission()
{
   local dir_path=$1
   local file_type=$2
   local permission=$3
   
   if [[ -d "$dir_path" ]];
   then
      find $dir_path -type $file_type -name "*" -print | xargs chmod $permission
	  RC=$?
	  return_code $RC $dir_path
   else
      echo "$(date '+%Y-%m-%d %T') : The Dir $dir_path is not present..." | tee -a $LOG_FILE
   fi
}

restore_ssh_permission()
{
   echo "$(date '+%Y-%m-%d %T') : Restore the access permission for .ssh directory...." | tee -a $LOG_FILE 
   
   if [[ -d "/appl/prcsrvce/.ssh" ]];
   then
      chmod 755 /appl/prcsrvce/.ssh
      RC=$?
      return_code $RC "/appl/prcsrvce/.ssh"
   fi
   
   if [[ -f "/appl/prcsrvce/.ssh/id_rsa" ]];
   then
      chmod 600 /appl/prcsrvce/.ssh/id_rsa
      RC=$?
      return_code $RC "/appl/prcsrvce/.ssh/id_rsa"
   fi
   
   if [[ -f "/appl/prcsrvce/.ssh/id_rsa.pub" ]];
   then
      chmod 600 /appl/prcsrvce/.ssh/id_rsa.pub
      RC=$?
      return_code $RC "/appl/prcsrvce/.ssh/id_rsa.pub"
   fi
   
   if [[ -f "/appl/prcsrvce/.ssh/known_hosts" ]];
   then
      chmod +r /appl/prcsrvce/.ssh/known_hosts
      RC=$?
      return_code $RC "/appl/prcsrvce/.ssh/known_hosts"
   fi
   
   if [[ -f "/appl/prcsrvce/.ssh/authorized_keys" ]];
   then
      chmod +r /appl/prcsrvce/.ssh/authorized_keys
      RC=$?
      return_code $RC "/appl/prcsrvce/.ssh/authorized_keys"
   fi
   
   echo "$(date '+%Y-%m-%d %T') : Restore the access permission for .ssh directory completed..." | tee -a $LOG_FILE
}



echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME started by $USER.. Hostname is <`hostname`>" | tee -a  $LOG_FILE

echo "$(date '+%Y-%m-%d %T') : Remove the execute and write permission of all files to OTHERS..." | tee -a  $LOG_FILE
chmod -R o-rxw /appl/prcsrvce
RC=$?
return_code $RC "/appl/prcsrvce"

echo "$(date '+%Y-%m-%d %T') : Granting read and execute permission for the directory /appl/prcsrvce to OTHERS..." | tee -a  $LOG_FILE
chmod o+rx /appl/prcsrvce
RC=$?
return_code $RC "/appl/prcsrvce"

echo "$(date '+%Y-%m-%d %T') : Granting access to selective sub-directories (log, error, autosys, logs, var) w.r.t directory /appl/prcsrvce to OTHERS..." | tee -a  $LOG_FILE
change_dir_permission "/appl/prcsrvce/log" "d" "o+rx" 
change_dir_permission "/appl/prcsrvce/error" "d" "o+rx"
change_dir_permission "/appl/prcsrvce/autosys" "d" "o+rx"
change_dir_permission "/appl/prcsrvce/logs" "d" "o+rx"
change_dir_permission "/appl/prcsrvce/var" "d" "o+rx"

change_dir_permission "/appl/prcsrvce/log" "f" "o+r"
change_dir_permission "/appl/prcsrvce/error" "f" "o+r"
change_dir_permission "/appl/prcsrvce/autosys" "f" "o+r"
change_dir_permission "/appl/prcsrvce/logs" "f" "o+r"
change_dir_permission "/appl/prcsrvce/var" "f" "o+r"


echo "$(date '+%Y-%m-%d %T') : Remove the execute and write permission of all files to GROUPS..." | tee -a  $LOG_FILE
chmod -R g-rxw /appl/prcsrvce
RC=$?
return_code $RC "/appl/prcsrvce"

echo "$(date '+%Y-%m-%d %T') : Granting read and execute permission for the directory /appl/prcsrvce to GROUPS..." | tee -a  $LOG_FILE
chmod g+rx /appl/prcsrvce
RC=$?
return_code $RC "/appl/prcsrvce"

echo "$(date '+%Y-%m-%d %T') : All directories should have read permission to the group..." | tee -a  $LOG_FILE
change_dir_permission "/appl/prcsrvce" "d" "g+rx"

echo "$(date '+%Y-%m-%d %T') : All files should have read permission to the group..." | tee -a  $LOG_FILE
change_dir_permission "/appl/prcsrvce" "f" "g+r"

echo "$(date '+%Y-%m-%d %T') : Granting access to selective sub-directories (data/in, data/out and data/rej) w.r.t directory /appl/prcsrvce to GROUPS..." | tee -a  $LOG_FILE
change_dir_permission "/appl/prcsrvce/data" "d" "g+rwx"
change_dir_permission "/appl/prcsrvce/data/in" "d" "g+rwx"
change_dir_permission "/appl/prcsrvce/data/out" "d" "g+rwx"
change_dir_permission "/appl/prcsrvce/data/rej" "d" "g+rwx"

change_dir_permission "/appl/prcsrvce/data/in" "f" "g+rw"
change_dir_permission "/appl/prcsrvce/data/out" "f" "g+rw"
change_dir_permission "/appl/prcsrvce/data/rej" "f" "g+rw"


restore_ssh_permission

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME completed by $USER.. Hostname is <`hostname`>" | tee -a  $LOG_FILE
exit $?	