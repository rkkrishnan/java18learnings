#!/bin/bash

######################### IMPORTANT NOTE #######################################
# The content of .bash_profile and profile need 
# to be set before running the below steps

export PSHOME=/appl/prcsrvce

. $PSHOME/.bash_profile

echo "@@@@@@@@@@@@@@@@@@@@@ JAVA INSTALL STARTED @@@@@@@@@@@@@@@@@@@@@@@@@@"
java_variable=`which java`
if [ "$java_variable" == "/appl/prcsrvce/usr/java/jdk1.7.0_67/bin/java" ];
then
	echo "Java is installed in $java_variable"
else
	echo "No java found"
	echo "Installing it"
	cd $PSHOME/usr/java
	tar zxvf  $PSHOME/install/jdk-7u67-linux-x64.gz

	if [ `echo $?` -ne "0" ]
	then
		echo "Unable to install"
		exit 3
	else
		echo "Java is installed in $java_variable"
	fi
fi
echo "@@@@@@@@@@@@@@@@@@@@@ JAVA INSTALL COMPLETED @@@@@@@@@@@@@@@@@@@@@@@@@@"


echo "@@@@@@@@@@@@@@@@@@@@@ SOI INSTALL STARTED @@@@@@@@@@@@@@@@@@@@@@@@@@"

if [ -d $PSHOME/soi ]
then
	echo "Deleting existing SOI directory"
	rm -rf $PSHOME/soi 
	echo "Creating SOI directory again"
	mkdir -p $PSHOME/soi 
fi

unzip -qo $PSHOME/install/soi.zip -d $PSHOME/soi/
if [ `echo $?` -ne "0" ]
then
	echo "Unable to install SOI"
	exit 3
else
	echo "SOI is installed in $PSHOME/soi"
fi

cp $PSHOME/soi/wily/core/config/IntroscopeAgent.profile IntroscopeAgent.profile.orig

soi_agent_name="fakedomain"
soi_hostname="fakedomain"

sed -e "s/^introscope.agent.agentName=Product Service/introscope.agent.agentName=$soi_agent_name/" -e "s/^introscope.agent.enterprisemanager.transport.tcp.host.DEFAULT=ukirp273.ukroi.tesco.org/introscope.agent.enterprisemanager.transport.tcp.host.DEFAULT=$soi_hostname/" IntroscopeAgent.profile.orig > $PSHOME/soi/wily/core/config/IntroscopeAgent.profile

echo "@@@@@@@@@@@@@@@@@@@@@ SOI INSTALL COMPLETED @@@@@@@@@@@@@@@@@@@@@@@@@@"


echo "@@@@@@@@@@@@@@@@@@@@@ PYTHON INSTALL STARTED @@@@@@@@@@@@@@@@@@@@@@@@@@"

rpm2cpio install/python26-libs-2.6.8-2.el5.x86_64.rpm | cpio --extract --make-directories --no-absolute-filenames
rpm2cpio install/python26-2.6.8-2.el5.x86_64.rpm | cpio --extract --make-directories --no-absolute-filenames

ln -s $PSHOME/usr/bin/python26 $PSHOME/usr/bin/python

rpm2cpio install/python-elementtree-1.2.6-5.x86_64.rpm | cpio --extract --make-directories --no-absolute-filenames
rpm2cpio install/python-meld3-0.6.3-1.el5.x86_64.rpm | cpio --extract --make-directories --no-absolute-filenames

echo "@@@@@@@@@@@@@@@@@@@@@ PYTHON INSTALL COMPLETED @@@@@@@@@@@@@@@@@@@@@@@@@@"


echo "@@@@@@@@@@@@@@@@@@@@@ SUPERVISOR INSTALL STARTED @@@@@@@@@@@@@@@@@@@@@@@@@@"

rpm2cpio install/supervisor-2.1-3.el5.noarch.rpm | cpio --extract --make-directories --no-absolute-filenames

. $PSHOME/profile 

cp $PSHOME/usr/bin/supervisord  $PSHOME/usr/bin/supervisord.orig
cp $PSHOME/usr/bin/supervisorctl  $PSHOME/usr/bin/supervisorctl.orig

sed -e "s|/usr/bin/python|"$PSHOME"\/usr\/bin\/python|" $PSHOME/usr/bin/supervisord.orig > $PSHOME/usr/bin/supervisord
sed -e "s|/usr/bin/python|"$PSHOME"\/usr\/bin\/python|" $PSHOME/usr/bin/supervisorctl.orig > $PSHOME/usr/bin/supervisorctl

if [ "$PSENV_TYPE" == "SERVICE" ];
then
	echo "Installing nginx.."
	tar zxvf  install/nginx-1.6.0-tescobuild-prcsrvce-20141027.tar.gz
fi 

echo "@@@@@@@@@@@@@@@@@@@@@ SUPERVISOR INSTALL COMPLETED @@@@@@@@@@@@@@@@@@@@@@@@@@"