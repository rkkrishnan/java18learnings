#!/bin/bash
. $HOME/.bash_profile
. $PSHOME/profile

# Sourcing the config file
. $PSHOME/usr/local/scripts/config.sh
RC=$?
if [[ "$RC" -ne "0" ]]; then
   echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Failed to source config.sh script. Please check..!!"
   exit 1
fi

STAMP=`date +"%Y%m%d"`
PROG_NAME=$(basename $0 .sh)
USER="$(id -u -n)"

LOG_FILE=$LOG_PATH/${PROG_NAME}_log_${STAMP}.log

if [[ ! -d "$LOG_PATH" ]];
then
   echo "Log path is not set. Please set the LOG_PATH."
   exit 1
fi

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME started by $USER.. Hostname is <`hostname`>" | tee -a  $LOG_FILE

chmod -R o-rxw /appl/prcsrvce
RC=$?
if [[ "$RC" -ne "0" ]] ;
then
   echo "$(date '+%Y-%m-%d %T') : Unable to provide the permission to $path..." | tee -a $LOG_FILE
   exit 1 
else
   echo "$(date '+%Y-%m-%d %T') : Permission granted to $path path..." | tee -a $LOG_FILE
fi

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME completed by $USER.. Hostname is <`hostname`>" | tee -a  $LOG_FILE
exit $?	