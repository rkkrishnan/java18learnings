#!/bin/bash

######################### IMPORTANT NOTE #######################################
# The content of .bash_profile and profile need 
# to be set before running the below steps


# This script is used to verify some of the basic 
# checks in the server and create the directory structure given

if [ `ls -ld /appl|wc -l` ]
then
	echo "Directory /appl alreday exists"
fi


own=` ls -ld /appl|awk '{print $3}'`
if [ "$own" == "prcsrvce" ]; 
then 
	echo "owner is prcsrvce";
else
	echo "Owner is not prcsrvce and it is $own"
	exit 3
fi


if [ `echo $SHELL|grep bash|wc -l` ]
then
	echo "Default shell is bash"
else
	echo "Shell is $SHELL"
fi


usr=`groups prcsrvce|cut -d" " -f1|tr -d ' '`
grp=`groups prcsrvce|cut -d" " -f3|tr -d ' '`
if [ "$usr" == "$grp" ]
then
	echo "user and group are same"
else
	echo "user is $usr and group is $grp"
fi
 

grp_id=`grep prcsrvce /etc/group|cut -d: -f3`
no_of_user=`grep $grp_id /etc/passwd|awk '{print $1" " $5}'|wc -l`
if [ "$no_of_user" -ne "0" ]
then
	echo "Below are the user for the group prsvc_user"
	grep $grp_id /etc/passwd|awk -F: '{print $1" " $5}'
else
	echo "There are no user for the group prsvc_user"
fi


gr_id=`grep prcsrvce /etc/group|cut -d: -f3`

if [ `grep $gr_id /etc/passwd|wc -l` ]; 
then
	echo "There is only one user for group prcsrvce"
else 
	echo "There may be other users as well for group id 6329"
fi

# Basic checks are completed....

################################################################################
######################### Directory structure creation #########################
################################################################################

export PSHOME=/appl/prcsrvce

# Directory array...
# If any new directory need to be added then 
# add the directory path to the given below array.

dir_array=(
			$PSHOME/autosys/log
			$PSHOME/log
			$PSHOME/error
			$PSHOME/var
			$PSHOME/var/tmp
			$PSHOME/var/run
			$PSHOME/var/log
			$PSHOME/var/log/nginx
			$PSHOME/usr/local/scripts
			$PSHOME/usr/bin
			$PSHOME/usr/java
			$PSHOME/usr/local/price-adapter/versions
			$PSHOME/usr/local/latest
			$PSHOME/usr/local/price-service/versions
			$PSHOME/usr/sbin
			$PSHOME/etc/supervisor-fragments
			$PSHOME/etc/nginx
			$PSHOME/install
			$PSHOME/tmp
			$PSHOME/opt
			$PSHOME/data/in_arch
			$PSHOME/data/out_arch
			$PSHOME/data/in_reg
			$PSHOME/data/rej
			$PSHOME/data/in
			$PSHOME/data/out
			$PSHOME/data/files
			$PSHOME/data/in/acayg
			$PSHOME/data/in/emernonranged
			$PSHOME/data/in/emerranged
			$PSHOME/data/in/regranged
			$PSHOME/data/in/regnonranged
			$PSHOME/data/in/mmemer
			$PSHOME/data/in/mmreg
			$PSHOME/data/files/acayg
			$PSHOME/data/files/emernonranged
			$PSHOME/data/files/emerranged
			$PSHOME/data/files/regranged
			$PSHOME/data/files/regnonranged
			$PSHOME/data/files/mmemer
			$PSHOME/data/files/mmreg
			$PSHOME/data/files/onetime
			$PSHOME/data/in/onetime
			$PSHOME/data/in_arch/rpmzoneonetime
			$PSHOME/data/in/rpmzoneonetime
			$PSHOME/data/in/onetimepromotion
			$PSHOME/data/in_arch/onetimepromotion
			$PSHOME/data/in_arch/teauth
			$PSHOME/data/in_arch/teauth/uk
			$PSHOME/data/in_arch/teauth/roi
			$PSHOME/data/in/teauth
			$PSHOME/data/in/teauth/uk
			$PSHOME/data/in/teauth/roi
			$PSHOME/data/in/onetimesellinguom
            $PSHOME/data/in_arch/onetimesellinguom
            $PSHOME/data/files/onetimesellinguom
			$PSHOME/data/in/sonettouk
			$PSHOME/data/in_arch/sonettouk
			$PSHOME/data/files/sonettouk
			$PSHOME/data/in/sonettoroi
			$PSHOME/data/in_arch/sonettoroi
			$PSHOME/data/files/sonettoroi
			$PSHOME/data/in/onetimeprice
			$PSHOME/data/in_arch/onetimeprice
			$PSHOME/data/files/onetimeprice
			$PSHOME/data/in/estdprice
			$PSHOME/data/files/estdprice
			$PSHOME/data/in_arch/estdprice
            $PSHOME/data/in/futureOfferDesc
			$PSHOME/data/files/futureOfferDesc
			$PSHOME/data/in_arch/futureOfferDesc
            $PSHOME/data/in/oneTimeFutureOfferDesc
			$PSHOME/data/files/oneTimeFutureOfferDesc
			$PSHOME/data/in_arch/oneTimeFutureOfferDesc			
		)


for fname in ${dir_array[@]}
do
	mkdir -p $fname
	
	dir_no=`ls -ld $fname | wc -l`
	if [ "$dir_no" -eq "1" ]
	then
		echo "Directory $fname is created.."
	else
		echo "Unable to create $fname directory... Please check"
		exit 3
	fi
done

echo "All directory created ..."



