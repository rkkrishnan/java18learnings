#!/bin/bash
#
# Created By : - Biswo Ranjan
# Date: - 20150708
# Created Sprint: - Sprint 29
# Functionality: -  Rename APM Directory(hotdeploy) to control probing mechanism
# Usage: - Program Name - ps_apmprobing.sh
#                                        Input Arguments - ON or OFF
#          Output Expected - should log the error if script fails in any of the rename activity in price server and Adapter
# Modified By: Dinesh Sivasankaran
# Modified On: 21-Jul-2015
# Change Description: Code has been fixed to rename only the files in hotdeploy folder instead of hotdeploy folder itself. 

#set -x
. $HOME/.bash_profile
. $PSHOME/usr/local/scripts/config.sh
. $PSHOME/profile

if [ "$#" -ne "1" ];then
        echo "USAGE:The script accepts parameters.  basename $0 [ON/OFF]" | tee -a $LOG_FILE
exit 1;
fi

apmpath=$APMHOME/wily/core/config/hotdeploy

RUN_PARAM=`echo $1 |tr '[:lower:]' '[:upper:]'`
STAMP=`date +"%Y%m%d"`
PROG_NAME=$(basename $0 .sh)
USER="$(id -u -n)"
SCRIPT_PROBING="usr/local/scripts/ps_apm_probing.sh"
LOG_FILE=$LOG_PATH/${PROG_NAME}_log_${STAMP}.log
ERR_FILE=$ERROR_PATH/${PROG_NAME}_err_${STAMP}.log

if [ -z "$LOG_PATH" ];
then
      echo "Log path is not set. Please set the LOG_PATH"
      exit 1
fi

if [ -z "$ERROR_PATH" ];
then
      echo "Error path is not set. Please set the ERROR_PATH"
      exit 1
fi

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME started by $USER with param $*" | tee -a $LOG_FILE

Disable_Apm_Probing()
{
   #set -x
   funcname="Disable_Apm_Probing"

   if [[ -d $apmpath ]];
   then

      for ff in $( find $apmpath -maxdepth 1 -type f -name "*pbd" -print )  
      do
          fname=$(basename $ff $apmpath)
          tname=$apmpath/$fname".disable"

          echo "$(date '+%Y-%m-%d %T') - $funcname - Directory <$apmpath>: renaming file <$ff> to <$tname>" | tee -a $LOG_FILE

          mv $ff $tname
          RC=$?

          if [[ $RC -ne "0" ]];
          then
             echo "$(date '+%Y-%m-%d %T') - $funcname - Directory <$apmpath>: failed to rename from <$ff> to <$tname>" | tee -a $ERR_FILE
   	     exit 1;
          fi;
      done;
   else
      echo "$(date '+%Y-%m-%d %T') - $funcname - Unable to find apm probing directory <$apmpath> ... exiting" | tee -a $LOG_FILE
   fi;
   
   return $?;
}

Enable_Apm_Probing()
{
   #set -x
   funcname="Enable_Apm_Probing"

   if [[ -d $apmpath ]];
   then

      for ff in $( find $apmpath -maxdepth 1 -type f -name "*pbd.disable" -print )  
      do
          fname=$(basename $ff $apmpath)
          tname=$apmpath/$(basename $fname ".disable")

          echo "$(date '+%Y-%m-%d %T') - $funcname - Directory <$apmpath>: renaming file <$ff> to <$tname>" | tee -a $LOG_FILE

          mv $ff $tname
          RC=$?

          if [[ $RC -ne "0" ]];
          then
             echo "$(date '+%Y-%m-%d %T') - $funcname - Directory <$apmpath>: failed to rename from <$ff> to <$tname>" | tee -a $ERR_FILE
   	     exit 1;
          fi;
      done;

   else
      echo "$(date '+%Y-%m-%d %T') - $funcname - Unable to find apm probing directory <$apmpath> ... exiting" | tee -a $LOG_FILE
   fi;
   
   return $?;
}


#########ON or OFF APM probing############
if [ "$RUN_PARAM" == "ON" ];
then
	Enable_Apm_Probing
else
	if [ "$RUN_PARAM" == "OFF" ];
	then
	    Disable_Apm_Probing
	else
	    echo "USAGE: The script accepts parameters.  basename $0 [ON/OFF]" | tee -a $ERR_FILE
            exit 1
	fi
fi

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME completed  by $USER with param $*" | tee -a $LOG_FILE

exit $?
