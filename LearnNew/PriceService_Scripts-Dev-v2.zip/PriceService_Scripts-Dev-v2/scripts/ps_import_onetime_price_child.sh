#!/bin/bash

. $HOME/.bash_profile
. $PSHOME/profile
. $PSHOME/usr/local/scripts/config.sh
#set -x

STAMP=`date +"%Y%m%d"`
PROG_NAME=$(basename $0 .sh)
SNAME=$(basename $0 ) #Script Name
USER="$(id -u -n)"

if [[ ! -d $LOG_PATH ]];
then
    echo "$(date '+%y/%m/%d %T') : ERROR : the variable LOG_PATH >$LOG_PATH< is not set properly ..."
    exit 1
fi

if [[ ! -d $ERROR_PATH ]];
then
    echo "$(date '+%y/%m/%d %T') : ERROR : the variable ERROR_PATH >$ERROR_PATH< is not set properly ..."
    exit 1
fi
USAGE="Script accepts one parameter usage: ${PROG_NAME} <onetimeprice>  <filename>"

if [[ "$#" -ne "2" ]];
then
echo $USAGE
exit 1

fi

process_param=$1
filename=$2
log_temp=$LOG_PATH/log_temp_${filename}

LOG_FILE=$LOG_PATH/${PROG_NAME}_${filename}_log_${STAMP}.log
ERR_FILE=$ERROR_PATH/${PROG_NAME}_${filename}_err_${STAMP}.log


if [[ "$process_param" != "onetimeprice" ]];
then
   echo "$(date '+%Y-%m-%d %T') : ERROR : First  parameter is Invalid "| tee -a $ERR_FILE
   echo $usage
   exit 1
fi

echo "$(date '+%Y-%m-%d %T') : Job $SNAME started by $USER for $2 file" | tee -a $LOG_FILE

#To invoke the rest call with filename as a parameter
status=$(curl -X POST -s -o $log_temp -w "%{http_code}" http://$ADAPTER_HOST:$PORT_SERVICE/admin/importPrice/${process_param}/${filename})
curl_response=$(cat $log_temp)

if [ "$status" -eq "000" ];
then
   echo "$(date '+%Y-%m-%d %T') : REST call failed due to connectivity error,check error log" | tee -a $LOG_FILE
   echo "$(date '+%Y-%m-%d %T') : curl exited with status code : $status" | tee -a $ERR_FILE
   exit 1
fi

curl_response=$(cat $log_temp)
echo "$(date '+%Y-%m-%d %T') : Response from curl is: >" $curl_response | tee -a $LOG_FILE
echo "the status is $status"
if [ "$status" == "200" ];
then
   echo "$(date '+%Y-%m-%d %T') : Rest call successfull  for $filename" | tee -a $LOG_FILE
else
   echo "$(date '+%Y-%m-%d %T') : REST call failed with  error,check error log" | tee -a $LOG_FILE
   echo "$(date '+%Y-%m-%d %T') : curl exited with status code : $status" | tee -a $ERR_FILE
   exit 1

fi

   #%%%%%%%%%%%%%%%%%%%%%%%%%%JAVA Process Progress check%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   while [[ true ]]; do

      #sleep period
      sleep $SLEEP_PERIOD
      
      #REST call to check if import in progress or not
      status=$(curl -X GET  -s -o $log_temp -w "%{http_code}" http://$ADAPTER_HOST:$PORT_SERVICE/admin/importInProgress/${process_param}/${filename})
      #sleep 90
      if [ "$status" == "000" ];
      then
         echo "$(date '+%Y-%m-%d %T') : Import progress check failed check error file" | tee -a $LOG_FILE
         echo "$(date '+%Y-%m-%d %T') : curl exited with status code : $status" | tee -a $ERR_FILE
         echo "the status is" $status
         echo "Job $PROG_NAME failed..!!"
         exit 1

      elif [ "$status" == "200" ];
      then
         output=$(cat $log_temp)

         #check if import is in progress
         # echo $output | grep  "import.*:.*progress"

         ret=$(echo $output | grep -c "import.*:.*progress" )

         #if in progress sleep 60 and the check again
          if [[ "$ret" -eq "0" ]];
          then
             #echo $output | grep "import.*:.*aborted"
             ret=$(echo $output | grep -c "import.*:.*aborted")
              if [[ "$ret" -ne "0" ]];
              then
                 #import has errored,log and exit 1
                 echo "$(date '+%Y-%m-%d %T') : Import activity is aborted ,check script error log and adapter error logs for more info" | tee -a  $LOG_FILE
                 echo "$(date '+%Y-%m-%d %T') : ERROR from adapter is $output" | tee -a $ERR_FILE
                 echo "Job $PROG_NAME failed..!!"
                 exit 1
              else
                 # Import is successful!!!
                 echo "$(date '+%Y-%m-%d %T') : Import Completed successfully" | tee -a $LOG_FILE
                 echo "$(date '+%Y-%m-%d %T') : Output from restcall is >$output<" | tee -a $LOG_FILE
                 break
               fi

            else
               echo "Import still in progress"
            fi

         else
            echo "$(date '+%Y-%m-%d %T') : Import progress check failed check error file" | tee -a  $LOG_FILE
            echo "$(date '+%Y-%m-%d %T') : Import activity failed-exited with status:$status " | tee -a  $ERR_FILE
            echo "Job $PROG_NAME failed..!!"
            exit 1
         fi
done
