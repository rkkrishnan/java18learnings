#!/bin/bash
#Archive the rpmzone onetime files in file share server from in/rpmzoneonetime to in_arch/rpmzoneonetime
. $HOME/.bash_profile

RC=$?
if [[ $RC -ne 0 ]] ; then
  # Error exit
  echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : $0 failed calling profile script for variable setup"
  exit 1
fi

. $PSHOME/usr/local/scripts/config.sh

RC=$?
if [[ $RC -ne 0 ]] ; then
  # Error exit
  echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : $0 failed calling config script for variable setup"
  exit 1
fi

STAMP=`date +"%Y%m%d"`
PROG_NAME=$(basename $0 .sh)

#file_param=$1

LOG_FILE=$LOG_PATH/${PROG_NAME}_log_${STAMP}.log
ERR_FILE=$ERROR_PATH/${PROG_NAME}_err_${STAMP}.log

if [ ! -d  "$LOG_PATH" ];
then
      echo "Log path is not set. Please set the LOG_PATH"
      exit 1
fi

if [ ! -d  "$ERROR_PATH" ];
then
      echo "Error path is not set. Please set the ERROR_PATH"
      exit 1
fi

. $PSHOME/usr/local/scripts/clearance_config.sh

RC=$?
if [[ $RC -ne 0 ]] ; then
  echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : $0 failed calling clearance config script for variable setup"
  exit 1
fi

SSH_ERR=$SSH_TMP/${PROG_NAME}_err_${STAMP}

USER="$(id -u -n)"

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME started by $USER" | tee -a $LOG_FILE

SERVER=$PS_USER@$FILESHR_HOST

TIMESTAMP=$(date +%Y%m%d%H%M%S)
currentDayDate=$(date +%Y%m%d)

file_param=$(echo $1 | tr [[A-Z]] [[a-z]])

if [[ "$file_param" != "rpmzoneonetime" ]];
then
        echo "$(date '+%Y-%m-%d %T') : ERROR: The parameter should be [rpmzoneonetime].." | tee -a $LOG_FILE
        echo "$(date '+%Y-%m-%d %T') : ERROR: Return code: ${RC} $PROG_NAME script failed!!" | tee -a $ERR_FILE
        exit 1
fi

archiveRpmZoneOnetimeFiles() {

      filesInSrc=$(find $SRC  -maxdepth 1 -type f)

      currentValue=''
      for i in $filesInSrc
         do
            currentValue=`basename $i`
            if [[ "$currentValue" == *.csv.gz ]];
               then
                  filename=$(basename $currentValue .csv.gz)
                  TIMESTAMP=$(date +%Y%m%d%H%M%S)
                  append_date=${filename}_${TIMESTAMP}.csv.gz
            fi
           mv $SRC/${currentValue} $ARCHIVE/${append_date}
		   
		   
           RC=$?

           if [ "$RC" -ne "0" ];
              then
                 echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
                 echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR :RPMZONE onetime File Archive Failed" | tee -a $ERR_FILE
                 exit 1
           fi

     done
}

archiveRpmZoneOnetimeFiles

exit $?

