#!/bin/bash
. $HOME/.bash_profile

RC=$?
if [[ $RC -ne 0 ]] ; then
   # Error exit
   echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : $0 failed calling profile script for variable setup"
   exit 1
fi

. $PSHOME/usr/local/scripts/config.sh

RC=$?
if [[ $RC -ne 0 ]] ; then
   # Error exit
   echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : $0 failed calling config script for variable setup"
   exit 1
fi

STAMP=`date +"%Y%m%d"`
PROG_NAME=$(basename $0 .sh)

file_param=$1

#Checking for number of arguments
if [ "$#" -ne 1 ]
then
   echo "Invalid number of arguments" | tee -a $ERR_FILE
   echo "Usage : Should be the type of files to be processed."| tee -a $ERR_FILE
   echo "Script >$PROG_NAME< Failed .. Please refer to the error file >$ERR_FILE< for more details" | tee -a $LOG_FILE
   exit -1
fi

LOG_FILE=$LOG_PATH/${PROG_NAME}_log_${STAMP}.log
ERR_FILE=$ERROR_PATH/${PROG_NAME}_err_${STAMP}.log

if [ ! -d  "$LOG_PATH" ]; then
   echo "Log path is not set. Please set the LOG_PATH"
   exit 1
fi

if [ ! -d  "$ERROR_PATH" ]; then
   echo "Error path is not set. Please set the ERROR_PATH"
   exit 1
fi

. $PSHOME/usr/local/scripts/clearance_config.sh

RC=$?
if [[ $RC -ne 0 ]] ; then
   # Error exit
   echo "$(date '+%Y-%m-%d %T') : Return code: ${RC} : ERROR : $0 failed calling clearance config script for variable setup" |tee -a $ERR_FILE
   exit 1
fi


input_param=$(echo $1 | tr [[A-Z]] [[a-z]])

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME started by $USER" | tee -a $LOG_FILE

function validate_netvide
{
   echo "$(date '+%Y-%m-%d %T') : File validation started" | tee -a $LOG_FILE
   #Check if the files exists
   files=$(find ${LOAD_PATH}/${filePattern} -maxdepth 1 -type f)

  
   for ff in $files
   do
   
    numOfRetries=$numoftries
    

        oldFileSize=`ls -l "$ff" | awk '{print $5}'`

        while true
        do

        currFileSize=`ls -l "$ff" | awk '{print $5}'`
                if [ ${oldFileSize} -eq ${currFileSize} ];then
                        # If reaches here ${numOfRetries} times, so the file is ok
                        numOfRetries=`expr ${numOfRetries} - 1`
						
                else
                        echo "File size differ. Old File Size: [${oldFileSize}] - Curr File Size: [${currFileSize}]."
                fi

                echo "Old File Size: [${oldFileSize}] - Curr File Size: [${currFileSize}] - Retry: [${numOfRetries}] - Sleeping: [${sleepTime}]..."
                sleep $SLEEP_TIME
                oldFileSize=`ls -l "$ff" | awk '{print $5}'`


                if [ ${numOfRetries} -eq 0 ];then
                        echo "File transfer ok. Max number of retries reached: [${numOfRetries}]"

						
						
                        #copy that $ff to temp_path
						cp $ff $TEMP_PATH

						#then, gunzip,unzip, gzip that file in temp_path
						gunzip $TEMP_PATH/*
						unzip $TEMP_PATH/* -d $TEMP_PATH
						rm $TEMP_PATH/*.zip
						gzip $TEMP_PATH/*.txt 
                 
				 
				 

              tailVal=$(gunzip -cd $TEMP_PATH/* |tail -n1|cut -d '|' -f1)

                  if [ "$tailVal" == "9" ];then
                        mv $TEMP_PATH/* $DEST_PATH
                        #move files in loadpath as well
                        mv $ff $DONE_PATH

						break
                        else
                        echo "Error in the file Format, please check the logs"

                   fi
                fi
        done
        done

return 0;
}

function validate_cmhopos
{
   start_time_sec=`date +%s`
   echo "$(date '+%Y-%m-%d %T') : File validation started" | tee -a $LOG_FILE
   #Check if the files exists
   src_path_date=${SRC}/${STAMP}
   while [ true ];
   do
   files=$(find "${SRC}" -maxdepth 1 -name "${filePattern}" -type f )
   RC=$?
      if [[ $RC -ne 0 ]] ; then
         # Error exit
         echo "$(date '+%Y-%m-%d %T') : Error while ssh ...Check error logs" | tee -a $LOG_FILE
         echo "$(date '+%Y-%m-%d %T') : Return code: ${RC} : ERROR : Failed to ssh !!"  | tee -a $ERR_FILE
         exit 1
      fi
		
	file_count=$(find "${SRC}" -maxdepth 1 -name "${filePattern}" -type f | grep -v "^$" | wc -l)
	
	if [[ "$file_count" -gt "$ReqNoFiles" ]];then
	    echo "Required number of files is ($ReqNoFiles) "
	    exit 1
      fi
	  
    echo "count : $file_count"
	 #To wait for sometime before checking for the files again.
      if [[ "$file_count" -ne "$ReqNoFiles" ]];then

         if [ $(( `date +%s` - $start_time_sec )) -lt "$WAIT_TIME" ];then
            echo "$(date '+%Y-%m-%d %T'): sleeping for $(( $WAIT_TIME / 60 ))" | tee -a $LOG_FILE
            sleep $(( $WAIT_TIME / 60 ))
         else
	    echo "$(date '+%Y-%m-%d %T') : Script failed waiting for file..!!!Exiting .Check Error File" |tee -a $LOG_FILE
            echo "$(date '+%Y-%m-%d %T') : $WAIT_TIME seconds elapsed waiting for the file and file is not found.!!!! Hence exiting.." |tee -a $ERR_FILE
            exit 1;
         fi
      else
         echo "$(date '+%y/%m/%d %T') : $ReqNoFiles files found in ${SRC}" | tee -a $LOG_FILE
         
      fi
	  
	  file_count=$(find "${SRC}" -maxdepth 1 -name "${filePattern}" -type f | grep -v "^$" | wc -l)
      if [[ "$file_count" -gt "$ReqNoFiles" ]];then
	    echo "Final Required number of files is ($ReqNoFiles) "
	    exit 1
      fi
	  
   for ff in $files
   do
   
    numOfRetries=$numoftries
    

        oldFileSize=`ls -l "$ff" | awk '{print $5}'`

        while [ true ];
        do

        currFileSize=`ls -l "$ff" | awk '{print $5}'`
                if [ ${oldFileSize} -eq ${currFileSize} ];then
                        # If reaches here ${numOfRetries} times, so the file is ok
                        numOfRetries=`expr ${numOfRetries} - 1`
						
                else
                        echo "File size differ. Old File Size: [${oldFileSize}] - Curr File Size: [${currFileSize}]."
                fi

                echo "Old File Size: [${oldFileSize}] - Curr File Size: [${currFileSize}] - Retry: [${numOfRetries}] - Sleeping: [${sleepTime}]..."
                sleep $SLEEP_TIME
                oldFileSize=`ls -l "$ff" | awk '{print $5}'`


                if [ ${numOfRetries} -eq 0 ];then

                        echo "Max number of retries reached: [${numOfRetries}]"

			if [ ${oldFileSize} -eq ${currFileSize} ];then
			   echo "File size matched and successfully received the file"
			      return 0;

                        else
                        echo "Error in the file Format, please check the logs"
                       fi
	      fi
        done
        done
done

return 0;
}

if [[ $input_param  == "netvide" ]]; then

validate_netvide

elif [[ $input_param == "choffers" ]]; then

validate_cmhopos

fi

exit $?
