#!/bin/bash
# Downloads MMfiles(Emergency and Regular based on parameter provided) from the fileshare server and copy it into adapter server
. $HOME/.bash_profile

RC=$?
if [[ $RC -ne 0 ]] ; then
  # Error exit
  echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : $0 failed calling profile script for variable setup"
  exit 1
fi

set -o pipefail
. $PSHOME/usr/local/scripts/config.sh

RC=$?
if [[ $RC -ne 0 ]] ; then
  # Error exit
  echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : $0 failed calling config script for variable setup"
  exit 1
fi

STAMP=`date +"%Y%m%d"`
PROG_NAME=$(basename $0 .sh)

file_param=$1

LOG_FILE=$LOG_PATH/${PROG_NAME}_log_${STAMP}.log
ERR_FILE=$ERROR_PATH/${PROG_NAME}_err_${STAMP}.log

if [ ! -d  "$LOG_PATH" ];
then
      echo "Log path is not set. Please set the LOG_PATH"
      exit 1
fi

if [ ! -d  "$ERROR_PATH" ];
then
      echo "Error path is not set. Please set the ERROR_PATH"
      exit 1
fi

. $PSHOME/usr/local/scripts/clearance_config.sh

RC=$?
if [[ $RC -ne 0 ]] ; then
  # Error exit
  echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : $0 failed calling clearance config script for variable setup"
  exit 1
fi

SSH_ERR=$SSH_TMP/${PROG_NAME}_err_${STAMP}

USER="$(id -u -n)"

if [ "$#" -ne 1 ]
then
   echo "Invalid number of arguments" | tee -a $ERR_FILE
   echo "Usage : $PROG_NAME [mmemer|mmreg|mmondemand]" | tee -a $ERR_FILE
   echo "Script >$PROG_NAME< Failed .. Please refer to the error file >$ERR_FILE< for more details" | tee -a $LOG_FILE
   exit 1
fi

echo "Job $PROG_NAME started by $USER"
echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME started by $USER" >> $LOG_FILE

SERVER=$PS_USER@$FILESHR_HOST

checkServer() {

  echo "$(date '+%Y-%m-%d %T') : Begin : Checking for the required files in the server" | tee -a $LOG_FILE
  for ((i = 0; i < $numFiles; i++))
  do
    from="${srcfile[$i]}"

    exec 6>&1
    exec 1> $SSH_ERR
    exec 2>&1

    # src_time_stamp contains file name and the time stamp
    src_time_stamp=$(ssh -o StrictHostKeyChecking=no $SERVER "ls -l $SRC/$from | tr -s ' ' | cut -d' ' -f6-9 " | tail -n1)
          RC=$?

          exec 1>&6 6>&-

      #Changed to handle error
          sshout=$(tail -n1 $SSH_ERR | grep -ve "-----")

    if [[ -z "$src_time_stamp" || ! -z $sshout ]];
    then
      echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
      echo "$(date '+%y/%m/%d %T') : ERROR : Failed to ssh !!" >> $ERR_FILE
      echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR Occured is : >$sshout< !!" | tee -a $ERR_FILE
      exit 1
    fi

    # cut out the time stamp
    time_stamp=$( echo "$src_time_stamp" | cut -d ' ' -f1-3 )

    # cut out the file name
    src_filename[i]=$( echo "$src_time_stamp" | cut -d ' ' -f4 )

    fileName=`basename ${src_filename[$i]}`

    if [ -z "$src_filename[i]" ];
    then
      echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
      echo "$(date '+%y/%m/%d %T') : ERROR : No file matching $from found on server" | tee -a $ERR_FILE
        exit 1
    fi

        if [[ "$fileName" == *.gz ]];
        then
                fileNamegz=$( echo $fileName | cut -c0-41 )
                checkDate_gz=$( echo $fileNamegz | cut -d '.'  -f6 )
        elif [[ "$fileName" == *.trg ]];
        then
                fileNametrg=$( echo $fileName | cut -c0-41 )
                checkDate_trg=$( echo $fileNametrg | cut -d '.'  -f6 )
        fi
  done
}

checkFileType() {

trgfilearr=$(ssh -o StrictHostKeyChecking=no $SERVER "ls  $SRC/$filesearchPattern")
trgfilearray=($trgfilearr)
arrcount=${#trgfilearray[@]}
for(( i=0;i<${#trgfilearray[@]};i++ ))
do
        filename=$(basename ${trgfilearray[$i]} .trg)
        fname=$filename.gz
gzfilecount=$(ssh -o StrictHostKeyChecking=no $SERVER "find $SRC -name $fname -maxdepth 1 | wc -l")
        if [[ "$gzfilecount" != 1 ]];
        then
                echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
                echo "$(date '+%y/%m/%d %T') : ERROR : Trg and gz files are not in sync" | tee -a $ERR_FILE
                exit 1
        fi
done

}

copyFile() {

rm -f $TEMP_PATH/*
  numFiles=${#src_filename[@]}
  for ((i = 0; i < $numFiles; i++))
  do
        from="${src_filename[$i]}"
        to="${destfile[$i]}"
        fileToProceed=`basename $from`
        if [[ "$fileToProceed" == *.gz ]];
        then
           echo "$(date '+%Y-%m-%d %T') : Getting latest file matching $SERVER:$from and copying to $TEMP_PATH" | tee -a $LOG_FILE

        doScp $from $TEMP_PATH

        if [[ "$from" == *gz ]];
        then
                file=$(basename $from)
                gzip -d $TEMP_PATH/$file
                file=$(basename $file .gz)
            fi
        fi
  done
}

doScp() {
   local from=$1
   local to=$2

   scp -o StrictHostKeyChecking=no $SERVER:$from $to

   RC=$?
   if [ "$RC" -ne "0" ];
   then
   echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
   echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : Failed to scp $from to $to" | tee -a $ERR_FILE
   exit 1
  fi
}

process() {

 testArray=$(find $TEMP_PATH -maxdepth 1 -type f)
 currentValue=''

rm -f $DEST_PATH/*
rm -f $TEMP_PATH/$filepattern

for ((i=0; i<${#testArray[@]}; i++))
    do
        tempFile=${testArray[$i]}
       currentValue=`basename $tempFile`

         fileDest="${destfile[$i]}"
         headVal=$(head $tempFile -n1|cut -d '|' -f1)
         tailVal=$(tail $tempFile -n1|cut -d '|' -f1)
         tailCount=$(tail $tempFile -n1|cut -c2-11)
         tempTailval=${tailVal:1}
         countInTail=`echo $tempTailval | sed 's/ //g' | bc`
         rowCount=$(($(wc -l < $tempFile) -2))
         #diffCount=`expr $tailCount - $rowCount`

        if [[ "${headVal:0:1}" != 0 ]];
        then
                 echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
                 echo "$(date '+%Y-%m-%d %T') : HEAD RECORD IS NOT AVAILABLE" | tee -a $LOG_FILE
                 exit 1

        elif [[ "${tailVal:0:1}" != 9 ]];
        then
                 echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
                 echo "$(date '+%Y-%m-%d %T') : TAIL RECORD IS NOT AVAILABLE" | tee -a $LOG_FILE
                 exit 1
        elif [[ "$countInTail" != "$rowCount" ]];
        #elif [[ "$diffCount" != 0 ]]
        then
                echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
                echo "$(date '+%Y-%m-%d %T') : RECORD COUNT INCORRECT" | tee -a $LOG_FILE
                exit 1

        else
                mv $TEMP_PATH/$file $DEST_PATH/$fileDest
        fi
   done
}

archiveFiles() {

for ((i=0; i<$numFiles ;i++))
  do
     pattern="${src_filename[$i]}"

     if [[ "$pattern" == *.gz ]];
        then
           filename=$(basename $pattern .gz)
           TIMESTAMP=$(date +%Y%m%d%H%M%S)
           append_date=${filename}_${TIMESTAMP}.gz
     elif [[ "$pattern" == *.trg ]];
        then
           filename=$(basename $pattern .trg)
           TIMESTAMP=$(date +%Y%m%d%H%M%S)
           append_date=${filename}_${TIMESTAMP}.trg
     fi
     ssh -o StrictHostKeyChecking=no $SERVER "mv $pattern $ARCHIVE/$append_date"
done

}


checkServer

checkFileType

copyFile

process

archiveFiles

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME completed successfully" | tee -a $LOG_FILE

exit $?