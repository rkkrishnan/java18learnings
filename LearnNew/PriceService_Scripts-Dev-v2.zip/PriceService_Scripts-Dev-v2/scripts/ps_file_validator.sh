#!/bin/bash
. $HOME/.bash_profile

RC=$?
if [[ $RC -ne 0 ]] ; then
  # Error exit
  echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : $0 failed calling profile script for variable setup"
  exit 1
fi

. $PSHOME/usr/local/scripts/config.sh

RC=$?
if [[ $RC -ne 0 ]] ; then
  # Error exit
  echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : $0 failed calling config script for variable setup"
  exit 1
fi

STAMP=`date +"%Y%m%d"`
PROG_NAME=$(basename $0 .sh)

file_param=$1

LOG_FILE=$LOG_PATH/${PROG_NAME}_log_${STAMP}.log
ERR_FILE=$ERROR_PATH/${PROG_NAME}_err_${STAMP}.log

if [ ! -d  "$LOG_PATH" ];
then
      echo "Log path is not set. Please set the LOG_PATH"
      exit 1
fi

if [ ! -d  "$ERROR_PATH" ];
then
      echo "Error path is not set. Please set the ERROR_PATH"
      exit 1
fi

. $PSHOME/usr/local/scripts/clearance_config.sh

RC=$?
if [[ $RC -ne 0 ]] ; then
  # Error exit
  echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : $0 failed calling clearance config script for variable setup"
  exit 1
fi

USER="$(id -u -n)"

if [ "$#" -ne 1 ]
then
   echo "Invalid number of arguments" | tee -a $ERR_FILE
   echo "Usage : $PROG_NAME <Parameter>" | tee -a $ERR_FILE
   exit 1
fi

input_param=$(echo $1 | tr [[A-Z]] [[a-z]])

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME started by $USER for parameter $input_param" | tee -a $LOG_FILE

################################# File Validation Functions -Start ######################################
validate_sonetto(){

#Check if the files exists
count_files=$(find ${DEST_PATH}/${filePattern} -maxdepth 1 -type f | wc -l)

if [[ "$count_files" -eq "0" ]];then
	echo "$(date '+%y/%m/%d %T') : No files found for validation in the path ${DEST_PATH}/${filePattern} " | tee -a $LOG_FILE
	return 1;
elif [ [ ! -z $ReqNoFiles ] && [ "$count_files" -ne "$ReqNoFiles" ] ];then

echo "$(date '+%y/%m/%d %T') : No files in the path ${DEST_PATH}/${filePattern} is less than $ReqNoFiles  " | tee -a $LOG_FILE
	return 1;
fi;

return 0;
}


validate_establishedPrice(){
   echo "$(date '+%Y-%m-%d %T') : File validation started" | tee -a $LOG_FILE
   #Check if the files exists
   files=$(find ${DEST_PATH}/${filePattern} -maxdepth 1 -type f)
   for ff in $files
   do
      headVal=$(gunzip -cd $ff |head -n1|cut -d '|' -f1)
      tailVal=$(gunzip -cd $ff |tail -n1|cut -d '|' -f1)
      rowCount=$(gunzip -cd $ff |wc -l)
      countInTail=$(gunzip -cd $ff |tail -n1|cut -d '|' -f2|sed 's/^0*//')
      
	  if [[ "$headVal" != "FHEAD" || "$tailVal" != "FTAIL" ]];
      then
         echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
         echo "$(date '+%Y-%m-%d %T') : HEAD OR TAIL RECORD IS NOT AVAILABLE" | tee -a $ERR_FILE
         exit 1
      
	  elif [ "$rowCount" != "$countInTail" ];
      then
         echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
         echo "$(date '+%Y-%m-%d %T') : RECORD COUNT INCORRECT..!!!" | tee -a $ERR_FILE
		 echo "$(date '+%Y-%m-%d %T') : Row count from file:$rowCount" | tee -a $ERR_FILE
		 echo "$(date '+%Y-%m-%d %T') : Row count from tail record:$countInTail" | tee -a $ERR_FILE
         exit 1
      
	  else
	     #Remove the Head and tail records from the file.
		 gunzip -cd $ff |sed  '1d'|sed '$d' > ${TEMP_PATH}/$(basename $ff .gz)
		 gzip -f ${TEMP_PATH}/$(basename $ff .gz)
		 RC=$?
		 if [[ $RC -ne 0 ]] ; then
		    # Error exit
			echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
		    echo "$(date '+%Y-%m-%d %T') : Return code: ${RC} : ERROR : $0 failed while removing head and tail from file $ff" | tee -a $ERR_FILE
		    exit 1
		 fi
		 #Move the file back to the source directory after processing
         mv ${TEMP_PATH}/$(basename $ff) $SRC
		 RC=$?
		 if [[ $RC -ne 0 ]] ; then
		    # Error exit
			echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
		    echo "$(date '+%Y-%m-%d %T') : Return code: ${RC} : ERROR : $0 failed while moving the file $ff from ${TEMP_PATH} to $SRC" | tee -a $ERR_FILE
		    exit 1
		 fi
	     echo "$(date '+%Y-%m-%d %T') : Validation successful for the file $ff" | tee -a $LOG_FILE
	  fi
	done
    echo "$(date '+%Y-%m-%d %T') : File validation is complete without errors" | tee -a $LOG_FILE

return 0;
}



validate_netvide(){
   echo "$(date '+%Y-%m-%d %T') : File validation started" | tee -a $LOG_FILE
   #Check if the files exists
   files=$(find ${DEST_PATH}/${filePattern} -maxdepth 1 -type f)
   for ff in $files
   do
      headVal=$(gunzip -cd $ff |head -n1|cut -d '|' -f1)
      tailVal=$(gunzip -cd $ff |tail -n1|cut -d '|' -f1)
      rowCount=`expr $(gunzip -cd $ff |wc -l) - 2`
      countInTail=$(gunzip -cd $ff |tail -n1|cut -d '|' -f3|sed 's/^0*//')
      
	  if [[ "$headVal" != "0" || "$tailVal" != "9" ]];
      then
         echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
         echo "$(date '+%Y-%m-%d %T') : HEAD OR TAIL RECORD IS NOT AVAILABLE" | tee -a $ERR_FILE
         exit 1
      
	  elif [ "$rowCount" != "$countInTail" ];
      then
         echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
         echo "$(date '+%Y-%m-%d %T') : RECORD COUNT INCORRECT..!!!" | tee -a $ERR_FILE
		 echo "$(date '+%Y-%m-%d %T') : Row count from file:$rowCount" | tee -a $ERR_FILE
		 echo "$(date '+%Y-%m-%d %T') : Row count from tail record:$countInTail" | tee -a $ERR_FILE
         exit 1
      
	 
	  
	  else
	     #Remove the Head and tail records from the file.
		 gunzip -cd $ff |sed  '1d'|sed '$d' > ${TEMP_PATH}/$(basename $ff .gz)
		 gzip -f ${TEMP_PATH}/$(basename $ff .gz)
		 RC=$?
		 if [[ $RC -ne 0 ]] ; then
		    # Error exit
			echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
		    echo "$(date '+%Y-%m-%d %T') : Return code: ${RC} : ERROR : $0 failed while removing head and tail from file $ff" | tee -a $ERR_FILE
		    exit 1
		 fi
		 #Move the file back to the source directory after processing
         mv ${TEMP_PATH}/$(basename $ff) $SRC
		 RC=$?
		 if [[ $RC -ne 0 ]] ; then
		    # Error exit
			echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
		    echo "$(date '+%Y-%m-%d %T') : Return code: ${RC} : ERROR : $0 failed while moving the file $ff from ${TEMP_PATH} to $SRC" | tee -a $ERR_FILE
		    exit 1
		 fi
	     echo "$(date '+%Y-%m-%d %T') : Validation successful for the file $ff" | tee -a $LOG_FILE
	  fi
	done
    echo "$(date '+%Y-%m-%d %T') : File validation is complete without errors" | tee -a $LOG_FILE

return 0;
}

################################# File Validation Functions -Stop ######################################

################################# File validation control ###############################################

if [[ $input_param == "product_avg_weight_uk" || $input_param == "product_avg_weight_roi" ]] ;then

   validate_sonetto
   RC=$?
   if [[ $RC -ne 0 ]] ; then
      # Error exit
      echo "$(date '+%Y-%m-%d %T') : Return code: ${RC} : ERROR : File validation failed" | tee -a $LOG_FILE
      exit 1
   fi
   
   elif [[ $input_param == "competitor" ]];then

   validate_netvide
   RC=$?
   if [[ $RC -ne 0 ]] ; then
      # Error exit
      echo "$(date '+%Y-%m-%d %T') : Return code: ${RC} : ERROR : File validation failed" | tee -a $LOG_FILE
      exit 1
   fi
   
elif [[ $input_param == "estdprice" ]];then

   validate_establishedPrice
   RC=$?
   if [[ $RC -ne 0 ]] ; then
      # Error exit
      echo "$(date '+%Y-%m-%d %T') : Return code: ${RC} : ERROR : File validation failed" | tee -a $LOG_FILE
      exit 1
   fi
else
   echo "$(date '+%Y-%m-%d %T') : Invalid parameter passed..Refer config file for valid parameters" | tee -a $LOG_FILE
fi

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME completed successfully" | tee -a $LOG_FILE
exit $?