#!/bin/bash
###################################################################################################################
#Modified by: Pallavi Ambali
#Modified date: 20141216
#Created Sprint: Sprint14
#Functionality: To archive the price promotion files RPM and MM clearance files from in folder to in_arch folder.
####################################################################################################################
#Modified by: Nibedita Panda
#Modified date: 20150122
#Created Sprint: HotFix v1
#Functionality: To archive the .trg files for MM files and to append date for CMHOPOS files
####################################################################################################################
#Modified by: Nibedita Panda
#Modified date: 20150204
#Created Sprint: HotFix v2 - PS-457
#Functionality: To Modify not to fail the script if no files found to archive and to modularize the code
####################################################################################################################
#Modified by: Nibedita/Nitisha
#Modified date: 20150318
#Created Sprint: Sprint 21  - PS-120
#Functionality: To archive the TEAUTH files in DR Server
####################################################################################################################
#Modified by: Nibedita
#Modified date: 20150812
#Created Sprint: Sprint 31/32
#Functionality: To generalize the script to archive of files in DR, if we mention proper parameter and paths and patterens configured in clearance_config file
####################################################################################################################
#Modified by: Nibedita
#Modified date: 20151021
#Created Sprint: Sprint 36
#Functionality: To add functionality for the sonetto data archive to DR
####################################################################################################################
#Modified by: Nibedita
#Modified date: 20151204
#Created Sprint: Sprint 39
#Functionality: To add functionality for the establish price data archive to DR
####################################################################################################################
#Modified by: Santhosh
#Modified date: 20160318
#Created Sprint: Sprint 1- Competitor Feed
#Functionality: To add functionality for Netvide data archive to DR
####################################################################################################################
#set -x
. $HOME/.bash_profile
. $PSHOME/usr/local/scripts/config.sh

RC=$?
if [[ $RC -ne 0 ]] ; then
  # Error exit
  echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : $0 failed calling  config script for variable setup"
  exit 1
fi

STAMP=`date +"%Y%m%d"`
PROG_NAME=$(basename $0 .sh)
USER="$(id -u -n)"

LOG_FILE=$LOG_PATH/${PROG_NAME}_log_${STAMP}.log
ERR_FILE=$ERROR_PATH/${PROG_NAME}_err_${STAMP}.log

if [[ ! -d $LOG_PATH ]];
then
    echo "$(date '+%y/%m/%d %T') : ERROR : the variable LOG_PATH is not set properly ..."
    exit 1
fi
if [[ ! -d $ERROR_PATH ]];
then
    echo "$(date '+%Y-%m-%d %T') : ERROR : the variable ERROR_PATH  is not set properly ..."
    exit 1
fi
echo "FIle param $1"
. $PSHOME/usr/local/scripts/clearance_config.sh

RC=$?
if [[ $RC -ne 0 ]] ; then
  # Error exit
  echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : $0 failed calling clearance config script for variable setup"
  exit 1
fi

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME started by $USER" | tee -a $LOG_FILE

if [[ "$#" -ne 1 ]];
    then
           echo "$(date '+%Y-%m-%d %T') : ERROR: Please specify the file_param as [acayg|regranged|regnonranged|emerranged|emernonranged|mmemer|mmreg|mmondemand|teauthuk|teauthroi|rpmzoneonetime|onetimepromotionsp|onetimepromotionth|onetimepromotionmb|onetimeprice|product_avg_weight_uk|estdprice]

         check error log " | tee -a $LOG_FILE
         echo "$(date '+%Y-%m-%d %T') : ERROR: Return code: ${RC} ps_dataarchive.sh script " | tee -a $ERR_FILE
         exit 1
fi

# To archive the files from in folder to in_arch folder based on parameter
file_param=$1

# Based on run parameter call the archiveFilesDR

archiveFilesDR() {

#local filePattern=$1
TIMESTAMP=$(date +%Y%m%d%H%M%S)

if [ -z "$srcFilePattern" ];
then
       echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
       echo "$(date '+%y/%m/%d %T') : ERROR : File pattern not found for archiving" | tee -a $ERR_FILE
       exit 1
fi

for j in $srcFilePattern
do
filePatternToArch=$j

findFile=($(find "$SRC" -maxdepth 1 -type f -name "$filePatternToArch" | wc -l))

if [[ "$findFile" -ne "0" ]];
   then
      testArray=$(find $SRC/$filePatternToArch -maxdepth 1 -type f)
      #testArray=$(find $SRC .name .$filePatternToArch. -maxdepth 1 -type f)

      currentValue=''
      for i in $testArray
         do
            currentValue=`basename $i`

            if [[ "${currentValue}" == "CH_offers_"*.csv.gz ]];
               then
                  filename=$(basename $currentValue .csv.gz)
                  fileToArchive=${filename}_${STAMP}_${TIMESTAMP}.csv.gz
           
            elif [[ "${currentValue}" == "TescoDirect-"*.zip.gz ]];
               then
                  filename=$(basename $currentValue .csv.zip)
                  fileToArchive=${filename}_${STAMP}_${TIMESTAMP}.zip.gz

     

            elif [[ "${currentValue}" == *.pub.gz ]];
               then
                  filename=$(basename $currentValue .pub.gz)
                  fileToArchive=${filename}_${TIMESTAMP}.pub.gz

            elif [[ "${currentValue}" == *.txt.gz ]];
               then
                   filename=$(basename $currentValue .txt.gz)
                   fileToArchive=${filename}_${TIMESTAMP}.txt.gz

            elif [[ "${currentValue}" == *.csv.gz ]];
               then
                   filename=$(basename $currentValue .csv.gz)
                   fileToArchive=${filename}_${TIMESTAMP}.csv.gz

            elif [[ "${currentValue}" == *.dat.gz ]];
               then
                   filename=$(basename $currentValue .dat.gz)
                   fileToArchive=${filename}_${TIMESTAMP}.dat.gz
				   
			elif [[ "${currentValue}" == *.xml.gz ]];
               then
                  filename=$(basename $currentValue .xml.gz)
                  fileToArchive=${filename}_${TIMESTAMP}.xml.gz
				  
            elif [[ "${currentValue}" == *.gz ]];
                then
                   filename=$(basename $currentValue .gz)
                   fileToArchive=${filename}_${TIMESTAMP}.gz

            elif [[ "${currentValue}" == *.trg ]];
               then
                  filename=$(basename $currentValue .trg)
                  fileToArchive=${filename}_${TIMESTAMP}.trg

            fi

            if [[ $file_param == "futureOfferDesc_fs" && $iscr501inuse == "Y" ]];
			then
               cp $SRC/$currentValue $ARCHIVE/$fileToArchive
            else
               mv $SRC/$currentValue $ARCHIVE/$fileToArchive
            fi

            RC=$?
            if [[ "$RC" -ne "0" ]];
            then
               echo "$(date '+%Y-%m-%d %T') : ERROR: Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $ERR_FILE
               echo "$(date '+%Y-%m-%d %T') : Return code: ${RC} : ERROR : Failed to archive file from $SRC to $ARCHIVE" | tee -a $LOG_FILE
               exit 1
            fi
            echo "$(date '+%Y-%m-%d %T') : $currentValue archived successfully in DR $ARCHIVE" | tee -a $LOG_FILE
        done
else
 echo "$(date '+%Y-%m-%d %T') : No Files to archive for type $file_param with pattern $filePattern" | tee -a $LOG_FILE
fi
done
}

archiveFilesDR

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME completed successfully" | tee -a $LOG_FILE
exit $?
