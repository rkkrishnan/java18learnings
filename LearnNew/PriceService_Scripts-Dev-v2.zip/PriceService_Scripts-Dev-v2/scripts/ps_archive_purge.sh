#!/bin/bash

. $HOME/.bash_profile

RC=$?
if [[ $RC -ne 0 ]] ; then
  # Error exit
  echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : $0 failed calling profile script for variable setup"
  exit 1
fi

. $PSHOME/usr/local/scripts/config_purge.sh

RC=$?
if [[ $RC -ne 0 ]] ; then
  # Error exit
  echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : $0 failed calling config script for variable setup"
  exit 1
fi

STAMP=`date +"%Y%m%d"`
PROG_NAME=$(basename $0 .sh)
USER="$(id -u -n)"

LOG_FILE=$LOG_PATH/${PROG_NAME}_log_${STAMP}.log
ERR_FILE=$ERROR_PATH/${PROG_NAME}_err_${STAMP}.log

ARCHIVE_LOG=$LOG_PATH
ARCHIVE_ERR=$ERROR_PATH

if [[ ! -d  "$LOG_PATH" ]];
then
      echo "Log path is not set. Please set the LOG_PATH."
      exit 1
fi

if [[ ! -d  "$ERROR_PATH" ]];
then
      echo "Error path is not set. Please set the ERROR_PATH."
      exit 1
fi

echo "Job $PROG_NAME started by $USER"
echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME started by $USER" >> $LOG_FILE

purge_log() {

  local_path=$1
  local_retention=$2
  filename=$(find $local_path -maxdepth 1 -type f -mtime +$local_retention)

  if [ -z "$filename" ];
  then
    echo "$(date '+%Y-%m-%d %T') : No files to purge!!" >> $LOG_FILE
    echo "No files to purge in $local_path..."
    return 0
  fi

  for i in $filename
  do
    temp=$(basename $i)
    rm $i
    RC=$?
    if [ "$RC" -ne "0" ];
    then
      echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" >> $LOG_FILE
      echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : Failed to purge the file $temp" >> $ERR_FILE
      exit 1
    fi

    echo "$(date '+%Y-%m-%d %T') : File purged : $temp" >> $LOG_FILE
  done

  return 0
}

purge_data_archive() {

  local_path=$1
  local_retention=$2

  filename=$(find $local_path -maxdepth 1 -name "*.gz*" -o -name "*.trg" -type f -mtime +$local_retention)

  if [ -z "$filename" ];
  then
    echo "$(date '+%Y-%m-%d %T') : No files to purge!!" >> $LOG_FILE
    echo "No files to purge in $local_path..."
    return 0
  fi

  for i in $filename
  do
    temp=$(basename $i)
    rm $i
    RC=$?
    if [ "$RC" -ne "0" ];
    then
      echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" >> $LOG_FILE
      echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : Failed to purge the file $temp" >> $ERR_FILE
      exit 1
    fi

    echo "$(date '+%Y-%m-%d %T') : File purged : $temp" >> $LOG_FILE
  done

  return 0
}

##Purging Logic begins here##
for (( j = 0; j < ${#PRG_LOG_DIR[@]}; j++ ))
do

  # Purge the archived logs
  purge_log "${PRG_LOG_DIR[j]}" "${PRG_DIR_LOG_RET[j]}"
  

done

for (( k = 0; k < ${#PRG_DATA_DIR[@]}; k++ ))
do

  #Purge the archived data files
  purge_data_archive "${PRG_DATA_DIR[k]}" "${PRG_DIR_DATA_RET[k]}"

done

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME completed successfully" >> $LOG_FILE
echo "Job $PROG_NAME completed successfully"

exit $?
