#!/bin/bash

#set -x
. $HOME/.bash_profile
. $PSHOME/usr/local/scripts/config.sh

STAMP=`date +"%Y%m%d"`
PROG_NAME=$(basename $0 .sh)
USER="$(id -u -n)"
NGINX_ARCHIVE_SCRIPT="usr/local/scripts/ps_nginx.sh"

LOG_FILE=$LOG_PATH/${PROG_NAME}_log_${STAMP}.log
ERR_FILE=$ERROR_PATH/${PROG_NAME}_err_${STAMP}.log

if [ -z "$LOG_PATH" ];
then
      echo "Log path is not set. Please set the LOG_PATH"
      exit 1
fi

if [ -z "$ERROR_PATH" ];
then
      echo "Error path is not set. Please set the ERROR_PATH"
      exit 1
fi

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME started by $USER" | tee -a $LOG_FILE


######### Invoking ARCHIVE option for ps_nginx script in PPE Servers
for hname in ${PS_SERVERS[@]}
do
	############## Running ps_nginx  Script
	echo "$(date '+%Y-%m-%d %T') : Invoking $NGINX_ARCHIVE_SCRIPT in Service server ($hname)..." | tee -a $LOG_FILE
	ssh $USER@$hname "$PSHOME/$NGINX_ARCHIVE_SCRIPT ARCHIVE"
	RC=$?
	if [ "$RC" -ne "0" ]; 
	then
		echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
		echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : Failed to run $NGINX_ARCHIVE_SCRIPT in Service server ($hname)..." | tee -a $ERR_FILE
		exit 1
	fi
	echo "$(date '+%Y-%m-%d %T') : Completed $NGINX_ARCHIVE_SCRIPT in Service server ($hname)..." | tee -a $LOG_FILE

done

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME completed by $USER" | tee -a $LOG_FILE

exit $?;
