#!/bin/bash
#set -x
. $HOME/.bash_profile
. $PSHOME/usr/local/scripts/config.sh

STAMP=`date +"%Y%m%d"`
PROG_NAME=$(basename $0 .sh)
USER="$(id -u -n)"

LOG_FILE=$LOG_PATH/${PROG_NAME}_log_${STAMP}.log
ERR_FILE=$ERROR_PATH/${PROG_NAME}_err_${STAMP}.log

if [[ ! -d  $LOG_PATH ]];
then
    echo "$(date '+%Y-%m-%d %T') : ERROR : the variable LOG_PATH >$LOG_PATH< is not set properly ..."
    exit 1
fi

if [[ ! -d $ERROR_PATH ]];
then
    echo "$(date '+%Y-%m-%d %T') : ERROR : the variable ERROR_PATH >$ERROR_PATH< is not set properly ..."
    exit 1
fi

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME started by $USER" | tee -a $LOG_FILE

#connect to fileshare server and  run the housekeeping script
echo "$(date '+%Y-%m-%d %T') : Running the ps_dataarchive.sh script in fileshare server"| tee -a $LOG_FILE\

# To archive the files from in folder to in_arch folder based on the parameter
if [[ "$#" -ne 1 ]];
    then
       echo "$(date '+%Y-%m-%d %T') : ERROR: Please specify the file_param as [acayg|regranged|pricepromo|regnonranged|emerranged|emernonranged|mmemer|mmreg|teauthuk|teauthroi|product_avg_weight_uk|estdprice]
       check error log " | tee -a $LOG_FILE
       echo "$(date '+%Y-%m-%d %T') : ERROR: Return code: ${RC} ps_dataarchive.sh script " | tee -a $ERR_FILE
    exit 1
fi
file_param=$1

#ssh_out=$(ssh -o StrictHostKeyChecking=no $FILESHR_HOST "/appl/prcsrvce/usr/local/scripts/ps_housekeep.sh")
ssh_out=$(ssh -o StrictHostKeyChecking=no $PS_USER@$FILESHR_HOST "$PSHOME/usr/local/scripts/ps_dataarchive.sh '${file_param}'")

RC=$?


if [[ "$RC" -ne "0" ]];
then
    echo "$(date '+%Y-%m-%d %T') : ERROR: Error occured while running ps_dataarchive.sh script check error log " | tee -a $LOG_FILE
    echo "$(date '+%Y-%m-%d %T') : ERROR: Return code: ${RC} ps_dataarchive.sh script " | tee -a $ERR_FILE
    echo "$(date '+%Y-%m-%d %T') : ERROR: from ssh >> $ssh_out <<"  | tee -a $ERR_FILE
    exit 1
fi

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME completed successfully" | tee -a $LOG_FILE

exit $?

