#!/bin/bash
#set -x

fileParam=$(echo $1);

if [[ -z $fileParam ]];
then
   fileParam="PRICESTATS"
   echo "$(date '+%Y-%m-%d %T %Z') : INFO : Parameter Missing ... Defaulting the Parameter to $fileParam"
fi;

. $HOME/.bash_profile
RC=$?
if [[ $RC -ne 0 ]] ; then
   # Error exit
   echo "$(date '+%Y-%m-%d %T %Z') : Return code: ${RC} : ERROR : ${PROG_NAME} failed calling profile script for variable setup"
   exit 1
fi

. $PSHOME/usr/local/scripts/config.sh
RC=$?
if [[ $RC -ne 0 ]] ; then
   # Error exit
   echo "$(date '+%Y-%m-%d %T %Z') : Return code: ${RC} : ERROR : ${PROG_NAME} failed calling config script for variable setup"
   exit 1
fi

. $PSHOME/usr/local/scripts/clearance_config.sh "$fileParam"
RC=$?
if [[ $RC -ne 0 ]] ;
then
        # Error exit
        echo "$(date '+%Y-%m-%d %T %Z') : Return code: ${RC} : ERROR : $0 failed calling config script for variable setup"
        exit 1
fi

SCRIPTSDIR="$PSHOME/usr/local/scripts"

datetime=$(date '+%Y%m%d%H%M%S')
STAMP=`date +"%Y%m%d"`

PROG_NAME=$(basename $0 .sh)

STATFILENAME="PriceService_Stats"

STATFILE=${LOG_PATH}/"$STATFILENAME"_"$datetime".log

FINALSTATFILE=${LOG_PATH}/"$STATFILENAME"_"$datetime".log."final.csv"


NGINXFILE="${LOG_PATH}/nginx.log"

LOGFILE=${LOG_PATH}/${PROG_NAME}_log_${STAMP}.log

ERRFILE=${ERROR_PATH}/${PROG_NAME}_err_${STAMP}.log

if [[ ! -d "$LOG_PATH" ]];
then
   echo "$(date '+%Y-%m-%d %T %Z') : Log path is not set. Please set the LOG_PATH."
   exit 1
fi

if [[ ! -d  "$ERROR_PATH" ]];
then
   echo "$(date '+%Y-%m-%d %T %Z') : Error path is not set. Please set the ERROR_PATH."
   exit 1
fi

rm -f $NGINXFILE

echo "$(date '+%Y-%m-%d %T %Z') - Script ${PROG_NAME} started " | tee -a $LOGFILE

function process
{
    
    ddir=$(echo ${LOG_PATH}/$1)

    rm -rf $ddir

    mkdir $ddir

output=$(sftp $2 <<EOF
cd var/log
mget nginx*log* $ddir
EOF
)

    gzip -fd $ddir/*gz

    ls -1 $ddir/nginx-access*log* | sort | xargs cat >> $NGINXFILE
    # cat $ddir/nginx-access*log* >> $PSHOME/stats/nginx.log

    rm -rf $ddir
}

# echo $PS_SERVERS

for hname in $(echo ${PS_SERVERS[@]})
do
   echo "$(date '+%Y-%m-%d %T %Z') - Fetching files from host ($hname)" | tee -a $LOGFILE
   process nginx_$hname $hname

   ret=$?

   if [[ $ret != 0 ]];
   then
      echo "$(date '+%Y-%m-%d %T %Z') - process function failed for Hostname ($hname) ... <$ret>" | tee -a $LOGFILE
      exit 1;
   fi;
done;

echo "$(date '+%Y-%m-%d %T %Z') - Generating base statistics" | tee -a $LOGFILE

awk -f $SCRIPTSDIR/ps_stats.awk $NGINXFILE > $STATFILE

ret=$?

if [[ $ret != 0 ]];
then
   echo "$(date '+%Y-%m-%d %T %Z') - Awk failed ... <$ret>" | tee -a $LOGFILE
   exit 1;
fi;

period=$(cat $STATFILE | tail -1 |  awk -F"," '{ print $1 }')

echo "$(date '+%Y-%m-%d %T %Z') - Generating Percentile statistics" | tee -a $LOGFILE

$SCRIPTSDIR/ps_stats_percentile.sh "$STATFILE" "$NGINXFILE"

ret=$?

if [[ $ret != 0 ]];
then
    echo "$(date '+%Y-%m-%d %T %Z') - Error Occured while calling the script <ps_stats_percentile.sh> " | tee -a $LOGFILE
    exit 1;
fi;

echo "$(date '+%Y-%m-%d %T %Z') - Sending Email" | tee -a $LOGFILE

EMAILSTATFILE="$STATFILENAME"_"$period".csv

( echo ${MAIL_BODY} ; uuencode $FINALSTATFILE "$EMAILSTATFILE" ) | mailx -s "${MAIL_SUBJECT} $period" "${MAIL_RECIPIENTS}"

ret=$?

if [[ $ret != 0 ]];
then
    echo "$(date '+%Y-%m-%d %T %Z') - Error Occured while sending the email <ps_stats_percentile.sh> " | tee -a $LOGFILE
    exit 1;
fi;

#rm -f $NGINXFILE

echo "$(date '+%Y-%m-%d %T %Z') - Script completed successfully" | tee -a $LOGFILE

exit $?
