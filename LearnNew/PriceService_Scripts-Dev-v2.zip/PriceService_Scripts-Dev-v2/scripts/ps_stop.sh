#!/bin/bash
#set -x
. $HOME/.bash_profile
. $PSHOME/usr/local/scripts/config.sh

STAMP=`date +"%Y%m%d"`
PROG_NAME=$(basename $0 .sh)
USER="$(id -u -n)"

LOG_FILE=$LOG_PATH/${PROG_NAME}_log_${STAMP}.log
ERR_FILE=$ERROR_PATH/${PROG_NAME}_err_${STAMP}.log

if [ -z "$LOG_PATH" ];
then
	echo "Log path is not set. Please set the LOG_PATH"
	exit 1
fi

if [ -z "$ERROR_PATH" ];
then
	echo "Error path is not set. Please set the ERROR_PATH"
	exit 1
fi

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME started by $USER.. Hostname is <`hostname`>" | tee -a  $LOG_FILE

if [ "$PSENV_TYPE" == "SERVICE" ];
then
	#Command to stop NGINX in the server
    echo "$(date '+%Y-%m-%d %T') : JStopping NGINX..!!!" | tee -a  $LOG_FILE
    $PSHOME/usr/local/scripts/ps_nginx.sh QUIT
    RC=$?

    if [ "$RC" -ne "0" ];
    then
		echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE"| tee -a  $LOG_FILE
		echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : Failed to run ps_nginx.sh.. Check the ngnix log.."| tee -a  $ERR_FILE
		exit 1
    fi
fi

# Stop the service by caling supervisor script with param STOP
$PSHOME/usr/local/scripts/ps_supervisor.sh STOP
RC=$?
if [ "$RC" -ne "0" ];
then
	echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
	echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : Failed to stop the supervisor.sh.. Check the supervisor log.." | tee -a $ERR_FILE
	exit 1
fi

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME completed successfully.. Hostname is <`hostname`>"| tee -a  $LOG_FILE

exit $?;