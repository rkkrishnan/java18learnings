#!/bin/bash
#set -x

PROG_NAME=$(basename $0 .sh)

fileParam=$(echo $1);

if [[ -z $fileParam ]];
then
   fileParam="CLIENTSTATS"
   echo "$(date '+%Y-%m-%d %T %Z') : ${PROG_NAME} : INFO : Parameter Missing ... Defaulting the Parameter to $fileParam"
fi;

. $HOME/.bash_profile
RC=$?
if [[ $RC -ne 0 ]] ; then
   # Error exit
   echo "$(date '+%Y-%m-%d %T %Z') : ${PROG_NAME} : Return code: ${RC} : ERROR : ${PROG_NAME} failed calling profile script for variable setup"
   exit 1
fi

. $PSHOME/usr/local/scripts/config.sh
RC=$?
if [[ $RC -ne 0 ]] ; then
   # Error exit
   echo "$(date '+%Y-%m-%d %T %Z') : ${PROG_NAME} : Return code: ${RC} : ERROR : ${PROG_NAME} failed calling config script for variable setup"
   exit 1
fi

. $PSHOME/usr/local/scripts/clearance_config.sh "$fileParam"
RC=$?
if [[ $RC -ne 0 ]] ;
then
        # Error exit
        echo "$(date '+%Y-%m-%d %T %Z') : ${PROG_NAME} : Return code: ${RC} : ERROR : $0 failed calling config script for variable setup"
        exit 1
fi

datetime=$(date '+%Y%m%d%H%M%S')
STAMP=`date +"%Y%m%d"`

STATFILE=${LOG_PATH}/"$STATFILENAME"_"$datetime".csv

LOGFILE=${LOG_PATH}/${PROG_NAME}_log_${STAMP}.log

ERRFILE=${ERROR_PATH}/${PROG_NAME}_err_${STAMP}.log

if [[ ! -d "$LOG_PATH" ]];
then
   echo "$(date '+%Y-%m-%d %T %Z') : ${PROG_NAME} : Log path is not set. Please set the LOG_PATH."
   exit 1
fi

if [[ ! -d  "$ERROR_PATH" ]];
then
   echo "$(date '+%Y-%m-%d %T %Z') : ${PROG_NAME} : Error path is not set. Please set the ERROR_PATH."
   exit 1
fi

if [[ ! -s "$CLIENTLISTFILE" ]];
then
   echo "$(date '+%Y-%m-%d %T %Z') : ${PROG_NAME} : Client list file ($CLIENTLISTFILE) is not set. Please validate."
   exit 1
fi

if [[ ! -s "$NGINXFILE" || ! -f "$NGINXFILE" ]];
then
   echo "$(date '+%Y-%m-%d %T %Z') : ${PROG_NAME} : Nginx file ($NGINXFILE) is either not found or zero byte file. Please validate."
   exit 1
fi

echo "$(date '+%Y-%m-%d %T %Z') : ${PROG_NAME} : Script ${PROG_NAME} started " | tee -a $LOGFILE

echo "$(date '+%Y-%m-%d %T %Z') : ${PROG_NAME} : Generating client usage  statistics" | tee -a $LOGFILE

awk -v clientlist="$CLIENTLISTFILE" -f $SCRIPTSDIR/ps_stats_client.awk $NGINXFILE > $STATFILE

ret=$?

if [[ $ret != 0 ]];
then
   echo "$(date '+%Y-%m-%d %T %Z') : ${PROG_NAME} : Awk failed ... <$ret>" | tee -a $LOGFILE
   exit 1;
fi;

period1=$(cat $STATFILE | head -2 |  tail -1 | awk -F"," '{ print $1 }')
period2=$(cat $STATFILE | tail -1 |  awk -F"," '{ print $1 }')
period=$(echo $period1 "-" $period2 )

echo "$(date '+%Y-%m-%d %T %Z') : ${PROG_NAME} : Sending Email" | tee -a $LOGFILE

EMAILSTATFILE="$STATFILENAME"_"$period".csv

( echo ${MAIL_BODY} ; uuencode $STATFILE "$EMAILSTATFILE" ) | mailx -s "${MAIL_SUBJECT} $period" "${MAIL_RECIPIENTS}"

ret=$?

if [[ $ret != 0 ]];
then
    echo "$(date '+%Y-%m-%d %T %Z') : ${PROG_NAME} :  Error Occured while sending the email" | tee -a $LOGFILE
    exit 1;
fi;

rm -f $NGINXFILE

echo "$(date '+%Y-%m-%d %T %Z') : ${PROG_NAME} : Script completed successfully" | tee -a $LOGFILE

exit $?
