#!/bin/bash
# Script Created by: Dinesh Sivasankaran (Price Service Team)
# Created on 27-OCT-2014

# Modified by : Rohan Puranik (For story PS-454)
# Modified date : 06-FEB-2015
# Modified by : Saurabh Kumar (For task PS-359)
# Modified to resolve the monitor.sh failure in Prod where the Couchbase node was missing in the config file
# Modified date : 20-04-2015

. $HOME/.bash_profile
. $PSHOME/profile
. $PSHOME/usr/local/scripts/config.sh

#set -x

STAMP=`date +"%Y%m%d"`
PROG_NAME=$(basename $0 .sh)
SNAME=$(basename $0 ) #Script Name
SSNAME="ps_monitor.sh" #Actual Script name
USER="$(id -u -n)"
PARAM=""
ERROR_MSG=""

LOG_FILE=$LOG_PATH/${PROG_NAME}_log_${STAMP}.log
ERR_FILE=$ERROR_PATH/${PROG_NAME}_err_${STAMP}.log

if [[ -z $LOG_PATH ]];
then
    echo "$(date '+%y/%m/%d %T') : ERROR : the variable LOG_PATH >$LOG_PATH< is not set properly ..."
    exit 1
fi

if [[ -z $ERROR_PATH ]];
then
    echo "$(date '+%y/%m/%d %T') : ERROR : the variable ERROR_PATH >$ERROR_PATH< is not set properly ..."
    exit 1
fi;

PARAM=$(echo $1 | tr [[a-z]] [[A-Z]])

if [[ "$PARAM" != "ALL" && "$PARAM" != "PRIM" && "$PARAM" != "DR" && "$PARAM" != "" ]];
then
	echo "$(date '+%Y-%m-%d %T') : ERROR: The parameter should be [(no parameter)/ALL/PRIM/DR].." | tee -a $LOG_FILE
	echo "$(date '+%Y-%m-%d %T') : ERROR: Return code: ${RC} $SNAME script failed!!" | tee -a $ERR_FILE
	exit 1
fi

if [[ "$PARAM" == "" ]]
then
	PARAM="ALL"
	echo "$(date '+%Y-%m-%d %T') : Job $SNAME started by $USER for NO PARAMETER.." | tee -a $LOG_FILE
else
	echo "$(date '+%Y-%m-%d %T') : Job $SNAME started by $USER for $PARAM PARAMETER.." | tee -a $LOG_FILE
fi

if [[ "$PSENV" == "DEV" || "$PSENV" == "PPE" ]]
then
	if [[ "$PARAM" == "DR" ]]
	then
		echo "$(date '+%Y-%m-%d %T') : ERROR: The parameter for DEV/PPE environment should NOT be [DR].." | tee -a $LOG_FILE
		echo "$(date '+%Y-%m-%d %T') : ERROR: Return code: ${RC} $SNAME script failed!!" | tee -a $ERR_FILE
		exit 1
	fi
fi


curl_log=$LOG_PATH/curl_log

check_couchbase()
{
   fname="check_couchbase"
   echo "$(date '+%Y-%m-%d %T') : $fname - Starting $SNAME for CB ..." | tee -a $LOG_FILE

   if [[ -z $COUCHBASE_HOST ]];
   then
      echo "$(date '+%y/%m/%d %T') : $fname - ERROR : the variable COUCHBASE_HOST <$COUCHBASE_HOST> is not set properly ..." | tee -a $ERR_FILE
      ERROR_MSG="ERROR IN PROGRAM!!" 
   fi;

   if [[ -z $UP ]];
   then
      echo "$(date '+%y/%m/%d %T') : $fname - ERROR : the variable UP <$UP> is not set properly ..." | tee -a $ERR_FILE
      ERROR_MSG="ERROR IN PROGRAM!!"
   fi;

   #Success counter for counting the number of Couchbase nodes up and running
   success_ctr=0
   for ff in ${COUCHBASE_HOST[@]}
   do
       hname=$(echo $ff | awk -F":" '{ print $1 }');

       echo "$(date '+%Y-%m-%d %T') : $fname - Starting $SNAME for CB Server ($hname:$CB_PORT)..." | tee -a $LOG_FILE

       status=$(curl -u $UP -X GET  -s -o $curl_log -w "%{http_code}" http://$hname:$CB_PORT/pools)
       

       if [[ "$status" == "200" ]];
       then
          curl_response=$(cat $curl_log)
          echo "$(date '+%Y-%m-%d %T') : $fname - Couchbase on ($hname:$CB_PORT) running" | tee -a $LOG_FILE
          #echo "$(date '+%Y-%m-%d %T') : $fname - Response from curl is: <$curl_response>" | tee -a $LOG_FILE
          success_ctr=$((success_ctr+1))
          
       else
          echo "$(date '+%Y-%m-%d %T') : $fname - Couchbase on ($hname:$CB_PORT) Node Inactive, curl failed with error,check error log " | tee -a $LOG_FILE
          echo "$(date '+%Y-%m-%d %T') : $fname - Couchbase on ($hname:$CB_PORT) Node Inactive, curl exited with status code : $status" | tee -a $ERR_FILE
          
       fi
   done;

      #Changes for checking the Couchbase nodes up and running

       if [[ "$success_ctr" -ge $REQUIRED_NO_NODES ]]
       then
          echo  "$(date '+%Y-%m-%d %T') : $fname - All the nodes are up and running"  | tee -a $LOG_FILE

       else
          echo  "$(date '+%Y-%m-%d %T') : $fname - All the nodes are not up and running fine.Please check the error log on the faulty node"  | tee -a $ERR_FILE
          echo "$(date '+%Y-%m-%d %T') : $fname - Job $SNAME failed..!!" | tee -a $LOG_FILE
          ERROR_MSG="ERROR IN PROGRAM!!"
           
       fi

   echo "$(date '+%Y-%m-%d %T') : $fname - Completed on all servers ..." | tee -a $LOG_FILE

}
check_supervisor()
{
   fname="check_supervisor";
   echo "$(date '+%Y-%m-%d %T') : Starting $SNAME for supervisor Server ..." | tee -a $LOG_FILE

   SDIR=$PSHOME/usr/local/scripts
   SSNAME="ps_supervisor.sh";

   if [[ -z $PS_SERVERS ]];
   then
      echo "$(date '+%y/%m/%d %T') : $fname - ERROR : the variable PS_SERVERS <$PS_SERVERS> is not set properly ..." | tee -a $ERR_FILE
      ERROR_MSG="ERROR IN PROGRAM!!"
   fi;

   echo "$(date '+%Y-%m-%d %T') : $fname - Starting $SSNAME for Adpater Server ..." | tee -a $LOG_FILE

   $SDIR/$SSNAME "status"

   RC=$?
   if [[ "$RC" -ne "0" ]];
   then
      echo "$(date '+%Y-%m-%d %T') : $fname - Exiting the $SSNAME Check the error log in >$ERR_FILE<" | tee -a $LOG_FILE
      echo "$(date '+%y/%m/%d %T') : $fname - Return code: ${RC} : ERROR : Failed to run $SSNAME in Adapter server ..." | tee -a $ERR_FILE
      ERROR_MSG="ERROR IN PROGRAM!!"
   else
      echo "$(date '+%Y-%m-%d %T') : $fname - Supervisor on Adapter Server running" | tee -a $LOG_FILE
   fi

   for hname in ${PS_SERVERS[@]}
   do
      echo "$(date '+%Y-%m-%d %T') : $fname - Starting $SSNAME for Server ($hname)..." | tee -a $LOG_FILE

      ssh $USER@$hname "$SDIR/$SSNAME status"

      RC=$?
      if [ "$RC" -ne "0" ]; 
      then
         echo "$(date '+%Y-%m-%d %T') : $fname - Exiting the $SSNAME Check the error log in >$ERR_FILE< in server >$hname< " | tee -a $LOG_FILE
         echo "$(date '+%y/%m/%d %T') : $fname - Return code: ${RC} : ERROR : Failed to run $SSNAME in server >$hname< ..." | tee -a $ERR_FILE
         ERROR_MSG="ERROR IN PROGRAM!!"
      else
         echo "$(date '+%Y-%m-%d %T') : $fname - Supervisor on <$hname> Server running" | tee -a $LOG_FILE
      fi
   done;

   echo "$(date '+%Y-%m-%d %T') : $fname - Completed on all servers ..." | tee -a $LOG_FILE

   return $?;
}

check_service()
{
   fname="check_service";
   echo "$(date '+%Y-%m-%d %T') : $fname - Starting $SNAME for Price Server ..." | tee -a $LOG_FILE

   if [[ -z $PS_SERVERS ]];
   then
      echo "$(date '+%y/%m/%d %T') : $fname - ERROR : the variable PS_SERVERS <$PS_SERVERS> is not set properly ..." | tee -a $ERR_FILE
      ERROR_MSG="ERROR IN PROGRAM!!"
   fi;

   #hport=8081
   for ff in ${PS_SERVERS[@]}
   do
       hname=$(echo $ff);

       for pp in ${PS_PORT[@]}
       do
	   hport=$(echo $pp);


           echo "$(date '+%Y-%m-%d %T') : $fname - Starting $SNAME for Server ($hname:$hport)..." | tee -a $LOG_FILE

		   status=$(curl -X GET  -s -o $curl_log -w "%{http_code}" http://$hname:$hport/docs)

           if [[ "$status" == "200" ]];
           then
              curl_response=$(cat $curl_log)
              echo "$(date '+%Y-%m-%d %T') : $fname - PriceService ($hname:$hport) running" | tee -a $LOG_FILE
              #echo "$(date '+%Y-%m-%d %T') : $fname - Response from curl is: <$curl_response>" | tee -a $LOG_FILE
           else
              echo "$(date '+%Y-%m-%d %T') : $fname - PriceService ($hname:$hport) curl failed with error,check error log " | tee -a $LOG_FILE
              echo "$(date '+%Y-%m-%d %T') : $fname - PriceService ($hname:$hport) curl exited with status code : $status" | tee -a $ERR_FILE
              echo "$(date '+%Y-%m-%d %T') : $fname - Job $SNAME failed..!!" | tee -a $LOG_FILE
              ERROR_MSG="ERROR IN PROGRAM!!"
           fi
       done;
   done;

   echo "$(date '+%Y-%m-%d %T') : $fname - Completed on all servers ..." | tee -a $LOG_FILE

   return $?;
}

check_nginx()
{
   fname="check_nginx"

   echo "$(date '+%Y-%m-%d %T') : $fname - Starting Nginx Check for Price Service Servers ..." | tee -a $LOG_FILE

   if [[ -z $PS_SERVERS ]];
   then
      echo "$(date '+%y/%m/%d %T') : $fname - ERROR : the variable PS_SERVERS <$PS_SERVERS> is not set properly ..." | tee -a $ERR_FILE
      ERROR_MSG="ERROR IN PROGRAM!!"
   fi;

   if [[ -z $NGINX_PORT ]];
   then
      echo "$(date '+%y/%m/%d %T') : $fname - ERROR : the variable NGINX_PORT <$NGINX_PORT> is not set properly ..." | tee -a $ERR_FILE
      ERROR_MSG="ERROR IN PROGRAM!!"
   fi;

   hport=$NGINX_PORT

   for hname in ${PS_SERVERS[@]}
   do
      echo "$(date '+%Y-%m-%d %T') : $fname - Starting Nginx check for Server ($hname:$hport)..." | tee -a $LOG_FILE

       status=$(curl -X GET  -s -o $curl_log -w "%{http_code}" http://$hname:$hport)

       RC=$?
       if [ "$RC" -ne "0" ]; 
       then
          echo "$(date '+%Y-%m-%d %T') : $fname - Exiting the $SNAME Check the error log in >$ERR_FILE< in server >$hname< " | tee -a $LOG_FILE
          echo "$(date '+%y/%m/%d %T') : $fname - Return code: ${RC} : ERROR : Failed to run $SNAME in server >$hname< ..." | tee -a $ERR_FILE
          ERROR_MSG="ERROR IN PROGRAM!!"
       fi

       if [[ "$status" == "200" ]];
       then
          curl_response=$(cat $curl_log)
          echo "$(date '+%Y-%m-%d %T') : $fname - PriceService ($hname:$hport) running" | tee -a $LOG_FILE
          #echo "$(date '+%Y-%m-%d %T') : $fname - Response from curl is: <$curl_response>" | tee -a $LOG_FILE
       else
          echo "$(date '+%Y-%m-%d %T') : $fname - PriceService ($hname:$hport) curl failed with error,check error log " | tee -a $LOG_FILE
          echo "$(date '+%Y-%m-%d %T') : $fname - PriceService ($hname:$hport) curl exited with status code : $status" | tee -a $ERR_FILE
          echo "$(date '+%Y-%m-%d %T') : $fname - Job $SNAME failed..!!" | tee -a $LOG_FILE
          ERROR_MSG="ERROR IN PROGRAM!!"
       fi
   done;

   echo "$(date '+%Y-%m-%d %T') : $fname - Completed on all servers ..." | tee -a $LOG_FILE

   return $?;
}

check_nlb()
{
   fname="check_nlb"

   if [[ -z $NLB_SERVER ]];
   then
      echo "$(date '+%y/%m/%d %T') : $fname - ERROR : the variable NLB_SERVER >$NLB_SERVER< is not set properly ..." | tee -a $ERR_FILE
      ERROR_MSG="ERROR IN PROGRAM!!"
   fi;

   if [[ -z $NLB_PORT ]];
   then
      echo "$(date '+%y/%m/%d %T') : $fname - ERROR : the variable NLB_PORT >$NLB_PORT< is not set properly ..." | tee -a $ERR_FILE
      ERROR_MSG="ERROR IN PROGRAM!!"
   fi;
   for ff in ${NLB_SERVER[@]}
   do
   hname=$ff

   echo "$(date '+%Y-%m-%d %T') : $fname - Starting $SNAME for NLB Server <$hname:$NLB_PORT>..." | tee -a $LOG_FILE

   status=$(curl -X GET  -s -o $curl_log -w "%{http_code}" http://$hname:$NLB_PORT)

   if [[ "$status" == "200" ]];
   then
      curl_response=$(cat $curl_log)
      echo "$(date '+%Y-%m-%d %T') : $fname - NLB ($hname:$NLB_PORT)  running" | tee -a $LOG_FILE
     #echo "$(date '+%Y-%m-%d %T') : $fname - Response from curl is: <$curl_response>" | tee -a $LOG_FILE
   else
      echo "$(date '+%Y-%m-%d %T') : $fname - NLB curl failed with error,check error log " | tee -a $LOG_FILE
      echo "$(date '+%Y-%m-%d %T') : $fname - NLB curl exited with status code : $status" | tee -a $ERR_FILE
      echo "$(date '+%Y-%m-%d %T') : $fname - Job $SNAME failed..!!" | tee -a $LOG_FILE
      ERROR_MSG="ERROR IN PROGRAM!!"
   fi
   done;

   echo "$(date '+%Y-%m-%d %T') : $fname - Completed on all servers ..." | tee -a $LOG_FILE

   return $?;
}

check_adapter()
{
   fname="check_adapter";

   echo "$(date '+%Y-%m-%d %T') : $fname - Starting $SNAME for Adapter Price Server ..." | tee -a $LOG_FILE

   if [[ -z $ADAPTER_HOST ]];
   then
      echo "$(date '+%y/%m/%d %T') : $fname - ERROR : the variable PS_SERVERS >$PS_ADAPTERSERVERS< is not set properly ..." | tee -a $ERR_FILE
      ERROR_MSG="ERROR IN PROGRAM!!"
   fi;

   hport=$PORT_SERVICE

   for ff in ${ADAPTER_HOST[@]}
   do
       hname=$(echo $ff | awk -F":" '{ print $1 }');

       echo "$(date '+%Y-%m-%d %T') : $fname - Starting $SNAME for Adapter Server ($hname:$hport)..." | tee -a $LOG_FILE

       status=$(curl -X GET  -s -o $curl_log -w "%{http_code}" http://$hname:$hport/docs)

       if [[ "$status" == "200" ]];
       then
          curl_response=$(cat $curl_log)
          echo "$(date '+%Y-%m-%d %T') : $fname - Adapter PriceService ($hname:$hport) running" | tee -a $LOG_FILE
          #echo "$(date '+%Y-%m-%d %T') : $fname - Response from curl is: <$curl_response>" | tee -a $LOG_FILE
       else
          echo "$(date '+%Y-%m-%d %T') : $fname - Adapter PriceService ($hname:$hport) curl failed with error,check error log " | tee -a $LOG_FILE
          echo "$(date '+%Y-%m-%d %T') : $fname - Adapter PriceService ($hname:$hport) curl exited with status code : $status" | tee -a $ERR_FILE
          echo "$(date '+%Y-%m-%d %T') : $fname -Job $SNAME failed..!!" | tee -a $LOG_FILE
          ERROR_MSG="ERROR IN PROGRAM!!"
       fi
   done;

   echo "$(date '+%Y-%m-%d %T') : $fname - Completed on all servers ..." | tee -a $LOG_FILE

   return $?;
}

check_resource()
{
	echo "$(date '+%Y-%m-%d %T') : Monitoring for environment <$PSENV> started.." | tee -a $LOG_FILE
	check_couchbase
	check_supervisor
	check_service
	check_nginx
	check_adapter
	
	if [[ $PSENV != "DEV" ]];
	then
	   check_nlb
	else
	   echo "$(date '+%Y-%m-%d %T') : Skipping NLB checking for environment of type <$PSENV> " | tee -a $LOG_FILE
	fi;
}

#### This is the beginning of the script #######

echo "$(date '+%Y-%m-%d %T') : Environment is set as <$PSENV> " | tee -a $LOG_FILE

if [[ "$PARAM" == "ALL" ]]
then
	check_resource
	
	if [[ $PSENV == "PROD" ]];
	then
	   PSENV="PROD_DR"
	   . $PSHOME/usr/local/scripts/config.sh
	   
	   check_resource
	fi;
fi

if [[ "$PARAM" == "PRIM" ]]
then
	check_resource
fi

if [[ "$PARAM" == "DR" ]]
then
	if [[ $PSENV == "PROD_DR" ]];
	then
		check_resource
	fi;
fi

if [[ -n $ERROR_MSG ]]
then
	echo "$(date '+%Y-%m-%d %T') : PROGRAM $SNAME is failed!!! Please check the error log for all the error message... <$ERR_FILE>" | tee -a $LOG_FILE
	exit 1
fi

echo "$(date '+%Y-%m-%d %T') : Job $SNAME completed by $USER for $PARAM PARAMETER.." | tee -a $LOG_FILE
exit $?;
