#!/bin/bash
# Script Created by: Dinesh Sivasankaran (Price Service Team)
# Created on 21-OCT-2014

. $HOME/.bash_profile
. $PSHOME/usr/local/scripts/config.sh

STAMP=`date +"%Y%m%d"`
PROG_NAME=$(basename $0 .sh)
SNAME=$(basename $0 ) #Script Name
USER="$(id -u -n)"

LOG_FILE=$LOG_PATH/${PROG_NAME}_log_${STAMP}.log
ERR_FILE=$ERROR_PATH/${PROG_NAME}_err_${STAMP}.log

if [[ -z $LOG_PATH ]];
then
    echo "$(date '+%y/%m/%d %T') : ERROR : the variable LOG_PATH >$LOG_PATH< is not set properly ..."
    exit 1
fi

if [[ -z $ERROR_PATH ]];
then
    echo "$(date '+%y/%m/%d %T') : ERROR : the variable ERROR_PATH >$ERROR_PATH< is not set properly ..."
    exit 1
fi

echo "$(date '+%Y-%m-%d %T') : Job $SNAME started by $USER" | tee -a $LOG_FILE

if [ "$#" -ne 1 ]
then
   echo "Invalid number of arguments" | tee -a $ERR_FILE
   echo "Usage : $SNAME [START|QUIT|STOP|RELOAD|STATUS|ARCHIVE]" | tee -a $ERR_FILE
   echo "Script >$SNAME< Failed .. Please refer to the error file >$ERR_FILE< for more details" | tee -a $LOG_FILE
   exit 1
fi

#PID value
nginx_pid=$(netstat -tulpn | grep nginx  | awk '{ print $7 }' | awk -F"/" '{ print $1 }' )

ps_nginx=$(ps -ef | grep -i nginx | grep -v grep);

if [[ ! -z $nginx_pid ]];
then
   if [[ ! -f $PSHOME/var/run/nginx.pid ]];
   then
       echo "Nginx PID not found <$nginx_pid> and it is not running <$ps_nginx>... (re)creating the PID file <$PSHOME/var/run/nginx.pid>" | tee -a $LOG_FILE
       echo $nginx_pid > $PSHOME/var/run/nginx.pid
   else
       echo "Nginx PID found <$nginx_pid> and it is running <$ps_nginx>... The PID File already present <$PSHOME/var/run/nginx.pid>" | tee -a $LOG_FILE
   fi;
else
   echo "Nginx PID not found <$nginx_pid> and it is not running <$ps_nginx>... removing the PID file <$PSHOME/var/run/nginx.pid>" | tee -a $LOG_FILE
   rm -f $PSHOME/var/run/nginx.pid
fi;

PARM=$(echo $1 | tr -s [[a-z]] [[A-Z]]);

if [[ "$PARM" == "START" ]];
then

   if [[ ! -f $PSHOME/var/run/nginx.pid ]];
   then
      $PSHOME/usr/sbin/nginx
      ret=$?
   else
      echo "Nginx is already running... so exiting" | tee -a $LOG_FILE
      exit 1;
   fi

elif [[ "$PARM" == "QUIT" ]];
then

   if [[ -f $PSHOME/var/run/nginx.pid ]];
   then
      $PSHOME/usr/sbin/nginx -s quit #Graceful shutdown
      ret=$?
   else
      echo "Nginx is not running .. so exiting" | tee -a $LOG_FILE
   fi;

elif [[ "$PARM" == "STOP" ]];
then

   if [[ -f $PSHOME/var/run/nginx.pid ]];
   then
      $PSHOME/usr/sbin/nginx -s stop #Abrupt shutdown
      ret=$?
   else
      echo "Nginx is not running .. so exiting" | tee -a $LOG_FILE
   fi;

elif [[ "$PARM" == "RELOAD" ]];
then

   if [[ ! -f $PSHOME/var/run/nginx.pid ]];
   then
      echo "Nginx is not running .. Starting the nginx!!" | tee -a $LOG_FILE
      $PSHOME/usr/sbin/nginx
      ret=$?
   else
      echo "Nginx is running .. Reloading the nginx!!" | tee -a $LOG_FILE
      $PSHOME/usr/sbin/nginx -s reload
      ret=$?
   fi

elif [[ "$PARM" == "STATUS" ]];
then

   if [[ -f $PSHOME/var/run/nginx.pid ]];
   then
      echo "Nginx is up and running ... Nginx PID is <$nginx_pid>" | tee -a $LOG_FILE
      ret=0
   else
      echo "Nginx is not running .. so exiting" | tee -a $LOG_FILE
      exit 1
   fi;

elif [[ "$PARM" == "ARCHIVE" ]];
then
 
   TIMESTAMP=$(date +"%Y%m%d%H%M%S")
 
   if [[ -f $PSHOME/var/log/nginx_error.log ]];
   then
      echo "Ziping nginx error log ..." | tee -a $LOG_FILE
      gzip $PSHOME/var/log/nginx_error.log
      ret=$?

       if [[ $ret -ne "0" ]];
       then
          echo "$(date '+%y/%m/%d %T') : ERROR : occurred while gzipping the file >$PSHOME/var/log/nginx_error.log< ..." | tee -a $ERR_FILE
          echo "$(date '+%y/%m/%d %T') : ERROR : Please check the file >$ERR_FILE< for details ..." | tee -a $LOG_FILE
          exit 1
       fi;

      echo "Archiving nginx error log ..." | tee -a $LOG_FILE
      mv $PSHOME/var/log/nginx_error.log.gz $PSHOME/var/log/nginx_error.log.$TIMESTAMP.gz
      ret=$?

   fi; 
 
   if [[ -f $PSHOME/var/log/nginx-access.log.gz ]];
   then
      echo "Archiving nginx access log ..." | tee -a $LOG_FILE
      mv $PSHOME/var/log/nginx-access.log.gz $PSHOME/var/log/nginx-access.log.$TIMESTAMP.gz
      ret=$?

       if [[ $ret -ne "0" ]];
       then
          echo "$(date '+%y/%m/%d %T') : ERROR : occurred while archiving the file >$PSHOME/var/log/nginx_error.log.gz< to >$PSHOME/var/log/nginx_error.log.$TIMESTAMP.gz <..." | tee -a $ERR_FILE
          echo "$(date '+%y/%m/%d %T') : ERROR : Please check the file >$ERR_FILE< for details ..." | tee -a $LOG_FILE
          exit 1
       fi;

   fi; 
 
   if [[ -f $PSHOME/var/run/nginx.pid ]];
   then
      echo "Sending User defined signal 1-switch over ..." | tee -a $LOG_FILE
      kill -USR1 `cat $PSHOME/var/run/nginx.pid`
      ret=$?
      sleep 1
   fi;

else
   echo "Script >$SNAME< Failed .. Please refer to the error file >$ERR_FILE< for more details" | tee -a $LOG_FILE
   echo "Invalid number of arguments" | tee -a $ERR_FILE
   echo "Usage : $SNAME [START|QUIT|STOP|RELOAD|STATUS|ARCHIVE]" | tee -a $ERR_FILE
   exit 1
fi;

if [[ $ret -ne "0" ]];
then
   echo "$(date '+%y/%m/%d %T') : ERROR : nginx $1 failed ..." | tee -a $ERR_FILE
   echo "$(date '+%y/%m/%d %T') : ERROR : Please check the file >$PSHOME/var/log/nginx_error.log< for details ..." | tee -a $ERR_FILE
   exit 1
fi;

echo "$(date '+%Y-%m-%d %T') : Job $SNAME completed successfully by $USER" | tee -a $LOG_FILE

exit 0;

