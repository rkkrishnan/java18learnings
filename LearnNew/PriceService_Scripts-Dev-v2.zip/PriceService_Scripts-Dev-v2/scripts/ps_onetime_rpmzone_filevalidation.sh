#!/bin/bash
#Validate the rpmzone onetime files in file share server and returns error code 1 if validation fails
. $HOME/.bash_profile

RC=$?
if [[ $RC -ne 0 ]] ; then
  # Error exit
  echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : $0 failed calling profile script for variable setup"
  exit 1
fi

. $PSHOME/usr/local/scripts/config.sh

RC=$?
if [[ $RC -ne 0 ]] ; then
  # Error exit
  echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : $0 failed calling config script for variable setup"
  exit 1
fi

STAMP=`date +"%Y%m%d"`
PROG_NAME=$(basename $0 .sh)

#file_param=$1

LOG_FILE=$LOG_PATH/${PROG_NAME}_log_${STAMP}.log
ERR_FILE=$ERROR_PATH/${PROG_NAME}_err_${STAMP}.log

if [ ! -d  "$LOG_PATH" ];
then
      echo "Log path is not set. Please set the LOG_PATH"
      exit 1
fi

if [ ! -d  "$ERROR_PATH" ];
then
      echo "Error path is not set. Please set the ERROR_PATH"
      exit 1
fi

. $PSHOME/usr/local/scripts/clearance_config.sh

RC=$?
if [[ $RC -ne 0 ]] ; then
  echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : $0 failed calling clearance config script for variable setup"
  exit 1
fi

SSH_ERR=$SSH_TMP/${PROG_NAME}_err_${STAMP}

USER="$(id -u -n)"

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME started by $USER" | tee -a $LOG_FILE

SERVER=$PS_USER@$FILESHR_HOST

TIMESTAMP=$(date +%Y%m%d%H%M%S)
currentDayDate=$(date +%Y%m%d)

ERROR_CODE=0
ERROR_COUNT=0
storeFileCount=0
storeFilesNum=0

file_param=$(echo $1 | tr [[A-Z]] [[a-z]])

if [[ "$file_param" != "rpmzoneonetime" ]];
then
        echo "$(date '+%Y-%m-%d %T') : ERROR: The parameter should be [rpmzoneonetime].." | tee -a $LOG_FILE
        echo "$(date '+%Y-%m-%d %T') : ERROR: Return code: ${RC} $PROG_NAME script failed!!" | tee -a $ERR_FILE
        exit 1
fi

validateRpmZoneFiles(){

fileInServer=$(ls -l $SRC/$filePattern | wc -l)

   if [[ "$fileInServer" == "0" ]];
   then
      echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
      echo "$(date '+%y/%m/%d %T') : ERROR : RPMZONEONETIME FILE IS MISSING IN FILESHARE SERVER" | tee -a $ERR_FILE
      exit 1
   fi

     if [[ "$fileInServer" -gt "$numFiles" ]];
   then
      echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
      echo "$(date '+%y/%m/%d %T') : ERROR : RPMZONEONETIME FILE ARE MORE THEN EXPECTED IN FILESHARE SERVER.
                                                 NUMBER OF FILE EXPECTED : $numFiles, FILES PRESENT : $fileInServer" | tee -a $ERR_FILE
      exit 1
   fi

 onetimeFile=$(find $SRC -maxdepth 1 -type f)

      for ((i=0; i<${#onetimeFile[@]}; i++))
         do
            tempFile=${onetimeFile[$i]}
            srcFileName=`basename $tempFile`
            tailVal=$(zcat $tempFile | tail -1)

             if [[ "${tailVal:0:5}" != "FTAIL" ]];
               then
                  echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
                  echo "$(date '+%Y-%m-%d %T') : RPMZONEONETIME TAIL RECORD MISSING IN THE RPM_ZONE FILE - $srcFileName" | tee -a $LOG_FILE
                  exit 1
             fi

            tempTailval=${tailVal:5}
            countInTail=`echo $tempTailval | sed 's/ //g' | bc`
            rowCount=$(($(zcat $tempFile | wc -l) -2))

            if [[ "$countInTail" != "$rowCount" ]];
               then
                  echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
                  echo "$(date '+%Y-%m-%d %T') : RPMZONEONETIME NUMBER OF ROWS MISMATCH ON FILE - $srcFileName ,
                                                   COUNT IN TAIL IS - $countInTail , TOTAL ROW COUNT IS - $rowCount" | tee -a $LOG_FILE
                  exit 1
            fi
   done

}

validateRpmZoneFiles

exit $?

