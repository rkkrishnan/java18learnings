#!/bin/bash

. $HOME/.bash_profile
. $PSHOME/profile
. $PSHOME/usr/local/scripts/config.sh
RC=$?

if [[ "$RC" -ne "0" ]];
then
echo "Failed to source the config.sh script for variable setup"
exit 1

fi

set -x

STAMP=`date +"%Y%m%d"`
PROG_NAME=$(basename $0 .sh)
SNAME=$(basename $0 ) #Script Name
USER="$(id -u -n)"

if [[ ! -d $LOG_PATH ]];
then
    echo "$(date '+%y/%m/%d %T') : ERROR : the variable LOG_PATH >$LOG_PATH< is not set properly ..."
    exit 1
fi

if [[ ! -d $ERROR_PATH ]];
then
    echo "$(date '+%y/%m/%d %T') : ERROR : the variable ERROR_PATH >$ERROR_PATH< is not set properly ..."
    exit 1
fi
USAGE="Script accepts one parameter usage: ${PROG_NAME} <uk/roi>  "

if [[ "$#" -ne "1" ]];
then
echo $USAGE
exit 1

fi

PROCESS_UK_ROI=$(echo $1 | tr -s [[A-Z]] [[a-z]] );
log_temp=$LOG_PATH/log_temp_${PROG_NAME}

LOG_FILE=$LOG_PATH/${PROG_NAME}_log_${STAMP}.log
ERR_FILE=$ERROR_PATH/${PROG_NAME}_err_${STAMP}.log

process_param=""
if [[ "$PROCESS_UK_ROI" != "teauthuk" && "$PROCESS_UK_ROI" != "teauthroi"  ]];
then
   echo "$(date '+%Y-%m-%d %T') : ERROR : First  parameter is Invalid "| tee -a $ERR_FILE
   echo $usage
   exit 1
elif [[ "$PROCESS_UK_ROI" == "teauthuk" ]];
then
   process_param="uk"

elif [[ "$PROCESS_UK_ROI" == "teauthroi" ]];
then
   process_param="roi"
fi

echo "$(date '+%Y-%m-%d %T') : Job $SNAME started by $USER for $1" | tee -a $LOG_FILE

files=$(ls -rS ${SRC_TEAUTH}/${process_param}/${TEAUTH_FILE_PATTERN} |tail -n1)
filename=$(basename $files)
#To invoke the rest call with filename as a parameter
status=$(curl -X POST -s -o $log_temp -w "%{http_code}" http://$ADAPTER_HOST:$PORT_SERVICE/${TEAUTH_URL_EANSEED}/${process_param}/${filename})

curl_response=$(cat $log_temp)
#sleep 10 

if [ "$status" -eq "000" ];
then
   echo "$(date '+%Y-%m-%d %T') : REST call failed due to connectivity error,check error log" | tee -a $LOG_FILE
   echo "$(date '+%Y-%m-%d %T') : curl exited with status code : $status" | tee -a $ERR_FILE
   exit 1
fi

curl_response=$(cat $log_temp)
echo "$(date '+%Y-%m-%d %T') : Response from curl is: >" $curl_response | tee -a $LOG_FILE
echo "the status is $status"
if [ "$status" == "200" ];
then
   echo "$(date '+%Y-%m-%d %T') : Rest call successfull  for $filename" | tee -a $LOG_FILE
else
   echo "$(date '+%Y-%m-%d %T') : REST call failed with  error,check error log" | tee -a $LOG_FILE
   echo "$(date '+%Y-%m-%d %T') : curl exited with status code : $status" | tee -a $ERR_FILE
   exit 1

fi

   #%%%%%%%%%%%%%%%%%%%%%%%%%%JAVA Process Progress check%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   while [[ true ]]; do

      #sleep period
      sleep $SLEEP_PERIOD
      
      #REST call to check if import in progress or not
      status=$(curl -X GET  -s -o $log_temp -w "%{http_code}" http://$ADAPTER_HOST:$PORT_SERVICE/${TEAUTH_URL_PROG_CHK}/${filename})
      #sleep 90
      if [ "$status" == "000" ];
      then
         echo "$(date '+%Y-%m-%d %T') : Import progress check failed check error file" | tee -a $LOG_FILE
         echo "$(date '+%Y-%m-%d %T') : curl exited with status code : $status" | tee -a $ERR_FILE
         echo "the status is" $status
         echo "Job $PROG_NAME failed..!!"
         exit 1

      elif [ "$status" == "200" ];
      then
         output=$(cat $log_temp)

         #check if import is in progress
         # echo $output | grep  "import.*:.*progress"

         ret=$(echo $output | grep -c "import.*:.*progress" )

         #if in progress sleep 60 and the check again
          if [[ "$ret" -eq "0" ]];
          then
             #echo $output | grep "import.*:.*aborted"
             ret=$(echo $output | grep -c "import.*:.*aborted")
              if [[ "$ret" -ne "0" ]];
              then
                 #import has errored,log and exit 1
                 echo "$(date '+%Y-%m-%d %T') : Import activity is aborted ,check script error log and adapter error logs for more info" | tee -a  $LOG_FILE
                 echo "$(date '+%Y-%m-%d %T') : ERROR from adapter is $output" | tee -a $ERR_FILE
                 echo "Job $PROG_NAME failed..!!"
                 exit 1
              else
                 # Import is successful!!!
                 echo "$(date '+%Y-%m-%d %T') : Import Completed successfully" | tee -a $LOG_FILE
                 echo "$(date '+%Y-%m-%d %T') : Output from restcall is >$output<" | tee -a $LOG_FILE
                 break
               fi

            else
               echo "Import still in progress"
            fi

         else
            echo "$(date '+%Y-%m-%d %T') : Import progress check failed check error file" | tee -a  $LOG_FILE
            echo "$(date '+%Y-%m-%d %T') : Import activity failed-exited with status:$status " | tee -a  $ERR_FILE
            echo "Job $PROG_NAME failed..!!"
            exit 1
         fi
done

echo "$(date '+%Y-%m-%d %T') : $PROG_NAME has completed successfully..!!" | tee -a  $LOG_FILE
exit $?

