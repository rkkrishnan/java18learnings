#!/bin/bash
#Archive the teauth files in file share server from in/teauth/uk or roi to in_arch/teauth/uk or roi 
. $HOME/.bash_profile

RC=$?
if [[ $RC -ne 0 ]] ; then
  # Error exit
  echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : $0 failed calling profile script for variable setup"
  exit 1
fi

. $PSHOME/usr/local/scripts/config.sh

RC=$?
if [[ $RC -ne 0 ]] ; then
  # Error exit
  echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : $0 failed calling config script for variable setup"
  exit 1
fi

STAMP=`date +"%Y%m%d"`
PROG_NAME=$(basename $0 .sh)

#file_param=$1

LOG_FILE=$LOG_PATH/${PROG_NAME}_log_${STAMP}.log
ERR_FILE=$ERROR_PATH/${PROG_NAME}_err_${STAMP}.log

if [ ! -d  "$LOG_PATH" ];
then
      echo "Log path is not set. Please set the LOG_PATH"
      exit 1
fi

if [ ! -d  "$ERROR_PATH" ];
then
      echo "Error path is not set. Please set the ERROR_PATH"
      exit 1
fi

. $PSHOME/usr/local/scripts/clearance_config.sh

RC=$?
if [[ $RC -ne 0 ]] ; then
  echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : $0 failed calling clearance config script for variable setup"
  exit 1
fi

SSH_ERR=$SSH_TMP/${PROG_NAME}_err_${STAMP}

USER="$(id -u -n)"

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME started by $USER" | tee -a $LOG_FILE

SERVER=$PS_USER@$FILESHR_HOST

TIMESTAMP=$(date +%Y%m%d%H%M%S)
currentDayDate=$(date +%Y%m%d)

file_param=$(echo $1 | tr [[A-Z]] [[a-z]])

if [[ "$file_param" != "teauthuk" && "$file_param" != "teauthroi" ]];
then
        echo "$(date '+%Y-%m-%d %T') : ERROR: The parameter should be [teauthuk|teauthroi].." | tee -a $LOG_FILE
        echo "$(date '+%Y-%m-%d %T') : ERROR: Return code: ${RC} $PROG_NAME script failed!!" | tee -a $ERR_FILE
        exit 1
fi

archiveTeauthFiles() {

      filesInSrc=$(find $SRC  -maxdepth 1 -type f)

      currentValue=''
      for i in $filesInSrc
         do
            currentValue=`basename $i`
            if [[ "$currentValue" == *.gz ]];
               then
                  filename=$(basename $currentValue .gz)
                  TIMESTAMP=$(date +%Y%m%d%H%M%S)
                  append_date=${filename}_${TIMESTAMP}.gz

            elif [[ "$currentValue" == *.trg ]];
                then
                   filename=$(basename $currentValue .trg)
                   TIMESTAMP=$(date +%Y%m%d%H%M%S)
                   append_date=${filename}_${TIMESTAMP}.trg
            fi
           mv $SRC/${currentValue} $ARCHIVE/${append_date}

           RC=$?

           if [ "$RC" -ne "0" ];
              then
                 echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
                 echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR :Teauth Files Archive Failed" | tee -a $ERR_FILE
                 exit 1
           fi

     done
}

archiveTeauthFiles

exit $?
