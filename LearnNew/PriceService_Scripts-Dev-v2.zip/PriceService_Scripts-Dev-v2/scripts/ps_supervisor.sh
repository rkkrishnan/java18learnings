#!/bin/bash
# Script Created by: Dinesh Sivasankaran (Price Service Team)
# Created on 21-OCT-2014

. $HOME/.bash_profile
. $PSHOME/profile
. $PSHOME/usr/local/scripts/config.sh
#set -x

STAMP=`date +"%Y%m%d"`
PROG_NAME=$(basename $0 .sh)
SNAME=$(basename $0 ) #Script Name
USER="$(id -u -n)"

LOG_FILE=$LOG_PATH/${PROG_NAME}_log_${STAMP}.log
ERR_FILE=$ERROR_PATH/${PROG_NAME}_err_${STAMP}.log

if [[ -z $LOG_PATH ]];
then
    echo "$(date '+%y/%m/%d %T') : ERROR : the variable LOG_PATH >$LOG_PATH< is not set properly ..."
    exit 1
fi

if [[ -z $ERROR_PATH ]];
then
    echo "$(date '+%y/%m/%d %T') : ERROR : the variable ERROR_PATH >$ERROR_PATH< is not set properly ..."
    exit 1
fi

echo "$(date '+%Y-%m-%d %T') : Job $SNAME started by $USER.. Hostname is <`hostname`>" | tee -a $LOG_FILE

if [ "$#" -ne 1 ]
then
   echo "Invalid number of arguments" | tee -a $ERR_FILE
   echo "Usage : $SNAME [START|STOP|STATUS]" | tee -a $ERR_FILE
   echo "Script >$SNAME< Failed .. Please refer to the error file >$ERR_FILE< for more details" | tee -a $LOG_FILE
   exit -1
fi

#Check resources for firing the curl command and inducing a sleep mode for the adapter/service servers

check_resource_for_curl()
{
   echo "$(date '+%Y-%m-%d %T') : Checking resources for invoking curl for environment <$PSENV> started.." | tee -a $LOG_FILE

   if [[ $PSENV_TYPE == "ADAPTER" ]];
    then   
      check_adapter_for_curl

   elif [[ $PSENV_TYPE == "SERVICE" ]];
    then
      check_service_for_curl
   fi;
      ret=$?
   
   if [[ $ret -ne "0" ]];
    then
      echo "$(date '+%Y-%m-%d %T') : CURL ERROR: script >$SNAME< Failed .. Please refer to the error file >$ERR_FILE< for more details" | tee -a $LOG_FILE 
      exit 1 
   fi;
  
   echo "$(date '+%Y-%m-%d %T') : Checking resources for invoking curl completed for environment <$PSENV>..."
   return $ret;
}

check_status_for_supervisor()
{
   fname="check_status_for_supervisor";
   typeset -i counter=1;
   typeset -i failed_flag=1
   
   while [ true ]
   do
      if [[ $counter -ge  $ITERATION_COUNT ]];
      then
         echo "$(date '+%Y-%m-%d %T') : $fname - ERROR : Unable to stop the service after $ITERATION_COUNT attempts.." | tee -a  $LOG_FILE
         break;
      else
         sleep $SLEEPTIME_SUPERVISOR
      fi
   
      # Check the status by calling supervisor script with param STATUS
      $PSHOME/usr/local/scripts/ps_supervisor.sh STATUS
      RC=$?
      if [ "$RC" -ne "0" ];
      then
         echo "$(date '+%Y-%m-%d %T') : $fname - Successfully stopped the service.."| tee -a  $LOG_FILE
         failed_flag=0
         break;
      fi

      counter=$((counter+1))
   done;
   #done for while loop 
   
   if [[ $failed_flag -ne 0 ]];
   then
      echo "$(date '+%Y-%m-%d %T') : $fname - Please check in the server.."| tee -a  $LOG_FILE
      exit 1
   fi
   
   echo "$(date '+%Y-%m-%d %T') : Checking status completed for <`hostname`>..."| tee -a  $LOG_FILE
   return 0;
}

PARM=$(echo $1 | tr -s [[a-z]] [[A-Z]]);

if [[ "$PARM" == "START" ]];
then
   status=$(python $PSHOME/usr/bin/supervisord -c $PSHOME/etc/supervisord.conf)
   ret=$?

   if [[ $ret -ne "0" || $status -ne 0 ]];
   then
      echo "$(date '+%y/%m/%d %T') : ERROR: script >$SNAME< Failed .. Please refer to the error file >$ERR_FILE< for more details" | tee -a $LOG_FILE
      echo "$(date '+%y/%m/%d %T') : ERROR : supervisor status is <$status> and retcode is <$ret> ..." | tee -a $ERR_FILE
      echo "$(date '+%y/%m/%d %T') : ERROR : supervisor error status is <$estatus> and retcode is <$ret1> ..." | tee -a $ERR_FILE
      exit 1
   fi;
   
   check_resource_for_curl
  
elif [[ "$PARM" == "STOP" ]];
then
   status=$(python $PSHOME/usr/bin/supervisorctl -c $PSHOME/etc/supervisord.conf shutdown)
   ret=$?
   
   check_status_for_supervisor
   
elif [[ "$PARM" == "STATUS" ]];
then
   status=$(python $PSHOME/usr/bin/supervisorctl -c $PSHOME/etc/supervisord.conf status)
   ret=$?

   estatus=$(echo $status | awk '{ print $2 }' | grep -cv "RUNNING" )

   echo "$(date '+%y/%m/%d %T') : STATUS : supervisor status is <$status> and retcode is <$ret> ..." | tee -a $LOG_FILE
   echo "$(date '+%y/%m/%d %T') : ERROR-STATUS : supervisor error status is <$estatus> and retcode is <$ret1> ..." | tee -a $LOG_FILE

else
   echo "$(date '+%y/%m/%d %T') : ERROR: script >$SNAME< Failed .. Please refer to the error file >$ERR_FILE< for more details" | tee -a $LOG_FILE
   echo "Invalid number of arguments" | tee -a $ERR_FILE
   echo "Usage : $SNAME [START|QUIT|STOP|RELOAD]" | tee -a $ERR_FILE
   exit -1
fi;

if [[ $ret -ne "0" || $estatus -ne 0 ]];
then
   echo "$(date '+%y/%m/%d %T') : ERROR: script >$SNAME< Failed .. Please refer to the error file >$ERR_FILE< for more details" | tee -a $LOG_FILE
   echo "$(date '+%y/%m/%d %T') : ERROR : supervisor status is <$status> and retcode is <$ret> ..." | tee -a $ERR_FILE
   echo "$(date '+%y/%m/%d %T') : ERROR : supervisor error status is <$estatus> and retcode is <$ret1> ..." | tee -a $ERR_FILE
   exit 1
fi;

echo "$(date '+%Y-%m-%d %T') : Job $SNAME completed successfully by $USER.. Hostname is <`hostname`>" | tee -a $LOG_FILE

exit 0;
