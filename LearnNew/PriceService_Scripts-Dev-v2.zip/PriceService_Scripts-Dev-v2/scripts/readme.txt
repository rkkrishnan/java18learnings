This folder would contain the scripts -
1) Application shell scripts 
