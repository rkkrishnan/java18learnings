#!/bin/bash

STAMP=`date +"%Y%m%d"`
PROG_NAME=$(basename $0 .sh)
USER="$(id -u -n)"
SLOTS=2
PERCENTILE="95,99,99.5,99.9";

. $HOME/.bash_profile
RC=$?
if [[ $RC -ne 0 ]] ; then
        # Error exit
        echo "$(date '+%Y-%m-%d %T %Z') : Return code: ${RC} : ERROR : ${PROG_NAME} failed calling profile script for variable setup"
        exit 1
fi

. $PSHOME/usr/local/scripts/config.sh
RC=$?
if [[ $RC -ne 0 ]] ; then
        # Error exit
        echo "$(date '+%Y-%m-%d %T %Z') : Return code: ${RC} : ERROR : ${PROG_NAME} failed calling config script for variable setup"
        exit 1
fi

#set -x

LOGFILE=$LOG_PATH/${PROG_NAME}_log_${STAMP}.log
ERRFILE=$ERROR_PATH/${PROG_NAME}_err_${STAMP}.log

if [[ ! -d "$LOG_PATH" ]];
then
   echo "$(date '+%Y-%m-%d %T %Z') : Log path is not set. Please set the LOG_PATH."
   exit 1
fi

if [[ ! -d  "$ERROR_PATH" ]];
then
   echo "$(date '+%Y-%m-%d %T %Z') : Error path is not set. Please set the ERROR_PATH."
   exit 1
fi

echo "$(date '+%Y-%m-%d %T %Z') - Script ${PROG_NAME} invoked with parameters inputFile ($1) nginxFile ($2) " | tee -a $LOGFILE

inputFile=$(echo $1);

if [[ -z $inputFile ]];
then
   echo "$(date '+%Y-%m-%d %T %Z') : ERROR : inputFile ($inputFile) Parameter Missing ... Exiting" | tee -a $LOGFILE
   echo "$(date '+%Y-%m-%d %T %Z') : ERROR : Invalid Number of  Arguments to run the code - Usage: $0 <inputFile> [nginxFile]" | tee -a $LOGFIL_E
   exit 1;
fi;

nginxFile=$(echo $2);

if [[ -z $nginxFile ]];
then
   fileParam="nginx.log"
   echo "$(date '+%Y-%m-%d %T %Z') : INFO : Parameter Missing ... Defaulting the Parameter to $nginxFile" | tee -a $LOGFILE
fi;

if [[ ! -f $nginxFile ]];
then
   echo "$(date '+%Y-%m-%d %T %Z') : ERROR : Nginx log file ($nginxFile) missing ... Exiting" | tee -a $LOGFILE
   exit 1;
fi;

failed=${LOG_PATH}/${PROG_NAME}.$STAMP.failed
reportFile1=${LOG_PATH}/${PROG_NAME}.report1.$STAMP.log
reportFile2=${LOG_PATH}/${PROG_NAME}.report2.$STAMP.log
finalReportFile=$inputFile."final.csv"
#finalReportFile=1."final.csv"

#set -x 
rm -f $reportFile1

rm -f $reportFile2

echo "$(date '+%Y-%m-%d %T %Z') - Script ${PROG_NAME} started " | tee -a $LOGFILE

format_jobs()
{
   #set -x
   jnos="$#"
   pjobs="$1"
   shift
   for j
   do
      pjobs="$pjobs,$j"
   done
}

find_jobs()
{
   #set -x
   if [[ $pjobs == "" ]];
   then
     nnos=0;
     njobs="";
     return;
   fi;

   set -- `ps -p $pjobs | awk '$1 ~ /^[0-9]/ { print $1 }'`
   njobs="$*"

   pjobs=$njobs
   jobs=$pjobs

   nnos=$#
   jmsg="$pnos $jnos Jobs"
}

invoke()
{
   IFS=$old_IFS     # restore default field separator 

   fname=$1;
   dt=$2
   method=$3
   cnt=$4


# first awk is required for sorting
output=$(awk -v dt="$dt" -v "method=$method" -F"^" ' BEGIN { split(dt,a,"|"); } { for ( i in a ) { if ( substr($2,5,11) == a[i] && $3 ~ method && $4 ~ /200/ ) { print $6 } } }' $fname | 
#head -1000 |
sort -n  | 
awk -v PERCENTILE="$PERCENTILE" '
BEGIN {totalcnt=0; i=1;  split(PERCENTILE,a,",") }
{ s[i]=$1; i++; totalcnt++; }  # store the entire list of response times in an array
END {
print "total count:", totalcnt;
print ",";
n=asort(a); # Added to fix the array sorting issue
#for ( i in a ) # loop through the array of percentile
for (i = 1; i <= n; i++) # loop through the array of percentile
{
  per = a[i];
  #print "per", i, per;
  if ( (per/100)*NR != int( (per/100)*NR )) {
   if ( ( (per/100)*NR - int( (per/100)*NR) ) >= 0.5 ) { 
       #print "inside", (per/100)*NR, int( (per/100)*NR), s[int( (per/100)*NR )+1]; 
       #print s[int( (per/100)*NR )+1]; 
       b[i]=s[int( (per/100)*NR )+1]; 
   } else {
      #print "inside else", (per/100)*NR, int( (per/100)*NR), s[int( (per/100)*NR )]; 
      #print s[int( (per/100)*NR )]; 
      b[i]=s[int( (per/100)*NR )]; 
   }
  } else {
  if ( per == 100 ) { 
     #print s[NR]; 
     b[i]= s[NR]; 
   } else {
     #print "else", (per/100)*NR, int( (per/100)*NR)  , (s[(per/100)*NR]+s[(per/100)*NR+1])/2  ;
     #print (s[(per/100)*NR]+s[(per/100)*NR+1])/2;
     b[i]=(s[(per/100)*NR]+s[(per/100)*NR+1])/2;
   }
  }
#print "1... b[i]", b[i]
}
first=1;
m=asort(b); # Added to fix the array sorting issue
#for ( i in b )
for (i = 1; i <= m; i++) # loop through the array 
{
   #print "2... b[i]", b[i]

   if ( first == 1 ) {
     c=b[i]
     first=0;
   }
   else {
      c=c","b[i]
   }
   #print "3... c, b[i]", c, b[i]
}
#print varArray[2];
#printf("arrays %s,%s\n", varArray[2], c);
print c;
}'
)

ret=$?

if [[ $ret -ne "0" ]];
then
    echo "Occured while calculating the percentile details <$ret>"
    touch $failed
    return 1;
fi;

echo "output <$output>"

echo $cnt, $dt, $method, $output >> $reportFile1

} # end of invoke function

invokeWrapper()
{
   #set -x
   dt=$1
   input=$2
   cnt=$3

   ( invoke "$nginxFile" "$dt" "POST" "$cnt" || return 1)  &

   ( invoke "$nginxFile" "$dt" "GET" "$cnt" || return 1)  &

   wait;

   fileDt=$(echo $input | awk -F"," '{ split($1,a," "); printf("%s/%s/%s\n", a[2],substr(a[3],1,3),a[4] ) }')

   postPercentile=$( cat $reportFile1 | grep -w "^$cnt" | grep -w "$dt" | grep "POST" | awk -F ',' '{ printf("%.2f,%.2f,%.2f,%.2f", $5*1000, $6*1000, $7*1000, $8*1000); }')
   getPercentile=$( cat $reportFile1 | grep -w "^$cnt" | grep -w "$dt" | grep "GET" | awk -F ',' '{ printf("%.2f,%.2f,%.2f,%.2f", $5*1000, $6*1000, $7*1000, $8*1000); }')

   finalFormat1=$(echo $input | awk -v postPercentile="$postPercentile" -F ',' '{ printf("%s,%s,%s,%s,%s,%s",$1,$2,postPercentile,$3,$5,$6); }')

   finalFormat2=$(echo $input | awk -v getPercentile="$getPercentile" -F ',' '{ printf("%s,%s,%s,%s,%s",$7,getPercentile,$8,$10,$11); }' )

   echo $cnt,$finalFormat1,$finalFormat2 | tee -a $reportFile2
}

#for ff in $(cat $inputFile | tail -9 | head -7 | awk -F"," '{ split($1,a," "); printf("%s/%s/%s\n", a[2],substr(a[3],1,3),a[4] ) }' | head -1)

old_IFS=$IFS      # save the field separator           
IFS=$'\n'     # new field separator, the end of line        

typeset -i processCnt=0;

catdt=""

#headCnt=$( wc -l $InputFile | awk '{ print $1-2 }')
#headCnt=echo $tailCnt | awk '{ print $1 - 1 

#for ff in $(cat $inputFile | tail -9 | head -7 )
for ff in $(cat $inputFile | grep -wE "Sunday|Monday|Tuesday|Wednesday|Thursday|Friday|Saturday" )
do

   dt=$(echo $ff | awk -F"," '{ split($1,a," "); printf("%s/%s/%s\n", a[2],substr(a[3],1,3),a[4] ) }')

   catdt=$catdt"|"$dt

   input=$ff

   processCnt=$processCnt+1;

   find_jobs

   while [ $nnos -gt $SLOTS ]
   do
     sleep 1
     find_jobs
   done

   echo "$(date '+%Y-%m-%d %T %Z') - Invoked Percentile calculation for date ($dt) and input record ($ff)" | tee -a $LOGFILE
   ( invokeWrapper $dt "$input" $processCnt || touch $failed ) &

   job=$!
   jobs=$( echo "$jobs $job" | sed 's/^\ *//g')
   format_jobs $jobs

done;

   find_jobs

   while [ $nnos -gt $SLOTS ]
   do
     sleep 1
     find_jobs
   done

input=$(cat $inputFile | tail -1)
catdt=$(echo $catdt | sed 's/^|//g')

echo "$(date '+%Y-%m-%d %T %Z') - Invoked Percentile calculation for summary  ($catdt) and input record ($input)" | tee -a $LOGFILE
invokeWrapper $catdt "$input" "99" || touch $failed 

   job=$!
   jobs=$( echo "$jobs $job" | sed 's/^\ *//g')
   format_jobs $jobs

echo "$(date '+%Y-%m-%d %T %Z') - Waiting for the background process to complete" | tee -a $LOGFILE
wait;

#set -x

header=$( echo "Date, BULK count, 95th Percentile (ms), 99th Percentile (ms), 99.5th Percentile (ms), 99.9th Percentile (ms), Avg. Response (ms), Request Error (4xx), Server Error (5xx), SINGLE count, 95th Percentile (ms), 99th Percentile (ms), 99.5th Percentile (ms), 99.9th Percentile (ms), Avg. Response (ms), Request Error (4xx), Server Error (5xx)" )

tailer=$( cat $inputFile | tail -2 | head -1 )

echo "$(date '+%Y-%m-%d %T %Z') - Preparing the final format" | tee -a $LOGFILE

echo $header > $finalReportFile

for ff in $(cat $reportFile2 | sort -t',' -k1 -n)
do
  if [[ $(echo $ff | awk -F',' '{ print $1 }' | sed -e 's/^\ *//g' -e 's/,$//g') == "99" ]];
  then
      echo $tailer >> $finalReportFile
  fi;

  echo $ff | awk -F',' 'BEGIN {ORS=",";} { for (i=2; i <= NF; i++) { printf("%s,",$i); } }' | sed -e 's/^\ *//g' -e 's/,$//g' >> $finalReportFile
  echo >> $finalReportFile
done;


IFS=$old_IFS     # restore default field separator 

echo "$(date '+%Y-%m-%d %T %Z') - Script completed successfully" | tee -a $LOGFILE
