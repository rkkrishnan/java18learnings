#!/bin/bash

DATA_IN=$PSHOME/data/in
ARCHIVE=$PSHOME/data/in_arch
LOG_PATH=$PSHOME/log
VAR_LOG_PATH=$PSHOME/var/log
LOG_PATH_NGINX=$PSHOME/var/log/nginx
ERROR_PATH=$PSHOME/error
PS_USER=prcsrvce
AUTOSYS_LOG_PATH=$PSHOME/autosys/log
REJECT=$PSHOME/data/rej
REJECT_ARCHIVE=$PSHOME/data/rej_arch
SRC_TEAUTH=$PSHOME/data/in/teauth
TEAUTH_ARCHIVE_UK=$PSHOME/data/in_arch/teauth/uk
TEAUTH_ARCHIVE_ROI=$PSHOME/data/in_arch/teauth/roi
AVG_WEIGHT_UK=$PSHOME/data/in_arch/sonettouk

if [[ "$PSENV" == "DEV" ]]
then
                #In days
                PRG_LOG_DIR=($LOG_PATH $VAR_LOG_PATH $LOG_PATH_NGINX $ERROR_PATH $AUTOSYS_LOG_PATH)
                PRG_DIR_LOG_RET=(7 7 14 7 14)
                PRG_DATA_DIR=($ARCHIVE $REJECT_ARCHIVE $TEAUTH_ARCHIVE_UK $TEAUTH_ARCHIVE_ROI $AVG_WEIGHT_UK)
                PRG_DIR_DATA_RET=(7 7 2 2 7)
				#PRG_REJECT_DIR=($REJECT_ARCHIVE)
                #PRG_DIR_REJECT_RET=(7)


                #Fileshare server IP
                FILESHR_HOST=dvprcfserv001uk.dev.global.tesco.org

                log_temp=$PSHOME/log

                #List of service servers used by ps_restartall.sh and ps_stopall.sh
                PS_SERVERS=(dvprcsrvce001uk.dev.global.tesco.org)

                #NGINX Details
                NGINX_PORT=8080

                PS_PORT=8081

elif [[ "$PSENV" == "PPE" ]]
then
                #In days
                PRG_LOG_DIR=($LOG_PATH $VAR_LOG_PATH $LOG_PATH_NGINX $ERROR_PATH $AUTOSYS_LOG_PATH)
                PRG_DIR_LOG_RET=(7 7 14 7 14)
                PRG_DATA_DIR=($ARCHIVE $REJECT_ARCHIVE $TEAUTH_ARCHIVE_UK $TEAUTH_ARCHIVE_ROI $AVG_WEIGHT_UK)                
                PRG_DIR_DATA_RET=(7 7 2 2 7)
		        #PRG_REJECT_DIR=($REJECT_ARCHIVE)
                #PRG_DIR_REJECT_RET=(7)

                #Fileshare server IP
                FILESHR_HOST=ppeprcfserv001uk.globalppe.tesco.org

                log_temp=$PSHOME/log

                #couchbase server ip
                PS_SERVERS=(ppeprcsrvce001uk.globalppe.tesco.org ppeprcsrvce002uk.globalppe.tesco.org ppeprcsrvce003uk.globalppe.tesco.org)

                NGINX_PORT=8080

                PS_PORT=8081


elif [[ "$PSENV" == "PROD" ]]
then
                #In days
                PRG_LOG_DIR=($LOG_PATH $VAR_LOG_PATH $LOG_PATH_NGINX $ERROR_PATH $AUTOSYS_LOG_PATH)
                PRG_DIR_LOG_RET=(7 7 14 7 14)
                PRG_DATA_DIR=($ARCHIVE $REJECT_ARCHIVE $TEAUTH_ARCHIVE_UK $TEAUTH_ARCHIVE_ROI $AVG_WEIGHT_UK)                
                PRG_DIR_DATA_RET=(7 7 2 2 7)
		        #PRG_REJECT_DIR=($REJECT_ARCHIVE)
                #PRG_DIR_REJECT_RET=(7)

                #Fileshare server IP
                FILESHR_HOST=pvprcfserv001uk.global.tesco.org

                #couchbase server ip
                log_temp=$PSHOME/log

               #List of service servers used by ps_restartall.sh and ps_stopall.sh
                PS_SERVERS=(pvprcsrvce001uk.global.tesco.org pvprcsrvce002uk.global.tesco.org pvprcsrvce003uk.global.tesco.org)

                #NGINX Details
                NGINX_PORT=8080

                PS_PORT=8081

elif [[ "$PSENV" == "PROD_DR" ]]
then
                #In days
                PRG_LOG_DIR=($LOG_PATH $VAR_LOG_PATH $LOG_PATH_NGINX $ERROR_PATH $AUTOSYS_LOG_PATH)
                PRG_DIR_LOG_RET=(7 7 14 7 14)
                PRG_DATA_DIR=($ARCHIVE $REJECT_ARCHIVE $TEAUTH_ARCHIVE_UK $TEAUTH_ARCHIVE_ROI $AVG_WEIGHT_UK)
                PRG_DIR_DATA_RET=(7 7 2 2 7)

   		        #PRG_REJECT_DIR=($REJECT_ARCHIVE)
                #PRG_DIR_REJECT_RET=(7)
				
                #Fileshare server IP
                FILESHR_HOST=pvprcfserv002uk.global.tesco.org


                log_temp=$PSHOME/log



                #List of service servers used by ps_restartall.sh and ps_stopall.sh
                PS_SERVERS=(pvprcsrvce004uk.global.tesco.org pvprcsrvce005uk.global.tesco.org pvprcsrvce006uk.global.tesco.org)

                #NGINX Details
                NGINX_PORT=8080

                PS_PORT=8081

fi
