This folder would contain the scripts configuration files (It does not require
application restart and only deployment is required) -
1) profile.sh
2) config.sh
3) clearance_config.sh
4) config_purge.sh
