#!/bin/bash
#
# Modified By : - Nibedita Panda
# Last Modified: - 20140112
# Created Sprint: - Sprint 16
# Functionality: -  Tail Record and total detail record count validation based on parameter.
# Usage: - Program Name - validateFile
#                                        Input Arguments - moduletype(ex : price_promo , acayg , mmreg),filename
#          Output Expected - should log the error if validation fails in any of the file and set ERROR_CODE to 1 except for CMHOPS file
# Modified By : - Nibedita Panda
# Last Modified: - 20150205
# Created Sprint: - Sprint 18
# Functionality: -  Common Archive script
# Usage: - Program Name - archiveFiles
#                                        Input Arguments - filePattern(ex : pricepromo , acayg , mmreg)
#          Output Expected - should archive the file by appending timestamp and if no files available to archive it should not fail.
# Modified By : - Nitisha/Nibedita
# Last Modified: - 20150318
# Created Sprint: - Sprint 21
# Functionality: -  DR archiving for TEAUTH files
# Usage: - Program Name - archiveFiles
#          Input Arguments - filePattern
#          Output Expected - should archive the file by appending timestamp and if no files available to archive it should not fail.
# Modified By : - Nibedita
# Last Modified: - 20150522
# Created Sprint: - Sprint 25
# Functionality: -  Changes for rpmzone one time functionality
# Modified By : - Nibedita
# Last Modified: - 20150812
# Created Sprint: - Sprint 31/32
# Functionality: To generalize the script to archive of files in DR,file patterns added in each type

SRC=$PSHOME/data/in
ARCHIVE=$PSHOME/data/in_arch
TEMP=$PSHOME/data/files
SSH_TMP=$PSHOME/log
LOG_PATH=$PSHOME/log
ERROR_PATH=$PSHOME/error
PS_USER=prcsrvce
DESTINATION=$PSHOME/data/in
fileParam=$1
ERROR_CODE=0
PRICEZONE="PRICE_ZONE.csv"
PROMOZONE="PROM_ZONE.csv"
PROMOEXTRACT="PROM_EXTRACT.csv"
CMHOPOS="PROM_DESC_EXTRACT_full_dump.csv"
STOREZONE="STORE_ZONE.csv"
STAMP=`date +"%Y%m%d"`

# File name for onetime Promotions
onetime_promo_file_name_SP="tsl_ps_promoextract_SP_*.dat*"
onetime_promo_file_name_TH="tsl_ps_promoextract_TH_*.dat*"
onetime_promo_file_name_MB="tsl_ps_promoextract_MB_*.dat*"

onetime_price_file_name="tsl_ps_priceextract_*_*.dat*"

        scrFilesMMemer=(
                 "MML.MMEXPRCH.DAILY.EMERG.ARCHIVE.*.gz"
                 "MML.MMEXPRCH.DAILY.EMERG.ARCHIVE.*.trg"
        )
        scrFilesMMreg=(
                 "MML.MMEXPRCH.MARKDOWN.ARCHIVE.*.gz"
                 "MML.MMEXPRCH.MARKDOWN.ARCHIVE.*.trg"
                )
        scrFilesMMondemand=(
                 "MML.MMEXPRCH.DAILY.ARCHIVE.*.gz"
                 "MML.MMEXPRCH.DAILY.ARCHIVE.*.trg"
                )
        destFilesMMemer=(
                "MM_CLR_DATA.dat"
             )
        destFilesMMreg=(
                 "MM_CLR_DATA.dat"
                )
        destFilesMMondemand=(
                 "MM_CLR_DATA.dat"
                )

        srcFilesAcayg=(
                "CLRPC_ACAYG_1_*.pub.gz"
                "CLRPC_ACAYG_2_*.pub.gz"
                "CLRPC_ACAYG_3_*.pub.gz"
                "CLRPC_ACAYG_4_*.pub.gz"
                )

        srcFilesRegNonranged=(
                "tsl_clearancenonrangeddm_2_*.txt.gz"
                )

        srcFilesRegRanged=(
                "CLRPC_DLR_1_*.pub.gz"
                "CLRPC_DLR_2_*.pub.gz"
                "CLRPC_DLR_3_*.pub.gz"
                "CLRPC_DLR_4_*.pub.gz"
                )

        srcFilesEmerRanged=(
                "CLRPC_EMER_*.pub.gz"
                )

         srcFilesEmerNonranged=(
                "tsl_clearancenonrangeddm_1_*.txt.gz"
                )
         srcFilesRpmOneTime=(
                "tsl_clearancenonrangeddm_1_*.txt.gz"
                "CLRPC_EMER_*.pub.gz"
                )


        destFilesAcayg=(
                "CLRPC_ACAYG_1.pub"
                "CLRPC_ACAYG_2.pub"
                "CLRPC_ACAYG_3.pub"
                "CLRPC_ACAYG_4.pub"
                )

        destFilesRegNonranged=(
                 "tsl_clearancenonrangeddm_2.txt"
                )

        destFilesRegRanged=(
                "CLRPC_DLR_1.pub"
                "CLRPC_DLR_2.pub"
                "CLRPC_DLR_3.pub"
                "CLRPC_DLR_4.pub"
              )

        destFilesEmerRanged=(
                "CLRPC_EMER*.pub"
                )

        destFilesEmerNonranged=(
                "tsl_clearancenonrangeddm_1.txt"
                )
				
		srcFilesAdapter=(
                "CLEARANCE_CRE.txt"
                "CLEARANCE_MOD.txt"
                "CLEARANCE_DEL.txt"
                )

         srcFilesTeauthUK=(
                "KLL.KLBRNODS.TEAUTH.KL179_*.gz"
                "KLL.KLTEAUTH*.gz"
            )

         srcFilesTeauthROI=(
                "KLL.KLBRNODS.TEAUTH.KL179.ROI_*.gz"
                "KLL.KLTEAUTH*.gz"
            )

         srcFilesRpmZoneOneTime=(
                "tsl_rpm_zone_onetime_*.csv.gz"
                )
         destFilesRpmZoneOneTime=(
                "tsl_rpm_zone_onetime.csv"
                )
         
         srcFilesCompetitor=(
                "TescoDirect-Amazon-*.zip.gz"
                "TescoDirect-Argos-*.zip.gz"
                "TescoDirect-AsdaDirect-*.zip.gz"
                "TescoDirect-BandQ-*.zip.gz"
                "TescoDirect-Currys-*.zip.gz"
                "TescoDirect-DunelmMill-*.zip.gz"
                "TescoDirect-Halfords-*.zip.gz"
                "TescoDirect-JohnLewis-*.zip.gz"
                "TescoDirect-Mothercare-*.zip.gz"
                "TescoDirect-ToysrUs-*.zip.gz"
                "TescoDirect-WHSmith-*.zip.gz"
                "TescoDirect-Wilkinson-*.zip.gz"
                )
           destFilesCompetitor=(
                "TescoDirect-Amazon-*.txt"
                "TescoDirect-Argos-*.txt"
                "TescoDirect-AsdaDirect-*.txt"
                "TescoDirect-BandQ-*.txt"
                "TescoDirect-Currys-*.txt"
                "TescoDirect-DunelmMill-*.txt"
                "TescoDirect-Halfords-*.txt"
                "TescoDirect-JohnLewis-*.txt"
                "TescoDirect-Mothercare-*.txt"
                "TescoDirect-ToysrUs-*.txt"
                "TescoDirect-WHSmith-*.txt"
                "TescoDirect-Wilkinson-*.txt"
                )
if [[ "$fileParam" == "netvide" ]]
then
         
         SRC=$PSHOME/data/in/netvide
         ARCHIVE=$PSHOME/data/in_arch/netvide
		 SLEEP_TIME=3
		 numoftries=2
         srcfile=("${srcFilesCompetitor[@]}")
         numFiles=${#srcFilesCompetitor[@]}
         destfile=${srcFilesCompetitor[@]}
		 LOAD_PATH=$PSHOME/data/files/load_netvide
         TEMP_PATH=$PSHOME/data/files/netvide
		 DONE_PATH=$PSHOME/data/files/load_netvide/done
         DEST_PATH=$PSHOME/data/in/netvide
         filePattern="TescoDirect-*"
         filePatternToArch="TescoDirect-*"
         srcFilePattern=("${filePatternToArch[@]}")


		
elif [[ "$fileParam" == "acayg" ]]
then
         srcfile=("${srcFilesAcayg[@]}")
         numFiles=${#srcFilesAcayg[@]}
         destfile=${destFilesAcayg[@]}
         TEMP_PATH=$PSHOME/data/files/acayg
         DEST_PATH=$PSHOME/data/in/acayg
         CREFILE=$TEMP_PATH/cre.txt
         MODFILE=$TEMP_PATH/mod.txt
         DELFILE=$TEMP_PATH/del.txt
         filePattern="CLRPC_ACAYG_*"
         filePatternToArch="CLRPC_ACAYG_*"
         srcFilePattern=("${filePatternToArch[@]}")


elif [[ "$fileParam" == "regranged" ]]
then
         srcfile=("${srcFilesRegRanged[@]}")
         numFiles=${#srcFilesRegRanged[@]}
         destfile=${destFilesRegRanged[@]}
         TEMP_PATH=$PSHOME/data/files/regranged
         DEST_PATH=$PSHOME/data/in/regranged
         CREFILE=$TEMP_PATH/cre.txt
         MODFILE=$TEMP_PATH/mod.txt
         DELFILE=$TEMP_PATH/del.txt
         filePattern="CLRPC_DLR_*"
         filePatternToArch="CLRPC_DLR_*"
         srcFilePattern=("${filePatternToArch[@]}")


elif [[ "$fileParam" == "regnonranged" ]]
then
         srcfile=("${srcFilesRegNonranged[@]}")
         numFiles=${#srcFilesRegNonranged[@]}
         destfile=${destFilesRegNonranged[@]}
         TEMP_PATH=$PSHOME/data/files/regnonranged
         DEST_PATH=$PSHOME/data/in/regnonranged
         CREFILE=$TEMP_PATH/cre.txt
         MODFILE=$TEMP_PATH/mod.txt
         DELFILE=$TEMP_PATH/del.txt
         filePattern="tsl_clearancenonrangeddm_2_*"
         filePatternToArch="tsl_clearancenonrangeddm_2_*"
         srcFilePattern=("${filePatternToArch[@]}")


elif [[ "$fileParam" == "emerranged" ]]
then
         srcfile=("${srcFilesEmerRanged[@]}")
         numFiles=${#srcFilesEmerRanged[@]}
         destfile=${destFilesEmerRanged[@]}
         TEMP_PATH=$PSHOME/data/files/emerranged
         DEST_PATH=$PSHOME/data/in/emerranged
         CREFILE=$TEMP_PATH/cre.txt
         MODFILE=$TEMP_PATH/mod.txt
         DELFILE=$TEMP_PATH/del.txt
         filePattern="CLRPC_EMER*"
         filePatternToArch="CLRPC_EMER*"
         srcFilePattern=("${filePatternToArch[@]}")


elif [[ "$fileParam" == "emernonranged" ]]
then
        srcfile=("${srcFilesEmerNonranged[@]}")
        numFiles=${#srcFilesEmerNonranged[@]}
        destfile=${destFilesEmerNonranged[@]}
        TEMP_PATH=$PSHOME/data/files/emernonranged
        DEST_PATH=$PSHOME/data/in/emernonranged
        CREFILE=$TEMP_PATH/cre.txt
        MODFILE=$TEMP_PATH/mod.txt
        DELFILE=$TEMP_PATH/del.txt
        filePattern="tsl_clearancenonrangeddm_1_*"
        filePatternToArch="tsl_clearancenonrangeddm_1_*"
        srcFilePattern=("${filePatternToArch[@]}")



elif [[ "$fileParam" == "mmemer" ]]
then
         srcfile=("${scrFilesMMemer[@]}")
         #scrtrgfile=("${srcFilesMMemertrg[@]}")
         numFiles=${#scrFilesMMemer[@]}
         #numFilestrg=${#srcFilesMMemertrg[@]}
         destfile=("${destFilesMMemer[@]}")
         TEMP_PATH=$PSHOME/data/files/mmemer
         DEST_PATH=$PSHOME/data/in/mmemer
         DEST_PATHREM=$PSHOME/data/in/mmemer/MM_CLR_DATA.dat
         filePattern="MML.MMEXPRCH.DAILY.EMERG.ARCHIVE.*.*"
         filesearchPattern="MML.MMEXPRCH.DAILY.EMERG.ARCHIVE.*.trg"
         filePatternToArch="MML.MMEXPRCH.DAILY.EMERG.ARCHIVE.*.* MML.MMEXPRCH.DAILY.EMERG.ARCHIVE.*.trg"
         srcFilePattern=("${filePatternToArch[@]}")


elif [[ "$fileParam" == "mmreg" ]]
then
         srcfile=("${scrFilesMMreg[@]}")
         scrtrgfile=("${srcFilesMMregtrg[@]}")
         numFilestrg=${#srcFilesMMregtrg[@]}
         numFiles=${#scrFilesMMreg[@]}
         destfile=("${destFilesMMreg[@]}")
         TEMP_PATH=$PSHOME/data/files/mmreg
         DEST_PATH=$PSHOME/data/in/mmreg
         DEST_PATHREM=$PSHOME/data/in/mmreg/MM_CLR_DATA.dat
         filePattern="MML.MMEXPRCH.MARKDOWN.ARCHIVE.*.*"
         filesearchPattern="MML.MMEXPRCH.MARKDOWN.ARCHIVE.*.trg"
         filePatternToArch="MML.MMEXPRCH.MARKDOWN.ARCHIVE.*.* MML.MMEXPRCH.MARKDOWN.ARCHIVE.*.trg"
         srcFilePattern=("${filePatternToArch[@]}")

elif [[ "$fileParam" == "mmondemand" ]]
then
         srcfile=("${scrFilesMMondemand[@]}")
         scrtrgfile=("${srcFilesMMondemandtrg[@]}")
         numFilestrg=${#srcFilesMMondemandtrg[@]}
         numFiles=${#scrFilesMMondemand[@]}
         destfile=("${destFilesMMondemand[@]}")
         TEMP_PATH=$PSHOME/data/files/mmondemand
         DEST_PATH=$PSHOME/data/in/mmondemand
         DEST_PATHREM=$PSHOME/data/in/mmondemand/MM_CLR_DATA.dat
         filePattern="MML.MMEXPRCH.DAILY.ARCHIVE.*.*"
         filesearchPattern="MML.MMEXPRCH.DAILY.ARCHIVE.*.trg"
         filePatternToArch="MML.MMEXPRCH.DAILY.ARCHIVE.*.* MML.MMEXPRCH.DAILY.ARCHIVE.*.trg"
         srcFilePattern=("${filePatternToArch[@]}")


elif [[ "$fileParam" == "onetime" ]]
then
         srcfile=("${srcFilesRpmOneTime[@]}")
         numFiles=${#srcFilesRpmOneTime[@]}
         TEMP_PATH=$PSHOME/data/files/onetime
         DEST_PATH=$PSHOME/data/in/onetime
         TEMP_ONETIME_FILE="$TEMP_PATH/onetime_temp"
         CREFILE=$TEMP_PATH/cre.txt
         MODFILE=$TEMP_PATH/mod.txt
         DELFILE=$TEMP_PATH/del.txt
         filePattern="CLRPC_EMER* $SRC/tsl_clearancenonrangeddm_1_*"
         filePatternToArch="CLRPC_EMER* tsl_clearancenonrangeddm_1_*"
         srcFilePattern=("${filePatternToArch[@]}")

elif [[ "$fileParam" == "pricepromo" ]]
then
         filePattern="tsl_rpm_price_srvc*.csv.gz"
         filePatternCmhopos="CH_offers_desc*.csv.gz"
         filePatternToArch="tsl_rpm_price_srvc*.csv.gz CH_offers_desc*.csv.gz"
         srcFilePattern=("${filePatternToArch[@]}")


elif [[ "$fileParam" == "teauthuk" ]]
then
         SRC=$PSHOME/data/in/teauth/uk
         ARCHIVE=$PSHOME/data/in_arch/teauth/uk
         DEST_PATH=$PSHOME/data/in/teauth/uk
         TEMP_PATH=$PSHOME/data/files/teauth/uk
         srcfile=("${srcFilesTeauthUK[@]}")
         numFiles=${#srcFilesTeauthUK[@]}
         teauthFilePatternStore="KLL.KLTEAUTH.B*"
         teauthFilePatternControl="KLL.KLBRNODS.TEAUTH.KL179_*"
         teauthFilePatternTrigger="KLL.KLTEAUTH_UK_*.trg"
         location_type="UK"
         filePatternToArch="KLL.KLTEAUTH.B* KLL.KLBRNODS.TEAUTH.KL179_* KLL.KLTEAUTH_UK_*.trg"
         srcFilePattern=("${filePatternToArch[@]}")


elif [[ "$fileParam" == "teauthroi" ]]
then
         SRC=$PSHOME/data/in/teauth/roi
         ARCHIVE=$PSHOME/data/in_arch/teauth/roi
         DEST_PATH=$PSHOME/data/in/teauth/roi
         TEMP_PATH=$PSHOME/data/files/teauth/roi
         srcfile=("${srcFilesTeauthROI[@]}")
         numFiles=${#srcFilesTeauthROI[@]}
         teauthFilePatternStore="KLL.KLTEAUTH.B*"
         teauthFilePatternControl="KLL.KLBRNODS.TEAUTH.KL179.ROI_*"
         teauthFilePatternTrigger="KLL.KLTEAUTH_ROI_*.trg"
         location_type="ROI"
         filePatternToArch="KLL.KLTEAUTH.B* KLL.KLBRNODS.TEAUTH.KL179.ROI_* KLL.KLTEAUTH_ROI_*.trg"
         srcFilePattern=("${filePatternToArch[@]}")


elif [[ "$fileParam" == "rpmzoneonetime" ]]
then
         SRC=$PSHOME/data/in/rpmzoneonetime
         ARCHIVE=$PSHOME/data/in_arch/rpmzoneonetime
         DEST_PATH=$PSHOME/data/in/rpmzoneonetime
         TEMP_PATH=$PSHOME/data/files/rpmzoneonetime
         filePattern="tsl_ps_zone_onetime_*.csv.gz"
         filePatternToArch="tsl_ps_zone_onetime_*.csv.gz"
         srcFilePattern=("${filePattern[@]}")
		 filepattern_import="tsl_ps_zone_onetime_*.csv"
         importUrl="admin/importRPMZone/rpmzoneonetime"
         importInProgressUrl="admin/importInProgress/rpmzoneonetime"
         ReqNoFiles=1


elif [[ "$fileParam" == "rpmzonegrouponetime" ]]
then
         SRC=$PSHOME/data/in/rpmzonegrouponetime
         ARCHIVE=$PSHOME/data/in_arch/rpmzonegrouponetime
         DEST_PATH=$PSHOME/data/in/rpmzonegrouponetime
         TEMP_PATH=$PSHOME/data/files/rpmzonegrouponetime
         filePattern="tsl_ps_zonegroup_onetime_*.csv.gz"
         filePatternToArch="tsl_ps_zonegroup_onetime_*.csv.gz"
         srcFilePattern=("${filePattern[@]}")
	     filepattern_import="tsl_ps_zonegroup_onetime_*.csv"
         importUrl="admin/importRPMZoneGroup/rpmzonegrouponetime"
         importInProgressUrl="admin/importInProgress"
         ReqNoFiles=1

elif [[ "$fileParam" == "onetimepromotionsp" ]]
then
         SRC=$PSHOME/data/in/onetimepromotion
         ARCHIVE=$PSHOME/data/in_arch/onetimepromotion
         DEST_PATH=$PSHOME/data/in/onetimepromotion
         TEMP_PATH=$PSHOME/data/files/onetimepromotion
         filePattern="tsl_ps_promoextract_SP_*.dat.gz"
         filePatternToArch="tsl_ps_promoextract_SP_*.dat.gz"
         srcFilePattern=("${filePatternToArch[@]}")

elif [[ "$fileParam" == "onetimepromotionth" ]]
then
         SRC=$PSHOME/data/in/onetimepromotion
         ARCHIVE=$PSHOME/data/in_arch/onetimepromotion
         DEST_PATH=$PSHOME/data/in/onetimepromotion
         TEMP_PATH=$PSHOME/data/files/onetimepromotion
         filePattern="tsl_ps_promoextract_TH_*.dat.gz"
         filePatternToArch="tsl_ps_promoextract_TH_*.dat.gz"
         srcFilePattern=("${filePatternToArch[@]}")

elif [[ "$fileParam" == "onetimepromotionmb" ]]
then
         SRC=$PSHOME/data/in/onetimepromotion
         ARCHIVE=$PSHOME/data/in_arch/onetimepromotion
         DEST_PATH=$PSHOME/data/in/onetimepromotion
         TEMP_PATH=$PSHOME/data/files/onetimepromotion
         filePattern="tsl_ps_promoextract_MB_*.dat.gz"
         filePatternToArch="tsl_ps_promoextract_MB_*.dat.gz"
         srcFilePattern=("${filePatternToArch[@]}")

elif [[ "$fileParam" == "onetimeprice" ]]
then
		 SRC=$PSHOME/data/in
         ARCHIVE=$PSHOME/data/in_arch/onetimeprice
         DEST_PATH=$PSHOME/data/in/onetimeprice
         TEMP_PATH=$PSHOME/data/files/onetimeprice
         filePattern="tsl_ps_priceextract_*_*.dat.gz"
         filePatternToArch="tsl_ps_priceextract_*_*.dat.gz"
         srcFilePattern=("${filePatternToArch[@]}")
		 
elif [[ "$fileParam" == "subgroup_dflt_uom" ]]
then
         SRC=$PSHOME/data/in/subgroup_dflt_uom
         ARCHIVE=$PSHOME/data/in_arch/subgroup_dflt_uom
         DEST_PATH=$PSHOME/data/in/subgroup_dflt_uom
         TEMP_PATH=$PSHOME/data/files/subgroup_dflt_uom
         filePattern="subgroup_dflt_uom*.dat.gz"
         filePatternToArch="subgroup_dflt_uom*.dat.gz"
         srcFilePattern=("${filePattern[@]}")
         importUrl="admin/importSubGroupDefault/subgroup_dflt_uom"
         importInProgressUrl="admin/importInProgress/subgroup_dflt_uom"
         ReqNoFiles=1

		 
elif [[ "$fileParam" == "product_avg_weight_uk" ]]
then
	 
	 if [[ "$PSENV" == "PROD" ]]
	 then
	    REMOTE_USER="prcsrvce"
        REMOTE_SERVER="ukirp035.global.tesco.org"
		REMOTE_PATH="/appl/priceservice/received/sonetto/uk"
		REMOTE_ARCHIVE_PATH="/appl/priceservice/archive/sonetto/uk"
		
	  elif [[ "$PSENV" == "PPE" ]]
	  then
	    REMOTE_USER="prcsrvce"
	    REMOTE_SERVER="ppeprcfserv001uk.globalppe.tesco.org"
		REMOTE_PATH="/appl/prcsrvce/data/files"
		REMOTE_ARCHIVE_PATH="/appl/prcsrvce/data/files"
		
	   elif [[ "$PSENV" == "DEV" ]]
	  then
	    REMOTE_USER="prcsrvce"
	    REMOTE_SERVER="dvprcfserv001uk.dev.global.tesco.org"
		REMOTE_PATH="/appl/prcsrvce/data/files"
		REMOTE_ARCHIVE_PATH="/appl/prcsrvce/data/files"
	 fi
	 
	 REMOTE_FILE_PATTERN="Products_*.xml"
	 #Wait time in seconds	 
	 WAIT_TIME=3600
         ARCHIVE=$PSHOME/data/in_arch/sonettouk
	     SRC=$PSHOME/data/in/sonettouk
         DEST_PATH=$PSHOME/data/in/sonettouk
         TEMP_PATH=$PSHOME/data/files/sonettouk
         filePattern="Products_*.xml.gz"
         filePatternToArch="Products_*.xml.gz"
         srcFilePattern=("${filePattern[@]}")
	     filepattern_import="Products_*.xml"
	     ReqNoFiles=1
		 importUrl="admin/importavgweight/sonettouk"
         importInProgressUrl="admin/importInProgress"

elif [[ "$fileParam" == "product_avg_weight_roi" ]]
then

     if [[ "$PSENV" == "PROD" ]]
	 then
	    REMOTE_USER="prcsrvce"
        REMOTE_SERVER="ukirp035.global.tesco.org"
		REMOTE_PATH="/appl/priceservice/received/sonetto/roi"
		REMOTE_ARCHIVE_PATH="/appl/priceservice/archive/sonetto/roi"
		
	  elif [[ "$PSENV" == "PPE" ]]
	  then
	    REMOTE_USER="prcsrvce"
	    REMOTE_SERVER="ppeprcfserv001uk.globalppe.tesco.org"
		REMOTE_PATH="/appl/prcsrvce/data/files"
		REMOTE_ARCHIVE_PATH="/appl/prcsrvce/data/files"
		
	   elif [[ "$PSENV" == "DEV" ]]
	  then
	    REMOTE_USER="prcsrvce"
	    REMOTE_SERVER="dvprcfserv001uk.dev.global.tesco.org"
		REMOTE_PATH="/appl/prcsrvce/data/files"
		REMOTE_ARCHIVE_PATH="/appl/prcsrvce/data/files"
	 fi
	 
         REMOTE_FILE_PATTERN="Products_*.xml"
         #Wait time in seconds
         WAIT_TIME=3600
         ARCHIVE=$PSHOME/data/in_arch/sonettoroi
         SRC=$PSHOME/data/in/sonettoroi
         DEST_PATH=$PSHOME/data/in/sonettoroi
         TEMP_PATH=$PSHOME/data/files/sonettoroi
         filePattern="Products_*.xml.gz"
         filePatternToArch="Products_*.xml.gz"
         srcFilePattern=("${filePattern[@]}")
         filepattern_import="Products_*.xml"
         ReqNoFiles=1
         importUrl="admin/importavgweight/sonettoroi"
         importInProgressUrl="admin/importInProgress"
		 
elif [[ "$fileParam" == "estdprice" ]]
then
         SRC=$PSHOME/data/in/estdprice
         ARCHIVE=$PSHOME/data/in_arch/estdprice
         DEST_PATH=$PSHOME/data/in/estdprice
         TEMP_PATH=$PSHOME/data/files/estdprice
         #Example file pattern: tsl_ps_estd_price_<onetime|regular>_<threadno>_<yyyymmdd>.csv.gz
         filePattern="tsl_ps_estd_price_*_*_*.csv.gz"
         filePatternToArch="tsl_ps_estd_price_*_*_*.csv.gz"
         srcFilePattern=("${filePattern[@]}")
		 filepattern_import="tsl_ps_estd_price_*_*_*.csv"
         importUrl="admin/importEstablishedPrice/estdprice"
         importInProgressUrl="admin/importInProgress"
         #Required number of files is not used in this case.
         ReqNoFiles=""
		 
elif [[ "$fileParam" == "futureOfferDesc" ]]
then
         SRC=$PSHOME/data/in/futureOfferDesc
         ARCHIVE=$PSHOME/data/in_arch/futureOfferDesc
         DEST_PATH=$PSHOME/data/in/futureOfferDesc
         TEMP_PATH=$PSHOME/data/files/futureOfferDesc
		 filePattern_import="CH_offers_desc*.csv"
		 srcFilePattern=("${filePattern[@]}")
         importUrl="admin/importFutureOfferDesc/futureOfferDesc"
         importInProgressUrl="admin/importInProgress"
         #Required number of files is not used in this case.
         ReqNoFiles="1"
		 
elif [[ "$fileParam" == "futureOfferDesc_fs" ]]
then
         SRC=$PSHOME/data/in/
         ARCHIVE=$PSHOME/data/in_arch/futureOfferDesc
         DEST_PATH=$PSHOME/data/in/futureOfferDesc
         TEMP_PATH=$PSHOME/data/files/futureOfferDesc
         filePattern="CH_offers_desc*.csv.gz"
         srcFilePattern=("${filePattern[@]}")
         #Required number of files is not used in this case.
         ReqNoFiles="1"

elif [[ "$fileParam" == "oneTimeFutureOfferDesc" ]]
then
         SRC=$PSHOME/data/in/oneTimeFutureOfferDesc
         ARCHIVE=$PSHOME/data/in_arch/oneTimeFutureOfferDesc
         DEST_PATH=$PSHOME/data/in/oneTimeFutureOfferDesc
         TEMP_PATH=$PSHOME/data/files/oneTimeFutureOfferDesc
		 filePattern_import="CH_offers_desc*.csv"
		 srcFilePattern=("${filePattern[@]}")
         importUrl="admin/importFutureOfferDesc/oneTimeFutureOfferDesc"
         importInProgressUrl="admin/importInProgress"
         #Required number of files is not used in this case.
         ReqNoFiles="1"
		 
elif [[ "$fileParam" == "oneTimeFutureOfferDesc_fs" ]]
then
         SRC=$PSHOME/data/in/
         ARCHIVE=$PSHOME/data/in_arch/oneTimeFutureOfferDesc
         DEST_PATH=$PSHOME/data/in/oneTimeFutureOfferDesc
         TEMP_PATH=$PSHOME/data/files/oneTimeFutureOfferDesc
         filePattern="CH_offers_desc*.csv.gz"
         srcFilePattern=("${filePattern[@]}")
         #Required number of files is not used in this case.
         ReqNoFiles="1"
		 
#parameter defined for fileWatcher to check CMHopos file.  

elif [[ "$fileParam" == "choffers" ]]
then
         SRC=$PSHOME/data/in
         ARCHIVE=$PSHOME/data/in_arch
         DEST_PATH=$PSHOME/data/in
         TEMP_PATH=$PSHOME/data/files
		 #Wait time in seconds
         WAIT_TIME=3600
		 SLEEP_TIME=60
         numoftries=5
         filePattern="CH_offers_desc*.csv.gz"
         #Required number of files is not used in this case.
         ReqNoFiles="1"

elif [[ "$fileParam" == "item_dflt_uom" ]]
then
         SRC=$PSHOME/data/in/item_dflt_uom
         ARCHIVE=$PSHOME/data/in_arch/item_dflt_uom
         DEST_PATH=$PSHOME/data/in/item_dflt_uom
         TEMP_PATH=$PSHOME/data/files/item_dflt_uom
         filePattern="item_dflt_uom_*.dat.gz"
         filePatternToArch="item_dflt_uom_*.dat.gz"
         srcFilePattern=("${filePattern[@]}")
         importUrl="admin/importItemDefaultUom/item_dflt_uom"
         importInProgressUrl="admin/importInProgress/item_dflt_uom"
         #Required number of files is not used in this case.
         ReqNoFiles="1"
         
elif [[ "$fileParam" == "EVENTPUBLISH" ]]
then
        publishURL=("scheduledEventAdmin/publishPriceChangeEvent" "scheduledEventAdmin/publishClearanceEndEvent" "scheduledEventAdmin/publishClearanceStartEvent" "scheduledEventAdmin/publishZoneLevelPromotionStart" "scheduledEventAdmin/publishZoneLevelPromotionEnd" "scheduledEventAdmin/publishPromotionStartProduct");
        progressPublishURL=("scheduledEventAdmin/scheduledEventJobStatus/PriceChange" "scheduledEventAdmin/scheduledEventJobStatus/ClearanceEnd" "scheduledEventAdmin/scheduledEventJobStatus/ClearanceStart" "scheduledEventAdmin/scheduledEventJobStatus/PromotionStart" "scheduledEventAdmin/scheduledEventJobStatus/PromotionEnd" "scheduledEventAdmin/scheduledEventJobStatus/PromotionStartProduct");
	SLEEP_PERIOD=30
	FIRST_SLEEP_PERIOD=5
        SLOTS=2

elif [[ "$fileParam" == "PRICESTATS" ]]
then
     MAIL_SUBJECT="$PSENV - PriceService Statistics For Period"
     MAIL_RECIPIENTS="05_HSC_TeamBrass@in.tesco.com"
     MAIL_BODY="Please find attached the performance stats for Price Service. 

This is a system generated E-mail, please do not reply."

elif [[ "$fileParam" == "CLIENTSTATS" ]];
then
     SCRIPTSDIR="$PSHOME/usr/local/scripts"
     NGINXFILE="${LOG_PATH}/nginx.log"
     CLIENTLISTFILE="$SCRIPTSDIR/ps_clientlist.txt"
     STATFILENAME="PriceService_Client_Stats"
     MAIL_SUBJECT="$PSENV - PriceService Client Usage Statistics For Period"
     MAIL_RECIPIENTS="05_HSC_TeamBrass@in.tesco.com"
     MAIL_BODY="Please find attached the Client usage stats for Price Service. 

This is a system generated E-mail, please do not reply."

#else
         #echo "The file parameter is not Valid.Usage: [acayg|regranged|regnonranged|emerranged|emernonranged|mmemer|mmreg|mmondemand|onetime|pricepromo|teauthuk|teauthroi|rpmzoneonetime|rpmzonegrouponetime|onetimepromotionsp|onetimepromotionth|onetimepromotionmb|onetimeprice|subgroup_dflt_uom|product_avg_weight_uk|product_avg_weight_roi|estdprice]"
         #exit 1
fi


#Validate the input files for head,tail and record count
validateFile() {

   function_param=$1
   price_file=$2

   if [[ "$function_param" == "price_promo" ]];
   then
      if [[ "${price_file}" != "CH_offers_"* ]];
         then
            tailVal=$(tail $TEMP/$price_file -n1|cut -d '|' -f1)
            tailCount=$(tail $TEMP/$price_file -n1|cut -c6-25)
            tempTailval=${tailVal:6}
            countInTail=`echo $tempTailval | sed 's/ //g' | bc`
            rowCount=$(($(wc -l < $TEMP/$price_file) -2))

            if [[ "${tailVal:0:5}" != "FTAIL" ]];
               then
                  echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
                  echo "$(date '+%Y-%m-%d %T') : $price_file - TAIL RECORD IS NOT AVAILABLE" | tee -a $LOG_FILE
                  #exit 1
                  ERROR_CODE=1

            elif [[ "$countInTail" != "$rowCount" ]];
               then
                  echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
                  echo "$(date '+%Y-%m-%d %T') : $price_file - RECORD COUNT INCORRECT" | tee -a $LOG_FILE
                  #exit 1
                  ERROR_CODE=1
            fi
   fi


   elif [[ "$function_param" == "mmreg" ]];
   then
      testArray=$(find $TEMP_PATH -maxdepth 1 -type f)

      for ((i=0; i<${#testArray[@]}; i++))
         do
            tempFile=${testArray[$i]}
            currentValue=`basename $tempFile`
            fileDest="${destfile[$i]}"
            headVal=$(head $tempFile -n1|cut -d '|' -f1)
            tailVal=$(tail $tempFile -n1|cut -d '|' -f1)
            tailCount=$(tail $tempFile -n1|cut -c2-11)
            tempTailval=${tailVal:1}
            countInTail=`echo $tempTailval | sed 's/ //g' | bc`
            rowCount=$(($(wc -l < $tempFile) -2))

            if [[ "${headVal:0:1}" != 0 ]];
               then
                  echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
                  echo "$(date '+%Y-%m-%d %T') : HEAD RECORD IS NOT AVAILABLE" | tee -a $LOG_FILE
                  exit 1

            elif [[ "${tailVal:0:1}" != 9 ]];
               then
                  echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
                  echo "$(date '+%Y-%m-%d %T') : TAIL RECORD IS NOT AVAILABLE" | tee -a $LOG_FILE
                  exit 1

            elif [[ "$countInTail" != "$rowCount" ]];
               then
                  echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
                  echo "$(date '+%Y-%m-%d %T') : RECORD COUNT INCORRECT" | tee -a $LOG_FILE
                  exit 1
            fi
      done
elif [[ "$function_param" == "acayg" ]];
   then
      testArray=$(find $TEMP_PATH -maxdepth 1 -type f)
      currentValue=''

      for i in $testArray
         do
			currentValue=`basename $i`

            headVal=$(head $i -n1|cut -d '|' -f1)
            tailVal=$(tail $i -n1|cut -d '|' -f1)
            rowCount=$(wc -l < $i)
            fileDate=$(head $i -n1|cut -d '|' -f4)
            systemDate=$(date +%Y%m%d)
            countInTail=$(tail $i -n1|cut -d '|' -f2)

            if [[ "$headVal" != "FHEAD" || "$tailVal" != "FTAIL" ]];
               then
                  echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
                  echo "$(date '+%Y-%m-%d %T') : HEAD OR TAIL RECORD IS NOT AVAILABLE" | tee -a $LOG_FILE
                  exit 1

            elif [ "$rowCount" != "$countInTail" ];
               then
                  echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
                  echo "$(date '+%Y-%m-%d %T') : RECORD COUNT INCORRECT" | tee -a $LOG_FILE
                  exit 1
            fi

      done
else
      echo "The parameter for validation is not specified properly.Usage: [acayg|regranged|regnonranged|emerranged|emernonranged|mmemer|mmreg|mmondemand|price_promo]"
      exit 1
fi

}

#Archives the files for DR
archiveFiles() {

local filePattern=$1
TIMESTAMP=$(date +%Y%m%d%H%M%S)

 findFile=$(find $SRC/$filePattern | wc -l)

if [[ "$findFile" -ne "0" ]];
   then
      testArray=$(find $SRC/$filePattern -maxdepth 1 -type f)

      currentValue=''

      for i in $testArray
         do
            currentValue=`basename $i`

            if [[ "${currentValue}" == "CH_offers_"*.csv.gz ]];
               then
                  filename=$(basename $currentValue .csv.gz)
                  fileToArchive=${filename}_${STAMP}_${TIMESTAMP}.csv.gz

            elif [[ "${currentValue}" == *.pub.gz ]];
               then
                  filename=$(basename $currentValue .pub.gz)
                  fileToArchive=${filename}_${TIMESTAMP}.pub.gz

            elif [[ "${currentValue}" == *.txt.gz ]];
               then
                   filename=$(basename $currentValue .txt.gz)
                   fileToArchive=${filename}_${TIMESTAMP}.txt.gz


            elif [[ "${currentValue}" == *.csv.gz ]];
               then
                   filename=$(basename $currentValue .csv.gz)
                   fileToArchive=${filename}_${TIMESTAMP}.csv.gz

            elif [[ "${currentValue}" == *.gz ]];
               then
					filename=$(basename $currentValue .gz)
                   fileToArchive=${filename}_${TIMESTAMP}.gz

            elif [[ "${currentValue}" == *.trg ]];
               then
                  filename=$(basename $currentValue .trg)
                  fileToArchive=${filename}_${TIMESTAMP}.trg

            fi
                    mv $SRC/$currentValue $ARCHIVE/$fileToArchive

        done
else
 echo "$(date '+%Y-%m-%d %T') : No Files to archive for type $file_param with pattern $filePattern" | tee -a $LOG_FILE
fi


}
