#!/bin/bash
###############################################################################################################################
#Modified: on 7-may-2015
#Modified Reason: ps_restart_all.sh failed due the server taking time to start.Therefore changed the no of iterations.
#Modified Info: Change iteration logic to check server status: Soft configure the no of iterartions and the sleep logic is changed.
################################################################################################################################
SRC=$PSHOME/data/in
ARCHIVE=$PSHOME/data/in_arch
TEMP=$PSHOME/data/files
SSH_TMP=$PSHOME/log
LOG_PATH=$PSHOME/log
ERROR_PATH=$PSHOME/error
PS_USER=prcsrvce
DESTINATION=$PSHOME/data/in
REJECT=$PSHOME/data/rej
REJECT_ARCHIVE=$PSHOME/data/rej_arch
SLEEPTIME=20
ITERATION_COUNT=12
SLEEPTIME_SUPERVISOR=10
APMHOME="$PSHOME/Introscope9.6.0.0"

 #Path for Teauth files
 SRC_TEAUTH=$PSHOME/data/in/teauth
 TEMP_TEAUTH=$PSHOME/data/files/teauth
 
 #URLS for the rest calls of TEATUTH
 
 TEAUTH_URL_EANSEED="teauth/importEan"
 TEAUTH_URL_COMPARE="teauth/comparePrice"
 TEAUTH_URL_PROG_CHK="teauth/checksInProgress"
 TEAUTH_FILE_PATTERN="KLL.KLTEAUTH.*"
 
 #Regression ports
 REG_PORT=9083
 REG_ADP_PORT=9081
 REG_SRV_PORT=9085
 
 #Future date promotion
 iscr501inuse="Y"
 
 #Configured script
 VALIDATOR_SCRIPT="/appl/prcsrvce/usr/local/scripts/ps_file_validator.sh"
MAIL_SUBJECT="Server Performance statistics -Price Service"
MAIL_RECIPIENTS="mohammed.s.bandesale@in.tesco.com"
MAIL_BODY="Please find attached the performance stats for Price Service. This is a system generated E-mail ,please do not reply"
if [[ "$PSENV" == "DEV" ]]
then
                #In days
                LOG_RETENTION=7
                ERROR_RETENTION=7

                #Fileshare server IP
                FILESHR_HOST=dvprcfserv001uk.dev.global.tesco.org

                #Adapter server ip
                COUCHBASE_HOST=(dvprcbserv001uk.dev.global.tesco.org)

                #Required No. of Couchbase Server
                REQUIRED_NO_NODES=1

                UP=PriceService:tesco
                ADAPTER_HOST=dvprcadptr001uk.dev.global.tesco.org
                log_temp=$PSHOME/log

                #port on which the view creation REST api is running
                PORT_VIEW=8092
                PORT_SERVICE=8081

                #Couchbase port
                CB_PORT=8091

                #Design doc for view creation
                DESIGN_DOC_NAME=prod_designdoc_item

                #sleep time for ps_import.sh script
                SLEEP_PERIOD=60

                #List of service servers used by ps_restartall.sh and ps_stopall.sh
                PS_SERVERS=(dvprcsrvce001uk.dev.global.tesco.org)

                #NGINX Details
                NGINX_PORT=8080

                PS_PORT="8083"

elif [[ "$PSENV" == "PPE" ]]
then
                #In days
                LOG_RETENTION=7
                ERROR_RETENTION=7

                #Fileshare server IP
                FILESHR_HOST=ppeprcfserv001uk.globalppe.tesco.org

                #couchbase server ip
                COUCHBASE_HOST=(ukirs416.global.tesco.org ukirs417.global.tesco.org ukirs418.global.tesco.org)
                UP=PriceService_PPE:ppeprsrv01

                #Required No. of Couchbase Server
                REQUIRED_NO_NODES=3

                ADAPTER_HOST=ppeprcadptr001uk.globalppe.tesco.org
                log_temp=$PSHOME/log

                #port on which the view creation REST api is running
                PORT_VIEW=8092
                PORT_SERVICE=8081

                #Couchbase port
                CB_PORT=8091

                #Design doc for view creation
                DESIGN_DOC_NAME=prod_designdoc_item

                #sleep time for ps_import.sh script
                SLEEP_PERIOD=60

                #List of service servers used by ps_restartall.sh and ps_stopall.sh
                PS_SERVERS=(ppeprcsrvce001uk.globalppe.tesco.org ppeprcsrvce002uk.globalppe.tesco.org ppeprcsrvce003uk.globalppe.tesco.org)

                #NLB Details
                 NLB_SERVER="price.dev.global.tesco.org"
                 NLB_PORT=80

                 #NGINX Details
                 NGINX_PORT=8080

                 PS_PORT="8083"


elif [[ "$PSENV" == "PROD" ]]
then
                #In days
                LOG_RETENTION=7
                ERROR_RETENTION=7

                #Fileshare server IP
                FILESHR_HOST=pvprcfserv001uk.global.tesco.org

                #couchbase server ip
                COUCHBASE_HOST=(ukirp381.global.tesco.org ukirp382.global.tesco.org ukirp383.global.tesco.org ukirp384.global.tesco.org ukirp385.global.tesco.org)
                UP=PriceService:prsrcb01

                #Required No. of Couchbase Server
                REQUIRED_NO_NODES=4

                ADAPTER_HOST=pvprcadptr001uk.global.tesco.org
                log_temp=$PSHOME/log

                #port on which the view creation REST api is running
                PORT_VIEW=8092
                PORT_SERVICE=8081

                #Couchbase port
                CB_PORT=8091

                #Design doc for view creation
                DESIGN_DOC_NAME=prod_designdoc_item

                #sleep time for ps_import.sh script
                SLEEP_PERIOD=60

                #List of service servers used by ps_restartall.sh and ps_stopall.sh
                PS_SERVERS=(pvprcsrvce001uk.global.tesco.org pvprcsrvce002uk.global.tesco.org pvprcsrvce003uk.global.tesco.org)

                #NLB Details
                NLB_SERVER=(price.global.tesco.org wdc.price.global.tesco.org)
                NLB_PORT=80

                #NGINX Details
                NGINX_PORT=8080

                PS_PORT="8083"

elif [[ "$PSENV" == "PROD_DR" ]]
then
                #In days
                LOG_RETENTION=7
                ERROR_RETENTION=7

                #Fileshare server IP
                FILESHR_HOST=pvprcfserv002uk.global.tesco.org

                #couchbase server ip
                COUCHBASE_HOST=(ukirp376.global.tesco.org ukirp377.global.tesco.org ukirp378.global.tesco.org ukirp379.global.tesco.org ukirp380.global.tesco.org)
                UP=PriceService:prsrcb01

                #Required No. of Couchbase Server
                REQUIRED_NO_NODES=4

                ADAPTER_HOST=pvprcadptr002uk.global.tesco.org
                log_temp=$PSHOME/log

                #port on which the view creation REST api is running
                PORT_VIEW=8092
                PORT_SERVICE=8081

                #Couchbase port
                CB_PORT=8091

                #Design doc for view creation
                DESIGN_DOC_NAME=prod_designdoc_item

                #sleep time for ps_import.sh script
                SLEEP_PERIOD=60

                #List of service servers used by ps_restartall.sh and ps_stopall.sh
                PS_SERVERS=(pvprcsrvce004uk.global.tesco.org pvprcsrvce005uk.global.tesco.org pvprcsrvce006uk.global.tesco.org)

                #NLB Details
                NLB_SERVER=(price.global.tesco.org sdc.price.global.tesco.org)
                NLB_PORT=80

                #NGINX Details
                NGINX_PORT=8080

                PS_PORT="8083"

fi

#Generic function to check the run status of adapter server and the response of curl

check_adapter_for_curl()
{
   fname="check_adapter_curl";
   ret_code=1

   echo "$(date '+%Y-%m-%d %T') : $fname - Starting $SNAME for Adapter Price Server ..."

   if [[ -z $ADAPTER_HOST ]];
   then
      echo "$(date '+%y/%m/%d %T') : $fname - ERROR : the variable PS_SERVERS >$PS_ADAPTERSERVERS< is not set properly ..."
      ERROR_MSG="ERROR IN PROGRAM!!"
      exit 1
   fi;

   hport=$PORT_SERVICE

   #Inducing sleep after superviser start is invoked
   curl_adp_log=$LOG_PATH/curl_adapter_log

   for ff in $(hostname)
   do
      ret_code=1
      echo "$(date '+%Y-%m-%d %T') : $fname - Running for Adapter Server ($ff:$hport)..." 
      typeset -i counter=1;
       while [ true ]
          do
          
             if [[ $counter -ge $ITERATION_COUNT ]]; then
                echo "$(date '+%Y-%m-%d %T') : ERROR : The server check failed for ${ff}:${hport} after $ITERATION_COUNT attempts "
                break;
             else
                sleep $SLEEPTIME
             fi

             status=$(curl -X GET  -s -o $curl_adp_log -w "%{http_code}" http://$ff:$hport/docs)
             if [[ "$status" -ne "200" ]];
             then

                echo "$(date '+%Y-%m-%d %T') : $fname - Response <$status> from curl command is present in the log path:/appl/prcsrvce/log/curl_adapter_log"
				echo "$(date '+%Y-%m-%d %T') : $fname - failed on the server <$(hostname)> on $counter attempt ... url (http://$ff:$hport/docs)"  
               
             else
                echo "$(date '+%Y-%m-%d %T') : $fname - Response <$status>.. Completed on server  ($ff:$hport) ..."
                return 0;
             fi   

             counter=$counter+1; 
        done;
   done;
   echo "$(date '+%Y-%m-%d %T') : $fname - failed on the server <$(hostname)>..."
   return $ret_code;
}

#Generic function to check the run status of service servers and the response of curl

check_service_for_curl()
{
   fname="check_service_curl";
   ret_code=0
   
   #typeset -i failed_server_count=0
   echo "$(date '+%Y-%m-%d %T') : $fname - Starting $SNAME for Price Server ..."

   if [[ -z $PS_SERVERS ]];
   then
      echo "$(date '+%y/%m/%d %T') : $fname - ERROR : the variable PS_SERVERS <$PS_SERVERS> is not set properly ..."
      ERROR_MSG="ERROR IN PROGRAM!!"
      exit 1
   fi;

   #hport=8081

  #Inducing sleep after superviser start is invoked
   curl_svc_log=$LOG_PATH/curl_srvc_log

   for ff in $(hostname)
   do
     for pp in ${PS_PORT[@]}
     do
        hport=$(echo $pp);
        typeset -i counter=1;   
        typeset -i failed_server_count=1     

           while [ true ]
           do
              echo "$(date '+%Y-%m-%d %T') : $fname - Starting $SNAME for Server ($ff:$hport)..."
              if [[ $counter -ge  $ITERATION_COUNT ]]; 
              then
                 echo "$(date '+%Y-%m-%d %T') : ERROR : The server check failed for ${ff}:${hport} after $ITERATION_COUNT attempts "
                 break;
              else
                 sleep $SLEEPTIME
              fi

              status=$(curl -X GET  -s -o $curl_svc_log -w "%{http_code}" http://$ff:$hport/docs)

              if [[ "$status" -ne "200" ]];
              then
          
                 echo "$(date '+%Y-%m-%d %T') : $fname - Response <$status> from curl command is present in the log path: /appl/prcsrvce/log/curl_srvc_log"
                 echo "$(date '+%Y-%m-%d %T') : $fname - failed on the server <$(hostname)> on $counter attempt ... url (http://$ff:$hport/docs)"       

                 failed_server_count=1
              else
                 echo "$(date '+%Y-%m-%d %T') : $fname - Completed on this server on $counter attempt... url (http://$ff:$hport/docs)"
                 failed_server_count=0
                 break;
              fi
              counter=$((counter+1))
           done; #done for while loop 

           if [[ $failed_server_count -ne 0 ]];
           then
              echo "$(date '+%Y-%m-%d %T') : $fname - failed on the server <$(hostname)> on  ${ITERATION_COUNT} attempts... for port ${hport}"
              return 1
           fi    
     
     done; # done for PS_PORT for loop

   done; #done for hostname for loop

  return $ret_code;

}
