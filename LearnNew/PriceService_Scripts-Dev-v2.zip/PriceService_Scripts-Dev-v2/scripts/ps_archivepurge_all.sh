#!/bin/bash

#set -x
. $HOME/.bash_profile
. $PSHOME/usr/local/scripts/config_purge.sh

STAMP=`date +"%Y%m%d"`
PROG_NAME=$(basename $0 .sh)
USER="$(id -u -n)"
PURGE_SCRIPT="ps_archive_purge.sh"
SCRIPT_PATH="$PSHOME/usr/local/scripts"

LOG_FILE=$LOG_PATH/${PROG_NAME}_log_${STAMP}.log
ERR_FILE=$ERROR_PATH/${PROG_NAME}_err_${STAMP}.log

if [ ! -d "$LOG_PATH" ];
then
      echo "Log path is not set. Please set the LOG_PATH"
      exit 1
fi

if [ ! -d  "$ERROR_PATH" ];
then
      echo "Error path is not set. Please set the ERROR_PATH"
      exit 1
fi

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME started by $USER" | tee -a $LOG_FILE

######### Running Purge scripts in Adapter###################
echo "$(date '+%Y-%m-%d %T') : Staring $PURGE_SCRIPT in Adapter server ($ADAPTER_HOST)..." | tee -a $LOG_FILE
${SCRIPT_PATH}/${PURGE_SCRIPT}
RC=$?
if [ "$RC" -ne "0" ]; 
then
	echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
	echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : Failed to run $PURGE_SCRIPT in Adapter server ($ADAPTER_HOST)..." | tee -a $LOG_FILE
	exit 1
fi
echo "$(date '+%Y-%m-%d %T') : Completed $PURGE_SCRIPT in Adapter server ($ADAPTER_HOST)..." | tee -a $LOG_FILE


################# Running Purge scripts in service servers ###############
for hname in ${PS_SERVERS[@]}
do
	############## Running PURGE_SCRIPT#######
	echo "$(date '+%Y-%m-%d %T') : Staring $PURGE_SCRIPT in Service server ($hname)..." | tee -a $LOG_FILE
	ssh $USER@$hname "${SCRIPT_PATH}/${PURGE_SCRIPT}"
	RC=$?
	if [ "$RC" -ne "0" ]; 
	then
		echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
		echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : Failed to run $PURGE_SCRIPT in Service server ($hname)..." | tee -a $LOG_FILE
		exit 1
	fi
	echo "$(date '+%Y-%m-%d %T') : Completed $PURGE_SCRIPT in Service server ($hname)..." | tee -a $LOG_FILE
done

################# Running Purge scripts in Fileshare servers ###############


	echo "$(date '+%Y-%m-%d %T') : Staring $PURGE_SCRIPT in Fileshare server ($FILESHR_HOST)..." | tee -a $LOG_FILE
	ssh $USER@$FILESHR_HOST "${SCRIPT_PATH}/${PURGE_SCRIPT}"
	RC=$?
	if [ "$RC" -ne "0" ]; 
	then
		echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
		echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : Failed to run $PURGE_SCRIPT in Fileshare server ($FILESHR_HOST)..." | tee -a $LOG_FILE
		exit 1
	fi
	echo "$(date '+%Y-%m-%d %T') : Completed $PURGE_SCRIPT in Fileshare server ($FILESHR_HOST)..." | tee -a $LOG_FILE

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME completed by $USER" | tee -a $LOG_FILE

exit $?;
