#!/bin/bash
# Downloads Teauthfiles(control file and store file) from the fileshare server and copy it into adapter server
. $HOME/.bash_profile

RC=$?
if [[ $RC -ne 0 ]] ; then
  # Error exit
  echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : $0 failed calling profile script for variable setup"
  exit 1
fi

. $PSHOME/usr/local/scripts/config.sh

RC=$?
if [[ $RC -ne 0 ]] ; then
  # Error exit
  echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : $0 failed calling config script for variable setup"
  exit 1
fi

STAMP=`date +"%Y%m%d"`
PROG_NAME=$(basename $0 .sh)

file_param=$1

LOG_FILE=$LOG_PATH/${PROG_NAME}_log_${STAMP}.log
ERR_FILE=$ERROR_PATH/${PROG_NAME}_err_${STAMP}.log

if [ ! -d  "$LOG_PATH" ];
then
      echo "Log path is not set. Please set the LOG_PATH"
      exit 1
fi

if [ ! -d  "$ERROR_PATH" ];
then
      echo "Error path is not set. Please set the ERROR_PATH"
      exit 1
fi

. $PSHOME/usr/local/scripts/clearance_config.sh

RC=$?
if [[ $RC -ne 0 ]] ; then
  # Error exit
  echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : $0 failed calling clearance config script for variable setup"
  exit 1
fi

SSH_ERR=$SSH_TMP/${PROG_NAME}_err_${STAMP}

USER="$(id -u -n)"

if [ "$#" -ne 1 ]
then
   echo "Invalid number of arguments" | tee -a $ERR_FILE
   echo "Usage : $PROG_NAME [teauthuk|teauthroi]" | tee -a $ERR_FILE
   echo "Script >$PROG_NAME< Failed .. Please refer to the error file >$ERR_FILE< for more details" | tee -a $LOG_FILE
   exit 1
fi

echo "Job $PROG_NAME started by $USER"
echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME started by $USER" >> $LOG_FILE

SERVER=$PS_USER@$FILESHR_HOST

checkDestination() {

    inboundFiles=$(find $DEST_PATH -maxdepth 1 -type f | wc -l)

    if [[ "$inboundFiles" -ne "0" ]];
       then
          echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
          echo "$(date '+%y/%m/%d %T') : ERROR : TEAUTH files are already prsent in the inbound folder" | tee -a $ERR_FILE
          exit 1
    fi

}

validateTeauthFiles() {

ssh_out=$(ssh -o StrictHostKeyChecking=no $PS_USER@$FILESHR_HOST "$PSHOME/usr/local/scripts/ps_teauth_filevalidation.sh '${file_param}'")

RC=$?
if [[ "$RC" -ne "0" ]];
then
    echo "$(date '+%Y-%m-%d %T') : ERROR: Error occured while running ps_teauth_filevalidation.sh script check error log " | tee -a $LOG_FILE
    echo "$(date '+%Y-%m-%d %T') : ERROR: Return code: ${RC} ps_teauth_filevalidation.sh script " | tee -a $ERR_FILE
    echo "$(date '+%Y-%m-%d %T') : ERROR: from ssh >> $ssh_out <<"  | tee -a $ERR_FILE
    exit 1
fi

}

copyFiles() {

 scp -o StrictHostKeyChecking=no $SERVER:$SRC/$teauthFilePatternStore $DEST_PATH

   RC=$?
   if [ "$RC" -ne "0" ];
   then
   echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
   echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : Failed to scp store $SRC to $DEST_PATH" | tee -a $ERR_FILE
   exit 1
  fi

 scp -o StrictHostKeyChecking=no $SERVER:$SRC/$teauthFilePatternControl $DEST_PATH

   RC=$?
   if [ "$RC" -ne "0" ];
   then
   echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
   echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : Failed to scp control files from $SRC to $DEST_PATH" | tee -a $ERR_FILE
   exit 1
  fi

 gunzip -f $DEST_PATH/*.gz

 RC=$?
   if [ "$RC" -ne "0" ];
   then
   echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
   echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : Failed to unzip the files in  $DEST_PATH" | tee -a $ERR_FILE
   exit 1
  fi


}


archiveFilesTeauth() {

ssh_out=$(ssh -o StrictHostKeyChecking=no $PS_USER@$FILESHR_HOST "$PSHOME/usr/local/scripts/ps_teauth_archivefiles.sh '${file_param}'")

RC=$?
if [[ "$RC" -ne "0" ]];
then
    echo "$(date '+%Y-%m-%d %T') : ERROR: Error occured while running ps_teauth_archivefiles.sh script check error log " | tee -a $LOG_FILE
    echo "$(date '+%Y-%m-%d %T') : ERROR: Return code: ${RC} ps_teauth_archivefiles.sh script " | tee -a $ERR_FILE
    echo "$(date '+%Y-%m-%d %T') : ERROR: from ssh >> $ssh_out <<"  | tee -a $ERR_FILE
    exit 1
fi

}

archiveFiles() {

      testArray=$(ssh -o StrictHostKeyChecking=no $SERVER "find $SRC  -maxdepth 1 -type f")

      currentValue=''
      for i in $testArray
         do
            currentValue=`basename $i`
	    if [[ "$currentValue" == *.gz ]];
               then
                  filename=$(basename $currentValue .gz)
                  TIMESTAMP=$(date +%Y%m%d%H%M%S)
                  append_date=${filename}_${TIMESTAMP}.gz
            
	    elif [[ "$currentValue" == *.trg ]];
                then
                   filename=$(basename $currentValue .trg)
                   TIMESTAMP=$(date +%Y%m%d%H%M%S)
                   append_date=${filename}_${TIMESTAMP}.trg
            fi
          ssh -o StrictHostKeyChecking=no $SERVER "mv $SRC/${currentValue} $ARCHIVE/$append_date"
	
	   RC=$?

	   if [ "$RC" -ne "0" ];
      	      then
                 echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
                 echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : Archive Failed" | tee -a $ERR_FILE
           exit 1
   fi

      done
}

checkDestination

validateTeauthFiles

copyFiles

archiveFilesTeauth

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME completed successfully" | tee -a $LOG_FILE

exit $?
