#!/bin/bash

################################################################################################################
#Script Name:ps_rpm_clearancefileshare.sh
#Modified by: Saurabh Kumar
#Modified Date: 24/12/2014
#Team Name: Price Service (Brass)
#Functionality: Copies Acayg,DLR,Non Ranged and Emergency Clearance files from the FileShare server 
#               to Adapter server in CRE/MOD/DEL files. 
#Restartability Points:
#
#1) The script is restartable in most cases.However, when there is a failure in archiveFiles() 
#   (say failed when archiving 3rd file out of 4th file) then you cannot restart.In such case, the archiving 
#   alone should be done manually.
#2) Please check for the specific files [acayg(count:4)/regranged(count:4)/regnonranged(count:1)/
#   emerranged(count:1)/emernonranged(count:1))]in the fileshare server's "data/in" directory on file(s) 
#   related (fileCountFS()) failure(s).
#3) This is a re-runnable script and it will have to be started from the beginning on any failure(s).
#4) Please also check for the cre/mod/del.txt files present in the "data/in/files/<regranged/acayg/regnonranged/
#   emerranged/emernonranged>" directories on the respective failure.
################################################################################################################# 

#set -x

. $HOME/.bash_profile

RC=$?
if [[ $RC -ne 0 ]] ; then
  # Error exit
  echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : $0 failed calling profile script for variable setup"
  exit 1
fi

set -o pipefail
. $PSHOME/usr/local/scripts/config.sh

RC=$?
if [[ $RC -ne 0 ]] ; then
  # Error exit
  echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : $0 failed calling config script for variable setup"
  exit 1
fi


#STAMP=`date +"%Y%m%d%T"`
STAMP=`date +"%Y%m%d"`
PROG_NAME=$(basename $0 .sh)


LOG_FILE=$LOG_PATH/${PROG_NAME}_log_${STAMP}.log
ERR_FILE=$ERROR_PATH/${PROG_NAME}_err_${STAMP}.log
FAIL_FILE=$LOG_PATH/${PROG_NAME}_failed_${STAMP}.txt

SSH_ERR=$SSH_TMP/${PROG_NAME}_err_${STAMP}.log

USER="$(id -u -n)"

if [ "$#" -ne 1 ]
then
   echo "Invalid number of arguments" | tee -a $ERR_FILE
   echo "Usage : $PROG_NAME [acayg|regranged|regnonranged|emerranged|emernonranged|onetime]" | tee -a $ERR_FILE
   echo "Script >$PROG_NAME< Failed .. Please refer to the error file >$ERR_FILE< for more details" | tee -a $LOG_FILE
   exit 1
fi

file_param=$1
. $PSHOME/usr/local/scripts/clearance_config.sh

RC=$?
if [[ $RC -ne 0 ]] ; then
  # Error exit
  echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : $0 failed calling clearance config script for variable setup"
  exit 1
fi

if [ ! -d  "$LOG_PATH" ];
then
      echo "Log path is not set. Please set the LOG_PATH"
      exit 1
fi

if [ ! -d  "$ERROR_PATH" ];
then
      echo "Error path is not set. Please set the ERROR_PATH"
      exit 1
fi
echo $file_param
if [[ "$file_param" != "acayg" && "$file_param" != "regranged" && "$file_param" != "regnonranged"  && "$file_param" != "emerranged"  && "$file_param" != "emernonranged"      && "$file_param" != "onetime" ]];then
   echo "Usage : $PROG_NAME [acayg|regranged|regnonranged|emerranged|emernonranged|onetime]" | tee -a $ERR_FILE
   exit 1
fi

echo "Job $PROG_NAME started by $USER"
echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME started by $USER" | tee -a $LOG_FILE

#Assigning values from command line parameters
SERVER=$PS_USER@$FILESHR_HOST


fileCountFS(){
   echo $filePattern
   fileCountFS=$(ssh -o StrictHostKeyChecking=no $SERVER "ls -ltr $SRC/$filePattern | wc -l")
   echo filecount $fileCountFS
   echo numfile $numFiles
   if [[ "$fileCountFS" -ne "$numFiles" ]];
      then
      echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
      echo "$(date '+%y/%m/%d %T') : The files with pattern $filePattern does not have required number of files" | tee -a $ERR_FILE 
      exit 1
   fi
	
}

checkServer() {

  echo "$(date '+%Y-%m-%d %T') : Begin : Checking for the required files in the server" | tee -a $LOG_FILE

  for ((i = 0; i < $numFiles; i++))
  do
    from="${srcfile[$i]}"
  
    exec 6>&1
    exec 1> $SSH_ERR
    exec 2>&1

    # src_time_stamp contains file name and the time stamp
    src_time_stamp=$(ssh -o StrictHostKeyChecking=no $SERVER "ls -l $SRC/$from | tr -s ' ' | cut -d' ' -f6-9 " | tail -n1)
          RC=$?

          exec 1>&6 6>&-

      #Changed to handle error
          sshout=$(tail -n1 $SSH_ERR | grep -ve "-----")

    if [[ -z "$src_time_stamp" || ! -z $sshout ]];
    then
      echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
      echo "$(date '+%y/%m/%d %T') : ERROR : Failed to ssh !!" >> $ERR_FILE
      echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR Occured is : >$sshout< !!" | tee -a $ERR_FILE
      exit 1
    fi

    # cut out the time stamp
    time_stamp=$( echo "$src_time_stamp" | cut -d ' ' -f1-3 )
    # cut out the file name
    src_filename[i]=$( echo "$src_time_stamp" | cut -d ' ' -f4 )

    if [ -z "$src_filename[i]" ];
    then
      echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
      echo "$(date '+%y/%m/%d %T') : ERROR : No file matching $from found on server" | tee -a $ERR_FILE
    fi
  done
}

copyFile() {

rm -f $TEMP_PATH/*

  numFiles=${#src_filename[@]}


   for ((i = 0; i < $numFiles; i++))
  do

    from="${src_filename[$i]}"
    to="${destfile[$i]}"
#echo $from
#echo $to
    echo "$(date '+%Y-%m-%d %T') : Getting latest file matching $SERVER:$from and copying to $TEMP_PATH" | tee -a $LOG_FILE

	doScp $from $TEMP_PATH
	
   if [[ "$from" == *gz ]];
    then
	file=$(basename $from)
        gzip -d $TEMP_PATH/$file
    fi

  done

}

doScp() {
  local from=$1
  local to=$2

  scp -o StrictHostKeyChecking=no $SERVER:$from $to

  RC=$?
  if [ "$RC" -ne "0" ];
  then
    echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
    echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : Failed to scp $from to $to" | tee -a $ERR_FILE
   fi
}

process()
{

  testArray=$(find $TEMP_PATH -maxdepth 1 -type f)
  currentValue=''

rm -f $DEST_PATH/*

    for i in $testArray
    do
       currentValue=`basename $i`
	
	 headVal=$(head $i -n1|cut -d '|' -f1)
         tailVal=$(tail $i -n1|cut -d '|' -f1)
         rowCount=$(wc -l < $i)
         fileDate=$(head $i -n1|cut -d '|' -f4)
         systemDate=$(date +%Y%m%d)
         countInTail=$(tail $i -n1|cut -d '|' -f2)

	 if [[ "$headVal" != "FHEAD" || "$tailVal" != "FTAIL" ]];
                    then
                         echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
                         echo "$(date '+%Y-%m-%d %T') : HEAD OR TAIL RECORD IS NOT AVAILABLE" | tee -a $LOG_FILE
                         exit 1
          elif [ "$rowCount" != "$countInTail" ];
                    then
                         echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
                         echo "$(date '+%Y-%m-%d %T') : RECORD COUNT INCORRECT" | tee -a $LOG_FILE
                         exit 1
       	 else

                         #Creating the CRE/MOD/DEL files

                         touch $CREFILE $MODFILE $DELFILE

	        if [[ "${currentValue}" ==  "CLRPC_ACAYG_"* ]];
        	    then

                         #Optimizing the repeated operations

         	 	 awk -v file1="$CREFILE" -v file2="$MODFILE" -v file3="$DELFILE" -F"|" 'BEGIN {OFS=FS="|"}
                         { if ($3 == "CRE") { sub($4, "AC-" $4); print >> file1; } else if ($3 == "MOD") { sub($4, "AC-" $4); print >> file2; }
                         else if ($1 == "FDELE") { sub($3, "AC-" $3); print >> file3; } }' $i


	        elif [[ "${currentValue}" ==  "CLRPC_EMER"*  ]]
        	    then
		         
                         #Optimizing the repeated operations

                         awk -v file1="$CREFILE" -v file2="$MODFILE" -v file3="$DELFILE" -F"|" 'BEGIN {OFS=FS="|"}
                         { if ($3 == "CRE") { sub($4, "EC-" $4); print >> file1; } else if ($3 == "MOD") { sub($4, "EC-" $4); print >> file2; }
                         else if ($1 == "FDELE") { sub($3, "EC-" $3); print >> file3; } }' $i

           
	        elif [[ "${currentValue}" ==  "CLRPC_DLR_"*  ]]
        	    then
	    	         
                          #Optimizing the repeated operations

                          awk -v file1="$CREFILE" -v file2="$MODFILE" -v file3="$DELFILE" -F"|" 'BEGIN {OFS=FS="|"} 
                          { if ($3 == "CRE") { sub($4, "CL-" $4); print >> file1; } else if ($3 == "MOD") { sub($4, "CL-" $4); print >> file2; }
                          else if ($1 == "FDELE") { sub($3, "CL-" $3); print >> file3; } }' $i
		
              
	        elif  [[ "${currentValue}" ==  "tsl_clearancenonrangeddm_"*  ]]
	            then
 		          
                          #Optimizing the repeated operations

                          awk -v file1="$CREFILE" -v file2="$MODFILE" -v file3="$DELFILE" -F"|" 'BEGIN {OFS=FS="|"}
                          { if ($3 == "CRE") { sub($4, "UC-" $4); print >> file1; } else if ($3 == "MOD") { sub($4, "UC-" $4); print >> file2; }
                          else if ($1 == "FDELE") { sub($3, "UC-" $3); print >> file3; } }' $i

		
	      else
		 echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
                 echo "$(date '+%Y-%m-%d %T') : REASON CODE HAS NOT APPENDED" | tee -a $LOG_FILE
		 exit 1

        	fi
	fi
   done

       #Implementing parallel processing
       
       rm -f $FAIL_FILE

       sort -t '|' -k5,5 -k4,4f $CREFILE | awk -F"|" 'BEGIN {OFS=FS="|"} { print $1, NR, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13 }'  > $DEST_PATH/CLEARANCE_CRE.txt || touch $FAIL_FILE &       
       
       sort -t '|' -k5,5 -k4,4  $MODFILE | awk -F"|" 'BEGIN {OFS=FS="|"} { print $1, NR, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13 }' > $DEST_PATH/CLEARANCE_MOD.txt || touch $FAIL_FILE &
          
       sort -t '|' -k4,4 -k3,3  $DELFILE | awk -F"|" 'BEGIN {OFS=FS="|"} { print $1, NR, $3, $4, $5, $6, $7 }' > $DEST_PATH/CLEARANCE_DEL.txt  || touch $FAIL_FILE &
        
       wait

        #Report any sort failure

        if [[ -f $FAIL_FILE ]];
          then
            echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
            echo "$(date '+%Y-%m-%d %T') : Sort Failed" | tee -a $ERR_FILE
            exit 1;
        fi;


}

#####Function to process the RPM one-time import files#####
process_onetime(){

  Array=$(find $TEMP_PATH -maxdepth 1 -type f)

  rm -f $DEST_PATH/*

  for i in $Array
  do

     headVal=$(head $i -n1|cut -d '|' -f1)
     tailVal=$(tail $i -n1|cut -d '|' -f1)
     rowCount=$(wc -l < $i)
     fileDate=$(head $i -n1|cut -d '|' -f4)
     systemDate=$(date +%Y%m%d)
     countInTail=$(tail $i -n1|cut -d '|' -f2)
     if [[ "$headVal" != "FHEAD" || "$tailVal" != "FTAIL" ]];
     then
        echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
        echo "$(date '+%Y-%m-%d %T') : HEAD OR TAIL RECORD IS NOT AVAILABLE in $i File" | tee -a $ERR_FILE
        exit 1
     elif [ "$rowCount" != "$countInTail" ];
     then
        echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
        echo "$(date '+%Y-%m-%d %T') : RECORD COUNT INCORRECT in file : $i " | tee -a $ERR_FILE
        exit 1
     else
	cat $i >> $TEMP_ONETIME_FILE
     fi
  done 
  #Convert to the required files and sort the files
  touch $CREFILE $MODFILE $DELFILE

  awk -v file1="$CREFILE" -v file2="$MODFILE" -v file3="$DELFILE" -F"|" 'BEGIN {OFS=FS="|"}
                         { if ($3 == "CRE") { sub($4, "EC-" $4); print > file1; } else if ($3 == "MOD") { sub($4, "EC-" $4); print > file1; }
                         else if ($1 == "FDELE") { sub($3, "EC-" $3); print > file3; } }' $TEMP_ONETIME_FILE
  
  #Implementing parallel processing
       
  rm -f $FAIL_FILE

  sort -t '|' -k5,5 -k3,3f $CREFILE  > $DEST_PATH/CLEARANCE_CRE.txt || touch $FAIL_FILE &       
    
  sort -t '|' -k5,5 -k3,3  $MODFILE > $DEST_PATH/CLEARANCE_MOD.txt || touch $FAIL_FILE &
          
  sort -t '|' -k4,4 -k3,3  $DELFILE  > $DEST_PATH/CLEARANCE_DEL.txt  || touch $FAIL_FILE &
        
  wait

        #Report any sort failure

  if [[ -f $FAIL_FILE ]];
     then
     echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
     echo "$(date '+%Y-%m-%d %T') : Sort Failed" | tee -a $ERR_FILE
     exit 1;
  fi
}

archiveFiles_old() {
  numOfFile=${#srcfile[@]}

  echo "$(date '+%Y-%m-%d %T') : Archiving $numOfFiles to $ARCHIVE" | tee -a $LOG_FILE
  for ((i = 0; i < $numOfFile; i++))
  do

     pattern="${src_filename[$i]}"
     filepattern=$(basename $pattern $SRC)

     fileWith_timestamp=${filepattern}_${STAMP}

   ssh -o StrictHostKeyChecking=no $SERVER "mv $SRC/$filepattern $ARCHIVE/$fileWith_timestamp"

   RC=$?

    if [ "$RC" -ne "0" ];
    then
    echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
    echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : Archive Failed" | tee -a $ERR_FILE
    exit 1
  fi

done

}

archiveFiles() {

   numOfFile=${#srcfile[@]}
   echo "$(date '+%Y-%m-%d %T') : Archiving $numOfFiles to $ARCHIVE" | tee -a $LOG_FILE

   for ((i=0; i<$numFiles ;i++))
      do
         filepattern="${src_filename[$i]}"
         pattern=$(basename $filepattern $SRC)

         if [[ "$pattern" == *.pub.gz ]];
            then
               filename=$(basename $pattern .pub.gz)
               TIMESTAMP=$(date +%Y%m%d%H%M%S)
               append_date=${filename}_${TIMESTAMP}.pub.gz
         elif [[ "$pattern" == *.txt.gz ]];
            then
               filename=$(basename $pattern .txt.gz)
               TIMESTAMP=$(date +%Y%m%d%H%M%S)
               append_date=${filename}_${TIMESTAMP}.txt.gz
         fi
   ssh -o StrictHostKeyChecking=no $SERVER "mv $SRC/$pattern $ARCHIVE/$append_date"

   RC=$?

   if [ "$RC" -ne "0" ];
      then
         echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
         echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : Archive Failed" | tee -a $ERR_FILE
         exit 1
   fi

done

}


fileCountFS

checkServer

copyFile

####if the input parameter is one-time then call the function process_onetime() else the generix function process()
if [ "$file_param" == "onetime" ]; 
   then
   process_onetime
else

   process

fi

archiveFiles

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME completed successfully" | tee -a $LOG_FILE

exit $?
