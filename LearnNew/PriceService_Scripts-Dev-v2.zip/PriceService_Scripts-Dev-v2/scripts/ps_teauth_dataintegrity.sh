#!/bin/bash
#set -x
#-----------------------------------------------------------------------------------------------
#  File: ps_teauth_dataintegrity.sh 
#
#  Desc:  UNIX shell script to run the any batch program multi-threaded.
#-----------------------------------------------------------------------------------------------
#  Created by: Dinesh Sivasankaran
#  Created on: 26-NOV-2012
# Modified By: Salman
# Modified On: 27-Mar-2015
#************************************************************************************************#
. $HOME/.bash_profile
. $PSHOME/profile
. $PSHOME/usr/local/scripts/config.sh
RC=$?

if [[ "$RC" -ne "0" ]];
then
echo "Failed to source the config.sh script for variable setup"
exit 1

fi

DEFAULTDEGREE=10
mydir=$(dirname $0)
scriptname=$(basename $0 $mydir)
pgmname=$(basename $0 .sh)
STAMP=`date +"%Y%m%d"`
LOG_FILE=$LOG_PATH/${pgmname}_log_${STAMP}.log
ERR_FILE=$ERROR_PATH/${pgmname}_err_${STAMP}.log

BINFILE="ps_teauth_data_integiry_child.sh"

TEMP="/tmp"
#inputfilelist="$TEMP/$pgmname".storelist.$$

###Child script to be run as parallel
CHILD_SCRIPT="${PSHOME}/usr/local/scripts/ps_teauth_data_integiry_child.sh"
# Set filename to flag any failed executions
failed="$TEMP/$pgmname".failed.$$

USAGE="Usage: `basename $0` [-p <# parallel threads>] [<${BINFILE} options>]\n
<# parallel threads> is the number of ${BINFILE} threads to run in parallel.\n
Parameter uk/roi should be passed .\n
The default is set as $DEFAULTDEGREE. \n
"

# Parse the command line
while getopts "p:" CMD;
   do
      case $CMD in
         p)  DEGREE=$OPTARG;;
         *)  echo $0: Unknown option $OPTARG
             echo $USAGE
             exit 1;;
      esac
  done
shift $((OPTIND - 1))

PROCESS_UK_ROI=$(echo $1 | tr -s [[A-Z]] [[a-z]] ); 


echo "Script <$scriptname> started at >$(date)<" | tee -a $LOG_FILE


###############################################################################
#                       Format Submitted Jobs for Checks                      #
###############################################################################
format_jobs()
{
   #set -x
   jnos="$#"
   pjobs="$1"
   shift
   for j
   do
      pjobs="$pjobs,$j"
   done
}


###############################################################################
#                                   Find Active Jobs                          #
###############################################################################
find_jobs()
{
   #set -x

   if [[ $pjobs == "" ]];
   then
     nnos=0;
     njobs="";
     return;
   fi;

   set -- `ps -p "$pjobs" | awk '$1 ~ /^[0-9]/ { print $1 }'`

   njobs="$*"

   pjobs=$njobs
   jobs=$pjobs

   nnos=$#
   jmsg="$pnos $jnos Jobs"
}


### This is the beginning of the script ###
###########################################

[ -f $failed ] && rm $failed

# If this script is killed, cleanup
#trap "kill -15 0; rm -f $failed; exit 15" 1 2 3 15

process_param=""
if [[ "$PROCESS_UK_ROI" != "teauthuk" && "$PROCESS_UK_ROI" != "teauthroi"  ]];
then
   echo "$(date '+%Y-%m-%d %T') : ERROR : First  parameter is Invalid "| tee -a $ERR_FILE
   echo $usage
   exit 1
elif [[ "$PROCESS_UK_ROI" == "teauthuk" ]];
then
   process_param="uk"

elif [[ "$PROCESS_UK_ROI" == "teauthroi" ]];
then
   process_param="roi"
fi



if [[ $DEGREE  == "" ]];
then
  echo "Parallel Degree is missing for program >$BINFILE< " | tee -a $LOG_FILE
  DEGREE=$DEFAULTDEGREE
fi

files=($(find $SRC_TEAUTH/${process_param}/${TEAUTH_FILE_PATTERN}))

typeset -i cnt=0
cnt=${#files[@]}
if [[ "$cnt" -eq "0" ]];
then
   echo "No files to be processed" | tee -a $LOG_FILE
   exit 1
else
   echo "Identified  >$cnt< Store files to be processed >$(date)<" | tee -a $LOG_FILE
fi

# Run the store program in parallel each processing a store

for ((i = 0; i < $cnt; i++))
do
filename=`basename ${files[$i]}`
   find_jobs

   if [ $nnos -lt $DEGREE ]
   then

      ( ${CHILD_SCRIPT} ${PROCESS_UK_ROI} ${filename} || touch $failed;) &
      job=$!
      jobs="$jobs $job"
      format_jobs $jobs
   else
      # Loop until a thread becomes available
      find_jobs

      while [ $nnos -ge $DEGREE ]
      do
         sleep 1
         find_jobs
      done

            ( ${CHILD_SCRIPT} ${PROCESS_UK_ROI} ${filename} || touch $failed;) &
      job=$!
      jobs="$jobs $job"
      format_jobs $jobs
   fi







done

echo "Finished spawning for all files .. waiting for them to finish >$(date)<" | tee -a $LOG_FILE
echo "background process list >$(ps)< jobs >$(jobs)< before wait >$(date)<" | tee -a $LOG_FILE

wait;
echo "background process list >$(ps)< jobs >$(jobs)< after wait >$(date)<" | tee -a $LOG_FILE

find_jobs
while [ $nnos -gt 0 ]
do
  sleep 5
  find_jobs
done











echo "background process list >$(ps)< jobs >$(jobs)< after while sleep >$(date)<" | tee -a $LOG_FILE

# Check for the existence of a failed file from any of the threads
# and determine exit status
if [ -f $failed ]
then
   rm $failed
   exit 1
fi;
#delete all the files once the import is completed successfully
rm -f $SRC_TEAUTH/${process_param}/${TEAUTH_FILE_PATTERN}
RC=$?
if [[ "$RC" -ne "0" ]];
then
echo "$(date '+%Y-%m-%d %T') : ERROR : Failed to clear files after Import "| tee -a $ERR_FILE
exit 1
fi

echo "Script <$scriptname> finished succesfully at >$(date)<" | tee -a $LOG_FILE
exit $?;

### END OF SCRIPT ###
