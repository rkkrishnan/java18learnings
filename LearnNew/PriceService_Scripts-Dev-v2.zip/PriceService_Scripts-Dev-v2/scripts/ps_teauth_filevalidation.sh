#!/bin/bash
#Validate the teauth files in file share server and returns error code 1 if validation fails
. $HOME/.bash_profile

RC=$?
if [[ $RC -ne 0 ]] ; then
  # Error exit
  echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : $0 failed calling profile script for variable setup"
  exit 1
fi

. $PSHOME/usr/local/scripts/config.sh

RC=$?
if [[ $RC -ne 0 ]] ; then
  # Error exit
  echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : $0 failed calling config script for variable setup"
  exit 1
fi

STAMP=`date +"%Y%m%d"`
PROG_NAME=$(basename $0 .sh)

#file_param=$1

LOG_FILE=$LOG_PATH/${PROG_NAME}_log_${STAMP}.log
ERR_FILE=$ERROR_PATH/${PROG_NAME}_err_${STAMP}.log

if [ ! -d  "$LOG_PATH" ];
then
      echo "Log path is not set. Please set the LOG_PATH"
      exit 1
fi

if [ ! -d  "$ERROR_PATH" ];
then
      echo "Error path is not set. Please set the ERROR_PATH"
      exit 1
fi

. $PSHOME/usr/local/scripts/clearance_config.sh

RC=$?
if [[ $RC -ne 0 ]] ; then
  echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : $0 failed calling clearance config script for variable setup"
  exit 1
fi

SSH_ERR=$SSH_TMP/${PROG_NAME}_err_${STAMP}

USER="$(id -u -n)"

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME started by $USER" | tee -a $LOG_FILE

SERVER=$PS_USER@$FILESHR_HOST

TIMESTAMP=$(date +%Y%m%d%H%M%S)
currentDayDate=$(date +%Y%m%d)

ERROR_CODE=0
ERROR_COUNT=0
storeFileCount=0
storeFilesNum=0

file_param=$(echo $1 | tr [[A-Z]] [[a-z]])

if [[ "$file_param" != "teauthuk" && "$file_param" != "teauthroi" ]];
then
        echo "$(date '+%Y-%m-%d %T') : ERROR: The parameter should be [teauthuk|teauthroi].." | tee -a $LOG_FILE
        echo "$(date '+%Y-%m-%d %T') : ERROR: Return code: ${RC} $PROG_NAME script failed!!" | tee -a $ERR_FILE
        exit 1
fi


checkFileType() {

#Trigger File Vaidation

trgFileCount=$(ls -l $SRC/$teauthFilePatternTrigger | wc -l)

if [[ "$trgFileCount" -eq "0" ]];
   then
      echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
      echo "$(date '+%y/%m/%d %T') : ERROR : TEAUTH $location_type TRIGGER FILE MISSING" | tee -a $ERR_FILE
 exit 1
fi

if [[ "$trgFileCount" -gt "1" ]];
   then
      echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
      echo "$(date '+%y/%m/%d %T') : ERROR : TEAUTH INVALID NUMBER OF $location_type TRIGGER FILE - TRIGGER FILE COUNT IS $trgFileCount" | tee -a $ERR_FILE
      exit 1
fi

trgfilename=$(basename `ls -1 $SRC/$teauthFilePatternTrigger` dirname)

trgArrivedDate=$(echo $trgfilename | awk -F"_" '{ print substr($3,0,8)}')


if [[ "$trgArrivedDate" != "$currentDayDate" ]];
 then
      echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
      echo "$(date '+%y/%m/%d %T') : ERROR : TEAUTH $location_type TRIGGER FILE - $trgFiles DATE ERROR, TRIGGER FILE DATE : $trgArrivedDate, EXPECTED CURRENT DAY DATE : $currentDayDate" | tee -a $ERR_FILE
      exit 1
fi


controlfilepattern=$(echo $teauthFilePatternControl | awk -F"_" '{ print $1}')

controlfilepatterndated=$(echo $controlfilepattern"_$trgArrivedDate*".gz)

totalctrlfiles=$(ls -l $SRC/$teauthFilePatternControl | wc -l)

if [[ "$totalctrlfiles" -eq "0" ]];
   then
      echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
      echo "$(date '+%y/%m/%d %T') : ERROR :  TEAUTH $location_type CONTROL FILE $controlfilepatterndated  MISSING" | tee -a $ERR_FILE
      exit 1
fi

if [[ "$totalctrlfiles" -gt "1" ]];
   then
      echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
      echo "$(date '+%y/%m/%d %T') : ERROR : TEAUTH INVALID NUMBER OF $location_type CONTROL FILE - CONTROL FILE COUNT IS $totalctrlfiles" | tee -a $ERR_FILE

  exit 1
fi


controlFileCount=$(ls -l $SRC/$controlfilepatterndated | wc -l)

if [[ "$controlFileCount" -eq "0" ]];
   then
      echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
      echo "$(date '+%y/%m/%d %T') : ERROR :  TEAUTH $location_type CONTROL FILE IS NOT PRESENT FOR THE DATE - $currentDayDate" | tee -a $ERR_FILE
      exit 1
fi


#Check if KL TEAUTH UK/ROI Files are present in source folder

storefilepatterndated=$(echo $teauthFilePatternStore"_$trgArrivedDate*".gz)

storeFileCount=$(ls -l $SRC/$teauthFilePatternStore | wc -l)

if [[ "$storeFileCount" == "0" ]];
   then
      echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
      echo "$(date '+%y/%m/%d %T') : ERROR : TEAUTH $location_type STORE FILES ARE NOT PRESENT IN FILE SHARE SERVER" | tee -a $ERR_FILE
      exit 1
fi


storeFileCountToday=$(ls -l $SRC/$storefilepatterndated | wc -l)

if [[ "$storeFileCountToday" == 0 ]]
   then
       otherDayFileCount=`expr $storeFileCount - $storeFileCountToday`
       echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
      echo "$(date '+%y/%m/%d %T') : ERROR : TEAUTH $location_tye STORE FILES FOR TODAY ARE NOT PRESENT IN FILE SHARE SERVER.  TODAY'S FILE COUNT - $storeFileCountToday ,FILES FOUND FOR OTHER DAYS - $otherDayFileCount" | tee -a $ERR_FILE
      exit 1
fi

if [[ "$storeFileCountToday" != "$storeFileCount" ]]
   then
 otherDayFileCount=`expr $storeFileCount - $storeFileCountToday`
       echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
      echo "$(date '+%y/%m/%d %T') : ERROR : TEAUTH TODAY'S $location_type STORE FILES AVAILABLE FOR PROCESSING - $storeFileCountToday , FILES FOUND WITH INVALID DATE IN FILE NAME IS  - $otherDayFileCount" | tee -a $ERR_FILE
      exit 1
fi


}



validateTeauthFiles(){

previousDayDate=$(date +%Y%m%d -d "yesterday")
typeset -i ERROR_COUNT=0

      controlfile=$(find $SRC/$teauthFilePatternControl -maxdepth 1 -type f)

      storeInCtrlFile=$(zcat $controlfile | awk '{ print substr($0,2,4) }')

      for cstore in ${storeInCtrlFile[@]}
         do

             #f1="KLL.KLTEAUTH.B"
             f1=$(echo $teauthFilePatternStore | awk -F"*" '{ print substr($1,0,14)}')
             f2="*"
             filestore="${f1}${cstore}_${currentDayDate}${f2}"

             storeFileInSrc=$(find $SRC/$filestore -maxdepth 1 -type f)

             if [[ "$storeFileInSrc" == "" ]];
                then
                   echo "$(date '+%Y-%m-%d %T') :TEAUTH FILE NOT FOUND FOR THE $location_type STORE $cstore" | tee -a $LOG_FILE
             else
             storeFile=`basename $storeFileInSrc`
             headVal=$(zcat $storeFileInSrc| head -1)

             if [[ "$headVal" == "" ]];
                then
                 echo "$(date '+%Y-%m-%d %T') :TEAUTH $location_type STORE FILE - $storeFile - IS EMPTY" | tee -a $LOG_FILE
				 filename=$(basename $storeFile .gz)
                 fileToArchive=${filename}_${TIMESTAMP}.gz
                 mv $SRC/${storeFile} $ARCHIVE/${fileToArchive}
             else
                   storeValInHead=${headVal:2:4}

                   dateInHeader=${headVal:6:6}

                    prevDay=${previousDayDate:2:6}
                   tailVal=$(zcat $storeFileInSrc| tail -1)

                   countInTail=${tailVal:2}
                    rowCount=$(zcat $storeFileInSrc | wc -l)

                   if [[ "${headVal:0:2}" != 10 ]];
                       then
                          echo "$(date '+%Y-%m-%d %T') : TEAUTH HEADER MISSING ON $location_type STORE FILE - $storeFile" | tee -a $LOG_FILE
                          strErrorFile=`basename $storeFile .gz`
                          strErrorFile=${strErrorFile}_${TIMESTAMP}_ERROR.gz
                          mv $SRC/${storeFile} $ARCHIVE/${strErrorFile}

                   elif [[ "${tailVal:0:2}" != 90 ]];
                      then
                         echo "$(date '+%Y-%m-%d %T') : TEAUTH TAIL RECORD MISSING ON $location_type STORE FILE - $storeFile" | tee -a $LOG_FILE
                         strErrorFile=`basename $storeFile .gz`
                         strErrorFile=${strErrorFile}_${TIMESTAMP}_ERROR.gz
                         mv $SRC/${storeFile} $ARCHIVE/${strErrorFile}

                   elif [[ "$cstore" != "$storeValInHead" ]];
                      then
                         echo "$(date '+%Y-%m-%d %T') : TEAUTH INVALID STORE IN HEADER ON $location_type STORE FILE - $storeFile , STORE IN HEADER IS - $storeValInHead" | tee -a $LOG_FILE
                         strErrorFile=`basename $storeFile .gz`
                         strErrorFile=${strErrorFile}_${TIMESTAMP}_ERROR.gz
                         mv $SRC/${storeFile} $ARCHIVE/${strErrorFile}

                   elif [[ "$dateInHeader" != "$prevDay" ]];
                      then
                         echo "$(date '+%Y-%m-%d %T') : TEAUTH INVALID DATE ON $location_type STORE FILE - $storeFile ,
                                                        DATE ON FILE IS - $dateInHeader AND EXPECTED DATE IS - $prevDay" | tee -a $LOG_FILE
														
                         strErrorFile=`basename $storeFile .gz`
                         strErrorFile=${strErrorFile}_${TIMESTAMP}_ERROR.gz
                         mv $SRC/${storeFile} $ARCHIVE/${strErrorFile}

                   elif [[ "$countInTail" -ne "$rowCount" ]];
                      then
                         echo "$(date '+%Y-%m-%d %T') : TEAUTH NUMBER OF ROWS MISMATCH ON $location_type STORE FILE - $storeFile ,
                                                        COUNT IN TAIL IS - $countInTail , TOTAL ROW COUNT IS - $rowCount" | tee -a $LOG_FILE
                         strErrorFile=`basename $storeFile .gz`
                         strErrorFile=${strErrorFile}_${TIMESTAMP}_ERROR.gz
                         mv $SRC/${storeFile} $ARCHIVE/${strErrorFile}
                   fi
         fi
   fi
done

storeFileInServer=$(ls -l $SRC/$teauthFilePatternStore | wc -l)

if [[ "$storeFileInServer" == "0" ]];
   then
      echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
      echo "$(date '+%y/%m/%d %T') : ERROR : TEAUTH VALIDATION FAILED FOR ALL THE $location_type STORE FILES PRESENT IN FILESHARE" | tee -a $ERR_FILE
      exit 1
fi

}

checkFileType

validateTeauthFiles

exit $?														
