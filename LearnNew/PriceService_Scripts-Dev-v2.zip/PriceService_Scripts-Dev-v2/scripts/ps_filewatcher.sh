#!/bin/bash
. $HOME/.bash_profile

RC=$?
if [[ $RC -ne 0 ]] ; then
   # Error exit
   echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : $0 failed calling profile script for variable setup"
   exit 1
fi

. $PSHOME/usr/local/scripts/config.sh

RC=$?
if [[ $RC -ne 0 ]] ; then
   # Error exit
   echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : $0 failed calling config script for variable setup"
   exit 1
fi

STAMP=`date +"%Y%m%d"`
PROG_NAME=$(basename $0 .sh)

file_param=$1

LOG_FILE=$LOG_PATH/${PROG_NAME}_log_${STAMP}.log
ERR_FILE=$ERROR_PATH/${PROG_NAME}_err_${STAMP}.log

if [ ! -d  "$LOG_PATH" ];
then
   echo "Log path is not set. Please set the LOG_PATH"
   exit 1
fi

if [ ! -d  "$ERROR_PATH" ];
then
   echo "Error path is not set. Please set the ERROR_PATH"
   exit 1
fi

. $PSHOME/usr/local/scripts/clearance_config.sh

RC=$?
if [[ $RC -ne 0 ]] ; then
   # Error exit
   echo "$(date '+%Y-%m-%d %T') : Return code: ${RC} : ERROR : $0 failed calling clearance config script for variable setup" |tee -a $ERR_FILE
   exit 1
fi

USER="$(id -u -n)"

input_param=$(echo $1 | tr [[A-Z]] [[a-z]])

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME started by $USER" | tee -a $LOG_FILE

check_for_file()
{
   start_time_sec=`date +%s`
   #To check for the file in the remote server
   remote_path_date=${REMOTE_PATH}/${STAMP}
   while [ true ];
   do
      #The array will have filenames with the path 
      remote_files=($(ssh -o StrictHostKeyChecking=no ${REMOTE_USER}@${REMOTE_SERVER} "ls -l ${REMOTE_PATH}/${REMOTE_FILE_PATTERN} |tr  -s ' ' |cut -d ' ' -f9"))
      RC=$?
      if [[ $RC -ne 0 ]] ; then
         # Error exit
         echo "$(date '+%Y-%m-%d %T') : Error while ssh ...Check error logs" | tee -a $LOG_FILE
         echo "$(date '+%Y-%m-%d %T') : Return code: ${RC} : ERROR : Failed to ssh !!"  | tee -a $ERR_FILE
         exit 1
      fi
      remote_file_count=${#remote_files[@]}
      echo "count : $remote_file_count"
      #To wait for sometime before checking for the files again.
      if [[ "$remote_file_count" -ne "$ReqNoFiles" ]];then

         if [ $(( `date +%s` - $start_time_sec )) -lt "$WAIT_TIME" ];then
            echo "$(date '+%Y-%m-%d %T'): sleeping for $(( $WAIT_TIME / 6 ))" | tee -a $LOG_FILE
            sleep $(( $WAIT_TIME / 10 ))
         else
	    echo "$(date '+%Y-%m-%d %T') : Script failed waiting for file..!!!Exiting .Check Error File" |tee -a $LOG_FILE
            echo "$(date '+%Y-%m-%d %T') : $WAIT_TIME seconds elapsed waiting for the file and file is not found.!!!! Hence exiting.." |tee -a $ERR_FILE
            exit 1;
         fi
      else
	 echo "$(date '+%Y-%m-%d %T') : Check for the completeness of the file by grepping the final tag in the file" | tee -a $LOG_FILE
	 check_file_integrity

         echo "$(date '+%y/%m/%d %T') : $ReqNoFiles files found in ${REMOTE_SERVER} ...!!! Hence Copying" | tee -a $LOG_FILE
         return 0;
      fi
   done
}

copy_files(){
   echo "$(date '+%Y-%m-%d %T') : Started the file copying process..!!!" | tee -a $LOG_FILE
   rm -rf $TEMP_PATH/*
   for (( k=0; k<${remote_file_count}; k++ ))
   do   
   scp -o StrictHostKeyChecking=no ${REMOTE_USER}@${REMOTE_SERVER}:${remote_files[$k]} $TEMP_PATH
   RC=$?
   if [ "$RC" -ne "0" ];
      then
         echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
         echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : Failed to scp ${remote_files[$k]}  to $TEMP_PATH" | tee -a  $ERR_FILE
         exit 1
   fi
   done

   for (( l=0 ; l<${remote_file_count}; l++ ))
   do
      filename=`basename ${remote_files[$l]}`
      gzip -c ${TEMP_PATH}/$filename > "${DEST_PATH}/${filename}.gz"
      RC=$?
      if [ "$RC" -ne "0" ];
         then
            echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
            echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : Failed to ZIP the file to ${DEST_PATH} path" | tee -a  $ERR_FILE
            exit 1
      else
         echo "$(date '+%Y-%m-%d %T') : The file $ff is zipped to ${DEST_PATH}/${filename}.gz" | tee -a $LOG_FILE
      fi
   done
  echo "$(date '+%Y-%m-%d %T') : Completed the file copying process..!!!" | tee -a $LOG_FILE

}
check_file_integrity(){
   echo "$(date '+%Y-%m-%d %T') : Started File Integrity check process..!!!" | tee -a $LOG_FILE
   eof_pattern="</Products>"
   for (( k=0; k<${remote_file_count}; k++ ))
   do
      typeset -i count=0
      while [ true ]
      do
         end_of_file=$(ssh -o StrictHostKeyChecking=no ${REMOTE_USER}@${REMOTE_SERVER} "tail -n1 ${remote_files[$k]} | dos2unix ")
         RC=$?
         echo "eof : $end_of_file"
         if [ "$RC" -ne "0" ];
         then
            echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
            echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : Failed to ssh when checking for file integrity of  ${remote_files[$k]}" | tee -a  $ERR_FILE
            exit 1
         fi

         if [[ "$end_of_file" != "$eof_pattern" && $count -lt 3 ]];then
            echo "$(date '+%Y-%m-%d %T') : Sleeping for 60 secs while waiting for file to be complete"
	    sleep 60
            count=$count+1
         elif [[ "$end_of_file" == "$eof_pattern" ]];then
            echo "$(date '+%Y-%m-%d %T') : ${remote_files[$k]} is a complete file and hence can be copied" |tee -a $LOG_FILE
            break;
         else
            echo "$(date '+%Y-%m-%d %T') : ${remote_files[$k]} is an incomplete file hence exiting" |tee -a $LOG_FILE
	    exit 1;
         fi

      done
   
   done
   echo "$(date '+%Y-%m-%d %T') : completed File Integrity check process..!!!" | tee -a $LOG_FILE
return 0
}

archive(){
   echo "$(date '+%Y-%m-%d %T') : Started Archiving process..!!!" | tee -a $LOG_FILE
   for (( l=0; l<${remote_file_count}; l++ ))
   do
   filename=`basename ${remote_files[$l]}`
   ssh -o StrictHostKeyChecking=no ${REMOTE_USER}@${REMOTE_SERVER} "gzip -c ${remote_files[$l]} > ${REMOTE_ARCHIVE_PATH}/${filename}.gz"
   RC=$?
   if [ "$RC" -ne "0" ];
      then
         echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
         echo "$(date '+%Y-%m-%d %T') : Return code: ${RC} : ERROR : Failed to Archive file: ${remote_files[$l]} to $REMOTE_ARCHIVE_PATH in $REMOTE_SERVER" | tee -a  $ERR_FILE
         exit 1
   fi
   echo "$(date '+%Y-%m-%d %T') : Archiving of ${remote_files[$l]} complete" | tee -a $LOG_FILE
   
   #Delete the old file after archiving.
   ssh -o StrictHostKeyChecking=no ${REMOTE_USER}@${REMOTE_SERVER} "rm -rf ${remote_files[$l]}"
   RC=$?
   if [ "$RC" -ne "0" ];
      then
         echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
         echo "$(date '+%Y-%m-%d %T') : Return code: ${RC} : ERROR : Failed to Delete the archived file: ${remote_files[$l]}" | tee -a  $ERR_FILE
         exit 1
   fi
   echo "$(date '+%Y-%m-%d %T') : Archiving of ${remote_files[$l]} complete" | tee -a $LOG_FILE
   done
   
   echo "$(date '+%Y-%m-%d %T') : Archive process complete..!!!" | tee -a $LOG_FILE
}
check_for_file

copy_files

archive

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME completed successfully" | tee -a $LOG_FILE
exit $?
