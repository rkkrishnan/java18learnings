#!/bin/bash
###################################################################################################################
#Author: Pallavi Ambali
#Created date: 09-Jan-2015
#Created Sprint: Sprint16
#Functionality: To archive the rejected clearance files from rej folder to rej_arch folder.
####################################################################################################################

. $HOME/.bash_profile
. $PSHOME/usr/local/scripts/config.sh

STAMP=`date +"%Y%m%d"`
PROG_NAME=$(basename $0 .sh)
USER="$(id -u -n)"

LOG_FILE=$LOG_PATH/${PROG_NAME}_log_${STAMP}.log
ERR_FILE=$ERROR_PATH/${PROG_NAME}_err_${STAMP}.log
echo After log set

if [[ ! -d $LOG_PATH ]];
then
    echo "$(date '+%y/%m/%d %T') : ERROR : the variable LOG_PATH is not set properly ..."
    exit 1
fi

if [[ ! -d $ERROR_PATH ]];
then
    echo "$(date '+%Y-%m-%d %T') : ERROR : the variable ERROR_PATH  is not set properly ..."
    exit 1
fi

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME started by $USER" | tee -a $LOG_FILE

#To check the files present in data/rej folder
files=($(find $REJECT -maxdepth 1 -type f))

if [[ "${#files[@]}" -gt 0 ]]
then
    echo "$(date '+%y/%m/%d %T') : moving the files to archive directory" | tee -a $LOG_FILE

    for (( i = 0; i < ${#files[@]}; i++ )) do
    file_name=${files[i]}
    

    if [[ "$file_name" == *REJECT_FILE* ]] ;
    then
            
             mv $file_name $REJECT_ARCHIVE
             gzip $REJECT_ARCHIVE/*REJECT_FILE*
    fi
    
    if [[ "$RC" -ne "0" ]];
    then
        echo "$(date '+%Y-%m-%d %T') : ERROR: Failed to move the file from >$SRC< to >$REJECTARCHIVE<" | tee -a $LOG_FILE
        echo "$(date '+%Y-%m-%d %T') : ERROR: Return code: ${RC} Failed to move the file from >$REJECT< to >$REJECTARCHIVE<" | tee -a $ERR_FILE
        exit 1
    fi
        echo "$(date '+%y/%m/%d %T') : File  > $file_name < is archived..." | tee -a $LOG_FILE
done
    else
        echo "$(date '+%Y-%m-%d %T') : no files to be archived" | tee -a $LOG_FILE
fi

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME completed successfully" | tee -a $LOG_FILE
exit $?


