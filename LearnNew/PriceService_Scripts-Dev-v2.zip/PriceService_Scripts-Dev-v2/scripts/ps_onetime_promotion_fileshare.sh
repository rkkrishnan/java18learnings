#!/bin/bash

# This program will pick the one time promotion JSON file from fileshare and transfer to Adapter server
# Downloads one time PROMO files from the fileshare server and copy it into adapter server

set -o pipefail

. $HOME/.bash_profile
RC=$?
if [[ $RC -ne 0 ]] ; 
then
	# Error exit
	echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : $0 failed calling profile script for variable setup"
	exit 1
fi

. $PSHOME/usr/local/scripts/config.sh
RC=$?
if [[ $RC -ne 0 ]] ; 
then
	# Error exit
	echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : $0 failed calling config script for variable setup"
	exit 1
fi

. $PSHOME/usr/local/scripts/clearance_config.sh
RC=$?
if [[ $RC -ne 0 ]] ; 
then
	# Error exit
	echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : $0 failed calling config script for variable setup"
	exit 1
fi

if [ "$#" -ne "1" ]
then
	echo "$(date '+%y/%m/%d %T') : ERROR : Expecting the parameter, Param1-[SP/TH/MB] ...."
	exit 1
fi

STAMP=`date +"%Y%m%d"`
PROG_NAME=$(basename $0 .sh)
param=$1

LOG_FILE=$LOG_PATH/${PROG_NAME}_log_${STAMP}.log
ERR_FILE=$ERROR_PATH/${PROG_NAME}_err_${STAMP}.log

if [ ! -d  "$LOG_PATH" ];
then
	echo "Log path is not set. Please set the LOG_PATH"
	exit 1
fi

if [ ! -d  "$ERROR_PATH" ];
then
	echo "Error path is not set. Please set the ERROR_PATH"
	exit 1
fi

SSH_ERR=$SSH_TMP/${PROG_NAME}_err_${STAMP}

USER="$(id -u -n)"

echo "Job $PROG_NAME started by $USER"
echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME started by $USER" | tee -a $LOG_FILE

SERVER=$PS_USER@$FILESHR_HOST

if [[ "$param" == "SP" ]]
then
	onetime_file_name=${onetime_promo_file_name_SP}
elif [[ "$param" == "TH" ]]
then
	onetime_file_name=${onetime_promo_file_name_TH}
elif [[ "$param" == "MB" ]]
then
	onetime_file_name=${onetime_promo_file_name_MB}
else
	echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
	echo "$(date '+%y/%m/%d %T') : ERROR : Param should be [SP or TH or MB]" | tee -a $ERR_FILE
	exit 1
fi

# Check the file exists and no duplicates files are present...
checkServer() {

	echo "$(date '+%Y-%m-%d %T') : Checking for the required files in the server" | tee -a $LOG_FILE
	from="${SRC}/onetimepromotion/${onetime_file_name}"

	exec 6>&1
	exec 1> $SSH_ERR
	exec 2>&1

	# src_file_name contains file name and the time stamp
	src_file_name=($(ssh -o StrictHostKeyChecking=no $SERVER "find $from -maxdepth 1 -type f "))
	RC=$?

	exec 1>&6 6>&-

	#Changed to handle error
	sshout=$(tail -n1 $SSH_ERR | grep -ve "-----")

	if [[ -z "$src_file_name" || ! -z $sshout ]];
	then
		echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
		echo "$(date '+%y/%m/%d %T') : ERROR : Failed to ssh !!" | tee -a $ERR_FILE
		echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR Occured is : >$sshout< !!" | tee -a $ERR_FILE
	exit 1
	fi
	
	file_count=${#src_file_name[@]}
	if [[ "$file_count" -ne "1" ]];
	then
		echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
		echo "$(date '+%Y-%m-%d %T') : Duplicate files are present in the directory..." | tee -a $ERR_FILE
		exit 1
	fi
	echo "$(date '+%Y-%m-%d %T') : Completed checking in the server" | tee -a $LOG_FILE
}


copyFile() {
	echo "$(date '+%Y-%m-%d %T') : Copying the file $onetime_file_name from the server..." | tee -a $LOG_FILE
	to="${SRC}/onetimepromotion"

	doScp $from $to
	
	echo "$(date '+%Y-%m-%d %T') : Copied file $onetime_file_name from $FILESHR_HOST..." | tee -a $LOG_FILE

	file=$(basename $from)
	gzip -df $to/$file
	RC=$?
	if [ "$RC" -ne "0" ];
	then
		echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
		echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : Failed to unzip the file $onetime_file_name..." | tee -a $ERR_FILE
		exit 1
	fi
	echo "$(date '+%Y-%m-%d %T') : Completed coping file $onetime_file_name..." | tee -a $LOG_FILE
}

doScp() {
	local from=$1
	local to=$2

	scp -o StrictHostKeyChecking=no $SERVER:$from $to

	RC=$?
	if [ "$RC" -ne "0" ];
	then
		echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
		echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : Failed to scp $from to $to" | tee -a $ERR_FILE
		exit 1
	fi
}


archiveFiles() {
	echo "$(date '+%Y-%m-%d %T') : Archiving the file $onetime_file_name in the server $FILESHR_HOST..." | tee -a $LOG_FILE
	
	pattern="${src_file_name}"
	temp_name=$(basename $pattern .gz)
	TIMESTAMP=$(date +%Y%m%d%H%M%S)
	append_date=${temp_name}_${TIMESTAMP}.gz
	
	ssh -o StrictHostKeyChecking=no $SERVER "mv $pattern $ARCHIVE/$append_date"
	
	echo "$(date '+%Y-%m-%d %T') : Archiving completed in the server $FILESHR_HOST..." | tee -a $LOG_FILE
}


checkServer

copyFile

archiveFiles

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME completed successfully" | tee -a $LOG_FILE

exit $?
