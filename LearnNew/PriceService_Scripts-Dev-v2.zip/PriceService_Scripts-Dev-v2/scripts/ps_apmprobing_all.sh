#!/bin/bash
#
# Created By : - Biswo Ranjan
# Date: - 20150708
# Created Sprint: - Sprint 29
# Functionality: -  This is the master script to call child script(ps_apmprobing.sh) to have control on probing functionality in Adapter and service server
# Usage: - Program Name - ps_apmprobing_all.sh
#                                        Input Arguments - ON or OFF
#          Output Expected - should log the error if script fails in any of the rename activity in price server and Adapter
#set -x
. $HOME/.bash_profile
. $PSHOME/usr/local/scripts/config.sh
. $PSHOME/profile

SWITCH_PARAM=`echo $1 |tr '[:lower:]' '[:upper:]'`
SERVER=`echo $2 |tr '[:lower:]' '[:upper:]'`
echo "no of params : $#"
if [ "$#" -lt "1" ];
then
        echo "USAGE:The script accepts one parameters and one optional for CICD"
        exit 1;
else
        if [[ "$SWITCH_PARAM" != "ON" && "$SWITCH_PARAM" != "OFF" ]];
        then
                echo "USAGE:The script accepts parameters.  basename $0 [ON/OFF] [ADAPTER/SERVICE optional,used for CICD]"
                exit 1;
        fi
fi

#SWITCH_PARAM=`echo $1 |tr '[:lower:]' '[:upper:]'`
STAMP=`date +"%Y%m%d"`
PROG_NAME=$(basename $0 .sh)
USER="$(id -u -n)"
SCRIPT_PROBING="$PSHOME/usr/local/scripts/ps_apmprobing.sh"
LOG_FILE=$LOG_PATH/${PROG_NAME}_log_${STAMP}.log
ERR_FILE=$ERROR_PATH/${PROG_NAME}_err_${STAMP}.log

if [ -z "$LOG_PATH" ];
then
      echo "Log path is not set. Please set the LOG_PATH"
      exit 1
fi

if [ -z "$ERROR_PATH" ];
then
      echo "Error path is not set. Please set the ERROR_PATH"
      exit 1
fi

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME started by $USER with param $*" | tee -a $LOG_FILE

######### Running Probing scripts in Adapter Servers
run_apm_adapter()
{
        echo "Started in adapter.."
        for hname in ${ADAPTER_HOST[@]}
        do
                ############## running probing script in Adapter servers
                echo "$(date '+%Y-%m-%d %T') : Staring $SCRIPT_PROBING in Adapter server ($hname)..." | tee -a $LOG_FILE
                $SCRIPT_PROBING "$SWITCH_PARAM"
                RC=$?
                if [ "$RC" -ne "0" ];
                then
                                echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
                                echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : Failed to run $SCRIPT_PROBING in Adapter server ($hname)..." | tee -a $ERR_FILE
                                exit 1
                fi
                echo "$(date '+%Y-%m-%d %T') : Completed $SCRIPT_PROBING in Adapter server ($hname)..." | tee -a $LOG_FILE

        done
}

######### Running Probing scripts in Service Servers
run_apm_service()
{
        echo "Started in Service.."
        for hname in ${PS_SERVERS[@]}
        do
                ############## running probing script in service servers
                echo "$(date '+%Y-%m-%d %T') : Staring $SCRIPT_PROBING in Service server ($hname)..." | tee -a $LOG_FILE
                ssh $USER@$hname "$SCRIPT_PROBING "$SWITCH_PARAM""
                RC=$?
                if [ "$RC" -ne "0" ];
                then
                                echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
                                echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : Failed to run $SCRIPT_PROBING in Service server ($hname)..." | tee -a $ERR_FILE
                                exit 1
                fi
                echo "$(date '+%Y-%m-%d %T') : Completed $SCRIPT_PROBING in Service server ($hname)..." | tee -a $LOG_FILE

done
}

if [[ "$SERVER" == "ADAPTER" ]];then
        run_apm_adapter
echo "here"
elif [[ "$SERVER" == "SERVICE" ]];then
        run_apm_service

else
        run_apm_adapter
        run_apm_service

fi

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME completed by $USER" | tee -a $LOG_FILE

exit $?;