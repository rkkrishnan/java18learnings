#!/bin/bash
. $HOME/.bash_profile

RC=$?
if [[ $RC -ne 0 ]] ; then
  # Error exit
  echo "$(date '+%Y-%m-%d %T') : Return code: ${RC} : ERROR : $0 failed calling profile script for variable setup"
  exit 1
fi

. $PSHOME/usr/local/scripts/config.sh

RC=$?
if [[ $RC -ne 0 ]] ; then
  # Error exit
  echo "$(date '+%Y-%m-%d %T') : Return code: ${RC} : ERROR : $0 failed calling config script for variable setup"
  exit 1
fi

STAMP=`date +"%Y%m%d"`
PROG_NAME=$(basename $0 .sh)

LOG_FILE=$LOG_PATH/${PROG_NAME}_log_${STAMP}.log
ERR_FILE=$ERROR_PATH/${PROG_NAME}_err_${STAMP}.log

if [ ! -d  "$LOG_PATH" ];
then
      echo "Log path is not set. Please set the LOG_PATH"
      exit 1
fi

if [ ! -d  "$ERROR_PATH" ];
then
      echo "Error path is not set. Please set the ERROR_PATH"
      exit 1
fi

. $PSHOME/usr/local/scripts/clearance_config.sh

RC=$?
if [[ $RC -ne 0 ]] ; then
  # Error exit
  echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : $0 failed calling clearance config script for variable setup"
  exit 1
fi

#Checking for number of arguments 
if [ "$#" -ne 1 ]
then
   echo "Invalid number of arguments" | tee -a $ERR_FILE
   echo "Usage : Should be the type of files to be processed."| tee -a $ERR_FILE
   echo "Script >$PROG_NAME< Failed .. Please refer to the error file >$ERR_FILE< for more details" | tee -a $LOG_FILE
   exit -1
fi

USER="$(id -u -n)"

file_param=$1

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME started by $USER for parameter $file_param" | tee -a $LOG_FILE

SERVER=$PS_USER@$FILESHR_HOST

copyFiles() {

rm -f $DEST_PATH/*
rm -f $TEMP_PATH/*

if [ -z "$srcFilePattern" ];
then
       echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
       echo "$(date '+%Y-%m-%d %T') : ERROR : File pattern not found" | tee -a $ERR_FILE
       exit 1
fi

for i in $srcFilePattern
  do
	echo the filename in array is $i
      scp -o StrictHostKeyChecking=no $SERVER:${SRC}/${i} $TEMP_PATH

     RC=$?
     if [ "$RC" -ne "0" ];
        then
           echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
           echo "$(date '+%Y-%m-%d %T') : Return code: ${RC} : ERROR : Failed to scp $i file from $SRC to $DEST_PATH" | tee -a $ERR_FILE
           exit 1
     fi
  done

gunzip -f $TEMP_PATH/*.gz

 RC=$?
   if [ "$RC" -ne "0" ];
   then
   echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
   echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : Failed to unzip the files in  $DEST_PATH" | tee -a $ERR_FILE
   exit 1
  fi
#Move the unzipped files from temp folder to the main IN folder

for ff in $(ls -1 $TEMP_PATH)
do
	file_encode=$(file ${TEMP_PATH}/$ff | grep -wci "ISO-8859")

    if (( $file_encode == 1 ));
    then
	   iconv -f ISO-8859-1 -t utf-8 $TEMP_PATH/$ff -o $TEMP_PATH/$ff"_utf8"

	   RC=$?
	   if [[ "$RC" -ne "0" ]];
	   then
	      echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
	      echo "$(date '+%Y-%m-%d %T') : Failed to convert the file <$TEMP_PATH/$ff> to UTF-8..." | tee -a $ERR_FILE
	      exit 1
	   fi

	   mv $TEMP_PATH/$ff"_utf8" $TEMP_PATH/$ff

	   RC=$?
	   if [[ "$RC" -ne "0" ]];
	   then
	      echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
	      echo "$(date '+%Y-%m-%d %T') : <$TEMP_PATH/$ff> : No such file or directory.." | tee -a $ERR_FILE
	   exit 1
	   fi
    fi
done;
 
mv $TEMP_PATH/* $DEST_PATH

 RC=$?
   if [ "$RC" -ne "0" ];
   then
   echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
   echo "$(date '+%Y-%m-%d %T') : Return code: ${RC} : ERROR : Failed to move files from ${TEMP_PATH} to  ${DEST_PATH}" | tee -a $ERR_FILE
   exit 1
  fi
return 0
}


archiveFiles() {

ssh_out=$(ssh -o StrictHostKeyChecking=no $PS_USER@$FILESHR_HOST "$PSHOME/usr/local/scripts/ps_dataarchive.sh '${file_param}'")

RC=$?
if [[ "$RC" -ne "0" ]];
then
    echo "$(date '+%Y-%m-%d %T') : ERROR: Error occured while running ps_archive_files_all.sh script check error log " | tee -a $LOG_FILE
    echo "$(date '+%Y-%m-%d %T') : ERROR: Return code: ${RC} ps_dataarchive.sh script " | tee -a $ERR_FILE
    echo "$(date '+%Y-%m-%d %T') : ERROR: from ssh >> $ssh_out <<"  | tee -a $ERR_FILE
    exit 1
fi
return 0;

}

check_and_validate(){
ssh_out=$(ssh -o StrictHostKeyChecking=no $PS_USER@$FILESHR_HOST "$VALIDATOR_SCRIPT '${file_param}'")

RC=$?
if [[ "$RC" -ne "0" ]];
then
    echo "$(date '+%Y-%m-%d %T') : ERROR: Error occured while running $VALIDATOR_SCRIPT script check logs " | tee -a $LOG_FILE
    echo "$(date '+%Y-%m-%d %T') : ERROR: Return code: ${RC} $VALIDATOR_SCRIPT script " | tee -a $ERR_FILE
    echo "$(date '+%Y-%m-%d %T') : ERROR: from ssh >> $ssh_out <<"  | tee -a $ERR_FILE
    exit 1
fi
return 0;
}

check_and_validate

copyFiles

archiveFiles

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME completed successfully" | tee -a $LOG_FILE

exit $?
