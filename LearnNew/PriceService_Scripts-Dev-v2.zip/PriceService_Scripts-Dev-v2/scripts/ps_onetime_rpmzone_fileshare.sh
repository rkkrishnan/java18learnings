#!/bin/bash
# Downloads rpm zone onetime file from the fileshare server and copy it into adapter server
. $HOME/.bash_profile

RC=$?
if [[ $RC -ne 0 ]] ; then
  # Error exit
  echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : $0 failed calling profile script for variable setup"
  exit 1
fi

. $PSHOME/usr/local/scripts/config.sh

RC=$?
if [[ $RC -ne 0 ]] ; then
  # Error exit
  echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : $0 failed calling config script for variable setup"
  exit 1
fi

STAMP=`date +"%Y%m%d"`
PROG_NAME=$(basename $0 .sh)

file_param=$1

LOG_FILE=$LOG_PATH/${PROG_NAME}_log_${STAMP}.log
ERR_FILE=$ERROR_PATH/${PROG_NAME}_err_${STAMP}.log

if [ ! -d  "$LOG_PATH" ];
then
      echo "Log path is not set. Please set the LOG_PATH"
      exit 1
fi

if [ ! -d  "$ERROR_PATH" ];
then
      echo "Error path is not set. Please set the ERROR_PATH"
      exit 1
fi

. $PSHOME/usr/local/scripts/clearance_config.sh

RC=$?
if [[ $RC -ne 0 ]] ; then
  # Error exit
  echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : $0 failed calling clearance config script for variable setup"
  exit 1
fi

SSH_ERR=$SSH_TMP/${PROG_NAME}_err_${STAMP}

USER="$(id -u -n)"

file_param=$(echo $1 | tr [[A-Z]] [[a-z]])

if [[ "$file_param" != "rpmzoneonetime" ]];
then
        echo "$(date '+%Y-%m-%d %T') : ERROR: The parameter should be [rpmzoneonetime].." | tee -a $LOG_FILE
        echo "$(date '+%Y-%m-%d %T') : ERROR: Return code: ${RC} $PROG_NAME script failed!!" | tee -a $ERR_FILE
        exit 1
fi

echo "Job $PROG_NAME started by $USER"
echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME started by $USER" >> $LOG_FILE

SERVER=$PS_USER@$FILESHR_HOST


validateRpmZoneFiles() {

ssh_out=$(ssh -o StrictHostKeyChecking=no $PS_USER@$FILESHR_HOST "$PSHOME/usr/local/scripts/ps_onetime_rpmzone_filevalidation.sh '${file_param}'")

RC=$?
if [[ "$RC" -ne "0" ]];
then
    echo "$(date '+%Y-%m-%d %T') : ERROR: Error occured while running ps_onetime_rpmzone_filevalidation.sh script check error log " | tee -a $LOG_FILE
	 echo "$(date '+%Y-%m-%d %T') : ERROR: Return code: ${RC} ps_onetime_rpmzone_filevalidation.sh script " | tee -a $ERR_FILE
    echo "$(date '+%Y-%m-%d %T') : ERROR: from ssh >> $ssh_out <<"  | tee -a $ERR_FILE
    exit 1
fi

}

copyFiles() {

to="${destfile[0]}"

rm -f $DEST_PATH/*

 scp -o StrictHostKeyChecking=no $SERVER:$SRC/$filePattern $DEST_PATH

   RC=$?
   if [ "$RC" -ne "0" ];
   then
   echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
   echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : Failed to scp rpm_zone_onetime file from $SRC to $DEST_PATH" | tee -a $ERR_FILE
   exit 1
  fi


 gunzip -f $DEST_PATH/*.gz

 RC=$?
   if [ "$RC" -ne "0" ];
   then
   echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
   echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : Failed to unzip the files in  $DEST_PATH" | tee -a $ERR_FILE
   exit 1
  fi

 fileReceived=$(find $DEST_PATH -maxdepth 1 -type f)

 for ((i=0; i<${#fileReceived[@]}; i++))
         do
            tempFile=${fileReceived[$i]}
            rcvdFileName=`basename $tempFile`
            mv $DEST_PATH/$rcvdFileName $DEST_PATH/$to
			sed '$d' $DEST_PATH/$to > $DEST_PATH/temp.csv
            cp $DEST_PATH/temp.csv $DEST_PATH/$to
			rm -f $DEST_PATH/temp.csv
			
		 RC=$?
     if [ "$RC" -ne "0" ];
       then
          echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Check the error log in $ERR_FILE" | tee -a $LOG_FILE
          echo "$(date '+%y/%m/%d %T') : Return code: ${RC} : ERROR : Failed to rename the files in $DEST_PATH" | tee -a $ERR_FILE
          exit 1
     fi

 done

}


archiveFilespmZoneOnetime() {

ssh_out=$(ssh -o StrictHostKeyChecking=no $PS_USER@$FILESHR_HOST "$PSHOME/usr/local/scripts/ps_onetime_rpmzone_archivefiles.sh '${file_param}'")

RC=$?
if [[ "$RC" -ne "0" ]];
then
    echo "$(date '+%Y-%m-%d %T') : ERROR: Error occured while running ps_onetime_rpmzone_archivefiles.sh script check error log " | tee -a $LOG_FILE
    echo "$(date '+%Y-%m-%d %T') : ERROR: Return code: ${RC} ps_onetime_rpmzone_archivefiles.sh script " | tee -a $ERR_FILE
    echo "$(date '+%Y-%m-%d %T') : ERROR: from ssh >> $ssh_out <<"  | tee -a $ERR_FILE
    exit 1
fi

}

validateRpmZoneFiles

copyFiles

archiveFilespmZoneOnetime

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME completed successfully" | tee -a $LOG_FILE

exit $?