#!/bin/bash

# Script is to trigger an endpoint call to publish events that affects the label for next day.
# Whenever the evet publish is successfully finished, the script will create a dummy ps_eventpublish_20160624.finished.$thread.log
# in order to avoid republishing upon restart or rerun.
# Whenever there is a failure, it will create a failed file of the format ps_eventpublish_20160624.failed.$thread.log
# The housekeeping of the failed file will be taken care of by the script itself.

#publishURL=("scheduledEventAdmin/publishPriceChangeEvent" "scheduledEventAdmin/publishClearanceEndEvent" "scheduledEventAdmin/publishClearanceStartEvent" "scheduledEventAdmin/publishZoneLevelPromotionStart" "scheduledEventAdmin/publishZoneLevelPromotionEnd" "scheduledEventAdmin/publishPromotionStartProduct");
#progressPublishURL=();

SLOTS=2
fileParam=$(echo $1);

if [[ -z $fileParam ]];
then
   fileParam="EVENTPUBLISH"
   echo "$(date '+%Y-%m-%d %T %Z') : INFO : Parameter Missing ... Defaulting the Parameter to $fileParam"
fi;

. $HOME/.bash_profile
RC=$?
if [[ $RC -ne 0 ]] ; then
	# Error exit
	echo "$(date '+%Y-%m-%d %T %Z') : Return code: ${RC} : ERROR : $0 failed calling profile script for variable setup"
	exit 1
fi

. $PSHOME/usr/local/scripts/config.sh
RC=$?
if [[ $RC -ne 0 ]] ; then
	# Error exit
	echo "$(date '+%Y-%m-%d %T %Z') : Return code: ${RC} : ERROR : $0 failed calling config script for variable setup"
	exit 1
fi

. $PSHOME/usr/local/scripts/clearance_config.sh "$fileParam"
RC=$?
if [[ $RC -ne 0 ]] ; 
then
	# Error exit
	echo "$(date '+%Y-%m-%d %T %Z') : Return code: ${RC} : ERROR : $0 failed calling config script for variable setup"
	exit 1
fi

STAMP=`date +"%Y%m%d"`
PROG_NAME=$(basename $0 .sh)
USER="$(id -u -n)"
typeset -i fail=0;

LOG_FILE=$LOG_PATH/${PROG_NAME}_log_${STAMP}.log
ERR_FILE=$ERROR_PATH/${PROG_NAME}_err_${STAMP}.log

if [[ ! -d "$LOG_PATH" ]];
then
	echo "$(date '+%Y-%m-%d %T %Z') : Log path is not set. Please set the LOG_PATH."
	exit 1
fi

if [[ ! -d  "$ERROR_PATH" ]];
then
	echo "$(date '+%Y-%m-%d %T %Z') : Error path is not set. Please set the ERROR_PATH."
	exit 1
fi

failed=${LOG_PATH}/${PROG_NAME}_$STAMP".failed"

finished=${LOG_PATH}/${PROG_NAME}_$STAMP".finished"

echo "$(date '+%Y-%m-%d %T %Z') : Job $PROG_NAME started by $USER" | tee -a  $LOG_FILE

format_jobs()
{
   #set -x
   jnos="$#"
   pjobs="$1"
   shift
   for j
   do
      pjobs="$pjobs,$j"
   done
}

find_jobs()
{
   #set -x
   if [[ $pjobs == "" ]];
   then
     nnos=0;
     njobs="";
     return;
   fi;

   set -- `ps -p $pjobs | awk '$1 ~ /^[0-9]/ { print $1 }'`
   njobs="$*"

   pjobs=$njobs
   jobs=$pjobs

   nnos=$#
   jmsg="$pnos $jnos Jobs"
}

exec_prog()
{
 publishurl=$1
 progressurl=$2
 thread=$3

 log_temp=${LOG_PATH}/${PROG_NAME}_"log_temp"_"${STAMP}"_$thread.log

 LOG_FILE=${LOG_PATH}/${PROG_NAME}_log_${STAMP}_$thread.log
 ERR_FILE=${ERROR_PATH}/${PROG_NAME}_err_${STAMP}_$thread.log

 echo "$(date '+%Y-%m-%d %T %Z') : Event Publish script ${PROG_NAME} with thread ($thread) started with args - publish url ($publishurl) and progress url ($progressurl)" | tee -a $LOG_FILE

 status=$(curl -X GET -s -o ${log_temp} -w "%{http_code}" http://$ADAPTER_HOST:$PORT_SERVICE/${publishurl})

  if [ "$status" == "000" ];
  then
  	echo "$(date '+%Y-%m-%d %T %Z') : Event Publish failed due to connectivity error,check error log" | tee -a $LOG_FILE
  	echo "$(date '+%Y-%m-%d %T %Z') : curl exited with status code : $status" | tee -a  $ERR_FILE
  	return 1
  fi

  curl_response=$(cat ${log_temp})
  echo "$(date '+%Y-%m-%d %T %Z') : Response from curl is: <$curl_response>" | tee -a $LOG_FILE
  echo "$(date '+%Y-%m-%d %T %Z') : The status is <$status>" | tee -a  $LOG_FILE

  if [ "$status" == "200" ];
  then
  	echo "$(date '+%Y-%m-%d %T %Z') : Event Publish started successfully" | tee -a $LOG_FILE

  elif [ "$status" == "500" ];
  then
	echo "$(date '+%Y-%m-%d %T %Z') : Event Publish activity is aborted -Internal server error" | tee -a $LOG_FILE
	echo "$(date '+%Y-%m-%d %T %Z') : Event Publish activity is aborted -Internal server error" | tee -a $ERR_FILE
	echo "$(date '+%Y-%m-%d %T %Z') : ERROR :exited with status :$status" | tee -a $ERR_FILE
	return 1

  elif [ "$status" == "409" ];
  then
	echo "$(date '+%Y-%m-%d %T %Z') : Event Publish activity is aborted -There is already an import in progress" | tee -a $LOG_FILE
	echo "$(date '+%Y-%m-%d %T %Z') : Event Publish activity is aborted -There is already an import in progress" | tee -a $ERR_FILE
	echo "$(date '+%Y-%m-%d %T %Z') : ERROR :exited with status :$status" | tee -a $ERR_FILE
	return 1
	
  else
	echo "$(date '+%Y-%m-%d %T %Z') : Event Publish activity failed-exited with status : $status" | tee -a  $ERR_FILE
	return 1
  fi

  if [[ ! -z $progressurl ]];
  then
      echo "$(date '+%Y-%m-%d %T %Z') : Event Publish activity is monitored in the progressURL <$progressurl>" | tee -a $ERR_FILE

  typeset -i firstTime=1;
  # BEGIN - Monitor the Progress of the event published
  while true
  do
        if (( $firstTime == 1 ));
        then
            firstTime=0;
            sleep ${FIRST_SLEEP_PERIOD};
        else
	    sleep ${SLEEP_PERIOD};
        fi;
	#sleep period

	status=$(curl -X GET  -s -o $log_temp -w "%{http_code}" http://$ADAPTER_HOST:$PORT_SERVICE/${progressurl})

	if [ "$status" == "000" ];
	then
		echo "$(date '+%Y-%m-%d %T %Z') : Event Publishing progress check failed check error file" | tee -a $LOG_FILE
		echo "$(date '+%Y-%m-%d %T %Z') : curl exited with status code : $status" | tee -a $ERR_FILE
		echo "$(date '+%Y-%m-%d %T %Z') : The status is" $status | tee -a  $ERR_FILE
		return 1

	elif [ "$status" == "200" ];
	then
		output=$(cat $log_temp)

		ret=$(echo $output | grep -ic "import.*:.*completed" )

		if [[ "$ret" -ne "0" ]];
		then
		   # Event Publish is successful!!!
		   echo "$(date '+%Y-%m-%d %T %Z') : Event Publish Completed successfully" | tee -a $LOG_FILE
		   echo "$(date '+%Y-%m-%d %T %Z') : Output from restcall is >$output<" | tee -a $LOG_FILE
		   break
                fi;

		ret=$(echo $output | grep -ic "import.*:.*progress" )

		#if in progress sleep 60 and the check again
		if [[ "$ret" -eq "0" ]];
		then
	           #echo $output | grep "import.*:.*aborted"
		   ret=$(echo $output | grep -ic "import.*:.*failed")
			
		   if [[ "$ret" -ne "0" ]];
		   then
		       #Event Publish has errored,log and exit 1
		       echo "$(date '+%Y-%m-%d %T %Z') : Event Publish activity is aborted ,check script error log and adapter error logs for more info" | tee -a $LOG_FILE
		       echo "$(date '+%Y-%m-%d %T %Z') : ERROR from adapter is $output" | tee -a $ERR_FILE
		       return 1
		   else
		       # Nothing to report
		       echo "$(date '+%Y-%m-%d %T %Z') : Unable to recognize the status of the Event Publish activity ... marked as failure" | tee -a $LOG_FILE
		       echo "$(date '+%Y-%m-%d %T %Z') : ERROR from progressURL is <$output>" | tee -a $ERR_FILE
		       return 1;
		   fi
		else
		    echo "$(date '+%Y-%m-%d %T %Z') : JobName $PROG_NAME : Thread: $thread: Event Publish still in progress" | tee -a $LOG_FILE
		fi
	else
	    echo "$(date '+%Y-%m-%d %T %Z') : Event Publish progress check failed check error file" | tee -a $LOG_FILE
	    echo "$(date '+%Y-%m-%d %T %Z') : Event Publish activity failed-exited with status:$status " | tee -a  $ERR_FILE
	    return 1
	fi
    done
  else
    echo "$(date '+%Y-%m-%d %T %Z') : Event Publish progress check skipped ($progressurl)" | tee -a $LOG_FILE
  fi;

  # END - Monitor the Progress of the event published

  touch $finished."$thread".log
  echo "$(date '+%Y-%m-%d %T %Z') : Event Publish script for url ($publishurl) in thread ($thread) finished " > $finished."$thread".log

  echo "$(date '+%Y-%m-%d %T %Z') : Event Publish script ${PROG_NAME} thread ($thread) finished " | tee -a $LOG_FILE
  
  return $?
} # end of function exec_prog

### Beginning of the script ###
#set -x

typeset -i itr=0;

# Total count of urls
cnt=$( echo ${publishURL[@]} | awk -F' ' '{ split($0,a," "); { print length(a); } }' );

cntProgress=$( echo ${progressPublishURL[@]} | awk -F' ' '{ split($0,a,","); { print length(a); } }' );

if [[ $cnt == 0 ]];
then
   echo "$(date '+%Y-%m-%d %T %Z') : publishURL string is empty ($cnt) - ($publishURL) ... exiting" | tee -a  $LOG_FILE
   exit 1;
fi;

   rm -f "$failed".*.log

   ret=$?

   if [[ $ret != "0" ]];
   then
      echo "$(date '+%Y-%m-%d %T %Z') : Unable to remove failed file ($failed.*) ... exiting" | tee -a  $LOG_FILE
      exit 1 ;
   fi;

# BEGIN - Threading logic
while true
do

  url=$( echo ${publishURL[$itr]} );
  progressurl=$( echo ${progressPublishURL[$itr]} );

  if [[ -f $finished."$itr".log ]];
  then
     echo "$(date '+%Y-%m-%d %T %Z') : The event publishing ($url) in thread ($itr) is already finished ... skipping" | tee -a  $LOG_FILE
     itr=$itr+1;

     if (( $itr >= $cnt ));
     then
       break;
     fi;
     continue;
  fi;

  find_jobs

   while [ $nnos -ge $SLOTS ]
   do
     sleep 1
     find_jobs
   done

   echo "$(date '+%Y-%m-%d %T %Z') : The event publishing ($url) in thread ($itr) is invoked" | tee -a  $LOG_FILE
   ( exec_prog "$url" "$progressurl" $itr || touch $failed."$itr".log ) &

   job=$!
   jobs=$( echo "$jobs $job" | sed 's/^\ *//g')
   format_jobs $jobs

   itr=$itr+1;

  if (( $itr >= $cnt ));
  then
    break;
  fi;

done;
# END - Threading logic

echo "$(date '+%Y-%m-%d %T %Z') : Spawned all threads and waiting for them to finish" | tee -a  $LOG_FILE

   find_jobs

   while [ $nnos -gt 0 ]
   do
     sleep 1
     find_jobs
   done

wait;

itr=0;

# BEGIN - Checking for failures 
while true
do
  
  if [[ -f $failed."$itr".log ]];
  then
    echo "$(date '+%Y-%m-%d %T %Z') : Event Publishing for thread ($itr) and  publish URL (${publishURL[$itr]})" | tee -a  $LOG_FILE
    fail=1;
  fi;

  itr=$itr+1;

  if (( $itr >= $cnt ));
  then
    break;
  fi;

done;
# END - Checking for failures 

if [[ $fail == 1 ]];
then
   echo "$(date '+%Y-%m-%d %T %Z') : Job $PROG_NAME Failed ... Exiting" | tee -a $LOG_FILE
   exit 1;
else
   echo "$(date '+%Y-%m-%d %T %Z') : Job $PROG_NAME Completed Successfully" | tee -a $LOG_FILE
fi;

exit $?

#### End of Script ####
