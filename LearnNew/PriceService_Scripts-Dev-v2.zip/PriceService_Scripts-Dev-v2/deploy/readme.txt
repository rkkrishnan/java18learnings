This folder would contain the deployable components - 
1) public key details of the server. 
