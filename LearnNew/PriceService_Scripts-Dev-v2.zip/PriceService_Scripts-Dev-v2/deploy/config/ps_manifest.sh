#!/bin/bash

# Manifest file is a master file, which contains the information of scripts related to build, deploy and run.

# Each scripts should have a entry in manifest file.
# The entry should contain 
# <filename>:[ADAPTER/SERVICE/FILESHARE]:[deploy/run]:<destination path>
#		[ADAPTER/SERVICE/FILESHARE] --> Which all environment should this script go.
#		[deploy/run] --> If this file is changed what kind of action does it require in CICD process.
#		<destination path> --> Destination path  in the servers.

# Default path for script in the Servers
default:/appl/prcsrvce/usr/local/scripts

# Active version that are LIVE
ps_active_version:v3

# Infra configuration scripts
02-supervisord.conf:ADAPTER:run:/appl/prcsrvce/tmp
03-supervisord.conf:SERVICE:run:/appl/prcsrvce/tmp
nginx-supervisord.conf:SERVICE:run:/appl/prcsrvce/etc/supervisor-fragments
nginx_profile:SERVICE:run:/appl/prcsrvce
nginx.conf.template:SERVICE:run:/appl/prcsrvce/etc/nginx
ps_directory_create.sh:ADAPTER SERVICE FILESHARE:deploy:/appl/prcsrvce/install

ps_apmprobing.sh:ADAPTER SERVICE:deploy:/appl/prcsrvce/usr/local/scripts
ps_apmprobing_all.sh:ADAPTER:deploy:/appl/prcsrvce/usr/local/scripts

# PS scripts
profile:ADAPTER SERVICE:run:/appl/prcsrvce
clearance_config.sh:ADAPTER FILESHARE:deploy:/appl/prcsrvce/usr/local/scripts
config.sh:ADAPTER SERVICE FILESHARE:deploy:/appl/prcsrvce/usr/local/scripts
config_purge.sh:ADAPTER SERVICE FILESHARE:deploy:/appl/prcsrvce/usr/local/scripts
ps_archive_purge.sh:ADAPTER SERVICE FILESHARE:deploy:/appl/prcsrvce/usr/local/scripts
ps_archivepurge_all.sh:ADAPTER:deploy:/appl/prcsrvce/usr/local/scripts
ps_dataarchive.sh:ADAPTER FILESHARE:deploy:/appl/prcsrvce/usr/local/scripts
ps_dataarchive_all.sh:ADAPTER:deploy:/appl/prcsrvce/usr/local/scripts
ps_fileshare.sh:ADAPTER:deploy:/appl/prcsrvce/usr/local/scripts
ps_import.sh:ADAPTER:deploy:/appl/prcsrvce/usr/local/scripts
ps_importmmclearance.sh:ADAPTER:deploy:/appl/prcsrvce/usr/local/scripts
ps_importrpmclearance.sh:ADAPTER:deploy:/appl/prcsrvce/usr/local/scripts
ps_item_purge.sh:ADAPTER:deploy:/appl/prcsrvce/usr/local/scripts
ps_log_purge.sh:ADAPTER:deploy:/appl/prcsrvce/usr/local/scripts
ps_mm_clearancefileshare.sh:ADAPTER:deploy:/appl/prcsrvce/usr/local/scripts
ps_monitor.sh:ADAPTER:deploy:/appl/prcsrvce/usr/local/scripts
ps_nginx.sh:SERVICE:run:/appl/prcsrvce/usr/local/scripts
ps_nginxall.sh:ADAPTER:run:/appl/prcsrvce/usr/local/scripts
ps_restartall.sh:ADAPTER:run:/appl/prcsrvce/usr/local/scripts
ps_rpm_clearancefileshare.sh:ADAPTER:deploy:/appl/prcsrvce/usr/local/scripts
ps_start.sh:ADAPTER SERVICE:run:/appl/prcsrvce/usr/local/scripts
ps_stop.sh:ADAPTER SERVICE:run:/appl/prcsrvce/usr/local/scripts
ps_stopall.sh:ADAPTER:run:/appl/prcsrvce/usr/local/scripts
ps_supervisor.sh:ADAPTER SERVICE:run:/appl/prcsrvce/usr/local/scripts
purge_archive.sh:ADAPTER:deploy:/appl/prcsrvce/usr/local/scripts
ps_dataarchive_reject.sh:ADAPTER:deploy:/appl/prcsrvce/usr/local/scripts
ps_teauth_fileshare.sh:ADAPTER:deploy:/appl/prcsrvce/usr/local/scripts
ps_teauth_filevalidation.sh:FILESHARE:deploy:/appl/prcsrvce/usr/local/scripts
ps_teauth_archivefiles.sh:FILESHARE:deploy:/appl/prcsrvce/usr/local/scripts
ps_file_validator.sh:FILESHARE:deploy:/appl/prcsrvce/usr/local/scripts
ps_fileshare_generic.sh:ADAPTER:deploy:/appl/prcsrvce/usr/local/scripts
ps_wrapper.sh:ADAPTER:deploy:/appl/prcsrvce/usr/local/scripts
ps_filewatcher.sh:FILESHARE:deploy:/appl/prcsrvce/usr/local/scripts
ps_import_generic.sh:ADAPTER:deploy:/appl/prcsrvce/usr/local/scripts
ps_filewatcher_generic.sh:FILESHARE:deploy:/appl/prcsrvce/usr/local/scripts

#Event scripts
ps_eventpublish.sh:ADAPTER:deploy:/appl/prcsrvce/usr/local/scripts

#Performance Statistics scripts
ps_stats_all.sh:ADAPTER:deploy:/appl/prcsrvce/usr/local/scripts
ps_stats.awk:ADAPTER:deploy:/appl/prcsrvce/usr/local/scripts
ps_stats_percentile.sh:ADAPTER:deploy:/appl/prcsrvce/usr/local/scripts

#Client Statistics scripts
ps_stats_client_all.sh:ADAPTER:deploy:/appl/prcsrvce/usr/local/scripts
ps_stats_client.awk:ADAPTER:deploy:/appl/prcsrvce/usr/local/scripts
ps_clientlist.txt:ADAPTER:deploy:/appl/prcsrvce/usr/local/scripts

ps_teauth_data_integiry_child.sh:ADAPTER:deploy:/appl/prcsrvce/usr/local/scripts
ps_teauth_dataintegrity.sh:ADAPTER:deploy:/appl/prcsrvce/usr/local/scripts
ps_teauth_eanseed.sh:ADAPTER:deploy:/appl/prcsrvce/usr/local/scripts

# RPM Promotion onetime data dump
ps_onetime_promotion_fileshare.sh:ADAPTER:deploy:/appl/prcsrvce/usr/local/scripts
ps_import_onetime_promotion.sh:ADAPTER:deploy:/appl/prcsrvce/usr/local/scripts

# RPM Price onetime data dump
ps_onetime_price_fileshare.sh:ADAPTER:deploy:/appl/prcsrvce/usr/local/scripts
ps_import_onetime_price.sh:ADAPTER:deploy:/appl/prcsrvce/usr/local/scripts
ps_import_onetime_price_child.sh:ADAPTER:deploy:/appl/prcsrvce/usr/local/scripts

# RPM Zone onetime data dump
ps_import_onetime_rpmzone.sh:ADAPTER:deploy:/appl/prcsrvce/usr/local/scripts
ps_onetime_rpmzone_fileshare.sh:ADAPTER:deploy:/appl/prcsrvce/usr/local/scripts
ps_onetime_rpmzone_filevalidation.sh:FILESHARE:deploy:/appl/prcsrvce/usr/local/scripts
ps_onetime_rpmzone_archivefiles.sh:FILESHARE:deploy:/appl/prcsrvce/usr/local/scripts

# Reg deployment scripts
ps_deploy_reg.sh:ADAPTER:deploy:/appl/prcsrvce/usr/local/scripts
ps_stop_reg.sh:ADAPTER SERVICE:deploy:/appl/prcsrvce/usr/local/scripts
ps_start_reg.sh:ADAPTER SERVICE:deploy:/appl/prcsrvce/usr/local/scripts

# Deployment scripts
ps_deploy_prcsrvce.sh:ADAPTER SERVICE:run:/appl/prcsrvce/install

# Security access model scripts..
ps_file_security.sh:ADAPTER SERVICE FILESHARE:deploy:/appl/prcsrvce/install
ps_file_security_rollback.sh:ADAPTER SERVICE FILESHARE:deploy:/appl/prcsrvce/install

#View Creation Scripts
ps_view_create.sh:ADAPTER:deploy:/appl/prcsrvce/install
CreateTpnMappingView.ddoc:ADAPTER:deploy:/appl/prcsrvce/install

#idl_details:idl_status
priceservice-price-1_0_0.idl:Deprecated
priceservice-price-2_0_0.idl:Obsolete
priceservice-price-2_0_1.idl:Obsolete
priceservice-price-2_0_2.idl:Deprecated
priceservice-price-2_0_3.idl:Obsolete
priceservice-price-3_0_0.idl:Contained
priceservice-priceevents-3_0_0.idl:Draft
priceservice-promotions-2_0_0.idl:Obsolete

# Deployment Priority 
# <run> : which includes deploying the scripts to respective servers and restarting the Services.
# <deploy> : only deploy the changed scripts to the respective servers.
run:1
deploy:2

#Status of APM probing.[ON-then APM will  be switched on]
ADAPTER_APM_STATUS:ON
SERVICE_APM_STATUS:ON
