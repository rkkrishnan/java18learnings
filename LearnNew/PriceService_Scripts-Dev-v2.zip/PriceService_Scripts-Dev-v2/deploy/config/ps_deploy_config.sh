#!/bin/bash

# Added the below overrides for java 1.8 upgrade. 
# This can be removed once we have a dedicated environment for PriceService.
export JAVA_HOME=/appl/usr/java/jdk1.8.0_91
export PATH=$JAVA_HOME/bin:$PATH

export GRADLE_HOME=/appl/usr/local/lib/gradle-2.2
export PATH=$GRADLE_HOME/bin:$PATH

# Price Service user
PS_USER=prcsrvce
PS_HOME=/appl/prcsrvce

# Tapi Credentials 
USERNAME=05_HSC_TeamBrass@in.tesco.com
PASSWORD=PriceService123
TAPIURL=https://tapi.azurewebsites.net/idl/upload
HOSTNAME_IDL_TAPI=172.25.66.1
HOSTNAME_IDL_TAPI_PORT=8080
LOG_PATH=/appl/var/lib/jenkins/workspace/PriceService_Logs

JENKIN_BUILD_DIR_ADAPTER="/appl/var/lib/jenkins/workspace/PriceService_Adapter_Build"
JENKIN_BUILD_DIR_SERVICE="/appl/var/lib/jenkins/workspace/PriceService_Service_Build"
JENKIN_BUILD_DIR_SCRIPTS="/appl/var/lib/jenkins/workspace/PriceService_Scripts_Build"

# Hostnames of the DEV, PPE, PROD and PROD_DR servers
DEV_ADAPTER=(dvprcadptr001uk.dev.global.tesco.org)
DEV_SERVICE=(dvprcsrvce001uk.dev.global.tesco.org)
DEV_FILESHARE=(dvprcfserv001uk.dev.global.tesco.org)

PPE_ADAPTER=(ppeprcadptr001uk.globalppe.tesco.org)
PPE_SERVICE=(ppeprcsrvce001uk.globalppe.tesco.org ppeprcsrvce002uk.globalppe.tesco.org ppeprcsrvce003uk.globalppe.tesco.org)
PPE_FILESHARE=(ppeprcfserv001uk.globalppe.tesco.org)

PROD_ADAPTER=(pvprcadptr001uk.global.tesco.org)
PROD_SERVICE=(pvprcsrvce001uk.global.tesco.org pvprcsrvce002uk.global.tesco.org pvprcsrvce003uk.global.tesco.org)
PROD_FILESHARE=(pvprcfserv001uk.global.tesco.org)

PROD_DR_ADAPTER=(pvprcadptr002uk.global.tesco.org)
PROD_DR_SERVICE=(pvprcsrvce004uk.global.tesco.org pvprcsrvce005uk.global.tesco.org pvprcsrvce006uk.global.tesco.org)
PROD_DR_FILESHARE=(pvprcfserv002uk.global.tesco.org)
