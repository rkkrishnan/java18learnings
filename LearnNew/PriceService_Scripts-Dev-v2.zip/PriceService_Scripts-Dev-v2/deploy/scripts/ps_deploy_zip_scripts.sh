#!/bin/bash

set -x

STAMP=`date +"%Y%m%d"`
PROG_NAME=$(basename $0 .sh)

if [ "$#" -ne "3" ]
then
	echo "$(date '+%Y-%m-%d %T') : ERROR : Expecting the parameter, Param1-[DEV/PPE/PROD]  Param2-[VERSION] & Param3-[ADAPTER/SERVICE/FILESHARE]...."
	exit 1
fi

BRANCH=$1
VERSION=$2

# Sourcing the config file
. /appl/var/lib/jenkins/workspace/PriceService_Scripts_Build/${BRANCH}-v2/deploy/config/ps_deploy_config.sh
RC=$?
if [[ "$RC" -ne "0" ]]; then
   echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Failed to source ps_deploy_config.sh script. Please check..!!"
   exit 1
fi


PSENV_TYPE=$(echo $3 | tr [[a-z]] [[A-Z]])

if [[ "$PSENV_TYPE" != "ADAPTER" && "$PSENV_TYPE" != "SERVICE" && "$PSENV_TYPE" != "FILESHARE" ]];
then
	echo "$(date '+%Y-%m-%d %T') : Invalid parameter.. Param3 should be [ADAPTER/SERVICE/FILESHARE]... Please check again!!"
	exit 1
fi


WORK_DIR_ADAPTER=$JENKIN_BUILD_DIR_ADAPTER/${BRANCH}-${VERSION}
WORK_DIR_SERVICE=$JENKIN_BUILD_DIR_SERVICE/${BRANCH}-${VERSION}
WORK_DIR_SCRIPTS=$JENKIN_BUILD_DIR_SCRIPTS/${BRANCH}-v2

BRANCH_UPPER=$(echo $BRANCH | tr [[a-z]] [[A-Z]])
DEPLOY_JOB=""

deploy_script=$WORK_DIR_SCRIPTS/deploy/scripts/ps_deploy_restart.sh
deploy_tapiscript=$WORK_DIR_SCRIPTS/deploy/scripts/ps_tapi.sh
MONITOR_SCRIPT="$PS_HOME/usr/local/scripts/ps_monitor.sh"

deploy_idl="$WORK_DIR_SCRIPTS/idl_to_deploy"
LOG_FILE=$LOG_PATH/$JOB_NAME/${PROG_NAME}_log_${BUILD_NUMBER}_${STAMP}.log

# Forming the hostname to substitute the value
HOSTNAME=${BRANCH_UPPER}_${PSENV_TYPE}[@]
DR_HOSTNAME=""

if [[ "$BRANCH_UPPER" == "PROD" ]]; 
then
	DR_HOSTNAME=${BRANCH_UPPER}_DR_${PSENV_TYPE}[@]
fi

if [[ ! -d $WORK_DIR_SCRIPTS ]];
then
	echo "$(date '+%Y-%m-%d %T') : Invalid directory $WORK_DIR_SCRIPTS... Please check again!!" | tee -a $LOG_FILE
	exit 1
fi


echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME started by $USER" | tee -a $LOG_FILE

if [[ "$PSENV_TYPE" == "ADAPTER" && -f $WORK_DIR_ADAPTER/deploy.zip.adapter ]]
then
	DEPLOY_JOB=run
	echo "$(date '+%Y-%m-%d %T') : Copying the zip to Adapter server.." | tee -a $LOG_FILE
	for hname in ${!HOSTNAME}
	do
		scp_result=$(scp -v $WORK_DIR_ADAPTER/build/distributions/*.zip $PS_USER@$hname:$PS_HOME/tmp 2>&1 | tail -1 | awk '{print $4}'|tr -d '\r')
		if [ "$scp_result" -ne "0" ]
		then
			echo "$(date '+%Y-%m-%d %T') : Failed to transfer zip to Adapter server.. Hostname:<$hname>" | tee -a $LOG_FILE
			exit 1
		else
			echo "$(date '+%Y-%m-%d %T') : Zip file sent successful Adapter server.. Hostname:<$hname>" | tee -a $LOG_FILE
		fi
	done

	# Operations on DR Server
	if [[ ! -z $DR_HOSTNAME ]]; 
	then
		for hname in ${!DR_HOSTNAME}
		do
			scp_result=$(scp -v $WORK_DIR_ADAPTER/build/distributions/*.zip $PS_USER@$hname:$PS_HOME/tmp 2>&1 | tail -1 | awk '{print $4}'|tr -d '\r')
			if [ "$scp_result" -ne "0" ]
			then
				echo "$(date '+%Y-%m-%d %T') : Failed to transfer zip to DR Adapter server.. Hostname:<$hname>" | tee -a $LOG_FILE
				exit 1
			else
				echo "$(date '+%Y-%m-%d %T') : Zip file sent successful DR Adapter server.. Hostname:<$hname>" | tee -a $LOG_FILE
			fi
		done
	fi

	rm -f $WORK_DIR_ADAPTER/deploy.zip.adapter
	echo "$(date '+%Y-%m-%d %T') : Successfully copied zip to Adapter server.. Hostname:<$hname>" | tee -a $LOG_FILE
	
elif [[ "$PSENV_TYPE" == "SERVICE" && -f $WORK_DIR_SERVICE/deploy.zip.service ]]
then
	DEPLOY_JOB=run
	echo "$(date '+%Y-%m-%d %T') : Copying the zip to Service server.. Hostname:<$hname>" | tee -a $LOG_FILE
	for hname in ${!HOSTNAME}
	do
		scp_result=$(scp -v $WORK_DIR_SERVICE/build/distributions/*.zip $PS_USER@$hname:$PS_HOME/tmp 2>&1 | tail -1 | awk '{print $4}'|tr -d '\r')
		if [ "$scp_result" -ne "0" ]
		then
			echo "$(date '+%Y-%m-%d %T') : Failed to transfer zip to Service server.. Hostname:<$hname>" | tee -a $LOG_FILE
			exit 3
		else
			echo "$(date '+%Y-%m-%d %T') : Zip file sent successful Service server.. Hostname:<$hname>" | tee -a $LOG_FILE
		fi
	done

	# Operations on DR Server
	if [[ ! -z $DR_HOSTNAME ]]; 
	then
		for hname in ${!DR_HOSTNAME}
		do
			scp_result=$(scp -v $WORK_DIR_SERVICE/build/distributions/*.zip $PS_USER@$hname:$PS_HOME/tmp 2>&1 | tail -1 | awk '{print $4}'|tr -d '\r')
			if [ "$scp_result" -ne "0" ]
			then
				echo "$(date '+%Y-%m-%d %T') : Failed to transfer zip to DR Service server.. Hostname:<$hname>" | tee -a $LOG_FILE
				exit 3
			else
				echo "$(date '+%Y-%m-%d %T') : Zip file sent successful DR Service server.. Hostname:<$hname>" | tee -a $LOG_FILE
			fi
		done
	fi

	rm -f $WORK_DIR_SERVICE/deploy.zip.service
	echo "$(date '+%Y-%m-%d %T') : Successfully copied zip to Service server.. Hostname:<$hname>" | tee -a $LOG_FILE
	
else
	echo "$(date '+%Y-%m-%d %T') : No zip file found in Adapter/Service.." | tee -a $LOG_FILE
fi

if [[ -f $WORK_DIR_SCRIPTS/deploy.shell_script ]]
then
	changed_scripts=($(ls -ltr $WORK_DIR_SCRIPTS/scripts_to_deploy | tr -s ' '|cut -d " " -f 9))
	
	echo "$(date '+%Y-%m-%d %T') : Started copying the scripts..." | tee -a $LOG_FILE
	
	for script_name in ${changed_scripts[@]}
	do
		grep_res=$(grep -w $script_name $WORK_DIR_SCRIPTS/deploy/config/ps_manifest.sh)
		RC=$?
		
		if [ "$?" -ne "0" ]
		then
			echo "$(date '+%Y-%m-%d %T') : The script $script_name is not present in Manifest file... Please check again !!" | tee -a $LOG_FILE
			exit 1
		fi
		
		dest_server_name=($(echo $grep_res | cut -d ":" -f 2))
		dest_job_type=$(echo $grep_res | cut -d ":" -f 3)
		dest_path=$(echo $grep_res | cut -d ":" -f 4)
		
		if [ "$dest_job_type" == "run" ]
		then
			DEPLOY_JOB=run
		fi

		for server_types in ${dest_server_name[@]}
		do
			if [ "$server_types" == "$PSENV_TYPE" ]
			then
				for host_name in ${!HOSTNAME}
				do
					scp_result=$(scp -v $WORK_DIR_SCRIPTS/scripts_to_deploy/$script_name $PS_USER@$host_name:$dest_path 2>&1 | tail -1 | awk '{print $4}'|tr -d '\r')
					echo "$(date '+%Y-%m-%d %T') : Changing the permission of $dest_path/$script_name in Server : <$PS_USER@$host_name>" | tee -a $LOG_FILE
					ssh $PS_USER@$host_name "chmod -R 755 $dest_path/$script_name"
					if [ "$scp_result" -ne "0" ]
					then
						echo "$(date '+%Y-%m-%d %T') : Failed to transfer script $script_name to $PSENV_TYPE server.. Hostname:<$host_name>" | tee -a $LOG_FILE
						exit 1
					else
						echo "$(date '+%Y-%m-%d %T') : Script $script_name sent successful to $PSENV_TYPE server.. Hostname:<$host_name>" | tee -a $LOG_FILE
					fi
				done

				# Operations on DR Server
				if [[ ! -z $DR_HOSTNAME ]]; 
				then
					for host_name in ${!DR_HOSTNAME}
					do
						scp_result=$(scp -v $WORK_DIR_SCRIPTS/scripts_to_deploy/$script_name $PS_USER@$host_name:$dest_path 2>&1 | tail -1 | awk '{print $4}'|tr -d '\r')
						echo "$(date '+%Y-%m-%d %T') : Changing the permission of $dest_path/$script_name in Server : <$PS_USER@$host_name>" | tee -a $LOG_FILE
						ssh $PS_USER@$host_name "chmod -R 755 $dest_path/$script_name"
						if [ "$scp_result" -ne "0" ]
						then
							echo "$(date '+%Y-%m-%d %T') : Failed to transfer script $script_name to DR $PSENV_TYPE server.. Hostname:<$host_name>" | tee -a $LOG_FILE
							exit 1
						else
							echo "$(date '+%Y-%m-%d %T') : Script $script_name sent successful to DR $PSENV_TYPE server.. Hostname:<$host_name>" | tee -a $LOG_FILE
						fi
					done
				fi
			fi
		done
	done
	
	echo "$(date '+%Y-%m-%d %T') : Copied all the scripts successful!!" | tee -a $LOG_FILE
fi

# Copying the 02-supervisord.conf and 03-supervisord.conf for Deployment process
if [[ "$PSENV_TYPE" == "ADAPTER" ]]
then
	for host_name in ${!HOSTNAME}
	do
		scp_result=$(scp -v $WORK_DIR_SCRIPTS/Infra/config/02-supervisord.conf $PS_USER@$host_name:/appl/prcsrvce/tmp 2>&1 | tail -1 | awk '{print $4}'|tr -d '\r')
		if [ "$scp_result" -ne "0" ]
		then
			echo "$(date '+%Y-%m-%d %T') : Failed to transfer 02-supervisord.conf to $PSENV_TYPE server.. Hostname:<$host_name>" | tee -a $LOG_FILE
			exit 1
		else
			echo "$(date '+%Y-%m-%d %T') : 02-supervisord.conf sent successful to $PSENV_TYPE server.. Hostname:<$host_name>" | tee -a $LOG_FILE
		fi
	done

	if [[ ! -z $DR_HOSTNAME ]]; 
	then
		for host_name in ${!DR_HOSTNAME}
		do
			scp_result=$(scp -v $WORK_DIR_SCRIPTS/Infra/config/02-supervisord.conf $PS_USER@$host_name:/appl/prcsrvce/tmp 2>&1 | tail -1 | awk '{print $4}'|tr -d '\r')
			if [ "$scp_result" -ne "0" ]
			then
				echo "$(date '+%Y-%m-%d %T') : Failed to transfer 02-supervisord.conf to DR $PSENV_TYPE server.. Hostname:<$host_name>" | tee -a $LOG_FILE
				exit 1
			else
				echo "$(date '+%Y-%m-%d %T') : 02-supervisord.conf sent successful to DR $PSENV_TYPE server.. Hostname:<$host_name>" | tee -a $LOG_FILE
			fi
		done
	fi

elif [[ "$PSENV_TYPE" == "SERVICE" ]]
then
	for host_name in ${!HOSTNAME}
	do
		scp_result=$(scp -v $WORK_DIR_SCRIPTS/Infra/config/03-supervisord.conf $WORK_DIR_SCRIPTS/deploy/config/ps_manifest.sh $PS_USER@$host_name:/appl/prcsrvce/tmp 2>&1 | tail -1 | awk '{print $4}'|tr -d '\r')
		if [ "$scp_result" -ne "0" ]
		then
			echo "$(date '+%Y-%m-%d %T') : Failed to transfer 03-supervisord.conf & ps_manifest.sh to $PSENV_TYPE server.. Hostname:<$host_name>" | tee -a $LOG_FILE
			exit 1
		else
			echo "$(date '+%Y-%m-%d %T') : 03-supervisord.conf & ps_manifest.sh sent successful to $PSENV_TYPE server.. Hostname:<$host_name>" | tee -a $LOG_FILE
		fi
	done

	if [[ ! -z $DR_HOSTNAME ]]; 
	then
		for host_name in ${!DR_HOSTNAME}
		do
			scp_result=$(scp -v $WORK_DIR_SCRIPTS/Infra/config/03-supervisord.conf $WORK_DIR_SCRIPTS/deploy/config/ps_manifest.sh $PS_USER@$host_name:/appl/prcsrvce/tmp 2>&1 | tail -1 | awk '{print $4}'|tr -d '\r')
			if [ "$scp_result" -ne "0" ]
			then
				echo "$(date '+%Y-%m-%d %T') : Failed to transfer 03-supervisord.conf & ps_manifest.sh to DR $PSENV_TYPE server.. Hostname:<$host_name>" | tee -a $LOG_FILE
				exit 1
			else
				echo "$(date '+%Y-%m-%d %T') : 03-supervisord.conf & ps_manifest.sh sent successful to DR $PSENV_TYPE server.. Hostname:<$host_name>" | tee -a $LOG_FILE
			fi
		done
	fi
fi

echo "$(date '+%Y-%m-%d %T') : Starting the deployment process.." | tee -a $LOG_FILE

if [[ "$DEPLOY_JOB" == "run" && "$PSENV_TYPE" != "FILESHARE" ]]
then
	chmod 755 $deploy_script
	$deploy_script "$BRANCH" "$VERSION" "$PSENV_TYPE"
	if [ "$?" -ne "0" ]
	then
		echo "$(date '+%Y-%m-%d %T') : Failed to call $deploy_script script... Please check !!" | tee -a $LOG_FILE
		exit 1
	fi
else
	echo "$(date '+%Y-%m-%d %T') : Deployment process not required for this build..." | tee -a $LOG_FILE
fi
echo "$(date '+%Y-%m-%d %T') : Deployment process completed..." | tee -a $LOG_FILE

############################################################################################
########################## IDL UPLOAD TO TAPI SITE STARTED #################################
############################################################################################

echo "$(date '+%Y-%m-%d %T') : Starting the idl upload to tapi process.." | tee -a $LOG_FILE
countidl=0;
if [[ -d "$deploy_idl" ]];
then
   countidl=`find $deploy_idl  -type f |wc -l`
fi

if [[ "$PSENV_TYPE" = "SERVICE" && "$countidl" -gt 0 ]];

then
        chmod 755 $deploy_tapiscript
        $deploy_tapiscript "$BRANCH" "$VERSION" 
        RC=$?
        if [ "$RC" -ne "0" ];
        then
			echo "$(date '+%Y-%m-%d %T') : Failed to call $deploy_tapiscript script... Please check !!" | tee -a $LOG_FILE
            exit 1
        fi
		
else
        echo "$(date '+%Y-%m-%d %T') : idl upload to tapi  process not required for this build..." | tee -a $LOG_FILE
fi
echo "$(date '+%Y-%m-%d %T') : idl upload to tapi process completed..." | tee -a $LOG_FILE

############################################################################################
########################## IDL UPLOAD TO TAPI SITE COMPLETED ###############################
############################################################################################


############################################################
############## Running Monitor Script Start ################
############################################################

call_monitor()
{
	local host_name=$1
	
	echo "$(date '+%Y-%m-%d %T') : Calling $MONITOR_SCRIPT script in $host_name server..." | tee -a $LOG_FILE
	ssh ${PS_USER}@${host_name} "$MONITOR_SCRIPT ALL"
	RC=$?
	if [[ "$RC" -ne "0" ]] ;
	then
		echo "$(date '+%Y-%m-%d %T') : $MONITOR_SCRIPT script did not execute successfully in $host_name server" | tee -a $LOG_FILE
		echo "$(date '+%Y-%m-%d %T') : Please check !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" | tee -a $LOG_FILE
		exit 1
	else
		echo "$(date '+%Y-%m-%d %T') : $MONITOR_SCRIPT script executed successfully in $host_name server" | tee -a $LOG_FILE
	fi
}

if [[ "$PSENV_TYPE" != "FILESHARE" ]];
then
	if [[ "$BRANCH_UPPER" == "DEV" ]];
	then
		call_monitor $DEV_ADAPTER
	elif [[ "$BRANCH_UPPER" == "PPE" ]];
	then
		call_monitor $PPE_ADAPTER
	elif [[ "$BRANCH_UPPER" == "PROD" ]];
	then
		call_monitor $PROD_ADAPTER
	else
		echo "$(date '+%Y-%m-%d %T') : Invalid parameter $BRANCH_UPPER... Please check!!!" | tee -a $LOG_FILE
		exit 1
	fi
fi

############################################################
############ Running Monitor Script Completed ##############
############################################################


echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME completed by $USER" | tee -a $LOG_FILE
exit $?
