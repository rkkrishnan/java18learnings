#!/bin/bash
. $HOME/.bash_profile
PSHOME=/appl/prcsrvce
. $PSHOME/profile

# Sourcing the config file
. $PSHOME/usr/local/scripts/config.sh
RC=$?
if [[ "$RC" -ne "0" ]]; then
   echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Failed to source config.sh script. Please check..!!"
   exit 1
fi

if [ "$#" -ne "2" ]; then
	echo "$(date '+%Y-%m-%d %T') : ERROR : Input param [Dev/PPE] [DEPLOY/REGRESSION]"
	exit 1
fi

#set -x

STAMP=`date +"%Y%m%d"`
PROG_NAME=$(basename $0 .sh)
REG_PATH=$PSHOME/regression

ENV=$1
RUN_PARAM=$2

LOG_FILE=$LOG_PATH/${PROG_NAME}_log_${STAMP}.log
ERR_FILE=$ERROR_PATH/${PROG_NAME}_err_${STAMP}.log
if [[ ! -d "$LOG_PATH" ]];
then
      echo "Log path is not set. Please set the LOG_PATH."
      exit 1
fi

if [[ ! -d  "$ERROR_PATH" ]];
then
      echo "Error path is not set. Please set the ERROR_PATH."
      exit 1
fi


echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME started by $USER" | tee -a  $LOG_FILE

if [[ "$RUN_PARAM" == "DEPLOY" ]];then

# Unzipping the regression jar and running the jar with <>.yml
artifact_file_loc=`ls -ltr $REG_PATH/temp_deploy/*.zip|tail -1|awk '{print $9}'`
artifact=`basename ${artifact_file_loc}`
jenkins_ver=`echo ${artifact}|cut -d. -f1|cut -d- -f3`

echo $jenkins_ver > $REG_PATH/versions/latest_version

# Remove the old build if exist..
rm -rf $REG_PATH/versions/$jenkins_ver/

# Create Dir for regression jars
mkdir -p $REG_PATH/versions/$jenkins_ver

unzip -q $REG_PATH/temp_deploy/ps-regression-*.zip -d $REG_PATH/versions/$jenkins_ver
RC=$?
if [[ "$RC" -ne "0" ]] ; 
then  
	echo "Unable to unzip.. Please check again..." | tee -a  $LOG_FILE
	exit 1
fi

# Delete the zip file after unzipping...
rm -f $REG_PATH/temp_deploy/*.zip

elif [[ "$RUN_PARAM" == "REGRESSION" ]];then
#Run curl command to run the regression.

	status=$(curl -X GET --max-time 3600 -s -o ${REG_PATH}/logs/curl_reg_output_initial -w "%{http_code}" http://${ADAPTER_HOST}:${REG_PORT}/reg/run)

	if [ "$status" == "000" ];
	then
		echo "Curl command to invoke regression tests failed due to connectivity issue...please check if regression is running in the servers.. "
		echo "curl exited with status code : $status"
		exit 1
	elif [ "$status" == "200" ];
	then
		echo "${REG_PATH}/logs/curl_reg_output_initial"
		#Check if regression is complete...!!!!
		while [ true ];
		do
			status=$(curl -X GET --max-time 3600 -s -o ${REG_PATH}/logs/curl_reg_output -w "%{http_code}" http://${ADAPTER_HOST}:${REG_PORT}/reg/regressionInProgress)
			if [[ "$status" == "610" ]];then
			   echo "${REG_PATH}/logs/curl_reg_output"
			   sleep 20
			
			elif [[ "$status" == "600" ]];then
			   break;   
			   	
			fi
		done
    	echo "The test results are << ${REG_PATH}/logs/curl_reg_output >>"
	else
		echo "Regressionn test failed... !!!!!"
    	echo "curl exited with status code : $status"
    	exit 1
	fi


fi
echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME completed successfully" | tee -a $LOG_FILE
exit $?