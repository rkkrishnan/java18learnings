#!/bin/bash

set -x

STAMP=`date +"%Y%m%d"`
PROG_NAME=$(basename $0 .sh)

if [ "$#" -ne "4" ]; then
         echo "$(date '+%Y-%m-%d %T') : ERROR: Please specify the file_param as [Dev/PPE/Prod] [v2] [force {will forcefully build even if no changes.}]"
         exit 1
fi


BRANCH=$1
VERSION=$2
SERVER=$(echo $3 | tr -s [[A-Z]] [[a-z]] );
force_build=$(echo $4 | tr -s [[A-Z]] [[a-z]] );
#Sourcing the config files
. /appl/var/lib/jenkins/workspace/PriceService_Scripts_Build/${BRANCH}-v2/deploy/config/ps_deploy_config.sh

RC=$?
if [[ "$RC" -ne "0" ]]; then
   echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Failed to source ps_deploy_config.sh script. Please check..!!"
   exit 1
fi

LOG_FILE=$LOG_PATH/$JOB_NAME/${PROG_NAME}_log_${BUILD_NUMBER}_${STAMP}.log

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME started by $USER" 

#Removing the files that are used temporarily by the deployment process

if [[ "$SERVER" == "adapter" ]]; then
   JENKIN_BUILD_DIR=$JENKIN_BUILD_DIR_ADAPTER

   WORK_DIR=$JENKIN_BUILD_DIR/${BRANCH}-${VERSION}
   #Clean up
   rm -f $WORK_DIR/deploy.zip.adapter
   changed_list=`find $WORK_DIR -not \( -path "*/build" -prune \)  -mmin -15 | cut -f9 -d'/' |sort -u`

   if [[ ! -z "$changed_list" || "$force_build" == "force" ]]; then
     chmod 755 ${WORK_DIR}/ci
   	  #executing CI build script.
     cd ${WORK_DIR}
     ${WORK_DIR}/ci

     RC=$?

	  if [[ "$RC" -ne "0" ]]; then
	     echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Failed to run the script ci to build." | tee -a $LOG_FILE
	     exit 1
	  fi

	  touch "$WORK_DIR/deploy.zip.adapter"

   else
      echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME..No new changes to build.." | tee -a $LOG_FILE
   fi

elif [[ "$SERVER" == "service" ]]; then
   JENKIN_BUILD_DIR=$JENKIN_BUILD_DIR_SERVICE
   WORK_DIR=$JENKIN_BUILD_DIR/${BRANCH}-${VERSION}

   rm -f $WORK_DIR/deploy.zip.service
   changed_list=`find $WORK_DIR -not \( -path "*/build" -prune \)  -mmin -15 | cut -f9 -d'/' |sort -u`

   if [[ ! -z "$changed_list" || "$force_build" == "force" ]]; then
   chmod 755 ${WORK_DIR}/ci
   #executing CI build script.
   cd ${WORK_DIR}
   ${WORK_DIR}/ci
   RC=$?

	  if [[ "$RC" -ne "0" ]]; then
	     echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Failed to run the script ci to build." | tee -a $LOG_FILE
	     exit 1
	  fi

	  touch "$WORK_DIR/deploy.zip.service"
     else
      echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME..No new changes to build.." | tee -a $LOG_FILE
   fi

elif [[ "$SERVER" == "scripts" ]];then

   echo "############################ Building scripts to be deployed ###############################"

   JENKIN_BUILD_DIR=$JENKIN_BUILD_DIR_SCRIPTS
   WORK_DIR=$JENKIN_BUILD_DIR/${BRANCH}-${VERSION}
   
   #Clean up
   rm -f $WORK_DIR/deploy.shell_script
   rm -rf $WORK_DIR/scripts_to_deploy

   deploy_shell_dir="${WORK_DIR}/scripts_to_deploy"
   mkdir -p $deploy_shell_dir
   changed_list=`find $WORK_DIR -not \( -path "*/.git" -prune \) -mmin -15 | cut -f9 -d'/' |sort -u`
   for i in $changed_list; do
      if [[ "$i" == "scripts" || "$i" == "deploy" || "$i" == "Infra" ]]; 
      then
   
         scripts_changed=`find ${WORK_DIR}/${i}  -type f -mmin -15`
	  	
         if [ ! -z "$scripts_changed" ]
         then
     
            echo ${scripts_changed} |while read ff
            do
               echo "Copying file $ff to $deploy_shell_dir" | tee -a $LOG_FILE
               cp $ff $deploy_shell_dir
            done
            touch "$WORK_DIR/deploy.shell_script"
         else
            echo "No ${i} scripts to be  deployed" | tee -a $LOG_FILE
         fi

      elif [[ "$i" == "idl" ]]; then
         deploy_idl="${WORK_DIR}/idl_to_deploy"

         #Clean up
         rm -rf $WORK_DIR/idl_to_deploy/
         idl_changed=`find ${WORK_DIR}/${i}  -type f -mmin -15`
         
         if [ ! -z "$idl_changed" ];
         then
            mkdir -p $deploy_idl      

            echo $idl_changed|while read ffile
            do
               echo "Copying changed idlfile $ffile to $deploy_idl" | tee -a $LOG_FILE
               cp $ffile $deploy_idl
      
               RC=$?
               if [ "$RC" -ne "0" ];
               then
                  echo "$(date '+%Y-%m-%d %T') : Failed to copy  $ffile to $deploy_idl... Please check !!" | tee -a $LOG_FILE
                  exit 1
               fi 

            done

         else
            echo "No changed idl files " | tee -a $LOG_FILE
         fi

      fi
   done

else
	echo "$(date '+%Y-%m-%d %T') : ERROR : 3rd Parameter passed is wrong..!!!" | tee -a $LOG_FILE
   exit 1
fi

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME completed successfully" | tee -a $LOG_FILE
exit $?
