#!/bin/bash
. $HOME/.bash_profile
PSHOME=/appl/prcsrvce
. $PSHOME/profile

# Sourcing the config file
. $PSHOME/usr/local/scripts/config.sh
RC=$?
if [[ "$RC" -ne "0" ]]; then
   echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Failed to source config.sh script. Please check..!!"
   exit 1
fi

if [ "$#" -ne "1" ]; then
   echo "$(date '+%Y-%m-%d %T') : ERROR : Input param [ADAPTER/SERVICE]"
   exit 1
fi

#set -x
cd $PSHOME/regression/logs

STAMP=`date +"%Y%m%d"`
PROG_NAME=$(basename $0 .sh)
REG_PATH=$PSHOME/regression
ENV=$1

LOG_FILE=$LOG_PATH/${PROG_NAME}_log_${STAMP}.log

if [[ ! -d "$LOG_PATH" ]];
then
	echo "Log path is not set. Please set the LOG_PATH."
	exit 1
fi

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME started by $USER for $ENV environment.. Hostname is <`hostname`>" | tee -a  $LOG_FILE

if [[ "$ENV" == "ADAPTER" ]]; then
   
   #reg_pid=$(cat $REG_PATH/versions/reg_pid)
   if [[ -f $REG_PATH/versions/reg_pid ]]; then
	  reg_pid=$(cat $REG_PATH/versions/reg_pid)
	  kill -9 $reg_pid
      RC=$?
      if [[ "$RC" -ne "0" ]]; then
         echo "$(date '+%Y-%m-%d %T') : Unable to kill program with PID : $reg_pid " | tee -a  $LOG_FILE
         exit 1;
      fi
	  rm -f $REG_PATH/versions/reg_pid
   else
      echo "$(date '+%Y-%m-%d %T') : Regression PID not present..!!!!! Hence Regression may not be running..!!" | tee -a  $LOG_FILE
   fi
   
   #adp_pid=$(cat $REG_PATH/versions/adp_pid)
   if [[ -f $REG_PATH/versions/adp_pid ]]; then
	  adp_pid=$(cat $REG_PATH/versions/adp_pid)
	  #killing Adapter instance
      kill -9 $adp_pid
      RC=$?
      if [[ "$RC" -ne "0" ]]; then
         echo "$(date '+%Y-%m-%d %T') : Unable to kill program with PID : $adp_pid " | tee -a  $LOG_FILE
         exit 1
	  fi
	  rm -f $REG_PATH/versions/adp_pid 
   else
      echo "$(date '+%Y-%m-%d %T') : PID  of adapter instance is not present..!!!!! Hence adapter instance in regression mode may not be running..!!" | tee -a  $LOG_FILE
   fi
   
elif [[ "$ENV" == "SERVICE" ]]; then
   
   #srvc_pid=$(cat $REG_PATH/versions/srvc_pid)
   if [[ -f $REG_PATH/versions/srvc_pid ]]; then
	  srvc_pid=$(cat $REG_PATH/versions/srvc_pid)
	  #killing service instance
      kill -9 $srvc_pid
      RC=$?
      if [[ "$RC" -ne "0" ]]; then
         echo "$(date '+%Y-%m-%d %T') : Unable to kill program with PID : $srvc_pid " | tee -a  $LOG_FILE
         exit 1
      fi
	  rm -f $REG_PATH/versions/srvc_pid
   else
	  echo "$(date '+%Y-%m-%d %T') : PID  of service instance is not present..!!!!! Hence service instance in regression mode may not be running..!!" | tee -a  $LOG_FILE
   fi
fi

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME completed successfully for $ENV environment.. Hostname is <`hostname`>..." | tee -a  $LOG_FILE
exit $?