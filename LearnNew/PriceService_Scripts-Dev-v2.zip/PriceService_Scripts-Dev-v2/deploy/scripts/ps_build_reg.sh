#!/bin/bash

STAMP=`date +"%Y%m%d"`
PROG_NAME=$(basename $0 .sh)
ENVIRONMENT=$1
RUN_PARAM=$2

#Sourcing the config files
. /appl/var/lib/jenkins/workspace/PriceService_Scripts_Build/${ENVIRONMENT}-v2/deploy/config/ps_deploy_config.sh
RC=$?
if [[ "$RC" -ne "0" ]]; then
   echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Failed to source ps_deploy_config.sh script. Please check..!!"
   exit 1
fi

LOG_FILE=$LOG_PATH/$JOB_NAME/${PROG_NAME}_log_${BUILD_NUMBER}_${STAMP}.log

REG_DIR=/appl/var/lib/jenkins/workspace/PriceService_Regression_Build/Reg-Dev-v3
USER=prcsrvce

DEV_ENV=$DEV_ADAPTER
PPE_ENV=$PPE_ADAPTER

DEST_PATH=$PS_HOME/regression/temp_deploy
DEST_SCRIPT_PATH=$PS_HOME/usr/local/scripts/ps_deploy_reg.sh
DEST_STOP_PATH=$PS_HOME/usr/local/scripts/ps_stop_reg.sh
DEST_START_PATH=$PS_HOME/usr/local/scripts/ps_start_reg.sh

BUILD_ENV=$(echo $ENVIRONMENT | tr [[a-z]] [[A-Z]])
echo "Building Regression code for $BUILD_ENV environment..." | tee -a $LOG_FILE



#################Function Definitions START#######################################
invoke_stop()
{
   local_hostname=$1
   local_env=$2
   local_server=$3
   ssh -f $USER@$local_hostname "$DEST_STOP_PATH $local_server"
   RC=$?
   if [[ "$RC" -ne "0" ]] ;
   then
      echo "Script $DEST_STOP_PATH did not execute in $local_env $local_server server" | tee -a $LOG_FILE
      exit 1
   else
      echo "Script $DEST_STOP_PATH executed successfully in $local_env $local_server server" | tee -a $LOG_FILE
   fi
   
}

invoke_start()
{
   local_hostname=$1
   local_env=$2
   local_server=$3

   ssh -f $USER@$local_hostname "$DEST_START_PATH $local_env $local_server START_REG"
   RC=$?
   if [[ "$RC" -ne "0" ]] ;
   then
      echo "Script $DEST_START_PATH did not execute in $local_env $local_server server" | tee -a $LOG_FILE
      exit 1
   else
      echo "Script $DEST_START_PATH executed successfully in $local_env $local_server server" | tee -a $LOG_FILE
   fi

}

invoke_regression()
{
   local_hostname=$1
   local_env=$2

   ssh $USER@$local_hostname "$DEST_SCRIPT_PATH $local_env REGRESSION"
   RC=$?
   if [[ "$RC" -ne "0" ]] ;
   then
      echo "Script $DEST_START_PATH did not execute in $local_hostname server" | tee -a $LOG_FILE
      exit 1
   else
      echo "Script $DEST_START_PATH executed successfully in $local_hostname server" | tee -a $LOG_FILE
   fi

}

invoke_status()
{
   local_hostname=$1
   local_env=$2
   local_server=$3
   ssh  $USER@$local_hostname "$DEST_START_PATH $local_env $local_server  CHECK_STATUS"
   RC=$?
   if [[ "$RC" -ne "0" ]] ;
   then
      echo "Script $DEST_START_PATH did not execute in $local_env $local_server server to check status" | tee -a $LOG_FILE
      exit 1
   else
      echo "Script $DEST_START_PATH executed successfully in $local_env $local_server server to check staus" | tee -a $LOG_FILE
   fi

}

run_reg_procedure()
{
   if [[ "$ENVIRONMENT" == "Dev" ]];
   then
      # Stop script called in DEV ADP server...
      invoke_stop $DEV_ENV "$ENVIRONMENT" "ADAPTER"
      RC=$?
      if [[ "$RC" -ne "0" ]] ;
      then
         echo "Error in Stop script for $ENVIRONMENT ADAPTER" | tee -a $LOG_FILE
         exit 1
      fi
	  
      # Stop script called in DEV SRVC server...
      invoke_stop $DEV_SERVICE "$ENVIRONMENT" "SERVICE"      
      RC=$?
      if [[ "$RC" -ne "0" ]] ;
      then
         echo "Error in Stop script for $ENVIRONMENT SERVICE" | tee -a $LOG_FILE
         exit 1
      fi
      
      # Start script called in DEV ADP server...
      invoke_start $DEV_ENV "$ENVIRONMENT" "ADAPTER"
      RC=$?
      if [[ "$RC" -ne "0" ]] ;
      then
         echo "Error in start script for $ENVIRONMENT ADAPTER" | tee -a $LOG_FILE
         exit 1
      fi
	  
      invoke_status $DEV_ENV "$ENVIRONMENT" "ADAPTER"
	  RC=$?
      if [[ "$RC" -ne "0" ]] ;
      then
         echo "Error in invoking status for $ENVIRONMENT ADAPTER" | tee -a $LOG_FILE
         exit 1
      fi
	  
      # Start script called in DEV SRVC server...
      invoke_start $DEV_SERVICE "$ENVIRONMENT" "SERVICE"
      RC=$?
      if [[ "$RC" -ne "0" ]] ;
      then
         echo "Error in Start script for $ENVIRONMENT SERVICE" | tee -a $LOG_FILE
         exit 1
      fi
	  
      invoke_status $DEV_SERVICE "$ENVIRONMENT" "SERVICE"
	  RC=$?
      if [[ "$RC" -ne "0" ]] ;
      then
         echo "Error in invoking status for $ENVIRONMENT SERVICE" | tee -a $LOG_FILE
         exit 1
      fi
	  
      # Run the regression suite
      invoke_regression $DEV_ENV $ENVIRONMENT
      RC=$?
      if [[ "$RC" -ne "0" ]] ;
      then
         echo "Error in Regression invocation for $ENVIRONMENT " | tee -a $LOG_FILE
         exit 1
      fi

      # Stop script called in DEV ADP server...
      invoke_stop $DEV_ENV "$ENVIRONMENT" "ADAPTER"
      RC=$?
      if [[ "$RC" -ne "0" ]] ;
      then
         echo "Error in Stop script for $ENVIRONMENT ADAPTER" | tee -a $LOG_FILE
         exit 1
      fi
      
      # Stop script called in DEV SRVC server...
      invoke_stop $DEV_SERVICE "$ENVIRONMENT" "SERVICE"
      RC=$?
      if [[ "$RC" -ne "0" ]] ;
      then
         echo "Error in Stop script for $ENVIRONMENT SERVICE" | tee -a $LOG_FILE
         exit 1
      fi
	  
   elif [[ "$ENVIRONMENT" == "PPE" ]];then
      # Stop script called in PPE ADP server...
      invoke_stop $PPE_ENV "$ENVIRONMENT" "ADAPTER"
      RC=$?
      if [[ "$RC" -ne "0" ]] ;
      then
              echo "Error in Stop script for $ENVIRONMENT ADAPTER" | tee -a $LOG_FILE
              exit 1
      fi
      
      # Stop script called in PPE SRVC server...
      for hname in ${PPE_SERVICE[@]}
      do
         invoke_stop $hname "$ENVIRONMENT" "SERVICE"
         RC=$?
         if [[ "$RC" -ne "0" ]] ;
         then
            echo "Error in Stop script for $ENVIRONMENT SERVICE $hname" | tee -a $LOG_FILE
            exit 1
         fi
         
      done
	  
      # Start script called in PPE ADP server...
      invoke_start $PPE_ENV "$ENVIRONMENT" "ADAPTER"
      RC=$?
      if [[ "$RC" -ne "0" ]] ;
      then
         echo "Error in start script for $ENVIRONMENT ADAPTER" | tee -a $LOG_FILE
         exit 1
      fi
	  invoke_status $PPE_ENV "$ENVIRONMENT" "ADAPTER"
	  RC=$?
      if [[ "$RC" -ne "0" ]] ;
      then
         echo "Error in invoking status for $ENVIRONMENT ADAPTER" | tee -a $LOG_FILE
         exit 1
      fi

      # Start script called in PPE SRVC server...
      for hname in ${PPE_SERVICE[@]}
      do
         invoke_start $hname "$ENVIRONMENT" "SERVICE"
         RC=$?
         if [[ "$RC" -ne "0" ]] ;
         then
            echo "Error in start script for $ENVIRONMENT SERVICE $hname" | tee -a $LOG_FILE
            exit 1
         fi
      done
	  for hname in ${PPE_SERVICE[@]}
      do
	     invoke_status $hname "$ENVIRONMENT" "SERVICE"
	     RC=$?
         if [[ "$RC" -ne "0" ]] ;
         then
            echo "Error in invoking status for $ENVIRONMENT SERVICE" | tee -a $LOG_FILE
            exit 1
         fi
	  done
	  
      # Run the regression suite
      invoke_regression $DEV_ENV $ENVIRONMENT
      RC=$?
      if [[ "$RC" -ne "0" ]] ;
      then
         echo "Error in Regression invocation for $ENVIRONMENT $DEV_ENV" | tee -a $LOG_FILE
         exit 1
      fi
	  
      # Stop script called in PPE ADP server...
      invoke_stop $PPE_ENV "$ENVIRONMENT" "ADAPTER"
      RC=$?
      if [[ "$RC" -ne "0" ]] ;
      then
         echo "Error in Stop script for $ENVIRONMENT ADAPTER" | tee -a $LOG_FILE
         exit 1
      fi
	  
      # Stop script called in PPE SRVC server...
      for hname in ${PPE_SERVICE[@]}
      do
         invoke_stop $hname "$ENVIRONMENT" "SERVICE"
         RC=$?
         if [[ "$RC" -ne "0" ]] ;
         then
           echo "Error in Stop script for $ENVIRONMENT ADAPTER $hname" | tee -a $LOG_FILE
           exit 1
         fi
      done
   fi
}
#################Function Definitions END#######################################

# BDR: Build deploy and run
#else only run
if [[ "$RUN_PARAM" == "BDR" ]];then
   echo "Building regression jar..." | tee -a $LOG_FILE
   cd $REG_DIR
   chmod 755 ci
   ./ci
   RC=$?
   if [[ "$RC" -ne "0" ]] ;
   then
      echo "Build Failed....!!!" | tee -a $LOG_FILE
      exit 1
   fi

   cd ..
   echo "Build completed... Zip file is created..." | tee -a $LOG_FILE
   
   if [[ "$ENVIRONMENT" == "Dev" ]];
   then
      scp_result=$(scp -v $REG_DIR/build/distributions/*.zip $USER@$DEV_ENV:$DEST_PATH 2>&1 | tail -1 | awk '{print $4}'|tr -d '\r')
      if [ "$scp_result" -ne "0" ]
      then
         echo "Failed to transfer zip file to DEV server..." | tee -a $LOG_FILE
         exit 1
      else
         echo "Zip file successfully sent to DEV server..." | tee -a $LOG_FILE
      fi
   
   echo "Starting regression suite in DEV server..." | tee -a $LOG_FILE
   ssh $USER@$DEV_ENV "$DEST_SCRIPT_PATH $ENVIRONMENT DEPLOY"
   RC=$?
   if [[ "$RC" -ne "0" ]] ;
   then
      echo "Script $DEST_SCRIPT_PATH did not execute in DEV server" | tee -a $LOG_FILE
      exit 1
   else
      echo "Script $DEST_SCRIPT_PATH executed successfully in DEV server" | tee -a $LOG_FILE
   fi
   run_reg_procedure
   
   elif [[ "$ENVIRONMENT" == "PPE" ]];
   then
      scp_result=$(scp -v $REG_DIR/build/distributions/*.zip $USER@$PPE_ENV:$DEST_PATH 2>&1 | tail -1 | awk '{print $4}'|tr -d '\r')
      if [ "$scp_result" -ne "0" ]
      then
         echo "Failed to transfer zip file to PPE server..." | tee -a $LOG_FILE
         exit 1
      else
         echo "Zip file successfully sent to PPE server..." | tee -a $LOG_FILE
      fi
      echo "Starting regression suite in PPE server..." | tee -a $LOG_FILE
      ssh $USER@$PPE_ENV "$DEST_SCRIPT_PATH $ENVIRONMENT DEPLOY"
      RC=$?
      if [[ "$RC" -ne "0" ]] ;
      then
         echo "Script $DEST_SCRIPT_PATH did not execute in PPE server" | tee -a $LOG_FILE
         exit 1
      else
         echo "Script $DEST_SCRIPT_PATH executed successfully in PPE server" | tee -a $LOG_FILE
      fi
	  #Run the regression procedure with start stop regression ......
      run_reg_procedure
      
   fi
elif [[ "$RUN_PARAM" == "RUN" ]];then

   run_reg_procedure
   
fi
echo "Regression completed for $BUILD_ENV environment..." | tee -a $LOG_FILE
exit $?