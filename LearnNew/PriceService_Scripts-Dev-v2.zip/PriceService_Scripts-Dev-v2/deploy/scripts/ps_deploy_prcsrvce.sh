#!/bin/bash
. $HOME/.bash_profile
PSHOME=/appl/prcsrvce
. $PSHOME/profile

set -x

STAMP=`date +"%Y%m%d"`
PROG_NAME=$(basename $0 .sh)

# Sourcing the config file
. $PSHOME/usr/local/scripts/config.sh
RC=$?
if [[ "$RC" -ne "0" ]]; then
   echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Failed to source config.sh script. Please check..!!"
   exit 1
fi

LOG_FILE=$LOG_PATH/${PROG_NAME}_log_${STAMP}.log
if [[ -z "$LOG_PATH" ]];
then
	echo "$(date '+%Y-%m-%d %T') : Log path is not set. Please set the LOG_PATH."
	exit 1
fi

# Version from the parameter.
ver_from_param=$2

if [ "$PSENV_TYPE" == "SERVICE" ]
then
	. $PSHOME/nginx_profile
	
	version_from_manifest=$(grep -w "ps_active_version" ${PSHOME}/tmp/ps_manifest.sh | grep $ver_from_param)
	RC=$?
	if [[ $RC -ne 0 ]] ; then
	# Error exit
		echo "$(date '+%Y-%m-%d %T') : Return code: ${RC} : ERROR : The version $ver_from_param is not a live version.." | tee -a $LOG_FILE
		exit 3
	fi
fi

# Remove the temporary folder <temp_deploy> if it exists
rm -rf ${PSHOME}/usr/local/price-adapter/versions/temp_deploy/
rm -rf ${PSHOME}/usr/local/price-service/versions/temp_deploy/

build_ver=dummy_value
version=""
artifact=""

echo "$(date '+%Y-%m-%d %T') : Env is $PSENV_TYPE" | tee -a $LOG_FILE
artifact_file_loc=`ls -ltr ${PSHOME}/tmp/*.zip|tail -1|awk '{print $9}'`
artifact=`basename ${artifact_file_loc}`
echo "$(date '+%Y-%m-%d %T') : New zip file name is $artifact" | tee -a $LOG_FILE

version=`echo ${artifact}|cut -d. -f1|cut -d- -f3`
echo "$(date '+%Y-%m-%d %T') : Current version is $version" | tee -a $LOG_FILE

if [[ ! -z ${version} && ! -z ${artifact} ]]
then

	if [[ "$1" == "dev_adp" || "$1" == "ppe_adp" || "$1" == "prod_adp" || "$1" == "prod_adp_dr" ]]
	then
		echo "$(date '+%Y-%m-%d %T') : Moving ${version}th artifact version to $PSHOME/usr/local/price-adapter/versions/${version}" | tee -a $LOG_FILE

		mkdir -p ${PSHOME}/usr/local/price-adapter/versions/temp_deploy/
		unzip -qo ${PSHOME}/tmp/${artifact} -d ${PSHOME}/usr/local/price-adapter/versions/temp_deploy/

		#Append the name of the jar with version
		echo "$(date '+%Y-%m-%d %T') : Yml file is $1.yml" | tee -a $LOG_FILE
		build_ver=$(cat ${PSHOME}/usr/local/price-adapter/versions/temp_deploy/$1.yml | grep "^version" | tr -d ' ' | cut -d ':' -f 2)
		
		# Remove any old version folder if it exists
		rm -rf ${PSHOME}/usr/local/price-adapter/versions/${version}-${build_ver}/
		
		echo "$(date '+%Y-%m-%d %T') : Build version is $build_ver" | tee -a $LOG_FILE
		mv ${PSHOME}/usr/local/price-adapter/versions/temp_deploy/ ${PSHOME}/usr/local/price-adapter/versions/${version}-${build_ver}/
		RC=$?
		if [[ $RC -ne 0 ]] ; then
		# Error exit
			echo "$(date '+%Y-%m-%d %T') : Return code: ${RC} : ERROR : Failed to move the version folder.." | tee -a $LOG_FILE
			exit 3
		fi
		
		echo $version > ${PSHOME}/usr/local/price-adapter/versions/latest_version_$build_ver
		ln -s ${PSHOME}/usr/local/price-adapter/versions/${version} ${PSHOME}/usr/local/latest
		
		#Append the name of the jar with version
		mv ${PSHOME}/usr/local/price-adapter/versions/${version}-${build_ver}/*.jar ${PSHOME}/usr/local/price-adapter/versions/${version}-${build_ver}/price-adapter-developer-build-${build_ver}.jar

	elif [[ "$1" == "dev_srvc" || "$1" == "ppe_srvc" || "$1" == "prod_srvc" || "$1" == "prod_srvc_dr" ]]
	then
		echo "$(date '+%Y-%m-%d %T') : Moving ${version}th artifact version to $PSHOME/usr/local/price-service/versions/${version}" | tee -a $LOG_FILE

		mkdir -p ${PSHOME}/usr/local/price-service/versions/temp_deploy/
		unzip -qo ${PSHOME}/tmp/${artifact} -d ${PSHOME}/usr/local/price-service/versions/temp_deploy/

		#Append the name of the jar with version
		echo "$(date '+%Y-%m-%d %T') : Yml file is $1.yml" | tee -a $LOG_FILE
		build_ver=$(cat ${PSHOME}/usr/local/price-service/versions/temp_deploy/$1.yml | grep "^version" | tr -d ' ' | cut -d ':' -f 2)
		
		# Remove any old version folder if it exists
		rm -rf ${PSHOME}/usr/local/price-service/versions/${version}-${build_ver}/
		
		echo "$(date '+%Y-%m-%d %T') : Build version is $build_ver" | tee -a $LOG_FILE
		mv ${PSHOME}/usr/local/price-service/versions/temp_deploy/ ${PSHOME}/usr/local/price-service/versions/${version}-${build_ver}/
		RC=$?
		if [[ $RC -ne 0 ]] ; then
		# Error exit
			echo "$(date '+%Y-%m-%d %T') : Return code: ${RC} : ERROR : Failed to move the version folder.." | tee -a $LOG_FILE
			exit 3
		fi
		
		echo $version > ${PSHOME}/usr/local/price-service/versions/latest_version_$build_ver
		ln -s ${PSHOME}/usr/local/price-service/versions/${version} ${PSHOME}/usr/local/latest

		#Append the name of the jar with version
		mv ${PSHOME}/usr/local/price-service/versions/${version}-${build_ver}/*.jar ${PSHOME}/usr/local/price-service/versions/${version}-${build_ver}/price-service-developer-build-${build_ver}.jar

	fi

        echo "$(date '+%Y-%m-%d %T') : Removing now $artifact from tmp directory" | tee -a $LOG_FILE
        rm -f ${PSHOME}/tmp/${artifact}
		rm -f ${PSHOME}/tmp/*.zip
else
	echo "$(date '+%Y-%m-%d %T') : No zip file found in this build...." | tee -a $LOG_FILE
fi
wait

if [ "$build_ver" == "dummy_value" ]
then
	echo "$(date '+%Y-%m-%d %T') : Creating version number.." | tee -a $LOG_FILE
	if [[ "$PSENV_TYPE" == "SERVICE" ]]
	then
		build_ver=$ver_from_param
		pre_build_nor=`cat $PSHOME/usr/local/price-service/versions/latest_version_$build_ver`
		echo "$(date '+%Y-%m-%d %T') : Previous build number is $pre_build_nor.." | tee -a $LOG_FILE
		version=$pre_build_nor-$ver_from_param
		
		if [[ ! -d $PSHOME/usr/local/price-service/versions/$version ]] 
		then
			echo "$(date '+%Y-%m-%d %T') : Build failed!!! Please check the version:<$version>" | tee -a $LOG_FILE
			exit 1
		fi
		
		echo "$(date '+%Y-%m-%d %T') : Created version number is $version" | tee -a $LOG_FILE
	elif [[ "$PSENV_TYPE" == "ADAPTER" ]]
	then
		build_ver=$ver_from_param
		pre_build_nor=`cat $PSHOME/usr/local/price-adapter/versions/latest_version_$build_ver`
		echo "$(date '+%Y-%m-%d %T') : Previous build number is $pre_build_nor.." | tee -a $LOG_FILE
		version=$pre_build_nor-$ver_from_param
		
		if [[ ! -d $PSHOME/usr/local/price-adapter/versions/$version ]] 
		then
			echo "$(date '+%Y-%m-%d %T') : Build failed!!! Please check the version:<$version>" | tee -a $LOG_FILE
			exit 1
		fi
		
		echo "$(date '+%Y-%m-%d %T') : Created version number is $version" | tee -a $LOG_FILE
	fi

else
	version=${version}-${build_ver}
	echo "$(date '+%Y-%m-%d %T') : New version number is $version" | tee -a $LOG_FILE
fi


#nginx delpoyment steps
###########################################

if [ "$PSENV_TYPE" == "SERVICE" ]
then
	echo "$(date '+%Y-%m-%d %T') : Starting nginx profile sourcing..." | tee -a $LOG_FILE

	echo "$(date '+%Y-%m-%d %T') : Getting IP address of the Server.." | tee -a $LOG_FILE
	ip_address=$(/sbin/ifconfig eth0 | grep 'inet addr:' | cut -d: -f2 | awk '{ print $1}')
	echo "$(date '+%Y-%m-%d %T') : IP Address of the server is $ip_address.." | tee -a $LOG_FILE

	sed -e "s|\$PSHOME|"$PSHOME"|g" \
	-e "s|\$nginx_userid|"$nginx_userid"|g" \
	-e "s|\$nginx_nfiles|"$nginx_nfiles"|g" \
	-e "s|\$nginx_ktimeout|"$nginx_ktimeout"|g" \
	-e "s|\$nginx_app_port1|"$nginx_app_port1"|g" \
	-e "s|\$nginx_app_port2|"$nginx_app_port2"|g" \
	-e "s|\$nginx_app_port3|"$nginx_app_port3"|g" \
	-e "s|\$nginx_listenport|"$nginx_listenport"|g" \
	-e "s|\$nginx_version1|"$nginx_version1"|g" \
	-e "s|\$nginx_version2|"$nginx_version2"|g" \
	-e "s|\$nginx_version3|"$nginx_version3"|g" \
	-e "s|\$current_ip_address|"$ip_address"|g" \
	$PSHOME/etc/nginx/nginx.conf.template > $PSHOME/etc/nginx/nginx.conf

	sed -e "s|\$PSHOME|"$PSHOME"|g" $PSHOME/etc/supervisor-fragments/nginx-supervisord.conf > $PSHOME/etc/supervisor-fragments/nginx-supervisord.conf_modified
	mv $PSHOME/etc/supervisor-fragments/nginx-supervisord.conf_modified $PSHOME/etc/supervisor-fragments/nginx-supervisord.conf
	
	echo "$(date '+%Y-%m-%d %T') : Nginx profile completed.." | tee -a $LOG_FILE
fi

#Supervisor deploment pre steps
###############################

if [ -s $PSHOME/etc/supervisord.conf.orig ]
then
	cp $PSHOME/etc/supervisord.conf.orig $PSHOME/etc/supervisord.conf
fi

if [[ -s $PSHOME/etc/supervisord.conf && -s $PSHOME/etc/supervisord.conf.orig ]]
then
	echo "$(date '+%Y-%m-%d %T') : supervisord.conf  and supervisord.conf.orig exists in $PSHOME/etc" | tee -a $LOG_FILE
else
	cp $PSHOME/etc/supervisord.conf  $PSHOME/etc/supervisord.conf.orig
fi

if [ ! -d $PSHOME/etc/supervisor-fragments ]
then
	echo "$(date '+%Y-%m-%d %T') : Creating directories $PSHOME/etc/supervisor-fragments" | tee -a $LOG_FILE
	mkdir $PSHOME/etc/supervisor-fragments
else
	echo "$(date '+%Y-%m-%d %T') : Directory $PSHOME/etc/supervisor-fragments exists" | tee -a $LOG_FILE
fi

cp $PSHOME/etc/supervisord.conf  $PSHOME/etc/supervisor-fragments/01-supervisord.conf.orig
sed -e "s|\/var|"$PSHOME"/var|g" $PSHOME/etc/supervisord.conf > $PSHOME/etc/supervisor-fragments/01-supervisord.conf.orig


#Supervisor deployment steps
################################################

temp=/appl/prcsrvce/tmp

cd $temp

if [ "$PSENV_TYPE" == "ADAPTER" ]
then
	echo "$(date '+%Y-%m-%d %T') : Supervisor for ADAPTER started.." | tee -a $LOG_FILE
	sed -e "s|\/nnn|"\/$version"|g" -e "s/java_ver/"$build_ver"/g" 02-supervisord.conf > 02-supervisord.conf_mod
	sed -e "s|\$env.yml|"$1".yml|g" 02-supervisord.conf_mod > 02-supervisord.conf_modified
	mv 02-supervisord.conf_modified 02-supervisord.conf

	mv 02-supervisord.conf $PSHOME/etc/supervisor-fragments/02-supervisord.conf.orig

	sed -e "s|\$PSHOME|"$PSHOME"|g" $PSHOME/etc/supervisor-fragments/02-supervisord.conf.orig > $PSHOME/etc/supervisor-fragments/02-supervisord.conf

	cat $PSHOME/etc/supervisor-fragments/01-supervisord.conf.orig $PSHOME/etc/supervisor-fragments/02-supervisord.conf > $PSHOME/etc/supervisord.conf
	echo "$(date '+%Y-%m-%d %T') : Supervisor for ADAPTER completed." | tee -a $LOG_FILE
elif [ "$PSENV_TYPE" == "SERVICE" ]
then
	echo "$(date '+%Y-%m-%d %T') : Supervisor for SERVICE started.." | tee -a $LOG_FILE
	sed -e "s|\/nnn|"\/$version"|g" -e "s/java_ver/"$build_ver"/g" 03-supervisord.conf > 03-supervisord.conf_mod
	sed -e "s|\$env.yml|"$1".yml|g" -e "s/vnum/"$build_ver"/g" 03-supervisord.conf_mod > 03-supervisord.conf_modified
	mv 03-supervisord.conf_modified 03-supervisord.conf

	mv 03-supervisord.conf $PSHOME/etc/supervisor-fragments/03-supervisord.conf.orig

	sed -e "s|\$PSHOME|"$PSHOME"|g" $PSHOME/etc/supervisor-fragments/03-supervisord.conf.orig > $PSHOME/etc/supervisor-fragments/03-supervisord-${build_ver}.conf

	cat $PSHOME/etc/supervisor-fragments/01-supervisord.conf.orig > $PSHOME/etc/supervisord.conf
	
	vname=($(echo $version_from_manifest | cut -d ":" -f 2))
	for super_ver in ${vname[@]}
	do
		cat $PSHOME/etc/supervisor-fragments/03-supervisord-${super_ver}.conf >> $PSHOME/etc/supervisord.conf
		echo "" >> $PSHOME/etc/supervisord.conf
	done
	
	echo "$(date '+%Y-%m-%d %T') : Supervisor for SERVICE completed." | tee -a $LOG_FILE
else
	echo "$(date '+%Y-%m-%d %T') : Not executing supervisor deployment steps" | tee -a $LOG_FILE
fi

echo "$(date '+%Y-%m-%d %T') : Script execution completed......" | tee -a $LOG_FILE
exit $?;
