#!/bin/bash

#PRICE_BRANCH - Parameters are: Environment (Dev, PPE or Prod)
#PRICE_VERSION Version - v2
#PRICE_ENV_TYPE - ALL, ADAPTER and SERVICE

pgmname=$(basename $0)
DT=$(date +%Y%m%d)
INSTALL_DIR="/home/jenkins/Price_Service_installer"

# For mocking purpose only - Should be commented when running through Jenkins
#PRICE_BRANCH="Dev"
#PRICE_VERSION="v2"
#PRICE_ENV_TYPE="ALL"
#export JENKIN_BUILD_DIR="/appl/var/lib/jenkins/workspace/PriceService_Scripts_Build"
#export WORK_DIR=$JENKIN_BUILD_DIR/${PRICE_BRANCH}-v2/deploy/scripts

if [[ -z ${PRICE_BRANCH} || -z ${PRICE_VERSION} || -z ${PRICE_ENV_TYPE} ]];
then
   echo "$(date) - Following Parameters are mandatory and cannot be null" 
   echo "$(date) - Parameters are PRICE_BRANCH:<${PRICE_BRANCH}> PRICE_VERSION:<${PRICE_VERSION}> PRICE_ENV_TYPE:<${PRICE_ENV_TYPE}>"
   exit 1;
fi;

echo "$(date) - Parameters are PRICE_BRANCH:<${PRICE_BRANCH}> PRICE_VERSION:<${PRICE_VERSION}> PRICE_ENV_TYPE:<${PRICE_ENV_TYPE}>"
echo "$(date) - Parameters are JENKIN_BUILD_DIR:<${JENKIN_BUILD_DIR}>"
echo "$(date) - Parameters are WORK_DIR:<${WORK_DIR}>"

. ${JENKIN_BUILD_DIR}/${PRICE_BRANCH}-${PRICE_VERSION}/deploy/config/ps_deploy_config.sh
ret=$?

if [[ $ret -ne "0" ]];
then
   echo "$(date) - Unable to source the profile - <ps_deploy_config.sh>" 
   exit 1;
fi;

logname=${LOG_PATH}/$pgmname.$DT.log
echo "$(date) - logfile name is set as :<${logname}>"

set -x

echo "$(date) - Script $pgmname Started" | tee -a $logname

javainstall="ps_install_java.sh"
PSENV_TYPE=$( echo ${PRICE_ENV_TYPE} | tr [[a-z] [[A-Z]] )

if [[ ${PSENV_TYPE} == "ALL" ]];
then
  ALL=(ADAPTER SERVICE);
else
  ALL=${PSENV_TYPE}
fi;

PRICE_BRANCH_UPPER=$( echo ${PRICE_BRANCH} | tr [[a-z] [[A-Z]] )
for ff in ${ALL[@]}
do
   HOSTNAME=${PRICE_BRANCH_UPPER}_${ff}[@]

   for hname in ${!HOSTNAME}
   do
      hostnamelist=$hostnamelist" "$hname
   done;
done;

if [[ ${PRICE_BRANCH_UPPER} == "PROD" ]];
then
   for ff in ${ALL[@]}
   do
       HOSTNAME=${PRICE_BRANCH_UPPER}_"DR"_${ff}[@]

       for hname in ${!HOSTNAME}
       do
          hostnamelist=$hostnamelist" "$hname
       done;
    done;
fi;

#exit 0;

if [[ ! -f ${WORK_DIR}/$javainstall ]];
then
       echo "$(date) - The file <$javainstall> is not present in the WORK_DIR <$WORK_DIR>" | tee -a $logname
       exit 1;
fi;

for hname in $( echo $hostnamelist )
do

    echo "$(date) - Processing for hostname <$hname>" | tee -a $logname
    
    scp -o StrictHostKeyChecking=no ${INSTALL_DIR}/jdk-8u91-linux-x64.gz ${PS_USER}@$hname:${PS_HOME}/install

    ret=$?

    if [[ $ret -ne "0" ]];
    then
       echo "$(date) - Unable to copy <${INSTALL_DIR}/jdk-8u91-linux-x64.gz> to target server <$hname>" | tee -a $logname
       exit 1;
    fi;


    scp -o StrictHostKeyChecking=no ${WORK_DIR}/$javainstall ${PS_USER}@$hname:${PS_HOME}/install

    ret=$?

    if [[ $ret -ne "0" ]];
    then
       echo "$(date) - Unable to copy <$javainstall> to target server <$hname>" | tee -a $logname
       exit 1;
    fi;

    ssh ${PS_USER}@$hname "chmod +x ${PS_HOME}/install/$javainstall; ${PS_HOME}/install/$javainstall"

    ret=$?

    if [[ $ret -ne "0" ]];
    then
       echo "$(date) - Unable to execute script <$javainstall> in target server <$hname>" | tee -a $logname
       exit 1;
    fi;
    
done;

echo "$(date) - Script $pgmname completed" | tee -a $logname

exit 0;
