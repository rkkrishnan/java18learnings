#!/bin/bash
set -x

. $HOME/.bash_profile

cd $PSHOME/usr/java

ret=$?

if [[ $ret -ne "0" ]];
then
   echo "$(date) - Unable to change directory <$PSHOME/usr/java> in target server <$(hostname)>" 
   exit 1;
fi;

tar -xvzf $PSHOME/install/jdk-8u91-linux-x64.gz

ret=$?

if [[ $ret -ne "0" ]];
then
   echo "$(date) - Unable to extract tape archive <jdk-8u91-linux-x64.gz> in target server <$(hostname)>" 
   exit 1;
fi;

exit 0;
