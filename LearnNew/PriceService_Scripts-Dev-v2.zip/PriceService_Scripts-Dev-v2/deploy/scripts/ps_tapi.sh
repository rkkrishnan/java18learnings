#!/bin/bash

set -x

STAMP=`date +"%Y%m%d"`
PROG_NAME=$(basename $0 .sh)

if [ "$#" -ne "2" ]; then
	echo "$(date '+%Y-%m-%d %T') : ERROR: Please specify the file_param as [Dev/PPE/Prod] [v2orv3] "
	exit 1
fi

BRANCH=$1
VERSION=$2
#Sourcing the config files
. /appl/var/lib/jenkins/workspace/PriceService_Scripts_Build/${BRANCH}-v2/deploy/config/ps_deploy_config.sh
RC=$?
if [[ "$RC" -ne "0" ]]; then
   echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Failed to source ps_deploy_config.sh script. Please check..!!"
   exit 1
fi


WORK_DIR=$JENKIN_BUILD_DIR_SCRIPTS/${BRANCH}-${VERSION}
WORK_DIRIDL=$WORK_DIR/idl_to_deploy
LOG_FILE=$LOG_PATH/$JOB_NAME/${PROG_NAME}_log_${BUILD_NUMBER}_${STAMP}.log

if [[ -z "$WORK_DIR" ]];
then
	echo "WORK_DIR is not set. Please set the WORK_DIRIDL."
	exit 1
fi

if [[ -z "$WORK_DIRIDL" ]];
then
	echo "WORK_DIRIDL is not set. Please set the WORK_DIRIDL."
	exit 1
fi

if [[ -z "$LOG_PATH" ]];
then
	echo "Log path is not set. Please set the LOG_PATH."
	exit 1
fi

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME started by $USER" | tee -a $LOG_FILE

changed_idlfile=`find $WORK_DIRIDL -type f `

if [[ ! -z "$changed_idlfile" ]];
then
	for i in ${changed_idlfile[@] }
	do
		grep_res=$(grep -w `basename $i` $WORK_DIR/deploy/config/ps_manifest.sh)
		RC=$?

		if [ "$?" -ne "0" ]
		then
			echo "$(date '+%Y-%m-%d %T') : The $i is not present in Manifest file... Please check again !!" | tee -a $LOG_FILE
		exit 1
		fi


		mfstatus=($(echo $grep_res | cut -d ":" -f 2))
		awk -v tapistatus=$mfstatus 'BEGIN {FS=","} {  if ( index($0,"@version")!=0 ){sub($2,"\""tapistatus"\"");print} else {print}}' $i >> $WORK_DIRIDL/tapiidltemp
		var1=`date '+%Y/%m/%d'`
		awk -v var=$var1 'BEGIN {FS=","} {  if ( index($0,"@version")!=0 ){sub($3,"\""var"\"");print} else {print}}' $WORK_DIRIDL/tapiidltemp >> $WORK_DIRIDL/tapifile

		status=$(curl -s  -w "%{http_code}"  --proxy http://$HOSTNAME_IDL_TAPI:$HOSTNAME_IDL_TAPI_PORT --user $USERNAME:$PASSWORD  --form idl=@$WORK_DIRIDL/tapifile $TAPIURL -v)

		if [[ "$status" == "200" || "$status" == "201" ]];
		then
			echo "$(date '+%Y-%m-%d %T') : The idlfile $i  is uploaded successfully with status code $status to tapi" | tee -a $LOG_FILE
		else
			echo "$(date '+%Y-%m-%d %T') : The idlfile $i  is failed to upload with  status code $status to tapi" | tee -a $LOG_FILE
			exit 1
		fi
		
		#removing temporary files
		rm -rf $WORK_DIRIDL/tapiidltemp
		rm -rf $WORK_DIRIDL/tapifile

	done
else

   echo "$(date '+%Y-%m-%d %T') : There are  no idl changes to be uploaded to tapi" | tee -a $LOG_FILE
fi

#removing temporary files
rm -rf $WORK_DIRIDL/tapiidltemp
rm -rf $WORK_DIRIDL/tapifile

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME Completed Successfully" | tee -a $LOG_FILE
exit $?

