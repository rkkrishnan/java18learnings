#!/bin/bash

set -x

STAMP=`date +"%Y%m%d"`
PROG_NAME=$(basename $0 .sh)

if [ "$#" -ne "3" ]; then
   echo "$(date '+%Y-%m-%d %T') : ERROR: Please specify the file_param as [Dev/PPE/Prod] [v2/v3] [ADAPTER/SERVICE] "
   exit 1
fi

BRANCH=$1
SERVER=$3
VERSION=$2

# Sourcing the config file
. /appl/var/lib/jenkins/workspace/PriceService_Scripts_Build/${BRANCH}-v2/deploy/config/ps_deploy_config.sh
RC=$?
if [[ "$RC" -ne "0" ]]; then
   echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Failed to source ps_deploy_config.sh script. Please check..!!"
   exit 1
fi

WORK_DIR_SCRIPTS=$JENKIN_BUILD_DIR_SCRIPTS/${BRANCH}-v2

LOG_FILE=$LOG_PATH/$JOB_NAME/${PROG_NAME}_log_${BUILD_NUMBER}_${STAMP}.log
if [[ -z "$LOG_PATH" ]];
then
	echo "$(date '+%Y-%m-%d %T') : Log path is not set. Please set the LOG_PATH."
	exit 1
fi

YML=""
#YML for DR
YML_DR=""

if [[ "$SERVER" == "ADAPTER" ]]; then
   YML="adp"
   YML_DR="adp"
elif [[ "$SERVER" == "SERVICE" ]]; then
   YML="srvc"
   YML_DR="srvc"
else
   echo "$(date '+%Y-%m-%d %T') : Third parameter passed is invalid. Usage: ADAPTER/SERVICE" | tee -a $LOG_FILE
   exit 1
fi

#Validating the first parameter to be Dev/PPE/Prod. If it is valid then build the YML to be passed to the deploy script in server
if [[ "$BRANCH" == "Dev" || "$BRANCH" == "PPE" || "$BRANCH" == "Prod" ]]; then
   YML=$(echo $BRANCH | tr [[A-Z]] [[a-z]])_${YML}
   if [[ "$BRANCH" == "Prod" ]]; then
      #Building YML file for DR servers
     YML_DR=$(echo $BRANCH | tr [[A-Z]] [[a-z]])_${YML_DR}_dr

   fi
   
else
   echo "$(date '+%Y-%m-%d %T') : First paramter passed is invalid. Usage: Dev/PPE/Prod " | tee -a $LOG_FILE
   exit 1
fi



#Building variables
PSENV_TYPE=$(echo $SERVER | tr [[a-z]] [[A-Z]])
BRANCH_UPPER=$(echo $BRANCH | tr [[a-z]] [[A-Z]])
HOSTNAME=${BRANCH_UPPER}_${PSENV_TYPE}[@]

DEPLOY_SCRIPT="$PS_HOME/install/ps_deploy_prcsrvce.sh"
START_SCRIPT="$PS_HOME/usr/local/scripts/ps_start.sh"
STOP_SCRIPT="$PS_HOME/usr/local/scripts/ps_stop.sh"
APM_SCRIPT="$PS_HOME/usr/local/scripts/ps_apmprobing_all.sh"

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME started by $USER" | tee -a $LOG_FILE

#Extra config required for APM enable/disable functionality
grep_res=$(grep -w ${SERVER}_APM_STATUS $WORK_DIR_SCRIPTS/deploy/config/ps_manifest.sh | cut -d ":" -f 2)
HOSTNAME_APM=${BRANCH_UPPER}_ADAPTER[@]


restart_func(){

   l_hostname=$1
   l_yml=$2
   echo "$(date '+%Y-%m-%d %T') : The yml is $l_yml and the hostname is $l_hostname" | tee -a $LOG_FILE
   for hname in ${!l_hostname}
   do
      #Executin the deployment script in the servers
      ssh ${PS_USER}@${hname} "$DEPLOY_SCRIPT $l_yml $VERSION"
      RC=$?
      if [[ "$RC" -ne "0" ]] ; 
      then  
         echo "$(date '+%Y-%m-%d %T') : Script $DEPLOY_SCRIPT did not execute successfully in $hname server" | tee -a $LOG_FILE
         exit 1 
      else 
         echo "$(date '+%Y-%m-%d %T') : Script $DEPLOY_SCRIPT executed successfully in $hname server" | tee -a $LOG_FILE
      fi
	  
      #Executing stop script in the servers
      ssh ${PS_USER}@${hname} "$STOP_SCRIPT"
      RC=$?
      if [[ "$RC" -ne "0" ]] ;
      then
         echo "$(date '+%Y-%m-%d %T') : Script $STOP_SCRIPT did not execute successfully in $hname server" | tee -a $LOG_FILE
         exit 1 
      else
         echo "$(date '+%Y-%m-%d %T') : Script $STOP_SCRIPT executed successfully in $hname server" | tee -a $LOG_FILE
      fi
   
      #Executing start script in the servers
      ssh ${PS_USER}@${hname} "$START_SCRIPT"
      RC=$?   
      if [[ "$RC" -ne "0" ]] ;
      then
         echo "$(date '+%Y-%m-%d %T') : Script $START_SCRIPT did not execute successfully in $hname server" | tee -a $LOG_FILE
         exit 1 
      else
         echo "$(date '+%Y-%m-%d %T') : Script $START_SCRIPT executed successfully in $hname server" | tee -a $LOG_FILE
      fi
   
   done
}

apm_probing()
{
	local l_hostname=$1
	#Excuting the APM probing ENABLE/DISABLE script. First parameter[ON/OFF] is got from the manifest.
	for hname in ${!l_hostname}
	do
		ssh ${PS_USER}@${hname} "$APM_SCRIPT $grep_res $SERVER"
		RC=$?
		if [[ "$RC" -ne "0" ]] ;
		then
			echo "$(date '+%Y-%m-%d %T') : Script $APM_SCRIPT did not execute successfully in $hname server" | tee -a $LOG_FILE
			exit 1 
		else
			echo "$(date '+%Y-%m-%d %T') : Script $APM_SCRIPT executed successfully in $hname server" | tee -a $LOG_FILE
		fi
	done
}
#APM probing via CICD is disabled for now..
#apm_probing $HOSTNAME_APM
restart_func $HOSTNAME $YML

#Operation for DR servers
if [[ "$BRANCH" == "Prod" ]]; then
   HOSTNAME_DR=${BRANCH_UPPER}_DR_${PSENV_TYPE}[@]
   HOSTNAME_APM_DR=${BRANCH_UPPER}_DR_ADAPTER[@]
   
   #For APM enable disable
   #apm_probing $HOSTNAME_APM_DR
   
   restart_func $HOSTNAME_DR $YML_DR 
fi

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME completed successfully...!!!" | tee -a $LOG_FILE
exit $?