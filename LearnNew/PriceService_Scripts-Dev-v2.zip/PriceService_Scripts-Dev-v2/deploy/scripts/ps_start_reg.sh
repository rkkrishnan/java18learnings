#!/bin/bash
. $HOME/.bash_profile
PSHOME=/appl/prcsrvce
. $PSHOME/profile

# Sourcing the config file
. $PSHOME/usr/local/scripts/config.sh
RC=$?
if [[ "$RC" -ne "0" ]]; then
   echo "$(date '+%Y-%m-%d %T') : Exiting the $PROG_NAME. Failed to source config.sh script. Please check..!!"
   exit 1
fi

if [ "$#" -ne "3" ]; then
	echo "$(date '+%Y-%m-%d %T') : ERROR : Input param : Branch[Dev/PPE], Env[ADAPTER/SERVICE], Check status(To Check if jar is up and running)[CHECK_STATUS/START_REG]"
	exit 1
fi

#set -x
cd $PSHOME/regression/logs

STAMP=`date +"%Y%m%d"`
PROG_NAME=$(basename $0 .sh)
REG_PATH=$PSHOME/regression
REG_LOG_PATH=$PSHOME/regression/logs
BRANCH=$1
ENV=$2
CHK_STATUS=$3

LOG_FILE=$LOG_PATH/${PROG_NAME}_log_${STAMP}.log

if [[ ! -d "$LOG_PATH" ]];
then
	echo "Log path is not set. Please set the LOG_PATH."
	exit 1
fi

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME started by $USER for $ENV environment.. Hostname is <`hostname`>" | tee -a  $LOG_FILE

########################## Function definition for server checks START ######################
check_reg_adapter_for_curl()
{
	echo "$(date '+%Y-%m-%d %T') : Checking adapter jar is up for regression..." | tee -a  $LOG_FILE
	fname="check_reg_adapter_for_curl";
	ret_code=1

	echo "$(date '+%Y-%m-%d %T') : $fname - Starting $SNAME for Adapter Price Server ..." | tee -a  $LOG_FILE

	hport=$REG_ADP_PORT

	#Inducing sleep after superviser start is invoked
	curl_adp_log=$REG_LOG_PATH/curl_reg_adapter_log

	for ff in $(hostname)
	do
		ret_code=1
		echo "$(date '+%Y-%m-%d %T') : $fname - Running for Adapter Server ($ff:$hport)..." | tee -a  $LOG_FILE
		typeset -i counter=1;
		while [ true ]
		do
			if [[ $counter -ge $ITERATION_COUNT ]]; then
				echo "$(date '+%Y-%m-%d %T') : ERROR : The server check failed for ${ff}:${hport} after $ITERATION_COUNT attempts " | tee -a  $LOG_FILE
				break;
			else
				sleep $SLEEPTIME
			fi

			status=$(curl -X GET  -s -o $curl_adp_log -w "%{http_code}" http://${ff}:$hport/docs)
			if [[ "$status" -ne "200" ]];
			then
				echo "$(date '+%Y-%m-%d %T') : $fname - Response <$status> from curl command is present in the log path:/appl/prcsrvce/log/curl_adapter_log" | tee -a  $LOG_FILE
				echo "$(date '+%Y-%m-%d %T') : $fname - failed on the server <${ff}> on $counter attempt ... url (http://$ff:$hport/docs)" | tee -a  $LOG_FILE
			else
				echo "$(date '+%Y-%m-%d %T') : $fname - Response <$status>.. Completed on server  ($ff:$hport) ..." | tee -a  $LOG_FILE
				echo "$(date '+%Y-%m-%d %T') : Adapter jar is up and running for regression..." | tee -a  $LOG_FILE
			return 0;
			fi
			counter=$counter+1;
			
		done;
	done;
	echo "$(date '+%Y-%m-%d %T') : $fname - failed on the server <$(hostname)>..." | tee -a  $LOG_FILE
	return $ret_code;
}

check_reg_service_for_curl()
{
	echo "$(date '+%Y-%m-%d %T') : Checking service jar is up for regression..." | tee -a  $LOG_FILE
	fname="check_reg_service_for_curl";
	ret_code=0

	#typeset -i failed_server_count=0
	echo "$(date '+%Y-%m-%d %T') : $fname - Starting $SNAME for Price Server ..." | tee -a  $LOG_FILE

	hport=$REG_SRV_PORT

	#Inducing sleep after superviser start is invoked
	curl_svc_log=$REG_LOG_PATH/curl_reg_srvc_log

	for ff in $(hostname)
	do

		typeset -i counter=1;   
		typeset -i failed_server_count=1     

		while [ true ]
		do
			echo "$(date '+%Y-%m-%d %T') : $fname - Starting $SNAME for Server ($ff:$hport)..." | tee -a  $LOG_FILE
			if [[ $counter -ge  $ITERATION_COUNT ]]; 
			then
				echo "$(date '+%Y-%m-%d %T') : ERROR : The server check failed for ${ff}:${hport} after $ITERATION_COUNT attempts " | tee -a  $LOG_FILE
				break;
			else
				sleep $SLEEPTIME
			fi

			status=$(curl -X GET  -s -o $curl_svc_log -w "%{http_code}" http://$ff:$hport/docs)

			if [[ "$status" -ne "200" ]];
			then
				echo "$(date '+%Y-%m-%d %T') : $fname - Response <$status> from curl command is present in the log path: /appl/prcsrvce/log/curl_srvc_log" | tee -a  $LOG_FILE
				echo "$(date '+%Y-%m-%d %T') : $fname - failed on the server <${ff}> on $counter attempt ... url (http://$ff:$hport/docs)" | tee -a  $LOG_FILE
				failed_server_count=1
			else
				echo "$(date '+%Y-%m-%d %T') : $fname - Completed on this server on $counter attempt... url (http://$ff:$hport/docs)" | tee -a  $LOG_FILE
				failed_server_count=0
				break;
			fi
			counter=$((counter+1))
		done; #done for while loop 

		if [[ $failed_server_count -ne 0 ]];
		then
			echo "$(date '+%Y-%m-%d %T') : $fname - failed on the server <${ff}> on  ${ITERATION_COUNT} attempts... for port ${hport}" | tee -a  $LOG_FILE
			return 1
		fi

		
	done; #done for hostname for loop
	
	echo "$(date '+%Y-%m-%d %T') : Service jar is up and running for regression..." | tee -a  $LOG_FILE
	return 0;
}

check_reg_regression_status()
{
	echo "$(date '+%Y-%m-%d %T') : Checking regression jar is up for regression..." | tee -a  $LOG_FILE
	fname="check_reg_regression_status";
	ret_code=0

	typeset -i counter=1;   
	typeset -i failed_server_count=1     

	while [ true ]
	do
		if [[ $counter -ge  $ITERATION_COUNT ]]; 
		then
			echo "$(date '+%Y-%m-%d %T') : ERROR : Regression jar failed to start after $ITERATION_COUNT attempts " | tee -a  $LOG_FILE
			break;
		else
			sleep $SLEEPTIME
		fi

		regression_port=:$REG_PORT
		reg_status=$(netstat -tupln |grep $regression_port)

		if [[ -z $reg_status ]];
		then
			echo "$(date '+%Y-%m-%d %T') : $fname - Regression jar is not up after $counter attempt..." | tee -a  $LOG_FILE
			failed_server_count=1
		else
			echo "$(date '+%Y-%m-%d %T') : Regression jar is up and running for regression..." | tee -a  $LOG_FILE
			failed_server_count=0
			break;
		fi
		
		counter=$((counter+1))
	done; #done for while loop 

	if [[ $failed_server_count -ne 0 ]];
	then
		echo "$(date '+%Y-%m-%d %T') : ERROR : Regression jar failed to start after $ITERATION_COUNT attempts " | tee -a  $LOG_FILE
		return 1
	fi
	
	return 0;
}

########################## Function definition for server checks STOP######################

if [[ "$CHK_STATUS" == "CHECK_STATUS" ]];then
	
	if [[ "$ENV" == "ADAPTER" ]]; then	
		##check if the regression jars have come up....!!!!
		check_reg_adapter_for_curl
		RC=$?
		if [ "$RC" != "0" ];then
			echo "The regression adapter servers could not be started ...!!!!Please check" | tee -a  $LOG_FILE
			exit 1			
		fi
		
		##check if the regression jars have come up....!!!!
		check_reg_regression_status
		RC=$?
		if [ "$RC" != "0" ];then
			echo "The regression jar failed to start...!!!!Please check" | tee -a  $LOG_FILE
			exit 1			
		fi
	elif [[ "$ENV" == "SERVICE" ]];then
		##check if the regression jars have come up....!!!!
		check_reg_service_for_curl
		RC=$?
		if [ "$RC" != "0" ];then
			echo "The regression service servers could not be started ...!!!!Please check" | tee -a  $LOG_FILE
			exit 1			
		fi			
	fi

elif [[ "$CHK_STATUS" == "START_REG" ]]; then
	
	if [[ "$ENV" == "ADAPTER" ]]; then
		
		echo "$(date '+%Y-%m-%d %T') : Regression jar started for Adapter.." | tee -a  $LOG_FILE
		
		reg_latest=`cat $REG_PATH/versions/latest_version`
		adp_latest=`cat $PSHOME/usr/local/price-adapter/versions/latest_version_v2`	
		echo "$(date '+%Y-%m-%d %T') : Latest version of regression is $reg_latest.." | tee -a  $LOG_FILE
		echo "$(date '+%Y-%m-%d %T') : Latest version of adapter is $adp_latest.." | tee -a  $LOG_FILE
		
		if [[ "$BRANCH" == "Dev" ]]; then
			nohup java -jar $REG_PATH/versions/$reg_latest/ps-regression-${reg_latest}.jar server $REG_PATH/versions/$reg_latest/reg-test-dev.yml &
			reg_pid=$!
			echo $reg_pid > $REG_PATH/versions/reg_pid
			echo "$(date '+%Y-%m-%d %T') : PID for reg process is -->> $reg_pid" | tee -a  $LOG_FILE
			
			nohup java -jar  $PSHOME/usr/local/price-adapter/versions/$adp_latest-v2/price-adapter-developer-build-v2.jar server $PSHOME/usr/local/price-adapter/versions/$adp_latest-v2/reg_dev_adp.yml &
			adp_pid=$!
			echo $adp_pid > $REG_PATH/versions/adp_pid
			echo "$(date '+%Y-%m-%d %T') : PID for adp process is -->> $adp_pid" | tee -a  $LOG_FILE
			
		elif [[ "$BRANCH" == "PPE" ]]; then
			nohup java -jar $REG_PATH/versions/$reg_latest/ps-regression-${reg_latest}.jar server $REG_PATH/versions/$reg_latest/reg-test-ppe.yml &
			reg_pid=$!
			echo $reg_pid > $REG_PATH/versions/reg_pid
			echo "$(date '+%Y-%m-%d %T') : PID for reg process is -->> $reg_pid" | tee -a  $LOG_FILE
			
			nohup java -jar  $PSHOME/usr/local/price-adapter/versions/$adp_latest-v2/price-adapter-developer-build-v2.jar server $PSHOME/usr/local/price-adapter/versions/$adp_latest-v2/reg_ppe_adp.yml &
			adp_pid=$!
			echo $adp_pid > $REG_PATH/versions/adp_pid
			echo "$(date '+%Y-%m-%d %T') : PID for adp process is -->> $adp_pid" | tee -a  $LOG_FILE
	
		fi
		echo "$(date '+%Y-%m-%d %T') : Regression jar completed for Adapter.." | tee -a  $LOG_FILE
		
	elif [[ "$ENV" == "SERVICE" ]]; then
		
		echo "$(date '+%Y-%m-%d %T') : Regression jar started for Service.." | tee -a  $LOG_FILE
		
		srvc_latest=`cat $PSHOME/usr/local/price-service/versions/latest_version_v3`
		echo "$(date '+%Y-%m-%d %T') : Latest version of service is $reg_latest.." | tee -a  $LOG_FILE
		
		if [[ "$BRANCH" == "Dev" ]]; then
			nohup java -jar  $PSHOME/usr/local/price-service/versions/$srvc_latest-v3/price-service-developer-build-v3.jar server $PSHOME/usr/local/price-service/versions/$srvc_latest-v3/reg_dev_srvc.yml &
			srvc_pid=$!
			echo $srvc_pid > $REG_PATH/versions/srvc_pid
			echo "$(date '+%Y-%m-%d %T') : PID for srvc process is -->> $srvc_pid" | tee -a  $LOG_FILE
			
		elif [[ "$BRANCH" == "PPE" ]]; then
			nohup java -jar  $PSHOME/usr/local/price-service/versions/$srvc_latest-v3/price-service-developer-build-v3.jar server $PSHOME/usr/local/price-service/versions/$srvc_latest-v3/reg_ppe_srvc.yml &
			srvc_pid=$!
			echo $srvc_pid > $REG_PATH/versions/srvc_pid
			echo "$(date '+%Y-%m-%d %T') : PID for srvc process is -->> $srvc_pid" | tee -a  $LOG_FILE
		fi

		echo "$(date '+%Y-%m-%d %T') : Regression jar completed for Service.." | tee -a  $LOG_FILE
	fi
else
	echo "$(date '+%Y-%m-%d %T') : Wrong param... Please check!!!" | tee -a  $LOG_FILE
	exit 1
fi

echo "$(date '+%Y-%m-%d %T') : Job $PROG_NAME completed successfully for $ENV environment.. Hostname is <`hostname`>..." | tee -a  $LOG_FILE
exit $?