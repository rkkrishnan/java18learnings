import javaposse.jobdsl.dsl.DslScriptLoader
import javaposse.jobdsl.dsl.MemoryJobManagement
import javaposse.jobdsl.dsl.ScriptRequest
import org.custommonkey.xmlunit.Diff
import org.custommonkey.xmlunit.XMLUnit
import spock.lang.Shared

trait Commons {
    File jobs = new File("jobs")

    List<File> collectFiles(File file, filter) {
        def list = []
        file.eachFileMatch(filter) {
            list << it
        }

        return list
    }

    def generateAndCollectConfigs(List<File> files){
        files.collect{ generateConfigForDsl(it) }.inject([:]){ result, map ->
            result << map.configs
            result << map.views
        }
    }

    def generateConfigForDsl(File file){
        println file.name
        def url = file.parentFile.toURI().toURL()
        def sr = new ScriptRequest(null, file.text, url)
        def jm = new MemoryJobManagement()

        addScriptsFolder(jm)

        def dsl = new DslScriptLoader(jm)
        dsl.runScripts([sr])

        return [
            configs: jm.savedConfigs,
            views: jm.savedViews
        ]
    }

    /**
     * registers scripts so they will be visible for readFromWorkspace method in job dsl
     */
    void addScriptsFolder(MemoryJobManagement jm) {
		def scripts = new File("scripts")
        scripts.eachFileRecurse {
			def path = it.canonicalPath.replace(scripts.canonicalPath, "scripts")
            jm.availableFiles[path] = it.canonicalPath
        }
    }
}