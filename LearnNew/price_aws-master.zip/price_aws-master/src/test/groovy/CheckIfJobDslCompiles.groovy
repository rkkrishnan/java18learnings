import spock.lang.Shared
import spock.lang.Specification

class CheckIfJobDslCompiles extends Specification implements Commons {

	def "try to run all /jobs/*.groovy"() {
		given:
			def allJobs = collectFiles(jobs, ~".*\\.groovy")
		expect:
			generateAndCollectConfigs(allJobs) != null
	}
}
