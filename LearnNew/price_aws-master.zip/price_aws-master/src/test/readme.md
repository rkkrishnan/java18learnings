### Purpose

Job dsl can get big and repetitive. This folder store previous version of job dsl so we can test refactorings easily.

#### "xmls" folder

- Store previous / prototype version in xml
- You can use it to check if dsl have change
- You can use it to test if your custom configuration (job dsl direct xml generation) works as expected

`CompareWithXml.groovy` compares dsl output from `jobs` with content of `src/test/xmls`.

You can check if they are the same by running `gradle testXml` or `gradle testXmlCompare`

#### Implementation notes

I am using

- [Groovy](http://www.groovy-lang.org/) - for sanity
- [Spock framework](http://spockframework.github.io/spock/docs/1.0/spock_primer.html) - for nice tests
- XmlUnit - to compare xml output in semantic way
- DslScriptLoader, ScriptRequest and MemoryJobManagement

See method generateConfigForDsl in [Commons.groovy](src/test/groovy/Commons.groovy)
to understand how I invoke job dsl.