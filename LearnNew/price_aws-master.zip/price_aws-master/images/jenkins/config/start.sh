#!/usr/bin/env bash

# this file allows docker image to take precedence over mounted volume
# which allows overriding some settings when deploying new version


# always override init scripts at startup
rm -rf /var/jenkins_home/init.groovy.d/*
cp -rp /usr/share/jenkins/ref/init.groovy.d/* /var/jenkins_home/init.groovy.d/

# always reinstall plugins
rm -rf /var/jenkins_home/plugins/*

# remove all node data - we might have orphan nodes (slaves that will never be killed by jenkins)
# but there should be no problems with startup because of node no longer existing.
rm -rf /var/jenkins_home/nodes/*

# always override config at startup
#cp -rp /usr/share/jenkins/ref/config.xml /var/jenkins_home

export JAVA_OPTS="-Dhudson.DNSMultiCast.disabled=true"
./bin/tini -- /usr/local/bin/jenkins.sh
