def aws = true
def ip

try {
  def metadata = new URL("http://instance-data/latest/dynamic/instance-identity/document").text
  ip = new groovy.json.JsonSlurper().parseText(metadata).privateIp
  println "Running on AWS, ip: $ip"
} catch(e) {
  aws = false

  def system = System.properties['os.name']
  println "System: $system"

  if(System.env["ARTIFACTORY_IP"]) {
      ip = System.env["ARTIFACTORY_IP"]
  } else {
    ip = "192.168.99.100" // thats bit hardcoded - default ip of docker machine on mac / windows, on linux you have to provide ARTIFACTORY_IP
  }
  println "Tried to read AWS data but got [$e], using $ip instead"
}

System.properties["INSIDE_AWS"] = aws
System.properties["JENKINS_MASTER_IP"] = ip
System.properties["MAVEN_REPO"] = "http://bintray.com/bintray/jcenter"

def repo = "http://$ip:8081/artifactory/jcenter/"


// This if could be removed, bit better way to do that would be to add artifactory to
// docker-compose.yml and mount it's volume so we would make it persistent (and faster :) )
if(!canConnect(repo)) {
	println "Artifactory does not respond, trying to start it"

  def checkContainer = "docker inspect artifactory".execute()
  checkContainer.waitFor()
  def artifatoryContainerExists = checkContainer.exitValue() == 0

  if(artifatoryContainerExists) {
     println "docker start artifactory".execute().err.text
  } else {
	   println "docker run -d  -p 8081:8081 --name artifactory jfrog-docker-reg2.bintray.io/jfrog/artifactory-oss".execute().err.text
  }
}

println "Giving artifactory 50 sec to start"
int i
for(i=1; i<50; i++) {
  if(canConnect(repo)) {
    break;
  } else {
    println "still wating"
  }
  Thread.sleep(1000)
}

if(canConnect(repo)){
	println "Artifactory is running after $i seconds, seting it as repo :)"
	System.properties["MAVEN_REPO"] = repo
} else {
	println "Artifactory is not running :("
}


def canConnect(repo){
  try {
	new URL(repo).text
	return true
  } catch(e){
	return false
  }
}
