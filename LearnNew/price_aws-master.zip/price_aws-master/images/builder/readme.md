# Builder Docker image
## ubuntu:15.10

This is currently the image we are using to build the COES service this is portable and you can use the scripts/build_docker.sh
script in the COES repository to build the repo on your own machine.

We chose ubuntu almost at random since it seems to work. Idealy we will move to alpine for a minimalistic image (quicker to start and smaller on storage)

Currently the following packages are included to support different aspects of the build

| Name of package            | description|
| -------------              | -------------|
|ipuntils-ping               |checking if couchbase docker image is up|
| wget/curl                  | downloading the java jar and for performance test|
| lsof                       | used in the build to check for file handle leaks|
| software-properties-common | for the java download step|
| fontconfig                 | for the phantomjs tests in the search-ui|


# Users
currently there is a ec2-user(500) added and a group docker(497) added. This is so that the docker
socket can be used on the host (gid 497) and that the user folder is created ( HOME /home/ec2-user ).
This enables us to spawn the couchbase docker images from this image.

#Docker
We currently only get the docker cli that we attach to the mapped socket using  https://get.docker.io/builds/Linux/x86_64/docker-1.9.1

#java

Currently using **Oracle 8** installer for ubuntu from **webupd8team** from the apt-get repository ppa:webupd8team/java.
This may change but it is a decent way to get the most up to date java without having to specify the patch version.

