# PRICE java docker container
This container is based on common:latest container that you can find in ECS repository 780223221743.dkr.ecr.eu-west-1.amazonaws.com/common:latest

In order to run it properly, we need to provide a config file in your docker container context which it will be used by the entry point script of the docker image.

This container is setup to download the configuration and binaries needed for the PRICE container and
start the container.

The following environment variables can be set to configure the PRICE startup.

## Environment setup

| Name                     | Description          | Defaults |
|:---                      |:---                  |:---      |
| COUCHBASE                | A comma seperated list of the couchbase cluster. This overrides the configuration file version. |  configuration supplied |
| java.naming.provider.url | The Jndi location. This overrides the configuration file version | supplied in the configuration "tcp://localhost:61616" |
| MAX_RAM                  | The Xmx value to supply to the jvm.  | 2g |
| REPO_URL                 | The base url of the repostitory to download from. |  https://s3-eu-west-1.amazonaws.com/tesco-price-service/artifacts/ |
| VERSION                  | The PRICE code version to download. | 2.0.0-SNAPSHOT |
| ENVIRONMENT              | The environment from the configuration zip to use.| /build/vagrant/test |
| JAVA_OPTS                | Any other special jvm parameters you whish to supply|  |
| JMX_PORT                 | Open JMX on a given port in the docker image. CURRENTLY NOT SECURED. The given certificate should be installed in the image at some point |  |
| DEBUG_PORT               | Enable debugging and open the debug port on the given port.  |  |
| JAVA_OPTS                | Any other special jvm parameters you wish to supply|  |
| DEBUG                    | turn on the -x bash debug to debug out the startup script if it is failing|  |

There is one mapped volume /var/log that is used to access the price logs.
