#!/bin/sh -e
set -e
[ -n "${DEBUG}" ] && set -x

dir="/price/opt"
jar="$dir/price.jar"
version=${VERSION:-"4.0-SNAPSHOT"}
repository=${PRICE_REPO:-"https://s3-eu-west-1.amazonaws.com/tesco-price-service"}
url=${PRICE_URL:-"${repository}/${version}/price-service-${version}-all.jar"}
opts=${JAVA_OPTS:- " -server -Xmx1G"}
instances=${INSTANCES:- `cat /proc/cpuinfo | grep processor | wc -l`}

__download_from(){
   echo "downloading $1 to $2"
   curl -f -sS "$1" -o $2
}

__download(){
  echo "downloading Price artifacts from ${repository}"
  mkdir -p ${dir} || exit 1
  __download_from ${url} ${jar} || exit 1
}

__start(){
  echo "## Starting Java ##"
  java -version
  echo
  echo "Running price service instances: ${instances}"
  echo "Java flags: ${opts}"
  java ${opts} -jar ${jar} -instances ${instances}
}

echo "## Starting Price Service ##"
echo "============================"
__download
__start