#!/bin/bash -e

source ./scripts/common/stack.sh

healthCheck="HTTP:8080/v4/quote"
DEV="DEV"
PPE="PPE"
LIVE="LIVE"

__create_by_environment(){
    echo "############### CREATING $1 LB #################"
    echo "subnet2:$3"
    echo "subnet1:$2"
    name="PRICE-$1-LB"
    aws cloudformation create-stack --capabilities CAPABILITY_IAM --stack-name ${name} \
    --template-body file://./scripts/environment/load_balancer/template.json \
    --parameters  ParameterKey='ClusterName',ParameterValue=${name} \
    ParameterKey='subnet1',ParameterValue=$2 \
    ParameterKey='subnet2',ParameterValue=$3 \
    ParameterKey='SecurityGroup',ParameterValue=$4 \
    ParameterKey='HealthCheck',ParameterValue=${healthCheck}

    wait_for_stack_success ${name}
}

create_load_balancer(){
    _subnetDev1=`get_subnet_id DEV-1A`
    _subnetDev2=`get_subnet_id DEV-1C`
    _subnetPpe1=`get_subnet_id PPE-1A`
    _subnetPpe2=`get_subnet_id PPE-1B`
    _subnetLive1=`get_subnet_id LIVE-PUBLIC-1A`
    _subnetLive2=`get_subnet_id LIVE-PUBLIC-1B`
    _usersHttpDevSgId=`get_security_group_id_by_env_and_name PPE Users_HTTP`
    _usersHttpLiveSgId=`get_security_group_id_by_env_and_name LIVE Users_HTTP`

    __create_by_environment ${DEV} ${_subnetDev1} ${_subnetDev2} ${_usersHttpDevSgId}
    __create_by_environment ${PPE} ${_subnetPpe1} ${_subnetPpe2} ${_usersHttpDevSgId}
    __create_by_environment ${LIVE} ${_subnetLive1} ${_subnetLive2} ${_usersHttpLiveSgId}

}