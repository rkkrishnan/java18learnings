## AWS environment
![My image](../../src/main/resources/images/aws_price.png)

### Intro

- In order to provide a pipeline we need to provide first a AWS environment where run our pipeline.
- We decide to use cloudformation, which is a very useful tool to communicate with the AWS API. For more info here https://aws.amazon.com/cloudformation/
- To segregate responsibility and help the maintenance of the cloud formation template, we decide to split up into multiple the cloudformation templates.
    - vpc
      - [dev/ppe](vpc/dev/template.json)
      - [live](vpc/live/template.json)
    - [security group](security_group/template.json)
    - [vpc peering connection](vpc_peer/template.json)
    - [s3](s3/template.json)
    - [jenkins](jenkins/template.json)
    - [elb](load_balancer/template.json)

### Script

Having import all dependencies and scripts

```
source ./scripts/environment/create.sh
```

We proceed to create the AWS environment

#### Create AWS environment

Those are the stack templates that we use in order to create the AWS environment:

- VPC-DEV: Vpc, subnet, routeTables, end-points and networking for dev and ppe environment. 
- VPC_LIVE: Vpc, subnet, routeTables, end-points and networking for live environment. 
- VPC-PEERING-CONNECTION: A vpc peering connection to communicate dev/ppe vpc with live vpc.
- SECURITY-GROUPS: All the security groups for dev/ppe and live environment.
- JENKINS: Jenkins machine where we will run our pipeline.
- S3: Repository and policy to push/pull resources from our VPC´s
- PRICE-DEV-LB: Load balancer for dev environment.
- PRICE-PPE-LB: Load balancer for ppe environment.
- PRICE-LIVE-LB: Load balancer for live environment.


