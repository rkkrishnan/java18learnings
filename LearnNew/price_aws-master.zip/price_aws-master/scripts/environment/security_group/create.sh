#!/bin/bash

source ./scripts/common/stack.sh
source ./scripts/common/utils.sh

SECURITY_GROUPS="SECURITY-GROUPS"


create_security_group(){
       echo "############## CREATING SECURITY GROUPS ##############"
       aws cloudformation create-stack --capabilities CAPABILITY_IAM --stack-name ${SECURITY_GROUPS} \
                --template-body file://./scripts/environment/security_group/template.json \
                --parameters ParameterKey='vpcDev',ParameterValue=`get_vcp_id "DEV/PPE"` \
                             ParameterKey='vpcLive',ParameterValue=`get_vcp_id "LIVE"`
       wait_for_stack_success ${SECURITY_GROUPS}
}

