#!/bin/bash

source ./scripts/common/stack.sh
source ./scripts/common/utils.sh

S3="S3"

create_s3(){
       echo "################### CREATING S3 ####################"
       aws cloudformation create-stack --capabilities CAPABILITY_IAM --stack-name ${S3} \
                --template-body file://./scripts/environment/s3/template.json \
                 --parameters ParameterKey='vpcDev',ParameterValue=`get_vcp_id "DEV/PPE"` \
                             ParameterKey='vpcLive',ParameterValue=`get_vcp_id "LIVE"`
       wait_for_stack_success ${S3}
}



