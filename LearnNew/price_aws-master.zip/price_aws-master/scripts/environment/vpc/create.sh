#!/bin/bash

source ./scripts/common/stack.sh
source ./scripts/common/utils.sh


VPC_DEV="VPC-DEV"
VPC_LIVE="VPC-LIVE"


create_dev_vpc(){
       echo "################# CREATING DEV VPC ##################"
       aws cloudformation create-stack --capabilities CAPABILITY_IAM --stack-name ${VPC_DEV} \
                --template-body file://./scripts/environment/vpc/dev/template.json
      wait_for_stack_success ${VPC_DEV}

}

create_live_vpc(){
       echo "################# CREATING LIVE VPC ##################"
       aws cloudformation create-stack --capabilities CAPABILITY_IAM --stack-name ${VPC_LIVE} \
                --template-body file://./scripts/environment/vpc/live/template.json
       wait_for_stack_success ${VPC_LIVE}
}
