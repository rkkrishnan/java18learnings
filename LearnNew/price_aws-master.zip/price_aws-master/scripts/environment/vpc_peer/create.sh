#!/bin/bash

source ./scripts/common/stack.sh
source ./scripts/common/utils.sh

VPC_PEERING_CONNECTION="VPC-PEERING-CONNECTION"

create_vpc_peering_connection(){
       echo "############## CREATING PEERING CONNECTION ############"
       aws cloudformation create-stack --capabilities CAPABILITY_IAM --stack-name ${VPC_PEERING_CONNECTION} \
                --template-body file://./scripts/environment/vpc_peer/template.json \
                --parameters ParameterKey='vpcDev',ParameterValue=`get_vcp_id "DEV/PPE"` \
                             ParameterKey='vpcLive',ParameterValue=`get_vcp_id "LIVE"`
       wait_for_stack_success ${VPC_PEERING_CONNECTION}
}


