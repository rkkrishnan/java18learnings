#!/bin/bash

source ./scripts/common/stack.sh
source ./scripts/common/utils.sh
source ./scripts/environment/jenkins/create.sh
source ./scripts/environment/s3/create.sh
source ./scripts/environment/security_group/create.sh
source ./scripts/environment/vpc/create.sh
source ./scripts/environment/vpc_peer/create.sh
source ./scripts/environment/load_balancer/create.sh


__create_environment(){
    echo "############### CREATING ENVIRONMENT #################"
    create_dev_vpc
    create_live_vpc
    create_vpc_peering_connection
    create_s3
    create_security_group
    create_jenkins
    create_load_balancer
}


[[ "$BASH_SOURCE" != "$0" ]] && return

__create_environment


