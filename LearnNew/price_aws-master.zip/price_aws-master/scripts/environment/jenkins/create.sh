#!/bin/bash

source ./scripts/common/stack.sh
source ./scripts/common/utils.sh

JENKINS="JENKINS"

create_jenkins(){
       echo "############## CREATING JENKINS INSTANCE ##############"
       subnet=`get_subnet_id DEV`
       jenkinsSgId=`get_security_group_id_by_env_and_name PPE Jenkins_master`
       usersSSHSgId=`get_security_group_id_by_env_and_name PPE Users_SSH`
       echo "subnet:$subnet"
       echo "jenkins sg:$jenkinsSgId"
       echo "users ssh sg:$usersSSHSgId"
       aws cloudformation create-stack --capabilities CAPABILITY_IAM --stack-name ${JENKINS} \
                --template-body file://./scripts/environment/jenkins/template.json \
                --parameters ParameterKey='subnet',ParameterValue=$subnet \
                             ParameterKey='jenkinsSg',ParameterValue=$jenkinsSgId \
                             ParameterKey='usersSshSg',ParameterValue=$usersSSHSgId
       wait_for_stack_success ${JENKINS}
       wait_for_instance_running ${JENKINS}
}



