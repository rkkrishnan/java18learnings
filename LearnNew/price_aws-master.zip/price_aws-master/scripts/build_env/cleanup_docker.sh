#!/usr/bin/env bash
# removing all docker images running in given network before or after actual build so there is no old containers running
# it is needed before and after build, because if builds times out (or have been canceled) post build steps are not run
# and next build may fail in random ways it would be quite random as executor number changes so some builds may fail other
# not and postbuild might be executed after this failure so all subsequent builds would run ok again

echo "Killing instances from network $NETWORK if exist"
names=`docker ps | sed "s/.* //" | grep $NETWORK`
echo "Instances found in $NETWORK: $names"
for n in $names
do
    echo "killing container: $n"
    docker kill $n
done

echo "Removing containers from network $NETWORK if exist"
names=`docker ps -a | sed "s/.* //" | grep $NETWORK`
echo "Containers found in $NETWORK: $names"
for n in $names
do
    echo "removing container: $n"
    docker rm $n
done

echo "Removing network $NETWORK if exist"
docker network rm $NETWORK && echo "removed network $NETWORK" || echo "network: $NETWORK does not exist?" && docker network ls