#!/usr/bin/env bash

GIT_COMMITTER_DATE=`git show -s --format=%ct $GIT_COMMIT`

GIT_COMMIT=${GIT_COMMIT: -8}

PRICE_VERSION="$GIT_COMMITTER_DATE-$GIT_COMMIT"

echo "*********** JENKINS JOB PRICE VERSION: $PRICE_VERSION **************"

echo "PRICE_VERSION=$PRICE_VERSION" >> env.properties