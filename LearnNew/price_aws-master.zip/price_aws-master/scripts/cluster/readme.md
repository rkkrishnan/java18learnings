
## Cluster
![My image](../../src/main/resources/images/cluster.jpg)

In order to create our cluster we´re using AWS ECS. To reference to the official documentation look here: http://docs.aws.amazon.com/AmazonECS/latest/developerguide/Welcome.html

In all sub folders we define the templates to be used by cloud formation to create our clusters.

For now we´re adding on Jenkins the functionality to destroy and create clusters by environment.

In order to create a cluster we need to provide some environment variables to be set on Jenkins jobs.


### Environment setup

| Name                     | cloud formation variable name | Description                                                |
|:---                      |:---                           |:---                                                        |
| SUBNET                   |subnet                         | Subnet where it will be initiated                          |
| CLUSTER_NAME             | ClusterName                   | Name of the cluster to be showed on ECS                    |   
| CLUSTER_NAME             | instanceName                  | Instance name to be showed on Ec2 Instances                |
| ECS-${STACK_NAME}        | instanceReference             | Group instance to be showed on Ec2 Instances               |
| LB_NAME                  |   LoadBalancer                | Load balancer name to join the new cluster instances       |  
| PRICE_VERSION             |  Version                      | Version of artifact to be run on Docker image              | 
| ENVIRONMENT              | Environment                   | Environment config files to be used by docker image        | 
| SECURITY_GROUP_1         |     SecurityGroup1            | SecurityGroup Id                                           |
| SECURITY_GROUP_2         |     SecurityGroup2            | SecurityGroup Id                                           |
| SECURITY_GROUP_3         |     SecurityGroup3            | SecurityGroup Id                                           |


Then running the script create.sh should start the creation of the cluster.

Also, in that case we want to destroy the cluster, we should set again our environment variables and invoke destroy.sh script.

For now the creation of clusters using those scripts are just for ELB. 

For the creation of PRICE cluster reference to [deployment section] (../deployment/readme.md)


## ECS notes

### Problems

- Does not exactly fits our usecase, it designed to support using cpus efectivelly
 (i.e. close to 100%), by running many different tasks on same machine.
 We want to have one service on one machine. It also designed to keep task in queues if there is no room.
- Autoscaling - designed to scale if you run out of reasources (cpu / network) but on 2 levels
  - Autoscaling of services - you have task definition wrap it in service and can control number of tasks
  - Machines - you need separate ec2 autoscaling policy that is also based on resources and does not understand
  that you can't run all tasks because there is not enough resources in cluster). It could be worked around by
  creating a lamda that would create new machines when tasks fails to be deployed as requested by service autoscaling.


### Scripts


#### Add ec2 instance to ecs cluster


If you are running a ec2 machine with aws installed you can connect it to a cluster with AWS CLI:
`aws ecs register-container-instance clusterName`

But it is highly unlikely you would want to do that this way.

You should try AWS CLI:

```
aws ec2 run-instances --iam-instance-profile Name=ecsInstanceRole --image-id ami-f66de585 --count 1 --instance-type t2.micro --key-name some-key --security-groups PRICE ssh --user-data "#!/bin/bash
echo ECS_CLUSTER=cluster_name >> /etc/ecs/ecs.config"
```

`ami-f66de585` is AMI id from eu-west-1 that is ECS optimized (runs ecs agents etc.).

or cloud formation:

```json
    {
        "NiceNameForInstance" : {
            "Type": "AWS::EC2::Instance",
            "Properties": {
            "IamInstanceProfile": "ecsInstanceRole",
            "ImageId": "ami-f66de585",
            "InstanceType": "t2.micro",
            "KeyName": "some-key",
            "UserData": { "Fn::Base64" : { "Fn::Join" : ["", [
                "#!/bin/bash -xe\n",
                "echo ECS_CLUSTER=cluster_name",
                " >> /etc/ecs/ecs.config\n"
            ]]}}
          }
        }
    }
```

It is important to assign a role that have access to ecs and to assign ecs optimized AMI,
as this comes with ecs agent which reads the config file that "User Data" is generating.
