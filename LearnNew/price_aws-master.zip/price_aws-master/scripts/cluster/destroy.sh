#!/bin/bash

destroy_cluster(){
    echo "Deleting cluster $1"
    aws ecs delete-cluster --cluster $1
}