#!/bin/bash

source ./scripts/common/stack.sh
source ./scripts/common/utils.sh

source ${HEALTH_CHECK}


create_cluster(){
    aws ecs create-cluster --cluster-name ${CLUSTER_NAME}
}

create_ec2_instance(){
    echo "********** CREATING CONTAINER $1  *************"
    stackName=$1
    subnet=$2
    securityGroup1=$3
    securityGroup2=$4
    securityGroup3=$5

    echo "subnet $subnet"
    echo "securityGroup1 $securityGroup1"
    echo "securityGroup2 $securityGroup2"
    echo "securityGroup3 $securityGroup3"

    aws cloudformation create-stack --capabilities CAPABILITY_IAM --stack-name ${stackName} \
    --template-body file://./scripts/cluster/ec2_instance/template.json \
    --parameters ParameterKey='subnet',ParameterValue=${subnet} \
        ParameterKey='ClusterName',ParameterValue=${CLUSTER_NAME} \
        ParameterKey='instanceName',ParameterValue="${CLUSTER_NAME}" \
        ParameterKey='instanceReference',ParameterValue="ECS-${STACK_NAME}" \
        ParameterKey='AssociatePublicIpAddress',ParameterValue=$ASSOCIATE_PUBLIC_IP_ADDRESS \
        ParameterKey='SecurityGroup1',ParameterValue=${securityGroup1} \
        ParameterKey='SecurityGroup2',ParameterValue=${securityGroup2} \
        ParameterKey='SecurityGroup3',ParameterValue=${securityGroup3}
}

create_service(){
    echo "********** CREATING SERVICE PER CLUSTER $CLUSTER_NAME *************"

    aws cloudformation create-stack --capabilities CAPABILITY_IAM --stack-name ${STACK_NAME} \
    --template-body file://${CLUSTER_FILE} \
    --parameters ParameterKey='ClusterName',ParameterValue=${CLUSTER_NAME} \
        ParameterKey='LoadBalancer',ParameterValue=${LB_NAME} \
        ParameterKey='Version',ParameterValue=${PRICE_VERSION} \
        ParameterKey='Environment',ParameterValue=${ENVIRONMENT} \
        ParameterKey='DesiredCount',ParameterValue=$1

}

