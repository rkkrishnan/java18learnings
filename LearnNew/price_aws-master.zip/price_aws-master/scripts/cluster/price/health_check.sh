#!/bin/bash

source ./scripts/common/utils.sh

check_status(){
    result=`curl -s "$1:8080" > /dev/null`
    rc=$?
}


wait_service_up(){
    for private_ip in `get_instance_private_ip $1`
    do
        echo "Checking health status of Price service ${private_ip}"
        wait_service_start check_status $private_ip
    done
}

wait_service_down(){
    for private_ip in `get_instance_private_ip $1`
    do
        echo "Waiting for Price service to stop ${private_ip}"
        wait_service_stop check_status $private_ip
        echo ""
        echo "Price service stopped"
    done
}
