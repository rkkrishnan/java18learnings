#!/bin/bash

source ./scripts/common/utils.sh
source ./scripts/common/stack.sh
source ./scripts/common/try_catch.sh
source ./scripts/cluster/create.sh
source ./scripts/cluster/destroy.sh

__init(){
    _oldStackName=""
    _oldClusterName=""
    _desiredNumber=0
    _oldStackNames=`get_previous_versions ${STACK_NAME}`
    echo "Old stack names:$_oldStackNames"
    _oldClusterNames=`get_previous_versions ${CLUSTER_NAME}`
    echo "Old cluster names:$_oldClusterNames"

    [[ $SG_ENV = "DEV" ]] || [[ $SG_ENV = "PPE" ]] && HTTP_ENV="PPE" || HTTP_ENV="LIVE"

    _securityGroup1=`get_security_group_id_by_env_and_name ${SG_ENV} Price_service`
    _securityGroup2=`get_security_group_id_by_env_and_name ${SG_ENV} Users_SSH`
    _securityGroup3=`get_security_group_id_by_env_and_name ${HTTP_ENV} Users_HTTP`
}

__rollback(){
    echo "*********** DEPLOYMENT ERROR ON CLUSTER ${CLUSTER_NAME} ROLLING BACK **********"
    _oldStackNames=${STACK_NAME}
    _oldClusterNames=${CLUSTER_NAME}
    __destroy_old_clusters
}

__apply_on_subnets(){
    function=$1
    export IFS="," _subnets=$SUBNETS
    for _subnet in ${_subnets}; do
        ${function} ${_subnet}
    done
}

__get_ec2_stack_name(){
    echo "Ec2-$STACK_NAME-$1"
}

__get_old_ec2_stack_name(){
    echo "Ec2-$_oldStackName-$1"
}

__destroy_old_service(){
    delete_stack ${_oldStackName}
    wait_for_stack_delete ${_oldStackName}
}

__wait_for_ec2_instance_destroyed (){
    _subnetId=`get_subnet_id $1`
    _oldEc2StackName=`__get_old_ec2_stack_name ${_subnetId}`
    wait_for_stack_delete ${_oldEc2StackName}
}

__destroy_ec2_instance(){
    _subnetId=`get_subnet_id $1`
    _oldEc2StackName=`__get_old_ec2_stack_name ${_subnetId}`
    delete_stack ${_oldEc2StackName}
}

__destroy_old_clusters(){
    echo "*********** BLUE DEPLOYMENT ON CLUSTERS ${_oldClusterNames} **********"
    export IFS=" " _oldStackNames=${_oldStackNames}
    for _oldStackName in ${_oldStackNames}; do
        __destroy_old_service
        __apply_on_subnets __destroy_ec2_instance
        __apply_on_subnets __wait_for_ec2_instance_destroyed
        wait_service_down ${_oldStackName}
    done

    export IFS=" " _oldClusterNames=${_oldClusterNames}
    for _oldClusterName in ${_oldClusterNames}; do
        destroy_cluster ${_oldClusterName}
    done

}

__wait_for_ec2_instance(){
    _subnetId=`get_subnet_id $1`
    _ec2stackName=`__get_ec2_stack_name ${_subnetId}`
    wait_for_stack_success ${_ec2stackName}
}

__create_ec2_instance(){
    _subnetId=`get_subnet_id $1`
    _ec2stackName=`__get_ec2_stack_name ${_subnetId}`
    create_ec2_instance ${_ec2stackName} ${_subnetId} ${_securityGroup1} ${_securityGroup2} ${_securityGroup3}
    ((_desiredNumber++))
}

__create_service(){
    create_service ${_desiredNumber}
    wait_for_stack_success ${STACK_NAME}
    wait_for_instance_running ${CLUSTER_NAME}
    wait_service_up ${STACK_NAME}
}

__deploy_blue_green(){
    echo "*********** BLUE-GREEN DEPLOYMENT ON CLUSTER ${CLUSTER_NAME} **********"
    try
    (
        create_cluster
        __apply_on_subnets __create_ec2_instance
        __apply_on_subnets __wait_for_ec2_instance
        __create_service
    )
    catch || {
        __rollback
        return
    }
    __destroy_old_clusters
}

__init
__deploy_blue_green
