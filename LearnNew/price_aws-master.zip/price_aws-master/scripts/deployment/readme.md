## Blue-Green Deployment  
![My image](../../src/main/resources/images/blue-green.png)

### Intro

- In order to avoid down time in our deployment system, we decide to follow the blue-green deployment standard.
- For the deployment system we decide to use cloudformation, which is a very useful mechanism to communicate with the AWS API. For more info here https://aws.amazon.com/cloudformation/
- For now we´e using the most simple approach of the blue-green depoyment, which consist in the follow steps
  - We create a new cluster, container instance(so many as we want), service and task, using cloudformation.
  - The new cluster machines are then add it into the load balancer.
  - Once that the new cluster is up and running, we use the health_check script to ensure that app is working.
  - In case that a previous version of the cluster was running, both version are attach to the load balancer for a moment.
  - We delete the old cluster version using cloudformation leaving just the last version of the cluster running.

We proceed to create the new cluster, and destroy the old one.

#### Create cluster 


In order to create the cluster we follow the next steps:

- Create new cluster with format ${PRICE-ENV-BUILD_NUMBER}.
- Create some many ec2 instance as we describe. 
- We wait until cloudformation finish to create the stack.
- We wait until the ec2 instance is completely initialized.
- We check that app service is running as we expect.
- If something goes wrong during the deployment we rollback
- If everything finish as we expect we proceed to destroy the old cluster


#### Destroy cluster

Once the new cluster is up and running properly, and we attach to the load balancer, we can proceed to delete the old cluster version

- We calculate the previous version of the cluster and stack
- We use cloudformation to revert all actions done on the previous stack, which include:
  - Delete service.
  - Delete ec2 instance.
  - Unregister form the load balancer.
- Destroy cluster
- Wait for all machines to go down.  
 

### Scripts

Having import all dependencies scripts

```
source ./scripts/common/utils.sh
source ./scripts/common/stack.sh
source ./scripts/common/try_catch.sh
source ./scripts/cluster/create.sh
source ./scripts/cluster/destroy.sh
```

```
__deploy_blue_green(){
    try
    (
        create_cluster
        __apply_on_subnets __create_ec2_instance
        __apply_on_subnets __wait_for_ec2_instance
        __create_service
    )
    catch || {
        __rollback
        return
    }
    __destroy_old_cluster
}
}
```

