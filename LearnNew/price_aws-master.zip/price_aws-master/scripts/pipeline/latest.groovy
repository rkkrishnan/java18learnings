try {
     new XmlParser().parse(new URL("http://tesco-price-service.s3.amazonaws.com").openStream())
            .Contents.Key.collect {
        (it =~ "value=\\[(\\d+.\\d+).(\\d+)-(\\w*)")[0][1..-1]

    }.collect{it[0] + "." + it[1] + "-" + it [2] as String }.reverse().take(20)
} catch(e) {
    [e]
}