#!/bin/bash -x
#Global script to gather all the utils functionality
timeout=0


__is_timeout(){
    if [ $timeout -lt 50 ]
    then
        sleep 1
        echo -n "."
        timeout=$((timeout+1))
    else
        echo "Failed timed out."
        exit 1
    fi
}

__instance_state(){
    echo `aws ec2 describe-instances --filters "Name=tag-value,Values=$1" | \
                                                 jq '.Reservations[].Instances[]' | \
                                                 jq 'select(.State.Name!="terminated")' | \
                                                 jq '.InstanceId' | \
                                                 xargs -I {} aws ec2 describe-instance-status --instance-ids {} | \
                                                 jq -r '.InstanceStatuses[].InstanceStatus.Details[].Status'`
}

__get_cluster_list(){
    echo `aws ecs list-clusters |\
                                jq '.clusterArns[]' | \
                                jq  'match("(.*cluster/?)\/(.*$)").captures[1].string'`
}

__get_previous_cluster(){
     echo `aws ecs list-clusters |  jq '.clusterArns[]' | \
                                    jq 'select(. | contains("'$1'"))' | \
                                    jq -r 'match("(.*cluster/?)\/(.*$)").captures[1].string'`
}

__toUpperCase(){
    echo $1 | awk '{print toupper($0)}'
}

get_instance_private_ip(){
   echo `aws ec2 describe-instances --filters "Name=tag-value,Values=$1" | \
                                                       jq '.Reservations[].Instances[]' | \
                                                       jq 'select(.State.Name!="terminated")' | \
                                                       jq -r '.PrivateIpAddress'`
}

get_instance_public_ip(){
   echo `aws ec2 describe-instances --filters "Name=tag-value,Values=$1" | \
                                                       jq '.Reservations[].Instances[]' | \
                                                       jq 'select(.State.Name!="terminated")' | \
                                                       jq -r '.PublicIpAddress'`
}

wait_service_start(){
    $1 $2
    while [ $rc  -ne 0 ]
    do
       __is_timeout
       $1 $2
    done
}

wait_service_stop(){
    $1 $2
    until [ $rc  -ne 0 ]
    do
       __is_timeout
       $1 $2
    done
}

is_cluster_running(){
    for cluster in `__get_cluster_list`
    do
        if [ $cluster == "$1" ]
        then
             echo "true"
         fi
    done
}

wait_for_instance_running(){
    index=0
    result=`__instance_state $1`
    echo "Waiting for instance:$1"
    while [ "$result" == *"initializing"* ]
    do
    echo -n "."
    sleep 5
    result=`__instance_state $1`
    done
    echo ""
    echo "$result"
    echo ""
}

get_previous_versions(){
    oldClusters=()
    original=$1
    name=`__toUpperCase ${original}`
    IFS='- ' read -r -a array <<< ${name}
    currentVersion=${array[2]}
    simpleName="${name/$currentVersion/}"
    allClusterNames=`__get_previous_cluster ${simpleName}`
    export IFS=" " _clusters=${allClusterNames}
    for _cluster in ${_clusters}; do
        oldVersion=${_cluster##*-}
        if [[ ${currentVersion} -ne ${oldVersion}  ]]
        then
            oldCluster="${original/$currentVersion/$oldVersion}"
            oldClusters+=(${oldCluster})
        fi
    done
    echo ${oldClusters[@]}
}

get_vcp_id(){
    echo `aws ec2  describe-vpcs | jq '.Vpcs[]' | \
                       jq 'select(.Tags[]?.Value=="'$1'")' | \
                       jq -r '.VpcId'`
}

get_subnet_id(){
    echo `aws ec2 describe-subnets | \
                     jq '.Subnets[]' | \
                     jq 'select(.Tags[]?.Value=="'$1'")' | \
                     jq -r '.SubnetId'`
}

get_security_group_id_by_env_and_name(){
    echo `aws ec2 describe-security-groups | \
                    jq '.SecurityGroups[]' | \
                    jq 'select(.Tags[]?.Value=="'$1'" and .Tags[]?.Value=="'$2'")' | \
                    jq -r '.GroupId'`

}

