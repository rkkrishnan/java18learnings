#!/bin/bash
#Global script to gather all the cloud_formation stack functionality

__status(){
    echo `aws cloudformation list-stacks | jq -r ".StackSummaries | map(select(.StackName == \"$1\")) | .[0].StackStatus"`
}

__stack_instance_state(){
    echo `aws cloudformation list-stacks | \
               jq '.StackSummaries[]' | \
               jq 'select(.StackName=="'$1'" and .StackStatus!="DELETE_COMPLETE")' |\
               jq -r '.StackStatus'`
}

wait_for_stack_success(){
    result=`__status $1`
    echo $result
    while [ "$result" != "CREATE_COMPLETE" ]
    do
        echo -n "."
        if [ "$result"  == "CREATE_FAILED" ]
    then
        exit 1
    fi
    sleep 10
    result=`__status $1`
    done
    echo ""
    echo $result
    echo ""
}

wait_for_stack_delete(){
    result=`__stack_instance_state $1`
    echo $result
    while [ "$result" == "DELETE_IN_PROGRESS" ]
    do
        echo -n "."
        if [ "$result"  == "DELETE_FAILED" ]
        then
            exit 1
        fi
    sleep 1
    result=`__stack_instance_state $1`
    done
    echo ""
    echo $result
    echo ""

}

delete_stack(){
    echo "Deleting stack instance $1"
    aws cloudformation delete-stack --stack-name $1
}