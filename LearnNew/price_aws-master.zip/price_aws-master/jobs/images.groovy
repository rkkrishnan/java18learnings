import commons.JobMixin

folder("images") {
    description("Docker images")
}


createJobInternal('builder')
createJobInternal('jenkins')
createJobInternal('price')
createJobGithub('java', "frol/docker-alpine-oraclejdk8" )

def createJobInternal(String name){
    createJob(name,"images/$name"){
        scm {
            git {
                remote {
                    github("TescoPriceService/price_aws", "https", "github.dev.global.tesco.org")
                    credentials('github_user')
                    branches("origin/master")
                }
            }
        }
    }
}

def createJobGithub( String name, String repo){
    createJob(name,"."){
        scm {
            git {
                remote {
                    github(repo, 'https', 'github.com')
                    branches("origin/master")
                }
            }
        }
    }

}

def createJob(def name, String location, body) {
    job("images/$name") {
        JobMixin.scmTrigger(delegate)

        delegate.with(body)

        steps {
            shell("""
                export AWS_DEFAULT_REGION=eu-west-1
                aws ecr get-login --region eu-west-1
                cd $location
                docker build -t ${name} .
                docker tag -f ${name}:latest 780223221743.dkr.ecr.eu-west-1.amazonaws.com/${name}:latest
                docker push 780223221743.dkr.ecr.eu-west-1.amazonaws.com/${name}:latest
               """.stripIndent())
        }
        wrappers {
            colorizeOutput()
            timeout {
                absolute(15)
            }
        }
    }
}

