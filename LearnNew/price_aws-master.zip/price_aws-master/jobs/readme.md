## Job DSL

We using [Jenkins Job DSL](https://github.com/jenkinsci/job-dsl-plugin/wiki) to generate jenkins jobs.
This way we can automate repetitive pipelines and version our whole build pipeline in git.
This also allow you to create pipelines for every branch of your code (we don't do that yet),
and because we run everything in docker it is easy to keep those separate.

### Implementation notes

#### Using imports

Job dsl support Java imports, even for other .groovy scripts.
Thus you can import another groovy class from work directory with usual Java convention.
Be aware that class name need to be the same as file name (which is normally not required in Groovy).

See [build.groovy](build.groovy) and [commons/Utils.groovy](commons/Utils.groovy) for example.

#### Using categories

I am using [categories and use(X, Y){...}](http://mrhaki.blogspot.co.uk/2009/09/groovy-goodness-use-categories-to-add.html), so I don't have to pass delegate directly (see next point).
It works almost like mixins, but is safe, does not change classes outside of scope and require explicit scope of applications:

```
class JobCategory {
    def static hello(Job job, String greeting){
        steps{
            shell("echo 'hello $greeting'")
        }
    }
}

use(JobCategory) {
    job("someJob") {
        hello("world")
    }
}
```

This works for everything inside this scope so you can have any number of methods.

#### Why Mixins are evil ?

Groovy understands a concept of mixins, which looks like nice idea, but it is not.

Some parts are actually deprecated:
http://stackoverflow.com/questions/23121890/difference-between-delegate-mixin-and-traits-in-groovy

But dynamic mixins are not, thus this way I can create a mixin:

```
class JobMixin{
    static foo(Job job, x, y, z) {
        job.steps{
            shell(x)
            gradle(y)
            shell(z)
        }
    }
}
```

and then use it like that:

```
Job.mixin JobMixin

job("hello"){
    foo("echo 1", "hello", "echo 2")
}
```

instead of

```
job("hello"){
    foo(delegate, "echo 1", "hello", "echo 2")
}
```

To understand why we need a `delegate` at all see next point.

But why mixins are bad? Well they addying a function to Job class which is part of Jenkins.
The class loaders are not protected in job dsl plugin thus:
- every other job will see those changes in given jenkins instance
- **mixin can be applied only once** thus if you change something in
your function this change will only be visible if it is first build
run on given jenkins slave instance.

#### Why my dsl stop working if I extract method

Once we created a complex build it is natural to cut it in smaller pieces.
Usually there are two problems you would face:

```
//This will not work
job("1") {
    commonParts()
    gradle("clean build")
}


def commonParts(){
    // some common parts
    triggers { githubPush() }
    //...
}

def gradle(String taskName){
    steps{
        gradle{
            tasks(taskName)
        }
    }
}
```

This example would fail (you can test it [here](http://job-dsl.herokuapp.com/)) with exception like:

`javaposse.jobdsl.dsl.DslScriptException: (script, line 10) No signature of method: script.triggers()`

This is because Job DSL is written in Groovy and the body of a job is a Closure, long story short, Closure is looking for methods in different places.
In our case that would be the `delegate` closure variable which is not available in methods. That's why we need to pass it:

```
//This will work
job("1") {
    commonParts(delegate)
    gradle(delegate, "clean build")
}


def commonParts(delegate){
    // some common parts
    delegate.triggers { githubPush() }
}

def gradle(delegate, String taskName){
    delegate.steps{
        gradle{
            tasks(taskName)
        }
    }
}
```

If you want to better understand why you can read about [closure: this, owner, delegate](https://dzone.com/articles/groovy-closures-owner-delegate)

#### Why my dsl is generating something strange is I am using `each`?

You might want to use `each` to iterate over collection and generate jobs based on that.
This will work most of the time, but in some cases (when a method in higher level has the same name as one in lower level)

Because builtin methods like .each use owner first which cause closure to resolve method first in context of closure creation then on delegate.
 See
https://github.com/jenkinsci/job-dsl-plugin/wiki/Frequently-Asked-Questions#why-does-a-method-defined-in-an-outer-scope-takes-precedence-of-a-method-defined-in-an-inner-scope
