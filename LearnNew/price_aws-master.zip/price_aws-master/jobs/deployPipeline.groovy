deliveryPipelineView('Pipeline') {
    allowPipelineStart()
    allowRebuild()
    showAggregatedPipeline()
    updateInterval(30)
    enableManualTriggers()
    showAvatars()
    showChangeLog()
    showPromotions()
    showTotalBuildTime()
    pipelines {
        component('Price compile and build', 'build/price')
    }
}