import commons.JobMixin
import commons.StepMixin
/**
 * The test jobs
 */
use(JobMixin, StepMixin) {

    folder("test") {
        description("Testing jobs for the Price Service")
    }

    /**
     * test/performance
     */
    [[name: "test/performance", host: "http://localhost:8080"],
     [name: "test/performance_dev", host: "http://price-dev-lb-loadbalancer-2102984194.eu-west-1.elb.amazonaws.com:8080/"],
     [name: "test/performance_ppe", host: "http://price-ppe-lb-loadbalancer-2116250891.eu-west-1.elb.amazonaws.com:8080/"]].each { env ->
        createJob(env.name, env.host)
    }
}

def createJob(def name, def host) {
    job("$name") {
        runOnMasterIfNotAws()
        concurrentBuild()
        parameters {
            activeChoiceParam('PRICE_VERSION') {
                groovyScript {
                    script(readFileFromWorkspace("scripts/pipeline/latest.groovy"))
                    description "Latest version of Price retrieved by groovy script from s3"
                }
            }
        }
        description("The relative (localy) performance test for price")
        setEnv(HOST: "$host", NETWORK:"net.\$EXECUTOR_NUMBER")

        setupGithub("master", "TescoPriceService/price_service")

        steps {
            killDockerContainers()
            shell( "./scripts/aws_docker_performance.sh")
        }

        wrapInDocker()
        killDockerContainers()
        removeDockerContainers()
    }
}