package commons

class Utils {
    def static inAws(){
		System.properties["INSIDE_AWS"]
    }

    def static awsSpecificEnv() {
        def map = [:]

        if (Utils.inAws()) {
            map['DOCKER_REPO']='780223221743.dkr.ecr.eu-west-1.amazonaws.com/' // last '/' is important
        } else {
            map['DOCKER_REPO'] ='' // you need to build required images locally first
            map['JAVA_HOME'] = '/usr/lib/jvm/java-8-oracle' // local jenkins have java home set and will override the one on docker image
        }

        if(System.properties["MAVEN_REPO"]) {
            map['MAVEN_REPO'] = System.properties["MAVEN_REPO"]
        }

        //S3 Credentials
        map['ACCESS_KEY'] =  "AKIAJVEDYG6DBJW7RGUQ"
        map['SECRET_KEY'] = "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"

        return map
    }
}
