package commons

import javaposse.jobdsl.dsl.Job

class JobMixin {
    def static scmTrigger(Job delegate) {
        delegate.triggers {
            // githubPush() // this does not work because our aws security groups does not allow it to access jenkins
            // so even though we are creating github hook, it is not able to call us back
            scm('H/5 * * * *') // check scm every 5 m
        }
    }

    def static wrapInDocker(Job delegate) {
        delegate.wrappers {
            buildInDocker {
                image('${DOCKER_REPO}builder:latest')
                volume('/var/run/docker.sock', '/var/run/docker.sock')
                volume('/home/ec2-user/.docker', '/home/ec2-user/.docker')
                userGroup('docker')
                verbose()
            }
            colorizeOutput()
            timeout {
                absolute(10)
            }
        }
    }

    def static killDockerContainers(Job job) {
        job.publishers {
            postBuildScripts {
                steps {
                    // there is small problem with readFileFromWorkspace because that one is set on DslFactory
                    // DslFactory is the root context from which job is created
                    // I don's have DslFactory here so I use a hack :/
                    shell(job.jobManagement.readFileInWorkspace('scripts/build_env/cleanup_docker.sh'))
                }
                onlyIfBuildSucceeds(false)
            }
        }
    }

    def static removeDockerContainers(Job delegate) {
        delegate.configure { project ->
            project / 'publishers' / 'com.nirima.jenkins.plugins.docker.publisher.DockerPublisherControl'(plugin: 'docker-plugin@0.16.0') { remove('true') }
        }
    }

    def static setupGithub(Job delegate, String branch, String repository) {
        delegate.scm {
            git {
                remote {
                    github(repository, "https", "github.dev.global.tesco.org")
                    credentials('github_user')
                    branches(branch)
                }
            }
        }
    }

    def static runOnMasterIfNotAws(Job delegate){
        if(!Utils.inAws()){
            // running everything in docker on localhost
            delegate.label "master"
        }
    }

    /**
     * This can be run as:
     * <br><code>setCouchbaseEnv([a :'b'], delegate)</code><br><br>
     *
     * or nicer looking (but it bit strange to grasp method signature)
     * <br><code>setCouchbaseEnv(delegate, a :'b')</code><br><br>
     *
     * This is a bit strange groovy convention for map based methods
     */
    def static setEnv(Job jobDelegate, Map options = [:], Map options2 = [:]) {
        def env = [:]
        env << Utils.awsSpecificEnv()
        env << options
        env << options2

        jobDelegate.environmentVariables {
            def envVarsDelegate = delegate
            env.each { k, v ->
                envVarsDelegate.env(k, v)
            }
        }
    }
}


