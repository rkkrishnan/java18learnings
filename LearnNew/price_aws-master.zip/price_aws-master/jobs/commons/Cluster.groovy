package commons

class Cluster {


    def static price_dev_env = [
            SUBNETS                    : 'DEV-1A,DEV-1C',
            SG_ENV                     : 'PPE',
            ASSOCIATE_PUBLIC_IP_ADDRESS: 'true',
            CLUSTER_NAME               : 'PRICE-DEV-$BUILD_NUMBER',
            STACK_NAME                 : 'price-DEV-$BUILD_NUMBER',
            HEALTH_CHECK               : './scripts/cluster/price/health_check.sh',
            CLUSTER_FILE               : './scripts/cluster/price/template.json',
            LB_NAME                    : 'PRICE-DEV-LB-LoadBalancer'


    ]

    def static price_ppe_env = [
            SUBNETS                    : 'PPE-1A,PPE-1B',
            SG_ENV                     : 'PPE',
            ASSOCIATE_PUBLIC_IP_ADDRESS: 'true',
            CLUSTER_NAME               : 'PRICE-PPE-$BUILD_NUMBER',
            STACK_NAME                 : 'price-PPE-$BUILD_NUMBER',
            HEALTH_CHECK               : './scripts/cluster/price/health_check.sh',
            CLUSTER_FILE               : './scripts/cluster/price/template.json',
            LB_NAME                    : 'PRICE-PPE-LB-LoadBalancer'
    ]

    def static price_live_env = [
            SUBNETS                    : 'LIVE-1A,LIVE-1B',
            SG_ENV                     : 'LIVE',
            ASSOCIATE_PUBLIC_IP_ADDRESS: 'false',
            CLUSTER_NAME               : 'PRICE-LIVE-$BUILD_NUMBER',
            STACK_NAME                 : 'price-LIVE-$BUILD_NUMBER',
            HEALTH_CHECK               : './scripts/cluster/price/health_check.sh',
            CLUSTER_FILE               : './scripts/cluster/price/template.json',
            LB_NAME                    : 'PRICE-LIVE-LB-LoadBalancer'
    ]


}
