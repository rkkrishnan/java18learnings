package commons

import javaposse.jobdsl.dsl.helpers.step.StepContext;

class StepMixin {
	def static gradleRun(StepContext delegate, String task) {
		delegate.gradle {
			tasks(task)

			def cacheDir = '$WORKSPACE/.gradle/'
			switches "-Dgradle.user.home=$cacheDir --project-cache-dir $cacheDir"
			switches '-Dmaven_repo=$MAVEN_REPO'
			switches '--console=plain'
			switches '-Dfile.encoding="UTF-8"'
		}
	}


	def static generateVersion(StepContext delegate) {
		delegate.environmentVariables{
			propertiesFile('build/version.properties')
		}
	}

	def static killDockerContainers(StepContext delegate) {
        // there is small problem with readFileFromWorkspace because that one is set on DslFactory
        // DslFactory is the root context from which job is created
        // I don's have DslFactory here so I use a hack :/
        delegate.shell(delegate.jobManagement.readFileInWorkspace('scripts/build_env/cleanup_docker.sh'))
    }
}
