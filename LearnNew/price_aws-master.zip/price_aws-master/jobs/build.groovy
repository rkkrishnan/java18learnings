import javaposse.jobdsl.dsl.Job

import commons.JobMixin
import commons.StepMixin

/**
 * main template
 */
def insideDockerJob(String name, String repository, String branch, @DelegatesTo(Job) Closure body) {
    job("build/$name") {
        runOnMasterIfNotAws()
        concurrentBuild()
        setupGithub(branch, repository)

        delegate.with(body)

        wrapInDocker()
        killDockerContainers()
        removeDockerContainers()
    }
}


/**
 * The Build jobs for Price
 */
use(JobMixin, StepMixin) {

    def priceRepository = "TescoPriceService/price_service"
    def priceBranch = "master"


    folder("build") {
        description("Development environment")
    }

    /**
     * build/price
     */
    insideDockerJob("price", priceRepository, priceBranch) {
        setEnv()
        scmTrigger()

        steps {
            killDockerContainers()
            gradleRun("clean build uploadToS3")
            generateVersion()
        }

        publishers {

            cucumberTestResults {
                jsonReportFiles("**/build/test-results/cucumber.json")
            }

            cucumberReports {
                // Sanity check, find difference between strings :
                fileIncludePattern("**/build/test-results/cucumber.json")
                failOnSkipSteps()
                failOnPendingSteps()
            }

//            archiveJunit('*/build/test-results/*.xml') {
//                retainLongStdout()
//                testDataPublishers {
//                    publishTestStabilityData()
//                }
//            }

            joinTrigger {
                publishers {
                    downstreamParameterized {
                        trigger(["deploy/price/price_dev"]) {
                            parameters {
                                predefinedProp('PRICE_VERSION', '$PRICE_VERSION')
                            }
                        }
                    }
                }
            }

            downstreamParameterized {
                trigger(["test/performance"]) {
                    parameters {
                        predefinedProp('PRICE_VERSION', '$PRICE_VERSION')
                    }
                }
            }
        }
    }




}