import commons.JobMixin
import javaposse.jobdsl.dsl.Job

import static commons.Cluster.*

/**
 * DEPLOYMENT JOBS FOR AWS
 */
use(JobMixin) {

    def deployFolder = "deploy"
    def deployPriceFolder = "$deployFolder/price"
    def deployPriceDEV = "$deployPriceFolder/price_dev"
    def deployPricePPE = "$deployPriceFolder/price_ppe"
    def deployPriceLIVE = "$deployPriceFolder/price_live"

    def testFolder = "test"
    def performanceDEV = "$testFolder/performance_dev"
    def performancePPE = "$testFolder/performance_ppe"


    folder(deployFolder) {
        description("Deploy jobs")
    }

    folder(deployPriceFolder) {
        description("Deploy jobs for Price")
    }

    def publish = { downstreamJob, performanceTestJob ->
        publishers {
            joinTrigger {
                publishers {
                    downstreamParameterized {
                        trigger([downstreamJob]) {
                            parameters {
                                predefinedProp('PRICE_VERSION', '$PRICE_VERSION')
                            }
                        }
                    }
                }
            }

            downstreamParameterized {
                trigger([performanceTestJob]) {
                    parameters {
                        predefinedProp('PRICE_VERSION', '$PRICE_VERSION')
                    }
                }
            }
        }
    }


    def deployJobs = { jobName, deployScript, envVariables, downstreamJob, performanceTestJob, Closure publisher ->

        deploy(jobName, deployScript) {
            parameters {
                activeChoiceParam('PRICE_VERSION') {
                    groovyScript {
                        script(readFileFromWorkspace("scripts/pipeline/latest.groovy"))
                        description "Latest version of Price retrieved by groovy script from s3"
                    }
                }
            }
            setEnv(envVariables)

            if (publisher) {
                publisher.delegate = delegate
                publisher(downstreamJob, performanceTestJob)
            }
        }
    }

    //Price
    /**
     * Jobs to deploy latest Price docker image on DEV-PPE-LIVE cluster
     */
    deployJobs(deployPriceDEV, "./scripts/deployment/price/deploy.sh", price_dev_env, deployPricePPE, performanceDEV, publish)
    deployJobs(deployPricePPE, "./scripts/deployment/price/deploy.sh", price_ppe_env, deployPriceLIVE, performancePPE, publish)
    deployJobs(deployPriceLIVE, "./scripts/deployment/price/deploy.sh", price_live_env, null, null, null)

}

def deploy(jobName, script, @DelegatesTo(Job) Closure body) {
    job(jobName) {
        delegate.with(body)

        setupGithub("master", "TescoPriceService/price_aws")



        steps {
            shell(script)
        }

        wrappers {
            colorizeOutput()
            timeout {
                absolute(15)
            }
        }
    }
}
