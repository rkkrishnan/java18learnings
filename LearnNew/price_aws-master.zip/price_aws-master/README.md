## Price AWS
![My image](src/main/resources/images/cicd.jpg)

Tool to be used for CI/CD of Price service in AWS.

- References:
    - [AWS environment](scripts/environment/readme.md)
    - [Cluster](scripts/cluster/readme.md)
    - [Deployment](scripts/deployment/readme.md)
    - [Docker Images](images/README.md)
