#!/bin/bash

 while [ true ]
  do
    current_date_time="`date +%Y%m%d%H%M%S`";
    curl $1:8080 
    echo "\n$current_date_time"
    sleep 1
  done
