package com.tesco.services.core.entity.product;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProductUOMInfo {

	@Valid
	@NotNull
	@JsonProperty("products")
	private List<Product> products = new ArrayList<Product>();

	@JsonProperty("total")
	private Integer total;

	@JsonProperty("missingSet")
	private List<String> missingSet = new ArrayList<String>();

	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	/**
	 *
	 * @return
	 * The products
	 */
	@JsonProperty("products")
	public List<Product> getProducts() {
		return products;
	}

	/**
	 *
	 * @param products
	 * The products
	 */
	@JsonProperty("products")
	public void setProducts(List<Product> products) {
		this.products = products;
	}

	/**
	 *
	 * @return
	 * The total
	 */
	@JsonProperty("total")
	public Integer getTotal() {
		return total;
	}

	/**
	 *
	 * @param total
	 * The total
	 */
	@JsonProperty("total")
	public void setTotal(Integer total) {
		this.total = total;
	}

	/**
	 *
	 * @return
	 * The missingSet
	 */
	@JsonProperty("missingSet")
	public List<String> getMissingSet() {
		return missingSet;
	}

	/**
	 *
	 * @param missingSet
	 * The missingSet
	 */
	@JsonProperty("missingSet")
	public void setMissingSet(List<String> missingSet) {
		this.missingSet = missingSet;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

}
