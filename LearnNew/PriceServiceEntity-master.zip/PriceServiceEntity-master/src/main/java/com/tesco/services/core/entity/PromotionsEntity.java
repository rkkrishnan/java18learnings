package com.tesco.services.core.entity;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class PromotionsEntity {

	@JsonProperty("offerId")
	private String offerId;
	@JsonProperty("zoneId")
	private Integer zoneId;
	@JsonProperty("CFDescription1")
	private String CFDescription1;
	@JsonProperty("CFDescription2")
	private String CFDescription2;
	@JsonProperty("offerName")
	private String offerName;
	@JsonProperty("effectiveDate")
	private String effectiveDate;
	@JsonProperty("endDate")
	private String endDate;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	/**
	 * 
	 * @return The offerId
	 */
	@JsonProperty("offerId")
	public String getOfferId() {
		return offerId;
	}

	/**
	 * 
	 * @param offerId
	 *            The offerId
	 */
	@JsonProperty("offerId")
	public void setOfferId(String offerId) {
		this.offerId = offerId;
	}

	/**
	 * 
	 * @return The zoneId
	 */
	@JsonProperty("zoneId")
	public Integer getZoneId() {
		return zoneId;
	}

	/**
	 * 
	 * @param zoneId
	 *            The zoneId
	 */
	@JsonProperty("zoneId")
	public void setZoneId(Integer zoneId) {
		this.zoneId = zoneId;
	}

	/**
	 * 
	 * @return The CFDescription1
	 */
	@JsonProperty("CFDescription1")
	public String getCFDescription1() {
		return CFDescription1;
	}

	/**
	 * 
	 * @param CFDescription1
	 *            The CFDescription1
	 */
	@JsonProperty("CFDescription1")
	public void setCFDescription1(String CFDescription1) {
		this.CFDescription1 = CFDescription1;
	}

	/**
	 * 
	 * @return The CFDescription2
	 */
	@JsonProperty("CFDescription2")
	public String getCFDescription2() {
		return CFDescription2;
	}

	/**
	 * 
	 * @param CFDescription2
	 *            The CFDescription2
	 */
	@JsonProperty("CFDescription2")
	public void setCFDescription2(String CFDescription2) {
		this.CFDescription2 = CFDescription2;
	}

	/**
	 * 
	 * @return The offerName
	 */
	@JsonProperty("offerName")
	public String getOfferName() {
		return offerName;
	}

	/**
	 * 
	 * @param offerName
	 *            The offerName
	 */
	@JsonProperty("offerName")
	public void setOfferName(String offerName) {
		this.offerName = offerName;
	}

	/**
	 * 
	 * @return The effectiveDate
	 */
	@JsonProperty("effectiveDate")
	public String getEffectiveDate() {
		return effectiveDate;
	}

	/**
	 * 
	 * @param effectiveDate
	 *            The effectiveDate
	 */
	@JsonProperty("effectiveDate")
	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	/**
	 * 
	 * @return The endDate
	 */
	@JsonProperty("endDate")
	public String getEndDate() {
		return endDate;
	}

	/**
	 * 
	 * @param endDate
	 *            The endDate
	 */
	@JsonProperty("endDate")
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(offerId).append(zoneId)
				.append(CFDescription1).append(CFDescription2)
				.append(offerName).append(effectiveDate).append(endDate)
				.append(additionalProperties).toHashCode();
	}

	@Override
	public boolean equals(Object other) {
		if (other == this) {
			return true;
		}
		if (!(other instanceof PromotionsEntity)) {
			return false;
		}
		PromotionsEntity rhs = ((PromotionsEntity) other);
		return new EqualsBuilder().append(offerId, rhs.offerId)
				.append(zoneId, rhs.zoneId)
				.append(CFDescription1, rhs.CFDescription1)
				.append(CFDescription2, rhs.CFDescription2)
				.append(offerName, rhs.offerName)
				.append(effectiveDate, rhs.effectiveDate)
				.append(endDate, rhs.endDate)
				.append(additionalProperties, rhs.additionalProperties)
				.isEquals();
	}

}
