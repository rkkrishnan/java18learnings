package com.tesco.services.core.entity;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by iv16 on 6/9/2015.
 */
public class PromoThreshold {
    @JsonProperty("thresholdType")
    private String thresholdType;
    @JsonProperty("thresholdValue")
    private String thresholdValue;

    public String getThresholdValue() {
        return thresholdValue;
    }

    public void setThresholdValue(String thresholdValue) {
        this.thresholdValue = thresholdValue;
    }

    public String getThresholdType() {
        return thresholdType;
    }

    public void setThresholdType(String thresholdType) {
        this.thresholdType = thresholdType;
    }

    @Override
    public String toString() {
        return "PromoThreshold{" +
                "thresholdType='" + thresholdType + '\'' +
                ", thresholdValue='" + thresholdValue + '\'' +
                '}';
    }
}
