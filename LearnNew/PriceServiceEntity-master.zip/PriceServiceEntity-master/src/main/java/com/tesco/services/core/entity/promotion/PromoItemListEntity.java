package com.tesco.services.core.entity.promotion;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
@JsonIgnoreProperties(ignoreUnknown = true)

public class PromoItemListEntity {
	@JsonProperty("@type")
	public String type;

	@JsonProperty("listType")
	public String listType;

	@JsonProperty("thresholdRefs")
	public int[] thresholdRefs;

	@JsonProperty("rewardRefs")
	public int[] rewardRefs;

	@JsonProperty("promoItems")
	public List<PromoItemEntity> promoItems;

	public void addPromoItem(PromoItemEntity promoItem) {
		if (this.promoItems == null) {
			this.promoItems = new ArrayList<>();
		}
		this.promoItems.add(promoItem);
	}

	public String getListType() {
		return listType;
	}

	public void setListType(String listType) {
		this.listType = listType;
	}

	public List<PromoItemEntity> getPromoItems() {
		return promoItems;
	}

	public void setPromoItems(List<PromoItemEntity> promoItems) {
		this.promoItems = promoItems;
	}

	public int[] getRewardRefs() {
		return rewardRefs;
	}

	public void setRewardRefs(int[] rewardRefs) {
		this.rewardRefs = rewardRefs;
	}

	public int[] getThresholdRefs() {
		return thresholdRefs;
	}

	public void setThresholdRefs(int[] thresholdRefs) {
		this.thresholdRefs = thresholdRefs;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public void removeItemEntity(PromoItemEntity promoItemEntity) {
		promoItems.remove(promoItemEntity);
	}

	@Override
	public String toString() {
		return "PromoItemListEntity{" + "type='" + type + '\'' + ", listType='"
				+ listType + '\'' + ", thresholdRefs="
				+ Arrays.toString(thresholdRefs) + ", promoItems=" + promoItems
				+ '}';
	}
}
