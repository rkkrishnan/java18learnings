package com.tesco.services.core.entity.price;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class RegularPriceVariantEntity {

	@JsonProperty("tpnc")
	private String tpnc;

	@JsonProperty("sellingUOM")
	private String sellingUOM;

	@JsonProperty("selling_currency")
	private String sellingCurrency;

	@JsonProperty("effective_date")
	private Map<String,PriceByDateTimeEntity> effectiveDate;

	@JsonProperty("tpnc")
	public String getTpnc() {
		return tpnc;
	}

	@JsonProperty("tpnc")
	public void setTpnc(String tpnc) {
		this.tpnc = tpnc;
	}

	@JsonProperty("sellingUOM")
	public String getSellingUOM() {
		return sellingUOM;
	}

	@JsonProperty("sellingUOM")
	public void setSellingUOM(String sellingUOM) {
		this.sellingUOM = sellingUOM;
	}

	@JsonProperty("selling_currency")
	public String getSellingCurrency() {
		return sellingCurrency;
	}

	@JsonProperty("selling_currency")
	public void setSellingCurrency(String sellingCurrency) {
		this.sellingCurrency = sellingCurrency;
	}

	@JsonProperty("effective_date")
	public Map<String, PriceByDateTimeEntity> getEffectiveDate() {
		if(effectiveDate == null){
			effectiveDate = new HashMap<>();
		}
		return effectiveDate;
	}

	@JsonProperty("effective_date")
	public void setEffectiveDate(Map<String, PriceByDateTimeEntity> effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	@Override public String toString() {
		return "ProductVariant{" +
				"tpnc='" + tpnc + '\'' +
				", sellingUOM='" + sellingUOM + '\'' +
				", sellingCurrency='" + sellingCurrency + '\'' +
				", effectiveDate=" + effectiveDate +
				'}';
	}
}
