package com.tesco.services.core.entity;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class StoreException {

	@JsonProperty("clearanceStoreId")
	private String clearanceStoreId;
	@JsonProperty("countryCode")
	private String countryCode;
	@JsonProperty("currency")
	private String currency;
	@JsonProperty("storesClearancePriceByDateTime")
	private Map<String, ClearancePriceByDateTime> storesClearancePriceByDateTime = new HashMap<String, ClearancePriceByDateTime>();

	/**
	 * 
	 * @return The clearanceStoreId
	 */
	@JsonProperty("clearanceStoreId")
	public String getClearanceStoreId() {
		return clearanceStoreId;
	}

	/**
	 * 
	 * @param clearanceStoreId
	 *            The clearanceStoreId
	 */
	@JsonProperty("clearanceStoreId")
	public void setClearanceStoreId(String clearanceStoreId) {
		this.clearanceStoreId = clearanceStoreId;
	}

	/**
	 * 
	 * @return The countryCode
	 */
	@JsonProperty("countryCode")
	public String getCountryCode() {
		return countryCode;
	}

	/**
	 * 
	 * @param countryCode
	 *            The countryCode
	 */
	@JsonProperty("countryCode")
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	/**
	 * 
	 * @return The currency
	 */
	@JsonProperty("currency")
	public String getCurrency() {
		return currency;
	}

	/**
	 * 
	 * @param currency
	 *            The currency
	 */
	@JsonProperty("currency")
	public void setCurrency(String currency) {
		this.currency = currency;
	}

	/**
	 * @return The storesClearancePriceByDateTime
	 */
	public Map<String, ClearancePriceByDateTime> getStoresClearancePriceByDateTime() {
		return storesClearancePriceByDateTime;
	}

	/**
	 * @param storesClearancePriceByDateTime
	 */
	public void setStoresClearancePriceByDateTime(
			Map<String, ClearancePriceByDateTime> storesClearancePriceByDateTime) {
		this.storesClearancePriceByDateTime = storesClearancePriceByDateTime;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((clearanceStoreId == null) ? 0 : clearanceStoreId.hashCode());
		result = prime * result
				+ ((countryCode == null) ? 0 : countryCode.hashCode());
		result = prime * result
				+ ((currency == null) ? 0 : currency.hashCode());
		result = prime
				* result
				+ ((storesClearancePriceByDateTime == null) ? 0
						: storesClearancePriceByDateTime.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StoreException other = (StoreException) obj;
		if (clearanceStoreId == null) {
			if (other.clearanceStoreId != null)
				return false;
		} else if (!clearanceStoreId.equals(other.clearanceStoreId))
			return false;
		if (countryCode == null) {
			if (other.countryCode != null)
				return false;
		} else if (!countryCode.equals(other.countryCode))
			return false;
		if (currency == null) {
			if (other.currency != null)
				return false;
		} else if (!currency.equals(other.currency))
			return false;
		if (storesClearancePriceByDateTime == null) {
			if (other.storesClearancePriceByDateTime != null)
				return false;
		} else if (!storesClearancePriceByDateTime
				.equals(other.storesClearancePriceByDateTime))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "StoreException [clearanceStoreId=" + clearanceStoreId
				+ ", countryCode=" + countryCode + ", currency=" + currency
				+ ", storesClearancePriceByDateTime="
				+ storesClearancePriceByDateTime + "]";
	}

}
