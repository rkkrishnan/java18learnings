package com.tesco.services.core.entity.product;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.validation.constraints.NotNull;
import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class DrainedIndicatorInfo {

	@NotNull
	@JsonProperty("country")
	private String country;

	@JsonProperty("indicator")
	private String indicator;

	@JsonProperty("source")
	private String source;

	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	/**
	 *
	 * @return
	 * The country
	 */
	@JsonProperty("country")
	public String getCountry() {
		return country;
	}

	/**
	 *
	 * @param country
	 * The country
	 */
	@JsonProperty("country")
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 *
	 * @return
	 * The indicator
	 */
	@JsonProperty("indicator")
	public String getIndicator() {
		return indicator;
	}

	/**
	 *
	 * @param indicator
	 * The indicator
	 */
	@JsonProperty("indicator")
	public void setIndicator(String indicator) {
		this.indicator = indicator;
	}

	/**
	 *
	 * @return
	 * The source
	 */
	@JsonProperty("source")
	public String getSource() {
		return source;
	}

	/**
	 *
	 * @param source
	 * The source
	 */
	@JsonProperty("source")
	public void setSource(String source) {
		this.source = source;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

}