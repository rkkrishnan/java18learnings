package com.tesco.services.core.entity;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ClearancePriceByDateTime {

	@JsonProperty("prevPrice")
	public List<EstablishedPriceInfo> establishedPriceInfos = new ArrayList<>();
	@JsonProperty("effvDateTime")
	private String effvDateTime;
	@JsonProperty("endDateTime")
	private String endDateTime;
	@JsonProperty("clearanceRef")
	private String clearanceRef;
	@JsonProperty("clearancePrice")
	private String clearancePrice;
	@JsonProperty("clearanceIndicator")
	private String clearanceIndicator;

	/**
	 * 
	 * @return The effvDateTime
	 */
	@JsonProperty("effvDateTime")
	public String getEffvDateTime() {
		return effvDateTime;
	}

	/**
	 * 
	 * @param effvDateTime
	 *            The effvDateTime
	 */
	@JsonProperty("effvDateTime")
	public void setEffvDateTime(String effvDateTime) {
		this.effvDateTime = effvDateTime;
	}

	/**
	 * 
	 * @return The endDateTime
	 */
	@JsonProperty("endDateTime")
	public String getEndDateTime() {
		return endDateTime;
	}

	/**
	 * 
	 * @param endDateTime
	 *            The endDateTime
	 */
	@JsonProperty("endDateTime")
	public void setEndDateTime(String endDateTime) {
		this.endDateTime = endDateTime;
	}

	/**
	 * 
	 * @return The clearanceRef
	 */
	@JsonProperty("clearanceRef")
	public String getClearanceRef() {
		return clearanceRef;
	}

	/**
	 * 
	 * @param clearanceRef
	 *            The clearanceRef
	 */
	@JsonProperty("clearanceRef")
	public void setClearanceRef(String clearanceRef) {
		this.clearanceRef = clearanceRef;
	}

	/**
	 * 
	 * @return The clearancePrice
	 */
	@JsonProperty("clearancePrice")
	public String getClearancePrice() {
		return clearancePrice;
	}

	/**
	 * 
	 * @param clearancePrice
	 *            The clearancePrice
	 */
	@JsonProperty("clearancePrice")
	public void setClearancePrice(String clearancePrice) {
		this.clearancePrice = clearancePrice;
	}

	public List<EstablishedPriceInfo> getEstablishedPriceInfos() {
		return establishedPriceInfos;
	}

	public void setEstablishedPriceInfos(List<EstablishedPriceInfo> establishedPriceInfos) {
		this.establishedPriceInfos = establishedPriceInfos;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((clearancePrice == null) ? 0 : clearancePrice.hashCode());
		result = prime * result + ((clearanceRef == null) ? 0 : clearanceRef.hashCode());
		result = prime * result + ((effvDateTime == null) ? 0 : effvDateTime.hashCode());
		result = prime * result + ((endDateTime == null) ? 0 : endDateTime.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ClearancePriceByDateTime other = (ClearancePriceByDateTime) obj;
		if (clearancePrice == null) {
			if (other.clearancePrice != null)
				return false;
		} else if (!clearancePrice.equals(other.clearancePrice))
			return false;
		if (clearanceRef == null) {
			if (other.clearanceRef != null)
				return false;
		} else if (!clearanceRef.equals(other.clearanceRef))
			return false;
		if (effvDateTime == null) {
			if (other.effvDateTime != null)
				return false;
		} else if (!effvDateTime.equals(other.effvDateTime))
			return false;
		if (endDateTime == null) {
			if (other.endDateTime != null)
				return false;
		} else if (!endDateTime.equals(other.endDateTime))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ClearancePriceByDateTime [effvDateTime=" + effvDateTime + ", endDateTime=" + endDateTime
				+ ", clearanceRef=" + clearanceRef + ", clearancePrice=" + clearancePrice + "]";
	}

	public String getClearanceIndicator() {
		return clearanceIndicator;
	}

	public void setClearanceIndicator(String clearanceIndicator) {
		this.clearanceIndicator = clearanceIndicator;
	}
}
