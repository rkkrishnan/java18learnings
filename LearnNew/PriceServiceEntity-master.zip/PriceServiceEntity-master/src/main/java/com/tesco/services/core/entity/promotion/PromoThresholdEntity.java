package com.tesco.services.core.entity.promotion;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PromoThresholdEntity {
	@JsonProperty("@type")
	public String type;
	@JsonProperty("thresholdType")
	public String thresholdType;
	@JsonProperty("thresholdAmount")
	public double thresholdAmount;
	@JsonProperty("thresholdCurrency")
	public String thresholdCurrency;
	@JsonProperty("thresholdQty")
	public int thresholdQty;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getThresholdType() {
		return thresholdType;
	}

	public void setThresholdType(String thresholdType) {
		this.thresholdType = thresholdType;
	}

	public double getThresholdAmount() {
		return thresholdAmount;
	}

	public void setThresholdAmount(double thresholdAmount) {
		this.thresholdAmount = thresholdAmount;
	}

	public String getThresholdCurrency() {
		return thresholdCurrency;
	}

	public void setThresholdCurrency(String thresholdCurrency) {
		this.thresholdCurrency = thresholdCurrency;
	}

	public int getThresholdQty() {
		return thresholdQty;
	}

	public void setThresholdQty(int thresholdQty) {
		this.thresholdQty = thresholdQty;
	}

	@Override
	public String toString() {
		return "PromoThresholdEntity{" + "type='" + type + '\''
				+ ", thresholdType='" + thresholdType + '\''
				+ ", thresholdAmount=" + thresholdAmount
				+ ", thresholdCurrency='" + thresholdCurrency + '\''
				+ ", thresholdQty=" + thresholdQty + '}';
	}
}
