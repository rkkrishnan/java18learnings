package com.tesco.services.core.entity;

import com.fasterxml.jackson.annotation.*;
import com.tesco.services.core.entity.product.UnitSellingPriceInfo;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class PriceEntity {

	@JsonProperty("tpnb")
	private String tpnb;
	@JsonProperty("last_updated_date")
	private String lastUpdatedDate;
	@JsonProperty("promotions")
	private Map<String, PromotionsEntity> promotions = new HashMap<String, PromotionsEntity>();
	@JsonProperty("tpncToProductVariant")
	private Map<String, ProductVariantEntity> tpncToProductVariant = new HashMap<String, ProductVariantEntity>();
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonIgnore
	private Map<String, UnitSellingPriceInfo> sellingUomInfo = new HashMap<String, UnitSellingPriceInfo>();
	@JsonIgnore
	private String countryId;
	@JsonIgnore
	private String currency;

	/**
	 *
	 * @param tpnb
	 *            The tpnb
	 */
	@JsonProperty("tpnb")
	public void setTpnb(String tpnb) {
		this.tpnb = tpnb;
	}

    /**
     *
     * @return The tpnb
     */
    @JsonProperty("tpnb")
    public String getTpnb() {
        return tpnb;
    }

	/**
	 * 
	 * @return The lastUpdatedDate
	 */
	@JsonProperty("last_updated_date")
	public String getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	/**
	 * 
	 * @param lastUpdatedDate
	 *            The last_updated_date
	 */
	@JsonProperty("last_updated_date")
	public void setLastUpdatedDate(String lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	/**
	 * 
	 * @return The promotions
	 */
	@JsonProperty("promotions")
	public Map<String, PromotionsEntity> getPromotions() {
		return promotions;
	}

	/**
	 * 
	 * @param promotions
	 *            The promotions
	 */
	@JsonProperty("promotions")
	public void setPromotions(Map<String, PromotionsEntity> promotions) {
		this.promotions = promotions;
	}

	/**
	 * 
	 * @return The tpncToProductVariant
	 */
	@JsonProperty("tpncToProductVariant")
	public Map<String, ProductVariantEntity> getTpncToProductVariant() {
		return tpncToProductVariant;
	}

	@JsonIgnore
	private String defaultUOMCode;

	/**
	 * 
	 * @param tpncToProductVariant
	 *            The tpncToProductVariant
	 */
	@JsonProperty("tpncToProductVariant")
	public void setTpncToProductVariant(
			Map<String, ProductVariantEntity> tpncToProductVariant) {
		this.tpncToProductVariant = tpncToProductVariant;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(tpnb).append(lastUpdatedDate)
				.append(promotions).append(tpncToProductVariant)
				.append(additionalProperties).toHashCode();
	}

	@Override
	public boolean equals(Object other) {
		if (other == this) {
			return true;
		}
		if (!(other instanceof PriceEntity)) {
			return false;
		}
		PriceEntity rhs = ((PriceEntity) other);
		return new EqualsBuilder().append(tpnb, rhs.tpnb)
				.append(lastUpdatedDate, rhs.lastUpdatedDate)
				.append(promotions, rhs.promotions)
				.append(tpncToProductVariant, rhs.tpncToProductVariant)
				.append(additionalProperties, rhs.additionalProperties)
				.isEquals();
	}

	public Map<String, UnitSellingPriceInfo> getSellingUomInfo() {
		return sellingUomInfo;
	}

	public void setSellingUomInfo(
			Map<String, UnitSellingPriceInfo> sellingUomInfo) {
		this.sellingUomInfo = sellingUomInfo;
	}

	public String getCountryId() {
		return countryId;
	}

	public void setCountryId(String countryId) {
		this.countryId = countryId;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getDefaultUOMCode() {
		return defaultUOMCode;
	}

	public void setDefaultUOMCode(String defaultUOMCode) {
		this.defaultUOMCode = defaultUOMCode;
	}
}
