package com.tesco.services.core.entity.price;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.tesco.services.core.entity.product.UnitSellingPriceInfo;

import java.util.HashMap;
import java.util.Map;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RegularPriceEntity {

	@JsonProperty("prodType")
	private String prodType;

	@JsonProperty("prodRef")
	private String prodRef;

	@JsonProperty("locRef")
	private String locRef;

	@JsonProperty("locType")
	private String locType;

	@JsonProperty("lastUpdateDate")
	private String lastUpdateDate;

	@JsonProperty("tpncToProductVariant")
	private Map<String,RegularPriceVariantEntity> tpncToProductVariant;

	@JsonIgnore
	private Map<String, UnitSellingPriceInfo> sellingUomInfo = new HashMap<String, UnitSellingPriceInfo>();

	@JsonIgnore
	private String countryId;

	@JsonIgnore
	private String currency;

	@JsonIgnore
	private String defaultUOMCode;

	@JsonProperty("prodType")
	public String getProdType() {
		return prodType;
	}

	@JsonProperty("prodType")
	public void setProdType(String prodType) {
		this.prodType = prodType;
	}

	@JsonProperty("prodRef")
	public String getProdRef() {
		return prodRef;
	}

	@JsonProperty("prodRef")
	public void setProdRef(String prodRef) {
		this.prodRef = prodRef;
	}

	@JsonProperty("locRef")
	public String getLocRef() {
		return locRef;
	}

	@JsonProperty("locRef")
	public void setLocRef(String locRef) {
		this.locRef = locRef;
	}

	@JsonProperty("locType")
	public String getLocType() {
		return locType;
	}

	@JsonProperty("locType")
	public void setLocType(String locType) {
		this.locType = locType;
	}

	@JsonProperty("lastUpdateDate")
	public String getLastUpdateDate() {
		return lastUpdateDate;
	}

	@JsonProperty("lastUpdateDate")
	public void setLastUpdateDate(String lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	@JsonProperty("tpncToProductVariant")
	public Map<String, RegularPriceVariantEntity> getTpncToProductVariant() {
		if(tpncToProductVariant == null){
			tpncToProductVariant = new HashMap<>();
		}
		return tpncToProductVariant;
	}

	@JsonProperty("tpncToProductVariant")
	public void setTpncToProductVariant(
			Map<String, RegularPriceVariantEntity> tpncToProductVariant) {
		this.tpncToProductVariant = tpncToProductVariant;
	}

	public String getCountryId() {
		return countryId;
	}

	public void setCountryId(String countryId) {
		this.countryId = countryId;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public Map<String, UnitSellingPriceInfo> getSellingUomInfo() {
		return sellingUomInfo;
	}

	public void setSellingUomInfo(
			Map<String, UnitSellingPriceInfo> sellingUomInfo) {
		this.sellingUomInfo = sellingUomInfo;
	}

	public String getDefaultUOMCode() {
		return defaultUOMCode;
	}

	public void setDefaultUOMCode(String defaultUOMCode) {
		this.defaultUOMCode = defaultUOMCode;
	}

	@Override public String toString() {
		return "PriceEntity{" +
				"prodType='" + prodType + '\'' +
				", prodRef='" + prodRef + '\'' +
				", locRef='" + locRef + '\'' +
				", locType='" + locType + '\'' +
				", lastUpdateDate='" + lastUpdateDate + '\'' +
				", tpncToProductVariant=" + tpncToProductVariant +
				'}';
	}
}
