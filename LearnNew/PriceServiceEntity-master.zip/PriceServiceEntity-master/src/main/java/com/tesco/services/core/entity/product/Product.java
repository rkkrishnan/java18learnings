package com.tesco.services.core.entity.product;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Product {

	@NotNull
	@JsonProperty("TPNB")
	private String TPNB;

	@NotNull
	@JsonProperty("TPNC")
	private String TPNC;

	@Valid
	@NotNull
	@JsonProperty("statusInfo")
	private List<StatusInfo> statusInfos = new ArrayList<StatusInfo>();

	@NotNull
	@JsonProperty("sellByType")
	private String sellByType;

	@Valid
	@NotNull
	@Size(min = 0)
	@JsonProperty("drainedIndicatorInfo")
	private List<DrainedIndicatorInfo> drainedIndicatorInfo = new ArrayList<DrainedIndicatorInfo>();

	@Valid
	@NotNull
	@Size(min = 1)
	@JsonProperty("quantityInfo")
	private List<QuantityInfo> quantityInfo = new ArrayList<QuantityInfo>();

	@Valid
	@NotNull
	@JsonProperty("commercialHierarchyInfo")
	private CommercialHierarchyInfo commercialHierarchyInfo;

	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	/**
	 *
	 * @return
	 * The TPNB
	 */
	@JsonProperty("TPNB")
	public String getTPNB() {
		return TPNB;
	}

	/**
	 *
	 * @param TPNB
	 * The TPNB
	 */
	@JsonProperty("TPNB")
	public void setTPNB(String TPNB) {
		this.TPNB = TPNB;
	}

	/**
	 *
	 * @return
	 * The TPNC
	 */
	@JsonProperty("TPNC")
	public String getTPNC() {
		return TPNC;
	}

	/**
	 *
	 * @param TPNC
	 * The TPNC
	 */
	@JsonProperty("TPNC")
	public void setTPNC(String TPNC) {
		this.TPNC = TPNC;
	}

	/**
	 *
	 * @return
	 * The sellByType
	 */
	@JsonProperty("sellByType")
	public String getSellByType() {
		return sellByType;
	}

	/**
	 *
	 * @param sellByType
	 * The sellByType
	 */
	@JsonProperty("sellByType")
	public void setSellByType(String sellByType) {
		this.sellByType = sellByType;
	}

	/**
	 *
	 * @return
	 * The drainedIndicatorInfo
	 */
	@JsonProperty("drainedIndicatorInfo")
	public List<DrainedIndicatorInfo> getDrainedIndicatorInfo() {
		return drainedIndicatorInfo;
	}

	/**
	 *
	 * @param drainedIndicatorInfo
	 * The drainedIndicatorInfo
	 */
	@JsonProperty("drainedIndicatorInfo")
	public void setDrainedIndicatorInfo(List<DrainedIndicatorInfo> drainedIndicatorInfo) {
		this.drainedIndicatorInfo = drainedIndicatorInfo;
	}

	/**
	 *
	 * @return
	 * The quantityInfo
	 */
	@JsonProperty("quantityInfo")
	public List<QuantityInfo> getQuantityInfo() {
		return quantityInfo;
	}

	/**
	 *
	 * @param quantityInfo
	 * The quantityInfo
	 */
	@JsonProperty("quantityInfo")
	public void setQuantityInfo(List<QuantityInfo> quantityInfo) {
		this.quantityInfo = quantityInfo;
	}

	/**
	 *
	 * @return
	 * The commercialHierarchyInfo
	 */
	@JsonProperty("commercialHierarchyInfo")
	public CommercialHierarchyInfo getCommercialHierarchyInfo() {
		return commercialHierarchyInfo;
	}

	/**
	 *
	 * @param commercialHierarchyInfo
	 * The commercialHierarchyInfo
	 */
	@JsonProperty("commercialHierarchyInfo")
	public void setCommercialHierarchyInfo(CommercialHierarchyInfo commercialHierarchyInfo) {
		this.commercialHierarchyInfo = commercialHierarchyInfo;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	@JsonProperty("statusInfos")
	public List<StatusInfo> getStatusInfos() {
		return statusInfos;
	}

	@JsonProperty("statusInfos")
	public void setStatusInfos(
			List<StatusInfo> statusInfos) {
		this.statusInfos = statusInfos;
	}

}
