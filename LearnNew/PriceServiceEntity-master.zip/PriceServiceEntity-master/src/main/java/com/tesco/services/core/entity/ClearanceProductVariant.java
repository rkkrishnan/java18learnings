package com.tesco.services.core.entity;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ClearanceProductVariant {

	@JsonProperty("tpnc")
	private String tpnc;

	@JsonProperty("zonePrices")
	private Map<String,ZonePrice> zonePrices = new HashMap<String,ZonePrice>();

	@JsonProperty("storeExceptions")
	private Map<String,StoreException> storeExceptions = new HashMap<String,StoreException>();

	/**
	 * 
	 * @return The tpnc
	 */
	@JsonProperty("tpnc")
	public String getTpnc() {
		return tpnc;
	}

	/**
	 * 
	 * @param tpnc
	 *            The tpnc
	 */
	@JsonProperty("tpnc")
	public void setTpnc(String tpnc) {
		this.tpnc = tpnc;
	}

	/**
	 * @return The zonePrices
	 */
	public Map<String,ZonePrice> getZonePrices() {
		return zonePrices;
	}

	/**
	 * @param zonePrices
	 */
	public void setZonePrices(Map<String,ZonePrice> zonePrices) {
		this.zonePrices = zonePrices;
	}

	/**
	 * @return The storeExceptions
	 */
	public Map<String,StoreException> getStoreExceptions() {
		return storeExceptions;
	}

	/**
	 * @param storeExceptions
	 */
	public void setStoreExceptions(Map<String,StoreException> storeExceptions) {
		this.storeExceptions = storeExceptions;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((storeExceptions == null) ? 0 : storeExceptions.hashCode());
		result = prime * result + ((tpnc == null) ? 0 : tpnc.hashCode());
		result = prime * result
				+ ((zonePrices == null) ? 0 : zonePrices.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ClearanceProductVariant other = (ClearanceProductVariant) obj;
		if (storeExceptions == null) {
			if (other.storeExceptions != null)
				return false;
		} else if (!storeExceptions.equals(other.storeExceptions))
			return false;
		if (tpnc == null) {
			if (other.tpnc != null)
				return false;
		} else if (!tpnc.equals(other.tpnc))
			return false;
		if (zonePrices == null) {
			if (other.zonePrices != null)
				return false;
		} else if (!zonePrices.equals(other.zonePrices))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ClearanceProductVariant [tpnc=" + tpnc + ", zonePrices="
				+ zonePrices + ", storeExceptions=" + storeExceptions + "]";
	}

}
