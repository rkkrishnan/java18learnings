package com.tesco.services.core.entity;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.base.Optional;

import java.io.Serializable;

import static com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility.ANY;
import static com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility.NONE;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonAutoDetect(fieldVisibility = ANY, getterVisibility = NONE, setterVisibility = NONE)
public class Store implements Serializable {

	@JsonProperty
	private String storeId;
	@JsonProperty
	private int priceZoneId;
	@JsonProperty
	private int promoZoneId;
	@JsonProperty
	private int clearanceZoneId;
	@JsonProperty
	private String currency;
	@JsonProperty
	private String countryId;



	/**
	 * Constructore Store
	 * @param storeId
	 * @param priceZoneId
	 * @param promoZoneId
	 * @param clearanceZoneId
	 * @param currency
	 * @param countryId
	 */
	public Store(String storeId, Optional<Integer> priceZoneId, Optional<Integer> promoZoneId,Optional<Integer> clearanceZoneId,String currency, String countryId) {
		this.storeId = storeId;
		setPriceZoneId(priceZoneId);
		setPromoZoneId(promoZoneId);
		setClearanceZoneId(clearanceZoneId);
		this.currency = currency;
		this.countryId = countryId;
	}

	/**
	 * Constructor Store
	 * @param storeId
	 * @param currency
	 */
	public Store(String storeId, String currency, String countryId) {
		this(storeId, Optional.<Integer>absent(), Optional.<Integer>absent(),Optional.<Integer>absent(), currency, countryId);
	}

	public Store() {
        /*Empty Constructor*/

	}

	/**
	 * Constructor Store
	 *
	 * @param storeId
	 * @param priceZoneId
	 * @param promoZoneId
	 * @param clearanceZoneId
	 * @param currency
	 */
	public Store(String storeId, Optional<Integer> priceZoneId,
				 Optional<Integer> promoZoneId, Optional<Integer> clearanceZoneId,
				 String currency) {
		this.storeId = storeId;
		setPriceZoneId(priceZoneId);
		setPromoZoneId(promoZoneId);
		setClearanceZoneId(clearanceZoneId);
		this.currency = currency;
	}

	public Store(String storeId, Optional<Integer> priceZoneId,
				 Optional<Integer> promoZoneId, String currency) {
		this.storeId = storeId;
		setPriceZoneId(priceZoneId);
		setPromoZoneId(promoZoneId);
		this.currency = currency;
	}

	/**
	 * Constructor Store
	 *
	 * @param storeId
	 * @param currency
	 */
	public Store(String storeId, String currency) {
		this(storeId, Optional.<Integer> absent(), Optional.<Integer> absent(),
				Optional.<Integer> absent(), currency);
	}

	public void setPriceZoneId(Optional<Integer> priceZoneId) {
		this.priceZoneId = priceZoneId.or(-1);
	}

	public void setPromoZoneId(Optional<Integer> promoZoneId) {
		this.promoZoneId = promoZoneId.or(-1);
	}

	public Optional<Integer> getPriceZoneId() {
		return (priceZoneId == -1) ? Optional.<Integer>absent() : Optional.of(priceZoneId) ;
	}

	public Optional<Integer> getPromoZoneId() {
		return (promoZoneId == -1) ? Optional.<Integer>absent() : Optional.of(promoZoneId) ;
	}

	public void setClearanceZoneId(Optional<Integer> clearanceZoneId) {
		this.clearanceZoneId = clearanceZoneId.or(-1);
	}
	public Optional<Integer> getClearanceZoneId() {
		return (clearanceZoneId == -1) ? Optional.<Integer>absent() : Optional.of(clearanceZoneId) ;
	}
	public String getStoreId() {
		return storeId;
	}

	public String getCountryId() {
		return countryId;
	}

	public void setCountryId(String countryId) {
		this.countryId = countryId;
	}

	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}


	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}

		Store store = (Store) o;
    /*Modified by Pallavi as part of sonar start*/
		if ((!currency.equals(store.currency))||(!storeId.equals(store.storeId))||(priceZoneId != store.priceZoneId)
				||(promoZoneId != store.promoZoneId)||(clearanceZoneId != store.clearanceZoneId)){
			return false;
		}
    /*Modified by Pallavi as part of sonar end*/


		return true;
	}

	@Override
	public int hashCode() {
		int result = storeId.hashCode();
		result = 31 * result + priceZoneId;
		result = 31 * result + promoZoneId;
		result = 31 * result + clearanceZoneId;
		result = 31 * result + currency.hashCode();
		result = 31 * result + countryId.hashCode();
		return result;
	}

	@Override
	public String toString() {
		return "Store{" +
				"storeId='" + storeId + '\'' +
				", priceZoneId=" + priceZoneId +
				", promoZoneId=" + promoZoneId +
				", clearanceZoneId=" + clearanceZoneId +
				", currency='" + currency + '\'' +
				", countryId='" + countryId + '\'' +
				'}';
	}

	public String getCurrency() {
		return currency;
	}
}
