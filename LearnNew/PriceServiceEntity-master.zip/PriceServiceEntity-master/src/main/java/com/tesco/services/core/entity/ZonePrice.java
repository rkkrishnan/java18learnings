package com.tesco.services.core.entity;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ZonePrice {

	@JsonProperty("clearanceZoneId")
	private String clearanceZoneId;
	@JsonProperty("countryCode")
	private String countryCode;
	@JsonProperty("currency")
	private String currency;
	@JsonProperty("zonesClearancePriceByDateTime")
	private Map<String, ClearancePriceByDateTime> zonesClearancePriceByDateTime = new HashMap<String, ClearancePriceByDateTime>();

	/**
	 * 
	 * @return The clearanceZoneId
	 */
	@JsonProperty("clearanceZoneId")
	public String getClearanceZoneId() {
		return clearanceZoneId;
	}

	/**
	 * 
	 * @param clearanceZoneId
	 *            The clearanceZoneId
	 */
	@JsonProperty("clearanceZoneId")
	public void setClearanceZoneId(String clearanceZoneId) {
		this.clearanceZoneId = clearanceZoneId;
	}

	/**
	 * 
	 * @return The countryCode
	 */
	@JsonProperty("countryCode")
	public String getCountryCode() {
		return countryCode;
	}

	/**
	 * 
	 * @param countryCode
	 *            The countryCode
	 */
	@JsonProperty("countryCode")
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	/**
	 * 
	 * @return The currency
	 */
	@JsonProperty("currency")
	public String getCurrency() {
		return currency;
	}

	/**
	 * 
	 * @param currency
	 *            The currency
	 */
	@JsonProperty("currency")
	public void setCurrency(String currency) {
		this.currency = currency;
	}

	/**
	 * @return The zonesClearancePriceByDateTime
	 */
	public Map<String, ClearancePriceByDateTime> getZonesClearancePriceByDateTime() {
		return zonesClearancePriceByDateTime;
	}

	/**
	 * @param zonesClearancePriceByDateTime
	 */
	public void setZonesClearancePriceByDateTime(
			Map<String, ClearancePriceByDateTime> zonesClearancePriceByDateTime) {
		this.zonesClearancePriceByDateTime = zonesClearancePriceByDateTime;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((clearanceZoneId == null) ? 0 : clearanceZoneId.hashCode());
		result = prime * result
				+ ((countryCode == null) ? 0 : countryCode.hashCode());
		result = prime * result
				+ ((currency == null) ? 0 : currency.hashCode());
		result = prime
				* result
				+ ((zonesClearancePriceByDateTime == null) ? 0
						: zonesClearancePriceByDateTime.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ZonePrice other = (ZonePrice) obj;
		if (clearanceZoneId == null) {
			if (other.clearanceZoneId != null)
				return false;
		} else if (!clearanceZoneId.equals(other.clearanceZoneId))
			return false;
		if (countryCode == null) {
			if (other.countryCode != null)
				return false;
		} else if (!countryCode.equals(other.countryCode))
			return false;
		if (currency == null) {
			if (other.currency != null)
				return false;
		} else if (!currency.equals(other.currency))
			return false;
		if (zonesClearancePriceByDateTime == null) {
			if (other.zonesClearancePriceByDateTime != null)
				return false;
		} else if (!zonesClearancePriceByDateTime
				.equals(other.zonesClearancePriceByDateTime))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ZonePrice [clearanceZoneId=" + clearanceZoneId
				+ ", countryCode=" + countryCode + ", currency=" + currency
				+ ", zonesClearancePriceByDateTime="
				+ zonesClearancePriceByDateTime + "]";
	}

}
