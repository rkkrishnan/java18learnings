package com.tesco.services.core.entity.promotion;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import static com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility.ANY;
import static com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility.NONE;

/**
 * @author a185
 *
 */
@SuppressWarnings("serial")
@JsonAutoDetect(fieldVisibility = ANY, getterVisibility = NONE, setterVisibility = NONE)
public class PromotionHierarchyEntity implements Serializable {

	@JsonProperty("hierarchyId")
	private String hierarchyId;

	@JsonProperty("offers")
	private Map<String, OfferEntity> promotions = new HashMap<String, OfferEntity>();

	@JsonProperty("createdDate")
	private String createdDate;

	@JsonProperty("createdById")
	private String createdById;

	@JsonProperty("lastUpdateDate")
	public String lastUpdateDate;

	@JsonProperty("lastUpdatedById")
	private String lastUpdatedById;

	public String getHierarchyId() {
		return hierarchyId;
	}

	public void setHierarchyId(String hierarchyId) {
		this.hierarchyId = hierarchyId;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedById() {
		return createdById;
	}

	public void setCreatedById(String createdById) {
		this.createdById = createdById;
	}

	public String getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(String lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	public String getLastUpdatedById() {
		return lastUpdatedById;
	}

	public void setLastUpdatedById(String lastUpdatedById) {
		this.lastUpdatedById = lastUpdatedById;
	}

	public Map<String, OfferEntity> getPromotions() {
		return promotions;
	}

	public void setPromotions(Map<String, OfferEntity> promotions) {
		this.promotions = promotions;
	}

	@Override
	public String toString() {
		return "PromotionHierarchyEntity [promotions=" + promotions
				+ ", createdDate=" + createdDate + ", createdById="
				+ createdById + ", lastUpdateDate=" + lastUpdateDate
				+ ", lastUpdatedById=" + lastUpdatedById + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((createdById == null) ? 0 : createdById.hashCode());
		result = prime * result
				+ ((createdDate == null) ? 0 : createdDate.hashCode());
		result = prime * result
				+ ((lastUpdateDate == null) ? 0 : lastUpdateDate.hashCode());
		result = prime * result
				+ ((lastUpdatedById == null) ? 0 : lastUpdatedById.hashCode());
		result = prime * result
				+ ((promotions == null) ? 0 : promotions.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PromotionHierarchyEntity other = (PromotionHierarchyEntity) obj;
		if (createdById == null) {
			if (other.createdById != null)
				return false;
		} else if (!createdById.equals(other.createdById))
			return false;
		if (createdDate == null) {
			if (other.createdDate != null)
				return false;
		} else if (!createdDate.equals(other.createdDate))
			return false;
		if (lastUpdateDate == null) {
			if (other.lastUpdateDate != null)
				return false;
		} else if (!lastUpdateDate.equals(other.lastUpdateDate))
			return false;
		if (lastUpdatedById == null) {
			if (other.lastUpdatedById != null)
				return false;
		} else if (!lastUpdatedById.equals(other.lastUpdatedById))
			return false;
		if (promotions == null) {
			if (other.promotions != null)
				return false;
		} else if (!promotions.equals(other.promotions))
			return false;
		return true;
	}

}
