package com.tesco.services.core.entity;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;

import static com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility.ANY;
import static com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility.NONE;

/**
 * Created by QU17 on 3/25/2015.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonAutoDetect(fieldVisibility = ANY, getterVisibility = NONE, setterVisibility = NONE)
public class Ean implements Serializable {
    public String getTpnc() {
        return tpnc;
    }

    @JsonProperty
    private String tpnc;

    @JsonProperty
    private String lastUpdateDate;

    public String getLastUpdatedDate() {
        return lastUpdateDate;
    }

    public void setLastUpdatedDate(String lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    public Ean(String tpnc) {
        this.tpnc = tpnc;
    }
    public Ean(){

    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        Ean ean = (Ean) o;

        if ((!tpnc.equals(ean.tpnc)) ||
                (!lastUpdateDate.equals(ean.lastUpdateDate))){
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int result = tpnc.hashCode();
        result = 31 * result + lastUpdateDate.hashCode();
        return result;
    }
    @Override
    public String toString() {
        return "Ean{" +
                "tpnc='" + tpnc + '\'' +
                ", lastUpdateDate='" + lastUpdateDate +
                '}';
    }
}
