# EventPublisher
**************************
This library provides utilities to configure JMS provider and provides templates to publish messages to topic

# Sample YAML configuration
***********************************
```html
eventPublishJMS:
-
  jms.config.id: REALTIME
  jms.topic.name: TSL.UK.DEV.EV.T.PRICE.events.pricechange.JSON.V1_0
  jms.retry.count: 3 
  jms.factory.class: com.tibco.tibjms.TibjmsConnectionFactory
  jms.factory.class.parameters:
  -
    type: java.lang.String
    name: FactoryURL
    value: tcp://xxxxxxxxxxx.dev.global.tesco.org:21122
  jms.factory.class.properties:
  -
    type: java.lang.String
    name: UserName
    value: user
  -
    type: java.lang.String
    name: UserPassword
    value: passwd
  -
    type: java.lang.Integer
    name: ConnAttemptCount
    value: 3
    primitive: true   
```

# Initialization of event publisher (sample)
*********************************************************************
```html
EventFactory factory = new JMSEventFactory();
EventConfiguration[] conf = new EventConfiguration[1];
factory.configureEventTemplate(conf);
```

# Publishing events
*******************
```html
JMSEventTemplate jmsEventTemplate = factory.getPublishTemplate(eventConfig.getConfigId());
EventData<Map<String, String>> event = new EventData<Map<String, String>>();
jmsEventTemplate.publishEvent(event);
```

# Current Version
************
```html
Repository URL: https://nexus.dev.global.tesco.org/nexus/content/repositories/
releases

Group Name    : com.tesco.services
Artifact Name : event-publisher
Artifact Type : jar
Version       : 2.0
Release Date  : 4th July 2016
```
