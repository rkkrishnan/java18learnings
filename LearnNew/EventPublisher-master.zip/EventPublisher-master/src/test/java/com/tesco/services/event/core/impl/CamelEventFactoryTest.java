package com.tesco.services.event.core.impl;

import jdk.nashorn.internal.ir.annotations.Ignore;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.tesco.services.event.core.EventConfigParameter;
import com.tesco.services.event.core.EventConfiguration;
import com.tesco.services.event.exception.EventConfigurationException;

public class CamelEventFactoryTest {

	CamelEventFactory camelEventFactory = null;

	EventConfiguration eventConfig = null;

	@Before
	public void setup() {
		eventConfig = new EventConfiguration();
		eventConfig.setConfigId("REALTIME");
		eventConfig.setTopicName("EventTopic");
		eventConfig.setTopicRetryCount(3);
		eventConfig.setJmsFactoryClassName("org.apache.activemq.ActiveMQConnectionFactory");

		EventConfigParameter factoryConstructorParameters = new EventConfigParameter();
		factoryConstructorParameters.setName("FactoryURL");
		factoryConstructorParameters.setPrimitive(false);
		factoryConstructorParameters.setType("java.lang.String");
		factoryConstructorParameters.setValue("failover:(tcp://localhost:61617)");

		EventConfigParameter eventConfigParams[] = { factoryConstructorParameters };
		eventConfig.setFactoryConstructorParameters(eventConfigParams);

		camelEventFactory = new CamelEventFactory();
	}
	
	@Test
	public void verifyConfigureEventTemplateCallWithFactoryProperties() throws EventConfigurationException {
		EventConfigParameter factoryClassCfgParam = new EventConfigParameter();
		EventConfigParameter[] factClassProperties = new EventConfigParameter[5];
		factoryClassCfgParam.setName("UserName");
        factoryClassCfgParam.setType("java.lang.String");
        factoryClassCfgParam.setValue("price");
        factClassProperties[0] = factoryClassCfgParam;
        
        factoryClassCfgParam = new EventConfigParameter();
        factoryClassCfgParam.setName("Password");
        factoryClassCfgParam.setType("java.lang.String");
        factoryClassCfgParam.setValue("prcsvc");
        factClassProperties[1] = factoryClassCfgParam;
        
        factoryClassCfgParam = new EventConfigParameter();
        factoryClassCfgParam.setName("DispatchAsync");
        factoryClassCfgParam.setType("java.lang.Boolean");
        factoryClassCfgParam.setValue("false");
        factoryClassCfgParam.setPrimitive(true);
        factClassProperties[2] = factoryClassCfgParam;
        
        factoryClassCfgParam = new EventConfigParameter();
        factoryClassCfgParam.setName("OptimizeAcknowledgeTimeOut");
        factoryClassCfgParam.setType("java.lang.Long");
        factoryClassCfgParam.setValue("0");
        factoryClassCfgParam.setPrimitive(true);
        factClassProperties[3] = factoryClassCfgParam;
        
        
        factoryClassCfgParam = new EventConfigParameter();
        factoryClassCfgParam.setName("AuditDepth");
        factoryClassCfgParam.setType("java.lang.Integer");
        factoryClassCfgParam.setValue("0");
        factoryClassCfgParam.setPrimitive(true);
        factClassProperties[4] = factoryClassCfgParam;
        
        
        eventConfig.setFactoryProperties(factClassProperties);
		EventConfiguration eventConfigArray[] = { eventConfig };
		camelEventFactory.configureEventTemplate(eventConfigArray);
		Assert.assertEquals("price", camelEventFactory.eventConfigMap.get("REALTIME").getFactoryProperties()[0].getValue());
		Assert.assertEquals("prcsvc", camelEventFactory.eventConfigMap.get("REALTIME").getFactoryProperties()[1].getValue());
		Assert.assertEquals(eventConfig.toString(), camelEventFactory.eventConfigMap.get("REALTIME").toString());
	}
	
	
	@Test
	public void verifyConfigureEventTemplateCallWithoutFactoryProperties() throws EventConfigurationException {
		eventConfig = new EventConfiguration();
		eventConfig.setConfigId("REALTIME");
		eventConfig.setTopicName("EventTopic");
		eventConfig.setTopicRetryCount(3);
		eventConfig.setJmsFactoryClassName("org.apache.activemq.ActiveMQConnectionFactory");
		EventConfiguration eventConfigArray[] = { eventConfig };
		camelEventFactory.configureEventTemplate(eventConfigArray);
		Assert.assertEquals(eventConfig.toString(), camelEventFactory.eventConfigMap.get("REALTIME").toString());
	}
	
	@Test
	public void verifyConfigureEventTemplateCall() throws EventConfigurationException {
		EventConfiguration eventConfigArray[] = { eventConfig };
		camelEventFactory.configureEventTemplate(eventConfigArray);
		Assert.assertEquals(true, camelEventFactory.eventConfigMap.containsKey("REALTIME"));
		Assert.assertEquals(eventConfig.toString(), camelEventFactory.eventConfigMap.get("REALTIME").toString());
	}
	
	//@Test(expected = EventConfigurationException.class)
	@Ignore
	public void configureEventTemplateCheckException() throws EventConfigurationException{
		EventConfiguration eventConfigs = new EventConfiguration();
		eventConfigs.setConfigId(null);
		eventConfigs.setTopicName("EventTopic");
		eventConfigs.setTopicRetryCount(3);
		eventConfigs.setJmsFactoryClassName("org.apache.activemq.ActiveMQConnectionFactory");

		EventConfigParameter factoryConstructorParameter = new EventConfigParameter();
		factoryConstructorParameter.setName("FactoryURL");
		factoryConstructorParameter.setPrimitive(false);
		factoryConstructorParameter.setType("java.lang.String");
		factoryConstructorParameter.setValue("failover:(tcp://localhost:61617)");

		EventConfigParameter eventConfigParam[] = { factoryConstructorParameter };
		eventConfigs.setFactoryConstructorParameters(eventConfigParam);
		
		EventConfiguration eventConfigArray[] = { eventConfigs };
		camelEventFactory.configureEventTemplate(eventConfigArray);
	}

	@Test(expected = EventConfigurationException.class)
	public void getPublishTemplateCallExceptionCheck() throws EventConfigurationException {
		camelEventFactory.getPublishTemplate("");
	}

	@Test
	public void verifyGetPublishTemplateCall() throws Exception{
		EventConfiguration eventConfigArray[] = { eventConfig };
		camelEventFactory.configureEventTemplate(eventConfigArray);
		camelEventFactory.getPublishTemplate("REALTIME");
		camelEventFactory.eventTemplateMap.get("REALTIME");
		Assert.assertTrue(camelEventFactory.eventTemplateMap.size()>0);
		Assert.assertTrue(camelEventFactory.eventConfigMap.size()>0);
	}
	

}
