package com.tesco.services.event.core.impl;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Processor;
import org.apache.camel.ProducerTemplate;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tesco.services.event.core.Event;
import com.tesco.services.event.core.EventConfigParameter;
import com.tesco.services.event.core.EventConfiguration;
import com.tesco.services.event.exception.EventPublishException;

@RunWith(MockitoJUnitRunner.class)
public class CamelEventTemplateTest {

	CamelEventTemplate camelEventTemplate = null;

	@Mock
	ProducerTemplate prodTemplate;

	Event<Map<String,String>> eventData = new EventData<Map<String,String>>();
	String payloadData = "";
	Map<String, String> headerMap = new HashMap<String, String>();

	@Before
	public void setup() throws JsonProcessingException {
		camelEventTemplate = new CamelEventTemplate(prodTemplate, getEventConfiguration()[0]);
		eventData = getEventData();
		payloadData = camelEventTemplate.getObjMapper().writeValueAsString(eventData.getPayloadData());
		headerMap = eventData.getHeaderData();
	}

	@Test(expected = EventPublishException.class)
	public void checkForExceptionOnNullCallOnPublishEvent() throws Exception {
		camelEventTemplate = new CamelEventTemplate(prodTemplate, getEventConfiguration()[0]);
		camelEventTemplate.publishEvent(null);
	}

	@Test(expected = EventPublishException.class)
	public void checkForExceptionOnJsonExceptionOnCallOnPublishEvent() throws Exception {
		camelEventTemplate = new CamelEventTemplate(prodTemplate, getEventConfiguration()[0]);
		CamelEventTemplate spyCamelEventTemplate = Mockito.spy(camelEventTemplate);
		ObjectMapper objectMapper = Mockito.mock(ObjectMapper.class);
		Mockito.doReturn(objectMapper).when(spyCamelEventTemplate).getObjMapper();
		when(objectMapper.writeValueAsString(getEventData().getPayloadData()))
				.thenThrow(new JsonProcessingException("msg") {
					private static final long serialVersionUID = 1L;
				});
		Mockito.doReturn("msgid").when(spyCamelEventTemplate).publishToTopic(payloadData, headerMap);
		spyCamelEventTemplate.publishEvent(eventData);
	}

	@Test
	public void verifyPublishToTopicCall() throws EventPublishException, JsonProcessingException {
		Exchange exchange = Mockito.mock(Exchange.class);
		Message exchangeMessage = Mockito.mock(Message.class);
		Mockito.when(exchange.getIn()).thenReturn(exchangeMessage);
		Mockito.doNothing().when(exchangeMessage).setHeader("PriceId", "456");
		Mockito.doNothing().when(exchangeMessage).setBody(payloadData);
		Mockito.when(exchange.getOut()).thenReturn(exchangeMessage);
		Mockito.when(exchangeMessage.getMessageId()).thenReturn("VDI-1234");
		Mockito.when(prodTemplate.send(Matchers.anyString(), Matchers.any(Processor.class))).thenReturn(exchange);
		Assert.assertEquals("VDI-1234", camelEventTemplate.publishToTopic(payloadData, headerMap));
	}

	@Test
	public void verifyPublishEventCall() throws EventPublishException, JsonProcessingException {
		String payloadString = "{PriceId=456, ProductId=1111}";
		CamelEventTemplate spyCamelEventTemplate = Mockito.spy(camelEventTemplate);
		ObjectMapper objectMapper = Mockito.mock(ObjectMapper.class);
		Mockito.doReturn("{\"PriceId\":\"456\",\"ProductId\":\"1111\"}").when(objectMapper)
				.writeValueAsString(eventData.getPayloadData());
		Mockito.doReturn(objectMapper).when(spyCamelEventTemplate).getObjMapper();
		Mockito.doReturn("VDI-1234").when(spyCamelEventTemplate).publishToTopic(payloadData, headerMap);
		Assert.assertEquals("VDI-1234", spyCamelEventTemplate.publishEvent(getEventData()));

		ArgumentCaptor<Map> stringArgument = ArgumentCaptor.forClass(Map.class);
		Mockito.verify(objectMapper, Mockito.times(1)).writeValueAsString(stringArgument.capture());
		Assert.assertEquals(payloadString, stringArgument.getValue().toString());
	}

	@Test
	public void verifySetObjMapperCall() {
		ObjectMapper objMapper = new ObjectMapper();
		ProducerTemplate prodTemplate = Mockito.mock(ProducerTemplate.class);
		CamelEventTemplate camelEventTemplate = new CamelEventTemplate(prodTemplate, getEventConfiguration()[0]);
		camelEventTemplate.setObjMapper(objMapper);
		Assert.assertTrue(objMapper.equals(camelEventTemplate.getObjMapper()));
	}
	
	@Test
	public void verifyPublishEventCallForComplexData() throws EventPublishException, JsonProcessingException {
		ProducerTemplate prodTemplate1 = Mockito.mock(ProducerTemplate.class);
		CamelEventTemplate complexDataCamelEventTemplate = new CamelEventTemplate(prodTemplate1, getEventConfiguration()[0]);
		MapEvent complexEventData = getComplexEventData();
		String complexPayloadData = complexDataCamelEventTemplate.getObjMapper().writeValueAsString(complexEventData.getPayloadData());
		Map<String, String> complexHeaderMap = complexEventData.getHeaderData();
		String payloadString = "{pricingLocation=[{locRef=2005, locType=S}], clearanceOfferId=MM}";
		CamelEventTemplate spyCamelEventTemplate = Mockito.spy(complexDataCamelEventTemplate);
		ObjectMapper objectMapper1 = Mockito.mock(ObjectMapper.class);
		Mockito.doReturn("{\"pricingLocation\":[{\"locRef\":\"2005\",\"locType\":\"S\"}],\"clearanceOfferId\":\"MM\"}").when(objectMapper1)
				.writeValueAsString(complexEventData.getPayloadData());
		Mockito.doReturn(objectMapper1).when(spyCamelEventTemplate).getObjMapper();
		Mockito.doReturn("VDI-1234").when(spyCamelEventTemplate).publishToTopic(complexPayloadData, complexHeaderMap);
		Assert.assertEquals("VDI-1234", spyCamelEventTemplate.publishEvent(getComplexEventData()));

		ArgumentCaptor<Map> stringArgument = ArgumentCaptor.forClass(Map.class);
		Mockito.verify(objectMapper1, Mockito.times(1)).writeValueAsString(stringArgument.capture());
		Assert.assertEquals(payloadString, stringArgument.getValue().toString());
	}

	private Event<Map<String,String>> getEventData() {
		EventData<Map<String,String>> event = new EventData<Map<String,String>>();
		event.setEventType("REGPRCCHGCRE");
		HashMap<String, String> payloadMap = new HashMap<String, String>();
		payloadMap.put("ProductId", "1111");
		payloadMap.put("PriceId", "456");
		HashMap<String, String> headerMap = new HashMap<String, String>();
		headerMap.put("PriceId", "1234");
		headerMap.put("Zoneid", "5");
		event.setHeaderData(headerMap);
		event.setPayloadData(payloadMap);
		event.addHeaderEntry("test", "123");
		event.removeHeaderEntry("test");
		event.getEventType();
		return event;
	}
	
	private MapEvent getComplexEventData() {
		
		MapEvent data = new MapEvent();
		HashMap<String, String> headerMap = new HashMap<>();
		headerMap.put("country", "UK");
		headerMap.put("EventType", "ClearanceDeleted");
		headerMap.put("LeadTimeDays", "0");
		data.setHeaderData(headerMap);
	
		Map<String,Object> clearanceMap = new HashMap<>();
		List<Map<String,Object>> locations = new ArrayList<Map<String,Object>>();
		Map<String,Object> locationMap= new HashMap<String,Object>();
		locationMap.put("locType", "S");
		locationMap.put("locRef", "2005");
		locations.add(locationMap);
		clearanceMap.put("pricingLocation", locations);
		clearanceMap.put("clearanceOfferId", "MM");
		data.setPayloadData(clearanceMap);
		
		data.setEventType("ClearanceDeleted");
		return data;
	}


	private EventConfiguration[] getEventConfiguration() {
		EventConfiguration eventConfig = new EventConfiguration();
		eventConfig.setConfigId("REALTIME");
		eventConfig.setTopicName("EventTopic");
		eventConfig.setTopicRetryCount(3);
		eventConfig.setJmsFactoryClassName("org.apache.activemq.ActiveMQConnectionFactory");

		EventConfigParameter factoryConstructorParameters = new EventConfigParameter();
		factoryConstructorParameters.setName("FactoryURL");
		factoryConstructorParameters.setPrimitive(false);
		factoryConstructorParameters.setType("java.lang.String");
		factoryConstructorParameters.setValue("failover:(tcp://localhost:61617)");

		EventConfigParameter eventConfigParams[] = { factoryConstructorParameters };
		eventConfig.setFactoryConstructorParameters(eventConfigParams);

		EventConfiguration[] configuration = { eventConfig };
		return configuration;
	}

}
