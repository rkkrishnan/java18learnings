package com.tesco.leadtime.core;

import static org.junit.Assert.assertEquals;

import org.joda.time.DateTime;
import org.junit.Test;

import com.tesco.services.leadtime.core.LeadTimeUtility;

public class LeadTimeUtilityTest {

	@Test
	public void checkLeadTime() {

		DateTime effectiveDate = DateTime.parse("2016-03-20T08:00:00+00:00");
		DateTime publishingDate = DateTime.parse("2016-03-17T07:06:45+00:00");
		int leadTime = LeadTimeUtility.getLeadTime(effectiveDate, publishingDate);

		assertEquals(3, leadTime);

	}

	@Test
	public void checkNegativeLeadTime() {

		DateTime effectiveDate = DateTime.parse("2016-03-20T08:00:00+00:00");
		DateTime publishingDate = DateTime.parse("2016-03-25T07:06:45+00:00");

		int leadTime = LeadTimeUtility.getLeadTime(effectiveDate, publishingDate);

		assertEquals(-5, leadTime);

	}

	@Test
	public void checkZeroLeadTime() {

		DateTime effectiveDate = DateTime.parse("2016-03-20T08:00:00+00:00");
		DateTime publishingDate = DateTime.parse("2016-03-20T08:00:00+00:00");

		int leadTime = LeadTimeUtility.getLeadTime(effectiveDate, publishingDate);

		assertEquals(0, leadTime);

	}

	@Test
	public void checkLeadTimeForHourDifference() {

		DateTime effectiveDate = DateTime.parse("2016-04-12T23:30:00+01:00");
		DateTime publishingDate = DateTime.parse("2016-04-11T00:30:00+01:00");

		int leadTime = LeadTimeUtility.getLeadTime(effectiveDate, publishingDate);

		assertEquals(1, leadTime);

	}

	@Test
	public void checkLeadTimeForMinuteDifference() {

		DateTime effectiveDate = DateTime.parse("2016-04-02T00:00:00+01:00");
		DateTime publishingDate = DateTime.parse("2016-04-01T23:59:59+01:00");

		int leadTime = LeadTimeUtility.getLeadTime(effectiveDate, publishingDate);

		assertEquals(1, leadTime);

	}

	@Test
	public void checkLeadTimeForSecDifference() {

		DateTime effectiveDate = DateTime.parse("2016-04-12T23:59:59+01:00");
		DateTime publishingDate = DateTime.parse("2016-04-11T00:00:01+01:00");

		int leadTime = LeadTimeUtility.getLeadTime(effectiveDate, publishingDate);

		assertEquals(1, leadTime);

	}

	@Test
	public void shouldLeadTimeDaysPositive() {

		DateTime effectiveDate = DateTime.parse("2016-04-12T23:59:59+00:00");
		DateTime publishingDate = DateTime.parse("2016-04-11T00:00:01+00:00");
		int leadDays = LeadTimeUtility.getLeadTime(effectiveDate, publishingDate);
		assertEquals(1, leadDays);
	}

	@Test
	public void shouldLeadTimeDaysNegative() {

		DateTime effectiveDate = DateTime.parse("2016-04-10T23:59:59+00:00");
		DateTime publishingDate = DateTime.parse("2016-04-12T00:00:01+00:00");

		int leadDays = LeadTimeUtility.getLeadTime(effectiveDate, publishingDate);
		assertEquals(-2, leadDays);
	}

	@Test
	public void checkLeadTimeForUKWithoutDayLightSaving_Section1() {

		DateTime effectiveDate1 = DateTime.parse("2016-03-02T00:00:00+00:00");
		DateTime publishingDate1 = DateTime.parse("2016-03-01T10:30:00+00:00");

		DateTime effectiveDate2 = DateTime.parse("2016-03-02T00:00:00+00:00");
		DateTime publishingDate2 = DateTime.parse("2016-03-01T23:59:59+00:00");

		DateTime effectiveDate3 = DateTime.parse("2016-03-02T00:00:00+00:00");
		DateTime publishingDate3 = DateTime.parse("2016-03-02T00:00:00+00:00");

		int leadTime1 = LeadTimeUtility.getLeadTime(effectiveDate1, publishingDate1);
		int leadTime2 = LeadTimeUtility.getLeadTime(effectiveDate2, publishingDate2);
		int leadTime3 = LeadTimeUtility.getLeadTime(effectiveDate3, publishingDate3);

		assertEquals(1, leadTime1);
		assertEquals(1, leadTime2);
		assertEquals(0, leadTime3);

	}

	@Test
	public void checkLeadTimeForUKWithoutDayLightSaving_Section2() {

		DateTime effectiveDate1 = DateTime.parse("2016-03-02T00:00:00+00:00");
		DateTime publishingDate1 = DateTime.parse("2016-03-02T10:30:00+00:00");

		DateTime effectiveDate2 = DateTime.parse("2016-03-01T00:00:00+00:00");
		DateTime publishingDate2 = DateTime.parse("2016-03-02T10:30:00+00:00");

		DateTime effectiveDate3 = DateTime.parse("2016-05-06T00:00:00+00:00");
		DateTime publishingDate3 = DateTime.parse("2016-03-01T10:30:00+00:00");

		DateTime effectiveDate4 = DateTime.parse("2017-01-02T00:00:00+00:00");
		DateTime publishingDate4 = DateTime.parse("2016-12-30T10:30:00+00:00");

		DateTime effectiveDate5 = DateTime.parse("2016-03-01T00:00:00+00:00");
		DateTime publishingDate5 = DateTime.parse("2016-02-29T23:59:59+00:00");

		int leadTime1 = LeadTimeUtility.getLeadTime(effectiveDate1, publishingDate1);
		int leadTime2 = LeadTimeUtility.getLeadTime(effectiveDate2, publishingDate2);
		int leadTime3 = LeadTimeUtility.getLeadTime(effectiveDate3, publishingDate3);
		int leadTime4 = LeadTimeUtility.getLeadTime(effectiveDate4, publishingDate4);
		int leadTime5 = LeadTimeUtility.getLeadTime(effectiveDate5, publishingDate5);

		assertEquals(0, leadTime1);
		assertEquals(-1, leadTime2);
		assertEquals(66, leadTime3);
		assertEquals(3, leadTime4);
		assertEquals(1, leadTime5);
	}

	@Test
	public void checkLeadTimeForUKWithDayLightSaving() {

		DateTime effectiveDate1 = DateTime.parse("2016-04-02T00:00:00+01:00");
		DateTime publishingDate1 = DateTime.parse("2016-04-01T10:30:00+01:00");

		DateTime effectiveDate2 = DateTime.parse("2016-04-02T00:00:00+01:00");
		DateTime publishingDate2 = DateTime.parse("2016-04-01T23:59:59+01:00");

		DateTime effectiveDate3 = DateTime.parse("2016-04-02T00:00:00+01:00");
		DateTime publishingDate3 = DateTime.parse("2016-04-02T00:00:00+01:00");

		DateTime effectiveDate4 = DateTime.parse("2016-04-02T00:00:00+01:00");
		DateTime publishingDate4 = DateTime.parse("2016-04-02T10:30:00+01:00");

		DateTime effectiveDate5 = DateTime.parse("2016-04-01T00:00:00+01:00");
		DateTime publishingDate5 = DateTime.parse("2016-04-02T10:30:00+01:00");

		DateTime effectiveDate6 = DateTime.parse("2016-05-06T00:00:00+01:00");
		DateTime publishingDate6 = DateTime.parse("2016-04-01T10:30:00+01:00");

		int leadTime1 = LeadTimeUtility.getLeadTime(effectiveDate1, publishingDate1);
		int leadTime2 = LeadTimeUtility.getLeadTime(effectiveDate2, publishingDate2);
		int leadTime3 = LeadTimeUtility.getLeadTime(effectiveDate3, publishingDate3);
		int leadTime4 = LeadTimeUtility.getLeadTime(effectiveDate4, publishingDate4);
		int leadTime5 = LeadTimeUtility.getLeadTime(effectiveDate5, publishingDate5);
		int leadTime6 = LeadTimeUtility.getLeadTime(effectiveDate6, publishingDate6);

		assertEquals(1, leadTime1);
		assertEquals(1, leadTime2);
		assertEquals(0, leadTime3);
		assertEquals(0, leadTime4);
		assertEquals(-1, leadTime5);
		assertEquals(35, leadTime6);

	}

	@Test
	public void checkLeadTimeForUKandTH() {

		DateTime effectiveDate1 = DateTime.parse("2016-03-03T00:00:00+07:00");
		DateTime publishingDate1 = DateTime.parse("2016-03-01T00:00:00+00:00");

		DateTime effectiveDate2 = DateTime.parse("2016-03-03T00:00:00+07:00");
		DateTime publishingDate2 = DateTime.parse("2016-03-02T16:59:59+00:00");

		DateTime effectiveDate3 = DateTime.parse("2016-03-03T00:00:00+07:00");
		DateTime publishingDate3 = DateTime.parse("2016-03-02T17:00:00+00:00");

		DateTime effectiveDate4 = DateTime.parse("2016-05-06T00:00:00+07:00");
		DateTime publishingDate4 = DateTime.parse("2016-03-01T10:30:00+00:00");

		int leadTime1 = LeadTimeUtility.getLeadTime(effectiveDate1, publishingDate1);
		int leadTime2 = LeadTimeUtility.getLeadTime(effectiveDate2, publishingDate2);
		int leadTime3 = LeadTimeUtility.getLeadTime(effectiveDate3, publishingDate3);
		int leadTime4 = LeadTimeUtility.getLeadTime(effectiveDate4, publishingDate4);

		assertEquals(2, leadTime1);
		assertEquals(1, leadTime2);
		assertEquals(0, leadTime3);
		assertEquals(66, leadTime4);

	}

	@Test
	public void checkLeadTimeForTHandTH() {

		DateTime effectiveDate1 = DateTime.parse("2016-03-02T00:00:00+07:00");
		DateTime publishingDate1 = DateTime.parse("2016-03-02T07:00:00+07:00");

		DateTime effectiveDate2 = DateTime.parse("2016-03-03T00:00:00+07:00");
		DateTime publishingDate2 = DateTime.parse("2016-03-02T23:59:59+07:00");

		DateTime effectiveDate3 = DateTime.parse("2016-03-03T00:00:00+07:00");
		DateTime publishingDate3 = DateTime.parse("2016-03-03T00:00:00+07:00");

		DateTime effectiveDate4 = DateTime.parse("2016-05-06T00:00:00+07:00");
		DateTime publishingDate4 = DateTime.parse("2016-03-01T06:00:00+07:00");

		int leadTime1 = LeadTimeUtility.getLeadTime(effectiveDate1, publishingDate1);
		int leadTime2 = LeadTimeUtility.getLeadTime(effectiveDate2, publishingDate2);
		int leadTime3 = LeadTimeUtility.getLeadTime(effectiveDate3, publishingDate3);
		int leadTime4 = LeadTimeUtility.getLeadTime(effectiveDate4, publishingDate4);

		assertEquals(0, leadTime1);
		assertEquals(1, leadTime2);
		assertEquals(0, leadTime3);
		assertEquals(66, leadTime4);
	}

	@Test
	public void checkLeadTimeForINandTH() {
		DateTime effectiveDate1 = DateTime.parse("2016-03-02T07:00:00+07:00");
		DateTime publishingDate1 = DateTime.parse("2016-03-02T07:00:00+05:30");

		DateTime effectiveDate2 = DateTime.parse("2016-03-03T00:00:00+07:00");
		DateTime publishingDate2 = DateTime.parse("2016-03-02T23:59:59+05:30");

		DateTime effectiveDate3 = DateTime.parse("2016-03-02T00:00:00+07:00");
		DateTime publishingDate3 = DateTime.parse("2016-03-02T23:59:59+05:30");

		int leadTime1 = LeadTimeUtility.getLeadTime(effectiveDate1, publishingDate1);
		int leadTime2 = LeadTimeUtility.getLeadTime(effectiveDate2, publishingDate2);
		int leadTime3 = LeadTimeUtility.getLeadTime(effectiveDate3, publishingDate3);

		assertEquals(0, leadTime1);
		assertEquals(0, leadTime2);
		assertEquals(-1, leadTime3);
	}

}
