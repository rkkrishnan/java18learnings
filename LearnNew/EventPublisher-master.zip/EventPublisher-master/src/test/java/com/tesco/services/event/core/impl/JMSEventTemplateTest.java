package com.tesco.services.event.core.impl;

import java.util.HashMap;
import java.util.Map;

import javax.jms.Connection;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.Topic;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.tesco.services.event.core.Event;
import com.tesco.services.event.core.EventConfiguration;
import com.tesco.services.event.exception.EventConfigurationException;
import com.tesco.services.event.exception.EventPublishException;

@RunWith(MockitoJUnitRunner.class)
public class JMSEventTemplateTest {

	EventConfiguration eventConfig = null;

	@Mock
	Connection mockConnection;

	@Mock
	Session mockSession;

	@Mock
	MessageProducer mockPublisher;

	@Mock
	Topic mockTopic;

	@Mock
	TextMessage mockEventMsg;

	JMSEventTemplate jmsEventTemplate;

	@Before
	public void setUp() throws Exception {
		eventConfig = new EventConfiguration();
		eventConfig.setConfigId("REALTIME");
		eventConfig.setTopicName("EventTopic");
		eventConfig.setTopicRetryCount(3);
		eventConfig
				.setJmsFactoryClassName("org.apache.activemq.ActiveMQConnectionFactory");

		Mockito.when(mockSession.createTopic("EventTopic")).thenReturn(
				mockTopic);

		Mockito.when(mockSession.createProducer(mockTopic)).thenReturn(
				mockPublisher);

		Mockito.when(
				mockConnection.createSession(false, Session.AUTO_ACKNOWLEDGE))
				.thenReturn(mockSession);

		Mockito.when(mockSession.createTextMessage(Matchers.anyString()))
				.thenReturn(mockEventMsg);

		Mockito.doNothing().when(mockPublisher).send(mockEventMsg);
	}

	@Test
	public void testPublishEvent() throws EventConfigurationException,
			EventPublishException {
		jmsEventTemplate = new JMSEventTemplate(mockSession, eventConfig);
		Assert.assertNotNull(jmsEventTemplate.publishEvent(getEventData()));
	}

	@Test(expected = EventPublishException.class)
	public void testPublishEventExceptionCreateMessage()
			throws EventConfigurationException, EventPublishException,
			JMSException {

		Mockito.when(mockSession.createTextMessage(Matchers.anyString()))
				.thenThrow(new JMSException("bad jms session"));

		jmsEventTemplate = new JMSEventTemplate(mockSession, eventConfig);
		jmsEventTemplate.publishEvent(getEventData());
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test(expected = EventPublishException.class)
	public void testPublishEventExceptionParsing()
			throws EventConfigurationException, EventPublishException,
			JMSException {
		jmsEventTemplate = new JMSEventTemplate(mockSession, eventConfig);

		EventData<Map<String, String>> event = new EventData<Map<String, String>>();
		event.setEventType("REGPRCCHGCRE");
		HashMap<String, String> payloadMap = new HashMap();
		payloadMap.put(null, null);
		event.setPayloadData(payloadMap);

		jmsEventTemplate.publishEvent(event);
	}

	@Test(expected = EventConfigurationException.class)
	public void testConfigException() throws EventConfigurationException,
			EventPublishException, JMSException {

		Mockito.when(mockSession.createProducer(mockTopic)).thenThrow(
				new JMSException("bad jms session"));

		jmsEventTemplate = new JMSEventTemplate(mockSession, eventConfig);
	}

	private Event<Map<String, String>> getEventData() {
		EventData<Map<String, String>> event = new EventData<Map<String, String>>();
		event.setEventType("REGPRCCHGCRE");
		HashMap<String, String> payloadMap = new HashMap<String, String>();
		payloadMap.put("ProductId", "1111");
		payloadMap.put("PriceId", "456");
		HashMap<String, String> headerMap = new HashMap<String, String>();
		headerMap.put("PriceId", "1234");
		headerMap.put("Zoneid", "5");
		event.setHeaderData(headerMap);
		event.setPayloadData(payloadMap);
		event.addHeaderEntry("test", "123");
		event.removeHeaderEntry("test");
		event.getEventType();
		return event;
	}

}
