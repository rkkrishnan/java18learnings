package com.tesco.services.event.core.impl;

import static org.junit.Assert.fail;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.Topic;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.tesco.services.event.core.EventConfiguration;
import com.tesco.services.event.exception.EventConfigurationException;

@RunWith(MockitoJUnitRunner.class)
public class JMSEventFactoryTest {

	EventConfiguration eventConfig = null;

	JMSEventFactory jmsEventFactory = null;

	@Mock
	ConnectionFactory mockConnectionFactory;

	@Mock
	Connection mockConnection;

	@Mock
	Session mockSession;

	@Mock
	MessageProducer mockPublisher;

	@Mock
	Topic mockTopic;

	@SuppressWarnings("unused")
	@Before
	public void setUp() throws Exception {
		eventConfig = new EventConfiguration();
		eventConfig.setConfigId("REALTIME");
		eventConfig.setTopicName("EventTopic");
		eventConfig.setTopicRetryCount(3);
		eventConfig
				.setJmsFactoryClassName("org.apache.activemq.ActiveMQConnectionFactory");

		Mockito.when(mockSession.createTopic("EventTopic")).thenReturn(
				mockTopic);

		Mockito.when(mockSession.createProducer(mockTopic)).thenReturn(
				mockPublisher);

		Mockito.when(
				mockConnection.createSession(false, Session.AUTO_ACKNOWLEDGE))
				.thenReturn(mockSession);

		Mockito.when(mockConnectionFactory.createConnection()).thenReturn(
				mockConnection);

		jmsEventFactory = new JMSEventFactory(mockConnectionFactory);

		JMSEventFactory testFactory = new JMSEventFactory();
	}

	@Test
	public void testConfigureEventTemplate() {
		EventConfiguration eventConfigArray[] = { eventConfig };
		try {
			jmsEventFactory.configureEventTemplate(eventConfigArray);
			Assert.assertNotNull(jmsEventFactory.getPublishTemplate(eventConfig
					.getConfigId()));
		} catch (EventConfigurationException e) {
			fail("Not expected to fail");
		}
	}

	@Test(expected = EventConfigurationException.class)
	public void testConfigureEventTemplateException1()
			throws EventConfigurationException {
		EventConfiguration eventConfigArray[] = { null };
		jmsEventFactory.configureEventTemplate(eventConfigArray);
	}

	@Test(expected = EventConfigurationException.class)
	public void testConfigureEventTemplateException2()
			throws EventConfigurationException, JMSException {
		Mockito.when(mockConnectionFactory.createConnection()).thenThrow(
				new JMSException("bad connection factory"));
		jmsEventFactory = new JMSEventFactory(mockConnectionFactory);
		EventConfiguration eventConfigArray[] = { eventConfig };
		jmsEventFactory.configureEventTemplate(eventConfigArray);
	}
}
