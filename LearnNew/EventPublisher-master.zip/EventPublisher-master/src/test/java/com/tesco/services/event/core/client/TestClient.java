package com.tesco.services.event.core.client;

import java.util.HashMap;

import com.tesco.services.event.core.EventConfigParameter;
import com.tesco.services.event.core.EventConfiguration;
import com.tesco.services.event.core.EventFactory;
import com.tesco.services.event.core.EventTemplate;
import com.tesco.services.event.core.impl.CamelEventFactory;
import com.tesco.services.event.core.impl.EventData;
import com.tesco.services.event.core.impl.JMSEventFactory;
import com.tesco.services.event.exception.EventConfigurationException;
import com.tesco.services.event.exception.EventPublishException;

public class TestClient {

	public static void main(String[] args) throws EventConfigurationException,
			EventPublishException {
		// EventData
		EventData data = new EventData();
		HashMap<String, String> payloadMap = new HashMap<String, String>();
		payloadMap.put("ProductId", "1111");
		payloadMap.put("PriceId", "456");
		payloadMap.put("PriceId", "897");
		HashMap<String, String> headerMap = new HashMap<String, String>();
		headerMap.put("PriceId", "1234");
		headerMap.put("Zoneid", "5");

		// EventFactory configuration
		// EventFactory factory= new CamelEventFactory();
		// EventConfiguration eventConfig = new EventConfiguration();
		// eventConfig = new EventConfiguration();
		// eventConfig.setConfigId("REALTIME");
		// eventConfig.setTopicName("EventTopic");
		// eventConfig.setTopicRetryCount(3);
		// eventConfig.setJmsFactoryClassName("org.apache.activemq.ActiveMQConnectionFactory");
		// EventConfiguration eventConfigArray[] = { eventConfig };
		//
		// EventConfigParameter factoryConstructorParameters = new
		// EventConfigParameter();
		// factoryConstructorParameters.setName("FactoryURL");
		// factoryConstructorParameters.setPrimitive(false);
		// factoryConstructorParameters.setType("java.lang.String");
		// factoryConstructorParameters.setValue("failover:(tcp://localhost:61616)?maxReconnectAttempts=3");

		EventFactory factory = new JMSEventFactory();
		EventConfiguration eventConfig = new EventConfiguration();
		eventConfig = new EventConfiguration();
		eventConfig.setConfigId("REALTIME");
		eventConfig
				.setTopicName("TSL.UK.PRD.EV.T.PRICE.Price.PriceEvents.JSON.V1_0");
		
		
		eventConfig.setTopicRetryCount(3);
		eventConfig
				.setJmsFactoryClassName("com.tibco.tibjms.TibjmsConnectionFactory");
		EventConfiguration eventConfigArray[] = { eventConfig };

		EventConfigParameter factoryConstructorParameters = new EventConfigParameter();
		factoryConstructorParameters.setName("FactoryURL");
		factoryConstructorParameters.setPrimitive(false);
		factoryConstructorParameters.setType("java.lang.String");
		factoryConstructorParameters
				.setValue("tcp://ukirp305.ukroi.tesco.org:21122");

		EventConfigParameter eventConfigParams[] = { factoryConstructorParameters };
		eventConfig.setFactoryConstructorParameters(eventConfigParams);
		EventConfigParameter factoryClassCfgParam = new EventConfigParameter();
		EventConfigParameter[] factClassProperties = new EventConfigParameter[4];
		factoryClassCfgParam.setName("UserName");
		factoryClassCfgParam.setType("java.lang.String");
		factoryClassCfgParam.setValue("price");
		factClassProperties[0] = factoryClassCfgParam;

		factoryClassCfgParam = new EventConfigParameter();
		factoryClassCfgParam.setName("UserPassword");
		factoryClassCfgParam.setType("java.lang.String");
		factoryClassCfgParam.setValue("prcsvc");
		factClassProperties[1] = factoryClassCfgParam;

		factoryClassCfgParam = new EventConfigParameter();
		factoryClassCfgParam.setName("ReconnAttemptCount");
		factoryClassCfgParam.setType("java.lang.Integer");
		factoryClassCfgParam.setValue("1");
		factoryClassCfgParam.setPrimitive(true);
		factClassProperties[2] = factoryClassCfgParam;

		factoryClassCfgParam = new EventConfigParameter();
		factoryClassCfgParam.setName("ConnAttemptCount");
		factoryClassCfgParam.setType("java.lang.Integer");
		factoryClassCfgParam.setValue("10");
		factoryClassCfgParam.setPrimitive(true);
		factClassProperties[3] = factoryClassCfgParam;

		eventConfig.setFactoryProperties(factClassProperties);

		// Setting up and calling the Event publisher
		factory.configureEventTemplate(eventConfigArray);
		EventTemplate template = factory.getPublishTemplate("REALTIME");
		data.setEventType("REGPRICECHANGE");
		data.setHeaderData(payloadMap);
		data.setPayloadData(headerMap);
		data.addHeaderEntry("Product", "123");
		try {
			System.out.println(template.publishEvent(data));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.print("1------------------------" + e.getMessage());
		}
	}

}
