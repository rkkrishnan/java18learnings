package com.tesco.services.event.core.impl;

public class MockConnectionFactory {
	public MockConnectionFactory(int mockInt) {
	}
}
