package com.tesco.services.event.core.impl;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tesco.services.event.core.EventConfiguration;

public class BaseEventFactory {

	private static final Logger LOGGER = (Logger) LoggerFactory
			.getLogger(BaseEventFactory.class);

	public static final String SETTER_METHOD_PREFIX = "set";

	protected static Object buildJMSProviderFactory(EventConfiguration config) {
		Object instance = null;
		try {
			Class<?> jmsFactoryClass = Class.forName(config
					.getJmsFactoryClassName());

			Constructor<?> jmsFactoryConstructor = null;

			if (config.getFactoryConstructorParameters() != null
					&& config.getFactoryConstructorParameters().length > 0) {
				Class<?> parameterTypes[] = new Class[config
						.getFactoryConstructorParameters().length];
				Object parameterValues[] = new Object[config
						.getFactoryConstructorParameters().length];

				for (int classindx = 0; classindx < config
						.getFactoryConstructorParameters().length; classindx++) {

					if (config.getFactoryConstructorParameters()[classindx]
							.isPrimitive()) {
						parameterTypes[classindx] = getType(Class
								.forName(config
										.getFactoryConstructorParameters()[classindx]
										.getType()));
						parameterValues[classindx] = getPrimitiveValue(
								getType(Class.forName(config
										.getFactoryConstructorParameters()[classindx]
										.getType())),
								config.getFactoryConstructorParameters()[classindx]
										.getValue());
					} else {
						parameterTypes[classindx] = Class.forName(config
								.getFactoryConstructorParameters()[classindx]
								.getType());
						parameterValues[classindx] = config
								.getFactoryConstructorParameters()[classindx]
								.getValue();
					}

				}

				jmsFactoryConstructor = jmsFactoryClass
						.getConstructor(parameterTypes);

				instance = jmsFactoryConstructor.newInstance(parameterValues);
			} else {
				jmsFactoryConstructor = jmsFactoryClass.getConstructor();
				instance = jmsFactoryConstructor.newInstance();
			}

			if (config.getFactoryProperties() != null
					&& config.getFactoryProperties().length > 0) {
				Class<?> propertyType = null;
				Object propertyValue = null;
				String propertyName = null;

				for (int classindx = 0; classindx < config
						.getFactoryProperties().length; classindx++) {

					if (config.getFactoryProperties()[classindx].isPrimitive()) {
						propertyType = getType(Class.forName(config
								.getFactoryProperties()[classindx].getType()));
						propertyValue = getPrimitiveValue(
								getType(Class.forName(config
										.getFactoryProperties()[classindx]
										.getType())),
								config.getFactoryProperties()[classindx]
										.getValue());
					} else {
						propertyType = Class.forName(config
								.getFactoryProperties()[classindx].getType());
						propertyValue = config.getFactoryProperties()[classindx]
								.getValue();
					}

					propertyName = config.getFactoryProperties()[classindx]
							.getName();
					Method propertySetterMethod = jmsFactoryClass.getMethod(
							SETTER_METHOD_PREFIX + propertyName,
							new Class[] { propertyType });
					propertySetterMethod.invoke(instance,
							new Object[] { propertyValue });

				}

			}

		} catch (Exception e) {
			LOGGER.error("Error in building JMS provider factory {} ", e);
		}
		return instance;
	}

	private static Class getType(Class clazz) {
		Class classType = null;
		if (Integer.class.equals(clazz)) {
			classType = Integer.TYPE;
		} else if (Long.class.equals(clazz)) {
			classType = Long.TYPE;
		} else if (Character.class.equals(clazz)) {
			classType = Character.TYPE;
		} else if (Short.class.equals(clazz)) {
			classType = Short.TYPE;
		} else if (Boolean.class.equals(clazz)) {
			classType = Boolean.TYPE;
		} else if (Byte.class.equals(clazz)) {
			classType = Byte.TYPE;
		} else if (Float.class.equals(clazz)) {
			classType = Float.TYPE;
		} else if (Double.class.equals(clazz)) {
			classType = Double.TYPE;
		}
		return classType;
	}

	private static Object getPrimitiveValue(Class<?> primitiveType,
			String valueToCast) {
		Object value = null;

		if (int.class.equals(primitiveType)) {
			value = Integer.parseInt(valueToCast);
		} else if (long.class.equals(primitiveType)) {
			value = Long.parseLong(valueToCast);
		} else if (char.class.equals(primitiveType)) {
			value = primitiveType;
		} else if (short.class.equals(primitiveType)) {
			value = Short.parseShort(valueToCast);
		} else if (boolean.class.equals(primitiveType)) {
			value = Boolean.parseBoolean(valueToCast);
		} else if (byte.class.equals(primitiveType)) {
			value = Byte.parseByte(valueToCast);
		} else if (double.class.equals(primitiveType)) {
			value = Double.parseDouble(valueToCast);
		} else if (float.class.equals(primitiveType)) {
			value = Float.parseFloat(valueToCast);
		}
		return value;
	}
}
