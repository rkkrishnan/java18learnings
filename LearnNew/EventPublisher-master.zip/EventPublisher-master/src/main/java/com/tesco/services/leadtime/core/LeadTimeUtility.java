package com.tesco.services.leadtime.core;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.Days;
import org.joda.time.LocalDate;

public class LeadTimeUtility {

	/**
	 * This method is used to calculate LeadTime days
	 * 
	 * @param effectiveDate
	 * @param publishingDate
	 * @return
	 */
	public static int getLeadTime(DateTime effectiveDate, DateTime publishingDate) {

		DateTimeZone effectiveDateZone = effectiveDate.getZone();
		DateTimeZone publishingDateZone = publishingDate.getZone();
		if (!effectiveDateZone.equals(publishingDateZone)) {
			publishingDate = new DateTime(publishingDate, effectiveDateZone);
		}
		LocalDate publishingDateWithoutTime = publishingDate.toLocalDate();
		LocalDate effectiveDateWithoutTime = effectiveDate.toLocalDate();

		Days led = Days.daysBetween(publishingDateWithoutTime, effectiveDateWithoutTime);
		return led.getDays();
	}

}
