package com.tesco.services.event.exception;


public class EventConfigurationException extends Exception {

	private static final long serialVersionUID = 1L;

	/**
	 * @param tmessage
	 *            - business related exception message
	 */
	public EventConfigurationException(String tmessage) {
		super(tmessage);
	}

}
