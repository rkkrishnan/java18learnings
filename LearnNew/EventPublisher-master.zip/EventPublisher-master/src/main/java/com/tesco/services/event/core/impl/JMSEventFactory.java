package com.tesco.services.event.core.impl;

import java.util.HashMap;
import java.util.Map;

import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.Session;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tesco.services.event.core.EventConfiguration;
import com.tesco.services.event.core.EventFactory;
import com.tesco.services.event.core.EventTemplate;
import com.tesco.services.event.exception.EventConfigurationException;

/**
 * This class will be the factory class for all the events
 * 
 * @author jb38
 *
 */
public class JMSEventFactory extends BaseEventFactory implements EventFactory {

	private static final Logger LOGGER = (Logger) LoggerFactory
			.getLogger(JMSEventFactory.class);

	/**
	 * Map to hold all the publish template configured in the application
	 */
	Map<String, EventTemplate> templateMap = new HashMap<String, EventTemplate>();
	/**
	 * Map to hold all the event configuration details
	 */
	Map<String, EventConfiguration> eventConfigMap = new HashMap<String, EventConfiguration>();

	/**
	 * JMS Connection factory for publishing events
	 */
	ConnectionFactory jmsProviderFactory;

	/**
	 * @Injecting JMS connection factory for unit testing
	 */
	public JMSEventFactory(ConnectionFactory jmsProviderFactory) {
		this.jmsProviderFactory = jmsProviderFactory;
	}

	public JMSEventFactory() {
	}

	/**
	 * This method is used to configure all the templates mentioned in the
	 * configuration file
	 * 
	 * @param eventConfig
	 *            - array of event configurations
	 * 
	 */
	@Override
	public void configureEventTemplate(EventConfiguration[] eventConfig)
			throws EventConfigurationException {
		try {
			for (EventConfiguration eventConfiguration : eventConfig) {
				if (eventConfiguration != null) {

					if (jmsProviderFactory == null) {
						jmsProviderFactory = (ConnectionFactory) buildJMSProviderFactory(eventConfiguration);
					}

					Session topicSession = (Session) jmsProviderFactory
							.createConnection().createSession(false,
									Session.AUTO_ACKNOWLEDGE);

					templateMap.put(eventConfiguration.getConfigId(),
							new JMSEventTemplate(topicSession,
									eventConfiguration));

				} else {
					LOGGER.error("No event configuration available.");
					throw new EventConfigurationException(
							"No event configuration available.");
				}
			}
		} catch (JMSException e) {
			throw new EventConfigurationException(
					"Unable to create topic connection" + e);
		}

	}

	/**
	 * This method will return the template for the given template id
	 * 
	 * @param templateID
	 *            - The id of the template for the current configuration
	 * @return EventTeamplate - current eventTemplate
	 */
	@Override
	public EventTemplate getPublishTemplate(String templateID)
			throws EventConfigurationException {
		return templateMap.get(templateID);

	}

}