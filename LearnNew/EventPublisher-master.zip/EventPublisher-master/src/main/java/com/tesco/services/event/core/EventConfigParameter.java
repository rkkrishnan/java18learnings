package com.tesco.services.event.core;

public class EventConfigParameter {

	private String type;
	private String name;
	private String value;
	private boolean primitive;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public boolean isPrimitive() {
		return primitive;
	}

	public void setPrimitive(boolean primitive) {
		this.primitive = primitive;
	}

	@Override
	public String toString() {
		return "EventConfigParameter [type=" + type + ", name=" + name + ", value=" + value + ", primitive=" + primitive
				+ "]";
	}

}
