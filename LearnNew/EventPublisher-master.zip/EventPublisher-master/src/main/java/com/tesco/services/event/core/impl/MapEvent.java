package com.tesco.services.event.core.impl;

import java.util.Map;

public class MapEvent extends EventData<Map<String, Object>>{
	
	private static final long serialVersionUID = 5218477418589314469L;

	public void addPayloadEntry(String key, String value) {
		getPayloadData().put(key, value);
	}
	
	public void removePayloadEntry(String key) {
		getPayloadData().remove(key);
	}
}
