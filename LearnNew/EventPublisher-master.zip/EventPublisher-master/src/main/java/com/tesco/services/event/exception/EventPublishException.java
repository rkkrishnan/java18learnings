package com.tesco.services.event.exception;

import javax.jms.JMSException;

public class EventPublishException extends Exception {
	private static final long serialVersionUID = 1L;

	/**
	 * @param e
	 *            - exception
	 * @param tmessage
	 *            - business related exception message
	 */
	public EventPublishException(Exception e, String tmessage) {
		super(tmessage, e);
	}

}
