package com.tesco.services.event.core;

import com.tesco.services.event.exception.EventPublishException;

/**
 * EventTemplate for publishing all the events
 * 
 * @author jb38
 *
 */
public interface EventTemplate {
	/**
	 * This method will prepare the body and the header part of the message to
	 * be send to the topic
	 * 
	 * @param event
	 *            - Event data
	 * @return String - correlation id of the message sent
	 */
	<T> String publishEvent(Event<T> event) throws EventPublishException;
}
