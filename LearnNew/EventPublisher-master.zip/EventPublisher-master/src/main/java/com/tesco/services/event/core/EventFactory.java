package com.tesco.services.event.core;

import com.tesco.services.event.exception.EventConfigurationException;

/**
 * Factory for all the events
 * 
 * @author jb38
 *
 */
public interface EventFactory {

	/**
	 * This method is used to configure all the templates mentioned in the
	 * configuraiton file
	 * 
	 * @param eventConfig
	 *            - array of event configurations
	 * 
	 */
	void configureEventTemplate(EventConfiguration[] eventConfig) throws EventConfigurationException;

	/**
	 * This method will return the teamplate for the given template id
	 * 
	 * @param templateID
	 *            - The id of the template for the current configuration
	 * @return EventTeamplate - current eventTemplate
	 */
	EventTemplate getPublishTemplate(String templateID) throws EventConfigurationException;

}
