package com.tesco.services.event.core;

import java.util.Map;

public interface Event<T> {

	/** get the header data map **/
	public Map<String, String> getHeaderData();

	/** get the payload data map **/
	public T getPayloadData();

}
