package com.tesco.services.event.core;

import java.util.Arrays;

public class EventConfiguration {
	private String configId;
	private EventConfigParameter[] factoryConstructorParameters;
	private String jmsFactoryClassName;
	private String topicName;
	private int topicRetryCount;
	private EventConfigParameter[] factoryProperties;
	
	public String getConfigId() {
		return configId;
	}

	public EventConfigParameter[] getFactoryConstructorParameters() {
		return factoryConstructorParameters;
	}

	public String getJmsFactoryClassName() {
		return jmsFactoryClassName;
	}

	public String getTopicName() {
		return topicName;
	}

	public int getTopicRetryCount() {
		return topicRetryCount;
	}

	public EventConfigParameter[] getFactoryProperties() {
		return factoryProperties;
	}
	public void setConfigId(String configId) {
		this.configId = configId;
	}

	public void setFactoryConstructorParameters(EventConfigParameter[] factoryConstructorParameters) {
		this.factoryConstructorParameters = new EventConfigParameter[factoryConstructorParameters.length];
		for (int i = 0; i < factoryConstructorParameters.length; i++) {
			this.factoryConstructorParameters[i] = factoryConstructorParameters[i];
		}
	}

	public void setJmsFactoryClassName(String jmsFactoryClassName) {
		this.jmsFactoryClassName = jmsFactoryClassName;
	}

	public void setTopicName(String topicName) {
		this.topicName = topicName;
	}

	public void setTopicRetryCount(int topicRetryCount) {
		this.topicRetryCount = topicRetryCount;
	}

	public void setFactoryProperties(EventConfigParameter[] factoryProperties) {
		this.factoryProperties = new EventConfigParameter[factoryProperties.length];
		for (int i = 0; i < factoryProperties.length; i++) {
			this.factoryProperties[i] = factoryProperties[i];
		}
	}
	
	@Override
	public String toString() {
		return "EventConfiguration [configId=" + configId + ", factoryConstructorParameters="
				+ Arrays.toString(factoryConstructorParameters) + ", factoryProperties="
				+ Arrays.toString(factoryProperties) + ", jmsFactoryClassName=" + jmsFactoryClassName + ", topicName="
				+ topicName + ", topicRetryCount=" + topicRetryCount + "]";
	}

}