package com.tesco.services.event.core.impl;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import com.tesco.services.event.core.Event;

/**
 * This class will hold header and payload data for all the events
 * 
 * @author jb38
 *
 */
public class EventData<T> implements Event<T>, Serializable {

	private static final long serialVersionUID = 1L;

	/** Header data for the jms message **/
	private Map<String, String> headerData = new HashMap<String, String>();

	/** Payload data for the jms message **/
	private T payloadData;

	/** The type of the event REALTIME/DEFFERED **/
	private String eventType;

	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	public void setHeaderData(Map<String, String> headerData) {
		this.headerData = headerData;
	}

	public void addHeaderEntry(String key, String value) {
		headerData.put(key, key);
	}

	public void removeHeaderEntry(String key) {
		headerData.remove(key);
	}

	public Map<String, String> getHeaderData() {
		return headerData;
	}

	public T getPayloadData() {
		return payloadData;
	}

	public void setPayloadData(T payloadData) {
		this.payloadData = payloadData;
	}

	@Override
	public String toString() {
		return "EventData [headerData=" + headerData + ", payloadData=" + payloadData + ", eventType=" + eventType
				+ "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((eventType == null) ? 0 : eventType.hashCode());
		result = prime * result + ((headerData == null) ? 0 : headerData.hashCode());
		result = prime * result + ((payloadData == null) ? 0 : payloadData.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EventData other = (EventData) obj;
		if (eventType == null) {
			if (other.eventType != null)
				return false;
		} else if (!eventType.equals(other.eventType))
			return false;
		if (headerData == null) {
			if (other.headerData != null)
				return false;
		} else if (!headerData.equals(other.headerData))
			return false;
		if (payloadData == null) {
			if (other.payloadData != null)
				return false;
		} else if (!payloadData.equals(other.payloadData))
			return false;
		return true;
	}

}