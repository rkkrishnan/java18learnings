package com.tesco.services.event.util;

public interface CommonConstants {
	String EVENT_FACTORY_NAME = "mqfactory";
	String EVENT_URI_TOPIC = ":topic:";
}
