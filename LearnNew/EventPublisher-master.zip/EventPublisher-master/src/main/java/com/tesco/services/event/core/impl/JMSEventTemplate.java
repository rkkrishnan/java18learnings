package com.tesco.services.event.core.impl;

import java.util.Map;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageProducer;
import javax.jms.Session;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.module.afterburner.AfterburnerModule;
import com.tesco.services.event.core.Event;
import com.tesco.services.event.core.EventConfiguration;
import com.tesco.services.event.core.EventTemplate;
import com.tesco.services.event.exception.EventConfigurationException;
import com.tesco.services.event.exception.EventPublishException;

public class JMSEventTemplate implements EventTemplate {

	static final Logger LOGGER = (Logger) LoggerFactory
			.getLogger(JMSEventTemplate.class);
	/** Jaxson object mapper **/
	private static ObjectMapper objMapper = new ObjectMapper()
			.registerModule(new AfterburnerModule());

	private Session topicSession;

	private MessageProducer topicPublisher;

	public JMSEventTemplate(Session topicSession,
			EventConfiguration configuration)
			throws EventConfigurationException {
		this.topicSession = topicSession;
		try {
			this.topicPublisher = topicSession.createProducer(topicSession
					.createTopic(configuration.getTopicName()));
		} catch (JMSException e) {
			throw new EventConfigurationException("" + e);
		}
	}

	@Override
	public <T> String publishEvent(Event<T> event) throws EventPublishException {
		String payloadString = null;
		Map<String, String> headerMap = null;
		try {
			headerMap = event.getHeaderData();
			T payloadMap = event.getPayloadData();
			payloadString = objMapper.writeValueAsString(payloadMap);
		} catch (Exception e) {
			LOGGER.error("Exception while parsing the json data for the event",
					e);
			throw new EventPublishException(e,
					"Exception while parsing the json data for the event");
		}
		return publishToTopic(payloadString, headerMap);
	}

	private String publishToTopic(final String payloadString,
			final Map<String, String> headerMap) throws EventPublishException {
		LOGGER.info("Message Publishing Started");
		Message eventMsg = null;
		String eventCorrelationId = null;
		try {
			eventMsg = topicSession.createTextMessage(payloadString);

			for (Map.Entry<String, String> header : headerMap.entrySet()) {
				eventMsg.setStringProperty(header.getKey(), header.getValue());
			}
			topicPublisher.send(eventMsg);

			eventCorrelationId = "" + eventMsg.getJMSTimestamp();
		} catch (JMSException e) {
			throw new EventPublishException(e,
					"Unable to publish to event topic");
		}
		return eventCorrelationId;
	}
}
