package com.tesco.services.event.core.impl;

import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Processor;
import org.apache.camel.ProducerTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tesco.services.event.core.Event;
import com.tesco.services.event.core.EventConfiguration;
import com.tesco.services.event.core.EventTemplate;
import com.tesco.services.event.exception.EventPublishException;
import com.tesco.services.event.util.CommonConstants;

/**
 * This class will publish all the events to the configured topic
 * 
 * @author jb38
 *
 */
public class CamelEventTemplate implements EventTemplate {

	static final Logger LOGGER = (Logger) LoggerFactory.getLogger(CamelEventTemplate.class);
	/** Camel producer template **/
	private ProducerTemplate template = null;
	/** Jaxson object mapper **/
	private ObjectMapper objMapper = null;
	/** Configuration **/
	private EventConfiguration configuration = null;

	/**
	 * @param templateParam
	 *            - Template for the current configuration
	 */
	public CamelEventTemplate(ProducerTemplate templateParam, EventConfiguration configuration) {
		this.template = templateParam;
		this.configuration = configuration;
		setObjMapper(new ObjectMapper());
	}

	/**
	 * This method will prepare the body and the header part of the message to
	 * be send to the topic
	 * 
	 * @param event
	 *            - Event data
	 * @return String - correlation id of the message sent
	 */
	@Override
	public <T> String publishEvent(Event<T> event) throws EventPublishException {
		String payloadString = null;
		Map<String, String> headerMap = null;
		try {
			headerMap = event.getHeaderData();
			T payloadMap = event.getPayloadData();
			payloadString = getObjMapper().writeValueAsString(payloadMap);
		} catch (Exception e) {
			LOGGER.error("Exception while parsing the json data for the event", e);
			throw new EventPublishException(e, "Exception while parsing the json data for the event");
		}
		return publishToTopic(payloadString, headerMap);
	}

	/**
	 * This method will send message to the topic
	 * 
	 * @param payloadString
	 *            - The body part of the message to be send
	 * @param headerMap
	 *            - Header data for the message to be send
	 * @return correlation of the message sent
	 */
	public String publishToTopic(final String payloadString, final Map<String, String> headerMap)
			throws EventPublishException {
		LOGGER.info("Message Publishing Started");
		Exchange result = template.send(
				CommonConstants.EVENT_FACTORY_NAME + CommonConstants.EVENT_URI_TOPIC + configuration.getTopicName(),
				new Processor() {
					public void process(Exchange exchange) {
						Message in = exchange.getIn();
						if (headerMap != null) {
							for (Map.Entry<String, String> header : headerMap.entrySet()) {
								in.setHeader(header.getKey(), header.getValue());
							}
						}
						in.setBody(payloadString);
					}
				});
		String msgId = result.getOut().getMessageId();
		if (result.getException() != null) {
			throw new EventPublishException(result.getException(), result.getException().getMessage());
		}
		LOGGER.info("Message Published to Topic: " + configuration.getTopicName() + " With ID : " + msgId);
		return msgId;
	}

	public ObjectMapper getObjMapper() {
		return objMapper;
	}

	public void setObjMapper(ObjectMapper objMapper) {
		this.objMapper = objMapper;
	}

}
