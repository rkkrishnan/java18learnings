package com.tesco.services.event.core.impl;

import static com.google.common.base.Strings.isNullOrEmpty;

import java.util.HashMap;
import java.util.Map;

import javax.jms.ConnectionFactory;

import org.apache.camel.CamelContext;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.component.jms.JmsComponent;
import org.apache.camel.impl.DefaultCamelContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tesco.services.event.core.EventConfiguration;
import com.tesco.services.event.core.EventFactory;
import com.tesco.services.event.core.EventTemplate;
import com.tesco.services.event.exception.EventConfigurationException;
import com.tesco.services.event.util.CommonConstants;

/**
 * This class will be the factory class for all the events
 * 
 * @author jb38
 *
 */
public class CamelEventFactory extends BaseEventFactory implements EventFactory {

	private static final Logger LOGGER = (Logger) LoggerFactory
			.getLogger(CamelEventFactory.class);

	/**
	 * Map to hold all the publish template configured in the application
	 */
	Map<String, ProducerTemplate> eventTemplateMap = new HashMap<String, ProducerTemplate>();
	/**
	 * Map to hold all the event configuration details
	 */
	Map<String, EventConfiguration> eventConfigMap = new HashMap<String, EventConfiguration>();

	/**
	 * This method is used to configure all the templates mentioned in the
	 * configuration file
	 * 
	 * @param eventConfig
	 *            - array of event configurations
	 * 
	 */
	@Override
	public void configureEventTemplate(EventConfiguration[] eventConfig)
			throws EventConfigurationException {
		for (EventConfiguration eventConfiguration : eventConfig) {
			if (eventConfiguration != null) {
				CamelContext camelContext = new DefaultCamelContext();
				camelContext
						.addComponent(
								CommonConstants.EVENT_FACTORY_NAME,
								JmsComponent
										.jmsComponentAutoAcknowledge((ConnectionFactory) buildJMSProviderFactory(eventConfiguration)));
				ProducerTemplate template = camelContext
						.createProducerTemplate();
				template.setDefaultEndpointUri(CommonConstants.EVENT_FACTORY_NAME
						+ CommonConstants.EVENT_URI_TOPIC
						+ eventConfiguration.getTopicName());
				eventTemplateMap
						.put(eventConfiguration.getConfigId(), template);
				eventConfigMap.put(eventConfiguration.getConfigId(),
						eventConfiguration);
			} else {
				LOGGER.error("No event configuration available.");
				throw new EventConfigurationException(
						"No event configuration available.");
			}
		}

	}

	/**
	 * This method will return the teamplate for the given template id
	 * 
	 * @param templateID
	 *            - The id of the template for the current configuration
	 * @return EventTeamplate - current eventTemplate
	 */
	@Override
	public EventTemplate getPublishTemplate(String templateID)
			throws EventConfigurationException {
		if (!isNullOrEmpty(templateID)) {
			EventTemplate eventTemplate = new CamelEventTemplate(
					eventTemplateMap.get(templateID),
					eventConfigMap.get(templateID));
			return eventTemplate;
		} else {
			LOGGER.error("TemplateID not available in the configuration.");
			throw new EventConfigurationException(
					"TemplateID not available in the configuration.");
		}
	}

}