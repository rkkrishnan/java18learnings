# PriceServiceEntity
Contains Java POJOs representing the couchbase document entity structure
