package com.tesco.services.core.entity;


import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;
import java.util.List;

import static com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility.ANY;
import static com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility.NONE;

@JsonAutoDetect(fieldVisibility = ANY, getterVisibility = NONE, setterVisibility = NONE)
public class ZoneEntity implements Serializable{


    @JsonProperty
    private String zoneGroupId;

    @JsonProperty
    private String zoneGroupName;

	@JsonProperty
	private String zoneGroupType;

    @JsonProperty
    private String zoneId;

    @JsonProperty
    private String zoneName;

    @JsonProperty
    private String baseInd;

    @JsonProperty
    private String currencyCode;

    @JsonProperty
    private String tslCountryCode;

    @JsonProperty
    private String offerPrefix;

    @JsonProperty
    private String createdDate;

    @JsonProperty
    private String createdById;

    @JsonProperty
    private String lastUpdateDate;

	@JsonProperty
	private List<String> storeIds;

    public String getZoneGroupId() {
        return zoneGroupId;
    }

    public void setZoneGroupId(String zoneGroupId) {
        this.zoneGroupId = zoneGroupId;
    }

    public String getZoneGroupName() {
        return zoneGroupName;
    }

    public void setZoneGroupName(String zoneGroupName) {
        this.zoneGroupName = zoneGroupName;
    }

    public String getZoneId() {
        return zoneId;
    }

    public void setZoneId(String zoneId) {
        this.zoneId = zoneId;
    }

    public String getZoneName() {
        return zoneName;
    }

    public void setZoneName(String zoneName) {
        this.zoneName = zoneName;
    }

    public String getBaseInd() {
        return baseInd;
    }

    public void setBaseInd(String baseInd) {
        this.baseInd = baseInd;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public String getTslCountryCode() {
        return tslCountryCode;
    }

    public void setTslCountryCode(String tslCountryCode) {
        this.tslCountryCode = tslCountryCode;
    }

    public String getOfferPrefix() {
        return offerPrefix;
    }

    public void setOfferPrefix(String offerPrefix) {
        this.offerPrefix = offerPrefix;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedById() {
        return createdById;
    }

    public void setCreatedById(String createdById) {
        this.createdById = createdById;
    }

    public String getLastUpdateDate() {
        return lastUpdateDate;
    }

    public void setLastUpdateDate(String lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

	public String getZoneGroupType() {
		return zoneGroupType;
	}

	public void setZoneGroupType(String zoneGroupType) {
		this.zoneGroupType = zoneGroupType;
	}


    public ZoneEntity(){
    }

    public ZoneEntity(String zoneId){
        this.zoneId = zoneId;
    }


    @Override
    public String toString() {
        return "ZoneEntity{" +
                "zoneGroupId='" + zoneGroupId + '\'' +
                ", zoneGroupName='" + zoneGroupName + '\'' +
                ", zoneGroupType='" + zoneGroupType + '\'' +
                ", zoneId='" + zoneId + '\'' +
                ", zoneName='" + zoneName + '\'' +
                ", baseInd='" + baseInd + '\'' +
                ", currencyCode='" + currencyCode + '\'' +
                ", tslCountryCode='" + tslCountryCode + '\'' +
                ", offerPrefix='" + offerPrefix + '\'' +
                ", createdDate='" + createdDate + '\'' +
                ", createdById='" + createdById + '\'' +
                ", lastUpdateDate='" + lastUpdateDate + '\'' +
				", storeIds='" + storeIds + '\'' +
                '}';
    }

	public List<String> getStoreIds() {
		return storeIds;
	}

	public void setStoreIds(List<String> storeIds) {
		this.storeIds = storeIds;
	}
}
