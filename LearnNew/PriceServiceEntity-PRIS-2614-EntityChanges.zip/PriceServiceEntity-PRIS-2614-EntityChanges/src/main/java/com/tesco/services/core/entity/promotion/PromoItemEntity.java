package com.tesco.services.core.entity.promotion;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by iv16 on 5/5/2015.
 */
public class PromoItemEntity {

    @JsonProperty("@type")
    public String type;

    @JsonProperty("itemType")
    public String itemType;

    @JsonProperty("itemRef")
    public String itemRef;

    @JsonProperty("wasPrice")
    public String wasPrice;

    @JsonProperty("wasWasPrice")
    public String wasWasPrice;

    @JsonProperty("posLabelReqInd")
    public String posLabelReqInd;

    @JsonProperty("effectiveDate")
    public String effectiveDate;

    @JsonProperty("endDate")
    public String endDate;

    @JsonProperty("rpmPromoCompDetailId")
    public String rpmPromoCompDetailId;

    public String getEffectiveDate() {
        return effectiveDate;
    }

    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getItemRef() {
        return itemRef;
    }

    public void setItemRef(String itemRef) {
        this.itemRef = itemRef;
    }

    public String getItemType() {
        return itemType;
    }

    public void setItemType(String itemType) {
        this.itemType = itemType;
    }

    public String getPosLabelReqInd() {
        return posLabelReqInd;
    }

    public void setPosLabelReqInd(String posLabelReqInd) {
        this.posLabelReqInd = posLabelReqInd;
    }

    public String getRpmPromoCompDetailId() {
        return rpmPromoCompDetailId;
    }

    public void setRpmPromoCompDetailId(String rpmPromoCompDetailId) {
        this.rpmPromoCompDetailId = rpmPromoCompDetailId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getWasPrice() {
        return wasPrice;
    }

    public void setWasPrice(String wasPrice) {
        this.wasPrice = wasPrice;
    }

    public String getWasWasPrice() {
        return wasWasPrice;
    }

    public void setWasWasPrice(String wasWasPrice) {
        this.wasWasPrice = wasWasPrice;
    }

    @Override
    public String toString() {
        return "PromoItemEntity{" +
                "type='" + type + '\'' +
                ", itemType='" + itemType + '\'' +
                ", itemRef='" + itemRef + '\'' +
                ", wasPrice='" + wasPrice + '\'' +
                ", wasWasPrice='" + wasWasPrice + '\'' +
                ", posLabelReqInd='" + posLabelReqInd + '\'' +
                ", effectiveDate='" + effectiveDate + '\'' +
                ", endDate='" + endDate + '\'' +
                ", rpmPromoCompDetailId='" + rpmPromoCompDetailId + '\'' +
                '}';
    }
}
