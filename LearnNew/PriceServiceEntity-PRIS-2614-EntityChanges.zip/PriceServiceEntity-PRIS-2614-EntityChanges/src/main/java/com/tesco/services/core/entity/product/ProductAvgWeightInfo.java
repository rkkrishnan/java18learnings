package com.tesco.services.core.entity.product;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by yp21 on 24/09/2015.
 */
public class ProductAvgWeightInfo {

	@JsonProperty
	private Map<String, ProductAvgWeightDetailInfo> avgWeight = new HashMap<>();
	@JsonProperty
	private String lastUpdateDate;

	public Map<String, ProductAvgWeightDetailInfo> getAvgWeight() {
		return avgWeight;
	}

	public void setAvgWeight(
			Map<String, ProductAvgWeightDetailInfo> avgWeight) {
		this.avgWeight = avgWeight;
	}

	public String getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(String lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}
}
