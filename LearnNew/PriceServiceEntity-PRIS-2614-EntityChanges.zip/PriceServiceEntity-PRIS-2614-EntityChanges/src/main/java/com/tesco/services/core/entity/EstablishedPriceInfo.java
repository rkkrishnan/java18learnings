package com.tesco.services.core.entity;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;

/**
 * Created by QP65 on 12/14/2015.
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
public class EstablishedPriceInfo implements Serializable {

	@JsonProperty("phase")
	private String phase;

	@JsonProperty("prevPrice")
	private String prevPrice;

	@JsonProperty("startDate")
	private String startDate;

	@JsonProperty("endDate")
	private String endDate;

	public String getPhase() {
		return phase;
	}

	public void setPhase(String phase) {
		this.phase = phase;
	}

	public String getPrevPrice() {
		return prevPrice;
	}

	public void setPrevPrice(String prevPrice) {
		this.prevPrice = prevPrice;
	}
	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}

		EstablishedPriceInfo that = (EstablishedPriceInfo) o;

		if (endDate != null ?
				!endDate.equals(that.endDate) :
				that.endDate != null) {
			return false;
		}
		if (prevPrice != null ?
				!prevPrice.equals(that.prevPrice) :
				that.prevPrice != null) {
			return false;
		}
		if (phase != null ? !phase.equals(that.phase) : that.phase != null) {
			return false;
		}
		if (startDate != null ?
				!startDate.equals(that.startDate) :
				that.startDate != null) {
			return false;
		}

		return true;
	}

	@Override
	public int hashCode() {
		int result = phase != null ? phase.hashCode() : 0;
		result = 31 * result + (prevPrice != null ? prevPrice.hashCode() : 0);
		result = 31 * result + (startDate != null ? startDate.hashCode() : 0);
		result = 31 * result + (endDate != null ? endDate.hashCode() : 0);
		return result;
	}

	@Override public String toString() {
		return "EstablishedPriceInfo{" +
				"phase='" + phase + '\'' +
				", prevPrice='" + prevPrice + '\'' +
				", startDate='" + startDate + '\'' +
				", endDate='" + endDate + '\'' +
				'}';
	}

}
