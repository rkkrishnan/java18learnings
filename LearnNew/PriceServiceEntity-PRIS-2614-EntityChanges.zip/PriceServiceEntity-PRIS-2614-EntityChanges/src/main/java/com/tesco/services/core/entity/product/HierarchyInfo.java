package com.tesco.services.core.entity.product;

public class HierarchyInfo {

	private String sectionCode;
	private String classCode;
	private String subclassCode;
	private String errorResponse = null;

	public String getSectionCode() {
		return sectionCode;
	}

	public void setSectionCode(String sectionCode) {
		this.sectionCode = sectionCode;
	}

	public String getClassCode() {
		return classCode;
	}

	public void setClassCode(String classCode) {
		this.classCode = classCode;
	}

	public String getSubclassCode() {
		return subclassCode;
	}

	public void setSubclassCode(String subclassCode) {
		this.subclassCode = subclassCode;
	}

	public String getErrorResponse() {
		return errorResponse;
	}

	public void setErrorResponse(String errorResponse) {
		this.errorResponse = errorResponse;
	}


	@Override public String toString() {
		return "HierarchyInfo{" +
				"sectionCode='" + sectionCode + '\'' +
				", classCode='" + classCode + '\'' +
				", subclassCode='" + subclassCode + '\'' +
				'}';
	}

	public boolean isHierarchyInfoEmpty(HierarchyInfo hierarchyInfo) {

		return (hierarchyInfo.getSectionCode() == null
				&& hierarchyInfo.getClassCode() == null
				&& hierarchyInfo.getSubclassCode() == null) ? true : false;
	}

}