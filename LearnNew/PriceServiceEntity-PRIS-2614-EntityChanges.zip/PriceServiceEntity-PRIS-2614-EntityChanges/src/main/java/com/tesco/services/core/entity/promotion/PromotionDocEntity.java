package com.tesco.services.core.entity.promotion;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PromotionDocEntity implements Serializable {

	@JsonProperty("@type")
	public String type;

	@JsonProperty("offerRef")
	public String offerRef;

	@JsonProperty("offerType")
	public String offerType;

	@JsonProperty("cfDescription1")
	public String cfDescription1;

	@JsonProperty("cfDescription2")
	public String cfDescription2;

	@JsonProperty("multi_buy_promo_type")
	public String multiBuyPromoType;

	@JsonProperty("locRef")
	public String locRef;

	@JsonProperty("locType")
	public String locType;

	@JsonProperty("state")
	public String state;

	@JsonProperty("name")
	public String name;

	@JsonProperty("externalPromoId")
	public String externalPromoId;

	@JsonProperty("tillRollDescription")
	public String tillRollDescription;

	@JsonProperty("couponTriggeredInd")
	public Boolean couponTriggeredInd;

	@JsonProperty("couponNumber")
	public String couponNumber;

	@JsonProperty("couponDescription")
	public String couponDescription;

	@JsonProperty("createdDate")
	public String createdDate;

	@JsonProperty("createdById")
	public String createdById;

	@JsonProperty("lastUpdateDate")
	public String lastUpdateDate;

	@JsonProperty("lastUpdatedById")
	public String lastUpdatedById;

	@JsonProperty("promoThresholds")
	public List<PromoThresholdEntity> promoThresholdEntities;

	@JsonProperty("promoRewards")
	public List<PromoRewardEntity> promoRewardEntities;

	@JsonProperty("promoItemLists")
	public List<PromoItemListEntity> promoItemListEntities;

	@JsonIgnore
	private String effectiveDate;
	@JsonIgnore
	private String endDate;
	@JsonIgnore
	private String hierarchyId;

	public void addPromoRewardEntities(PromoRewardEntity promoRewardEntities) {
		if (this.promoRewardEntities == null) {
			this.promoRewardEntities = new ArrayList<>();
		}
		this.promoRewardEntities.add(promoRewardEntities);
	}

	public void addPromoThresholdEntity(
			PromoThresholdEntity promoThresholdEntity) {
		if (this.promoThresholdEntities == null) {
			this.promoThresholdEntities = new ArrayList<>();
		}
		this.promoThresholdEntities.add(promoThresholdEntity);
	}

	public String getCfDescription1() {
		return cfDescription1;
	}

	public String getCfDescription2() {
		return cfDescription2;
	}

	public String getCouponDescription() {
		return couponDescription;
	}

	public String getCouponNumber() {
		return couponNumber;
	}

	public Boolean getCouponTriggeredInd() {
		return couponTriggeredInd;
	}

	public String getCreatedById() {
		return createdById;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public String getEffectiveDate() {
		return effectiveDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public String getExternalPromoId() {
		return externalPromoId;
	}

	public String getHierarchyId() {
		return hierarchyId;
	}

	public String getLastUpdateDate() {
		return lastUpdateDate;
	}

	public String getLastUpdatedById() {
		return lastUpdatedById;
	}

	public String getLocRef() {
		return locRef;
	}

	public String getLocType() {
		return locType;
	}

	public String getMultiBuyPromoType() {
		return multiBuyPromoType;
	}

	public String getName() {
		return name;
	}

	public String getOfferRef() {
		return offerRef;
	}

	public String getOfferType() {
		return offerType;
	}

	public List<PromoItemListEntity> getPromoItemListEntities() {
		return promoItemListEntities;
	}

	public List<PromoRewardEntity> getPromoRewardEntities() {
		return promoRewardEntities;
	}

	public List<PromoThresholdEntity> getPromoThresholdEntities() {
		return promoThresholdEntities;
	}

	public String getState() {
		return state;
	}

	public String getTillRollDescription() {
		return tillRollDescription;
	}

	public String getType() {
		return type;
	}

	public void setCfDescription1(String cfDescription1) {
		this.cfDescription1 = cfDescription1;
	}

	public void setCfDescription2(String cfDescription2) {
		this.cfDescription2 = cfDescription2;
	}

	public void setCouponDescription(String couponDescription) {
		this.couponDescription = couponDescription;
	}

	public void setCouponNumber(String couponNumber) {
		this.couponNumber = couponNumber;
	}

	public void setCouponTriggeredInd(Boolean couponTriggeredInd) {
		this.couponTriggeredInd = couponTriggeredInd;
	}

	public void setCreatedById(String createdById) {
		this.createdById = createdById;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public void setExternalPromoId(String externalPromoId) {
		this.externalPromoId = externalPromoId;
	}

	public void setHierarchyId(String hierarchyId) {
		this.hierarchyId = hierarchyId;
	}

	public void setLastUpdateDate(String lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	public void setLastUpdatedById(String lastUpdatedById) {
		this.lastUpdatedById = lastUpdatedById;
	}

	public void setLocRef(String locRef) {
		this.locRef = locRef;
	}

	public void setLocType(String locType) {
		this.locType = locType;
	}

	public void setMultiBuyPromoType(String multiBuyPromoType) {
		this.multiBuyPromoType = multiBuyPromoType;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setOfferRef(String offerRef) {
		this.offerRef = offerRef;
	}

	public void setOfferType(String offerType) {
		this.offerType = offerType;
	}

	public void setPromoItemListEntities(
			List<PromoItemListEntity> promoItemListEntities) {
		this.promoItemListEntities = promoItemListEntities;
	}

	public void setPromoRewardEntities(
			List<PromoRewardEntity> promoRewardEntities) {
		this.promoRewardEntities = promoRewardEntities;
	}

	public void setPromoThresholdEntities(
			List<PromoThresholdEntity> promoThresholdEntities) {
		this.promoThresholdEntities = promoThresholdEntities;
	}

	public void setState(String state) {
		this.state = state;
	}

	public void setTillRollDescription(String tillRollDescription) {
		this.tillRollDescription = tillRollDescription;
	}

	public void setType(String type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return "PromotionEntity{" + "type='" + type + '\'' + ", offerRef='"
				+ offerRef + '\'' + ", offerType='" + offerType + '\''
				+ ", multiBuyPromoType='" + multiBuyPromoType + '\''
				+ ", locRef='" + locRef + '\'' + ", locType='" + locType + '\''
				+ ", state='" + state + '\'' + ", name='" + name + '\''
				+ ", externalPromoId='" + externalPromoId + '\''
				+ ", tillRollDescription='" + tillRollDescription + '\''
				+ ", couponTriggeredInd=" + couponTriggeredInd
				+ ", couponNumber='" + couponNumber + '\''
				+ ", couponDescription='" + couponDescription + '\''
				+ ", createdDate='" + createdDate + '\'' + ", createdById='"
				+ createdById + '\'' + ", lastUpdateDate='" + lastUpdateDate
				+ '\'' + ", lastUpdatedById='" + lastUpdatedById + '\''
				+ ", promoThresholdEntities=" + promoThresholdEntities
				+ ", promoRewardEntities=" + promoRewardEntities
				+ ", promoItemListEntities=" + promoItemListEntities + '}';
	}
}
