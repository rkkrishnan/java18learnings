package com.tesco.services.core.entity;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by iv16 on 6/9/2015.
 */
public class PromoReward {
    @JsonProperty("rewardType")
    private String rewardType;
    @JsonProperty("rewardValue")
    private String rewardValue;
    @JsonProperty("rewardQty")
    private String rewardQty;
    @JsonProperty("voucherNumber")
    private String voucherNumber;
    @JsonProperty("voucherDescription")
    private String voucherDescription;

    public String getRewardType() {
        return rewardType;
    }

    public void setRewardType(String rewardType) {
        this.rewardType = rewardType;
    }

    public String getVoucherDescription() {
        return voucherDescription;
    }

    public void setVoucherDescription(String voucherDescription) {
        this.voucherDescription = voucherDescription;
    }

    public String getVoucherNumber() {
        return voucherNumber;
    }

    public void setVoucherNumber(String voucherNumber) {
        this.voucherNumber = voucherNumber;
    }

    public String getRewardQty() {
        return rewardQty;
    }

    public void setRewardQty(String rewardQty) {
        this.rewardQty = rewardQty;
    }

    public String getRewardValue() {
        return rewardValue;
    }

    public void setRewardValue(String rewardValue) {
        this.rewardValue = rewardValue;
    }

    @Override
    public String toString() {
        return "PromoReward{" +
                "rewardType='" + rewardType + '\'' +
                ", rewardValue='" + rewardValue + '\'' +
                ", rewardQty='" + rewardQty + '\'' +
                ", voucherNumber='" + voucherNumber + '\'' +
                ", voucherDescription='" + voucherDescription + '\'' +
                '}';
    }
}
