package com.tesco.services.core.entity.product;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CommercialHierarchyInfo {

	@JsonProperty("divisionCode")
	private String divisionCode;
	@JsonProperty("divisionNumber")
	private String divisionNumber;
	@JsonProperty("divisionName")
	private String divisionName;
	@JsonProperty("departmentCode")
	private String departmentCode;
	@JsonProperty("departmentNumber")
	private String departmentNumber;
	@JsonProperty("departmentName")
	private String departmentName;
	@JsonProperty("sectionCode")
	private String sectionCode;
	@JsonProperty("sectionNumber")
	private String sectionNumber;
	@JsonProperty("sectionName")
	private String sectionName;
	@JsonProperty("classCode")
	private String classCode;
	@JsonProperty("classNumber")
	private String classNumber;
	@JsonProperty("className")
	private String className;
	@JsonProperty("subclassCode")
	private String subclassCode;
	@JsonProperty("subclassNumber")
	private String subclassNumber;
	@JsonProperty("subclassName")
	private String subclassName;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	/**
	 *
	 * @return
	 * The divisionCode
	 */
	@JsonProperty("divisionCode")
	public String getDivisionCode() {
		return divisionCode;
	}

	/**
	 *
	 * @param divisionCode
	 * The divisionCode
	 */
	@JsonProperty("divisionCode")
	public void setDivisionCode(String divisionCode) {
		this.divisionCode = divisionCode;
	}

	/**
	 *
	 * @return
	 * The divisionNumber
	 */
	@JsonProperty("divisionNumber")
	public String getDivisionNumber() {
		return divisionNumber;
	}

	/**
	 *
	 * @param divisionNumber
	 * The divisionNumber
	 */
	@JsonProperty("divisionNumber")
	public void setDivisionNumber(String divisionNumber) {
		this.divisionNumber = divisionNumber;
	}

	/**
	 *
	 * @return
	 * The divisionName
	 */
	@JsonProperty("divisionName")
	public String getDivisionName() {
		return divisionName;
	}

	/**
	 *
	 * @param divisionName
	 * The divisionName
	 */
	@JsonProperty("divisionName")
	public void setDivisionName(String divisionName) {
		this.divisionName = divisionName;
	}

	/**
	 *
	 * @return
	 * The departmentCode
	 */
	@JsonProperty("departmentCode")
	public String getDepartmentCode() {
		return departmentCode;
	}

	/**
	 *
	 * @param departmentCode
	 * The departmentCode
	 */
	@JsonProperty("departmentCode")
	public void setDepartmentCode(String departmentCode) {
		this.departmentCode = departmentCode;
	}

	/**
	 *
	 * @return
	 * The departmentNumber
	 */
	@JsonProperty("departmentNumber")
	public String getDepartmentNumber() {
		return departmentNumber;
	}

	/**
	 *
	 * @param departmentNumber
	 * The departmentNumber
	 */
	@JsonProperty("departmentNumber")
	public void setDepartmentNumber(String departmentNumber) {
		this.departmentNumber = departmentNumber;
	}

	/**
	 *
	 * @return
	 * The departmentName
	 */
	@JsonProperty("departmentName")
	public String getDepartmentName() {
		return departmentName;
	}

	/**
	 *
	 * @param departmentName
	 * The departmentName
	 */
	@JsonProperty("departmentName")
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	/**
	 *
	 * @return
	 * The sectionCode
	 */
	@JsonProperty("sectionCode")
	public String getSectionCode() {
		return sectionCode;
	}

	/**
	 *
	 * @param sectionCode
	 * The sectionCode
	 */
	@JsonProperty("sectionCode")
	public void setSectionCode(String sectionCode) {
		this.sectionCode = sectionCode;
	}

	/**
	 *
	 * @return
	 * The sectionNumber
	 */
	@JsonProperty("sectionNumber")
	public String getSectionNumber() {
		return sectionNumber;
	}

	/**
	 *
	 * @param sectionNumber
	 * The sectionNumber
	 */
	@JsonProperty("sectionNumber")
	public void setSectionNumber(String sectionNumber) {
		this.sectionNumber = sectionNumber;
	}

	/**
	 *
	 * @return
	 * The sectionName
	 */
	@JsonProperty("sectionName")
	public String getSectionName() {
		return sectionName;
	}

	/**
	 *
	 * @param sectionName
	 * The sectionName
	 */
	@JsonProperty("sectionName")
	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}

	/**
	 *
	 * @return
	 * The classCode
	 */
	@JsonProperty("classCode")
	public String getClassCode() {
		return classCode;
	}

	/**
	 *
	 * @param classCode
	 * The classCode
	 */
	@JsonProperty("classCode")
	public void setClassCode(String classCode) {
		this.classCode = classCode;
	}

	/**
	 *
	 * @return
	 * The classNumber
	 */
	@JsonProperty("classNumber")
	public String getClassNumber() {
		return classNumber;
	}

	/**
	 *
	 * @param classNumber
	 * The classNumber
	 */
	@JsonProperty("classNumber")
	public void setClassNumber(String classNumber) {
		this.classNumber = classNumber;
	}

	/**
	 *
	 * @return
	 * The className
	 */
	@JsonProperty("className")
	public String getClassName() {
		return className;
	}

	/**
	 *
	 * @param className
	 * The className
	 */
	@JsonProperty("className")
	public void setClassName(String className) {
		this.className = className;
	}

	/**
	 *
	 * @return
	 * The subclassCode
	 */
	@JsonProperty("subclassCode")
	public String getSubclassCode() {
		return subclassCode;
	}

	/**
	 *
	 * @param subclassCode
	 * The subclassCode
	 */
	@JsonProperty("subclassCode")
	public void setSubclassCode(String subclassCode) {
		this.subclassCode = subclassCode;
	}

	/**
	 *
	 * @return
	 * The subclassNumber
	 */
	@JsonProperty("subclassNumber")
	public String getSubclassNumber() {
		return subclassNumber;
	}

	/**
	 *
	 * @param subclassNumber
	 * The subclassNumber
	 */
	@JsonProperty("subclassNumber")
	public void setSubclassNumber(String subclassNumber) {
		this.subclassNumber = subclassNumber;
	}

	/**
	 *
	 * @return
	 * The subclassName
	 */
	@JsonProperty("subclassName")
	public String getSubclassName() {
		return subclassName;
	}

	/**
	 *
	 * @param subclassName
	 * The subclassName
	 */
	@JsonProperty("subclassName")
	public void setSubclassName(String subclassName) {
		this.subclassName = subclassName;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

}