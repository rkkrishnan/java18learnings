package com.tesco.services.core.entity;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

/**
 * Created by QZ88 on 14/10/2015.
 */
public class ZoneGrpEntity {

	@JsonProperty
	private String zoneGroupId;

	@JsonProperty
	private String zoneGroupName;

	@JsonProperty
	private String zoneGroupType;

	@JsonProperty
	private String createdDate;

	@JsonProperty
	private String createdById;

	@JsonProperty
	private String lastUpdateDate;

	@JsonProperty
	private String lastUpdatedById;

	@JsonProperty
	private List<String> zoneIds;

	public List<String> getZoneIds() {
		return zoneIds;
	}

	public void setZoneIds(List<String> zoneIds) {
		this.zoneIds = zoneIds;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedById() {
		return createdById;
	}

	public void setCreatedById(String createdById) {
		this.createdById = createdById;
	}

	public String getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(String lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	public String getLastUpdatedById() {
		return lastUpdatedById;
	}

	public void setLastUpdatedById(String lastUpdatedById) {
		this.lastUpdatedById = lastUpdatedById;
	}

	public String getZoneGroupType() {
		return zoneGroupType;
	}

	public void setZoneGroupType(String zoneGroupType) {
		this.zoneGroupType = zoneGroupType;
	}

	public String getZoneGroupName() {
		return zoneGroupName;
	}

	public void setZoneGroupName(String zoneGroupName) {
		this.zoneGroupName = zoneGroupName;
	}

	public String getZoneGroupId() {
		return zoneGroupId;
	}

	public void setZoneGroupId(String zoneGroupId) {
		this.zoneGroupId = zoneGroupId;
	}

	public ZoneGrpEntity(){
	}

	public ZoneGrpEntity(String zoneGroupId){
		this.zoneGroupId = zoneGroupId;
	}


	@Override
	public String toString() {
		return "ZoneGrpEntity{" +
				"zoneGroupId='" + zoneGroupId + '\'' +
				", zoneGroupName='" + zoneGroupName + '\'' +
				", zoneGroupType='" + zoneGroupType + '\'' +
				", createdDate='" + createdDate + '\'' +
				", createdById='" + createdById + '\'' +
				", lastUpdateDate='" + lastUpdateDate + '\'' +
				", lastUpdatedById='" + lastUpdatedById + '\'' +
				", zoneIds='" + zoneIds + '\'' +
				'}';
	}
}
