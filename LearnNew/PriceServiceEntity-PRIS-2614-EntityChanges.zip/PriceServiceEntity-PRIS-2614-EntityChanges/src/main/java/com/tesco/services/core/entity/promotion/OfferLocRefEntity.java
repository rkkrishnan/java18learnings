package com.tesco.services.core.entity.promotion;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;

import static com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility.ANY;
import static com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility.NONE;

/**
 * Created by PO47 on 13/10/2015.
 */

@SuppressWarnings("serial")
@JsonAutoDetect(fieldVisibility = ANY, getterVisibility = NONE,
		setterVisibility = NONE)
public class OfferLocRefEntity implements Serializable {


	@JsonProperty("effectiveDate")
	private String effectiveDate;
	@JsonProperty("endDate")
	private String endDate;
	@JsonIgnore
	private String hierarchyId;

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		OfferLocRefEntity other = (OfferLocRefEntity) obj;
		if (effectiveDate == null) {
			if (other.effectiveDate != null) {
				return false;
			}
		} else if (!effectiveDate.equals(other.effectiveDate)) {
			return false;
		}
		if (endDate == null) {
			if (other.endDate != null) {
				return false;
			}
		} else if (!endDate.equals(other.endDate)) {
			return false;
		}
		return true;
	}

	/**
	 *
	 * @return The effectiveDate
	 */
	@JsonProperty("effectiveDate")
	public String getEffectiveDate() {
		return effectiveDate;
	}

	/**
	 *
	 * @return The endDate
	 */
	@JsonProperty("endDate")
	public String getEndDate() {
		return endDate;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((effectiveDate == null) ? 0 : effectiveDate.hashCode());
		result = prime * result + ((endDate == null) ? 0 : endDate.hashCode());
		return result;
	}

	/**
	 *
	 * @param effectiveDate
	 *            The effectiveDate
	 */
	@JsonProperty("effectiveDate")
	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	/**
	 *
	 * @param endDate
	 *            The endDate
	 */
	@JsonProperty("endDate")
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getHierarchyId() {
		return hierarchyId;
	}

	public void setHierarchyId(String hierarchyId) {
		this.hierarchyId = hierarchyId;
	}

	@Override
	public String toString() {
		return "OfferLocRefEntity [effectiveDate="
				+ effectiveDate + ", endDate=" + endDate +"]";
	}
}
