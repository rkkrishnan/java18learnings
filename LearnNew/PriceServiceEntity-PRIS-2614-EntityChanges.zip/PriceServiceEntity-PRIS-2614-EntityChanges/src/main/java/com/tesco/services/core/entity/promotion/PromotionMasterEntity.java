package com.tesco.services.core.entity.promotion;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import static com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility.ANY;
import static com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility.NONE;

/**
 * Created by QZ88 on 27/05/2015.
 */
@JsonAutoDetect(fieldVisibility = ANY, getterVisibility = NONE,
		setterVisibility = NONE)
public class PromotionMasterEntity implements Serializable {

	public String getOfferType() {
		return offerType;
	}

	public void setOfferType(String offerType) {
		this.offerType = offerType;
	}

	public String getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedById() {
		return createdById;
	}

	public void setCreatedById(String createdById) {
		this.createdById = createdById;
	}

	public String getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(String lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	public String getLastUpdatedById() {
		return lastUpdatedById;
	}

	public void setLastUpdatedById(String lastUpdatedById) {
		this.lastUpdatedById = lastUpdatedById;
	}

	public Set<String> getOfferLocRef() {
		return offerLocRef;
	}

	public void setOfferLocRef(Set offerLocRef) {
		this.offerLocRef = offerLocRef;
	}

	@JsonProperty
	private String offerType;

	@JsonProperty
	private String effectiveDate;

	@JsonProperty
	private String endDate;

	@JsonProperty
	private Set<String> offerLocRef = new HashSet<String>();

	@JsonProperty
	private String createdDate;

	@JsonProperty
	private String createdById;

	@JsonProperty
	private String lastUpdateDate;

	@JsonProperty
	private String lastUpdatedById;

	@Override
	public String toString() {
		return "OfferLocation{" +
				", offerType='" + offerType + '\'' +
				", effectiveDate='" + effectiveDate + '\'' +
				", endDate='" + endDate + '\'' +
				", offerLocRef='" + offerLocRef + '\'' +
				", createdDate='" + createdDate + '\'' +
				", createdById='" + createdById + '\'' +
				", lastUpdateDate='" + lastUpdateDate + '\'' +
				", lastUpdatedById='" + lastUpdatedById + '\'' +
				'}';
	}

}
