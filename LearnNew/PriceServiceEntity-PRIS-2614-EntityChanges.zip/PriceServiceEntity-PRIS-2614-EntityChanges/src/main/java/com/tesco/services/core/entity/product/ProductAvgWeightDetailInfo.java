package com.tesco.services.core.entity.product;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by yp21 on 06/10/2015.
 */
public class ProductAvgWeightDetailInfo {
	@JsonProperty
	private String displayType;

	@JsonProperty
	private String avMaxWt;

	@JsonProperty
	private String minWt;

	@JsonProperty
	private String maxWt;

	@JsonProperty
	private String increment;

	@JsonProperty
	private String uom;

	@Override
	public String toString() {
		return "ProductAvgWeightDetailInfo{" +
				"displayType='" + displayType + '\'' +
				", avMaxWt='" + avMaxWt + '\'' +
				", minWt='" + minWt + '\'' +
				", maxWt='" + maxWt + '\'' +
				", increment='" + increment + '\'' +
				", uom='" + uom + '\'' +
				'}';
	}

	public String getDisplayType() {
		return displayType;
	}

	public void setDisplayType(String displayType) {
		this.displayType = displayType;
	}

	public String getAvMaxWt() {
		return avMaxWt;
	}

	public void setAvMaxWt(String avMaxWt) {
		this.avMaxWt = avMaxWt;
	}

	public String getUom() {
		return uom;
	}

	public void setUom(String uom) {
		this.uom = uom;
	}

	public String getMinWt() {
		return minWt;
	}

	public void setMinWt(String minWt) {
		this.minWt = minWt;
	}

	public String getMaxWt() {
		return maxWt;
	}

	public void setMaxWt(String maxWt) {
		this.maxWt = maxWt;
	}

	public String getIncrement() {
		return increment;
	}

	public void setIncrement(String increment) {
		this.increment = increment;
	}
}
