package com.tesco.services.core.entity;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class RPMClearance {

	@JsonProperty("docType")
	private String docType;
	@JsonProperty("versionNo")
	private String versionNo;
	@JsonProperty("dateTimeFormat")
	private String dateTimeFormat;
	@JsonProperty("currencyFormat")
	private String currencyFormat;
	@JsonProperty("countryFormat")
	private String countryFormat;
	@JsonProperty("productId")
	private String productId;
	@JsonProperty("prodType")
	private String prodType;
	@JsonProperty("sellingUom")
	private String sellingUom;
	@JsonProperty("tpncToClearanceProductVariant")
	private Map<String, ClearanceProductVariant> tpncToClearanceProductVariant = new HashMap<String, ClearanceProductVariant>();

	/**
	 * 
	 * @return The docType
	 */
	@JsonProperty("docType")
	public String getDocType() {
		return docType;
	}

	/**
	 * 
	 * @param docType
	 *            The docType
	 */
	@JsonProperty("docType")
	public void setDocType(String docType) {
		this.docType = docType;
	}

	/**
	 * 
	 * @return The versionNo
	 */
	@JsonProperty("versionNo")
	public String getVersionNo() {
		return versionNo;
	}

	/**
	 * 
	 * @param versionNo
	 *            The versionNo
	 */
	@JsonProperty("versionNo")
	public void setVersionNo(String versionNo) {
		this.versionNo = versionNo;
	}

	/**
	 * 
	 * @return The dateTimeFormat
	 */
	@JsonProperty("dateTimeFormat")
	public String getDateTimeFormat() {
		return dateTimeFormat;
	}

	/**
	 * 
	 * @param dateTimeFormat
	 *            The dateTimeFormat
	 */
	@JsonProperty("dateTimeFormat")
	public void setDateTimeFormat(String dateTimeFormat) {
		this.dateTimeFormat = dateTimeFormat;
	}

	/**
	 * 
	 * @return The currencyFormat
	 */
	@JsonProperty("currencyFormat")
	public String getCurrencyFormat() {
		return currencyFormat;
	}

	/**
	 * 
	 * @param currencyFormat
	 *            The currencyFormat
	 */
	@JsonProperty("currencyFormat")
	public void setCurrencyFormat(String currencyFormat) {
		this.currencyFormat = currencyFormat;
	}

	/**
	 * 
	 * @return The countryFormat
	 */
	@JsonProperty("countryFormat")
	public String getCountryFormat() {
		return countryFormat;
	}

	/**
	 * 
	 * @param countryFormat
	 *            The countryFormat
	 */
	@JsonProperty("countryFormat")
	public void setCountryFormat(String countryFormat) {
		this.countryFormat = countryFormat;
	}

	/**
	 * 
	 * @return The productId
	 */
	@JsonProperty("productId")
	public String getProductId() {
		return productId;
	}

	/**
	 * 
	 * @param productId
	 *            The productId
	 */
	@JsonProperty("productId")
	public void setProductId(String productId) {
		this.productId = productId;
	}

	/**
	 * 
	 * @return The prodType
	 */
	@JsonProperty("prodType")
	public String getProdType() {
		return prodType;
	}

	/**
	 * 
	 * @param prodType
	 *            The prodType
	 */
	@JsonProperty("prodType")
	public void setProdType(String prodType) {
		this.prodType = prodType;
	}

	/**
	 * 
	 * @return The sellingUom
	 */
	@JsonProperty("sellingUom")
	public String getSellingUom() {
		return sellingUom;
	}

	/**
	 * 
	 * @param sellingUom
	 *            The sellingUom
	 */
	@JsonProperty("sellingUom")
	public void setSellingUom(String sellingUom) {
		this.sellingUom = sellingUom;
	}

	/**
	 * 
	 * @return The tpncToClearanceProductVariant
	 */
	@JsonProperty("tpncToClearanceProductVariant")
	public Map<String,ClearanceProductVariant> getTpncToClearanceProductVariant() {
		return tpncToClearanceProductVariant;
	}

	/**
	 * 
	 * @param tpncToClearanceProductVariant
	 *            The tpncToClearanceProductVariant
	 */
	@JsonProperty("tpncToClearanceProductVariant")
	public void setTpncToClearanceProductVariant(
			Map<String,ClearanceProductVariant> tpncToClearanceProductVariant) {
		this.tpncToClearanceProductVariant = tpncToClearanceProductVariant;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((countryFormat == null) ? 0 : countryFormat.hashCode());
		result = prime * result
				+ ((currencyFormat == null) ? 0 : currencyFormat.hashCode());
		result = prime * result
				+ ((dateTimeFormat == null) ? 0 : dateTimeFormat.hashCode());
		result = prime * result + ((docType == null) ? 0 : docType.hashCode());
		result = prime * result
				+ ((prodType == null) ? 0 : prodType.hashCode());
		result = prime * result
				+ ((productId == null) ? 0 : productId.hashCode());
		result = prime * result
				+ ((sellingUom == null) ? 0 : sellingUom.hashCode());
		result = prime
				* result
				+ ((tpncToClearanceProductVariant == null) ? 0
						: tpncToClearanceProductVariant.hashCode());
		result = prime * result
				+ ((versionNo == null) ? 0 : versionNo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RPMClearance other = (RPMClearance) obj;
		if (countryFormat == null) {
			if (other.countryFormat != null)
				return false;
		} else if (!countryFormat.equals(other.countryFormat))
			return false;
		if (currencyFormat == null) {
			if (other.currencyFormat != null)
				return false;
		} else if (!currencyFormat.equals(other.currencyFormat))
			return false;
		if (dateTimeFormat == null) {
			if (other.dateTimeFormat != null)
				return false;
		} else if (!dateTimeFormat.equals(other.dateTimeFormat))
			return false;
		if (docType == null) {
			if (other.docType != null)
				return false;
		} else if (!docType.equals(other.docType))
			return false;
		if (prodType == null) {
			if (other.prodType != null)
				return false;
		} else if (!prodType.equals(other.prodType))
			return false;
		if (productId == null) {
			if (other.productId != null)
				return false;
		} else if (!productId.equals(other.productId))
			return false;
		if (sellingUom == null) {
			if (other.sellingUom != null)
				return false;
		} else if (!sellingUom.equals(other.sellingUom))
			return false;
		if (tpncToClearanceProductVariant == null) {
			if (other.tpncToClearanceProductVariant != null)
				return false;
		} else if (!tpncToClearanceProductVariant
				.equals(other.tpncToClearanceProductVariant))
			return false;
		if (versionNo == null) {
			if (other.versionNo != null)
				return false;
		} else if (!versionNo.equals(other.versionNo))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "RPMClearance [docType=" + docType + ", versionNo=" + versionNo
				+ ", dateTimeFormat=" + dateTimeFormat + ", currencyFormat="
				+ currencyFormat + ", countryFormat=" + countryFormat
				+ ", productId=" + productId + ", prodType=" + prodType
				+ ", sellingUom=" + sellingUom
				+ ", tpncToClearanceProductVariant="
				+ tpncToClearanceProductVariant + "]";
	}

}
