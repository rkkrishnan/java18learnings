package com.tesco.services.core.entity;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import static com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility.ANY;
import static com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility.NONE;


@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonAutoDetect(fieldVisibility = ANY, getterVisibility = NONE, setterVisibility = NONE)

public class ClearanceZoneSaleInfo implements Serializable {
    @JsonProperty
    private String clearanceZoneId;
    @JsonProperty
    private String countryCode;
    @JsonProperty
    private String currency;
    @JsonProperty
    private Map<String, ClearanceByDateTime> zonesClearancePriceByDateTime = new HashMap<>();

    /**
     * Constructor ClearanceZoneSaleInfo
     * @param clearanceZoneId
     * @param countryCode
     * @param currency
     */
    public ClearanceZoneSaleInfo(String clearanceZoneId, String countryCode, String currency) {
        this.clearanceZoneId = clearanceZoneId;
        this.countryCode = countryCode;
        this.currency = currency;

    }

    /**
     * Constructor ClearanceZoneSaleInfo
     */
    public ClearanceZoneSaleInfo() {

    }

    public void addZoneClearanceByDateTime(ClearanceByDateTime clearanceByDateTime) throws ParseException {
        zonesClearancePriceByDateTime.put(getClearanceByDateTimeKeyFormat(clearanceByDateTime.getEffvDateTime()), clearanceByDateTime);
    }
    public void deleteZoneClearanceByDateTime(ClearanceByDateTime clearanceByDateTime) throws ParseException {
        zonesClearancePriceByDateTime.remove(getClearanceByDateTimeKeyFormat(clearanceByDateTime.getEffvDateTime()));
    }

    /*Added for PS-386 -- Start*/
    public void deleteZoneClearanceByDateTimeForRPMClr(String clearanceByDateTime) throws ParseException {
        zonesClearancePriceByDateTime.remove(clearanceByDateTime);
    }
    /*Added for PS-386 -- End*/

    public String getClearanceZoneId() {
        return clearanceZoneId;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public String getCurrency() {
        return currency;
    }

    public void setClearanceZoneId(String clearanceZoneId) {
        this.clearanceZoneId = clearanceZoneId;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public ClearanceByDateTime getZoneClearancePriceByDateTime(String effvDateTime) throws ParseException {
        return zonesClearancePriceByDateTime.get(getClearanceByDateTimeKeyFormat(effvDateTime));
    }

    /*Added for PS-386 -- Start*/
    public Map<String, ClearanceByDateTime>  getZoneClearancePriceByDateTime()  {
        return zonesClearancePriceByDateTime;
    }

    public ClearanceByDateTime getZoneClearancePriceByDateTimeForRpmClr(String effvDateTime) throws ParseException {
        return zonesClearancePriceByDateTime.get(effvDateTime);
    }
    /*Added for PS-386 -- End*/

    //Corrected the equals() method as part of PRIS-1133 Java 8 Migration
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        ClearanceZoneSaleInfo clearanceZoneSaleInfo = (ClearanceZoneSaleInfo) o;
        if (clearanceZoneId != null ? !clearanceZoneId.equals(clearanceZoneSaleInfo.clearanceZoneId) : clearanceZoneSaleInfo.clearanceZoneId != null){
            return false;
        }
        if (countryCode != null ? !countryCode.equals(clearanceZoneSaleInfo.countryCode) : clearanceZoneSaleInfo.countryCode != null){
            return false;
        }
        if ((currency != null ? !currency.equals(clearanceZoneSaleInfo.currency) : clearanceZoneSaleInfo.currency != null)){
            return false;
        }
        if(zonesClearancePriceByDateTime != null ? !zonesClearancePriceByDateTime.equals(clearanceZoneSaleInfo.zonesClearancePriceByDateTime) : clearanceZoneSaleInfo.zonesClearancePriceByDateTime != null){
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int result = clearanceZoneId != null ? clearanceZoneId.hashCode() : 0;
        result = 31 * result + (countryCode != null ? countryCode.hashCode() : 0);
        result = 31 * result + (currency != null ? currency.hashCode() : 0);
        result = 31 * result + (zonesClearancePriceByDateTime != null ? zonesClearancePriceByDateTime.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "ClearanceZoneSaleInfo{" +
                "clearanceZoneId=" + clearanceZoneId +
                ", countryCode='" + countryCode + '\'' +
                ", currency='" + currency + '\'' +
                ", zoneClearancePriceByDateTime :" + zonesClearancePriceByDateTime +
                '}';
    }


    public Collection<ClearanceByDateTime> getZonesClearancePriceByDateTime() {
        return zonesClearancePriceByDateTime.values();
    }

    private static String getClearanceByDateTimeKeyFormat(String date)
            throws ParseException {

        SimpleDateFormat dateFormatFromFiles = new SimpleDateFormat(
                "yyyy-MM-dd'T'HH:mm:ss");
        SimpleDateFormat isodateformat = new SimpleDateFormat("yyyyMMddHHmmss");
        Date date1 = dateFormatFromFiles.parse(date);

        return isodateformat.format(date1);
    }
}
