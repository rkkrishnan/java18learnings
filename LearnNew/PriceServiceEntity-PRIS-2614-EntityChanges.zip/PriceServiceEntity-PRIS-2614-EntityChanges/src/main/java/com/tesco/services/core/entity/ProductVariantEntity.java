package com.tesco.services.core.entity;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProductVariantEntity {

	@JsonProperty("tpnc")
	private String tpnc;
	@JsonProperty("sellingUOM")
	private String sellingUOM;
	@JsonProperty("zoneIdToSaleInfo")
	private Map<String, SaleInfoEntity> zoneIdToSaleInfo = new HashMap<String, SaleInfoEntity>();
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	/**
	 * 
	 * @return The tpnc
	 */
	@JsonProperty("tpnc")
	public String getTpnc() {
		return tpnc;
	}

	/**
	 * 
	 * @param tpnc
	 *            The tpnc
	 */
	@JsonProperty("tpnc")
	public void setTpnc(String tpnc) {
		this.tpnc = tpnc;
	}

	/**
	 * 
	 * @return The sellingUOM
	 */
	@JsonProperty("sellingUOM")
	public String getSellingUOM() {
		return sellingUOM;
	}

	/**
	 * 
	 * @param sellingUOM
	 *            The sellingUOM
	 */
	@JsonProperty("sellingUOM")
	public void setSellingUOM(String sellingUOM) {
		this.sellingUOM = sellingUOM;
	}

	/**
	 * 
	 * @return The zoneIdToSaleInfo
	 */
	@JsonProperty("zoneIdToSaleInfo")
	public Map<String, SaleInfoEntity> getZoneIdToSaleInfo() {
		return zoneIdToSaleInfo;
	}

	/**
	 * 
	 * @param zoneIdToSaleInfo
	 *            The zoneIdToSaleInfo
	 */
	@JsonProperty("zoneIdToSaleInfo")
	public void setZoneIdToSaleInfo(Map<String, SaleInfoEntity> zoneIdToSaleInfo) {
		this.zoneIdToSaleInfo = zoneIdToSaleInfo;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(tpnc).append(sellingUOM)
				.append(zoneIdToSaleInfo).append(additionalProperties)
				.toHashCode();
	}

	@Override
	public boolean equals(Object other) {
		if (other == this) {
			return true;
		}
		if (!(other instanceof ProductVariantEntity)) {
			return false;
		}
		ProductVariantEntity rhs = ((ProductVariantEntity) other);
		return new EqualsBuilder().append(tpnc, rhs.tpnc)
				.append(sellingUOM, rhs.sellingUOM)
				.append(zoneIdToSaleInfo, rhs.zoneIdToSaleInfo)
				.append(additionalProperties, rhs.additionalProperties)
				.isEquals();
	}

}
