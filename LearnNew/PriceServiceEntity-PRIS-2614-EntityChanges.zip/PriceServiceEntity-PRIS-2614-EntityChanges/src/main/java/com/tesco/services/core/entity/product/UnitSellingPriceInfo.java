package com.tesco.services.core.entity.product;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by qp65 on 9/22/2015.
 */
public class UnitSellingPriceInfo {

	private String sellByType;
	private String subclassCode;
	private List<DrainedIndicatorInfo> drainedIndicatorInfos = new ArrayList<>();
	private List<QuantityInfo> quantityInfos = new ArrayList<>();
	private String errorResponse = null;

	public String getSellByType() {
		return sellByType;
	}

	public void setSellByType(String sellByType) {
		this.sellByType = sellByType;
	}

	public String getSubclassCode() {
		return subclassCode;
	}

	public void setSubclassCode(String subclassCode) {
		this.subclassCode = subclassCode;
	}

	public List<DrainedIndicatorInfo> getDrainedIndicatorInfos() {
		return drainedIndicatorInfos;
	}

	public void setDrainedIndicatorInfos(
			List<DrainedIndicatorInfo> drainedIndicatorInfos) {
		this.drainedIndicatorInfos = drainedIndicatorInfos;
	}

	public List<QuantityInfo> getQuantityInfos() {
		return quantityInfos;
	}

	public void setQuantityInfos(List<QuantityInfo> quantityInfos) {
		this.quantityInfos = quantityInfos;
	}

	public String getErrorResponse() {
		return errorResponse;
	}

	public void setErrorResponse(String errorResponse) {
		this.errorResponse = errorResponse;
	}

	@Override public String toString() {
		return "UnitSellingPriceInfo{" +
				"sellByType='" + sellByType + '\'' +
				", subclassCode='" + subclassCode + '\'' +
				", drainedIndicatorInfos=" + drainedIndicatorInfos +
				", quantityInfos=" + quantityInfos +
				'}';
	}
}
