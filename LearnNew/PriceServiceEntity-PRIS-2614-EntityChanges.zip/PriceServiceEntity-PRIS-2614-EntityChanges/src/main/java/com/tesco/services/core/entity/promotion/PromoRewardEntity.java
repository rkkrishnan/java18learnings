package com.tesco.services.core.entity.promotion;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by iv16 on 5/5/2015.
 */
public class PromoRewardEntity {
	@JsonProperty("@type")
	public String type;

	@JsonProperty("changeType")
	public String changeType;

	@JsonProperty("changeQty")
	public String changeQty;

	@JsonProperty("changeAmount")
	public double changeAmount;

	@JsonProperty("changeCurrency")
	public String changeCurrency;

	@JsonProperty("changePercent")
	public double changePercent;

	@JsonProperty("changeUom")
	public String changeUom;

	@JsonProperty("voucherNumber")
	public String voucherNumber;

	@JsonProperty("voucherDescription")
	public String voucherDescription;

	public String getChangeQty() {
		return changeQty;
	}

	public void setChangeQty(String changeQty) {
		this.changeQty = changeQty;
	}

	public double getChangeAmount() {
		return changeAmount;
	}

	public void setChangeAmount(double changeAmount) {
		this.changeAmount = changeAmount;
	}

	public String getChangeCurrency() {
		return changeCurrency;
	}

	public void setChangeCurrency(String changeCurrency) {
		this.changeCurrency = changeCurrency;
	}

	public double getChangePercent() {
		return changePercent;
	}

	public void setChangePercent(double changePercent) {
		this.changePercent = changePercent;
	}

	public String getChangeUom() {
		return changeUom;
	}

	public void setChangeUom(String changeUom) {
		this.changeUom = changeUom;
	}

	public String getVoucherNumber() {
		return voucherNumber;
	}

	public void setVoucherNumber(String voucherNumber) {
		this.voucherNumber = voucherNumber;
	}

	public String getVoucherDescription() {
		return voucherDescription;
	}

	public void setVoucherDescription(String voucherDescription) {
		this.voucherDescription = voucherDescription;
	}

	public void setChangeType(String changeType) {
		this.changeType = changeType;
	}

	public String getChangeType() {
		return changeType;
	}

	@Override
	public String toString() {
		return "PromoRewardEntity{" +
				"type='" + type + '\'' +
				", changeType='" + changeType + '\'' +
				", changeQty='" + changeQty + '\'' +
				", changeAmount=" + changeAmount +
				", changeCurrency='" + changeCurrency + '\'' +
				", changePercent=" + changePercent +
				", changeUom='" + changeUom + '\'' +
				", voucherNumber='" + voucherNumber + '\'' +
				", voucherDescription='" + voucherDescription + '\'' +
				'}';
	}

}
