package com.tesco.services.adapters.promotion;

import com.tesco.services.adapters.core.exceptions.PromotionEventException;
import com.tesco.services.adapters.promotion.impl.PromotionEventHandlerImpl;
import com.tesco.services.core.ZoneEntity;
import com.tesco.services.core.promotion.PromoItemEntity;
import com.tesco.services.core.promotion.PromoRewardEntity;
import com.tesco.services.core.promotion.PromoThresholdEntity;
import com.tesco.services.event.core.EventTemplate;
import com.tesco.services.event.core.impl.MapEvent;
import com.tesco.services.event.exception.EventPublishException;
import com.tesco.services.repositories.RepositoryImpl;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.PriceConstants;
import org.joda.time.DateTime;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.tesco.services.utility.PriceConstants.*;
import static org.junit.Assert.assertEquals;

@RunWith(MockitoJUnitRunner.class)
public class PromotionEventHandlerImplTest {

	@Mock
	private EventTemplate eventTemplate;

	private PromotionEventHandler promoEventHandler;

	@Mock
	private RepositoryImpl repositoryImpl;

	@Captor
	private ArgumentCaptor<MapEvent> argument;
	
	String effectiveDate;

	@Before
	public void setUp() throws Exception {
		promoEventHandler = new PromotionEventHandlerImpl(eventTemplate,
				repositoryImpl);
		ZoneEntity ze = new ZoneEntity();
		ze.setZoneId("12");
		ze.setZoneGroupId("90");
		ze.setTslCountryCode("IE");
		ze.setZoneName("testZone");
		Mockito.when(repositoryImpl.getGenericObject("ZONE_12",ZoneEntity.class)).thenReturn(ze);
		
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 5);
		effectiveDate = dateFormat.format(cal.getTime());
	}

	@Test
	public void shouldSendPromotionDetailsChangedEventSimplePromotion()
			throws PromotionEventException, ParseException, EventPublishException {
		List<PromoThresholdEntity> promoThresholdEntities = new ArrayList<>();
		List<PromoRewardEntity> promoRewardEntities = new ArrayList<>();
		List<PromoRewardEntity> existingPromoRewardEntities = new ArrayList<>();
		PromoThresholdEntity promoThresholdEntity = new PromoThresholdEntity();
		promoThresholdEntity.thresholdType = PriceConstants.SIMPLE_PROMO_THR_TYPE;
		promoThresholdEntity.thresholdAmount = PriceConstants.SIMPLE_PROMO_THR_AMT;
		promoThresholdEntity.thresholdCurrency = null;
		promoThresholdEntity.thresholdQty = PriceConstants.SIMPLE_PROMO_THR_QTY;
		promoThresholdEntities.add(promoThresholdEntity);

		PromoRewardEntity existingPromoRewardEntity = new PromoRewardEntity();
		existingPromoRewardEntity.changeType = "F";
		existingPromoRewardEntity.changeAmount = Double.valueOf("0.01");
		existingPromoRewardEntity.changeUom = "EA";
		existingPromoRewardEntity.changeCurrency = null;
		existingPromoRewardEntities.add(existingPromoRewardEntity);

		PromoRewardEntity promoRewardEntity = new PromoRewardEntity();
		promoRewardEntity.changeType = "F";
		promoRewardEntity.changeAmount = Double.valueOf("0.02");
		promoRewardEntity.changeUom = "EA";
		promoRewardEntity.changeCurrency = null;
		promoRewardEntities.add(promoRewardEntity);

		Map<String, Object> argumentData = new HashMap<>();
		argumentData.put("existingPromotionThresholdEntities", promoThresholdEntities);
		argumentData.put("modifiedPromotionThresholdEntities", promoThresholdEntities);
		argumentData.put("existingPromoRewardEntities", existingPromoRewardEntities);
		argumentData.put("modifiedPromoRewardsEntities", promoRewardEntities);
		argumentData.put("offerId", "1559883");

		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, +(2));
		String effectiveDate = dateFormat.format(cal.getTime());
		String formattedEffDate = Dockyard.getISO8601FormatStartDate(effectiveDate);
		Map<String, DateTime> offLeveleffectiveDateMap = new HashMap<>();
		offLeveleffectiveDateMap.put("1559883", new DateTime(formattedEffDate + ".000+01:00"));
		argumentData.put("offLeveleffectiveDateMap", offLeveleffectiveDateMap);
		Map<String, Object> promotionDetailsChangedOfferLevelEventMap = new HashMap<>();
		promotionDetailsChangedOfferLevelEventMap.put("1559883", argumentData);
		Map<String, Object> allEventsData = new HashMap<>();
		allEventsData.put(PROMOTION_DETAILS_CHANGED_OFFER_LEVEL_KEY, promotionDetailsChangedOfferLevelEventMap);
		
		promoEventHandler.processPromotionEvents(PriceConstants.PROMO_MSG_TYPE_MOD,"12","Z",allEventsData);
		Mockito.verify(eventTemplate, Mockito.times(1)).publishEvent(argument.capture());
		assertEquals(PROMOTION_DETAILS_CHANGED_EVENT_TYPE,
				String.valueOf((argument.getValue()).getHeaderData().get("EventType")));
		assertEquals(2, Integer.valueOf((argument.getValue()).getHeaderData().get("LeadTimeDays")).intValue());
		assertEquals("IE:Z:12", (argument.getValue()).getHeaderData().get(PriceConstants.LOCATION_ID));
		assertEquals("1559883", (argument.getValue()).getPayloadData().get(PriceConstants.OFFER_ID));
	}

	@Test
	public void shouldNotSendPromotionDetailsChangedEvent()
			throws PromotionEventException, ParseException, EventPublishException {
		List<PromoThresholdEntity> promoThresholdEntities = new ArrayList<>();
		List<PromoRewardEntity> existingPromoRewardEntities = new ArrayList<>();
		PromoThresholdEntity promoThresholdEntity = new PromoThresholdEntity();
		promoThresholdEntity.thresholdType = PriceConstants.SIMPLE_PROMO_THR_TYPE;
		promoThresholdEntity.thresholdAmount = PriceConstants.SIMPLE_PROMO_THR_AMT;
		promoThresholdEntity.thresholdCurrency = null;
		promoThresholdEntity.thresholdQty = PriceConstants.SIMPLE_PROMO_THR_QTY;
		promoThresholdEntities.add(promoThresholdEntity);

		PromoRewardEntity existingPromoRewardEntity = new PromoRewardEntity();
		existingPromoRewardEntity.changeType = "F";
		existingPromoRewardEntity.changeAmount = Double.valueOf("0.01");
		existingPromoRewardEntity.changeUom = "EA";
		existingPromoRewardEntity.changeCurrency = null;
		existingPromoRewardEntities.add(existingPromoRewardEntity);

		Map<String, Object> argumentData = new HashMap<>();
		argumentData.put("existingPromotionThresholdEntities", promoThresholdEntities);
		argumentData.put("modifiedPromotionThresholdEntities", promoThresholdEntities);
		argumentData.put("existingPromoRewardEntities", existingPromoRewardEntities);
		argumentData.put("modifiedPromoRewardsEntities", existingPromoRewardEntities);
		argumentData.put("offerId", "1559883");

		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, +(2));
		String effectiveDate = dateFormat.format(cal.getTime());
		String formattedEffDate = Dockyard.getISO8601FormatStartDate(effectiveDate);
		Map<String, String> offLeveleffectiveDateMap = new HashMap<>();
		offLeveleffectiveDateMap.put("1559883", formattedEffDate + ".000+01:00");
		argumentData.put("offLeveleffectiveDateMap", offLeveleffectiveDateMap);
		promoEventHandler.processPromotionEvents(PriceConstants.PROMO_MSG_TYPE_MOD,"12","Z",argumentData);
		Mockito.verify(eventTemplate, Mockito.times(0)).publishEvent(argument.capture());
	}

	@Test
	public void shouldSendPromotionDetailsChangedEventThresholdPromotion()
			throws PromotionEventException, ParseException, EventPublishException {
		List<PromoThresholdEntity> promoThresholdEntities = new ArrayList<>();
		List<PromoThresholdEntity> modifiedPromoThresholdEntities = new ArrayList<>();
		List<PromoRewardEntity> existingPromoRewardEntities = new ArrayList<>();
		PromoThresholdEntity promoThresholdEntity = new PromoThresholdEntity();
		promoThresholdEntity.thresholdType = PriceConstants.SIMPLE_PROMO_THR_TYPE;
		promoThresholdEntity.thresholdAmount = PriceConstants.SIMPLE_PROMO_THR_AMT;
		promoThresholdEntity.thresholdCurrency = null;
		promoThresholdEntity.thresholdQty = PriceConstants.SIMPLE_PROMO_THR_QTY;
		promoThresholdEntities.add(promoThresholdEntity);

		PromoThresholdEntity modifiedPromoThresholdEntity = new PromoThresholdEntity();
		modifiedPromoThresholdEntity.thresholdType = PriceConstants.SIMPLE_PROMO_THR_TYPE;
		modifiedPromoThresholdEntity.thresholdAmount = PriceConstants.SIMPLE_PROMO_THR_AMT;
		modifiedPromoThresholdEntity.thresholdCurrency = null;
		modifiedPromoThresholdEntity.thresholdQty = 2;
		modifiedPromoThresholdEntities.add(modifiedPromoThresholdEntity);

		PromoRewardEntity existingPromoRewardEntity = new PromoRewardEntity();
		existingPromoRewardEntity.changeType = "F";
		existingPromoRewardEntity.changeAmount = Double.valueOf("0.01");
		existingPromoRewardEntity.changeUom = "EA";
		existingPromoRewardEntity.changeCurrency = null;
		existingPromoRewardEntities.add(existingPromoRewardEntity);

		Map<String, Object> argumentData = new HashMap<>();
		argumentData.put("existingPromotionThresholdEntities", promoThresholdEntities);
		argumentData.put("modifiedPromotionThresholdEntities", modifiedPromoThresholdEntities);
		argumentData.put("existingPromoRewardEntities", existingPromoRewardEntities);
		argumentData.put("modifiedPromoRewardsEntities", existingPromoRewardEntities);
		argumentData.put("offerId", "1559883");

		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, +(2));
		String effectiveDate = dateFormat.format(cal.getTime());
		String formattedEffDate = Dockyard.getISO8601FormatStartDate(effectiveDate);
		Map<String, DateTime> offLeveleffectiveDateMap = new HashMap<>();
		offLeveleffectiveDateMap.put("1559883", new DateTime(formattedEffDate + ".000+01:00"));
		argumentData.put("offLeveleffectiveDateMap", offLeveleffectiveDateMap);
		Map<String, Object> promotionDetailsChangedOfferLevelEventMap = new HashMap<>();
		promotionDetailsChangedOfferLevelEventMap.put("1559883", argumentData);
		Map<String, Object> allEventsData = new HashMap<>();
		allEventsData.put(PROMOTION_DETAILS_CHANGED_OFFER_LEVEL_KEY, promotionDetailsChangedOfferLevelEventMap);
		
		promoEventHandler.processPromotionEvents(PriceConstants.PROMO_MSG_TYPE_MOD,"12","Z",allEventsData);
		Mockito.verify(eventTemplate, Mockito.times(1)).publishEvent(argument.capture());
		assertEquals(PriceConstants.PROMOTION_DETAILS_CHANGED_EVENT_TYPE,
				String.valueOf((argument.getValue()).getHeaderData().get("EventType")));
		assertEquals(2, Integer.valueOf((argument.getValue()).getHeaderData().get("LeadTimeDays")).intValue());
		assertEquals("IE:Z:12", (argument.getValue()).getHeaderData().get(PriceConstants.LOCATION_ID));
		assertEquals("1559883", (argument.getValue()).getPayloadData().get(PriceConstants.OFFER_ID));
	}
	
	@Test
	public void shouldSendPromotionDetailsChangedProductLevelWasPriceChangedEventSimplePromotion()
			throws PromotionEventException, ParseException, EventPublishException {
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, +(2));
		String effectiveDate = dateFormat.format(cal.getTime());
		String formattedEffDate = Dockyard.getISO8601FormatStartDate(effectiveDate);
		
		List<PromoItemEntity> existingPromoItemEntities = new ArrayList<>();
		PromoItemEntity promoItemEntity = new PromoItemEntity();
		promoItemEntity.effectiveDate = formattedEffDate;
		promoItemEntity.endDate = formattedEffDate;
		promoItemEntity.itemType = PriceConstants.PROMO_ITEM_TYPE;
		promoItemEntity.itemRef = "063165054";
		promoItemEntity.setWasPrice("0.29");
		promoItemEntity.setWasWasPrice("1.29");
		promoItemEntity.setPosLabelReqInd(PriceConstants.POS_LABEL_Y);
		promoItemEntity.setRpmPromoCompDetailId("40690111");
		existingPromoItemEntities.add(promoItemEntity);
		
		PromoItemEntity promoItemEntitySecond = new PromoItemEntity();
		promoItemEntitySecond.effectiveDate = formattedEffDate;
		promoItemEntitySecond.endDate = formattedEffDate;
		promoItemEntitySecond.itemType = PriceConstants.PROMO_ITEM_TYPE;
		promoItemEntitySecond.itemRef = "064727108";
		promoItemEntitySecond.setWasPrice("1");
		promoItemEntitySecond.setWasWasPrice("2");
		promoItemEntitySecond.setPosLabelReqInd(PriceConstants.POS_LABEL_Y);
		promoItemEntitySecond.setRpmPromoCompDetailId("40690222");
		existingPromoItemEntities.add(promoItemEntitySecond);
		
		List<PromoItemEntity> modifiedPromoItemEntities = new ArrayList<>();
		PromoItemEntity modifiedPromoItemEntity = new PromoItemEntity();
		modifiedPromoItemEntity.effectiveDate = formattedEffDate;
		modifiedPromoItemEntity.endDate = formattedEffDate;
		modifiedPromoItemEntity.itemType = PriceConstants.PROMO_ITEM_TYPE;
		modifiedPromoItemEntity.itemRef = "063165054";
		modifiedPromoItemEntity.setWasPrice("0.19");
		modifiedPromoItemEntity.setWasWasPrice("1.29");
		modifiedPromoItemEntity.setPosLabelReqInd(PriceConstants.POS_LABEL_Y);
		modifiedPromoItemEntity.setRpmPromoCompDetailId("40690111");
		modifiedPromoItemEntities.add(modifiedPromoItemEntity);
		modifiedPromoItemEntities.add(promoItemEntitySecond);

		Map<Object, Object> argumentData = new HashMap<>();
		argumentData.put("existingPromoItemEntities", existingPromoItemEntities);
		argumentData.put("modifiedPromoItemEntities", modifiedPromoItemEntities);
	
		argumentData.put("promoMsgForZoneId", "12");
		argumentData.put("promoMsgLocType", "Z");
		argumentData.put("offerId", "31802215");
		
		Map<String, Object> promotionDetailsChangedOfferLevelEventMap = new HashMap<>();
		promotionDetailsChangedOfferLevelEventMap.put("31802215", argumentData);
		Map<String, Object> allEventsData = new HashMap<>();
		allEventsData.put(PROMOTION_DETAILS_CHANGED_PRODUCT_LEVEL_KEY, promotionDetailsChangedOfferLevelEventMap);
		
		promoEventHandler.processPromotionEvents(PriceConstants.PROMO_MSG_TYPE_MOD,"12","Z",allEventsData);
		Mockito.verify(eventTemplate, Mockito.times(1)).publishEvent(argument.capture());
		
		assertEquals(PriceConstants.PROMOTION_DETAILS_CHANGED_EVENT_TYPE,
				String.valueOf((argument.getValue()).getHeaderData().get("EventType")));
		assertEquals(2, Integer.valueOf((argument.getValue()).getHeaderData().get("LeadTimeDays")).intValue());
		assertEquals("IE:Z:12", (argument.getValue()).getHeaderData().get(PriceConstants.LOCATION_ID));
		assertEquals("31802215", (argument.getValue()).getPayloadData().get(PriceConstants.OFFER_ID));
		assertEquals("tpnb:063165054", (argument.getValue()).getPayloadData().get(PriceConstants.PROD_REF));
	}
	
	@Test
	public void shouldNotSendPromotionDetailsChangedProductLevelEventSimplePromotion()
			throws PromotionEventException, ParseException, EventPublishException {
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, +(2));
		String effectiveDate = dateFormat.format(cal.getTime());
		String formattedEffDate = Dockyard.getISO8601FormatStartDate(effectiveDate);
		
		List<PromoItemEntity> existingPromoItemEntities = new ArrayList<>();
		PromoItemEntity promoItemEntity = new PromoItemEntity();
		promoItemEntity.effectiveDate = formattedEffDate;
		promoItemEntity.endDate = formattedEffDate;
		promoItemEntity.itemType = PriceConstants.PROMO_ITEM_TYPE;
		promoItemEntity.itemRef = "063165054";
		promoItemEntity.setWasPrice("0.29");
		promoItemEntity.setWasWasPrice("1.29");
		promoItemEntity.setPosLabelReqInd(PriceConstants.POS_LABEL_Y);
		promoItemEntity.setRpmPromoCompDetailId("40690111");
		existingPromoItemEntities.add(promoItemEntity);
		
		PromoItemEntity promoItemEntitySecond = new PromoItemEntity();
		promoItemEntitySecond.effectiveDate = formattedEffDate;
		promoItemEntitySecond.endDate = formattedEffDate;
		promoItemEntitySecond.itemType = PriceConstants.PROMO_ITEM_TYPE;
		promoItemEntitySecond.itemRef = "064727108";
		promoItemEntitySecond.setWasPrice("1");
		promoItemEntitySecond.setWasWasPrice("2");
		promoItemEntitySecond.setPosLabelReqInd(PriceConstants.POS_LABEL_Y);
		promoItemEntitySecond.setRpmPromoCompDetailId("40690222");
		existingPromoItemEntities.add(promoItemEntitySecond);
		
		List<PromoItemEntity> modifiedPromoItemEntities = new ArrayList<>();		
		modifiedPromoItemEntities.add(promoItemEntity);
		modifiedPromoItemEntities.add(promoItemEntitySecond);

		Map<Object, Object> argumentData = new HashMap<>();
		argumentData.put("existingPromoItemEntities", existingPromoItemEntities);
		argumentData.put("modifiedPromoItemEntities", modifiedPromoItemEntities);
	
		argumentData.put("promoMsgForZoneId", "12");
		argumentData.put("promoMsgLocType", "Z");
		argumentData.put("offerId", "31802215");
		Map<String, Object> promotionDetailsChangedOfferLevelEventMap = new HashMap<>();
		promotionDetailsChangedOfferLevelEventMap.put("31802215", argumentData);
		Map<String, Object> allEventsData = new HashMap<>();
		allEventsData.put(PROMOTION_DETAILS_CHANGED_PRODUCT_LEVEL_KEY, promotionDetailsChangedOfferLevelEventMap);
		
		promoEventHandler.processPromotionEvents(PriceConstants.PROMO_MSG_TYPE_MOD,"12","Z",allEventsData);
		Mockito.verify(eventTemplate, Mockito.times(0)).publishEvent(argument.capture());
	
	}
	
	@Test
	public void shouldSendPromotionDetailsChangedProductLevelWasWasPriceChangedEventSimplePromotion()
			throws PromotionEventException, ParseException, EventPublishException {
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, +(2));
		String effectiveDate = dateFormat.format(cal.getTime());
		String formattedEffDate = Dockyard.getISO8601FormatStartDate(effectiveDate);
		
		List<PromoItemEntity> existingPromoItemEntities = new ArrayList<>();
		PromoItemEntity promoItemEntity = new PromoItemEntity();
		promoItemEntity.effectiveDate = formattedEffDate;
		promoItemEntity.endDate = formattedEffDate;
		promoItemEntity.itemType = PriceConstants.PROMO_ITEM_TYPE;
		promoItemEntity.itemRef = "063165054";
		promoItemEntity.setWasPrice("0.29");
		promoItemEntity.setWasWasPrice("1.29");
		promoItemEntity.setPosLabelReqInd(PriceConstants.POS_LABEL_Y);
		promoItemEntity.setRpmPromoCompDetailId("40690111");
		existingPromoItemEntities.add(promoItemEntity);
		
		PromoItemEntity promoItemEntitySecond = new PromoItemEntity();
		promoItemEntitySecond.effectiveDate = formattedEffDate;
		promoItemEntitySecond.endDate = formattedEffDate;
		promoItemEntitySecond.itemType = PriceConstants.PROMO_ITEM_TYPE;
		promoItemEntitySecond.itemRef = "064727108";
		promoItemEntitySecond.setWasPrice("1");
		promoItemEntitySecond.setWasWasPrice("2");
		promoItemEntitySecond.setPosLabelReqInd(PriceConstants.POS_LABEL_Y);
		promoItemEntitySecond.setRpmPromoCompDetailId("40690222");
		existingPromoItemEntities.add(promoItemEntitySecond);
		
		List<PromoItemEntity> modifiedPromoItemEntities = new ArrayList<>();
		PromoItemEntity modifiedPromoItemEntity = new PromoItemEntity();
		modifiedPromoItemEntity.effectiveDate = formattedEffDate;
		modifiedPromoItemEntity.endDate = formattedEffDate;
		modifiedPromoItemEntity.itemType = PriceConstants.PROMO_ITEM_TYPE;
		modifiedPromoItemEntity.itemRef = "063165054";
		modifiedPromoItemEntity.setWasPrice("0.29");
		modifiedPromoItemEntity.setWasWasPrice("1.19");
		modifiedPromoItemEntity.setPosLabelReqInd(PriceConstants.POS_LABEL_Y);
		modifiedPromoItemEntity.setRpmPromoCompDetailId("40690111");
		modifiedPromoItemEntities.add(modifiedPromoItemEntity);
		modifiedPromoItemEntities.add(promoItemEntitySecond);

		Map<Object, Object> argumentData = new HashMap<>();
		argumentData.put("existingPromoItemEntities", existingPromoItemEntities);
		argumentData.put("modifiedPromoItemEntities", modifiedPromoItemEntities);
	
		argumentData.put("promoMsgForZoneId", "12");
		argumentData.put("promoMsgLocType", "Z");
		argumentData.put("offerId", "31802215");
		Map<String, Object> promotionDetailsChangedOfferLevelEventMap = new HashMap<>();
		promotionDetailsChangedOfferLevelEventMap.put("31802215", argumentData);
		Map<String, Object> allEventsData = new HashMap<>();
		allEventsData.put(PROMOTION_DETAILS_CHANGED_PRODUCT_LEVEL_KEY, promotionDetailsChangedOfferLevelEventMap);
		
		promoEventHandler.processPromotionEvents(PriceConstants.PROMO_MSG_TYPE_MOD,"12","Z",allEventsData);
		Mockito.verify(eventTemplate, Mockito.times(1)).publishEvent(argument.capture());
		assertEquals(PriceConstants.PROMOTION_DETAILS_CHANGED_EVENT_TYPE,
				String.valueOf((argument.getValue()).getHeaderData().get("EventType")));
		assertEquals(2, Integer.valueOf((argument.getValue()).getHeaderData().get("LeadTimeDays")).intValue());
		assertEquals("IE:Z:12", (argument.getValue()).getHeaderData().get(PriceConstants.LOCATION_ID));
		assertEquals("31802215", (argument.getValue()).getPayloadData().get(PriceConstants.OFFER_ID));
		assertEquals("tpnb:063165054", (argument.getValue()).getPayloadData().get(PriceConstants.PROD_REF));
	}
	
	@Test
	public void shouldSendPromotionDetailsChangedProductLevelBothWasPriceChangedEventSimplePromotion()
			throws PromotionEventException, ParseException, EventPublishException {
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, +(2));
		String effectiveDate = dateFormat.format(cal.getTime());
		String formattedEffDate = Dockyard.getISO8601FormatStartDate(effectiveDate);
		
		List<PromoItemEntity> existingPromoItemEntities = new ArrayList<>();
		PromoItemEntity promoItemEntity = new PromoItemEntity();
		promoItemEntity.effectiveDate = formattedEffDate;
		promoItemEntity.endDate = formattedEffDate;
		promoItemEntity.itemType = PriceConstants.PROMO_ITEM_TYPE;
		promoItemEntity.itemRef = "063165054";
		promoItemEntity.setWasPrice("0.29");
		promoItemEntity.setWasWasPrice("1.29");
		promoItemEntity.setPosLabelReqInd(PriceConstants.POS_LABEL_Y);
		promoItemEntity.setRpmPromoCompDetailId("40690111");
		existingPromoItemEntities.add(promoItemEntity);
		
		PromoItemEntity promoItemEntitySecond = new PromoItemEntity();
		promoItemEntitySecond.effectiveDate = formattedEffDate;
		promoItemEntitySecond.endDate = formattedEffDate;
		promoItemEntitySecond.itemType = PriceConstants.PROMO_ITEM_TYPE;
		promoItemEntitySecond.itemRef = "064727108";
		promoItemEntitySecond.setWasPrice("1");
		promoItemEntitySecond.setWasWasPrice("2");
		promoItemEntitySecond.setPosLabelReqInd(PriceConstants.POS_LABEL_Y);
		promoItemEntitySecond.setRpmPromoCompDetailId("40690222");
		existingPromoItemEntities.add(promoItemEntitySecond);
		
		List<PromoItemEntity> modifiedPromoItemEntities = new ArrayList<>();
		PromoItemEntity modifiedPromoItemEntity = new PromoItemEntity();
		modifiedPromoItemEntity.effectiveDate = formattedEffDate;
		modifiedPromoItemEntity.endDate = formattedEffDate;
		modifiedPromoItemEntity.itemType = PriceConstants.PROMO_ITEM_TYPE;
		modifiedPromoItemEntity.itemRef = "063165054";
		modifiedPromoItemEntity.setWasPrice("0.19");
		modifiedPromoItemEntity.setWasWasPrice("1.09");
		modifiedPromoItemEntity.setPosLabelReqInd(PriceConstants.POS_LABEL_Y);
		modifiedPromoItemEntity.setRpmPromoCompDetailId("40690111");
		modifiedPromoItemEntities.add(modifiedPromoItemEntity);
		modifiedPromoItemEntities.add(promoItemEntitySecond);

		Map<Object, Object> argumentData = new HashMap<>();
		argumentData.put("existingPromoItemEntities", existingPromoItemEntities);
		argumentData.put("modifiedPromoItemEntities", modifiedPromoItemEntities);
	
		argumentData.put("promoMsgForZoneId", "12");
		argumentData.put("promoMsgLocType", "Z");
		argumentData.put("offerId", "31802215");
		Map<String, Object> promotionDetailsChangedOfferLevelEventMap = new HashMap<>();
		promotionDetailsChangedOfferLevelEventMap.put("31802215", argumentData);
		Map<String, Object> allEventsData = new HashMap<>();
		allEventsData.put(PROMOTION_DETAILS_CHANGED_PRODUCT_LEVEL_KEY, promotionDetailsChangedOfferLevelEventMap);
		
		promoEventHandler.processPromotionEvents(PriceConstants.PROMO_MSG_TYPE_MOD,"12","Z",allEventsData);
		Mockito.verify(eventTemplate, Mockito.times(1)).publishEvent(argument.capture());
		assertEquals(PriceConstants.PROMOTION_DETAILS_CHANGED_EVENT_TYPE,
				String.valueOf((argument.getValue()).getHeaderData().get("EventType")));
		assertEquals(2, Integer.valueOf((argument.getValue()).getHeaderData().get("LeadTimeDays")).intValue());
		assertEquals("IE:Z:12", (argument.getValue()).getHeaderData().get(PriceConstants.LOCATION_ID));
		assertEquals("31802215", (argument.getValue()).getPayloadData().get(PriceConstants.OFFER_ID));
		assertEquals("tpnb:063165054", (argument.getValue()).getPayloadData().get(PriceConstants.PROD_REF));
	}
	
	@Test
	public void shouldSendPromotionCreatedEventForPublishing() throws PromotionEventException, EventPublishException {

		Map<String, Object> allEventsData = prepareEventDataMapForPromotionOrLocationOrProductAdded(
				PROMOTION_MSG_TYPE_CRE);
		promoEventHandler.processPromotionEvents("PRMPRCCHGCRE", "12", "Z", allEventsData);
		Mockito.verify(eventTemplate, Mockito.times(1)).publishEvent(argument.capture());
		assertEquals("IE:Z:12", (argument.getValue()).getHeaderData().get(LOCATION_ID));
		assertEquals(PROMOTION_MSG_TYPE_CRE, String.valueOf((argument.getValue()).getHeaderData().get("EventType")));
		assertEquals("31757666", (argument.getValue()).getPayloadData().get(OFFER_ID));
		assertEquals(5, Integer.valueOf((argument.getValue()).getHeaderData().get("LeadTimeDays")).intValue());
	}

	@Test
	public void shouldSendPromotionLocationAddedEventForPublishing()
			throws PromotionEventException, EventPublishException {

		Map<String, Object> allEventsData = prepareEventDataMapForPromotionOrLocationOrProductAdded(
				PriceConstants.PROMO_LOC_ADDED);
		promoEventHandler.processPromotionEvents("PRMPRCCHGCRE", "12", "Z", allEventsData);
		Mockito.verify(eventTemplate, Mockito.times(1)).publishEvent(argument.capture());
		assertEquals("IE:Z:12", (argument.getValue()).getHeaderData().get(LOCATION_ID));
		assertEquals(PROMO_LOC_ADDED, String.valueOf((argument.getValue()).getHeaderData().get("EventType")));
		assertEquals("31757666", (argument.getValue()).getPayloadData().get(OFFER_ID));
		assertEquals(5, Integer.valueOf((argument.getValue()).getHeaderData().get("LeadTimeDays")).intValue());
	}

	@Test
	public void shouldSendPromotionProductAddedEventForPublishing()
			throws PromotionEventException, EventPublishException {

		Map<String, Object> allEventsData = prepareEventDataMapForPromotionOrLocationOrProductAdded(
				PriceConstants.PROMO_PRODUCT_ADDED);
		promoEventHandler.processPromotionEvents("PRMPRCCHGCRE", "12", "Z", allEventsData);
		Mockito.verify(eventTemplate, Mockito.times(1)).publishEvent(argument.capture());
		assertEquals("IE:Z:12", (argument.getValue()).getHeaderData().get(LOCATION_ID));
		assertEquals(PriceConstants.PROMO_PRODUCT_ADDED,
				String.valueOf((argument.getValue()).getHeaderData().get("EventType")));
		assertEquals("31757666", (argument.getValue()).getPayloadData().get(OFFER_ID));
		assertEquals(5, Integer.valueOf((argument.getValue()).getHeaderData().get("LeadTimeDays")).intValue());
	}
	
	@Test
	public void shouldSendPromotionEndDateChangedEventForPublishing()
			throws ParseException, PromotionEventException, EventPublishException {
		Map<String, String> promotionEndDateChangedEventMap = new HashMap<>();
		Map<String, Object> allEventsData = new HashMap<>();
		Map<String, Object> mapForOffferIdData = new HashMap<>();

		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, +(2));
		String effectiveDate = dateFormat.format(cal.getTime());
		String formattedEffDate = Dockyard.getISO8601FormatStartDate(effectiveDate);

		promotionEndDateChangedEventMap.put("endDate", new DateTime(formattedEffDate + ".000+01:00").toString());
		promotionEndDateChangedEventMap.put(PROD_REF, "tpnb:062299496");
		promotionEndDateChangedEventMap.put(OFFER_ID, "31802215");
		mapForOffferIdData.put("31802215", promotionEndDateChangedEventMap);
		allEventsData.put(PROMOTION_ENDDATE_CHANGED, mapForOffferIdData);

		promoEventHandler.processPromotionEvents(PriceConstants.PROMO_MSG_TYPE_MOD, "12", "Z", allEventsData);
		Mockito.verify(eventTemplate, Mockito.times(1)).publishEvent(argument.capture());
		assertEquals(PROMOTION_ENDDATE_CHANGED,
				String.valueOf((argument.getValue()).getHeaderData().get("EventType")));
		assertEquals(2, Integer.valueOf((argument.getValue()).getHeaderData().get("LeadTimeDays")).intValue());
		assertEquals("IE:Z:12", (argument.getValue()).getHeaderData().get(PriceConstants.LOCATION_ID));
		assertEquals("31802215", (argument.getValue()).getPayloadData().get(PriceConstants.OFFER_ID));

	}

	private Map<String, Object> prepareEventDataMapForPromotionOrLocationOrProductAdded(String eventType) {

		Map<String, Object> allEventsDataMap = new HashMap<>();
		Map<String, Object> eventsData = new HashMap<>();
		Map<String, String> productMap = new HashMap<>();
		eventsData.put(EVENT_TYPE, eventType);
		eventsData.put(EFFECTIVE_DATE, effectiveDate);
		eventsData.put(OFFER_ID, "31757666");
		if (eventType.equals(PROMO_PRODUCT_ADDED)) {

			productMap.put("056574421", effectiveDate);
			eventsData.put(PROMO_PRODUCT_ITEM_LIST, productMap);
		}
		allEventsDataMap.put(PROMOTION_CREATED_LOCATION_ADDED_PRODUCT_ADDED_KEY, eventsData);
		return allEventsDataMap;
	}
	
	@Test
	public void shouldSendPromotionDeletionEventForPublishing() throws PromotionEventException, EventPublishException {

		Map<String, Object> allEventsDataMap = new HashMap<>();
		Map<String, Object> eventsData = new HashMap<>();
		eventsData.put("31423485", effectiveDate);
		allEventsDataMap.put("PromotionDeleted", eventsData);
		promoEventHandler.processPromotionEvents("PRMPRCCHGDEL", "12", "Z", allEventsDataMap);
		Mockito.verify(eventTemplate, Mockito.times(1)).publishEvent(argument.capture());
		assertEquals("IE:Z:12", (argument.getValue()).getHeaderData().get(LOCATION_ID));
		assertEquals("PromotionDeleted", String.valueOf((argument.getValue()).getHeaderData().get("EventType")));
		assertEquals("31423485", (argument.getValue()).getPayloadData().get(OFFER_ID));
		assertEquals(5, Integer.valueOf((argument.getValue()).getHeaderData().get("LeadTimeDays")).intValue());
	}

	@Test
	public void shouldSendPromotionLocationRemovedEventForPublishing()
			throws PromotionEventException, EventPublishException {

		Map<String, Object> allEventsDataMap = new HashMap<>();
		Map<String, Object> eventsData = new HashMap<>();
		eventsData.put("29111553", effectiveDate);
		allEventsDataMap.put("PromotionLocationRemoved", eventsData);
		promoEventHandler.processPromotionEvents("PRMPRCCHGDEL", "12", "Z", allEventsDataMap);
		Mockito.verify(eventTemplate, Mockito.times(1)).publishEvent(argument.capture());
		assertEquals("IE:Z:12", (argument.getValue()).getHeaderData().get(LOCATION_ID));
		assertEquals("PromotionLocationRemoved",
				String.valueOf((argument.getValue()).getHeaderData().get("EventType")));
		assertEquals("29111553", (argument.getValue()).getPayloadData().get(OFFER_ID));
		assertEquals(5, Integer.valueOf((argument.getValue()).getHeaderData().get("LeadTimeDays")).intValue());
	}

	@Test
	public void shouldSendPromotionProductRemovedEventForPublishing()
			throws PromotionEventException, EventPublishException {

		Map<String, Object> allEventsDataMap = new HashMap<>();
		Map<String, Object> eventsData = new HashMap<>();
		List itemList = new ArrayList<>();
		itemList.add(effectiveDate + "|tpnb:050014015");
		eventsData.put("29111553", itemList);
		allEventsDataMap.put("PromotionProductRemoved", eventsData);
		promoEventHandler.processPromotionEvents("PRMPRCCHGDEL", "12", "Z", allEventsDataMap);
		Mockito.verify(eventTemplate, Mockito.times(1)).publishEvent(argument.capture());
		assertEquals("IE:Z:12", (argument.getValue()).getHeaderData().get(LOCATION_ID));
		assertEquals("PromotionProductRemoved", String.valueOf((argument.getValue()).getHeaderData().get("EventType")));
		assertEquals("29111553", (argument.getValue()).getPayloadData().get(OFFER_ID));
		assertEquals(5, Integer.valueOf((argument.getValue()).getHeaderData().get("LeadTimeDays")).intValue());
	}
	
}
