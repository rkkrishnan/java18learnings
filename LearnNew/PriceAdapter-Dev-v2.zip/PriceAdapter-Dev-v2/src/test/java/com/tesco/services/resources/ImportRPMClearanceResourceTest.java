package com.tesco.services.resources;

import com.tesco.couchbase.AsyncCouchbaseWrapper;
import com.tesco.couchbase.CouchbaseWrapper;
import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.Import;
import com.tesco.services.adapters.core.ImportRPMClearanceJob;
import com.tesco.services.repositories.CouchbaseConnectionManager;
import io.dropwizard.testing.junit.ResourceTestRule;
import org.junit.After;
import org.junit.Before;
import org.junit.ClassRule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.IOException;

import static org.fest.assertions.api.Assertions.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class ImportRPMClearanceResourceTest {


	private static Configuration testConfiguration = Mockito.mock(TestConfiguration.class);

	private static Import mockImportRPMClearanceJob = Mockito.mock(ImportRPMClearanceJob.class);

	@Before
	public void setUpResources() throws Exception {

		Mockito.doNothing().when(mockImportRPMClearanceJob).run();

		String[] runTypes = { "acayg", "emernonranged", "emerranged",
				"regnonranged", "regranged", "onetime" };

		Mockito.doReturn(runTypes).when(testConfiguration).getRpmClrTypes();
		Mockito.doReturn("/test/").when(testConfiguration)
				.getRpmClrDataDumpPath();
		Mockito.doReturn("cre.txt").when(testConfiguration)
				.getRpmClrCreFileName();
		Mockito.doReturn("mod.txt").when(testConfiguration)
				.getRpmClrModFileName();
		Mockito.doReturn("del.txt").when(testConfiguration)
				.getRpmClrDelFileName();

		ImportResource.getImportSemaphore().release();

	}

	@ClassRule
	public static final ResourceTestRule resources = ResourceTestRule.builder()
			.addResource(new ImportResource(testConfiguration, null, null,
					mockImportRPMClearanceJob, null, null, null, null, null,
					null, null, null)).build();

	@Test
	public void shouldStartRPMClearanceImportScript() throws IOException {
		WebTarget resource = resources.client().target("/admin/importRPMClearance/acayg");
		Response response = resource.request().accept(MediaType.APPLICATION_JSON).post(Entity.entity("", MediaType.APPLICATION_JSON));
		String responseText = response.readEntity(String.class);

		assertThat(responseText).isEqualTo(
				"{\"message\":\"Import RPM Clearance Job Started.\"}");
		assertThat(response.getStatus()).isEqualTo(200);
	}

	@Test
	public void shouldRPMClearanceImportScriptThrowException()
			throws IOException {
		WebTarget resource = resources.client().target("/admin/importRPMClearance/acayg1");
		Response response = resource.request().accept(MediaType.APPLICATION_JSON).post(Entity.entity("", MediaType.APPLICATION_JSON));

		assertThat(response.getStatus()).isEqualTo(400);
	}

	@After
	public void resetMocks() throws Exception {
		Mockito.reset(mockImportRPMClearanceJob);
		Mockito.reset(testConfiguration);
	}

}
