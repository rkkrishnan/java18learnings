package com.tesco.services.adapters.promotion;

import static io.dropwizard.testing.FixtureHelpers.fixture;
import static org.fest.assertions.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;

import com.tesco.services.adapters.promotion.impl.MultiBuyPromotionHandler;
import com.tesco.services.adapters.promotion.impl.SimplePromotionHandler;
import com.tesco.services.adapters.promotion.impl.ThresholdPromotionHandler;
import com.tesco.services.repositories.RepositoryImpl;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.glassfish.hk2.api.ServiceLocator;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.xml.sax.SAXException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tesco.couchbase.AsyncCouchbaseWrapper;
import com.tesco.couchbase.CouchbaseWrapper;
import com.tesco.couchbase.testutils.AsyncCouchbaseWrapperStub;
import com.tesco.couchbase.testutils.BucketTool;
import com.tesco.couchbase.testutils.CouchbaseTestManager;
import com.tesco.couchbase.testutils.CouchbaseWrapperStub;
import com.tesco.promotion.core.PrmPrcChgDesc;
import com.tesco.promotion.core.PrmPrcChgDtl;
import com.tesco.services.adapters.rpm.readers.impl.PromotionMessageRouter;
import com.tesco.services.adapters.rpm.writers.impl.PromotionWriter;
import com.tesco.services.core.promotion.ProductOffersEntity;
import com.tesco.services.core.promotion.PromoItemEntity;
import com.tesco.services.core.promotion.PromoItemListEntity;
import com.tesco.services.core.promotion.PromotionEntity;
import com.tesco.services.core.promotion.PromotionMasterEntity;
import com.tesco.services.exceptions.DataAccessException;
import com.tesco.services.exceptions.MessageRouterException;
import com.tesco.services.exceptions.ProductEncodeException;
import com.tesco.services.exceptions.PromoBusinessException;
import com.tesco.services.resources.TestConfiguration;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.ParseMessageUtil;
import com.tesco.services.utility.PriceConstants;

@RunWith(MockitoJUnitRunner.class)
public class SimplePromotionHandlerTest {
	TestConfiguration testConfiguration = null;

	RepositoryImpl repositoryImpl;
	SimplePromotionHandler simplePromotionHandler;
	ThresholdPromotionHandler thresholdPromotionHandler;
	MultiBuyPromotionHandler multiBuyPromotionHandler;
	String promoMsgType;
	PrmPrcChgDesc promotions;
	PromotionMessageRouter promotionMessageRouter;
	PromotionWriter promotionWriter;
	@Mock
	public CouchbaseWrapper couchbaseWrapper;
	@Mock
	public AsyncCouchbaseWrapper asyncCouchbaseWrapper;
	@Mock
	public ServiceLocator serviceLocator;

	@Mock
	private PromotionEventHandler promoEventHandler;

	ObjectMapper mapper;
	@Mock
	private CouchbaseTestManager couchbaseTestManager;
	PromotionEntity actualPromotionEntity;

	@Before
	public void setUp() throws Exception {
		testConfiguration = TestConfiguration.load();
		mapper = new ObjectMapper();
		if (testConfiguration.isDummyCouchbaseMode()) {
			Map<String, ImmutablePair<Long, String>> fakeBase = new HashMap<>();
			couchbaseTestManager = new CouchbaseTestManager(
					new CouchbaseWrapperStub(fakeBase),
					new AsyncCouchbaseWrapperStub(fakeBase),
					mock(BucketTool.class));
		} else {
			couchbaseTestManager = new CouchbaseTestManager(
					testConfiguration.getCouchbaseBucket(),
					testConfiguration.getCouchbaseUsername(),
					testConfiguration.getCouchbasePassword(),
					testConfiguration.getCouchbaseNodes(),
					testConfiguration.getCouchbaseAdminUsername(),

					testConfiguration.getCouchbaseAdminPassword());
		}
		couchbaseWrapper = couchbaseTestManager.getCouchbaseWrapper();
		asyncCouchbaseWrapper = couchbaseTestManager.getAsyncCouchbaseWrapper();

		repositoryImpl = new RepositoryImpl(couchbaseWrapper,
				asyncCouchbaseWrapper, mapper);

		// promotionWriter = Mockito.mock(PromotionWriter.class);
		promotionWriter = new PromotionWriter(testConfiguration,
				repositoryImpl, mapper);
		promoEventHandler = Mockito.mock(PromotionEventHandler.class);
		simplePromotionHandler = new SimplePromotionHandler(repositoryImpl,
				promotionWriter);
		promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promoEventHandler);

		String xmlData = fixture("com/tesco/services/core/fixtures/promotion/SimpleCreMessage.xml");
		ParseMessageUtil parseMessageUtil = ParseMessageUtil.getInstance();
		promoMsgType = parseMessageUtil.getNodeData(xmlData,
				PriceConstants.PROMO_MSG_TYPE_PATH);
		String messagePublishDate = parseMessageUtil.getNodeData(xmlData,
				PriceConstants.PROMO_MSG_PUBLISH_DATE_PATH);
		String promoDescData = parseMessageUtil.getNodeData(xmlData,
				PriceConstants.PROMO_MSG_DATA_PATH);
		promotions = (PrmPrcChgDesc) parseMessageUtil
				.getMappedObjectForXmlData(PrmPrcChgDesc.class, promoDescData);

	}

	@After
	public void tearDown() throws Exception {

	}

	@Test
	public void processCreMessageTest() throws IOException, ParseException,
			PromoBusinessException, DataAccessException {

		String prodItem = "071104000";
		ProductOffersEntity productOffersEntity;

		actualPromotionEntity = null;
		String promoMsgForZoneId = promotions.getTslZoneId().toString();
		String promoMsgLocType = promotions.getLocType();
		String promoMsgOfferType = null;
		String promoMsgState = null;
		ObjectMapper o = new ObjectMapper();
		for (PrmPrcChgDtl prmPrcChgDtl : promotions.getPrmPrcChgDtl()) {
			if (Dockyard.isSpaceOrNull(promoMsgOfferType)
					&& Dockyard.isSpaceOrNull(promoMsgState)) {
				promoMsgOfferType = promotionMessageRouter
						.getOfferTypeForDetail(prmPrcChgDtl);
				promoMsgState = promotionMessageRouter
						.getPromoStateForDetail(prmPrcChgDtl.getTslState());
			}
			if (PriceConstants.PROMO_SIMPLE_OFFER_TYPE
					.equals(promoMsgOfferType)) {

				simplePromotionHandler.processCreMessage(null,
						promotions.getPrmPrcChgDtl(), promoMsgForZoneId,
						promoMsgState, promoMsgOfferType, promoMsgLocType);

			}
			break;
		}

		String promotionEntityString = fixture("com/tesco/services/core/fixtures/promotion/SimplePromotionExpectedEntity.json");
		PromotionEntity promotionEntity = o.readValue(promotionEntityString,
				PromotionEntity.class);
		promotionEntity.createdDate = Dockyard
				.getSysDate(PriceConstants.ISO_8601_FORMAT);
		promotionEntity.lastUpdateDate = Dockyard
				.getSysDate(PriceConstants.ISO_8601_FORMAT);

		for (PromoItemListEntity promoItemListEntity : promotionEntity
				.getPromoItemListEntities()) {
			if (promoItemListEntity.getPromoItems() != null) {
				for (PromoItemEntity promoItemEntity : promoItemListEntity
						.getPromoItems()) {
					promoItemEntity.setEffectiveDate(Dockyard.getFormattedDate(
							promoItemEntity.getEffectiveDate(),
							PriceConstants.ISO_8601_FORMAT,
							PriceConstants.ISO_8601_FORMAT));
					promoItemEntity.setEndDate(Dockyard.getFormattedDate(
							promoItemEntity.getEndDate(),
							PriceConstants.ISO_8601_FORMAT,
							PriceConstants.ISO_8601_FORMAT));

				}
			}
		}

		PromotionEntity actualPromotionEntity = (PromotionEntity) repositoryImpl
				.getGenericObject(
						PriceConstants.PROMOTION_DOC_KEY_PREFIX
								+ promotionEntity.getOfferRef() + "_"
								+ promotionEntity.getLocType()
								+ promotionEntity.getLocRef(),
						PromotionEntity.class);
		for (PromoItemListEntity promoItemListEntity : actualPromotionEntity
				.getPromoItemListEntities()) {
			if (promoItemListEntity.getListType().equals(
					PriceConstants.PROMO_ITEM_LIST_BUY_TYPE)) {
				for (PromoItemEntity promoItemEntity : promoItemListEntity
						.getPromoItems()) {
					promoItemEntity.setEffectiveDate(Dockyard.getFormattedDate(
							promoItemEntity.getEffectiveDate(),
							PriceConstants.ISO_8601_FORMAT,
							PriceConstants.ISO_8601_FORMAT));
					promoItemEntity.setEndDate(Dockyard.getFormattedDate(
							promoItemEntity.getEndDate(),
							PriceConstants.ISO_8601_FORMAT,
							PriceConstants.ISO_8601_FORMAT));

				}
			}
		}
		assertThat(makeDateNull(actualPromotionEntity).toString()).isEqualTo(
				makeDateNull(promotionEntity).toString());

		productOffersEntity = (ProductOffersEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROD_OFFERS + prodItem
						+ "_Z13", ProductOffersEntity.class);
		Assert.assertTrue(productOffersEntity != null);
		Assert.assertTrue(validateProdOfferDocForCreAndMod(productOffersEntity,
				promotionEntity));

		// System.out.println(o.writeValueAsString(simplePromotionHandler.getPromotionEntityMap()));

	}

	@Test
	public void processCreMessageTestWhenPosLabelIsNull() throws IOException,
			ParseException, PromoBusinessException, XPathExpressionException,
			SAXException, ParserConfigurationException, JAXBException,
			DataAccessException {

		String prodItem = "071104000";
		ProductOffersEntity productOffersEntity;

		actualPromotionEntity = null;
		String xmlData = fixture("com/tesco/services/core/fixtures/promotion/SimpleCreMessageWithoutPos.xml");
		ParseMessageUtil parseMessageUtil = ParseMessageUtil.getInstance();
		promoMsgType = parseMessageUtil.getNodeData(xmlData,
				PriceConstants.PROMO_MSG_TYPE_PATH);
		String messagePublishDate = parseMessageUtil.getNodeData(xmlData,
				PriceConstants.PROMO_MSG_PUBLISH_DATE_PATH);
		String promoDescData = parseMessageUtil.getNodeData(xmlData,
				PriceConstants.PROMO_MSG_DATA_PATH);
		promotions = (PrmPrcChgDesc) parseMessageUtil
				.getMappedObjectForXmlData(PrmPrcChgDesc.class, promoDescData);
		String promoMsgForZoneId = promotions.getTslZoneId().toString();
		String promoMsgLocType = promotions.getLocType();
		String promoMsgOfferType = null;
		String promoMsgState = null;
		ObjectMapper o = new ObjectMapper();
		for (PrmPrcChgDtl prmPrcChgDtl : promotions.getPrmPrcChgDtl()) {
			if (Dockyard.isSpaceOrNull(promoMsgOfferType)
					&& Dockyard.isSpaceOrNull(promoMsgState)) {
				promoMsgOfferType = promotionMessageRouter
						.getOfferTypeForDetail(prmPrcChgDtl);
				promoMsgState = promotionMessageRouter
						.getPromoStateForDetail(prmPrcChgDtl.getTslState());
			}
			if (PriceConstants.PROMO_SIMPLE_OFFER_TYPE
					.equals(promoMsgOfferType)) {

				simplePromotionHandler.processCreMessage(null,
						promotions.getPrmPrcChgDtl(), promoMsgForZoneId,
						promoMsgState, promoMsgOfferType, promoMsgLocType);

			}
			break;
		}

		String promotionEntityString = fixture("com/tesco/services/core/fixtures/promotion/SimplePromotionExpectedEntityForPosNull.json");
		PromotionEntity promotionEntity = o.readValue(promotionEntityString,
				PromotionEntity.class);
		promotionEntity.createdDate = Dockyard
				.getSysDate(PriceConstants.ISO_8601_FORMAT);
		promotionEntity.lastUpdateDate = Dockyard
				.getSysDate(PriceConstants.ISO_8601_FORMAT);

		for (PromoItemListEntity promoItemListEntity : promotionEntity
				.getPromoItemListEntities()) {
			if (promoItemListEntity.getPromoItems() != null) {
				for (PromoItemEntity promoItemEntity : promoItemListEntity
						.getPromoItems()) {
					promoItemEntity.setEffectiveDate(Dockyard.getFormattedDate(
							promoItemEntity.getEffectiveDate(),
							PriceConstants.ISO_8601_FORMAT,
							PriceConstants.ISO_8601_FORMAT));
					promoItemEntity.setEndDate(Dockyard.getFormattedDate(
							promoItemEntity.getEndDate(),
							PriceConstants.ISO_8601_FORMAT,
							PriceConstants.ISO_8601_FORMAT));
				}
			}
		}

		PromotionEntity actualPromotionEntity = (PromotionEntity) repositoryImpl
				.getGenericObject(
						PriceConstants.PROMOTION_DOC_KEY_PREFIX
								+ promotionEntity.getOfferRef() + "_"
								+ promotionEntity.getLocType()
								+ promotionEntity.getLocRef(),
						PromotionEntity.class);
		for (PromoItemListEntity promoItemListEntity : actualPromotionEntity
				.getPromoItemListEntities()) {
			if (promoItemListEntity.getListType().equals(
					PriceConstants.PROMO_ITEM_LIST_BUY_TYPE)) {
				for (PromoItemEntity promoItemEntity : promoItemListEntity
						.getPromoItems()) {
					promoItemEntity.setEffectiveDate(Dockyard.getFormattedDate(
							promoItemEntity.getEffectiveDate(),
							PriceConstants.ISO_8601_FORMAT,
							PriceConstants.ISO_8601_FORMAT));
					promoItemEntity.setEndDate(Dockyard.getFormattedDate(
							promoItemEntity.getEndDate(),
							PriceConstants.ISO_8601_FORMAT,
							PriceConstants.ISO_8601_FORMAT));

				}
			}
		}
		assertThat(makeDateNull(actualPromotionEntity).toString()).isEqualTo(
				makeDateNull(promotionEntity).toString());

		productOffersEntity = (ProductOffersEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROD_OFFERS + prodItem
						+ "_Z13", ProductOffersEntity.class);
		Assert.assertTrue(productOffersEntity != null);
		Assert.assertTrue(validateProdOfferDocForCreAndMod(productOffersEntity,
				promotionEntity));

		// System.out.println(o.writeValueAsString(simplePromotionHandler.getPromotionEntityMap()));
		// System.out.println(o.writeValueAsString(simplePromotionHandler.getPromotionEntityMap()));
	}

	@Test
	public void testProcessSimpleModNewItemAdditionPromotionsMasterDocShouldnotChangeFromMsg()
			throws IOException, PromoBusinessException, ProductEncodeException,
			MessageRouterException, DataAccessException {

		String offerIdFromMsg = "31802215";
		String locType = "Z";
		String locRef = "5";

		String masterKey = PriceConstants.PROMOTION_DOC_KEY_PREFIX
				+ offerIdFromMsg;
		String key = PriceConstants.PROMOTION_DOC_KEY_PREFIX + offerIdFromMsg
				+ "_" + locType + locRef;

		deleteDocs(masterKey, key, null, null);

		String credata = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.08.25 14:26:13.719|237</ribmessageID>\n"
				+ "<publishTime>2015-08-25 14:26:13.719 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690111&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802215&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;063165054&lt;/item&gt;&lt;tsl_consumer_unit&gt;259661056&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;014685527&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;0.29&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;1.29&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.28&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690222&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802215&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;064727108&lt;/item&gt;&lt;tsl_consumer_unit&gt;265389479&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;016407285&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;1&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;2&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.99&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promoEventHandler);
		promotionMessageRouter.route(credata);

		PromotionMasterEntity promotionMasterEntity = (PromotionMasterEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg, PromotionMasterEntity.class);

		String modData = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.06.24 14:26:13.719|237</ribmessageID>\n"
				+ "<publishTime>2015-06-29 11:38:57.055 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP_Update1&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690555&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP_UPdate1&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802215&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;0647271968&lt;/item&gt;&lt;tsl_consumer_unit&gt;265389479&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;016407285&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;1&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;2&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.99&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP_Update1&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690666&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP_UPdate1&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802215&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;063165099&lt;/item&gt;&lt;tsl_consumer_unit&gt;259661056&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;014685527&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;0.29&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;1.29&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.28&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		PromotionMessageRouter promotionMessageRouterAfterMod = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promoEventHandler);

		promotionMessageRouterAfterMod.route(modData);

		PromotionMasterEntity promotionMasterEntityMod = (PromotionMasterEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg, PromotionMasterEntity.class);

		Assert.assertNotNull(promotionMasterEntityMod);
		Assert.assertEquals(promotionMasterEntityMod.toString(),
				promotionMasterEntity.toString());
		Assert.assertEquals(promotionMasterEntityMod.getLastUpdateDate(),
				promotionMasterEntity.getLastUpdateDate());
		deleteDocs(masterKey, key, null, null);
	}

	@Test
	public void testProcessSimpleModItemCancellationMasterDocShouldnotChangeFromMsg()
			throws IOException, PromoBusinessException, ProductEncodeException,
			MessageRouterException, DataAccessException {

		String offerIdFromMsg = "31802215";
		String locType = "Z";
		String locRef = "5";

		String masterKey = PriceConstants.PROMOTION_DOC_KEY_PREFIX
				+ offerIdFromMsg;
		String key = PriceConstants.PROMOTION_DOC_KEY_PREFIX + offerIdFromMsg
				+ "_" + locType + locRef;

		deleteDocs(masterKey, key, null, null);

		String credata = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.08.25 14:26:13.719|237</ribmessageID>\n"
				+ "<publishTime>2015-08-25 14:26:13.719 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690111&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802215&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;063165054&lt;/item&gt;&lt;tsl_consumer_unit&gt;259661056&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;014685527&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;0.29&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;1.29&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.28&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690222&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802215&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;064727108&lt;/item&gt;&lt;tsl_consumer_unit&gt;265389479&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;016407285&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;1&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;2&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.99&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promoEventHandler);
		promotionMessageRouter.route(credata);

		PromotionMasterEntity promotionMasterEntity = (PromotionMasterEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg, PromotionMasterEntity.class);

		String modData = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.06.24 14:26:13.719|237</ribmessageID>\n"
				+ "<publishTime>2015-06-29 11:38:57.055 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP_Update1&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690111&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;14&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.cancelled&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP_UPdate1&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802215&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;063165054&lt;/item&gt;&lt;tsl_consumer_unit&gt;265389479&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;016407285&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;1&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;2&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.99&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP_Update1&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690222&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;14&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.cancelled&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP_UPdate1&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802215&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;064727108&lt;/item&gt;&lt;tsl_consumer_unit&gt;259661056&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;014685527&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;0.29&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;1.29&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.28&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		PromotionMessageRouter promotionMessageRouterAfterMod = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promoEventHandler);

		promotionMessageRouterAfterMod.route(modData);

		PromotionMasterEntity promotionMasterEntityMod = (PromotionMasterEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg, PromotionMasterEntity.class);

		Assert.assertNotNull(promotionMasterEntityMod);
		Assert.assertEquals(promotionMasterEntityMod.toString(),
				promotionMasterEntity.toString());
		Assert.assertEquals(promotionMasterEntityMod.getLastUpdateDate(),
				promotionMasterEntity.getLastUpdateDate());

		deleteDocs(masterKey, key, null, null);

	}

	@Test
	public void testProcessSimpleModDescReawardPromotionsMasterDocShouldnotChangeFromMsg()
			throws IOException, PromoBusinessException, ProductEncodeException,
			MessageRouterException, DataAccessException {
		String offerIdFromMsg = "31802215";
		String locType = "Z";
		String locRef = "5";

		String masterKey = PriceConstants.PROMOTION_DOC_KEY_PREFIX
				+ offerIdFromMsg;
		String key = PriceConstants.PROMOTION_DOC_KEY_PREFIX + offerIdFromMsg
				+ "_" + locType + locRef;

		deleteDocs(masterKey, key, null, null);

		String credata = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.08.25 14:26:13.719|237</ribmessageID>\n"
				+ "<publishTime>2015-08-25 14:26:13.719 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690111&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802215&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;063165054&lt;/item&gt;&lt;tsl_consumer_unit&gt;259661056&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;014685527&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;0.29&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;1.29&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.28&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690222&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802215&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;064727108&lt;/item&gt;&lt;tsl_consumer_unit&gt;265389479&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;016407285&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;1&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;2&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.99&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promoEventHandler);
		promotionMessageRouter.route(credata);

		PromotionMasterEntity promotionMasterEntity = (PromotionMasterEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg, PromotionMasterEntity.class);

		String modData = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGMOD</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.06.24 14:26:13.719|237</ribmessageID>\n"
				+ "<publishTime>2015-06-29 11:38:57.055 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP_Update1&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690111&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.reapproved&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP_UPdate1&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802215&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;064727108&lt;/item&gt;&lt;tsl_consumer_unit&gt;265389479&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;016407285&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;1&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;2&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.99&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP_Update1&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690222&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.reapproved&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP_UPdate1&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802215&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;063165054&lt;/item&gt;&lt;tsl_consumer_unit&gt;259661056&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;014685527&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;0.29&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;1.29&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.28&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		PromotionMessageRouter promotionMessageRouterAfterMod = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promoEventHandler);

		promotionMessageRouterAfterMod.route(modData);

		PromotionMasterEntity promotionMasterEntityMod = (PromotionMasterEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg, PromotionMasterEntity.class);

		Assert.assertNotNull(promotionMasterEntityMod);
		Assert.assertEquals(promotionMasterEntityMod.getLastUpdateDate()
				.toString(), promotionMasterEntity.getLastUpdateDate()
				.toString());
		deleteDocs(masterKey, key, null, null);
	}

	@Test
	public void testProcessSimplePromotionsZoneAdditionMasterDocShouldChangeFromMsg()
			throws IOException, PromoBusinessException, ProductEncodeException,
			MessageRouterException, DataAccessException {

		String offerIdFromMsg = "31802215";
		String locType = "Z";
		String locRef = "5";
		String locRef1 = "6";

		String masterKey = PriceConstants.PROMOTION_DOC_KEY_PREFIX
				+ offerIdFromMsg;
		String key = PriceConstants.PROMOTION_DOC_KEY_PREFIX + offerIdFromMsg
				+ "_" + locType + locRef;
		String key1 = PriceConstants.PROMOTION_DOC_KEY_PREFIX + offerIdFromMsg
				+ "_" + locType + locRef1;

		deleteDocs(masterKey, key, null, null);
		deleteDocs(masterKey, key1, null, null);

		String credata = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.08.25 14:26:13.719|237</ribmessageID>\n"
				+ "<publishTime>2015-08-25 14:26:13.719 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690111&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802215&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;063165054&lt;/item&gt;&lt;tsl_consumer_unit&gt;259661056&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;014685527&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;0.29&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;1.29&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.28&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690222&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802215&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;064727108&lt;/item&gt;&lt;tsl_consumer_unit&gt;265389479&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;016407285&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;1&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;2&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.99&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promoEventHandler);
		promotionMessageRouter.route(credata);

		PromotionMasterEntity promotionMasterEntity = (PromotionMasterEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg, PromotionMasterEntity.class);

		String creDataNextZone = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.06.24 14:26:13.719|237</ribmessageID>\n"
				+ "<publishTime>2015-06-29 11:38:57.055 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;6&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;6&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690131&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802215&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;063165054&lt;/item&gt;&lt;tsl_consumer_unit&gt;259661056&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;014685527&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;0.29&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;1.29&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.28&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690121&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802215&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;064727108&lt;/item&gt;&lt;tsl_consumer_unit&gt;265389479&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;016407285&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;1&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;2&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.99&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		PromotionMessageRouter promotionMessageRouterAfterMod = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promoEventHandler);

		promotionMessageRouterAfterMod.route(creDataNextZone);

		PromotionMasterEntity promotionMasterEntityMod = (PromotionMasterEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg, PromotionMasterEntity.class);

		Assert.assertNotNull(promotionMasterEntityMod);
		Assert.assertNotSame(promotionMasterEntityMod.toString(),
				promotionMasterEntity.toString());
		Assert.assertNotSame(promotionMasterEntityMod.getLastUpdateDate(),
				promotionMasterEntity.getLastUpdateDate());
	}

	@Test
	public void testProcessSimplePromotionsZoneDeletionMasterDocShouldChangeFromMsg()
			throws IOException, PromoBusinessException, ProductEncodeException,
			MessageRouterException, DataAccessException {

		String offerIdFromMsg = "31802215";
		String locType = "Z";
		String locRef = "5";
		String delItem = "064727108";
		String zoneId = "Z6";
		String promoCompDisplayId = "31802215";
		String masterKey = PriceConstants.PROMOTION_DOC_KEY_PREFIX
				+ offerIdFromMsg;
		String key = PriceConstants.PROMOTION_DOC_KEY_PREFIX + offerIdFromMsg
				+ "_" + locType + locRef;

		deleteDocs(masterKey, key, null, null);

		String credata = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.08.25 14:26:13.719|237</ribmessageID>\n"
				+ "<publishTime>2015-08-25 14:26:13.719 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690111&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802215&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;063165054&lt;/item&gt;&lt;tsl_consumer_unit&gt;259661056&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;014685527&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;0.29&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;1.29&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.28&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690222&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802215&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;064727108&lt;/item&gt;&lt;tsl_consumer_unit&gt;265389479&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;016407285&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;1&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;2&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.99&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promoEventHandler);

		promotionMessageRouter.route(credata);

		String creDatanextZone = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.06.24 14:26:13.719|237</ribmessageID>\n"
				+ "<publishTime>2015-06-29 11:38:57.055 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;6&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;6&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228216&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690121&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802215&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;064727108&lt;/item&gt;&lt;tsl_consumer_unit&gt;265389479&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;016407285&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;1&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;2&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.99&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		promotionMessageRouter.route(creDatanextZone);

		PromotionMasterEntity promotionMasterEntity = (PromotionMasterEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg, PromotionMasterEntity.class);

		String delData = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGDEL</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.06.24 14:26:13.719|237</ribmessageID>\n"
				+ "<publishTime>2015-06-29 11:38:57.055 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgRef&gt;&lt;location&gt;6&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;6&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtlRef&gt;&lt;promo_comp_detail_id&gt;40690121&lt;/promo_comp_detail_id&gt;&lt;tsl_promo_comp_id&gt;228216&lt;/tsl_promo_comp_id&gt;&lt;tsl_state&gt;pcd.deleted&lt;/tsl_state&gt;&lt;PrmPrcChgSmpDtlRef&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;064727108&lt;/item&gt;&lt;tsl_consumer_unit&gt;255490379&lt;/tsl_consumer_unit&gt;&lt;/PrmPrcChgSmpDtlRef&gt;&lt;/PrmPrcChgDtlRef&gt;&lt;/PrmPrcChgRef&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		promotionMessageRouter.route(delData);

		PromotionMasterEntity promotionMasterEntityDel = (PromotionMasterEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg, PromotionMasterEntity.class);
		Assert.assertNotNull(promotionMasterEntityDel);
		Assert.assertNotSame(promotionMasterEntityDel.toString(),
				promotionMasterEntity.toString());
		Assert.assertNotSame(promotionMasterEntityDel.getLastUpdateDate()
				.toString(), promotionMasterEntity.getLastUpdateDate()
				.toString());

	}

	/**
	 * When we create the PromotionEntity doc, we set the createdDate &
	 * lastUpdateDate with Current date. So it's not possible to compare the
	 * exact date value between actual & expected JSON
	 * 
	 * @param promotionEntity
	 * @return
	 */
	private PromotionEntity makeDateNull(PromotionEntity promotionEntity) {
		promotionEntity.createdDate = null;
		promotionEntity.lastUpdateDate = null;

		if (promotionEntity.getPromoItemListEntities() != null) {
			for (PromoItemListEntity promoItemListEntity : promotionEntity
					.getPromoItemListEntities()) {
				if (promoItemListEntity.getPromoItems() != null) {
					for (PromoItemEntity promoItemEntity : promoItemListEntity
							.getPromoItems()) {
						promoItemEntity.setEffectiveDate(null);
						promoItemEntity.setEndDate(null);
					}
				}

			}
		}

		return promotionEntity;
	}

	public void deleteDocs(String masterKey, String key, List compDtlIds,
			List hierkeys) {
		if (!Dockyard.isSpaceOrNull(masterKey)) {
			repositoryImpl.deleteProduct(masterKey);
		}
		repositoryImpl.deleteProduct(key);

		if (!Dockyard.isSpaceOrNull(compDtlIds)) {
			Iterator it = compDtlIds.iterator();
			while (it.hasNext()) {
				String dtlId = it.next().toString();
				repositoryImpl.deleteProduct(dtlId);
			}
		}
		if (!Dockyard.isSpaceOrNull(compDtlIds)) {
			Iterator it1 = hierkeys.iterator();
			while (it1.hasNext()) {
				String hierkey = it1.next().toString();
				repositoryImpl.deleteProduct(hierkey);
			}
		}

	}

	private boolean validateProdOfferDocForCreAndMod(
			ProductOffersEntity productOffersEntity,
			PromotionEntity actualPromotionEntity) {

		List<PromoItemListEntity> promoItemListEntities;
		promoItemListEntities = actualPromotionEntity
				.getPromoItemListEntities();
		List<String> prodOfferItems = new ArrayList<>();

		for (PromoItemListEntity promoItemListEntity : promoItemListEntities) {

			if (PriceConstants.PROMO_ITEM_LIST_BUY_TYPE
					.equals(promoItemListEntity.getListType())) {
				List<PromoItemEntity> promoItems = promoItemListEntity
						.getPromoItems();
				for (PromoItemEntity promoItemEntity : promoItems) {
					prodOfferItems.add(promoItemEntity.getItemRef());
				}
			}

		}

		if (prodOfferItems.contains(productOffersEntity.getTpnb())
				&& productOffersEntity.getProductOffersPromotionMap().keySet()
						.contains(actualPromotionEntity.getOfferRef())) {
			return true;
		}

		return false;
	}

	private boolean validateProdOfferDocForDel(String item, String zoneId,
			String promoCompDisplayId) throws PromoBusinessException {
		String prodKey = PriceConstants.PROD_OFFERS + item + "_" + zoneId;
		ProductOffersEntity productOffersEntity;

		try {
			productOffersEntity = (ProductOffersEntity) repositoryImpl
					.getGenericObject(prodKey, ProductOffersEntity.class);
			if (productOffersEntity == null) {
				return true;
			} else {
				if (!productOffersEntity.getProductOffersPromotionMap()
						.keySet().contains(promoCompDisplayId)) {
					return true;
				}
			}
		} catch (Exception e) {
			throw new PromoBusinessException(e);
		}

		return false;
	}

}
