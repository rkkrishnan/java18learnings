package com.tesco.services.adapters.core.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.codahale.metrics.Counter;
import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.Timer;

/**
 * Created by vagrant on 6/13/2016.
 */
public class PriceMetricsTest {

	PriceMetrics priceMetrics = null;
	MetricRegistry mmetricsRegistry = null;
	Map metricsMap = null;

	@Before
	public void setUp() throws Exception {
		priceMetrics = PriceMetrics.getInstance();
		mmetricsRegistry = PriceMetrics.getMetricRegisty();
	}

	@After
	public void tearDown() throws Exception {

	}

	@Test
	public void logCrePriceProcessingStartTime() throws Exception {
		String name = MetricRegistry.name("com.tesco",
				"PriceElapsedTimeAndRate", "time-to-process-cre-message");

		priceMetrics.logCrePriceProcessingStartTime();
		priceMetrics.logCrePriceProcessingEndTime();

		metricsMap = mmetricsRegistry.getTimers();
		assertNotEquals(0, ((Timer) metricsMap.get(name)).getCount());
	}

	@Test
	public void logDelPriceProcessingStartTime() throws Exception {
		String name = MetricRegistry.name("com.tesco",
				"PriceElapsedTimeAndRate", "time-to-process-del-message");

		priceMetrics.logDelPriceProcessingStartTime();
		priceMetrics.logDelPriceProcessingEndTime();

		metricsMap = mmetricsRegistry.getTimers();
		assertNotEquals(0, ((Timer) metricsMap.get(name)).getCount());
	}

	@Test
	public void logMessageProcessingStartTime() throws Exception {
		String name = MetricRegistry.name("com.tesco",
				"OverallPriceElapsedTimeAndRate", "time-to-process-message");

		priceMetrics.logMessageProcessingStartTime();
		priceMetrics.logMessageProcessingEndTime();

		metricsMap = mmetricsRegistry.getTimers();
		assertNotEquals(0, ((Timer) metricsMap.get(name)).getCount());
	}

	@Ignore
	public void incrementErrorCount() throws Exception {
		String name = MetricRegistry.name("com.tesco",
				"PriceMessageProcessingErrors", "total-error-count");
		priceMetrics.incrementErrorCount();
		metricsMap = priceMetrics.getMetricRegisty().getCounters();
		assertEquals(1, ((Counter) metricsMap.get(name)).getCount());
		priceMetrics.resetMetrics();
		metricsMap = priceMetrics.getMetricRegisty().getCounters();
		assertEquals(0, ((Counter) metricsMap.get(name)).getCount());
	}

}