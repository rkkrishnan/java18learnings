package com.tesco.services.adapters.price;

import static io.dropwizard.testing.FixtureHelpers.fixture;
import static org.fest.assertions.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

import java.io.IOException;
import java.io.StringReader;
import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import com.tesco.services.repositories.RepositoryImpl;

import org.apache.commons.lang3.tuple.ImmutablePair;
import org.assertj.core.api.Assertions;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tesco.couchbase.AsyncCouchbaseWrapper;
import com.tesco.couchbase.CouchbaseWrapper;
import com.tesco.couchbase.testutils.AsyncCouchbaseWrapperStub;
import com.tesco.couchbase.testutils.BucketTool;
import com.tesco.couchbase.testutils.CouchbaseTestManager;
import com.tesco.couchbase.testutils.CouchbaseWrapperStub;
import com.tesco.price.core.RegPrcChgDesc;
import com.tesco.price.core.RegPrcChgRef;
import com.tesco.services.adapters.price.impl.PriceHandlerImpl;
import com.tesco.services.adapters.rpm.writers.impl.PriceWriter;
import com.tesco.services.core.price.PriceByDateTime;
import com.tesco.services.core.price.PriceEntity;
import com.tesco.services.core.price.ProductVariant;
import com.tesco.services.exceptions.DataAccessException;
import com.tesco.services.exceptions.PriceBusinessException;
import com.tesco.services.resources.TestConfiguration;
import com.tesco.services.utility.PriceConstants;

@RunWith(MockitoJUnitRunner.class)
public class PriceHandlerTest {
	RepositoryImpl repositoryImpl;
	@Mock
	public CouchbaseWrapper couchbaseWrapper;
	@Mock
	public AsyncCouchbaseWrapper asyncCouchbaseWrapper;

	ObjectMapper mapper;
	@Mock
	private CouchbaseTestManager couchbaseTestManager;
	TestConfiguration testConfiguration = null;
	PriceWriter priceWriter;
	PriceHandler priceHandler;

	@Before
	public void setUp() throws Exception {
		testConfiguration = TestConfiguration.load();
		mapper = new ObjectMapper();
		if (testConfiguration.isDummyCouchbaseMode()) {
			Map<String, ImmutablePair<Long, String>> fakeBase = new HashMap<>();
			couchbaseTestManager = new CouchbaseTestManager(
					new CouchbaseWrapperStub(fakeBase),
					new AsyncCouchbaseWrapperStub(fakeBase),
					mock(BucketTool.class));
		} else {
			couchbaseTestManager = new CouchbaseTestManager(
					testConfiguration.getCouchbaseBucket(),
					testConfiguration.getCouchbaseUsername(),
					testConfiguration.getCouchbasePassword(),
					testConfiguration.getCouchbaseNodes(),
					testConfiguration.getCouchbaseAdminUsername(),
					testConfiguration.getCouchbaseAdminPassword());
		}
		couchbaseWrapper = couchbaseTestManager.getCouchbaseWrapper();
		asyncCouchbaseWrapper = couchbaseTestManager.getAsyncCouchbaseWrapper();
		repositoryImpl = new RepositoryImpl(couchbaseWrapper,
				asyncCouchbaseWrapper, mapper);
		priceWriter = new PriceWriter(testConfiguration, mapper,
				repositoryImpl);
		priceHandler = new PriceHandlerImpl(priceWriter);
	}

	@After
	public void tearDown() throws Exception {

	}

	@Test
	public void processCreMessage() throws JAXBException, IOException,
			PriceBusinessException, DataAccessException {
		String item5851 = "071075851";
		String item4058 = "073334058";
		String xmlData = fixture("com/tesco/services/core/fixtures/price/PriceCre.xml");

		StringReader priceObjectFromXml = new StringReader(xmlData);
		JAXBContext jaxbContextForPromoDetail = JAXBContext
				.newInstance(RegPrcChgDesc.class);
		Unmarshaller unmarshallerPromoDetail = jaxbContextForPromoDetail
				.createUnmarshaller();
		RegPrcChgDesc regPrcChgDesc = (RegPrcChgDesc) unmarshallerPromoDetail
				.unmarshal(priceObjectFromXml);
		priceHandler.processCre(regPrcChgDesc);
		String locType = regPrcChgDesc.getLocType();
		String loc = String.valueOf(regPrcChgDesc.getLocation());

		String priceEntityString5851 = fixture("com/tesco/services/core/fixtures/price/REGPRICE_071075851_Z1.json");
		String priceEntityString4058 = fixture("com/tesco/services/core/fixtures/price/REGPRICE_073334058_Z1.json");

		assertThat(
				makeDateNull(
						(PriceEntity) repositoryImpl.getGenericObject(
								PriceConstants.PRICE_DOC_KEY_PREFIX
										.concat(item5851).concat("_")
										.concat(locType).concat(loc),
								PriceEntity.class)).toString()).isEqualTo(
				makeDateNull(
						mapper.readValue(priceEntityString5851,
								PriceEntity.class)).toString());

		assertThat(
				makeDateNull(
						(PriceEntity) repositoryImpl.getGenericObject(
								PriceConstants.PRICE_DOC_KEY_PREFIX
										.concat(item4058).concat("_")
										.concat(locType).concat(loc),
								PriceEntity.class)).toString()).isEqualTo(
				makeDateNull(
						mapper.readValue(priceEntityString4058,
								PriceEntity.class)).toString());
	}

	@Test
	public void processCreMessageWithVar() throws JAXBException, IOException,
			PriceBusinessException, DataAccessException {
		String item5851 = "071075851";
		String xmlData = fixture("com/tesco/services/core/fixtures/price/PriceCreWithVar.xml");

		StringReader priceObjectFromXml = new StringReader(xmlData);

		JAXBContext jaxbContextForPromoDetail = JAXBContext
				.newInstance(RegPrcChgDesc.class);
		Unmarshaller unmarshallerPromoDetail = jaxbContextForPromoDetail
				.createUnmarshaller();
		RegPrcChgDesc regPrcChgDesc = (RegPrcChgDesc) unmarshallerPromoDetail
				.unmarshal(priceObjectFromXml);
		priceHandler.processCre(regPrcChgDesc);
		String locType = regPrcChgDesc.getLocType();
		String loc = String.valueOf(regPrcChgDesc.getLocation());

		String priceEntityString5851 = fixture("com/tesco/services/core/fixtures/price/REGPRICE_073334058_Z1_Var.json");
		assertThat(
				makeDateNull(
						(PriceEntity) repositoryImpl.getGenericObject(
								PriceConstants.PRICE_DOC_KEY_PREFIX
										.concat(item5851).concat("_")
										.concat(locType).concat(loc),
								PriceEntity.class)).toString()).isEqualTo(
				makeDateNull(
						mapper.readValue(priceEntityString5851,
								PriceEntity.class)).toString());
	}

	@Test
	public void processDelMessageToDeleteSinglePriceChangeId()
			throws JAXBException, IOException, PriceBusinessException,
			DataAccessException {
		String item0016 = "050000016";
		String delItem0016 = "050000016";
		String xmlData = fixture("com/tesco/services/core/fixtures/price/PriceCreForDel.xml");
		String xmlDelData = fixture("com/tesco/services/core/fixtures/price/PriceDel.xml");
		StringReader priceObjectFromXml = new StringReader(xmlData);
		StringReader priceDelObjectFromXml = new StringReader(xmlDelData);
		JAXBContext jaxbContextForPromoDetail = JAXBContext
				.newInstance(RegPrcChgDesc.class);
		JAXBContext jaxbContextDel = JAXBContext
				.newInstance(RegPrcChgRef.class);
		Unmarshaller unmarshallerPromoDetail = jaxbContextForPromoDetail
				.createUnmarshaller();
		Unmarshaller unmarshallerDel = jaxbContextDel.createUnmarshaller();
		RegPrcChgDesc regPrcChgDesc = (RegPrcChgDesc) unmarshallerPromoDetail
				.unmarshal(priceObjectFromXml);
		RegPrcChgRef regPrcChgRef = (RegPrcChgRef) unmarshallerDel
				.unmarshal(priceDelObjectFromXml);
		priceHandler.processCre(regPrcChgDesc);
		String locType = regPrcChgDesc.getLocType();
		String loc = String.valueOf(regPrcChgDesc.getLocation());

		String priceEntityString0016 = fixture("com/tesco/services/core/fixtures/price/REGPRICE_050000016_Z1.json");
		// Added for PRIS-1133 Java 8 Migration
		PriceEntity expectedEntity = makeDateNull(mapper.readValue(
				priceEntityString0016, PriceEntity.class));
		PriceEntity actualEntity = makeDateNull((PriceEntity) repositoryImpl
				.getGenericObject(
						PriceConstants.PRICE_DOC_KEY_PREFIX.concat(item0016)
								.concat("_").concat(locType).concat(loc),
						PriceEntity.class));
		Assertions.assertThat(actualEntity)
				.isEqualToComparingFieldByFieldRecursively(expectedEntity);

		priceHandler.processDel(regPrcChgRef);
		String locTypeDel = regPrcChgRef.getLocType();
		String locRef = String.valueOf(regPrcChgRef.getLocation());

		String priceEntityAftDelString0016 = fixture("com/tesco/services/core/fixtures/price/REGPRICE_050000016_Z1_Expected.json");

		// Added for PRIS-1133 Java 8 Migration
		PriceEntity expectedPriceEntity = makeDateNull(mapper.readValue(
				priceEntityAftDelString0016, PriceEntity.class));
		PriceEntity actualPriceEntity = makeDateNull((PriceEntity) repositoryImpl
				.getGenericObject(
						PriceConstants.PRICE_DOC_KEY_PREFIX.concat(delItem0016)
								.concat("_").concat(locTypeDel).concat(locRef),
						PriceEntity.class));
		Assertions.assertThat(actualPriceEntity)
				.isEqualToComparingFieldByFieldRecursively(expectedPriceEntity);
	}

	@Test
	public void processDelMessageToDeletefullDoc() throws JAXBException,
			IOException, PriceBusinessException, DataAccessException {
		String item0016 = "050000016";
		String delItem0016 = "050000016";
		String xmlData = fixture("com/tesco/services/core/fixtures/price/PriceCreForDel.xml");
		String xmlDelData = fixture("com/tesco/services/core/fixtures/price/PriceDelCompletete.xml");
		StringReader priceObjectFromXml = new StringReader(xmlData);
		StringReader priceDelObjectFromXml = new StringReader(xmlDelData);
		JAXBContext jaxbContextForPromoDetail = JAXBContext
				.newInstance(RegPrcChgDesc.class);
		JAXBContext jaxbContextDel = JAXBContext
				.newInstance(RegPrcChgRef.class);
		Unmarshaller unmarshallerPromoDetail = jaxbContextForPromoDetail
				.createUnmarshaller();

		Unmarshaller unmarshallerDel = jaxbContextDel.createUnmarshaller();
		RegPrcChgDesc regPrcChgDesc = (RegPrcChgDesc) unmarshallerPromoDetail
				.unmarshal(priceObjectFromXml);
		RegPrcChgRef regPrcChgRef = (RegPrcChgRef) unmarshallerDel
				.unmarshal(priceDelObjectFromXml);
		priceHandler.processCre(regPrcChgDesc);
		String locType = regPrcChgDesc.getLocType();
		String loc = String.valueOf(regPrcChgDesc.getLocation());
		String priceEntityString0016 = fixture("com/tesco/services/core/fixtures/price/REGPRICE_050000016_Z1.json");

		// Added for PRIS-1133 Java 8 Migration
		PriceEntity expectedEntity = makeDateNull(mapper.readValue(
				priceEntityString0016, PriceEntity.class));
		PriceEntity actualEntity = makeDateNull((PriceEntity) repositoryImpl
				.getGenericObject(
						PriceConstants.PRICE_DOC_KEY_PREFIX.concat(item0016)
								.concat("_").concat(locType).concat(loc),
						PriceEntity.class));
		Assertions.assertThat(actualEntity)
				.isEqualToComparingFieldByFieldRecursively(expectedEntity);

		priceHandler.processDel(regPrcChgRef);
		String locTypeDel = regPrcChgRef.getLocType();
		String locRef = String.valueOf(regPrcChgRef.getLocation());
		assertThat(
				(PriceEntity) repositoryImpl.getGenericObject(
						PriceConstants.PRICE_DOC_KEY_PREFIX.concat(delItem0016)
								.concat("_").concat(locTypeDel).concat(locRef),
						PriceEntity.class)).isNull();
	}

	@Test
	public void processDelMessageToDeleteMultiplePriceChangeId()
			throws JAXBException, IOException, PriceBusinessException,
			DataAccessException {
		String item0016 = "050000016";
		String delItem0016 = "050000016";
		String xmlData = fixture("com/tesco/services/core/fixtures/price/PriceCreForDel.xml");
		String xmlDelData = fixture("com/tesco/services/core/fixtures/price/PriceDelMultiDelete.xml");

		StringReader priceObjectFromXml = new StringReader(xmlData);
		StringReader priceDelObjectFromXml = new StringReader(xmlDelData);
		JAXBContext jaxbContextForPromoDetail = JAXBContext
				.newInstance(RegPrcChgDesc.class);
		JAXBContext jaxbContextDel = JAXBContext
				.newInstance(RegPrcChgRef.class);
		Unmarshaller unmarshallerPromoDetail = jaxbContextForPromoDetail
				.createUnmarshaller();
		Unmarshaller unmarshallerDel = jaxbContextDel.createUnmarshaller();
		RegPrcChgDesc regPrcChgDesc = (RegPrcChgDesc) unmarshallerPromoDetail
				.unmarshal(priceObjectFromXml);
		RegPrcChgRef regPrcChgRef = (RegPrcChgRef) unmarshallerDel
				.unmarshal(priceDelObjectFromXml);
		priceHandler.processCre(regPrcChgDesc);
		String locType = regPrcChgDesc.getLocType();
		String loc = String.valueOf(regPrcChgDesc.getLocation());
		String priceEntityString0016 = fixture("com/tesco/services/core/fixtures/price/REGPRICE_050000016_Z1.json");

		// Added for PRIS-1133 Java 8 Migration
		PriceEntity expectedEntity = makeDateNull(mapper.readValue(
				priceEntityString0016, PriceEntity.class));
		PriceEntity actualEntity = makeDateNull((PriceEntity) repositoryImpl
				.getGenericObject(
						PriceConstants.PRICE_DOC_KEY_PREFIX.concat(item0016)
								.concat("_").concat(locType).concat(loc),
						PriceEntity.class));
		Assertions.assertThat(actualEntity)
				.isEqualToComparingFieldByFieldRecursively(expectedEntity);

		priceHandler.processDel(regPrcChgRef);
		String locTypeDel = regPrcChgRef.getLocType();
		String locRef = String.valueOf(regPrcChgRef.getLocation());
		String priceEntityAftDelString0016 = fixture("com/tesco/services/core/fixtures/price/REGPRICE_050000016_Z1_MultiDeleteExpected.json");

		// Added for PRIS-1133 Java 8 Migration
		PriceEntity expectedPriceEntity = makeDateNull(mapper.readValue(
				priceEntityAftDelString0016, PriceEntity.class));
		PriceEntity actualPriceEntity = makeDateNull((PriceEntity) repositoryImpl
				.getGenericObject(
						PriceConstants.PRICE_DOC_KEY_PREFIX.concat(delItem0016)
								.concat("_").concat(locTypeDel).concat(locRef),
						PriceEntity.class));
		Assertions.assertThat(actualPriceEntity)
				.isEqualToComparingFieldByFieldRecursively(expectedPriceEntity);
	}

	@Test
	public void processDelMessageToDeleteMultiplePriceChangeIdButDetailNotFound()
			throws JAXBException, IOException, PriceBusinessException,
			DataAccessException {
		String item0016 = "050000016";
		String delItem0016 = "050000016";
		String xmlData = fixture("com/tesco/services/core/fixtures/price/PriceCreForDel.xml");
		String xmlDelData = fixture("com/tesco/services/core/fixtures/price/PriceDelWhenDtlNotFoundInDoc.xml");

		StringReader priceObjectFromXml = new StringReader(xmlData);
		StringReader priceDelObjectFromXml = new StringReader(xmlDelData);
		JAXBContext jaxbContextForPromoDetail = JAXBContext
				.newInstance(RegPrcChgDesc.class);
		JAXBContext jaxbContextDel = JAXBContext
				.newInstance(RegPrcChgRef.class);
		Unmarshaller unmarshallerPromoDetail = jaxbContextForPromoDetail
				.createUnmarshaller();
		Unmarshaller unmarshallerDel = jaxbContextDel.createUnmarshaller();
		RegPrcChgDesc regPrcChgDesc = (RegPrcChgDesc) unmarshallerPromoDetail
				.unmarshal(priceObjectFromXml);
		RegPrcChgRef regPrcChgRef = (RegPrcChgRef) unmarshallerDel
				.unmarshal(priceDelObjectFromXml);
		priceHandler.processCre(regPrcChgDesc);
		String locType = regPrcChgDesc.getLocType();
		String loc = String.valueOf(regPrcChgDesc.getLocation());
		String priceEntityString0016 = fixture("com/tesco/services/core/fixtures/price/REGPRICE_050000016_Z1.json");

		// Added for PRIS-1133 Java 8 Migration
		PriceEntity expectedEntity = makeDateNull(mapper.readValue(
				priceEntityString0016, PriceEntity.class));
		PriceEntity actualEntity = makeDateNull((PriceEntity) repositoryImpl
				.getGenericObject(
						PriceConstants.PRICE_DOC_KEY_PREFIX.concat(item0016)
								.concat("_").concat(locType).concat(loc),
						PriceEntity.class));
		Assertions.assertThat(actualEntity)
				.isEqualToComparingFieldByFieldRecursively(expectedEntity);

		priceHandler.processDel(regPrcChgRef);
		String locTypeDel = regPrcChgRef.getLocType();
		String locRef = String.valueOf(regPrcChgRef.getLocation());

		// Added for PRIS-1133 Java 8 Migration
		PriceEntity expectedPriceEntity = makeDateNull(mapper.readValue(
				priceEntityString0016, PriceEntity.class));
		PriceEntity actualPriceEntity = makeDateNull((PriceEntity) repositoryImpl
				.getGenericObject(
						PriceConstants.PRICE_DOC_KEY_PREFIX.concat(delItem0016)
								.concat("_").concat(locTypeDel).concat(locRef),
						PriceEntity.class));
		Assertions.assertThat(actualPriceEntity)
				.isEqualToComparingFieldByFieldRecursively(expectedPriceEntity);
	}

	@Test
	public void processDelMessageToDeleteWithoutAnydata() throws JAXBException,
			IOException, PriceBusinessException, DataAccessException {
		String delItem0016 = "050000016";

		String xmlDelData = fixture("com/tesco/services/core/fixtures/price/PriceDelMultiDelete.xml");

		StringReader priceDelObjectFromXml = new StringReader(xmlDelData);
		JAXBContext jaxbContextForPromoDetail = JAXBContext
				.newInstance(RegPrcChgDesc.class);
		JAXBContext jaxbContextDel = JAXBContext
				.newInstance(RegPrcChgRef.class);
		Unmarshaller unmarshallerDel = jaxbContextDel.createUnmarshaller();
		RegPrcChgRef regPrcChgRef = (RegPrcChgRef) unmarshallerDel
				.unmarshal(priceDelObjectFromXml);

		priceHandler.processDel(regPrcChgRef);
		String locTypeDel = regPrcChgRef.getLocType();
		String locRef = String.valueOf(regPrcChgRef.getLocation());

		assertThat(
				repositoryImpl.getGenericObject(
						PriceConstants.PRICE_DOC_KEY_PREFIX.concat(delItem0016)
								.concat("_").concat(locTypeDel).concat(locRef),
						PriceEntity.class)).isNull();
	}

	private PriceEntity makeDateNull(PriceEntity priceEntity) {
		priceEntity.setLastUpdateDate(null);

		if (priceEntity.getTpncToProductVariant() != null) {
			for (ProductVariant productVariant : priceEntity
					.getTpncToProductVariant().values()) {
				if (productVariant.getEffectiveDate() != null) {
					for (PriceByDateTime priceByDateTime : productVariant
							.getEffectiveDate().values()) {
						priceByDateTime.setLastUpdateDate(null);
						priceByDateTime.setCreatedDate(null);
						priceByDateTime.setEffvDateTime(null);
					}
				}

			}
		}

		return priceEntity;
	}

}
