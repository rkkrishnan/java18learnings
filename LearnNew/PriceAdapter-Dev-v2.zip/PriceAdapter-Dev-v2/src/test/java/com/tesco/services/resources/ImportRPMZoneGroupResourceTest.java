package com.tesco.services.resources;

import com.tesco.couchbase.AsyncCouchbaseWrapper;
import com.tesco.couchbase.CouchbaseWrapper;
import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.Import;
import com.tesco.services.adapters.core.ImportRPMZoneGroupJob;
import io.dropwizard.testing.junit.ResourceTestRule;
import org.junit.After;
import org.junit.Before;
import org.junit.ClassRule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.IOException;

import static org.fest.assertions.api.Assertions.assertThat;

/**
 * Created by QP65 on 11/6/2015.
 */
@RunWith(MockitoJUnitRunner.class)
public class ImportRPMZoneGroupResourceTest {


	private static Configuration testConfiguration = Mockito.mock(TestConfiguration.class);

	private static Import importRPMZoneGroupJob = Mockito.mock(ImportRPMZoneGroupJob.class);

	@Before
	public void setUpResources() throws Exception {

		Mockito.doNothing().when(importRPMZoneGroupJob).run();
		String runType = "rpmzonegrouponetime";

		Mockito.doReturn(runType).when(testConfiguration).getRpmZoneDataDump();
		if(ImportResource.getImportSemaphoreForIdentifier("fileName")!=null){
			ImportResource.getImportSemaphoreForIdentifier("fileName").release();
		}
	}

	@ClassRule
	public static final ResourceTestRule resources = ResourceTestRule.builder()
			.addResource(new ImportResource(testConfiguration, null, null, null,
					null, null, null, null, importRPMZoneGroupJob, null, null,
					null)).build();

	@Test
	public void shouldStartRPMZoneGroupImportScript() throws IOException {

		WebTarget resource = resources.client().target("/admin/importRPMZoneGroup/rpmzonegrouponetime/fileName");
		Response response = resource.request().accept(MediaType.APPLICATION_JSON).post(Entity.entity("", MediaType.APPLICATION_JSON));
		String responseText = response.readEntity(String.class);

		assertThat(responseText).isEqualTo(
				"{\"message\":\"Import RPM Onetime Zone Group load Job Started.\"}");
		assertThat(response.getStatus()).isEqualTo(200);
	}

	@Test
	public void shouldRPMZoneImportScriptThrowException() throws IOException {
		WebTarget resource = resources.client().target("/admin/importRPMZoneGroup/invalidRunType/filename");
		Response response = resource.request().accept(MediaType.APPLICATION_JSON).post(Entity.entity("", MediaType.APPLICATION_JSON));

		assertThat(response.getStatus()).isEqualTo(400);
	}

	@After
	public void resetMocks() throws Exception {
		Mockito.reset(importRPMZoneGroupJob);
		Mockito.reset(testConfiguration);
	}
}
