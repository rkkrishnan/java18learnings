package com.tesco.services.resources;

import com.couchbase.client.CouchbaseClient;
import com.couchbase.client.protocol.views.DesignDocument;
import com.couchbase.client.protocol.views.InvalidViewException;
import com.couchbase.client.protocol.views.ViewDesign;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tesco.services.Configuration;
import com.tesco.services.core.Product;
import com.tesco.services.core.ProductVariant;
import com.tesco.services.core.SaleInfo;
import com.tesco.services.repositories.RepositoryImpl;
import io.dropwizard.testing.junit.ResourceTestRule;
import org.junit.ClassRule;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import static org.fest.assertions.api.Assertions.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class ItemPurgeResourceTest {

    @Mock
    private Configuration mockConfiguration;

    @Mock
    private static Configuration testConfiguration = TestConfiguration.load();

    @Mock
    private static CouchbaseClient couchbaseClient;
    @Mock
    private static RepositoryImpl repositoryImpl;

    @ClassRule
    public static final ResourceTestRule resources = ResourceTestRule.builder().addResource(
            new ItemPurgeResource(testConfiguration, couchbaseClient,
					repositoryImpl)).build();


    @Ignore
    @Test
    public void shouldStartItemPurge() throws Exception {
        System.out.println("Configuration HOST : " + testConfiguration
                .getCouchbaseNodes()[0]);
        System.out.println("Configuration Viewname : " + testConfiguration
                .getCouchBaseViewName());
        /*Added by Surya for View check to avoid Junit Failures - Start*/
        checkforView(couchbaseClient, testConfiguration);
        /*Added by Surya for View check to avoid Junit Failures - End*/
        buildAndInsertAProductToBePurged();
        WebTarget resource = resources.client().target("/itempurge/purge");
        Response response = resource.request()
                .accept(MediaType.APPLICATION_JSON)
                .post(Entity.entity("", MediaType.APPLICATION_JSON));
        String responseText = response.readEntity(String.class);

        assertThat(responseText).isEqualTo("{\"message\":\"Purge Completed\"}");
        assertThat(response.getStatus()).isEqualTo(200);
    }
   /*Added by Surya for View check to avoid Junit Failures - Start*/
        private void createView(Configuration configuration, CouchbaseClient couchbaseClient)throws Exception{

        final DesignDocument designDoc = new DesignDocument(configuration.getCouchBaseDesignDocName());
        designDoc.setView(new ViewDesign(configuration.getCouchBaseViewName(),
                "function (doc, meta) {\n" +
                        "  if (doc.last_updated_date && meta.type == \"json\" ) {\n" +
                        "    emit(doc.last_updated_date, {KEY: meta.id});\n" +
                        "  }\n" +
                        "}"
        ));

        couchbaseClient.createDesignDoc(designDoc);
    }
    public void checkforView(CouchbaseClient couchbaseClient, Configuration configuration) throws Exception {
        try {
             couchbaseClient.getView(configuration.getCouchBaseDesignDocName(), configuration.getCouchBaseViewName());
        }catch(InvalidViewException e){
            createView(configuration, couchbaseClient);
            Thread.sleep(50);
        }
    }
        /*Added by Surya for View check to avoid Junit Failures - End*/
    private void buildAndInsertAProductToBePurged() throws Exception{
        String tpnb = "056789123";
        String tpnc = "234567891";
        ObjectMapper mapper = new ObjectMapper();
        Product product = new Product(tpnb);
        ProductVariant productVariant = new ProductVariant(tpnc);
        productVariant.addSaleInfo(new SaleInfo(1,"2.00"));
        product.addProductVariant(productVariant);
        DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE,-(10));
        String lastUpdateDateTime=  dateFormat.format(cal.getTime());
        product.setLast_updated_date(lastUpdateDateTime);
        couchbaseClient.set("PRODUCT_" + product.getTPNB(), mapper.writeValueAsString(product));
        couchbaseClient.set(tpnb,mapper.writeValueAsString(tpnc));
        couchbaseClient.set(tpnc,mapper.writeValueAsString(tpnb));

    }
}
