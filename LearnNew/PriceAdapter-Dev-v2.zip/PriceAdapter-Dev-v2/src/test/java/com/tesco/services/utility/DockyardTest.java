package com.tesco.services.utility;

import junit.framework.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.io.BufferedWriter;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

/**
 * Created by Nibedita on 06/08/2014.
 */
@RunWith(MockitoJUnitRunner.class)
public class DockyardTest {
	@Test
	public void checkNull() {
		String val = " ";
		boolean flag;
		// Modified by Pallavi as part of code refactor
		if (val == null || val == "" || val == " ")
			flag = true;
		else
			flag = false;
		Assert.assertEquals(flag, Dockyard.isSpaceOrNull(val));
	}

	@Test
	public void checkPriceScaleRoundForGBP() {
		String price1 = "11.2";
		String currency = "GBP";
		String price2 = "11";
		String price3 = "11.209";
		String price4 = "11.99999";
		String actualPrice = "11.20";
		String actualPrice2 = "11.00";
		String actualPrice3 = "11.21";
		String actualPrice4 = "12.00";
		Assert.assertEquals(actualPrice,
				Dockyard.priceScaleRoundHalfUp(currency, price1));

		Assert.assertEquals(actualPrice2,
				Dockyard.priceScaleRoundHalfUp(currency, price2));

		Assert.assertEquals(actualPrice3,
				Dockyard.priceScaleRoundHalfUp(currency, price3));

		Assert.assertEquals(actualPrice4,
				Dockyard.priceScaleRoundHalfUp(currency, price4));
	}

	/**
	 * IQD Iraqi dinar Decimal places=3
	 */
	@Test
	public void checkPriceScaleRoundForIQD() {
		String price1 = "11.2";
		String currency = "IQD";
		String price2 = "11";
		String price3 = "11.209";
		String price4 = "11.99999";
		String actualPrice = "11.200";
		String actualPrice2 = "11.000";
		String actualPrice3 = "11.209";
		String actualPrice4 = "12.000";
		Assert.assertEquals(actualPrice,
				Dockyard.priceScaleRoundHalfUp(currency, price1));

		Assert.assertEquals(actualPrice2,
				Dockyard.priceScaleRoundHalfUp(currency, price2));

		Assert.assertEquals(actualPrice3,
				Dockyard.priceScaleRoundHalfUp(currency, price3));

		Assert.assertEquals(actualPrice4,
				Dockyard.priceScaleRoundHalfUp(currency, price4));
	}

	/**
	 * CLP Chile decimal places =0
	 */
	@Test
	public void checkPriceScaleRoundForCLP() {
		String price1 = "11.2";
		String currency = "CLP";
		String price2 = "11";
		String price3 = "11.209";
		String price4 = "11.99999";
		String actualPrice = "11";
		String actualPrice4 = "12";
		Assert.assertEquals(actualPrice,
				Dockyard.priceScaleRoundHalfUp(currency, price1));

		Assert.assertEquals(actualPrice,
				Dockyard.priceScaleRoundHalfUp(currency, price2));

		Assert.assertEquals(actualPrice,
				Dockyard.priceScaleRoundHalfUp(currency, price3));

		Assert.assertEquals(actualPrice4,
				Dockyard.priceScaleRoundHalfUp(currency, price4));
	}

	@Test
	public void checkISODateTimeFormatForStartDate() throws ParseException {
		SimpleDateFormat dateFormatFromFiles = new SimpleDateFormat("yyyyMMdd");
		String date = "20141117";
		SimpleDateFormat isodateformat = new SimpleDateFormat(
				"yyyy-MM-dd'T'HH:mm:ss");
		Date date1 = dateFormatFromFiles.parse(date);
		String newDate = isodateformat.format(date1);
		Assert.assertEquals(newDate, Dockyard.getISO8601FormatStartDate(date));
	}

	@Test
	public void checkISODateTimeFormatForEndDate() throws ParseException {
		SimpleDateFormat dateFormatFromFiles = new SimpleDateFormat(
				"yyyyMMdd HH:mm:ss");
		String date = "20141117";
		date = date + " 23:59:59";
		SimpleDateFormat isodateformat = new SimpleDateFormat(
				"yyyy-MM-dd'T'HH:mm:ss");
		Date date1 = dateFormatFromFiles.parse(date);
		String newDate = isodateformat.format(date1);
		Assert.assertEquals(newDate, Dockyard.getISO8601FormatEndDate(date));
	}

	@Test
	public void checkClearanceByDatetimeKey() throws ParseException {
		SimpleDateFormat dateFormatFromFiles = new SimpleDateFormat(
				"yyyy-MM-dd'T'HH:mm:ss");
		String date = "2014-11-17T00:00:00";
		SimpleDateFormat isodateformat = new SimpleDateFormat("yyyyMMddHHmmss");
		Date date1 = dateFormatFromFiles.parse(date);
		String newDate = isodateformat.format(date1);
		Assert.assertEquals(newDate,
				Dockyard.getClearanceByDateTimeKeyFormat(date));
	}

	@Test
	public void checkROIClrPriceFormat() {
		String price = "0000000.40";
		price = Dockyard.priceScaleRoundHalfUp("EU ", price);
		Assert.assertEquals("0.40", price);

	}

	@SuppressWarnings("deprecation")
	@Test
	public void testGetClearanceByDateTimeKeyFormatForRpmClr()
			throws ParseException {
		String dateFormatFromFiles = "2015-02-24T14:37:00";
		Assert.assertEquals(Dockyard
				.getClearanceByDateTimeKeyFormatForRpmClr(dateFormatFromFiles),
				"20150224143700");
	}

	@SuppressWarnings("deprecation")
	@Test
	public void testCheckActiveaClear() throws ParseException {
		String effdate = "2000-02-25T14:37:00";
		String enddate = "2000-02-26T14:37:00";
		boolean hasToBeFalse = Dockyard.checkActiveaClear(effdate, enddate);

		effdate = "2000-02-25T14:37:00";
		enddate = "2099-02-26T14:37:00";

		boolean hasToBeTrue = Dockyard.checkActiveaClear(effdate, enddate);
		boolean hasTestCasePassed = false;

		if (hasToBeFalse == false && hasToBeTrue == true) {
			hasTestCasePassed = true;
		}
		Assert.assertEquals(hasTestCasePassed, true);
	}

	@Test
	public void testLowestOfTwoNum() {

		assertThat("12").isEqualTo(Dockyard.lowestOfTwoNum("12", "12.1"));

		assertThat("12").isEqualTo(Dockyard.lowestOfTwoNum("12", ""));

		assertThat("12.1").isEqualTo(Dockyard.lowestOfTwoNum("", "12.1"));
	}

	@Test
	public void testGetBufferedWriter() {

		try {
			new Dockyard().getBufferedWriter(null);
		} catch (IOException e) {

		}

		try {
			new Dockyard().getBufferedWriter("dummy.txt");
		} catch (IOException e) {
			assertThat(e).hasNoCause();
		}

	}

	@Test
	public void testWriteProductDetailsToFile() throws IOException{

		Dockyard myDockyard = new  Dockyard();

		myDockyard.writeProductDetailsToFile(null,null);

		BufferedWriter mockBW = mock(BufferedWriter.class);

		Mockito.doNothing().when(mockBW).write(Matchers.anyString());
		Mockito.doNothing().when(mockBW).newLine();
		Mockito.doNothing().when(mockBW).flush();
		Mockito.doNothing().when(mockBW).close();

		myDockyard.setBufferedWriter(mockBW);

		Set<String> myProdSet = new HashSet<String>();
		myProdSet.add("12345");
		myProdSet.add("12346");

		myDockyard.writeProductDetailsToFile("dummy.txt",myProdSet);


		Mockito.doNothing().when(mockBW).write(Matchers.anyString());
		Mockito.doNothing().when(mockBW).newLine();
		Mockito.doNothing().when(mockBW).flush();
		Mockito.doThrow(new IOException()).when(mockBW).close();

		myDockyard.setBufferedWriter(mockBW);

		myDockyard.writeProductDetailsToFile("dummy.txt",myProdSet);

	}
    @Test
    public void DockyardTestLeftpadZero(){
    //checkleftpadzeroWhenInputStringsizeIsGreaterThenInputSize
        String retVal = Dockyard.leftPadZero("100",5);
        Assert.assertEquals("00100",retVal);
    //checkleftpadzeroWhenInputStringIsEqualToInputSize
         retVal = Dockyard.leftPadZero("50000",5);
        Assert.assertEquals("50000",retVal);
    //checkleftpadzeroWhenInputStringIsLessThanInputSize
         retVal = Dockyard.leftPadZero("50000", 3);
        Assert.assertEquals("50000", retVal);
    }
}
