package com.tesco.services.adapters.rpm.writers;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Optional;
import com.tesco.couchbase.AsyncCouchbaseWrapper;
import com.tesco.couchbase.CouchbaseWrapper;
import com.tesco.couchbase.testutils.AsyncCouchbaseWrapperStub;
import com.tesco.couchbase.testutils.BucketTool;
import com.tesco.couchbase.testutils.CouchbaseTestManager;
import com.tesco.couchbase.testutils.CouchbaseWrapperStub;
import com.tesco.services.Configuration;
import com.tesco.services.adapters.rpm.comparators.RPMComparator;
import com.tesco.services.adapters.rpm.events.impl.ClearanceEventData;
import com.tesco.services.adapters.rpm.events.ClearanceEventHandler;
import com.tesco.services.adapters.rpm.writers.impl.ClearanceProductMapper;
import com.tesco.services.adapters.rpm.writers.impl.MMWriter;
import com.tesco.services.core.*;
import com.tesco.services.repositories.RepositoryImpl;
import com.tesco.services.resources.ImportResource;
import com.tesco.services.resources.TestConfiguration;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.PriceConstants;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.assertj.core.api.Assertions;
import org.joda.time.DateTime;
import org.junit.*;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.io.*;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.Semaphore;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class MMWriterTest {
	public MMWriter mmWriter;
	@Mock
	public RepositoryImpl repositoryImpl;

	@Mock
	public AsyncCouchbaseWrapper asyncCouchbaseWrapper;

	@Mock
	public CouchbaseWrapper couchbaseWrapper;

	@Mock
	protected Configuration testConfiguration;

	@Mock
	private ObjectMapper mapper;

	@Mock
	protected BufferedReader mmClrFileReader;

	@Mock
	protected ClearanceProductMapper clearanceProductMapper;

	private ClearanceEventHandler clearanceEventHandler;

	@Mock
	FileWriter fileWriter;
	@Mock
	File mmClrFailedDatafile;
	@Mock
	BufferedReader mmClrFailedFileReader;

	@Mock
	FileReader fileReader;

	@Mock
	BufferedWriter bufferedWriter;

	@Mock
	private CouchbaseTestManager couchbaseTestManager;

	String currencyCode;
	String sellingUom = "EA";
	String runIdentifier = "mmreg";
	DateFormat dateFormat;
	Calendar cal;

	String eff_date1;
	String eff_date2;

	String end_date1;

	String end_date2;
	String eff_date3;
	String end_date3;

	@Before
	public void setUp() throws IOException, URISyntaxException,
			InterruptedException {

		testConfiguration = TestConfiguration.load();
		if (testConfiguration.isDummyCouchbaseMode()) {
			Map<String, ImmutablePair<Long, String>> fakeBase = new HashMap<>();
			couchbaseTestManager = new CouchbaseTestManager(
					new CouchbaseWrapperStub(fakeBase),
					new AsyncCouchbaseWrapperStub(fakeBase),
					mock(BucketTool.class));
		} else {
			couchbaseTestManager = new CouchbaseTestManager(
					testConfiguration.getCouchbaseBucket(),
					testConfiguration.getCouchbaseUsername(),
					testConfiguration.getCouchbasePassword(),
					testConfiguration.getCouchbaseNodes(),
					testConfiguration.getCouchbaseAdminUsername(),
					testConfiguration.getCouchbaseAdminPassword());
		}

		couchbaseWrapper = couchbaseTestManager.getCouchbaseWrapper();
		repositoryImpl = new RepositoryImpl(couchbaseWrapper,
				asyncCouchbaseWrapper, new ObjectMapper());
		clearanceProductMapper = new ClearanceProductMapper(repositoryImpl);
		clearanceEventHandler = Mockito.mock(ClearanceEventHandler.class);
		mmWriter = new MMWriter(testConfiguration, repositoryImpl,
				mmClrFileReader, clearanceEventHandler,clearanceProductMapper);

		ImportResource.importSemaphoreForIdentifier.put(runIdentifier,
				new Semaphore(1));
		mmWriter.setRunIdentifier(runIdentifier);
		when(mmClrFileReader.readLine()).thenReturn(null);

		dateFormat = new SimpleDateFormat("yyyyMMdd");
		cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 2);
		eff_date1 = dateFormat.format(cal.getTime());
		cal.add(Calendar.DATE, 20);
		end_date1 = dateFormat.format(cal.getTime());
		cal.add(Calendar.DATE, 10);
		eff_date2 = dateFormat.format(cal.getTime());
		cal.add(Calendar.DATE, 10);
		end_date2 = dateFormat.format(cal.getTime());
		cal.add(Calendar.DATE, 10);
		eff_date3 = dateFormat.format(cal.getTime());
		cal.add(Calendar.DATE, 10);
		end_date3 = dateFormat.format(cal.getTime());

	}

	@After
	public void tearDown() throws Exception {
		ImportResource.importSemaphoreForIdentifier.get(runIdentifier)
				.release();

	}

	@Test
	public void readAndWriteMMClrForUKNatAndStoreDataInserts() throws Exception {
		String line1 = "6075777636         " + eff_date1 + "NIGBP0000002.00MM"
				+ end_date1 + "HP20013";
		String line2 = "6075777636     2964" + eff_date1 + "SIGBP0000003.00MM"
				+ end_date1 + "HP20013";
		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "GBP";
		ConstructProductAndTpncMapping(productId, tpnc);
		when(mmClrFileReader.readLine()).thenReturn(line1).thenReturn(line2)
				.thenReturn(null);
		ClearanceByDateTime clearanceByDateTimeForNationalZone = createClearanceByDateTime(
				eff_date1, end_date1, "MM", "0000002.00");
		ClearanceByDateTime clearanceByDateTimeForStore = createClearanceByDateTime(
				eff_date1, end_date1, "MM", "0000003.00");
		ClearanceZoneSaleInfo clearanceZoneSaleInfo = createClearanceZoneSaleInfo(
				"20", "UK", "GBP", clearanceByDateTimeForNationalZone);
		ClearanceStoreSaleInfo clearanceStoreSaleInfo = createClearanceStoreSaleInfo(
				" 2964", "UK", "GBP", clearanceByDateTimeForStore);
		final ClearanceMMProduct expectedClearanceMMProduct = createClearanceMMProduct(
				productId, clearanceZoneSaleInfo, clearanceStoreSaleInfo);

		this.mmWriter.write(null);
		ClearanceMMProduct actualClearanceProduct = (ClearanceMMProduct) repositoryImpl
				.getGenericObject(PriceConstants.CLEARANCE_MM_PRODUCT_KEY_PREFIX+productId,ClearanceMMProduct.class);
		boolean isEqual = new RPMComparator().compare(actualClearanceProduct,
				expectedClearanceMMProduct);
		Assert.assertTrue(isEqual);
	}

	@Test
	public void readAndWriteMMClrForROINatAndStoreDataInserts()
			throws Exception {
		String line1 = "6075777636         " + eff_date1 + "NIEU 0000002.00MM"
				+ end_date1 + "HP20013";
		String line2 = "6075777636     2964" + eff_date1 + "SIEU 0000003.00MM"
				+ end_date1 + "HP20013";
		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "EUR";
		ConstructProductAndTpncMapping(productId, tpnc);
		when(mmClrFileReader.readLine()).thenReturn(line1).thenReturn(line2)
				.thenReturn(null);
		ClearanceByDateTime clearanceByDateTimeForNationalZone = createClearanceByDateTime(
				eff_date1, end_date1, "MM", "0000002.00");
		ClearanceByDateTime clearanceByDateTimeForStore = createClearanceByDateTime(
				eff_date1, end_date1, "MM", "0000003.00");
		ClearanceZoneSaleInfo clearanceZoneSaleInfo = createClearanceZoneSaleInfo(
				"21", "IE", "EUR", clearanceByDateTimeForNationalZone);
		ClearanceStoreSaleInfo clearanceStoreSaleInfo = createClearanceStoreSaleInfo(
				" 2964", "IE", "EUR", clearanceByDateTimeForStore);
		final ClearanceMMProduct expectedClearanceMMProduct = createClearanceMMProduct(
				productId, clearanceZoneSaleInfo, clearanceStoreSaleInfo);

		this.mmWriter.write(null);
		ClearanceMMProduct actualClearanceProduct = (ClearanceMMProduct) repositoryImpl
				.getGenericObject(PriceConstants.CLEARANCE_MM_PRODUCT_KEY_PREFIX
						+ productId, ClearanceMMProduct.class);
		boolean isEqual = new RPMComparator().compare(actualClearanceProduct,
				expectedClearanceMMProduct);
		Assert.assertTrue(isEqual);
	}

	@Test
	public void readAndWriteMMClrForUKNatDataDeletes() throws Exception {
		String line1 = "6075777636         20141013NIGBP0000002.00MM20141102HP20013";
		String line2 = "6075777636         20141013NDGBP0000002.00MM20141102HP20013";
		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "GBP";
		ConstructProductAndTpncMapping(productId, tpnc);
		when(mmClrFileReader.readLine()).thenReturn(line1).thenReturn(line2)
				.thenReturn(null);

		this.mmWriter.write(null);
		ClearanceMMProduct product = (ClearanceMMProduct) repositoryImpl
				.getGenericObject(PriceConstants.CLEARANCE_KEY_PREFIX+productId,ClearanceMMProduct.class);
		if (product == null) {
			Assert.assertTrue(true);
		} else {
			Assert.assertTrue(false);
		}
	}

	@Test
	public void readAndWriteMMClrForROINatDataDeletes() throws Exception {
		String line1 = "6075777636         20141013NIEU 0000002.00MM20141102HP20013";
		String line2 = "6075777636         20141013NDEU 0000002.00MM20141102HP20013";
		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "EUR";

		ConstructProductAndTpncMapping(productId, tpnc);
		when(mmClrFileReader.readLine()).thenReturn(line1).thenReturn(line2)
				.thenReturn(null);
		this.mmWriter.write(null);
		ClearanceMMProduct product = (ClearanceMMProduct) repositoryImpl
				.getGenericObject(PriceConstants.CLEARANCE_KEY_PREFIX+productId,ClearanceMMProduct.class);
		if (product == null) {
			Assert.assertTrue(true);
		} else {
			Assert.assertTrue(false);
		}
	}

	@Test
	public void readAndWriteMMClrForUKStoreDataDeletes() throws Exception {
		String line1 = "6075777636     2964" + eff_date1 + "SIGBP0000005.00MM"
				+ end_date1 + "HP20013";
		String line2 = "6075777636     2964" + eff_date1 + "SDGBP0000005.00MM"
				+ end_date2 + "HP20013";

		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "GBP";

		ConstructProductAndTpncMapping(productId, tpnc);
		when(mmClrFileReader.readLine()).thenReturn(line1).thenReturn(line2)
				.thenReturn(null);
		// ClearanceStoreSaleInfo clearanceStoreSaleInfo =
		// createClearanceStoreSaleInfo(" 2964","UK","GBP",null);
		final ClearanceMMProduct expectedClearanceMMProduct = createClearanceMMProduct(
				productId, null, null);

		this.mmWriter.write(null);
		ClearanceMMProduct product = (ClearanceMMProduct) repositoryImpl
				.getGenericObject(PriceConstants.CLEARANCE_KEY_PREFIX+productId,ClearanceMMProduct.class);
		if (product == null) {
			Assert.assertTrue(true);
		} else
			Assert.assertTrue(false);
	}

	@Test
	public void readAndWriteMMClrForROIStoreDataDeletes() throws Exception {
		String line1 = "6075777636     296420141013SIEU 0000005.00MM20141102HP20013";
		String line2 = "6075777636     296420141013SDEU 0000005.00MM20141031HP20013";

		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "EUR";

		ConstructProductAndTpncMapping(productId, tpnc);
		when(mmClrFileReader.readLine()).thenReturn(line1).thenReturn(line2)
				.thenReturn(null);
		createClearanceMMProduct(productId, null, null);

		this.mmWriter.write(null);
		ClearanceMMProduct product = (ClearanceMMProduct) repositoryImpl
				.getGenericObject(PriceConstants.CLEARANCE_KEY_PREFIX+productId,ClearanceMMProduct.class);
		if (product == null) {
			Assert.assertTrue(true);
		} else

			Assert.assertTrue(false);
	}

	@Test
	public void readAndWriteMMClrForUKNatDataDeletesAndInserts()
			throws Exception {
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = Calendar.getInstance();

		cal.add(Calendar.DATE, 10);
		String eff_date1 = dateFormat.format(cal.getTime());
		cal.add(Calendar.DATE, 10);
		String end_date1 = dateFormat.format(cal.getTime());
		String line1 = "6075777636         " + eff_date1 + "NIGBP0000005.00MM"
				+ end_date1 + "HP20013";
		String line2 = "6075777636         " + eff_date1 + "NDGBP0000005.00MM"
				+ end_date1 + "HP20013";
		String line3 = "6075777636         " + eff_date1 + "NIGBP0000002.00MM"
				+ end_date1 + "HP20013";

		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "GBP";

		// inserting the Nat Clr first
		ConstructProductAndTpncMapping(productId, tpnc);
		insertClearanceProduct(clearanceProductMapper
				.mapLineDataToClearanceMMProduct(line1, true, runIdentifier));
		when(mmClrFileReader.readLine()).thenReturn(line2).thenReturn(line3)
				.thenReturn(null);
		ClearanceByDateTime clearanceByDateTimeForStore = createClearanceByDateTime(
				eff_date1, end_date1, "MM", "0000002.00");
		ClearanceZoneSaleInfo clearanceZoneSaleInfo = createClearanceZoneSaleInfo(
				"20", "UK", "GBP", clearanceByDateTimeForStore);
		final ClearanceMMProduct expectedClearanceMMProduct = createClearanceMMProduct(
				productId, clearanceZoneSaleInfo, null);

		this.mmWriter.write(null);
		ClearanceMMProduct actualClearanceProduct = (ClearanceMMProduct) repositoryImpl
				.getGenericObject(PriceConstants.CLEARANCE_MM_PRODUCT_KEY_PREFIX+productId,ClearanceMMProduct.class);
		boolean isEqual = new RPMComparator().compare(actualClearanceProduct,
				expectedClearanceMMProduct);
		Assert.assertTrue(isEqual);
	}

	@Test
	public void readAndWriteMMClrForROINatDataDeletesAndInserts()
			throws Exception {
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = Calendar.getInstance();

		cal.add(Calendar.DATE, 10);
		String eff_date = dateFormat.format(cal.getTime());
		cal.add(Calendar.DATE, 10);
		String end_date = dateFormat.format(cal.getTime());
		String line1 = "6075777636         " + eff_date + "NIEU 0000005.00MM"
				+ end_date + "HP20013";
		String line2 = "6075777636         " + eff_date + "NDEU 0000005.00MM"
				+ end_date + "HP20013";
		String line3 = "6075777636         " + eff_date + "NIEU 0000002.00MM"
				+ end_date + "HP20013";

		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "EUR";

		// inserting the Nat Clr first
		ConstructProductAndTpncMapping(productId, tpnc);
		insertClearanceProduct(clearanceProductMapper
				.mapLineDataToClearanceMMProduct(line1, true, runIdentifier));
		when(mmClrFileReader.readLine()).thenReturn(line2).thenReturn(line3)
				.thenReturn(null);
		ClearanceByDateTime clearanceByDateTimeForStore = createClearanceByDateTime(
				eff_date, end_date, "MM", "0000002.00");
		ClearanceZoneSaleInfo clearanceZoneSaleInfo = createClearanceZoneSaleInfo(
				"21", "IE", "EUR", clearanceByDateTimeForStore);
		final ClearanceMMProduct expectedClearanceMMProduct = createClearanceMMProduct(
				productId, clearanceZoneSaleInfo, null);

		this.mmWriter.write(null);
		ClearanceMMProduct actualClearanceProduct = (ClearanceMMProduct) repositoryImpl
				.getGenericObject(PriceConstants.CLEARANCE_MM_PRODUCT_KEY_PREFIX+productId,ClearanceMMProduct.class);
		boolean isEqual = new RPMComparator().compare(actualClearanceProduct,
				expectedClearanceMMProduct);
		Assert.assertTrue(isEqual);
	}

	@Test
	public void readAndWriteMMClrForUKNatDataInsertAndUpdate() throws Exception {
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 10);
		String eff_date = dateFormat.format(cal.getTime());
		cal.add(Calendar.DATE, 10);
		String end_date1 = dateFormat.format(cal.getTime());
		cal.add(Calendar.DATE, 10);
		String end_date2 = dateFormat.format(cal.getTime());

		String line1 = "6075777636         " + eff_date + "NIGBP0000005.00MM"
				+ end_date2 + "HP20013";
		String line2 = "6075777636         " + eff_date + "NUGBP0000005.00MM"
				+ end_date1 + "HP20013";

		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "GBP";

		// inserting the Nat Clr first
		ConstructProductAndTpncMapping(productId, tpnc);
		insertClearanceProduct(clearanceProductMapper
				.mapLineDataToClearanceMMProduct(line1, true, runIdentifier));
		when(mmClrFileReader.readLine()).thenReturn(line2).thenReturn(null);
		ClearanceByDateTime clearanceByDateTimeForStore = createClearanceByDateTime(
				eff_date, end_date1, "MM", "0000005.00");
		ClearanceZoneSaleInfo clearanceZoneSaleInfo = createClearanceZoneSaleInfo(
				"20", "UK", "GBP", clearanceByDateTimeForStore);
		final ClearanceMMProduct expectedClearanceMMProduct = createClearanceMMProduct(
				productId, clearanceZoneSaleInfo, null);

		this.mmWriter.write(null);
		ClearanceMMProduct actualClearanceProduct = (ClearanceMMProduct) repositoryImpl
				.getGenericObject(PriceConstants.CLEARANCE_MM_PRODUCT_KEY_PREFIX+productId,ClearanceMMProduct.class);
		boolean isEqual = new RPMComparator().compare(actualClearanceProduct,
				expectedClearanceMMProduct);
		Assert.assertTrue(isEqual);
	}

	@Test
	public void readAndWriteMMClrForROINatDataInsertAndUpdate()
			throws Exception {
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 10);
		String eff_date = dateFormat.format(cal.getTime());
		cal.add(Calendar.DATE, 10);
		String end_date1 = dateFormat.format(cal.getTime());
		cal.add(Calendar.DATE, 10);
		String end_date2 = dateFormat.format(cal.getTime());
		String line1 = "6075777636         " + eff_date + "NIEU 0000005.00MM"
				+ end_date2 + "HP20013";
		String line2 = "6075777636         " + eff_date + "NUEU 0000005.00MM"
				+ end_date1 + "HP20013";

		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "EUR";

		// inserting the Nat Clr first
		ConstructProductAndTpncMapping(productId, tpnc);
		insertClearanceProduct(clearanceProductMapper
				.mapLineDataToClearanceMMProduct(line1, true, runIdentifier));
		when(mmClrFileReader.readLine()).thenReturn(line2).thenReturn(null);
		ClearanceByDateTime clearanceByDateTimeForStore = createClearanceByDateTime(
				eff_date, end_date1, "MM", "0000005.00");
		ClearanceZoneSaleInfo clearanceZoneSaleInfo = createClearanceZoneSaleInfo(
				"21", "IE", "EUR", clearanceByDateTimeForStore);
		final ClearanceMMProduct expectedClearanceMMProduct = createClearanceMMProduct(
				productId, clearanceZoneSaleInfo, null);

		this.mmWriter.write(null);
		ClearanceMMProduct actualClearanceProduct =(ClearanceMMProduct) repositoryImpl
				.getGenericObject(PriceConstants.CLEARANCE_MM_PRODUCT_KEY_PREFIX+productId,ClearanceMMProduct.class);
		boolean isEqual = new RPMComparator().compare(actualClearanceProduct,
				expectedClearanceMMProduct);
		Assert.assertTrue(isEqual);
	}

	@Test
	public void readAndWriteMMClrForUKStoreDataInsertAndUpdate()
			throws Exception {
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 10);
		String eff_date1 = dateFormat.format(cal.getTime());
		cal.add(Calendar.DATE, 10);
		String end_date1 = dateFormat.format(cal.getTime());
		cal.add(Calendar.DATE, 10);
		String end_date2 = dateFormat.format(cal.getTime());
		String line1 = "6075777636     2964" + eff_date1 + "SIGBP0000005.00MM"
				+ end_date2 + "HP20013";
		String line2 = "6075777636     2964" + eff_date1 + "SUGBP0000005.00MM"
				+ end_date1 + "HP20013";

		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "GBP";

		// inserting the Nat Clr first
		ConstructProductAndTpncMapping(productId, tpnc);
		insertClearanceProduct(clearanceProductMapper
				.mapLineDataToClearanceMMProduct(line1, true, runIdentifier));
		when(mmClrFileReader.readLine()).thenReturn(line2).thenReturn(null);
		ClearanceByDateTime clearanceByDateTimeForStore = createClearanceByDateTime(
				eff_date1, end_date1, "MM", "0000005.00");
		ClearanceStoreSaleInfo clearanceStoreSaleInfo = createClearanceStoreSaleInfo(
				" 2964", "UK", "GBP", clearanceByDateTimeForStore);
		final ClearanceMMProduct expectedClearanceMMProduct = createClearanceMMProduct(
				productId, null, clearanceStoreSaleInfo);

		this.mmWriter.write(null);
		ClearanceMMProduct actualClearanceProduct = (ClearanceMMProduct) repositoryImpl
				.getGenericObject(PriceConstants.CLEARANCE_MM_PRODUCT_KEY_PREFIX+productId,ClearanceMMProduct.class);
		boolean isEqual = new RPMComparator().compare(actualClearanceProduct,
				expectedClearanceMMProduct);
		Assert.assertTrue(isEqual);
	}

	@Test
	public void readAndWriteMMClrForROIStoreDataInsertAndUpdate()
			throws Exception {
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 10);
		String eff_date1 = dateFormat.format(cal.getTime());
		cal.add(Calendar.DATE, 10);
		String end_date1 = dateFormat.format(cal.getTime());
		cal.add(Calendar.DATE, 10);
		String end_date2 = dateFormat.format(cal.getTime());
		String line1 = "6075777636     2964" + eff_date1 + "SIEU 0000005.00MM"
				+ end_date2 + "HP20013";
		String line2 = "6075777636     2964" + eff_date1 + "SUEU 0000005.00MM"
				+ end_date1 + "HP20013";

		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "EUR";

		// inserting the Nat Clr first
		ConstructProductAndTpncMapping(productId, tpnc);
		insertClearanceProduct(clearanceProductMapper
				.mapLineDataToClearanceMMProduct(line1, true, runIdentifier));
		when(mmClrFileReader.readLine()).thenReturn(line2).thenReturn(null);
		ClearanceByDateTime clearanceByDateTimeForStore = createClearanceByDateTime(
				eff_date1, end_date1, "MM", "0000005.00");
		ClearanceStoreSaleInfo clearanceStoreSaleInfo = createClearanceStoreSaleInfo(
				" 2964", "IE", "EUR", clearanceByDateTimeForStore);
		final ClearanceMMProduct expectedClearanceMMProduct = createClearanceMMProduct(
				productId, null, clearanceStoreSaleInfo);

		this.mmWriter.write(null);
		ClearanceMMProduct actualClearanceProduct = (ClearanceMMProduct) repositoryImpl
				.getGenericObject(PriceConstants.CLEARANCE_MM_PRODUCT_KEY_PREFIX+productId,ClearanceMMProduct.class);
		boolean isEqual = new RPMComparator().compare(actualClearanceProduct,
				expectedClearanceMMProduct);
		Assert.assertTrue(isEqual);
	}

	@Test
	public void readAndWriteMMClrForUKNatDataMultipleMrkDwns() throws Exception {

		String line = "6075777636         " + "20181210" + "NIGBP0000005.00MM"
				+ "20191210" + "HP20013";
		String line2 = "6075777636         " + "20180910" + "NIGBP0000005.00MM"
				+ "20181020" + "HP20013";

		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "GBP";

		// inserting the Nat Clr first
		ConstructProductAndTpncMapping(productId, tpnc);
		insertClearanceProduct(clearanceProductMapper
				.mapLineDataToClearanceMMProduct(line, true, runIdentifier));

		when(mmClrFileReader.readLine()).thenReturn(line2).thenReturn(null);

		ClearanceByDateTime clearanceByDateTimeOldUK = createClearanceByDateTime(
				"20181210", "20191210", "MM", "0000005.00");
		ClearanceByDateTime clearanceByDateTimeNewUK = createClearanceByDateTime(
				"20180910", "20181020", "MM", "0000005.00");

		ClearanceZoneSaleInfo clearanceZoneSaleInfoUK = createClearanceZoneSaleInfo(
				"20", "UK", "GBP", clearanceByDateTimeNewUK);

		clearanceZoneSaleInfoUK
				.addZoneClearanceByDateTime(clearanceByDateTimeOldUK);

		final ClearanceMMProduct expectedClearanceMMProduct = createClearanceMMProduct(
				productId, clearanceZoneSaleInfoUK, null);

		this.mmWriter.write(null);
		ClearanceMMProduct actualClearanceProduct = (ClearanceMMProduct) repositoryImpl
				.getGenericObject(PriceConstants.CLEARANCE_MM_PRODUCT_KEY_PREFIX+productId,ClearanceMMProduct.class);

		Assertions.assertThat(actualClearanceProduct)
				.isEqualToComparingFieldByField(expectedClearanceMMProduct); // Added
																				// for
																				// PRIS-1133
																				// Java
																				// 8
																				// Migration.
	}

	@Test
	public void readAndWriteMMClrForROINatDataMultipleMrkDwns()
			throws Exception {

		String line1 = "6075777636         " + "20181210" + "NIEU 0000004.00MM"
				+ "20191210" + "HP20013";
		String line3 = "6075777636         " + "20180910" + "NIEU 0000004.00MM"
				+ "20181020" + "HP20013";

		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "EUR";

		// inserting the Nat Clr first
		ConstructProductAndTpncMapping(productId, tpnc);
		insertClearanceProduct(clearanceProductMapper
				.mapLineDataToClearanceMMProduct(line1, true, runIdentifier));

		when(mmClrFileReader.readLine()).thenReturn(line3).thenReturn(null);

		ClearanceByDateTime clearanceByDateTimeOldROI = createClearanceByDateTime(
				"20181210", "20191210", "MM", "0000004.00");
		ClearanceByDateTime clearanceByDateTimeNewROI = createClearanceByDateTime(
				"20180910", "20181020", "MM", "0000004.00");

		ClearanceZoneSaleInfo clearanceZoneSaleInfoROI = createClearanceZoneSaleInfo(
				"21", "IE", "EUR", clearanceByDateTimeNewROI);
		clearanceZoneSaleInfoROI
				.addZoneClearanceByDateTime(clearanceByDateTimeOldROI);

		final ClearanceMMProduct expectedClearanceMMProduct = createClearanceMMProduct(
				productId, clearanceZoneSaleInfoROI, null);

		this.mmWriter.write(null);
		ClearanceMMProduct actualClearanceProduct = (ClearanceMMProduct) repositoryImpl
				.getGenericObject(PriceConstants.CLEARANCE_MM_PRODUCT_KEY_PREFIX+productId,ClearanceMMProduct.class);

		Assertions.assertThat(actualClearanceProduct)
				.isEqualToComparingFieldByField(expectedClearanceMMProduct); // Added
																				// for
																				// PRIS-1133
																				// Java
																				// 8
																				// Migration.
	}

	@Test
	public void readAndWriteMMClrForUKStoreDataMultipleMrkDwns()
			throws Exception {

		String line1 = "6075777636     2964" + "20181210" + "SIGBP0000005.00MM"
				+ "20191210" + "HP20013";
		String line2 = "6075777636     2964" + "20180910" + "SIGBP0000005.00MM"
				+ "20181020" + "HP20013";
		String line3 = "6075777636     2964" + "20181210" + "SUGBP0000005.00MM"
				+ "20191225" + "HP20013";
		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "GBP";

		// inserting the Nat Clr first
		ConstructProductAndTpncMapping(productId, tpnc);
		insertClearanceProduct(clearanceProductMapper
				.mapLineDataToClearanceMMProduct(line1, true, runIdentifier));
		when(mmClrFileReader.readLine()).thenReturn(line2).thenReturn(null);
		ClearanceByDateTime clearanceByDateTimeOldUK = createClearanceByDateTime(
				"20181210", "20191225", "MM", "0000005.00");
		ClearanceByDateTime clearanceByDateTimeNewUK = createClearanceByDateTime(
				"20180910", "20181020", "MM", "0000005.00");
		ClearanceStoreSaleInfo clearanceStoreSaleInfo = createClearanceStoreSaleInfo(
				" 2964", "UK", "GBP", clearanceByDateTimeNewUK);
		clearanceStoreSaleInfo
				.addStoreClearanceByDateTime(clearanceByDateTimeOldUK);
		final ClearanceMMProduct expectedClearanceMMProduct = createClearanceMMProduct(
				productId, null, clearanceStoreSaleInfo);

		this.mmWriter.write(null);
		insertClearanceProduct(clearanceProductMapper
				.mapLineDataToClearanceMMProduct(line3, true, runIdentifier));
		ClearanceMMProduct actualClearanceProduct = (ClearanceMMProduct) repositoryImpl
				.getGenericObject(PriceConstants.CLEARANCE_MM_PRODUCT_KEY_PREFIX+productId,ClearanceMMProduct.class);

		Assertions.assertThat(actualClearanceProduct)
				.isEqualToComparingFieldByField(expectedClearanceMMProduct); // Added
																				// for
																				// PRIS-1133
																				// Java
																				// 8
																				// Migration.
	}

	@Test
	public void readAndWriteMMClrForROIStoreDataMultipleMrkDwns()
			throws Exception {

		String line1 = "6075777636     2964" + "20181210" + "SIEU 0000005.00MM"
				+ "20191210" + "HP20013";
		String line2 = "6075777636     2964" + "20180910" + "SIEU 0000005.00MM"
				+ "20181020" + "HP20013";
		String line3 = "6075777636     2964" + "20181210" + "SUEU 0000005.00MM"
				+ "20191225" + "HP20013";

		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "EUR";

		// inserting the Nat Clr first
		ConstructProductAndTpncMapping(productId, tpnc);
		insertClearanceProduct(clearanceProductMapper
				.mapLineDataToClearanceMMProduct(line1, true, runIdentifier));
		when(mmClrFileReader.readLine()).thenReturn(line2).thenReturn(null);
		ClearanceByDateTime clearanceByDateTimeOldUK = createClearanceByDateTime(
				"20181210", "20191225", "MM", "0000005.00");
		ClearanceByDateTime clearanceByDateTimeNewUK = createClearanceByDateTime(
				"20180910", "20181020", "MM", "0000005.00");
		ClearanceStoreSaleInfo clearanceStoreSaleInfo = createClearanceStoreSaleInfo(
				" 2964", "IE", "EUR", clearanceByDateTimeNewUK);
		clearanceStoreSaleInfo
				.addStoreClearanceByDateTime(clearanceByDateTimeOldUK);
		final ClearanceMMProduct expectedClearanceMMProduct = createClearanceMMProduct(
				productId, null, clearanceStoreSaleInfo);

		this.mmWriter.write(null);
		insertClearanceProduct(clearanceProductMapper
				.mapLineDataToClearanceMMProduct(line3, true, runIdentifier));
		ClearanceMMProduct actualClearanceProduct = (ClearanceMMProduct) repositoryImpl
				.getGenericObject(PriceConstants.CLEARANCE_MM_PRODUCT_KEY_PREFIX+productId,ClearanceMMProduct.class);

		Assertions.assertThat(actualClearanceProduct)
				.isEqualToComparingFieldByField(expectedClearanceMMProduct); // Added
																				// for
																				// PRIS-1133
																				// Java
																				// 8
																				// Migration.
	}

	@Test
	public void readAndSkipMMClrForUKNatAndStoreDataInsertsWhenNoProductInfoFound()
			throws Exception {
		String line1 = "6075777636         " + eff_date1 + "NIGBP0000002.00MM"
				+ end_date1 + "HP20013";
		String line2 = "6075777636     2964" + eff_date1 + "SIGBP0000003.00MM"
				+ end_date1 + "HP20013";
		String productId = "075777636";
		currencyCode = "GBP";
		when(mmClrFileReader.readLine()).thenReturn(line1).thenReturn(line2)
				.thenReturn(null);
		this.mmWriter.write(null);
		ClearanceMMProduct product = (ClearanceMMProduct) repositoryImpl.getGenericObject(PriceConstants.CLEARANCE_KEY_PREFIX+productId,ClearanceMMProduct.class);
		Optional<ClearanceMMProduct> actualClearanceProduct = (product != null) ? Optional.of(product) : Optional
				.<ClearanceMMProduct> absent();
		boolean isClearanceInserted = true;
		if (!actualClearanceProduct.isPresent()) {
			isClearanceInserted = false;
		}
		Assert.assertTrue(!isClearanceInserted);
	}

	@Test
	public void readAndWriteMMClrForROIStoreDataWhenSellingUomIsNull()
			throws Exception {

		String line1 = "6075777636     2964" + eff_date1 + "SIEU 0000005.00MM"
				+ end_date1 + "HP20013";
		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "EUR";
		sellingUom = "";
		ConstructProductAndTpncMapping(productId, tpnc);
		when(mmClrFileReader.readLine()).thenReturn(line1).thenReturn(null);
		ClearanceByDateTime clearanceByDateTime = createClearanceByDateTime(
				eff_date1, end_date1, "MM", "0000005.00");
		ClearanceStoreSaleInfo clearanceStoreSaleInfo = createClearanceStoreSaleInfo(
				" 2964", "IE", "EUR", clearanceByDateTime);
		final ClearanceMMProduct expectedClearanceMMProduct = createClearanceMMProduct(
				productId, null, clearanceStoreSaleInfo);
		this.mmWriter.write(null);
		ClearanceMMProduct actualClearanceProduct = (ClearanceMMProduct) repositoryImpl
				.getGenericObject(PriceConstants.CLEARANCE_MM_PRODUCT_KEY_PREFIX+productId,ClearanceMMProduct.class);
		boolean isEqual = new RPMComparator().compare(actualClearanceProduct,
				expectedClearanceMMProduct);
		Assert.assertTrue(isEqual);
	}

	@Test
	public void readAndNegletHearderAndFooter() throws Exception {

		String header = "020141118";
		String footer = "9000000013";
		String line1 = "6075777636     2964" + eff_date1 + "SIEU 0000005.00MM"
				+ end_date1 + "HP20013";
		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "EUR";
		sellingUom = "EA";
		ConstructProductAndTpncMapping(productId, tpnc);

		when(mmClrFileReader.readLine()).thenReturn(header).thenReturn(line1)
				.thenReturn(footer).thenReturn(null);
		ClearanceByDateTime clearanceByDateTime = createClearanceByDateTime(
				eff_date1, end_date1, "MM", "0000005.00");
		ClearanceStoreSaleInfo clearanceStoreSaleInfo = createClearanceStoreSaleInfo(
				" 2964", "IE", "EUR", clearanceByDateTime);
		final ClearanceMMProduct expectedClearanceMMProduct = createClearanceMMProduct(
				productId, null, clearanceStoreSaleInfo);
		this.mmWriter.write(null);
		ClearanceMMProduct actualClearanceProduct = (ClearanceMMProduct) repositoryImpl
				.getGenericObject(PriceConstants.CLEARANCE_MM_PRODUCT_KEY_PREFIX
						+ productId, ClearanceMMProduct.class);;
		boolean isEqual = new RPMComparator().compare(actualClearanceProduct,
				expectedClearanceMMProduct);
		// Assert.assertEquals(actualClearanceProduct,expectedClearanceMMProduct);
		Assert.assertTrue(isEqual);
	}

	@Test
	public void testRestartabilityForMmReg() throws Exception {

		runIdentifier = "mmreg";

		mmWriter = new MMWriter(testConfiguration, repositoryImpl,
				mmClrFileReader, clearanceEventHandler, clearanceProductMapper);
		mmWriter.setRunIdentifier(runIdentifier);
		ImportResource.importSemaphoreForIdentifier.put(runIdentifier,
				new Semaphore(1));

		String line1 = "6075777636     296420201013SIGBP0000005.00MM20201102HP20013";
		String line2 = "6075777636     ";
		String line3 = "6075777637     296420201101SIGBP0000005.00MM20201202HP20013";
		String tpnc = "281837179";
		String productId = "075777636";
		String tpnc2 = "281837178";
		String productId2 = "075777637";
		currencyCode = "GBP";
		// inserting the price/promo product first
		ConstructProductAndTpncMapping(productId, tpnc);
		ConstructProductAndTpncMapping(productId2, tpnc2);
		mmWriter.setFileWriter(fileWriter);
		// mmWriter.setFailedFile(mmClrFailedDatafile);
		mmWriter.setBufferedWriter(bufferedWriter);
		mmWriter.setFileReader(fileReader);
		mmWriter.setMmClrFailedFileReader(mmClrFailedFileReader);
		when(mmClrFileReader.readLine()).thenReturn(line2).thenReturn(null);
		this.mmWriter.write(null);
		ClearanceMMProduct product2 = (ClearanceMMProduct) repositoryImpl
				.getGenericObject(PriceConstants.CLEARANCE_KEY_PREFIX+productId,ClearanceMMProduct.class);
		assertNull(product2);

		when(mmClrFailedFileReader.readLine()).thenReturn(productId)
				.thenReturn(null);
		when(mmClrFileReader.readLine()).thenReturn(line1).thenReturn(line3)
				.thenReturn(null);
		this.mmWriter.write(null);
		ClearanceMMProduct product = (ClearanceMMProduct) repositoryImpl
				.getGenericObject(PriceConstants.CLEARANCE_MM_PRODUCT_KEY_PREFIX+productId,ClearanceMMProduct.class);
		assertNotNull(product);
		ClearanceMMProduct productObj = (ClearanceMMProduct) repositoryImpl
				.getGenericObject(PriceConstants.CLEARANCE_MM_PRODUCT_KEY_PREFIX+productId2,ClearanceMMProduct.class);
		assertNotNull(productObj);
	}

	@Test
	public void testRestartabilityForMmEmer() throws Exception {

		runIdentifier = "mmemer";
		mmWriter = new MMWriter(testConfiguration, repositoryImpl,
				mmClrFileReader, clearanceEventHandler, clearanceProductMapper);
		mmWriter.setRunIdentifier(runIdentifier);
		ImportResource.importSemaphoreForIdentifier.put(runIdentifier,
				new Semaphore(1));

		String line1 = "6075777636     296420201013SIGBP0000005.00MM20201102HP20013";
		String line2 = "6075777636     ";
		String line3 = "6075777637     296420201101SIGBP0000005.00MM20201202HP20013";
		String tpnc = "281837179";
		String productId = "075777636";
		String tpnc2 = "281837178";
		String productId2 = "075777637";
		currencyCode = "GBP";
		// inserting the price/promo product first
		ConstructProductAndTpncMapping(productId, tpnc);
		ConstructProductAndTpncMapping(productId2, tpnc2);
		mmWriter.setFileWriter(fileWriter);
		mmWriter.setFailedFile(mmClrFailedDatafile);
		mmWriter.setBufferedWriter(bufferedWriter);
		mmWriter.setFileReader(fileReader);
		mmWriter.setMmClrFailedFileReader(mmClrFailedFileReader);
		when(mmClrFileReader.readLine()).thenReturn(line2).thenReturn(null);
		/** Below 2 lines are to mock reject file deletion */
		when(mmClrFailedDatafile.exists()).thenReturn(true);
		when(mmClrFailedDatafile.toPath()).thenReturn(new File("abc").toPath());
		this.mmWriter.write(null);
		ClearanceMMProduct product = (ClearanceMMProduct) repositoryImpl
				.getGenericObject(PriceConstants.CLEARANCE_KEY_PREFIX+productId,ClearanceMMProduct.class);
		assertNull(product);

		when(mmClrFailedFileReader.readLine()).thenReturn(productId)
				.thenReturn(null);
		when(mmClrFileReader.readLine()).thenReturn(line1).thenReturn(line3)
				.thenReturn(null);
		this.mmWriter.write(null);
		ClearanceMMProduct product1 = (ClearanceMMProduct) repositoryImpl
				.getGenericObject(PriceConstants.CLEARANCE_MM_PRODUCT_KEY_PREFIX+productId,ClearanceMMProduct.class);
		assertNotNull(product1);
		ClearanceMMProduct product2 = (ClearanceMMProduct) repositoryImpl
				.getGenericObject(PriceConstants.CLEARANCE_MM_PRODUCT_KEY_PREFIX+productId2,ClearanceMMProduct.class);
		assertNotNull(product2);

	}

	@Ignore
	@Test
	public void shouldInsertProductDetailsIntoRejectFileWhenPriceProductNotFound()
			throws Exception {

		mmWriter = new MMWriter(testConfiguration, repositoryImpl,
				mmClrFileReader, clearanceEventHandler, clearanceProductMapper);
		ImportResource.importSemaphoreForIdentifier.put(runIdentifier,
				new Semaphore(1));

		String line1 = "6075777636     296420141013SIGBP0000005.00MM20141102HP20013";
		String productId = "075777636";
		String productIdWithReasonCode = "075777636|PRODUCT NOT FOUND";
		currencyCode = "GBP";

		when(mmClrFileReader.readLine()).thenReturn(line1).thenReturn(null);
		this.mmWriter.write(null);
		assertNull(repositoryImpl
				.getGenericObject(
						PriceConstants.CLEARANCE_MM_PRODUCT_KEY_PREFIX + productId,
						ClearanceMMProduct.class));
		assertThat(
				getfailedProductInProviousRunIfExist(testConfiguration
						.getRejectFilePath()
						+ "/REJECT_FILE_"
						+ runIdentifier
						+ "_" + Dockyard.getSysDate("yyyyMMddHHmmss") + ".log"))
				.isEqualTo(productIdWithReasonCode);
	}

	@Test
	public void testToThrowException() throws Exception {

		runIdentifier = "mmemer";
		mmWriter = new MMWriter(testConfiguration, repositoryImpl,
				mmClrFileReader, clearanceEventHandler, clearanceProductMapper);
		mmWriter.setRunIdentifier(runIdentifier);
		ImportResource.importSemaphoreForIdentifier.put(runIdentifier,
				new Semaphore(1));

		String line1 = "6075777636     296420141013SIGBP0000005.00MM20141102HP20013";
		String tpnc = "281837179";
		String productId = "075777636";
		String tpnc2 = "281837178";
		String productId2 = "075777637";
		currencyCode = "GBP";
		// inserting the price/promo product first
		ConstructProductAndTpncMapping(productId, tpnc);
		ConstructProductAndTpncMapping(productId2, tpnc2);
		mmWriter.setFileReader(fileReader);
		mmWriter.setFileWriter(fileWriter);
		mmWriter.setMmClrFailedFileReader(mmClrFailedFileReader);
		mmWriter.setFailedFile(mmClrFailedDatafile);
		mmWriter.setBufferedWriter(bufferedWriter);
		when(mmClrFileReader.readLine()).thenReturn(line1).thenReturn(null);
		// Mockito.when(bufferedWriter.write("075777636")).thenThrow(new
		// IOException());
		doThrow(new IOException()).when(bufferedWriter).write("075777636");

		this.mmWriter.write(null);
		assertThat(repositoryImpl
				.getGenericObject(PriceConstants.CLEARANCE_KEY_PREFIX+productId,ClearanceMMProduct.class)).isNull();
		// second exception
		when(mmClrFileReader.readLine()).thenThrow(new IOException());
		doThrow(new IOException()).when(bufferedWriter).write("075777636");
		this.mmWriter.write(null);
		assertThat(repositoryImpl
				.getGenericObject(PriceConstants.CLEARANCE_KEY_PREFIX+productId,ClearanceMMProduct.class)).isNull();

	}

	@Test
	public void removeExpiredStoreExclClearance() throws Exception {
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = Calendar.getInstance();
		Calendar cal2 = Calendar.getInstance();
		cal.add(Calendar.DATE, -20);
		String eff_date = dateFormat.format(cal.getTime());
		cal.add(Calendar.DATE, 10);
		String end_date = dateFormat.format(cal.getTime());
		cal2.add(Calendar.DATE, 10);
		String appEffDate = dateFormat.format(cal2.getTime());
		cal2.add(Calendar.DATE, 10);
		String appEndDate = dateFormat.format(cal2.getTime());
		String line1 = "6075777636     2964" + eff_date + "SIEU 0000005.00MM"
				+ end_date + "HP20013";
		String line2 = "6075777636     2964" + appEffDate + "SIEU 0000005.00MM"
				+ appEndDate + "HP20013";
		// String line3 =
		// "6075777636     2964"+"20141013"+"SUEU 0000005.00MM"+"20141031"+"HP20013";
		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "EUR";

		// inserting the Nat Clr first
		ConstructProductAndTpncMapping(productId, tpnc);
		// Inserting into couchbase to mock product with expired clearance
		insertClearanceProduct(clearanceProductMapper
				.mapLineDataToClearanceMMProduct(line2, true, runIdentifier));
		// Mocking a file read to insert data into couchbse with approved
		// clearance
		when(mmClrFileReader.readLine()).thenReturn(line1).thenReturn(null);
		ClearanceByDateTime clearanceByDateTimeApprovedClr = createClearanceByDateTime(
				appEffDate, appEndDate, "MM", "0000005.00");
		ClearanceStoreSaleInfo clearanceStoreSaleInfoApprovedClr = createClearanceStoreSaleInfo(
				"2964", "IE", "EUR", clearanceByDateTimeApprovedClr);
		final ClearanceMMProduct expectedClearanceMMProduct = createClearanceMMProduct(
				productId, null, clearanceStoreSaleInfoApprovedClr);

		this.mmWriter.write(null);
		ClearanceMMProduct actualClearanceProduct = (ClearanceMMProduct) repositoryImpl
				.getGenericObject(PriceConstants.CLEARANCE_MM_PRODUCT_KEY_PREFIX+productId,ClearanceMMProduct.class);
		boolean isEqual = new RPMComparator().compare(actualClearanceProduct,
				expectedClearanceMMProduct);
		Assert.assertTrue(isEqual);

	}

	@Test
	public void removeExpiredZoneClearance() throws Exception {
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = Calendar.getInstance();
		Calendar cal2 = Calendar.getInstance();
		cal.add(Calendar.DATE, -20);
		String eff_date = dateFormat.format(cal.getTime());
		cal.add(Calendar.DATE, 10);
		String end_date = dateFormat.format(cal.getTime());
		cal2.add(Calendar.DATE, 10);
		String appEffDate = dateFormat.format(cal2.getTime());
		cal2.add(Calendar.DATE, 10);
		String appEndDate = dateFormat.format(cal2.getTime());
		String line1 = "6075777636         " + eff_date + "NIEU 0000005.00MM"
				+ end_date + "HP20013";
		String line2 = "6075777636         " + appEffDate + "NIEU 0000005.00MM"
				+ appEndDate + "HP20013";
		// String line3 =
		// "6075777636     2964"+"20141013"+"SUEU 0000005.00MM"+"20141031"+"HP20013";
		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "EUR";

		// inserting the Nat Clr first
		ConstructProductAndTpncMapping(productId, tpnc);
		// Inserting into couchbase to mock product with expired clearance
		insertClearanceProduct(clearanceProductMapper
				.mapLineDataToClearanceMMProduct(line2, true, runIdentifier));
		// Mocking a file read to insert data into couchbse with approved
		// clearance
		when(mmClrFileReader.readLine()).thenReturn(line1).thenReturn(null);
		ClearanceByDateTime clearanceByDateTimeApprovedClr = createClearanceByDateTime(
				appEffDate, appEndDate, "MM", "0000005.00");
		ClearanceZoneSaleInfo clearanceZoneSaleInfoApprovedClr = createClearanceZoneSaleInfo(
				"21", "IE", "EUR", clearanceByDateTimeApprovedClr);

		final ClearanceMMProduct expectedClearanceMMProduct = createClearanceMMProduct(
				productId, clearanceZoneSaleInfoApprovedClr, null);

		this.mmWriter.write(null);
		ClearanceMMProduct actualClearanceProduct = (ClearanceMMProduct) repositoryImpl
				.getGenericObject(PriceConstants.CLEARANCE_MM_PRODUCT_KEY_PREFIX+productId,ClearanceMMProduct.class);
		boolean isEqual = new RPMComparator().compare(actualClearanceProduct,
				expectedClearanceMMProduct);
		Assert.assertTrue(isEqual);

	}

	@Test
	public void removeExpiredStoreExclAndZoneClearance() throws Exception {
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = Calendar.getInstance();
		Calendar cal2 = Calendar.getInstance();
		cal.add(Calendar.DATE, -20);
		String eff_date = dateFormat.format(cal.getTime());
		cal.add(Calendar.DATE, 10);
		String end_date = dateFormat.format(cal.getTime());
		cal2.add(Calendar.DATE, 10);
		String appEffDate = dateFormat.format(cal2.getTime());
		cal2.add(Calendar.DATE, 10);
		String appEndDate = dateFormat.format(cal2.getTime());
		String line1 = "6075777636     2964" + eff_date + "SIEU 0000005.00MM"
				+ end_date + "HP20013";
		String line2 = "6075777636     2964" + appEffDate + "SIEU 0000005.00MM"
				+ appEndDate + "HP20013";
		String line3 = "6075777636         " + eff_date + "NIEU 0000005.00MM"
				+ end_date + "HP20013";
		String line4 = "6075777636         " + appEffDate + "NIEU 0000005.00MM"
				+ appEndDate + "HP20013";

		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "EUR";

		// inserting the Nat Clr first
		ConstructProductAndTpncMapping(productId, tpnc);
		// Inserting into couchbase to mock product with expired clearance
		insertClearanceProduct(clearanceProductMapper
				.mapLineDataToClearanceMMProduct(line2, true, runIdentifier));
		insertClearanceProduct(clearanceProductMapper
				.mapLineDataToClearanceMMProduct(line4, true, runIdentifier));
		// Mocking a file read to insert data into couchbse with approved
		// clearance
		when(mmClrFileReader.readLine()).thenReturn(line1).thenReturn(line3)
				.thenReturn(null);
		ClearanceByDateTime clearanceByDateTimeApprovedClr = createClearanceByDateTime(
				appEffDate, appEndDate, "MM", "0000005.00");
		ClearanceStoreSaleInfo clearanceStoreSaleInfoApprovedClr = createClearanceStoreSaleInfo(
				"2964", "IE", "EUR", clearanceByDateTimeApprovedClr);
		ClearanceZoneSaleInfo clearanceZoneSaleInfoApprovedClr = createClearanceZoneSaleInfo(
				"21", "IE", "EUR", clearanceByDateTimeApprovedClr);
		final ClearanceMMProduct expectedClearanceMMProduct = createClearanceMMProduct(
				productId, clearanceZoneSaleInfoApprovedClr,
				clearanceStoreSaleInfoApprovedClr);

		this.mmWriter.write(null);
		ClearanceMMProduct actualClearanceProduct = (ClearanceMMProduct) repositoryImpl
				.getGenericObject(PriceConstants.CLEARANCE_MM_PRODUCT_KEY_PREFIX+productId,ClearanceMMProduct.class);
		boolean isEqual = new RPMComparator().compare(actualClearanceProduct,
				expectedClearanceMMProduct);
		Assert.assertTrue(isEqual);

	}

	@Test
	public void removeExpiredStoreExclAndZoneClearanceAndRemoveDoc()
			throws Exception {
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = Calendar.getInstance();
		Calendar cal2 = Calendar.getInstance();
		cal.add(Calendar.DATE, -20);
		String eff_date = dateFormat.format(cal.getTime());
		cal.add(Calendar.DATE, 10);
		String end_date = dateFormat.format(cal.getTime());
		cal2.add(Calendar.DATE, 10);
		cal2.add(Calendar.DATE, 10);

		String line1 = "6075777636     2964" + eff_date + "SIEU 0000005.00MM"
				+ end_date + "HP20013";
		String line3 = "6075777636         " + eff_date + "NIEU 0000005.00MM"
				+ end_date + "HP20013";

		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "EUR";

		// inserting the Nat Clr first
		ConstructProductAndTpncMapping(productId, tpnc);

		// Mocking a file read to insert data into couchbse with approved
		// clearance
		when(mmClrFileReader.readLine()).thenReturn(line1).thenReturn(line3)
				.thenReturn(null);

		this.mmWriter.write(null);
		ClearanceMMProduct product = (ClearanceMMProduct) repositoryImpl
				.getGenericObject(PriceConstants.CLEARANCE_KEY_PREFIX+productId,ClearanceMMProduct.class);
		if (product == null) {
			Assert.assertTrue(true);
		} else {
			Assert.assertTrue(false);
		}

	}

	@Test
	public void shouldInvokePublishEventsForMMClearancesForUKNatDataInsert()
			throws Exception {
		// let the date to be fixed as 2016-04-10
		DateTime dateTime = new DateTime();
		String eff_date2 = dateFormat.format(dateTime.toDate().getTime());
		String formattedEffDate = Dockyard.getISO8601FormatStartDate(eff_date2);
		String line1 = "6075777636         " + eff_date2 + "NIGBP0000002.00MM"
				+ end_date1 + "HP20013";
		String tpnc = "281837179";
		String productId = "075777636";
		ConstructProductAndTpncMapping(productId, tpnc);
		when(mmClrFileReader.readLine()).thenReturn(line1).thenReturn(null);
		this.mmWriter.write("");
		ArgumentCaptor<ClearanceEventData> argumentMap = ArgumentCaptor
				.forClass(ClearanceEventData.class);
		ClearanceEventData nationalClearanceDataEventMap = new ClearanceEventData();
		Set<String> testSet = new HashSet<>();
		testSet.add("Z_20_MM");
		nationalClearanceDataEventMap.put("tpnb:075777636_N_"
				+ formattedEffDate + "_GBP_I", testSet);
		Mockito.verify(clearanceEventHandler, Mockito.times(1))
				.publishEventsForClearances(argumentMap.capture());
		assertEquals(nationalClearanceDataEventMap, argumentMap.getValue());
	}

	@Test
	public void shouldNotInvokePublishEventsForExpiredMMClearancesForUKNatDataInsert()
			throws Exception {
		runIdentifier = "mmemer";
		DateTime dateTime = new DateTime();
		DateTime dateTimeMinusDays = dateTime.minusDays(10);
		end_date1 = dateFormat.format(dateTimeMinusDays.toDate().getTime());
		String line1 = "6075777636         " + eff_date1 + "NIGBP0000002.00MM"
				+ end_date1 + "HP20013";
		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "GBP";
		ConstructProductAndTpncMapping(productId, tpnc);
		when(mmClrFileReader.readLine()).thenReturn(line1).thenReturn(null);
		this.mmWriter.write("");
		ArgumentCaptor<ClearanceEventData> argumentMap = ArgumentCaptor
				.forClass(ClearanceEventData.class);
		Mockito.verify(clearanceEventHandler, Mockito.times(0))
				.publishEventsForClearances(argumentMap.capture());
	}

	@Test
	public void shouldInvokePublishEventsForMMClearancesForIENatDataDelete()
			throws Exception {
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 10);
		String eff_date = dateFormat.format(cal.getTime());
		cal.add(Calendar.DATE, 10);
		String end_date = dateFormat.format(cal.getTime());
		String line1 = "6075777636         " + eff_date + "NIEU 0000005.00MM"
				+ end_date + "HP20013";
		String line2 = "6075777636         " + eff_date + "NDEU 0000005.00MM"
				+ end_date + "HP20013";

		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "EUR";

		// inserting the Nat Clr first
		ConstructProductAndTpncMapping(productId, tpnc);
		insertClearanceProduct(clearanceProductMapper
				.mapLineDataToClearanceMMProduct(line1, true, runIdentifier));
		when(mmClrFileReader.readLine()).thenReturn(line2).thenReturn(null);

		ArgumentCaptor<ClearanceEventData> argumentMap = ArgumentCaptor
				.forClass(ClearanceEventData.class);
		ClearanceEventData nationalClearanceDataEventMap = new ClearanceEventData();
		Set<String> testSet = new HashSet<>();
		testSet.add("Z_21_MM");
		String key = "tpnb:075777636_N_"
				+ Dockyard.getISO8601FormatStartDate(eff_date) + "_EU_D";
		nationalClearanceDataEventMap.put(key, testSet);
		mmWriter.write("");
		Mockito.verify(clearanceEventHandler, Mockito.times(1))
				.publishEventsForClearances(argumentMap.capture());
		assertEquals(nationalClearanceDataEventMap, argumentMap.getValue());
	}

	@Test
	public void shouldInvokePublishEventsForMMClearancesForIENatDataDeleteWhenClrDocDeleted()
			throws Exception {
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 10);
		String eff_date = dateFormat.format(cal.getTime());
		runIdentifier = "mmemer";
		DateTime dateTime = new DateTime();
		dateTime.plusDays(10);
		end_date1 = dateFormat.format(dateTime.toDate().getTime());
		String line1 = "6075777636         " + eff_date + "NIEU 0000005.00MM"
				+ end_date1 + "HP20013";
		String line2 = "6075777636         " + eff_date + "NDEU 0000005.00MM"
				+ end_date1 + "HP20013";

		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "EUR";

		// inserting the Nat Clr first
		ConstructProductAndTpncMapping(productId, tpnc);
		insertClearanceProduct(clearanceProductMapper
				.mapLineDataToClearanceMMProduct(line1, true, runIdentifier));
		when(mmClrFileReader.readLine()).thenReturn(line2).thenReturn(null);

		ArgumentCaptor<ClearanceEventData> argumentMap = ArgumentCaptor
				.forClass(ClearanceEventData.class);
		ClearanceEventData nationalClearanceDataEventMap = new ClearanceEventData();
		Set<String> testSet = new HashSet<>();
		testSet.add("Z_21_MM");
		String key = "tpnb:075777636_N_"
				+ Dockyard.getISO8601FormatStartDate(eff_date) + "_EU_D";
		nationalClearanceDataEventMap.put(key, testSet);
		mmWriter.write("");
		Mockito.verify(clearanceEventHandler, Mockito.times(1))
				.publishEventsForClearances(argumentMap.capture());
		assertEquals(nationalClearanceDataEventMap, argumentMap.getValue());
	}

	@Test
	public void shouldNotInvokePublishEventsForExpiredMMClearancesForUKNatDataDelete()
			throws Exception {
		runIdentifier = "mmemer";
		DateTime dateTime = new DateTime();
		dateTime.minusDays(10);
		end_date1 = dateFormat.format(dateTime.toDate().getTime());
		String line1 = "6075777636         " + eff_date1 + "NDGBP0000002.00MM"
				+ end_date1 + "HP20013";
		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "GBP";
		ConstructProductAndTpncMapping(productId, tpnc);
		when(mmClrFileReader.readLine()).thenReturn(line1).thenReturn(null);
		mmWriter.write("");
		ArgumentCaptor<ClearanceEventData> argumentMap = ArgumentCaptor
				.forClass(ClearanceEventData.class);
		Mockito.verify(clearanceEventHandler, Mockito.times(0))
				.publishEventsForClearances(argumentMap.capture());
	}

	@Test
	public void shouldInvokePublishEventsForMMClearancesForUKStoreDataInserts()
			throws Exception {
		// let the date to be fixed as 2016-04-10
		// This method will also checks the grouping logic for the MM Store
		// clearance
		DateTime dateTime = new DateTime();
		String eff_date2 = dateFormat.format(dateTime.toDate().getTime());
		String formattedEffDate = Dockyard.getISO8601FormatStartDate(eff_date2);
		String line1 = "6075777636     1111" + eff_date2 + "SIGBP0000002.00MM"
				+ end_date1 + "HP20013";
		String line2 = "6075777636     2222" + eff_date2 + "SIGBP0000002.00MM"
				+ end_date1 + "HP20013";
		String tpnc = "281837179";
		String productId = "075777636";
		ConstructProductAndTpncMapping(productId, tpnc);
		when(mmClrFileReader.readLine()).thenReturn(line1).thenReturn(line2)
				.thenReturn(null);
		this.mmWriter.write("");

		ArgumentCaptor<ClearanceEventData> argumentMap = ArgumentCaptor
				.forClass(ClearanceEventData.class);
		ClearanceEventData storeClearanceDataEventMap = new ClearanceEventData();
		Set<String> testSet = new HashSet<>();
		testSet.add("S_2222_MM");
		testSet.add("S_1111_MM");
		storeClearanceDataEventMap.put("tpnb:075777636_S_" + formattedEffDate
				+ "_GBP_I", testSet);
		Mockito.verify(clearanceEventHandler, Mockito.times(1))
				.publishEventsForClearances(argumentMap.capture());
		assertEquals(storeClearanceDataEventMap, argumentMap.getValue());
	}

	@Test
	public void shouldNotInvokePublishEventsForMMClearancesForUKStoreDataInserts()
			throws Exception {
		runIdentifier = "mmemer";
		DateTime dateTime = new DateTime();
		DateTime dateTimeMinusDays = dateTime.minusDays(10);
		end_date1 = dateFormat.format(dateTimeMinusDays.toDate().getTime());
		String line1 = "6075777636     1111" + eff_date1 + "SIGBP0000002.00MM"
				+ end_date1 + "HP20013";
		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "GBP";
		ConstructProductAndTpncMapping(productId, tpnc);
		when(mmClrFileReader.readLine()).thenReturn(line1).thenReturn(null);
		this.mmWriter.write("");
		ArgumentCaptor<ClearanceEventData> argumentMap = ArgumentCaptor
				.forClass(ClearanceEventData.class);
		Mockito.verify(clearanceEventHandler, Mockito.times(0))
				.publishEventsForClearances(argumentMap.capture());
	}

	@Test
	public void shouldInvokePublishEventsForMMClearancesForIEStoreDataDelete()
			throws Exception {
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 10);
		String eff_date = dateFormat.format(cal.getTime());
		cal.add(Calendar.DATE, 10);
		String end_date = dateFormat.format(cal.getTime());
		String line1 = "6075777636     1111" + eff_date + "SIEU 0000005.00MM"
				+ end_date + "HP20013";
		String line2 = "6075777636     2222" + eff_date + "SIEU 0000005.00MM"
				+ end_date + "HP20013";
		String line3 = "6075777636     1111" + eff_date + "SDEU 0000005.00MM"
				+ end_date + "HP20013";
		String line4 = "6075777636     2222" + eff_date + "SDEU 0000005.00MM"
				+ end_date + "HP20013";

		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "EUR";

		// inserting the Nat Clr first
		ConstructProductAndTpncMapping(productId, tpnc);
		insertClearanceProduct(clearanceProductMapper
				.mapLineDataToClearanceMMProduct(line1, true, runIdentifier));
		insertClearanceProduct(clearanceProductMapper
				.mapLineDataToClearanceMMProduct(line2, true, runIdentifier));
		when(mmClrFileReader.readLine()).thenReturn(line3).thenReturn(line4)
				.thenReturn(null);

		ArgumentCaptor<ClearanceEventData> argumentMap = ArgumentCaptor
				.forClass(ClearanceEventData.class);
		Map<String, Set<String>> storeClearanceDataEventMap = new HashMap<>();
		Set<String> testSet = new HashSet<>();
		testSet.add("S_2222_MM");
		testSet.add("S_1111_MM");
		storeClearanceDataEventMap.put(
				"tpnb:075777636_S_"
						+ Dockyard.getISO8601FormatStartDate(eff_date)
						+ "_EU_D", testSet);
		mmWriter.write("");
		Mockito.verify(clearanceEventHandler, Mockito.times(1))
				.publishEventsForClearances(argumentMap.capture());
		assertEquals(storeClearanceDataEventMap, argumentMap.getValue());
	}

	@Test
	public void shouldNotInvokePublishEventsForExpiredMMClearancesForUKStoreDataDelete()
			throws Exception {
		runIdentifier = "mmemer";
		DateTime dateTime = new DateTime();
		DateTime dateTimeMinusDays = dateTime.minusDays(10);
		end_date1 = dateFormat.format(dateTimeMinusDays.toDate().getTime());
		String line1 = "6075777636         " + eff_date1 + "SDGBP0000002.00MM"
				+ end_date1 + "HP20013";
		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "GBP";
		ConstructProductAndTpncMapping(productId, tpnc);
		when(mmClrFileReader.readLine()).thenReturn(line1).thenReturn(null);
		mmWriter.write("");
		ArgumentCaptor<ClearanceEventData> argumentMap = ArgumentCaptor
				.forClass(ClearanceEventData.class);
		Mockito.verify(clearanceEventHandler, Mockito.times(0))
				.publishEventsForClearances(argumentMap.capture());
	}

	@Test
	public void shouldWriteClearanceEventMaptoFileInCaseOfFailure()
			throws Exception {
		DateTime dateTime = new DateTime();
		String eff_date2 = dateFormat.format(dateTime.toDate().getTime());
		String formattedEffDate = Dockyard.getISO8601FormatStartDate(eff_date2);
		String line1 = "6075777636     1111" + eff_date2 + "SIGBP0000002.00MM"
				+ end_date1 + "HP20013";
		String line2 = "6075777636     ";
		String tpnc = "281837179";
		String productId = "075777636";
		ConstructProductAndTpncMapping(productId, tpnc);
		when(mmClrFileReader.readLine()).thenReturn(line1).thenReturn(line2)
				.thenReturn(null);
		this.mmWriter.write("");

		// ArgumentCaptor<ClearanceEventData> argumentMap =
		// ArgumentCaptor.forClass(ClearanceEventData.class);
		ClearanceEventData storeClearanceDataEventMap = new ClearanceEventData();
		Set<String> testSet = new HashSet<>();
		testSet.add("S_1111_MM");
		storeClearanceDataEventMap.put("tpnb:075777636_S_" + formattedEffDate
				+ "_GBP_I", testSet);

		// Actual EventMap Data reading from file.
		File mmClrFailedDatfile = new File(
				testConfiguration.getMmClrImportFailedFile() + "/RR_MM_"
						+ runIdentifier + ".txt");
		File mmClrFailedMapfile = new File(
				testConfiguration.getMmClrImportFailedFile()
						+ "/RR_MM_EVENTMAP_" + runIdentifier + ".txt");
		ObjectMapper mapper = new ObjectMapper();
		ClearanceEventData clearanceFailedDataEventMap = mapper.readValue(
				mmClrFailedMapfile, new TypeReference<ClearanceEventData>() {
				});

		assertTrue(mmClrFailedMapfile.exists());
		assertEquals(storeClearanceDataEventMap, clearanceFailedDataEventMap);
		// removing files from the location
		Files.deleteIfExists(mmClrFailedMapfile.toPath());
		Files.deleteIfExists(mmClrFailedDatfile.toPath());

	}

	@Test
	public void shouldWriteClearanceEventMaptoFileInCaseOfDeleteFailure()
			throws Exception {
		DateTime dateTime = new DateTime();
		String eff_date2 = dateFormat.format(dateTime.toDate().getTime());
		String formattedEffDate = Dockyard.getISO8601FormatStartDate(eff_date2);
		String line1 = "6075777636     1111" + eff_date2 + "SIGBP0000002.00MM"
				+ eff_date1 + "HP20013";
		String line2 = "6075777636     	  " + null + "SDGBP0000002.00MM" + null
				+ "HP20013";
		String tpnc = "281837179";
		String productId = "075777636";
		// String productId1 = "075777637";
		ConstructProductAndTpncMapping(productId, tpnc);
		when(mmClrFileReader.readLine()).thenReturn(line1).thenReturn(line2)
				.thenReturn(null);
		this.mmWriter.write("");

		// ArgumentCaptor<ClearanceEventData> argumentMap =
		// ArgumentCaptor.forClass(ClearanceEventData.class);
		ClearanceEventData storeClearanceDataEventMap = new ClearanceEventData();
		Set<String> testSet = new HashSet<>();
		testSet.add("S_1111_MM");
		storeClearanceDataEventMap.put("tpnb:075777636_S_" + formattedEffDate
				+ "_GBP_I", testSet);

		// Actual EventMap Data reading from file.
		File mmClrFailedDatfile = new File(
				testConfiguration.getMmClrImportFailedFile() + "/RR_MM_"
						+ runIdentifier + ".txt");
		File mmClrFailedMapfile = new File(
				testConfiguration.getMmClrImportFailedFile()
						+ "/RR_MM_EVENTMAP_" + runIdentifier + ".txt");
		ObjectMapper mapper = new ObjectMapper();
		ClearanceEventData clearanceFailedDataEventMap = mapper.readValue(
				mmClrFailedMapfile, new TypeReference<ClearanceEventData>() {
				});

		assertTrue(mmClrFailedMapfile.exists());
		assertEquals(storeClearanceDataEventMap, clearanceFailedDataEventMap);
		// removing files from the location
		Files.deleteIfExists(mmClrFailedMapfile.toPath());
		Files.deleteIfExists(mmClrFailedDatfile.toPath());

	}

	@Test
	public void shouldRestartTestFromFailureEventMapFile() throws Exception {
		DateTime dateTime = new DateTime();
		String eff_date2 = dateFormat.format(dateTime.toDate().getTime());
		String formattedEffDate = Dockyard.getISO8601FormatStartDate(eff_date2);
		String line1 = "6075777636     1111" + eff_date2 + "SIGBP0000002.00MM"
				+ eff_date1 + "HP20013";
		ClearanceEventData failedStoreClearanceDataEventMap = new ClearanceEventData();
		Set<String> failedtestSet = new HashSet<>();
		failedtestSet.add("S_2222_MM");
		failedStoreClearanceDataEventMap.put("tpnb:075777636_S_"
				+ formattedEffDate + "_GBP_I", failedtestSet);
		File mmClrFailedMapfile = new File(
				testConfiguration.getMmClrImportFailedFile()
						+ "/RR_MM_EVENTMAP_" + runIdentifier + ".txt");
		constructFailedProduct("075777636");
		ObjectMapper mapper = new ObjectMapper();
		mapper.writeValue(mmClrFailedMapfile, failedStoreClearanceDataEventMap);
		String tpnc = "281837179";
		String productId = "075777636";
		ConstructProductAndTpncMapping(productId, tpnc);
		when(mmClrFileReader.readLine()).thenReturn(line1).thenReturn(null);
		this.mmWriter.write("");

		ArgumentCaptor<ClearanceEventData> argumentMap = ArgumentCaptor
				.forClass(ClearanceEventData.class);
		ClearanceEventData storeClearanceDataEventMap = new ClearanceEventData();
		Set<String> testSet = new HashSet<>();
		testSet.add("S_2222_MM");
		testSet.add("S_1111_MM");
		storeClearanceDataEventMap.put("tpnb:075777636_S_" + formattedEffDate
				+ "_GBP_I", testSet);
		Mockito.verify(clearanceEventHandler, Mockito.times(1))
				.publishEventsForClearances(argumentMap.capture());
		assertEquals(storeClearanceDataEventMap, argumentMap.getValue());

	}

	@Test
	public void shouldRestartTestFromFailureEventMapFileOnDelete()
			throws Exception {
		DateTime dateTime = new DateTime();
		String eff_date2 = dateFormat.format(dateTime.toDate().getTime());
		String formattedEffDate = Dockyard.getISO8601FormatStartDate(eff_date2);
		String line1 = "6075777636     1111" + eff_date2 + "SDGBP0000002.00MM"
				+ eff_date1 + "HP20013";
		ClearanceEventData failedStoreClearanceDataEventMap = new ClearanceEventData();
		Set<String> failedtestSet = new HashSet<>();
		failedtestSet.add("S_2222_MM");
		failedStoreClearanceDataEventMap.put("tpnb:075777636_S_"
				+ formattedEffDate + "_GBP_D", failedtestSet);
		File mmClrFailedMapfile = new File(
				testConfiguration.getMmClrImportFailedFile()
						+ "/RR_MM_EVENTMAP_" + runIdentifier + ".txt");
		constructFailedProduct("075777636");
		ObjectMapper mapper = new ObjectMapper();
		mapper.writeValue(mmClrFailedMapfile, failedStoreClearanceDataEventMap);
		String tpnc = "281837179";
		String productId = "075777636";
		ClearanceByDateTime clearanceByDateTimeForStore = createClearanceByDateTime(
				eff_date2, eff_date1, "MM", "0000002.00");
		ClearanceStoreSaleInfo clearanceStoreSaleInfo = createClearanceStoreSaleInfo(
				" 1111", "UK", "GBP", clearanceByDateTimeForStore);
		final ClearanceMMProduct expectedClearanceMMProduct = createClearanceMMProduct(
				productId, null, clearanceStoreSaleInfo);
		ConstructProductAndTpncMapping(productId, tpnc);
		when(mmClrFileReader.readLine()).thenReturn(line1).thenReturn(null);
		this.mmWriter.write("");

		ArgumentCaptor<ClearanceEventData> argumentMap = ArgumentCaptor
				.forClass(ClearanceEventData.class);
		ClearanceEventData storeClearanceDataEventMap = new ClearanceEventData();
		Set<String> testSet = new HashSet<>();
		testSet.add("S_2222_MM");
		storeClearanceDataEventMap.put("tpnb:075777636_S_" + formattedEffDate
				+ "_GBP_D", testSet);
		Mockito.verify(clearanceEventHandler, Mockito.times(1))
				.publishEventsForClearances(argumentMap.capture());
		assertEquals(storeClearanceDataEventMap, argumentMap.getValue());

	}

	@Test
	public void shouldInvokePublishEventsForMMClearancesForIEStoreDataClrEndDateChangedUpdate()
			throws Exception {
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 10);
		String eff_date = dateFormat.format(cal.getTime());
		Calendar newCal = Calendar.getInstance();
		String end_date = dateFormat.format(newCal.getTime());
		// change the clearance end date
		Calendar newCalEnd = Calendar.getInstance();
		newCalEnd.add(Calendar.DATE, 10);
		String new_end_date = dateFormat.format(newCalEnd.getTime());
		String line1 = "6075777636     1111" + eff_date + "SIEU 0000005.00MM"
				+ end_date + "HP20013";
		String line2 = "6075777636     1111" + eff_date + "SUEU 0000005.00MM"
				+ new_end_date + "HP20013";

		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "EUR";

		// inserting the Nat Clr first
		ConstructProductAndTpncMapping(productId, tpnc);
		insertClearanceProduct(clearanceProductMapper
				.mapLineDataToClearanceMMProduct(line1, true, runIdentifier));
		when(mmClrFileReader.readLine()).thenReturn(line2).thenReturn(null);

		ArgumentCaptor<ClearanceEventData> argumentMap = ArgumentCaptor
				.forClass(ClearanceEventData.class);
		ClearanceEventData storeClearanceDataEventMap = new ClearanceEventData();
		Set<String> testSet = new HashSet<>();
		testSet.add("S_1111_MM");
		String key = "tpnb:075777636_S_"
				+ Dockyard.getISO8601FormatStartDate(end_date)
				+ "_EU_U-CLR-END-DATE";
		storeClearanceDataEventMap.put(key, testSet);
		mmWriter.write("");
		Mockito.verify(clearanceEventHandler, Mockito.times(1))
				.publishEventsForClearances(argumentMap.capture());
		assertEquals(storeClearanceDataEventMap, argumentMap.getValue());
	}

	@Test
	public void shouldNotInvokePublishEventsForMMClearancesForIEStoreDataClrEndDateNotChangedUpdate()
			throws Exception {
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 10);
		String eff_date = dateFormat.format(cal.getTime());
		Calendar newCal = Calendar.getInstance();
		String end_date = dateFormat.format(newCal.getTime());
		String line1 = "6075777636     1111" + eff_date + "SIEU 0000005.00MM"
				+ end_date + "HP20013";
		String line2 = "6075777636     1111" + eff_date + "SUEU 0000005.00MM"
				+ end_date + "HP20013";

		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "EUR";

		// inserting the Nat Clr first
		ConstructProductAndTpncMapping(productId, tpnc);
		insertClearanceProduct(clearanceProductMapper
				.mapLineDataToClearanceMMProduct(line1, true, runIdentifier));
		when(mmClrFileReader.readLine()).thenReturn(line2).thenReturn(null);

		ArgumentCaptor<ClearanceEventData> argumentMap = ArgumentCaptor
				.forClass(ClearanceEventData.class);
		mmWriter.write("");
		Mockito.verify(clearanceEventHandler, Mockito.times(0))
				.publishEventsForClearances(argumentMap.capture());
	}

	@Test
	public void shouldNotInvokePublishEventsForExpiredMMClearancesForUKStoreDataClrEndDateChangedUpdate()
			throws Exception {
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 10);
		String eff_date = dateFormat.format(cal.getTime());
		Calendar newCal = Calendar.getInstance();
		String end_date = dateFormat.format(newCal.getTime());
		newCal.add(Calendar.DATE, 10);
		// change the clearance end date
		String new_end_date = dateFormat.format(newCal.getTime());
		Calendar expiredCal = Calendar.getInstance();
		expiredCal.add(Calendar.DATE, -100);
		String exp_end_date = dateFormat.format(expiredCal.getTime());
		String line1 = "6075777636     1111" + eff_date + "SIEU 0000005.00MM"
				+ end_date + "HP20013";
		String line2 = "6075777636     1111" + eff_date + "SUEU 0000005.00MM"
				+ exp_end_date + "HP20013";

		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "EUR";

		// inserting the Nat Clr first
		ConstructProductAndTpncMapping(productId, tpnc);
		insertClearanceProduct(clearanceProductMapper
				.mapLineDataToClearanceMMProduct(line1, true, runIdentifier));
		when(mmClrFileReader.readLine()).thenReturn(line2).thenReturn(null);

		ArgumentCaptor<ClearanceEventData> argumentMap = ArgumentCaptor
				.forClass(ClearanceEventData.class);
		mmWriter.write("");
		Mockito.verify(clearanceEventHandler, Mockito.times(0))
				.publishEventsForClearances(argumentMap.capture());
	}

	@Test
	public void shouldInvokePublishEventsForMMClearancesCreatedIEStoreDataClrEndDateNotExists()
			throws Exception {
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 10);
		String eff_date = dateFormat.format(cal.getTime());
		Calendar newCal = Calendar.getInstance();
		String end_date = dateFormat.format(newCal.getTime());
		// change the clearance end date
		Calendar newCalEnd = Calendar.getInstance();
		newCalEnd.add(Calendar.DATE, 10);
		String new_end_date = dateFormat.format(newCalEnd.getTime());
		String line1 = "6075777636     1111" + eff_date + "SUEU 0000005.00MM"
				+ new_end_date + "HP20013";

		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "EUR";

		// inserting the Nat Clr first
		ConstructProductAndTpncMapping(productId, tpnc);
		when(mmClrFileReader.readLine()).thenReturn(line1).thenReturn(null);

		ArgumentCaptor<ClearanceEventData> argumentMap = ArgumentCaptor
				.forClass(ClearanceEventData.class);
		ClearanceEventData storeClearanceDataEventMap = new ClearanceEventData();
		Set<String> testSet = new HashSet<>();
		testSet.add("S_1111_MM");
		String key = "tpnb:075777636_S_"
				+ Dockyard.getISO8601FormatStartDate(eff_date) + "_EU_I";
		storeClearanceDataEventMap.put(key, testSet);
		mmWriter.write("");
		Mockito.verify(clearanceEventHandler, Mockito.times(1))
				.publishEventsForClearances(argumentMap.capture());
		assertEquals(storeClearanceDataEventMap, argumentMap.getValue());
	}

	@Test
	public void shouldInvokePublishEventsForMMClearancesForIENatDataClrEndDateChangedUpdate()
			throws Exception {
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 10);
		String eff_date = dateFormat.format(cal.getTime());
		Calendar newCal = Calendar.getInstance();
		String end_date = dateFormat.format(newCal.getTime());
		// change the clearance end date
		Calendar newCalEnd = Calendar.getInstance();
		newCalEnd.add(Calendar.DATE, 10);
		String new_end_date = dateFormat.format(newCalEnd.getTime());
		String line1 = "6075777636         " + eff_date + "NIEU 0000005.00MM"
				+ end_date + "HP20013";
		String line2 = "6075777636         " + eff_date + "NUEU 0000005.00MM"
				+ new_end_date + "HP20013";

		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "EUR";

		// inserting the Nat Clr first
		ConstructProductAndTpncMapping(productId, tpnc);
		insertClearanceProduct(clearanceProductMapper
				.mapLineDataToClearanceMMProduct(line1, true, runIdentifier));
		when(mmClrFileReader.readLine()).thenReturn(line2).thenReturn(null);

		ArgumentCaptor<ClearanceEventData> argumentMap = ArgumentCaptor
				.forClass(ClearanceEventData.class);
		ClearanceEventData nationalClearanceDataEventMap = new ClearanceEventData();
		Set<String> testSet = new HashSet<>();
		testSet.add("Z_21_MM");
		String key = "tpnb:075777636_N_"
				+ Dockyard.getISO8601FormatStartDate(end_date)
				+ "_EU_U-CLR-END-DATE";
		nationalClearanceDataEventMap.put(key, testSet);
		mmWriter.write("");
		Mockito.verify(clearanceEventHandler, Mockito.times(1))
				.publishEventsForClearances(argumentMap.capture());
		assertEquals(nationalClearanceDataEventMap, argumentMap.getValue());
	}

	@Test
	public void shouldNotInvokePublishEventsForMMClearancesForIENatDataClrEndDateNotChangedUpdate()
			throws Exception {
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 10);
		String eff_date = dateFormat.format(cal.getTime());
		Calendar newCal = Calendar.getInstance();
		String end_date = dateFormat.format(newCal.getTime());
		String line1 = "6075777636         " + eff_date + "NIEU 0000005.00MM"
				+ end_date + "HP20013";
		String line2 = "6075777636         " + eff_date + "NUEU 0000005.00MM"
				+ end_date + "HP20013";

		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "EUR";

		// inserting the Nat Clr first
		ConstructProductAndTpncMapping(productId, tpnc);
		insertClearanceProduct(clearanceProductMapper
				.mapLineDataToClearanceMMProduct(line1, true, runIdentifier));
		when(mmClrFileReader.readLine()).thenReturn(line2).thenReturn(null);

		ArgumentCaptor<ClearanceEventData> argumentMap = ArgumentCaptor
				.forClass(ClearanceEventData.class);
		ClearanceEventData nationalClearanceDataEventMap = new ClearanceEventData();
		Set<String> testSet = new HashSet<>();
		testSet.add("Z_21_MM");
		String key = "075777636_N_"
				+ Dockyard.getISO8601FormatStartDate(end_date) + "_EU_U";
		nationalClearanceDataEventMap.put(key, testSet);
		mmWriter.write("");
		Mockito.verify(clearanceEventHandler, Mockito.times(0))
				.publishEventsForClearances(argumentMap.capture());
	}

	@Test
	public void shouldNotInvokePublishEventsForExpiredMMClearancesForUKNatDataClrEndDateChangedUpdate()
			throws Exception {
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 10);
		String eff_date = dateFormat.format(cal.getTime());
		Calendar newCal = Calendar.getInstance();
		String end_date = dateFormat.format(newCal.getTime());
		newCal.add(Calendar.DATE, 10);
		// change the clearance end date
		String new_end_date = dateFormat.format(newCal.getTime());
		Calendar expiredCal = Calendar.getInstance();
		expiredCal.add(Calendar.DATE, -100);
		String exp_end_date = dateFormat.format(expiredCal.getTime());
		String line1 = "6075777636         " + eff_date + "NIEU 0000005.00MM"
				+ end_date + "HP20013";
		String line2 = "6075777636         " + eff_date + "NUEU 0000005.00MM"
				+ exp_end_date + "HP20013";

		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "EUR";

		// inserting the Nat Clr first
		ConstructProductAndTpncMapping(productId, tpnc);
		insertClearanceProduct(clearanceProductMapper
				.mapLineDataToClearanceMMProduct(line1, true, runIdentifier));
		when(mmClrFileReader.readLine()).thenReturn(line2).thenReturn(null);

		ArgumentCaptor<ClearanceEventData> argumentMap = ArgumentCaptor
				.forClass(ClearanceEventData.class);
		mmWriter.write("");
		Mockito.verify(clearanceEventHandler, Mockito.times(0))
				.publishEventsForClearances(argumentMap.capture());
	}

	@Test
	public void shouldInvokePublishEventsForMMClearancesCreatedIENatDataClrEndDateNotExists()
			throws Exception {
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 10);
		String eff_date = dateFormat.format(cal.getTime());
		Calendar newCal = Calendar.getInstance();
		String end_date = dateFormat.format(newCal.getTime());
		// change the clearance end date
		Calendar newCalEnd = Calendar.getInstance();
		newCalEnd.add(Calendar.DATE, 10);
		String new_end_date = dateFormat.format(newCalEnd.getTime());
		String line1 = "6075777636         " + eff_date + "NUEU 0000005.00MM"
				+ new_end_date + "HP20013";

		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "EUR";

		// inserting the Nat Clr first
		ConstructProductAndTpncMapping(productId, tpnc);
		when(mmClrFileReader.readLine()).thenReturn(line1).thenReturn(null);

		ArgumentCaptor<ClearanceEventData> argumentMap = ArgumentCaptor
				.forClass(ClearanceEventData.class);
		ClearanceEventData nationalClearanceDataEventMap = new ClearanceEventData();
		Set<String> testSet = new HashSet<>();
		testSet.add("Z_21_MM");
		String key = "tpnb:075777636_N_"
				+ Dockyard.getISO8601FormatStartDate(eff_date) + "_EU_I";
		nationalClearanceDataEventMap.put(key, testSet);
		mmWriter.write("");
		Mockito.verify(clearanceEventHandler, Mockito.times(1))
				.publishEventsForClearances(argumentMap.capture());
		assertEquals(nationalClearanceDataEventMap, argumentMap.getValue());
	}

	protected ClearanceByDateTime createClearanceByDateTime(String effcDate,
			String endDate, String clrRef, String clrPrice)
			throws ParseException {
		ClearanceByDateTime clearanceByDateTime = new ClearanceByDateTime();
		clearanceByDateTime.setEffvDateTime(Dockyard
				.getISO8601FormatStartDate(effcDate));
		clearanceByDateTime.setEndDateTime(Dockyard
				.getISO8601FormatEndDate(endDate));
		clearanceByDateTime.setClearanceRef(clrRef);
		clearanceByDateTime.setClearancePrice(Dockyard.priceScaleRoundHalfUp(
				currencyCode, clrPrice));
		return clearanceByDateTime;
	}

	protected ClearanceZoneSaleInfo createClearanceZoneSaleInfo(String zone,
			String country, String currency,
			ClearanceByDateTime clearanceByDateTime) throws ParseException {
		ClearanceZoneSaleInfo clearanceZoneSaleInfo = new ClearanceZoneSaleInfo();
		clearanceZoneSaleInfo.setClearanceZoneId(zone);
		clearanceZoneSaleInfo.setCountryCode(country);
		clearanceZoneSaleInfo.setCurrency(currency);
		if (clearanceByDateTime != null) {
			clearanceZoneSaleInfo
					.addZoneClearanceByDateTime(clearanceByDateTime);
		}
		return clearanceZoneSaleInfo;
	}

	protected ClearanceStoreSaleInfo createClearanceStoreSaleInfo(String store,
			String country, String currency,
			ClearanceByDateTime clearanceByDateTime) throws ParseException {
		ClearanceStoreSaleInfo clearanceStoreSaleInfo = new ClearanceStoreSaleInfo();
		clearanceStoreSaleInfo.setClearanceStoreId(store.trim());
		clearanceStoreSaleInfo.setCountryCode(country);
		clearanceStoreSaleInfo.setCurrency(currency);
		if (clearanceByDateTime != null) {
			clearanceStoreSaleInfo
					.addStoreClearanceByDateTime(clearanceByDateTime);
		}
		return clearanceStoreSaleInfo;
	}

	protected ClearanceMMProduct createClearanceMMProduct(String productId,
			ClearanceZoneSaleInfo clearanceZoneSaleInfo,
			ClearanceStoreSaleInfo clearanceStoreSaleInfo) {
		ClearanceMMProduct clearanceProduct = new ClearanceMMProduct(productId);
		String docType = "datedPrice";
		String dateTimeFormat = "ISO8601";
		String countryFormat = "ISO3166";
		String currencyFormat = "ISO4217";
		String version = "1.0";
		String prodType = "tpnb";
		clearanceProduct.setVersionNo(version);
		clearanceProduct.setDocType(docType);
		clearanceProduct.setCountryFormat(countryFormat);
		clearanceProduct.setCurrencyFormat(currencyFormat);
		clearanceProduct.setDateTimeFormat(dateTimeFormat);
		clearanceProduct.setProdType(prodType);
		clearanceProduct.setSellingUom(sellingUom);
		if (clearanceZoneSaleInfo != null) {
			clearanceProduct.addClearanceZoneSaleInfo(clearanceZoneSaleInfo);
		}
		if (clearanceStoreSaleInfo != null) {
			clearanceProduct.addClearanceStoreSaleInfo(clearanceStoreSaleInfo);
		}
		return clearanceProduct;
	}

	protected void ConstructProductAndTpncMapping(String tpnb, String tpnc)
			throws Exception {
		Product product = new Product(tpnb);
		ProductVariant productVariant = new ProductVariant(tpnc);
		productVariant.setSellingUOM(sellingUom);
		product.addProductVariant(productVariant);
		repositoryImpl.insertObject(PriceConstants.PRODUCT_KEY_PREFIX+product.getTPNB(),product);
		repositoryImpl.mapLookUps(tpnb, tpnc);

	}

	protected void insertClearanceProduct(
			ClearanceMMProduct clearanceProductTobeInserted) throws Exception {
		repositoryImpl
				.insertObject(PriceConstants.CLEARANCE_MM_PRODUCT_KEY_PREFIX
						+ clearanceProductTobeInserted.getProductId(),
						clearanceProductTobeInserted);
	}

	private void constructFailedProduct(String value) throws IOException {
		ImportResource.importSemaphoreForIdentifier.put(runIdentifier,
				new Semaphore(1));
		File f = new File(testConfiguration.getMmClrImportFailedFile()
				+ "/RR_MM_" + runIdentifier + ".txt");
		FileWriter fileWriter = new FileWriter(f);
		BufferedWriter bw = new BufferedWriter(fileWriter);
		bw.write(value);
		bw.flush();
		bw.close();
	}

	private String getfailedProductInProviousRunIfExist(String file)
			throws IOException {
		File mmClrFailedDatafile = new File(file);
		FileReader reader;
		String line;
		BufferedReader rpmClrFailedFileReader;
		String failedProduct = "";
		try {
			reader = new FileReader(mmClrFailedDatafile);
			rpmClrFailedFileReader = new BufferedReader(reader);
			while ((line = rpmClrFailedFileReader.readLine()) != null) {
				failedProduct = line;
			}
			rpmClrFailedFileReader.close();
		} catch (FileNotFoundException e) {
			return null;
		} catch (IOException e) {
			return null;
		}
		return failedProduct;
	}
}
