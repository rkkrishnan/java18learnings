package com.tesco.services.resources;

import static org.fest.assertions.api.Assertions.assertThat;
import io.dropwizard.testing.junit.ResourceTestRule;

import java.io.IOException;
import java.util.concurrent.Semaphore;

import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

import org.junit.After;
import org.junit.Before;
import org.junit.ClassRule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.tesco.couchbase.AsyncCouchbaseWrapper;
import com.tesco.couchbase.CouchbaseWrapper;
import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.Import;
import com.tesco.services.adapters.core.ImportJob;

@RunWith(MockitoJUnitRunner.class)
public class ImportProgressErrorTest {

	@Mock
	private static CouchbaseWrapper couchbaseWrapper;
	@Mock
	private static AsyncCouchbaseWrapper asyncCouchbaseWrapper;

	private static Configuration mockConfiguration = TestConfiguration.load();

	@Mock
	private static Import mockImportJob;

	@Before
	public void setUpResources() throws Exception {
		ImportResource.getImportSemaphore().release();

		ImportJob.setErrorString("ERROR");

		ImportResource.importSemaphoreForIdentifier
				.put("123", new Semaphore(1));

		ImportResource.setErrorString("123", "ERROR");

	}

	@ClassRule
	public static final ResourceTestRule resources = ResourceTestRule
			.builder()
			.addResource(
					new ImportResource(mockConfiguration, mockImportJob, null,
							null, null, null, null, null, null, null, null,
							null)).build();

	@Test
	public void shouldReturnImportError() throws IOException {
		WebTarget resource = resources.client().target(
				"/admin/importInProgress");
		Response response = resource.request().get();
		String responseText = response.readEntity(String.class);
		assertThat(responseText).isEqualTo(
				"{\"import\":\"aborted\",\n \"error\":\"ERROR\"}");
	}

	@Test
	public void shouldReturnImportErrorWithFilename() throws IOException {
		ImportResource.importSemaphoreForIdentifier.put("1234.csv",
				new Semaphore(1));
		ImportResource.setErrorString("1234.csv", "ERROR");
		WebTarget resource = resources.client().target(
				"/admin/importInProgress/123/1234.csv");
		Response response = resource.request().get();
		String responseText = response.readEntity(String.class);
		assertThat(responseText).isEqualTo(
				"{\"import\":\"aborted\",\n \"error\":\"ERROR\"}");
	}

	@Test
	public void shouldReturnImportError1() throws IOException {
		WebTarget resource = resources.client().target(
				"/admin/importInProgress/123");
		Response response = resource.request().get();
		String responseText = response.readEntity(String.class);
		assertThat(responseText).isEqualTo(
				"{\"import\":\"aborted\",\n \"error\":\"ERROR\"}");
	}

	@After
	public void resetMocks() throws Exception {
		Mockito.reset(couchbaseWrapper);
		Mockito.reset(asyncCouchbaseWrapper);
	}
}
