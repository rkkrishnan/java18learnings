package com.tesco.services.adapters.promotion;

import com.tesco.promotion.core.PrmPrcChgDesc;
import com.tesco.services.adapters.core.exceptions.PromotionEventException;
import com.tesco.services.adapters.promotion.impl.PromotionEventHandlerImpl;
import com.tesco.services.core.ZoneEntity;
import com.tesco.services.event.core.EventTemplate;
import com.tesco.services.event.core.impl.MapEvent;
import com.tesco.services.event.exception.EventPublishException;
import com.tesco.services.repositories.RepositoryImpl;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.ParseMessageUtil;
import com.tesco.services.utility.PriceConstants;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import static com.tesco.services.utility.PriceConstants.*;
import static io.dropwizard.testing.FixtureHelpers.fixture;
import static org.junit.Assert.assertEquals;

@RunWith(MockitoJUnitRunner.class)
public class SimplePromotionEventCreationTest {

	PrmPrcChgDesc promotions;
	PrmPrcChgDesc promotionNegLTD;

	@Mock
	private EventTemplate eventTemplate;

	private PromotionEventHandler promoEventHandler;

	@Mock
	private RepositoryImpl repositoryImpl;

	@Captor
	private ArgumentCaptor<MapEvent> argument;

	@Before
	public void setUp() throws Exception {
		promoEventHandler = new PromotionEventHandlerImpl(eventTemplate,
				repositoryImpl);
		String xmlData = fixture("com/tesco/services/core/fixtures/promotion/SimpleEventCreMessage.xml");
		String xmlDataNegLeadTD = fixture("com/tesco/services/core/fixtures/promotion/SimplePromotionCreMessage.xml");
		ParseMessageUtil parseMessageUtil = ParseMessageUtil.getInstance();
		String promoDescData = parseMessageUtil.getNodeData(xmlData,
				PriceConstants.PROMO_MSG_DATA_PATH);
		String promoDescDataLTD = parseMessageUtil.getNodeData(
				xmlDataNegLeadTD, PriceConstants.PROMO_MSG_DATA_PATH);
		promotions = (PrmPrcChgDesc) parseMessageUtil
				.getMappedObjectForXmlData(PrmPrcChgDesc.class, promoDescData);
		promotionNegLTD = (PrmPrcChgDesc) parseMessageUtil
				.getMappedObjectForXmlData(PrmPrcChgDesc.class,
						promoDescDataLTD);
		ZoneEntity ze = new ZoneEntity();
		ze.setZoneId("12");
		ze.setZoneGroupId("90");
		ze.setTslCountryCode("IE");
		ze.setZoneName("testZone");
		Mockito.when(repositoryImpl.getGenericObject("ZONE_12",ZoneEntity.class)).thenReturn(ze);

	}

	@Test
	public void testEventCreatedForSimplePromotion()
			throws PromotionEventException, ParseException,
			EventPublishException {

		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 5);
		String eff_date = dateFormat.format(cal.getTime());
		String effective_date = Dockyard.getISO8601FormatStartDate(eff_date);

		Map<String, String> eventDataMap = prepareEventDataMap(effective_date);
		promoEventHandler.publishPromotionEvent(eventDataMap);
		Mockito.verify(eventTemplate, Mockito.times(1)).publishEvent(
				argument.capture());
		assertEquals(
				PriceConstants.PROMOTION_MSG_TYPE_CRE,
				String.valueOf((argument.getValue()).getHeaderData().get(
						"EventType")));
		assertEquals(
				5,
				Integer.valueOf(
						(argument.getValue()).getHeaderData().get(
								"LeadTimeDays")).intValue());
		assertEquals(
				"IE:Z:12",
				(argument.getValue()).getHeaderData().get(
						PriceConstants.LOCATION_ID));
		assertEquals(
				"1559883",
				(argument.getValue()).getPayloadData().get(
						PriceConstants.OFFER_ID));

	}

	@Test
	public void testNegativeLeadTimeDays() throws PromotionEventException,
			ParseException, EventPublishException {

		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -4);
		String eff_date = dateFormat.format(cal.getTime());
		String effective_date = Dockyard.getISO8601FormatStartDate(eff_date);

		Map<String, String> eventDataMap = prepareEventDataMap(effective_date);
		promoEventHandler.publishPromotionEvent(eventDataMap);
		Mockito.verify(eventTemplate, Mockito.times(1)).publishEvent(
				argument.capture());
		assertEquals(
				PriceConstants.PROMOTION_MSG_TYPE_CRE,
				String.valueOf((argument.getValue()).getHeaderData().get(
						"EventType")));
		assertEquals(
				-4,
				Integer.valueOf(
						(argument.getValue()).getHeaderData().get(
								"LeadTimeDays")).intValue());
		assertEquals(
				"IE:Z:12",
				(argument.getValue()).getHeaderData().get(
						PriceConstants.LOCATION_ID));
		assertEquals(
				"1559883",
				(argument.getValue()).getPayloadData().get(
						PriceConstants.OFFER_ID));

	}

	private Map<String, String> prepareEventDataMap(String effectiveDate) {
		Map<String, String> promotionEventDataMap = new HashMap<>();

		promotionEventDataMap.put(LOC_REF, "12");
		promotionEventDataMap.put(LOC_TYPE, "Z");
		promotionEventDataMap.put(OFFER_ID, "1559883");
		promotionEventDataMap.put(EFFECTIVE_DATE, effectiveDate);
		promotionEventDataMap.put(EVENT_TYPE, PROMOTION_MSG_TYPE_CRE);
		return promotionEventDataMap;
	}
}
