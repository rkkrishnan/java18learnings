package com.tesco.services.utility;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import java.util.LinkedHashSet;
import java.util.Set;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.tesco.services.Configuration;
import com.tesco.services.resources.TestConfiguration;

/**
 * Created by QU17 on 3/31/2015.
 */
@RunWith(MockitoJUnitRunner.class)
public class WebServiceCallBuilderTest {

	private static Configuration testConfiguration;

	private WebServiceCallBuilder webServiceCallBuilder;

	private Client client;

	@Before
	public void setUp() throws Exception {
		testConfiguration = TestConfiguration.load();
		webServiceCallBuilder = new WebServiceCallBuilder(testConfiguration);
	}

	@Test
	public void checkResponseForListWithOutStrore() {
		Set<String> prods = new LinkedHashSet<>();
		String storeId = null;
		Response response = webServiceCallBuilder
				.getResponseFromRemoteServerForProductsListWithStore(prods,
						storeId);
		assertThat(response.getStatus()).isEqualTo(400);

	}

	@Test
	public void checkResponseForListWithStrore() {
		Set<String> prods = new LinkedHashSet<>();
		String storeId = "1234";
		Response response = webServiceCallBuilder
				.getResponseFromRemoteServerForProductsListWithStore(prods,
						storeId);
		assertThat(response.getStatus()).isEqualTo(400);
	}

	@Test
	public void checkResponseFromProdServices() {
		String prodServiceUrl = "prodServiceUrl";
		client = Mockito.mock(Client.class);
		WebTarget resource = Mockito.mock(WebTarget.class);
		when(client.target(prodServiceUrl)).thenReturn(resource);
		Invocation.Builder builder = Mockito.mock(Invocation.Builder.class);
		when(resource.request()).thenReturn(builder);
		when(builder.get()).thenReturn(null);

		webServiceCallBuilder.setClient(client);
		Response response = webServiceCallBuilder
				.getResponseFromProdServices(prodServiceUrl);
		assertThat(response).isEqualTo(null);
	}
}
