package com.tesco.services.adapters.rpm.readers;

import static org.fest.assertions.api.Assertions.assertThat;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Map;

import com.tesco.services.adapters.rpm.readers.impl.PriceServiceRPMClearanceCSVReaderImpl;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import au.com.bytecode.opencsv.CSVReader;

import com.tesco.services.adapters.core.exceptions.ColumnNotFoundException;

@RunWith(MockitoJUnitRunner.class)
public class PriceServiceRPMClearanceCSVReaderImplTest {

	@Mock
	CSVReader mockCSVReader;

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
		Mockito.reset(mockCSVReader);
	}

	@Test
	public void testGetNext() throws IOException, ColumnNotFoundException {

		String[] headers = { "column1", "column2", "column3" };
		String[] values = { "1", "test", "23" };

		try {
			PriceServiceCSVReader dummyReader = new PriceServiceRPMClearanceCSVReaderImpl(
					"src/main/resources/com/tesco/services/adapters/mm/mmreg/MM_CLR_DATA.dat",
					headers);
		} catch (FileNotFoundException fnfe) {
			assertThat("iexpected").isEqualTo("iexpected");
		}

		PriceServiceCSVReader myPriceServiceCSVReader = new PriceServiceRPMClearanceCSVReaderImpl(
				mockCSVReader, headers);

		Mockito.doReturn(values).when(mockCSVReader).readNext();

		Map<String, String> myMap = myPriceServiceCSVReader.getNext();

		assertThat(myMap.get("column1")).isEqualTo("1");
		assertThat(myMap.get("column2")).isEqualTo("test");
		assertThat(myMap.get("column3")).isEqualTo("23");

		Mockito.doReturn(null).when(mockCSVReader).readNext();

		assertThat(myPriceServiceCSVReader.getNext()).isEqualTo(null);

	}

}
