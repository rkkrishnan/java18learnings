package com.tesco.services.adapters.core.utils;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.management.AttributeNotFoundException;
import javax.management.InstanceNotFoundException;
import javax.management.MBeanException;
import javax.management.MBeanServerConnection;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import javax.management.ReflectionException;
import javax.management.remote.JMXConnector;

import org.glassfish.hk2.api.ServiceLocator;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.powermock.reflect.Whitebox;

import com.tesco.services.Configuration;
import com.tesco.services.exceptions.PriceJMXException;
import com.tesco.services.exceptions.PromoJMXException;
import com.tesco.services.resources.TestConfiguration;

public class JMXClientImplTest {

	MBeanServerConnection mockMBeanServerConn;

	JMXConnector mockConnector;

	JMXClientImpl jmxClient;

	Configuration mockConfiguration;

	ServiceLocator serviceLocator;

	@Before
	public void setUp() throws Exception {
		mockConfiguration = TestConfiguration.load();
		serviceLocator = Mockito.mock(ServiceLocator.class);
		jmxClient = new JMXClientImpl(mockConfiguration, serviceLocator);
	}

	@Test
	public void testInitializeJMXConnector() throws Exception {
		JMXConnector localConnector = Whitebox.<JMXConnector> invokeMethod(
				jmxClient, "initializeJMXConnector");
		Assert.assertNull(localConnector);
	}

	@Test
	public void testInitializeMBeanConnection() throws Exception {
		mockConnector = Mockito.mock(JMXConnector.class);
		Mockito.when(mockConnector.getMBeanServerConnection()).thenReturn(null);
		jmxClient.setConnector(mockConnector);
		MBeanServerConnection localConnection = Whitebox
				.<MBeanServerConnection> invokeMethod(jmxClient,
						"initializeMBeanConnection");
		Assert.assertNull(localConnection);
	}

	@Test
	public void testInitializeMBeanConnectionException() throws Exception {
		mockConnector = Mockito.mock(JMXConnector.class);
		Mockito.when(mockConnector.getMBeanServerConnection()).thenThrow(
				new IOException());
		jmxClient.setConnector(mockConnector);
		MBeanServerConnection localConnection = null;
		try {
			localConnection = Whitebox.<MBeanServerConnection> invokeMethod(
					jmxClient, "initializeMBeanConnection");
		} catch (Exception e) {
			Assert.assertTrue(e instanceof PromoJMXException);
		}
		Assert.assertNull(localConnection);
	}

	@Test
	public void testInitializeMBeanConnectionNoConnector() throws Exception {
		mockConnector = Mockito.mock(JMXConnector.class);
		Mockito.when(mockConnector.getMBeanServerConnection()).thenThrow(
				new IOException());
		MBeanServerConnection localConnection = null;
		try {
			localConnection = Whitebox.<MBeanServerConnection> invokeMethod(
					jmxClient, "initializeMBeanConnection");
		} catch (Exception e) {
			Assert.assertNull(localConnection);
		}

	}

	@Test
	public void testResetPromotionMetrics() throws PromoJMXException {

		PromotionMetrics promoMetrics = Mockito.mock(PromotionMetrics.class);

		Mockito.doNothing().when(promoMetrics).resetMetrics();

		Mockito.when(
				serviceLocator.getService(PromotionMetrics.class,
						"promotionMetricsListener")).thenReturn(promoMetrics);

		jmxClient.resetPromotionMetrics();

		Assert.assertTrue(true);
	}

	@Test
	public void testGetPromotionLoadMetricsException() {
		mockMBeanServerConn = Mockito.mock(MBeanServerConnection.class);

		mockConnector = Mockito.mock(JMXConnector.class);
		try {
			jmxClient.setConnector(mockConnector);
			Mockito.when(mockConnector.getMBeanServerConnection()).thenThrow(
					new IOException("unable to connect"));
			jmxClient.getPromotionLoadMetrics();
		} catch (IOException | PromoJMXException e) {
			Assert.assertTrue(e instanceof PromoJMXException);
		}

	}

	@Test
	public void testGetPromotionLoadMetrics() throws IOException,
			AttributeNotFoundException, InstanceNotFoundException,
			MalformedObjectNameException, MBeanException, ReflectionException,
			PromoJMXException {
		mockMBeanServerConn = Mockito.mock(MBeanServerConnection.class);

		for (ObjectName promoMetricObjName : getPromotionMetricNameList()) {
			Mockito.when(
					mockMBeanServerConn.getAttribute(promoMetricObjName,
							MetricsConstants.COUNT)).thenReturn("1");
			Mockito.when(
					mockMBeanServerConn.getAttribute(promoMetricObjName,
							MetricsConstants.MIN_RESPONSE_TIME)).thenReturn(
					"12");
			Mockito.when(
					mockMBeanServerConn.getAttribute(promoMetricObjName,
							MetricsConstants.MAX_RESPONSE_TIME)).thenReturn(
					"50");
			Mockito.when(
					mockMBeanServerConn.getAttribute(promoMetricObjName,
							MetricsConstants.MEAN_RESPONSE_TIME)).thenReturn(
					"20");
			Mockito.when(
					mockMBeanServerConn.getAttribute(promoMetricObjName,
							MetricsConstants.RESPONSE_TIME_UNIT)).thenReturn(
					"MILLISECONDS");
			Mockito.when(
					mockMBeanServerConn.getAttribute(promoMetricObjName,
							MetricsConstants.RESPONSE_RATE_IN_A_MINUTE))
					.thenReturn("343.343");
			Mockito.when(
					mockMBeanServerConn.getAttribute(promoMetricObjName,
							MetricsConstants.RESPONSE_RATE_IN_FIVE_MINUTES))
					.thenReturn("232.23");
			Mockito.when(
					mockMBeanServerConn.getAttribute(promoMetricObjName,
							MetricsConstants.RESPONSE_RATE_IN_FIFTEEN_MINUTES))
					.thenReturn("22.23");
			Mockito.when(
					mockMBeanServerConn.getAttribute(promoMetricObjName,
							MetricsConstants.MEAN_RESPONSE_RATE)).thenReturn(
					"67.232");
			Mockito.when(
					mockMBeanServerConn.getAttribute(promoMetricObjName,
							MetricsConstants.RESPONSE_RATE_UNIT)).thenReturn(
					"SECONDS");
		}

		for (ObjectName promoMetricObjName : getPromotionCounterMetricNameList()) {
			Mockito.when(
					mockMBeanServerConn.getAttribute(promoMetricObjName,
							MetricsConstants.COUNT)).thenReturn("1");
		}

		mockConnector = Mockito.mock(JMXConnector.class);
		Mockito.when(mockConnector.getMBeanServerConnection()).thenReturn(
				mockMBeanServerConn);
		jmxClient.setConnector(mockConnector);

		Map<String, TimerMetrics> promoMetrics = jmxClient
				.getPromotionLoadMetrics();

		Assert.assertNotNull(promoMetrics
				.get("OverallPromotionElapsedTimeAndRate - time-to-process-message"));

		Assert.assertNotNull(promoMetrics
				.get("SimplePromotionElapsedTimeAndRate - time-to-process-cre-mod-message"));
		Assert.assertNotNull(promoMetrics
				.get("SimplePromotionElapsedTimeAndRate - time-to-process-del-message"));

		Assert.assertNotNull(promoMetrics
				.get("ThresholdPromotionElapsedTimeAndRate - time-to-process-cre-mod-message"));
		Assert.assertNotNull(promoMetrics
				.get("ThresholdPromotionElapsedTimeAndRate - time-to-process-del-message"));

		Assert.assertNotNull(promoMetrics
				.get("MultibuyPromotionElapsedTimeAndRate - time-to-process-cre-mod-message"));
		Assert.assertNotNull(promoMetrics
				.get("MultibuyPromotionElapsedTimeAndRate - time-to-process-del-message"));
		Assert.assertNotNull(promoMetrics
				.get("PromotionMessageProcessingErrors - total-error-count"));

		Mockito.when(mockConnector.getMBeanServerConnection()).thenReturn(null);
		jmxClient.setConnector(mockConnector);

		try {
			promoMetrics = jmxClient.getPromotionLoadMetrics();
		} catch (PromoJMXException e) {
			Assert.assertTrue(true);
		}

		Mockito.when(
				mockMBeanServerConn
						.getAttribute(
								new ObjectName(
										"\"com.tesco\":name=\"time-to-process-message\",type=\"OverallPromotionElapsedTimeAndRate\""),
								MetricsConstants.COUNT)).thenThrow(
				new AttributeNotFoundException());

		mockConnector = Mockito.mock(JMXConnector.class);
		Mockito.when(mockConnector.getMBeanServerConnection()).thenReturn(
				mockMBeanServerConn);
		jmxClient.setConnector(mockConnector);

		try {
			promoMetrics = jmxClient.getPromotionLoadMetrics();
		} catch (PromoJMXException e) {
			Assert.assertTrue(e.getCause() instanceof AttributeNotFoundException);
		}

	}

	private List<ObjectName> getPromotionMetricNameList()
			throws MalformedObjectNameException {

		List<ObjectName> metricNameList = new LinkedList<ObjectName>();
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-message\",type=\"OverallPromotionElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-cre-mod-message\",type=\"SimplePromotionElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-del-message\",type=\"SimplePromotionElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-cre-mod-message\",type=\"ThresholdPromotionElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-del-message\",type=\"ThresholdPromotionElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-cre-mod-message\",type=\"MultibuyPromotionElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-del-message\",type=\"MultibuyPromotionElapsedTimeAndRate\""));
		return metricNameList;
	}

	private List<ObjectName> getPromotionCounterMetricNameList()
			throws MalformedObjectNameException {

		List<ObjectName> metricNameList = new LinkedList<ObjectName>();
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"total-error-count\",type=\"PromotionMessageProcessingErrors\""));
		return metricNameList;
	}

	@Test
	public void testResetPriceMetrics() throws PriceJMXException {

		PriceMetrics priceMetrics = Mockito.mock(PriceMetrics.class);
		Mockito.doNothing().when(priceMetrics).resetMetrics();
		Mockito.when(
				serviceLocator.getService(PriceMetrics.class,
						"priceMetricsListener")).thenReturn(priceMetrics);
		jmxClient.resetPriceMetrics();
		Assert.assertTrue(true);
	}

	@Test
	public void testGetPriceLoadMetricsException() {

		mockMBeanServerConn = Mockito.mock(MBeanServerConnection.class);
		mockConnector = Mockito.mock(JMXConnector.class);

		try {
			jmxClient.setConnector(mockConnector);
			Mockito.when(mockConnector.getMBeanServerConnection()).thenThrow(
					new IOException("unable to connect"));
			jmxClient.getPriceLoadMetrics();
		} catch (IOException | PriceJMXException e) {
			Assert.assertTrue(e instanceof PriceJMXException);
		}

	}

	@Test
	public void testGetPriceLoadMetrics() throws IOException,
			AttributeNotFoundException, InstanceNotFoundException,
			MalformedObjectNameException, MBeanException, ReflectionException,
			PriceJMXException {

		mockMBeanServerConn = Mockito.mock(MBeanServerConnection.class);

		for (ObjectName priceMetricObjName : getPriceMetricNameList()) {
			Mockito.when(
					mockMBeanServerConn.getAttribute(priceMetricObjName,
							MetricsConstants.COUNT)).thenReturn("1");
			Mockito.when(
					mockMBeanServerConn.getAttribute(priceMetricObjName,
							MetricsConstants.MIN_RESPONSE_TIME)).thenReturn(
					"12");
			Mockito.when(
					mockMBeanServerConn.getAttribute(priceMetricObjName,
							MetricsConstants.MAX_RESPONSE_TIME)).thenReturn(
					"50");
			Mockito.when(
					mockMBeanServerConn.getAttribute(priceMetricObjName,
							MetricsConstants.MEAN_RESPONSE_TIME)).thenReturn(
					"20");
			Mockito.when(
					mockMBeanServerConn.getAttribute(priceMetricObjName,
							MetricsConstants.RESPONSE_TIME_UNIT)).thenReturn(
					"MILLISECONDS");
			Mockito.when(
					mockMBeanServerConn.getAttribute(priceMetricObjName,
							MetricsConstants.RESPONSE_RATE_IN_A_MINUTE))
					.thenReturn("343.343");
			Mockito.when(
					mockMBeanServerConn.getAttribute(priceMetricObjName,
							MetricsConstants.RESPONSE_RATE_IN_FIVE_MINUTES))
					.thenReturn("232.23");
			Mockito.when(
					mockMBeanServerConn.getAttribute(priceMetricObjName,
							MetricsConstants.RESPONSE_RATE_IN_FIFTEEN_MINUTES))
					.thenReturn("22.23");
			Mockito.when(
					mockMBeanServerConn.getAttribute(priceMetricObjName,
							MetricsConstants.MEAN_RESPONSE_RATE)).thenReturn(
					"67.232");
			Mockito.when(
					mockMBeanServerConn.getAttribute(priceMetricObjName,
							MetricsConstants.RESPONSE_RATE_UNIT)).thenReturn(
					"SECONDS");
		}

		for (ObjectName priceMetricObjName : getPriceCounterMetricNameList()) {
			Mockito.when(
					mockMBeanServerConn.getAttribute(priceMetricObjName,
							MetricsConstants.COUNT)).thenReturn("1");
		}

		mockConnector = Mockito.mock(JMXConnector.class);
		Mockito.when(mockConnector.getMBeanServerConnection()).thenReturn(
				mockMBeanServerConn);
		jmxClient.setConnector(mockConnector);

		Map<String, TimerMetrics> priceMetrics = jmxClient
				.getPriceLoadMetrics();

		Assert.assertNotNull(priceMetrics
				.get("OverallPriceElapsedTimeAndRate - time-to-process-message"));
		Assert.assertNotNull(priceMetrics
				.get("PriceElapsedTimeAndRate - time-to-process-cre-message"));
		Assert.assertNotNull(priceMetrics
				.get("PriceElapsedTimeAndRate - time-to-process-del-message"));
		Assert.assertNotNull(priceMetrics
				.get("PriceMessageProcessingErrors - total-error-count"));
		Mockito.when(mockConnector.getMBeanServerConnection()).thenReturn(null);
		jmxClient.setConnector(mockConnector);

		try {
			priceMetrics = jmxClient.getPriceLoadMetrics();
		} catch (PriceJMXException e) {
			Assert.assertTrue(true);
		}

		Mockito.when(
				mockMBeanServerConn
						.getAttribute(
								new ObjectName(
										"\"com.tesco\":name=\"time-to-process-message\",type=\"OverallPriceElapsedTimeAndRate\""),
								MetricsConstants.COUNT)).thenThrow(
				new AttributeNotFoundException());

		mockConnector = Mockito.mock(JMXConnector.class);
		Mockito.when(mockConnector.getMBeanServerConnection()).thenReturn(
				mockMBeanServerConn);
		jmxClient.setConnector(mockConnector);

		try {
			priceMetrics = jmxClient.getPriceLoadMetrics();
		} catch (PriceJMXException e) {
			Assert.assertTrue(e.getCause() instanceof AttributeNotFoundException);
		}

	}

	private List<ObjectName> getPriceMetricNameList()
			throws MalformedObjectNameException {

		List<ObjectName> metricNameList = new LinkedList<ObjectName>();
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-message\",type=\"OverallPriceElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-cre-message\",type=\"PriceElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-del-message\",type=\"PriceElapsedTimeAndRate\""));

		return metricNameList;
	}

	private List<ObjectName> getPriceCounterMetricNameList()
			throws MalformedObjectNameException {

		List<ObjectName> metricNameList = new LinkedList<ObjectName>();

		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"total-error-count\",type=\"PriceMessageProcessingErrors\""));

		return metricNameList;
	}

	@After
	public void tearDown() throws Exception {
	}

}
