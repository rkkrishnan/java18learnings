package com.tesco.services.adapters.rpm.comparators;

import com.google.common.base.Optional;
import com.tesco.services.core.ClearanceMMProduct;
import com.tesco.services.core.ClearanceProduct;
import com.tesco.services.core.Product;
import com.tesco.services.core.Store;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import static org.fest.assertions.api.Assertions.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class RPMComparatorTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testCompareProduct() {
		Product prod1 = null;
		Product prod2 = null;

		boolean isNull = new RPMComparator().compare(prod1, prod2);
		prod1 = Mockito.mock(Product.class);
		prod2 = Mockito.mock(Product.class);
		Mockito.doReturn("123").when(prod1).getTPNB();
		Mockito.doReturn("456").when(prod2).getTPNB();
		boolean isTPNBEqual = new RPMComparator().compare(prod1, prod2);
		Mockito.doReturn("123").when(prod1).getTPNB();
		Mockito.doReturn("123").when(prod2).getTPNB();
		prod1.setLast_updated_date("12122333");
		prod1.setLast_updated_date("12122343");
		boolean isToStringEqual = new RPMComparator().compare(prod1, prod2);
		boolean hasTestCasePassed = false;
		if (isNull == false && isTPNBEqual == false && isToStringEqual == false) {
			hasTestCasePassed = true;
		}
		assertThat(hasTestCasePassed).isEqualTo(true);
	}

	@Test
	public void testCompareStore() {

		Store store1 = null;
		Store store2 = null;
		boolean isNull = new RPMComparator().compare(store1, store2);
		store1 = Mockito.mock(Store.class);
		store2 = Mockito.mock(Store.class);
		Mockito.doReturn("123").when(store1).getStoreId();
		Mockito.doReturn("456").when(store2).getStoreId();
		boolean isIdEqual = new RPMComparator().compare(store1, store2);
		Mockito.doReturn("123").when(store2).getStoreId();
		Mockito.doReturn("USD").when(store1).getCurrency();
		Mockito.doReturn("AUD").when(store2).getCurrency();
		boolean isCurrencyEqual = new RPMComparator().compare(store1, store2);
		Mockito.doReturn("USD").when(store2).getCurrency();
		Mockito.doReturn(Optional.of("123")).when(store1).getPriceZoneId();
		Mockito.doReturn(Optional.of("676")).when(store2).getPriceZoneId();
		boolean isPriceZoneEqual = new RPMComparator().compare(store1, store2);
		Mockito.doReturn(Optional.of("123")).when(store2).getPriceZoneId();
		Mockito.doReturn(Optional.of("123")).when(store1).getPromoZoneId();
		Mockito.doReturn(Optional.of("676")).when(store2).getPromoZoneId();
		boolean isPromoZoneEqual = new RPMComparator().compare(store1, store2);
		Mockito.doReturn("123").when(store1).getStoreId();
		Mockito.doReturn("123").when(store2).getStoreId();
		Mockito.doReturn("USD").when(store1).getCurrency();
		Mockito.doReturn("USD").when(store2).getCurrency();
		Mockito.doReturn(Optional.of("123")).when(store1).getPriceZoneId();
		Mockito.doReturn(Optional.of("123")).when(store2).getPriceZoneId();
		Mockito.doReturn(Optional.of("123")).when(store1).getPromoZoneId();
		Mockito.doReturn(Optional.of("123")).when(store2).getPromoZoneId();
		boolean isIdEqualToReturnTrue = new RPMComparator().compare(store1, store2);

		boolean hasTestCasePassed = false;
		if (isNull == false && isIdEqual == false && isCurrencyEqual == false
				&& isPriceZoneEqual == false && isPromoZoneEqual == false && isIdEqualToReturnTrue == true) {
			hasTestCasePassed = true;
		}
		assertThat(hasTestCasePassed).isEqualTo(true);
	}

	@Test
	public void testCompareClearanceProduct() {
		ClearanceProduct prod1 = null;
		ClearanceProduct prod2 = null;

		boolean isNull = new RPMComparator().compare(prod1, prod2);
		prod1 = Mockito.mock(ClearanceProduct.class);
		prod2 = Mockito.mock(ClearanceProduct.class);
		Mockito.doReturn("123").when(prod1).getProductId();
		Mockito.doReturn("456").when(prod2).getProductId();
		boolean isIdEqual = new RPMComparator().compare(prod1, prod2);
		Mockito.doReturn("123").when(prod2).getProductId();
		prod1.setCurrencyFormat("232");
		prod1.setCurrencyFormat("343");
		boolean isToStringEqual = new RPMComparator().compare(prod1, prod2);
		boolean hasTestCasePassed = false;
		if (isNull == false && isIdEqual == false && isToStringEqual == false) {
			hasTestCasePassed = true;
		}
		assertThat(hasTestCasePassed).isEqualTo(true);
	}

	@Test
	public void testCompareClearanceMMProduct() {
		ClearanceMMProduct prod1 = null;
		ClearanceMMProduct prod2 = null;

		boolean isNull = new RPMComparator().compare(prod1, prod2);
		prod1 = Mockito.mock(ClearanceMMProduct.class);
		prod2 = Mockito.mock(ClearanceMMProduct.class);
		Mockito.doReturn("123").when(prod1).getProductId();
		Mockito.doReturn("456").when(prod2).getProductId();
		boolean isIdEqual = new RPMComparator().compare(prod1, prod2);
		Mockito.doReturn("123").when(prod2).getProductId();
		prod1.setCurrencyFormat("232");
		prod1.setCurrencyFormat("343");
		boolean isToStringEqual = new RPMComparator().compare(prod1, prod2);
		boolean hasTestCasePassed = false;
		if (isNull == false && isIdEqual == false && isToStringEqual == false) {
			hasTestCasePassed = true;
		}
		assertThat(hasTestCasePassed).isEqualTo(true);
	}
}
