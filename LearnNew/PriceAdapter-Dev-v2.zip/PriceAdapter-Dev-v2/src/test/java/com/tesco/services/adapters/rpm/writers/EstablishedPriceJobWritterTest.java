package com.tesco.services.adapters.rpm.writers;

import static io.dropwizard.testing.FixtureHelpers.fixture;
import static org.fest.assertions.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Semaphore;

import com.tesco.services.adapters.rpm.writers.impl.EstablishedPriceWritter;
import com.tesco.services.repositories.RepositoryImpl;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tesco.couchbase.AsyncCouchbaseWrapper;
import com.tesco.couchbase.CouchbaseWrapper;
import com.tesco.couchbase.testutils.AsyncCouchbaseWrapperStub;
import com.tesco.couchbase.testutils.BucketTool;
import com.tesco.couchbase.testutils.CouchbaseTestManager;
import com.tesco.couchbase.testutils.CouchbaseWrapperStub;
import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.exceptions.ColumnNotFoundException;
import com.tesco.services.adapters.rpm.events.impl.ClearanceEventData;
import com.tesco.services.adapters.rpm.events.ClearanceEventHandler;
import com.tesco.services.adapters.rpm.readers.PriceServiceCSVReader;
import com.tesco.services.core.ClearanceProduct;
import com.tesco.services.resources.ImportResource;
import com.tesco.services.resources.TestConfiguration;
import com.tesco.services.utility.PriceConstants;

/**
 * Created by QP65 on 12/16/2015.
 */
@RunWith(MockitoJUnitRunner.class)
public class EstablishedPriceJobWritterTest {

	@Mock
	public RepositoryImpl repositoryImpl;
	@Mock
	public AsyncCouchbaseWrapper asyncCouchbaseWrapper;
	@Mock
	public CouchbaseWrapper couchbaseWrapper;
	@Mock
	private Configuration testConfiguration;
	@Mock
	private Configuration mockTestConfiguration;
	@Mock
	private CouchbaseTestManager couchbaseTestManager;
	@Mock
	private PriceServiceCSVReader estbPriceReader;
	@Mock
	ClearanceEventHandler clearanceEventHandler;

	private EstablishedPriceWritter establishedPriceWritter;
	private ObjectMapper mapper = new ObjectMapper();

	private String runIdentifier = "estdprice";
	private String fileName = "tsl_ps_estd_price_regular_1_20151212.csv";
	private Map<String, String> estbPriceMappingMap;

	@Before
	public void setUp() throws IOException, URISyntaxException,
			InterruptedException, ColumnNotFoundException {

		testConfiguration = TestConfiguration.load();
		if (testConfiguration.isDummyCouchbaseMode()) {
			Map<String, ImmutablePair<Long, String>> fakeBase = new HashMap<>();
			couchbaseTestManager = new CouchbaseTestManager(
					new CouchbaseWrapperStub(fakeBase),
					new AsyncCouchbaseWrapperStub(fakeBase),
					mock(BucketTool.class));
		} else {
			couchbaseTestManager = new CouchbaseTestManager(
					testConfiguration.getCouchbaseBucket(),
					testConfiguration.getCouchbaseUsername(),
					testConfiguration.getCouchbasePassword(),
					testConfiguration.getCouchbaseNodes(),
					testConfiguration.getCouchbaseAdminUsername(),
					testConfiguration.getCouchbaseAdminPassword());
		}

		couchbaseWrapper = couchbaseTestManager.getCouchbaseWrapper();
		asyncCouchbaseWrapper = couchbaseTestManager.getAsyncCouchbaseWrapper();

		/*
		 * productRepository = new ProductRepository(couchbaseWrapper,
		 * asyncCouchbaseWrapper, new ObjectMapper());
		 */
		establishedPriceWritter = new EstablishedPriceWritter(
				testConfiguration, repositoryImpl, clearanceEventHandler,
				estbPriceReader);
		establishedPriceWritter.setRunIdentifier(runIdentifier);

	}

	@Test
	public void readAndWriteEstbPriceForZone() throws Exception {
		String tpnb = "050000419";
		String tpnc = "250000024";

		ClearanceProduct actualClearanceProduct = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/estbPrice/EstbPriceClearanceProd.json"),
						ClearanceProduct.class);

		estbPriceMappingMap = returnEstbPriceMap(tpnb, tpnc, 1, 3);
		when(estbPriceReader.getNext()).thenReturn(estbPriceMappingMap)
				.thenReturn(null);
		when(
				repositoryImpl.getGenericObject("CLRPROD_" + tpnb,
						ClearanceProduct.class)).thenReturn(
				actualClearanceProduct);

		ImportResource.importSemaphoreForIdentifier.put(fileName,
				new Semaphore(1));

		this.establishedPriceWritter.write(fileName);

		ClearanceProduct expectedClearanceProduct = (ClearanceProduct) repositoryImpl
				.getGenericObject(PriceConstants.RPM_CLR_PRODUCT + tpnb,
						ClearanceProduct.class);
		assertThat(expectedClearanceProduct).isNotNull();
		assertThat(actualClearanceProduct.toString().equals(
				expectedClearanceProduct.toString()));

	}

	@Test
	public void readAndWriteEstbPriceForZoneDiffTpnc() throws Exception {
		String tpnb = "050000419";
		String tpnc = "250000024111";

		ClearanceProduct actualClearanceProduct = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/estbPrice/EstbPriceClearanceProd.json"),
						ClearanceProduct.class);

		estbPriceMappingMap = returnEstbPriceMap(tpnb, tpnc, 1, 3);
		when(estbPriceReader.getNext()).thenReturn(estbPriceMappingMap)
				.thenReturn(null);
		when(
				repositoryImpl.getGenericObject("CLRPROD_" + tpnb,
						ClearanceProduct.class)).thenReturn(
				actualClearanceProduct);

		ImportResource.importSemaphoreForIdentifier.put(fileName,
				new Semaphore(1));

		this.establishedPriceWritter.write(fileName);

		ClearanceProduct expectedClearanceProduct = (ClearanceProduct) repositoryImpl
				.getGenericObject(PriceConstants.RPM_CLR_PRODUCT + tpnb,
						ClearanceProduct.class);
		assertThat(expectedClearanceProduct).isNotNull();
		assertThat(actualClearanceProduct.toString().equals(
				expectedClearanceProduct.toString()));

	}

	@Test
	public void readAndWriteEstbPriceForZoneWithoutEstbPrice() throws Exception {
		String tpnb = "050000419";
		String tpnc = "250000024";

		ClearanceProduct actualClearanceProduct = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/estbPrice/EstbPriceClearanceProd.json"),
						ClearanceProduct.class);

		estbPriceMappingMap = returnEstbPriceMap(tpnb, tpnc, 1, 9);
		when(estbPriceReader.getNext()).thenReturn(estbPriceMappingMap)
				.thenReturn(null);
		when(
				repositoryImpl.getGenericObject("CLRPROD_" + tpnb,
						ClearanceProduct.class)).thenReturn(
				actualClearanceProduct);

		ImportResource.importSemaphoreForIdentifier.put(fileName,
				new Semaphore(1));

		this.establishedPriceWritter.write(fileName);

		ClearanceProduct expectedClearanceProduct = (ClearanceProduct) repositoryImpl
				.getGenericObject(PriceConstants.RPM_CLR_PRODUCT + tpnb,
						ClearanceProduct.class);
		assertThat(expectedClearanceProduct).isNotNull();
		assertThat(actualClearanceProduct.toString().equals(
				expectedClearanceProduct.toString()));

	}

	@Test
	public void readAndWriteEstbPriceForStore() throws Exception {
		String tpnb = "050000419";
		String tpnc = "250000145";

		ClearanceProduct actualClearanceProduct = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/estbPrice/EstbPriceClearanceProd.json"),
						ClearanceProduct.class);

		estbPriceMappingMap = returnEstbPriceMap(tpnb, tpnc, 0, 3);
		when(estbPriceReader.getNext()).thenReturn(estbPriceMappingMap)
				.thenReturn(null);
		when(
				repositoryImpl.getGenericObject("CLRPROD_" + tpnb,
						ClearanceProduct.class)).thenReturn(
				actualClearanceProduct);

		ImportResource.importSemaphoreForIdentifier.put(fileName,
				new Semaphore(1));

		this.establishedPriceWritter.write(fileName);

		ClearanceProduct expectedClearanceProduct = (ClearanceProduct) repositoryImpl
				.getGenericObject(PriceConstants.RPM_CLR_PRODUCT + tpnb,
						ClearanceProduct.class);
		assertThat(expectedClearanceProduct).isNotNull();
		assertThat(actualClearanceProduct.toString().equals(
				expectedClearanceProduct.toString()));

	}

	@Test
	public void readAndWriteEstbPriceForStoreDiffTpnc() throws Exception {
		String tpnb = "050000419";
		String tpnc = "250000024111";

		ClearanceProduct actualClearanceProduct = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/estbPrice/EstbPriceClearanceProd.json"),
						ClearanceProduct.class);

		estbPriceMappingMap = returnEstbPriceMap(tpnb, tpnc, 0, 3);
		when(estbPriceReader.getNext()).thenReturn(estbPriceMappingMap)
				.thenReturn(null);
		when(
				repositoryImpl.getGenericObject("CLRPROD_" + tpnb,
						ClearanceProduct.class)).thenReturn(
				actualClearanceProduct);

		ImportResource.importSemaphoreForIdentifier.put(fileName,
				new Semaphore(1));

		this.establishedPriceWritter.write(fileName);

		ClearanceProduct expectedClearanceProduct = (ClearanceProduct) repositoryImpl
				.getGenericObject(PriceConstants.RPM_CLR_PRODUCT + tpnb,
						ClearanceProduct.class);
		assertThat(expectedClearanceProduct).isNotNull();
		assertThat(actualClearanceProduct.toString().equals(
				expectedClearanceProduct.toString()));

	}

	@Test
	public void readAndWriteEstbPriceForInvalidTpnb() throws Exception {
		String tpnb = "050000419111";
		String tpnc = "250000024";

		ClearanceProduct actualClearanceProduct = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/estbPrice/EstbPriceClearanceProd.json"),
						ClearanceProduct.class);

		estbPriceMappingMap = returnEstbPriceMap(tpnb, tpnc, 0, 3);
		when(estbPriceReader.getNext()).thenReturn(estbPriceMappingMap)
				.thenReturn(null);
		when(
				repositoryImpl.getGenericObject("CLRPROD_" + tpnb,
						ClearanceProduct.class)).thenReturn(null);

		ImportResource.importSemaphoreForIdentifier.put(fileName,
				new Semaphore(1));

		this.establishedPriceWritter.write(fileName);

		ClearanceProduct expectedClearanceProduct = (ClearanceProduct) repositoryImpl
				.getGenericObject(PriceConstants.RPM_CLR_PRODUCT + tpnb,
						ClearanceProduct.class);
		assertThat(expectedClearanceProduct).isNull();

	}

	@Test
	public void testWriteRPMZoneDataForException() throws Exception {

		establishedPriceWritter = spy(establishedPriceWritter);
		//estbPriceReader = Mockito.mock(PriceServiceCSVReader.class);
		//when(establishedPriceWritter.createEstbPriceReader(fileName))
			//	.thenReturn(estbPriceReader);
		when(estbPriceReader.getNext()).thenThrow(
				new ArrayIndexOutOfBoundsException(
						"Array index out of bound Exception"));

		ImportResource.importSemaphoreForIdentifier.put(fileName,
				new Semaphore(1));
		this.establishedPriceWritter.write(fileName);
		assertThat("Array index out of bound Exception").isEqualTo(
				ImportResource.getErrorString(fileName));

	}

	/**
	 *
	 * @param tpnb
	 * @param tpnc
	 * @param zoneNodeType
	 *            = 1 for Zone, 0 for Store
	 * @param phase
	 *            = 1, which means only Phase1 details are set 2 for Phase1 and
	 *            Phase2 are set
	 * @return
	 */
	private Map<String, String> returnEstbPriceMap(String tpnb, String tpnc,
			int zoneNodeType, int phase) {

		Map<String, String> estbPriceMappingMap = new HashMap<>();
		String zone = "20";
		String store = "2920";

		/**
		 * Established Price are dummy dates and its only for test purpose.
		 */
		String effDate = "20150615000000";
		String outOfStockDate = "20150625000000";
		String phaseStartDate = "20150515000000";
		String phaseEndDate = "20150525000000";
		String estbPriceP1 = "33.33";
		String estbPriceP2 = "22.22";
		String estbPriceP3 = "11.11";

		estbPriceMappingMap.put(CSVHeaders.EstablishedPriceHeaders.FDETL,
				"FDETL");
		estbPriceMappingMap.put(CSVHeaders.EstablishedPriceHeaders.LINE_NOR,
				"LINE_NOR");
		estbPriceMappingMap.put(CSVHeaders.EstablishedPriceHeaders.TPNB, tpnb);
		estbPriceMappingMap.put(CSVHeaders.EstablishedPriceHeaders.TPNC, tpnc);

		if (zoneNodeType == 1) {
			estbPriceMappingMap.put(
					CSVHeaders.EstablishedPriceHeaders.ZONE_NODE_TYPE, "1");
			estbPriceMappingMap.put(CSVHeaders.EstablishedPriceHeaders.ZONE_ID,
					zone);
		} else if (zoneNodeType == 0) {
			estbPriceMappingMap.put(
					CSVHeaders.EstablishedPriceHeaders.ZONE_NODE_TYPE, "0");
			estbPriceMappingMap.put(
					CSVHeaders.EstablishedPriceHeaders.LOCATION, store);
		}

		estbPriceMappingMap.put(
				CSVHeaders.EstablishedPriceHeaders.EFFECTIVE_DATE, effDate);
		estbPriceMappingMap.put(
				CSVHeaders.EstablishedPriceHeaders.OUT_OF_STOCK_DATE,
				outOfStockDate);

		if (phase == 1) {
			estbPriceMappingMap
					.put(CSVHeaders.EstablishedPriceHeaders.TSL_ESTABLISHED_PRICE_PH1,
							estbPriceP1);
			estbPriceMappingMap.put(
					CSVHeaders.EstablishedPriceHeaders.P1_START_DATE,
					phaseStartDate);
			estbPriceMappingMap.put(
					CSVHeaders.EstablishedPriceHeaders.P1_END_DATE,
					phaseEndDate);

			estbPriceMappingMap
					.put(CSVHeaders.EstablishedPriceHeaders.TSL_ESTABLISHED_PRICE_PH2,
							"");
			estbPriceMappingMap.put(
					CSVHeaders.EstablishedPriceHeaders.P2_START_DATE, "");
			estbPriceMappingMap.put(
					CSVHeaders.EstablishedPriceHeaders.P2_END_DATE, "");

			estbPriceMappingMap
					.put(CSVHeaders.EstablishedPriceHeaders.TSL_ESTABLISHED_PRICE_PH3,
							"");
			estbPriceMappingMap.put(
					CSVHeaders.EstablishedPriceHeaders.P3_START_DATE, "");
			estbPriceMappingMap.put(
					CSVHeaders.EstablishedPriceHeaders.P3_END_DATE, "");

		} else if (phase == 2) {
			estbPriceMappingMap
					.put(CSVHeaders.EstablishedPriceHeaders.TSL_ESTABLISHED_PRICE_PH1,
							estbPriceP1);
			estbPriceMappingMap.put(
					CSVHeaders.EstablishedPriceHeaders.P1_START_DATE,
					phaseStartDate);
			estbPriceMappingMap.put(
					CSVHeaders.EstablishedPriceHeaders.P1_END_DATE,
					phaseEndDate);

			estbPriceMappingMap
					.put(CSVHeaders.EstablishedPriceHeaders.TSL_ESTABLISHED_PRICE_PH2,
							estbPriceP2);
			estbPriceMappingMap.put(
					CSVHeaders.EstablishedPriceHeaders.P2_START_DATE,
					phaseStartDate);
			estbPriceMappingMap.put(
					CSVHeaders.EstablishedPriceHeaders.P2_END_DATE,
					phaseEndDate);

			estbPriceMappingMap
					.put(CSVHeaders.EstablishedPriceHeaders.TSL_ESTABLISHED_PRICE_PH3,
							"");
			estbPriceMappingMap.put(
					CSVHeaders.EstablishedPriceHeaders.P3_START_DATE, "");
			estbPriceMappingMap.put(
					CSVHeaders.EstablishedPriceHeaders.P3_END_DATE, "");

		} else if (phase == 3) {
			estbPriceMappingMap
					.put(CSVHeaders.EstablishedPriceHeaders.TSL_ESTABLISHED_PRICE_PH1,
							estbPriceP1);
			estbPriceMappingMap.put(
					CSVHeaders.EstablishedPriceHeaders.P1_START_DATE,
					phaseStartDate);
			estbPriceMappingMap.put(
					CSVHeaders.EstablishedPriceHeaders.P1_END_DATE,
					phaseEndDate);

			estbPriceMappingMap
					.put(CSVHeaders.EstablishedPriceHeaders.TSL_ESTABLISHED_PRICE_PH2,
							estbPriceP2);
			estbPriceMappingMap.put(
					CSVHeaders.EstablishedPriceHeaders.P2_START_DATE,
					phaseStartDate);
			estbPriceMappingMap.put(
					CSVHeaders.EstablishedPriceHeaders.P2_END_DATE,
					phaseEndDate);

			estbPriceMappingMap
					.put(CSVHeaders.EstablishedPriceHeaders.TSL_ESTABLISHED_PRICE_PH3,
							estbPriceP3);
			estbPriceMappingMap.put(
					CSVHeaders.EstablishedPriceHeaders.P3_START_DATE,
					phaseStartDate);
			estbPriceMappingMap.put(
					CSVHeaders.EstablishedPriceHeaders.P3_END_DATE,
					phaseEndDate);

		} else {
			estbPriceMappingMap
					.put(CSVHeaders.EstablishedPriceHeaders.TSL_ESTABLISHED_PRICE_PH1,
							"");
			estbPriceMappingMap.put(
					CSVHeaders.EstablishedPriceHeaders.P1_START_DATE, "");
			estbPriceMappingMap.put(
					CSVHeaders.EstablishedPriceHeaders.P1_END_DATE, "");

			estbPriceMappingMap
					.put(CSVHeaders.EstablishedPriceHeaders.TSL_ESTABLISHED_PRICE_PH2,
							"");
			estbPriceMappingMap.put(
					CSVHeaders.EstablishedPriceHeaders.P2_START_DATE, "");
			estbPriceMappingMap.put(
					CSVHeaders.EstablishedPriceHeaders.P2_END_DATE, "");

			estbPriceMappingMap
					.put(CSVHeaders.EstablishedPriceHeaders.TSL_ESTABLISHED_PRICE_PH3,
							"");
			estbPriceMappingMap.put(
					CSVHeaders.EstablishedPriceHeaders.P3_START_DATE, "");
			estbPriceMappingMap.put(
					CSVHeaders.EstablishedPriceHeaders.P3_END_DATE, "");
		}

		return estbPriceMappingMap;
	}

	@Test
	public void readAndPublishEventDataForEstablishedPriceChangeClearanceForStore()
			throws Exception {

		String tpnb = "050000419";
		String tpnc = "250000145";

		ClearanceProduct actualClearanceProduct = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/estbPrice/EstbPriceClearanceProdForEventing.json"),
						ClearanceProduct.class);
		estbPriceMappingMap = returnEstbPriceMap(tpnb, tpnc, 0, 3);

		when(estbPriceReader.getNext()).thenReturn(estbPriceMappingMap)
				.thenReturn(null);
		when(
				repositoryImpl.getGenericObject("CLRPROD_" + tpnb,
						ClearanceProduct.class)).thenReturn(
				actualClearanceProduct);

		ImportResource.importSemaphoreForIdentifier.put(fileName,
				new Semaphore(1));

		this.establishedPriceWritter.write(fileName);

		ArgumentCaptor<ClearanceEventData> argumentMap = ArgumentCaptor
				.forClass(ClearanceEventData.class);

		ClearanceEventData clearanceDataEventMap = new ClearanceEventData();
		Set<String> locationDataSet = new HashSet<>();
		locationDataSet.add("S_2920_EC-1329248497");
		clearanceDataEventMap.put("tpnc:250000145_S_2015-06-15T00:00:00_GB",
				locationDataSet);
		Mockito.verify(clearanceEventHandler, Mockito.times(1))
				.publishEventsForPreviousPriceChangeClearances(
						argumentMap.capture());
		assertEquals(clearanceDataEventMap, argumentMap.getValue());

	}

	@Test
	public void readAndPublishEventDataForEstablishedPriceChangeClearanceForStoreWithGrouping()
			throws Exception {

		String tpnb = "050000419";
		String tpnc = "250000024";
		Map<String, String> estblishedPriceMapforSecondLine;
		ClearanceProduct actualClearanceProduct = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/estbPrice/EstbPriceClearanceProdForEventing.json"),
						ClearanceProduct.class);
		estbPriceMappingMap = returnEstbPriceMap(tpnb, tpnc, 0, 3);
		estbPriceMappingMap.put("LOCATION", "2921");
		estblishedPriceMapforSecondLine = returnEstbPriceMap(tpnb, tpnc, 0, 3);
		estblishedPriceMapforSecondLine.put("LOCATION", "2922");
		when(estbPriceReader.getNext()).thenReturn(estbPriceMappingMap)
				.thenReturn(estblishedPriceMapforSecondLine).thenReturn(null);

		when(
				repositoryImpl.getGenericObject("CLRPROD_" + tpnb,
						ClearanceProduct.class)).thenReturn(
				actualClearanceProduct);

		ImportResource.importSemaphoreForIdentifier.put(fileName,
				new Semaphore(1));

		this.establishedPriceWritter.write(fileName);

		ArgumentCaptor<ClearanceEventData> argumentMap = ArgumentCaptor
				.forClass(ClearanceEventData.class);

		Map<String, Set<String>> clearanceDataEventMap = new HashMap<>();
		Set<String> locationDataSet = new HashSet<>();
		locationDataSet.add("S_2921_EC-1329248497");
		locationDataSet.add("S_2922_EC-1329248498");

		clearanceDataEventMap.put("tpnc:250000024_S_2015-06-15T00:00:00_GB",
				locationDataSet);

		Mockito.verify(clearanceEventHandler, Mockito.times(1))
				.publishEventsForPreviousPriceChangeClearances(
						argumentMap.capture());
		assertEquals(clearanceDataEventMap, argumentMap.getValue());

	}

	@Test
	public void readAndPublishEventDataForEstablishedPriceChangeClearanceForZone()
			throws Exception {

		String tpnb = "050000419";
		String tpnc = "250000024";

		ClearanceProduct actualClearanceProduct = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/estbPrice/EstbPriceClearanceProdForEventing.json"),
						ClearanceProduct.class);

		estbPriceMappingMap = returnEstbPriceMap(tpnb, tpnc, 1, 3);
		when(estbPriceReader.getNext()).thenReturn(estbPriceMappingMap)
				.thenReturn(null);
		when(
				repositoryImpl.getGenericObject("CLRPROD_" + tpnb,
						ClearanceProduct.class)).thenReturn(
				actualClearanceProduct);

		ImportResource.importSemaphoreForIdentifier.put(fileName,
				new Semaphore(1));

		this.establishedPriceWritter.write(fileName);
		ArgumentCaptor<ClearanceEventData> argumentMap = ArgumentCaptor
				.forClass(ClearanceEventData.class);

		ClearanceEventData clearanceDataEventMap = new ClearanceEventData();
		Set<String> locationDataSet = new HashSet<>();
		locationDataSet.add("Z_20_CL-1479643884");
		clearanceDataEventMap.put("tpnc:250000024_Z_2015-06-15T00:00:00_GB",
				locationDataSet);
		Mockito.verify(clearanceEventHandler, Mockito.times(1))
				.publishEventsForPreviousPriceChangeClearances(
						argumentMap.capture());
		assertEquals(clearanceDataEventMap, argumentMap.getValue());

	}

	@Test
	public void shouldNotInvokePublishEventDataForEstablishedPriceChangeClearanceIfTpncNotExist()
			throws Exception {

		String tpnb = "050000419";
		String tpnc = "123456789";

		ClearanceProduct actualClearanceProduct = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/estbPrice/EstbPriceClearanceProdForEventing.json"),
						ClearanceProduct.class);

		estbPriceMappingMap = returnEstbPriceMap(tpnb, tpnc, 1, 3);
		when(estbPriceReader.getNext()).thenReturn(estbPriceMappingMap)
				.thenReturn(null);
		when(
				repositoryImpl.getGenericObject("CLRPROD_" + tpnb,
						ClearanceProduct.class)).thenReturn(
				actualClearanceProduct);

		ImportResource.importSemaphoreForIdentifier.put(fileName,
				new Semaphore(1));

		this.establishedPriceWritter.write(fileName);
		ArgumentCaptor<ClearanceEventData> argumentMap = ArgumentCaptor
				.forClass(ClearanceEventData.class);
		Mockito.verify(clearanceEventHandler, Mockito.times(0))
				.publishEventsForPreviousPriceChangeClearances(
						argumentMap.capture());

	}

	@Test
	public void testWriteForException() throws Exception {
		when(estbPriceReader.getNext()).thenThrow(
				new IOException("IO Exception")).thenReturn(null);

		ImportResource.importSemaphoreForIdentifier.put(fileName,
				new Semaphore(1));

		try {
			this.establishedPriceWritter.write(fileName);
			Assert.fail("Suppose to fail");
		} catch (Exception e) {
			assertThat(e.getMessage().equals("IO Exception"));
		}
	}

}
