package com.tesco.services.adapters.rpm.writers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tesco.couchbase.AsyncCouchbaseWrapper;
import com.tesco.couchbase.CouchbaseWrapper;
import com.tesco.couchbase.testutils.AsyncCouchbaseWrapperStub;
import com.tesco.couchbase.testutils.BucketTool;
import com.tesco.couchbase.testutils.CouchbaseTestManager;
import com.tesco.couchbase.testutils.CouchbaseWrapperStub;
import com.tesco.services.Configuration;
import com.tesco.services.adapters.rpm.writers.impl.PriceWriter;
import com.tesco.services.core.price.PriceEntity;
import com.tesco.services.repositories.RepositoryImpl;
import com.tesco.services.resources.ImportResource;
import com.tesco.services.resources.TestConfiguration;
import com.tesco.services.utility.PriceConstants;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.io.*;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Semaphore;

import static io.dropwizard.testing.FixtureHelpers.fixture;
import static org.fest.assertions.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

@RunWith(MockitoJUnitRunner.class)
public class PriceWriterTest {
	@Mock
	public PriceWriter priceWriter;
	@Mock
	public RepositoryImpl repositoryImpl;

	@Mock
	public AsyncCouchbaseWrapper asyncCouchbaseWrapper;

	@Mock
	public CouchbaseWrapper couchbaseWrapper;
	@Mock
	private Configuration testConfiguration;

	@Mock
	private Configuration mockTestConfiguration;

	@Mock
	private ObjectMapper mapper;

	@Mock
	private CouchbaseTestManager couchbaseTestManager;

	@Mock
	FileWriter fileWriter;
	@Mock
	BufferedWriter bufferedWriter;
	@Mock
	private BufferedReader bufferedReader;

	String runIdentifier = "onetimeprice";

	String testFilename = "priceOnetime.dat";
	String tpnb = "050000016";
	String zone1 = "11";

	File oneTimeFile;

	@Before
	public void setUp() throws FileNotFoundException {
		testConfiguration = TestConfiguration.load();

		if (testConfiguration.isDummyCouchbaseMode()) {
			Map<String, ImmutablePair<Long, String>> fakeBase = new HashMap<>();
			couchbaseTestManager = new CouchbaseTestManager(
					new CouchbaseWrapperStub(fakeBase),
					new AsyncCouchbaseWrapperStub(fakeBase),
					mock(BucketTool.class));
		} else {
			couchbaseTestManager = new CouchbaseTestManager(
					testConfiguration.getCouchbaseBucket(),
					testConfiguration.getCouchbaseUsername(),
					testConfiguration.getCouchbasePassword(),
					testConfiguration.getCouchbaseNodes(),
					testConfiguration.getCouchbaseAdminUsername(),
					testConfiguration.getCouchbaseAdminPassword());
		}

		couchbaseWrapper = couchbaseTestManager.getCouchbaseWrapper();
		asyncCouchbaseWrapper = couchbaseTestManager.getAsyncCouchbaseWrapper();

		repositoryImpl = new RepositoryImpl(couchbaseWrapper,
				asyncCouchbaseWrapper, new ObjectMapper());
		oneTimeFile = new File(
				"src/test/resources/com/tesco/services/core/fixtures/priceOnetime.dat");

		mapper = new ObjectMapper();
		priceWriter = new PriceWriter(testConfiguration, mapper, repositoryImpl);
		priceWriter.setRunIdentifier(runIdentifier);
		ImportResource.getImportSemaphoreForIdentifier().put(testFilename,
				new Semaphore(1));
	}

	@Test
	public void testWritePriceToCB() throws Exception {
		priceWriter.setOnetimePromoFile(oneTimeFile);
		priceWriter.write(testFilename);
		String doc = (String) couchbaseWrapper
				.get(PriceConstants.PRICE_DOC_KEY_PREFIX + tpnb + "_" + "Z"
						+ zone1);
		assertThat(doc).isNotNull();

	}

	@Test
	public void testWritePriceToCBWithErrorJsonArray() throws Exception {
		oneTimeFile = new File(
				"src/test/resources/com/tesco/services/core/fixtures/priceOnetimeErrorJson.dat");
		priceWriter = new PriceWriter(testConfiguration, mapper, repositoryImpl);
		priceWriter.setOnetimePromoFile(oneTimeFile);
		priceWriter.write(testFilename);
		String doc = (String) couchbaseWrapper
				.get(PriceConstants.PRICE_DOC_KEY_PREFIX + tpnb + "_" + "Z"
						+ zone1);
		assertThat(doc).isNull();

	}

	@Test
	public void testWritePriceToCBWithIncompleteJson() throws Exception {
		oneTimeFile = new File(
				"src/test/resources/com/tesco/services/core/fixtures/priceOnetimeIncompleteData.dat");
		priceWriter = new PriceWriter(testConfiguration, mapper, repositoryImpl);
		priceWriter.setOnetimePromoFile(oneTimeFile);
		priceWriter.write(testFilename);
		String doc = (String) couchbaseWrapper
				.get(PriceConstants.PRICE_DOC_KEY_PREFIX + tpnb + "_" + "Z"
						+ zone1);
		assertThat(doc).isNull();
	}

	@Test
	public void testWriteOnetimePriceWithEmptyProdRef() throws Exception {
		oneTimeFile = new File(
				"src/test/resources/com/tesco/services/core/fixtures/priceOnetimeEmptyProdRefJson.dat");
		priceWriter = new PriceWriter(testConfiguration, mapper, repositoryImpl);
		priceWriter.setOnetimePromoFile(oneTimeFile);
		priceWriter.write(testFilename);
		String doc = (String) couchbaseWrapper
				.get(PriceConstants.PRICE_DOC_KEY_PREFIX + tpnb + "_" + "Z"
						+ zone1);
		assertThat(doc).isNull();
	}

	@Test
	public void testWriteOnetimePriceExceptionInInsertion() throws Exception {
		RepositoryImpl repositoryImpl = Mockito
				.mock(RepositoryImpl.class);
		Mockito.doThrow(new Exception("Exception")).when(repositoryImpl)
				.insertObject(Matchers.anyString(), Matchers.anyObject());
		oneTimeFile = new File(
				"src/test/resources/com/tesco/services/core/fixtures/priceOnetimeEmptyProdRefJson.dat");
		priceWriter = new PriceWriter(testConfiguration, mapper, repositoryImpl);
		priceWriter.setOnetimePromoFile(oneTimeFile);
		priceWriter.write(testFilename);
		String doc = (String) couchbaseWrapper
				.get(PriceConstants.PRICE_DOC_KEY_PREFIX + tpnb + "_" + "Z"
						+ zone1);
		assertThat(doc).isNull();
	}

	@Test
	public void testWritePriceJMSExceptionInInsertion() throws Exception {

		String tpnb = "123456";
		String priceDocKey = "REGPRICE_" + tpnb + "_Z1";
		String priceEntityString0016 = fixture("com/tesco/services/core/fixtures/price/REGPRICE_050000016_Z1.json");
		Map<String, PriceEntity> mapOfPriceEntities = new HashMap<>();
		PriceEntity priceEntity = mapper.readValue(priceEntityString0016,
				PriceEntity.class);
		priceEntity.setProdRef(tpnb);
		mapOfPriceEntities.put(priceDocKey, priceEntity);

		RepositoryImpl repositoryImpl = Mockito
				.mock(RepositoryImpl.class);
		Mockito.doThrow(new Exception("Exception")).when(repositoryImpl)
				.insertObject(Matchers.anyString(), Matchers.anyObject());
		priceWriter = new PriceWriter(testConfiguration, mapper,
				repositoryImpl);
		priceWriter.writePrice(mapOfPriceEntities);
		String doc = (String) couchbaseWrapper.get(priceDocKey);
		assertThat(doc).isNull();
	}

	@Test
	public void testWriteUpdatePriceEntityDocExceptionInInsertion()
			throws Exception {

		String tpnb = "123456";
		String priceDocKey = "REGPRICE_" + tpnb + "_Z1";
		String priceEntityString0016 = fixture("com/tesco/services/core/fixtures/price/REGPRICE_050000016_Z1.json");
		PriceEntity priceEntity = mapper.readValue(priceEntityString0016,
				PriceEntity.class);
		priceEntity.setProdRef(tpnb);

		RepositoryImpl repositoryImpl = Mockito
				.mock(RepositoryImpl.class);
		Mockito.doThrow(new Exception("Exception")).when(repositoryImpl)
				.insertObject(Matchers.anyString(), Matchers.anyObject());
		priceWriter = new PriceWriter(testConfiguration, mapper, repositoryImpl);
		priceWriter.writeUpdatePriceEntityDoc(priceEntity);
		String doc = (String) couchbaseWrapper.get(priceDocKey);
		assertThat(doc).isNull();
	}
}
