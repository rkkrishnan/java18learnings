package com.tesco.services.adapters.core;

import static com.tesco.services.utility.PriceConstants.EVENT_TYPE;
import static com.tesco.services.utility.PriceConstants.LEAD_TIME_DAYS;
import static com.tesco.services.utility.PriceConstants.LOC_REF;
import static com.tesco.services.utility.PriceConstants.LOC_TYPE;
import static com.tesco.services.utility.PriceConstants.OFFER_ID;
import static com.tesco.services.utility.PriceConstants.PROD_REF;
import static com.tesco.services.utility.PriceConstants.SCHEDULED_PROMOTION_END_EVENT_TYPE;
import static com.tesco.services.utility.PriceConstants.SCHEDULED_PROMOTION_START_EVENT_TYPE;
import static com.tesco.services.utility.PriceConstants.SCHEDULED_PROMOTION_START_PRODUCT_EVENT_TYPE;
import static io.dropwizard.testing.FixtureHelpers.fixture;
import static org.joda.time.DateTimeUtils.setCurrentMillisFixed;
import static org.joda.time.DateTimeUtils.setCurrentMillisSystem;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.Response;
import javax.xml.bind.JAXBException;

import org.codehaus.jettison.json.JSONException;
import org.joda.time.DateTimeUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tesco.services.Configuration;
import com.tesco.services.CouchbaseViewConfig;
import com.tesco.services.adapters.core.exceptions.PromotionEventException;
import com.tesco.services.adapters.promotion.PromotionEventHandler;
import com.tesco.services.core.ZoneEntity;
import com.tesco.services.event.exception.EventPublishException;
import com.tesco.services.exceptions.DataAccessException;
import com.tesco.services.repositories.RepositoryImpl;
import com.tesco.services.repositories.views.WebViewTemplate;

@RunWith(MockitoJUnitRunner.class)
public class PromotionScheduledEventJobTest {

	@Mock
	private Configuration configuration;
	@Mock
	private RepositoryImpl repositoryImpl;
	@Mock
	private PromotionEventHandler promotionEventHandler;
	@Mock
	WebViewTemplate mockWebViewTemplate;

	@Captor
	private ArgumentCaptor<Map<String, String>> argumentCaptorMapData;

	private String promotionEntityMultipleRecord = null;
	private ObjectMapper mapper = new ObjectMapper();
	private PromotionScheduledEventJob promotionScheduledEventJob;
	final static private String ZONE_ID_13 = "13";
	final static private String ZONE_ID_15 = "15";
	final static private String ZONE_GROUP_ID = "2";
	final static private String ZONE_ZONENAME = "testZone";
	final static private String COUNTRY_CODE = "GB";
	private String couchbaseViewPromotionStartUrl = null;
	private String couchbasePromotionEndUrl = null;
	private String couchbaseViewPromotionStarProductUrl = null;

	@Before
	public void setUp() throws IOException, DataAccessException {
		promotionEntityMultipleRecord = fixture("com/tesco/services/core/fixtures/promotion/SCHEDULED_PROMOTION_MULTIPLE.json");
		ZoneEntity zoneGB = new ZoneEntity();
		zoneGB.setZoneId(ZONE_ID_13);
		zoneGB.setZoneGroupId(ZONE_GROUP_ID);
		zoneGB.setZoneName(ZONE_ZONENAME);
		zoneGB.setTslCountryCode(COUNTRY_CODE);

		when(repositoryImpl.getGenericObject("ZONE_13", ZoneEntity.class))
				.thenReturn(zoneGB);

		ZoneEntity zoneIE = new ZoneEntity();
		zoneIE.setZoneId(ZONE_ID_15);
		zoneIE.setZoneGroupId(ZONE_GROUP_ID);
		zoneIE.setZoneName(ZONE_ZONENAME);
		zoneIE.setTslCountryCode("IE");

		when(repositoryImpl.getGenericObject("ZONE_15", ZoneEntity.class))
				.thenReturn(zoneIE);

	}

	@Test
	public void shouldTriggerPromotionStartEventForEffectiveDateTomorrow()
			throws IOException, EventPublishException, JAXBException,
			ParseException, JSONException, PromotionEventException {

		CouchbaseViewConfig mockViewConfig = Mockito
				.mock(CouchbaseViewConfig.class);

		Map<String, String> viewQueryParams = new HashMap<String, String>();
		viewQueryParams.put("stale.state", "false");
		viewQueryParams.put("page.size", "2");
		viewQueryParams.put("timeout.interval", "60000");

		Map<String, String> viewQueryAddlParams = new HashMap<String, String>();
		viewQueryAddlParams.put("offset", "+00:00");
		viewQueryAddlParams.put("effectiveday", "1");

		Mockito.when(mockViewConfig.getViewQueryParams()).thenReturn(
				viewQueryParams);

		Mockito.when(mockViewConfig.getViewAdditionalProperties()).thenReturn(
				viewQueryAddlParams);

		Map<String, CouchbaseViewConfig> priceChangeViewConfig = new HashMap<String, CouchbaseViewConfig>();
		priceChangeViewConfig.put("PromotionStart", mockViewConfig);

		Mockito.when(configuration.getCouchbaseViewConfig()).thenReturn(
				priceChangeViewConfig);

		String promotionStartEntityString = fixture("com/tesco/services/core/fixtures/promotion/SCHEDULED_PROMOTION_SINGLE.json");

		Response webViewResponse = Mockito.mock(Response.class);

		Mockito.when(webViewResponse.readEntity(String.class))
				.thenReturn(promotionStartEntityString).thenReturn(null);

		mockWebViewTemplate = Mockito.mock(WebViewTemplate.class);

		DateTimeUtils.setCurrentMillisFixed(1464505782847l);

		Mockito.when(
				mockWebViewTemplate.queryView(Matchers.anyMap(),
						Matchers.anyMap())).thenReturn(webViewResponse);

		promotionScheduledEventJob = new PromotionScheduledEventJob(
				configuration, mapper, promotionEventHandler,
				mockWebViewTemplate, SCHEDULED_PROMOTION_START_EVENT_TYPE);

		promotionScheduledEventJob.processScheduledEvents();
		verify(promotionEventHandler, times(1)).publishPromotionEvent(
				argumentCaptorMapData.capture());
		assertEquals("Z", (argumentCaptorMapData.getValue()).get(LOC_TYPE));
		assertEquals("15", (argumentCaptorMapData.getValue()).get(LOC_REF));
		assertEquals("31918284",
				(argumentCaptorMapData.getValue()).get(OFFER_ID));
		assertEquals("1",
				(argumentCaptorMapData.getValue()).get(LEAD_TIME_DAYS));
		assertEquals(SCHEDULED_PROMOTION_START_EVENT_TYPE,
				(argumentCaptorMapData.getValue()).get(EVENT_TYPE));

	}

	@Test
	public void shouldTriggerPromotionEndEventForEndDateToday()
			throws IOException, EventPublishException, JAXBException,
			ParseException, JSONException, PromotionEventException {

		CouchbaseViewConfig mockViewConfig = Mockito
				.mock(CouchbaseViewConfig.class);

		Map<String, String> viewQueryParams = new HashMap<String, String>();
		viewQueryParams.put("stale.state", "false");
		viewQueryParams.put("page.size", "2");
		viewQueryParams.put("timeout.interval", "60000");

		Map<String, String> viewQueryAddlParams = new HashMap<String, String>();
		viewQueryAddlParams.put("offset", "+00:00");
		viewQueryAddlParams.put("effectiveday", "0");

		Mockito.when(mockViewConfig.getViewQueryParams()).thenReturn(
				viewQueryParams);

		Mockito.when(mockViewConfig.getViewAdditionalProperties()).thenReturn(
				viewQueryAddlParams);

		Map<String, CouchbaseViewConfig> priceChangeViewConfig = new HashMap<String, CouchbaseViewConfig>();
		priceChangeViewConfig.put("PromotionEnd", mockViewConfig);

		Mockito.when(configuration.getCouchbaseViewConfig()).thenReturn(
				priceChangeViewConfig);

		String promotionEndEntityString = fixture("com/tesco/services/core/fixtures/promotion/SCHEDULED_PROMOTION_SINGLE.json");

		Response webViewResponse = Mockito.mock(Response.class);

		Mockito.when(webViewResponse.readEntity(String.class))
				.thenReturn(promotionEndEntityString).thenReturn(null);

		mockWebViewTemplate = Mockito.mock(WebViewTemplate.class);

		Mockito.when(
				mockWebViewTemplate.queryView(Matchers.anyMap(),
						Matchers.anyMap())).thenReturn(webViewResponse);

		promotionScheduledEventJob = new PromotionScheduledEventJob(
				configuration, mapper, promotionEventHandler,
				mockWebViewTemplate, SCHEDULED_PROMOTION_END_EVENT_TYPE);
		setCurrentMillisFixed(1464505782847l);

		promotionScheduledEventJob.processScheduledEvents();
		verify(promotionEventHandler, times(1)).publishPromotionEvent(
				argumentCaptorMapData.capture());
		assertEquals("Z", (argumentCaptorMapData.getValue()).get(LOC_TYPE));
		assertEquals("15", (argumentCaptorMapData.getValue()).get(LOC_REF));
		assertEquals("31918284",
				(argumentCaptorMapData.getValue()).get(OFFER_ID));
		assertEquals("1",
				(argumentCaptorMapData.getValue()).get(LEAD_TIME_DAYS));
		assertEquals(SCHEDULED_PROMOTION_END_EVENT_TYPE,
				(argumentCaptorMapData.getValue()).get(EVENT_TYPE));
	}

	@Test
	public void shouldTriggerPromotionStartProductForEffectiveDayTomorrow()
			throws IOException, EventPublishException, JAXBException,
			ParseException, JSONException, PromotionEventException {

		CouchbaseViewConfig mockViewConfig = Mockito
				.mock(CouchbaseViewConfig.class);

		Map<String, String> viewQueryParams = new HashMap<String, String>();
		viewQueryParams.put("stale.state", "false");
		viewQueryParams.put("page.size", "2");
		viewQueryParams.put("timeout.interval", "60000");

		Map<String, String> viewQueryAddlParams = new HashMap<String, String>();
		viewQueryAddlParams.put("offset", "+00:00");
		viewQueryAddlParams.put("effectiveday", "1");

		Mockito.when(mockViewConfig.getViewQueryParams()).thenReturn(
				viewQueryParams);

		Mockito.when(mockViewConfig.getViewAdditionalProperties()).thenReturn(
				viewQueryAddlParams);

		Map<String, CouchbaseViewConfig> priceChangeViewConfig = new HashMap<String, CouchbaseViewConfig>();
		priceChangeViewConfig.put("PromotionStartProduct", mockViewConfig);

		Mockito.when(configuration.getCouchbaseViewConfig()).thenReturn(
				priceChangeViewConfig);

		String promotionEndEntityString = fixture("com/tesco/services/core/fixtures/promotion/SCHEDULED_PROMOTION_START_PRODUCT.json");

		Response webViewResponse = Mockito.mock(Response.class);

		Mockito.when(webViewResponse.readEntity(String.class))
				.thenReturn(promotionEndEntityString).thenReturn(null);

		mockWebViewTemplate = Mockito.mock(WebViewTemplate.class);

		Mockito.when(
				mockWebViewTemplate.queryView(Matchers.anyMap(),
						Matchers.anyMap())).thenReturn(webViewResponse);

		promotionScheduledEventJob = new PromotionScheduledEventJob(
				configuration, mapper, promotionEventHandler,
				mockWebViewTemplate,
				SCHEDULED_PROMOTION_START_PRODUCT_EVENT_TYPE);
		setCurrentMillisFixed(1464505782847l);

		promotionScheduledEventJob.processScheduledEvents();
		verify(promotionEventHandler, times(1)).publishPromotionEvent(
				argumentCaptorMapData.capture());
		assertEquals("tpnb:050016211",
				(argumentCaptorMapData.getValue()).get(PROD_REF));
		assertEquals("31866745",
				(argumentCaptorMapData.getValue()).get(OFFER_ID));
		assertEquals("Z", (argumentCaptorMapData.getValue()).get(LOC_TYPE));
		assertEquals("5", (argumentCaptorMapData.getValue()).get(LOC_REF));
		assertEquals("1",
				(argumentCaptorMapData.getValue()).get(LEAD_TIME_DAYS));
		assertEquals(SCHEDULED_PROMOTION_START_PRODUCT_EVENT_TYPE,
				(argumentCaptorMapData.getValue()).get(EVENT_TYPE));
	}

	@Test
	public void shouldTriggerMultiplePromotionStartEventForEffectiveDateTomorrow()
			throws PromotionEventException, IOException, EventPublishException,
			JAXBException, ParseException, JSONException {

		CouchbaseViewConfig mockViewConfig = Mockito
				.mock(CouchbaseViewConfig.class);

		Map<String, String> viewQueryParams = new HashMap<String, String>();
		viewQueryParams.put("stale.state", "false");
		viewQueryParams.put("page.size", "2");
		viewQueryParams.put("timeout.interval", "60000");

		Map<String, String> viewQueryAddlParams = new HashMap<String, String>();
		viewQueryAddlParams.put("offset", "+00:00");
		viewQueryAddlParams.put("effectiveday", "1");

		Mockito.when(mockViewConfig.getViewQueryParams()).thenReturn(
				viewQueryParams);

		Mockito.when(mockViewConfig.getViewAdditionalProperties()).thenReturn(
				viewQueryAddlParams);

		Map<String, CouchbaseViewConfig> priceChangeViewConfig = new HashMap<String, CouchbaseViewConfig>();
		priceChangeViewConfig.put("PromotionStart", mockViewConfig);

		Mockito.when(configuration.getCouchbaseViewConfig()).thenReturn(
				priceChangeViewConfig);

		setCurrentMillisFixed(1464505782847l);

		promotionScheduledEventJob = new PromotionScheduledEventJob(
				configuration, mapper, promotionEventHandler,
				mockWebViewTemplate, SCHEDULED_PROMOTION_START_EVENT_TYPE);

		Response webViewResponse = Mockito.mock(Response.class);

		Mockito.when(webViewResponse.readEntity(String.class))
				.thenReturn(promotionEntityMultipleRecord).thenReturn(null);

		Mockito.when(
				mockWebViewTemplate.queryView(Matchers.anyMap(),
						Matchers.anyMap())).thenReturn(webViewResponse);

		promotionScheduledEventJob.processScheduledEvents();

		List<Map<String, String>> captorData = argumentCaptorMapData
				.getAllValues();
		verify(promotionEventHandler, times(2)).publishPromotionEvent(
				argumentCaptorMapData.capture());
		assertEquals("Z", (captorData.get(0)).get(LOC_TYPE));
		assertEquals("15", (captorData.get(0)).get(LOC_REF));
		assertEquals("31918284", (captorData.get(0)).get(OFFER_ID));
		assertEquals("1", (captorData.get(0)).get(LEAD_TIME_DAYS));
		assertEquals(SCHEDULED_PROMOTION_START_EVENT_TYPE,
				(captorData.get(0)).get(EVENT_TYPE));
		assertEquals("Z", (captorData.get(1)).get(LOC_TYPE));
		assertEquals("13", (captorData.get(1)).get(LOC_REF));
		assertEquals("31944914", (captorData.get(1)).get(OFFER_ID));
		assertEquals("1", (captorData.get(1)).get(LEAD_TIME_DAYS));
		assertEquals(SCHEDULED_PROMOTION_START_EVENT_TYPE,
				(captorData.get(1)).get(EVENT_TYPE));

	}

	@Test
	public void shouldTriggerMultiplePromotionEndEventForEndDateToday()
			throws PromotionEventException, IOException, EventPublishException,
			JAXBException, ParseException, JSONException {

		CouchbaseViewConfig mockViewConfig = Mockito
				.mock(CouchbaseViewConfig.class);

		Map<String, String> viewQueryParams = new HashMap<String, String>();
		viewQueryParams.put("stale.state", "false");
		viewQueryParams.put("page.size", "2");
		viewQueryParams.put("timeout.interval", "60000");

		Map<String, String> viewQueryAddlParams = new HashMap<String, String>();
		viewQueryAddlParams.put("offset", "+00:00");
		viewQueryAddlParams.put("effectiveday", "0");

		Mockito.when(mockViewConfig.getViewQueryParams()).thenReturn(
				viewQueryParams);

		Mockito.when(mockViewConfig.getViewAdditionalProperties()).thenReturn(
				viewQueryAddlParams);

		Map<String, CouchbaseViewConfig> priceChangeViewConfig = new HashMap<String, CouchbaseViewConfig>();
		priceChangeViewConfig.put("PromotionEnd", mockViewConfig);

		Mockito.when(configuration.getCouchbaseViewConfig()).thenReturn(
				priceChangeViewConfig);

		Response webViewResponse = Mockito.mock(Response.class);

		Mockito.when(webViewResponse.readEntity(String.class))
				.thenReturn(promotionEntityMultipleRecord).thenReturn(null);

		mockWebViewTemplate = Mockito.mock(WebViewTemplate.class);

		Mockito.when(
				mockWebViewTemplate.queryView(Matchers.anyMap(),
						Matchers.anyMap())).thenReturn(webViewResponse);

		setCurrentMillisFixed(1464505782847l);

		promotionScheduledEventJob = new PromotionScheduledEventJob(
				configuration, mapper, promotionEventHandler,
				mockWebViewTemplate, SCHEDULED_PROMOTION_END_EVENT_TYPE);

		promotionScheduledEventJob.processScheduledEvents();
		List<Map<String, String>> captorData = argumentCaptorMapData
				.getAllValues();
		verify(promotionEventHandler, times(2)).publishPromotionEvent(
				argumentCaptorMapData.capture());
		assertEquals("Z", (captorData.get(0)).get(LOC_TYPE));
		assertEquals("15", (captorData.get(0)).get(LOC_REF));
		assertEquals("31918284", (captorData.get(0)).get(OFFER_ID));
		assertEquals("1", (captorData.get(0)).get(LEAD_TIME_DAYS));
		assertEquals(SCHEDULED_PROMOTION_END_EVENT_TYPE,
				(captorData.get(0)).get(EVENT_TYPE));
		assertEquals("Z", (captorData.get(1)).get(LOC_TYPE));
		assertEquals("13", (captorData.get(1)).get(LOC_REF));
		assertEquals("31944914", (captorData.get(1)).get(OFFER_ID));
		assertEquals("1", (captorData.get(1)).get(LEAD_TIME_DAYS));
		assertEquals(SCHEDULED_PROMOTION_END_EVENT_TYPE,
				(captorData.get(1)).get(EVENT_TYPE));

	}

	@Test
	public void shouldTriggerMultiplePromotionStartProductEventForEffectiveDateTomorrow()
			throws PromotionEventException, IOException, EventPublishException,
			JAXBException, ParseException, JSONException {

		CouchbaseViewConfig mockViewConfig = Mockito
				.mock(CouchbaseViewConfig.class);

		Map<String, String> viewQueryParams = new HashMap<String, String>();
		viewQueryParams.put("stale.state", "false");
		viewQueryParams.put("page.size", "2");
		viewQueryParams.put("timeout.interval", "60000");

		Map<String, String> viewQueryAddlParams = new HashMap<String, String>();
		viewQueryAddlParams.put("offset", "+00:00");
		viewQueryAddlParams.put("effectiveday", "1");

		Mockito.when(mockViewConfig.getViewQueryParams()).thenReturn(
				viewQueryParams);

		Mockito.when(mockViewConfig.getViewAdditionalProperties()).thenReturn(
				viewQueryAddlParams);

		Map<String, CouchbaseViewConfig> promotionStartViewConfig = new HashMap<String, CouchbaseViewConfig>();
		promotionStartViewConfig.put("PromotionStartProduct", mockViewConfig);

		Mockito.when(configuration.getCouchbaseViewConfig()).thenReturn(
				promotionStartViewConfig);

		setCurrentMillisFixed(1464505782847l);
		String promotionEntityMultipleRecord = fixture("com/tesco/services/core/fixtures/promotion/SCHEDULED_PROMOTION_START_PRODUCT_MULTIPLE.json");

		promotionScheduledEventJob = new PromotionScheduledEventJob(
				configuration, mapper, promotionEventHandler,
				mockWebViewTemplate,
				SCHEDULED_PROMOTION_START_PRODUCT_EVENT_TYPE);

		Response webViewResponse = Mockito.mock(Response.class);

		Mockito.when(webViewResponse.readEntity(String.class))
				.thenReturn(promotionEntityMultipleRecord).thenReturn(null);

		Mockito.when(
				mockWebViewTemplate.queryView(Matchers.anyMap(),
						Matchers.anyMap())).thenReturn(webViewResponse);

		promotionScheduledEventJob.processScheduledEvents();

		List<Map<String, String>> captorData = argumentCaptorMapData
				.getAllValues();
		verify(promotionEventHandler, times(2)).publishPromotionEvent(
				argumentCaptorMapData.capture());
		assertEquals("tpnb:050016211", (captorData.get(0)).get(PROD_REF));
		assertEquals("Z", (captorData.get(0)).get(LOC_TYPE));
		assertEquals("5", (captorData.get(0)).get(LOC_REF));
		assertEquals("31866745", (captorData.get(0)).get(OFFER_ID));
		assertEquals("1", (captorData.get(0)).get(LEAD_TIME_DAYS));
		assertEquals(SCHEDULED_PROMOTION_START_PRODUCT_EVENT_TYPE,
				(captorData.get(0)).get(EVENT_TYPE));
		assertEquals("tpnb:050016222", (captorData.get(1)).get(PROD_REF));
		assertEquals("Z", (captorData.get(1)).get(LOC_TYPE));
		assertEquals("15", (captorData.get(1)).get(LOC_REF));
		assertEquals("31866746", (captorData.get(1)).get(OFFER_ID));
		assertEquals("1", (captorData.get(1)).get(LEAD_TIME_DAYS));
		assertEquals(SCHEDULED_PROMOTION_START_PRODUCT_EVENT_TYPE,
				(captorData.get(1)).get(EVENT_TYPE));
	}

	@After
	public void tearDown() {
		setCurrentMillisSystem();
	}

}
