package com.tesco.services.utility;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.tesco.services.Configuration;
import com.tesco.services.resources.TestConfiguration;

/**
 * Created by QU17 on 4/1/2015.
 */
@RunWith(MockitoJUnitRunner.class)
public class FileOperationsTest {
	@Mock
	private static Configuration testConfiguration;

	@Mock
	private FileOperations fileOperations;

	@Mock
	private File file;

	@Mock
	private FileReader fileReader;

	@Mock
	private BufferedReader bufferedReader;

	@Mock
	private FileWriter fileWriter;

	@Mock
	private BufferedWriter bufferedWriter;

	@Before
	public void setUp() throws Exception {

		testConfiguration = TestConfiguration.load();

		fileOperations = new FileOperations();
	}

	@Test
	public void testWriteToFile() throws Exception {

		fileOperations.setFile(file);
		fileOperations.setFileWriter(fileWriter);
		fileOperations.setBufferedWriter(bufferedWriter);
		fileOperations.writeFailedProductDetailsToFile(testConfiguration,
				"fileName", "Id");
		assertThat(fileOperations.getBufferedWriter(fileWriter)).isEqualTo(
				bufferedWriter);

	}

	@Test
	public void testGetFailedProdFromFile() throws Exception {
		String failedProduct = "";
		fileOperations.setFile(file);
		fileOperations.setFileReader(fileReader);
		fileOperations.setBufferedReader(bufferedReader);
		assertThat(
				fileOperations.getfailedProductInProviousRunIfExist(
						testConfiguration, "fileName"))
				.isEqualTo(failedProduct);

	}

	@Test
	public void testGetFailedProdFromFileCatchBlock() throws Exception {
		String failedProduct = null;
		fileOperations.setFile(file);
		fileOperations.setFileReader(fileReader);
		fileOperations.setBufferedReader(bufferedReader);
		when(bufferedReader.readLine()).thenThrow(new FileNotFoundException());
		assertThat(
				fileOperations.getfailedProductInProviousRunIfExist(
						testConfiguration, "fileName"))
				.isEqualTo(failedProduct);

	}
}
