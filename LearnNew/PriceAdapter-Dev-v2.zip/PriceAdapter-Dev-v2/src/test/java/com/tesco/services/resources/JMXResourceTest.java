package com.tesco.services.resources;

import static org.fest.assertions.api.Assertions.assertThat;
import io.dropwizard.testing.junit.ResourceTestRule;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

import org.junit.After;
import org.junit.Before;
import org.junit.ClassRule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.tesco.services.adapters.core.utils.JMXClient;
import com.tesco.services.adapters.core.utils.LatencyMetrics;
import com.tesco.services.adapters.core.utils.RateMetrics;
import com.tesco.services.adapters.core.utils.TimerMetrics;
import com.tesco.services.exceptions.PriceJMXException;
import com.tesco.services.exceptions.PromoJMXException;
import com.tesco.services.exceptions.ZoneJMXException;

@RunWith(MockitoJUnitRunner.class)
public class JMXResourceTest {

	static JMXClient mockJmxClient = Mockito.mock(JMXClient.class);

	static ObjectMapper mockObjectMapper = new ObjectMapper();

	Map<String, TimerMetrics> metricsData;
	Map<String, TimerMetrics> metricsDataReset;

	Map<String, TimerMetrics> priceMetricsData;
	Map<String, TimerMetrics> priceMetricsDataReset;

	Map<String, TimerMetrics> zoneMetricsData;
	Map<String, TimerMetrics> zoneMetricsDataReset;

	@ClassRule
	public static final ResourceTestRule resources = ResourceTestRule.builder()
			.addResource(new JMXResource(mockJmxClient, mockObjectMapper))
			.build();

	@Before
	public void setUpResources() throws Exception {
		mockObjectMapper = new ObjectMapper();
		mockObjectMapper.configure(SerializationFeature.INDENT_OUTPUT, true);

		metricsData = new LinkedHashMap<String, TimerMetrics>();
		TimerMetrics promoTimerMetric = new TimerMetrics();
		promoTimerMetric.setLatency(new LatencyMetrics());
		promoTimerMetric.setThroughput(new RateMetrics());

		promoTimerMetric.setCount("1");

		promoTimerMetric.getLatency().setMinResponseTime("55.31768");

		promoTimerMetric.getLatency().setMaxResponseTime("2378.090256");

		promoTimerMetric.getLatency().setMeanResponseTime("254.31227653731344");

		promoTimerMetric.getLatency().setLatencyUnit("MILLISECONDS");

		promoTimerMetric.getThroughput()
				.setOneMinuteRate("0.10147519214675003");

		promoTimerMetric.getThroughput()
				.setFiveMinuteRate("0.1376148189207803");

		promoTimerMetric.getThroughput().setFifteenMinuteRate(
				"0.06333774449299202");

		promoTimerMetric.getThroughput().setMeanRate("0.3678707903451512");

		promoTimerMetric.getThroughput().setRateUnit("SECONDS");

		metricsData.put("OverallElapsedTimeAndRate" + " - "
				+ "time-to-process-message", promoTimerMetric);

		metricsDataReset = new LinkedHashMap<String, TimerMetrics>();
		promoTimerMetric = new TimerMetrics();
		promoTimerMetric.setLatency(new LatencyMetrics());
		promoTimerMetric.setThroughput(new RateMetrics());

		promoTimerMetric.setCount("0");

		promoTimerMetric.getLatency().setMinResponseTime("0.0");

		promoTimerMetric.getLatency().setMaxResponseTime("0.0");

		promoTimerMetric.getLatency().setMeanResponseTime("0.0");

		promoTimerMetric.getLatency().setLatencyUnit("MILLISECONDS");

		promoTimerMetric.getThroughput().setOneMinuteRate("0.0");

		promoTimerMetric.getThroughput().setFiveMinuteRate("0.0");

		promoTimerMetric.getThroughput().setFifteenMinuteRate("0.0");

		promoTimerMetric.getThroughput().setMeanRate("0.0");

		promoTimerMetric.getThroughput().setRateUnit("SECONDS");

		metricsDataReset.put("OverallElapsedTimeAndRate" + " - "
				+ "time-to-process-message", promoTimerMetric);

		Mockito.doNothing().when(mockJmxClient).resetPromotionMetrics();

		Mockito.when(mockJmxClient.getPromotionLoadMetrics())
				.thenReturn(metricsData).thenThrow(new PromoJMXException())
				.thenReturn(new LinkedHashMap<String, TimerMetrics>())
				.thenReturn(null).thenReturn(metricsDataReset)
				.thenThrow(new PromoJMXException());

		setUpZoneResources();
		setUpPriceResources();

	}

	private void setUpZoneResources() throws ZoneJMXException {
		zoneMetricsData = new LinkedHashMap<String, TimerMetrics>();
		TimerMetrics zoneTimerMetric = new TimerMetrics();
		zoneTimerMetric.setLatency(new LatencyMetrics());
		zoneTimerMetric.setThroughput(new RateMetrics());

		zoneTimerMetric.setCount("1");
		zoneTimerMetric.getLatency().setMinResponseTime("23.31768");
		zoneTimerMetric.getLatency().setMaxResponseTime("1278.090256");
		zoneTimerMetric.getLatency().setMeanResponseTime("104.31227653731344");
		zoneTimerMetric.getLatency().setLatencyUnit("MILLISECONDS");
		zoneTimerMetric.getThroughput().setOneMinuteRate("0.10147519214675003");
		zoneTimerMetric.getThroughput().setFiveMinuteRate("0.1376148189207803");
		zoneTimerMetric.getThroughput().setFifteenMinuteRate(
				"0.06333774449299202");
		zoneTimerMetric.getThroughput().setMeanRate("0.3678707903451512");
		zoneTimerMetric.getThroughput().setRateUnit("SECONDS");

		zoneMetricsData.put("OverallElapsedTimeAndRate" + " - "
				+ "time-to-process-message", zoneTimerMetric);

		zoneMetricsDataReset = new LinkedHashMap<String, TimerMetrics>();
		zoneTimerMetric = new TimerMetrics();
		zoneTimerMetric.setLatency(new LatencyMetrics());
		zoneTimerMetric.setThroughput(new RateMetrics());

		zoneTimerMetric.setCount("0");
		zoneTimerMetric.getLatency().setMinResponseTime("0.0");
		zoneTimerMetric.getLatency().setMaxResponseTime("0.0");
		zoneTimerMetric.getLatency().setMeanResponseTime("0.0");
		zoneTimerMetric.getLatency().setLatencyUnit("MILLISECONDS");
		zoneTimerMetric.getThroughput().setOneMinuteRate("0.0");
		zoneTimerMetric.getThroughput().setFiveMinuteRate("0.0");
		zoneTimerMetric.getThroughput().setFifteenMinuteRate("0.0");
		zoneTimerMetric.getThroughput().setMeanRate("0.0");
		zoneTimerMetric.getThroughput().setRateUnit("SECONDS");

		zoneMetricsDataReset.put("OverallElapsedTimeAndRate" + " - "
				+ "time-to-process-message", zoneTimerMetric);

		Mockito.doNothing().when(mockJmxClient).resetZoneMetrics();

		Mockito.when(mockJmxClient.getZoneLoadMetrics())
				.thenReturn(zoneMetricsData).thenThrow(new ZoneJMXException())
				.thenReturn(new LinkedHashMap<String, TimerMetrics>())
				.thenReturn(null).thenReturn(zoneMetricsDataReset)
				.thenThrow(new ZoneJMXException());
	}

	private void setUpPriceResources() throws PriceJMXException {
		priceMetricsData = new LinkedHashMap<String, TimerMetrics>();
		TimerMetrics priceTimerMetric = new TimerMetrics();
		priceTimerMetric.setLatency(new LatencyMetrics());
		priceTimerMetric.setThroughput(new RateMetrics());

		priceTimerMetric.setCount("1");
		priceTimerMetric.getLatency().setMinResponseTime("23.31768");
		priceTimerMetric.getLatency().setMaxResponseTime("1278.090256");
		priceTimerMetric.getLatency().setMeanResponseTime("104.31227653731344");
		priceTimerMetric.getLatency().setLatencyUnit("MILLISECONDS");
		priceTimerMetric.getThroughput()
				.setOneMinuteRate("0.10147519214675003");
		priceTimerMetric.getThroughput()
				.setFiveMinuteRate("0.1376148189207803");
		priceTimerMetric.getThroughput().setFifteenMinuteRate(
				"0.06333774449299202");
		priceTimerMetric.getThroughput().setMeanRate("0.3678707903451512");
		priceTimerMetric.getThroughput().setRateUnit("SECONDS");

		priceMetricsData.put("OverallElapsedTimeAndRate" + " - "
				+ "time-to-process-message", priceTimerMetric);

		priceMetricsDataReset = new LinkedHashMap<String, TimerMetrics>();
		priceTimerMetric = new TimerMetrics();
		priceTimerMetric.setLatency(new LatencyMetrics());
		priceTimerMetric.setThroughput(new RateMetrics());

		priceTimerMetric.setCount("0");
		priceTimerMetric.getLatency().setMinResponseTime("0.0");
		priceTimerMetric.getLatency().setMaxResponseTime("0.0");
		priceTimerMetric.getLatency().setMeanResponseTime("0.0");
		priceTimerMetric.getLatency().setLatencyUnit("MILLISECONDS");
		priceTimerMetric.getThroughput().setOneMinuteRate("0.0");
		priceTimerMetric.getThroughput().setFiveMinuteRate("0.0");
		priceTimerMetric.getThroughput().setFifteenMinuteRate("0.0");
		priceTimerMetric.getThroughput().setMeanRate("0.0");
		priceTimerMetric.getThroughput().setRateUnit("SECONDS");

		priceMetricsDataReset.put("OverallElapsedTimeAndRate" + " - "
				+ "time-to-process-message", priceTimerMetric);

		Mockito.doNothing().when(mockJmxClient).resetPriceMetrics();

		Mockito.when(mockJmxClient.getPriceLoadMetrics())
				.thenReturn(priceMetricsData)
				.thenThrow(new PriceJMXException())
				.thenReturn(new LinkedHashMap<String, TimerMetrics>())
				.thenReturn(null).thenReturn(priceMetricsDataReset)
				.thenThrow(new PriceJMXException());
	}

	@Test
	public void testGetMetrics() throws IOException {
		WebTarget resource = resources.client().target(
				"/admin/jmx/promo/refresh");
		Response response = resource.request().get();

		final String respMetricsData = response.readEntity(String.class);

		final ByteArrayOutputStream promoMetricsPrettyPrint = new ByteArrayOutputStream();

		mockObjectMapper.writeValue(promoMetricsPrettyPrint, metricsData);

		assertThat(respMetricsData).isEqualTo(
				promoMetricsPrettyPrint.toString());

		assertThat(response.getStatus()).isEqualTo(200);

		resource = resources.client().target("/admin/jmx/promo/refresh");
		response = resource.request().get();
		String responseText = response.readEntity(String.class);
		assertThat(responseText).containsOnlyOnce(
				"Error: Unable to process command");
		assertThat(response.getStatus()).isEqualTo(200);

		resource = resources.client().target("/admin/jmx/promo/refresh");
		response = resource.request().get();
		responseText = response.readEntity(String.class);
		assertThat(responseText).isEqualTo("Invalid Command");
		assertThat(response.getStatus()).isEqualTo(200);

		resource = resources.client().target("/admin/jmx/promo/refresh");
		response = resource.request().get();
		responseText = response.readEntity(String.class);
		assertThat(responseText).isEqualTo("Invalid Command");
		assertThat(response.getStatus()).isEqualTo(200);

		resource = resources.client().target("/admin/jmx/promo/reset");
		response = resource.request().get();
		final String respMetricsDataReset = response.readEntity(String.class);
		final ByteArrayOutputStream promoMetricsPrettyPrintReset = new ByteArrayOutputStream();
		mockObjectMapper.writeValue(promoMetricsPrettyPrintReset,
				metricsDataReset);
		assertThat(respMetricsDataReset).isEqualTo(
				promoMetricsPrettyPrintReset.toString());
		assertThat(response.getStatus()).isEqualTo(200);

		resource = resources.client().target("/admin/jmx/promo/reset");
		response = resource.request().get();
		responseText = response.readEntity(String.class);
		assertThat(responseText).containsOnlyOnce(
				"Error: Unable to process command");
		assertThat(response.getStatus()).isEqualTo(200);
	}

	@Test
	public void testGetMetricsInvalid() {
		WebTarget resource = resources.client().target(
				"/admin/jmx/promo/refresh1");
		Response response = resource.request().get();
		String responseText = response.readEntity(String.class);
		assertThat(responseText).isEqualTo("Invalid Command");
		assertThat(response.getStatus()).isEqualTo(200);
	}

	@Test
	public void testGetPriceStatMetricsInvalid() {
		WebTarget resource = resources.client().target(
				"/admin/jmx/price/refresh1");
		Response response = resource.request().get();
		String responseText = response.readEntity(String.class);
		assertThat(responseText).isEqualTo("Invalid Command");
		assertThat(response.getStatus()).isEqualTo(200);
	}

	@Test
	public void testGetZoneStatMetricsInvalid() {
		WebTarget resource = resources.client().target(
				"/admin/jmx/zone/refresh1");
		Response response = resource.request().get();
		String responseText = response.readEntity(String.class);
		assertThat(responseText).isEqualTo("Invalid Command");
		assertThat(response.getStatus()).isEqualTo(200);
	}

	@Test
	public void testGetPriceStatMetrics() throws IOException {
		WebTarget resource = resources.client().target(
				"/admin/jmx/price/refresh");
		Response response = resource.request().get();

		final String respMetricsData = response.readEntity(String.class);
		final ByteArrayOutputStream priceMetricsPrettyPrint = new ByteArrayOutputStream();

		mockObjectMapper.writeValue(priceMetricsPrettyPrint, priceMetricsData);
		assertThat(respMetricsData).isEqualTo(
				priceMetricsPrettyPrint.toString());
		assertThat(response.getStatus()).isEqualTo(200);

		resource = resources.client().target("/admin/jmx/price/refresh");
		response = resource.request().get();
		String responseText = response.readEntity(String.class);
		assertThat(responseText).containsOnlyOnce(
				"Error: Unable to process command");
		assertThat(response.getStatus()).isEqualTo(200);

		resource = resources.client().target("/admin/jmx/price/refresh");
		response = resource.request().get();
		responseText = response.readEntity(String.class);
		assertThat(responseText).isEqualTo("Invalid Command");
		assertThat(response.getStatus()).isEqualTo(200);

		resource = resources.client().target("/admin/jmx/price/refresh");
		response = resource.request().get();
		responseText = response.readEntity(String.class);
		assertThat(responseText).isEqualTo("Invalid Command");
		assertThat(response.getStatus()).isEqualTo(200);

		resource = resources.client().target("/admin/jmx/price/reset");
		response = resource.request().get();
		final String respMetricsDataReset = response.readEntity(String.class);
		final ByteArrayOutputStream priceMetricsPrettyPrintReset = new ByteArrayOutputStream();
		mockObjectMapper.writeValue(priceMetricsPrettyPrintReset,
				priceMetricsDataReset);
		assertThat(respMetricsDataReset).isEqualTo(
				priceMetricsPrettyPrintReset.toString());
		assertThat(response.getStatus()).isEqualTo(200);

		resource = resources.client().target("/admin/jmx/price/reset");
		response = resource.request().get();
		responseText = response.readEntity(String.class);
		assertThat(responseText).containsOnlyOnce(
				"Error: Unable to process command");
		assertThat(response.getStatus()).isEqualTo(200);
	}

	@Test
	public void testGetZoneStatMetrics() throws JsonGenerationException,
			JsonMappingException, IOException {

		WebTarget resource = resources.client().target(
				"/admin/jmx/zone/refresh");
		Response response = resource.request().get();

		final String respMetricsData = response.readEntity(String.class);
		final ByteArrayOutputStream zoneMetricsPrettyPrint = new ByteArrayOutputStream();

		mockObjectMapper.writeValue(zoneMetricsPrettyPrint, zoneMetricsData);
		assertThat(respMetricsData)
				.isEqualTo(zoneMetricsPrettyPrint.toString());
		assertThat(response.getStatus()).isEqualTo(200);

		resource = resources.client().target("/admin/jmx/zone/refresh");
		response = resource.request().get();
		String responseText = response.readEntity(String.class);
		assertThat(responseText).containsOnlyOnce(
				"Error: Unable to process command");
		assertThat(response.getStatus()).isEqualTo(200);

		resource = resources.client().target("/admin/jmx/zone/refresh");
		response = resource.request().get();
		responseText = response.readEntity(String.class);
		assertThat(responseText).isEqualTo("Invalid Command");
		assertThat(response.getStatus()).isEqualTo(200);

		resource = resources.client().target("/admin/jmx/zone/refresh");
		response = resource.request().get();
		responseText = response.readEntity(String.class);
		assertThat(responseText).isEqualTo("Invalid Command");
		assertThat(response.getStatus()).isEqualTo(200);

		resource = resources.client().target("/admin/jmx/zone/reset");
		response = resource.request().get();
		final String respMetricsDataReset = response.readEntity(String.class);
		final ByteArrayOutputStream zoneMetricsPrettyPrintReset = new ByteArrayOutputStream();
		mockObjectMapper.writeValue(zoneMetricsPrettyPrintReset,
				zoneMetricsDataReset);
		assertThat(respMetricsDataReset).isEqualTo(
				zoneMetricsPrettyPrintReset.toString());
		assertThat(response.getStatus()).isEqualTo(200);

		resource = resources.client().target("/admin/jmx/zone/reset");
		response = resource.request().get();
		responseText = response.readEntity(String.class);
		assertThat(responseText).containsOnlyOnce(
				"Error: Unable to process command");
		assertThat(response.getStatus()).isEqualTo(200);
	}

	@After
	public void tearDown() throws Exception {
		Mockito.reset(mockJmxClient);
		metricsData = null;
		zoneMetricsData = null;
	}

}
