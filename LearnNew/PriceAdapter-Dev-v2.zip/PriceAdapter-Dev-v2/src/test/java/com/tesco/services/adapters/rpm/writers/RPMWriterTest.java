package com.tesco.services.adapters.rpm.writers;

import com.google.common.base.Optional;
import com.tesco.couchbase.AsyncCouchbaseWrapper;
import com.tesco.couchbase.CouchbaseWrapper;
import com.tesco.couchbase.testutils.CouchbaseTestManager;
import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.exceptions.WriterBusinessException;
import com.tesco.services.adapters.rpm.comparators.RPMComparator;
import com.tesco.services.adapters.rpm.readers.PriceServiceCSVReader;
import com.tesco.services.adapters.rpm.writers.impl.ProductMapper;
import com.tesco.services.adapters.rpm.writers.impl.RPMWriter;
import com.tesco.services.adapters.sonetto.SonettoPromotionXMLReader;
import com.tesco.services.builder.PromotionBuilder;
import com.tesco.services.core.*;
import com.tesco.services.repositories.RepositoryImpl;
import com.tesco.services.repositories.UUIDGenerator;
import com.tesco.services.resources.TestConfiguration;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.PriceConstants;
import net.spy.memcached.internal.OperationFuture;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.internal.matchers.CapturingMatcher;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.runners.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;

import java.io.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.argThat;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
@SuppressWarnings({ "rawtypes", "unused", "static-access", "unchecked",
		"serial" })
public class RPMWriterTest {
	private RPMWriter rpmWriter;

	@Mock
	private SonettoPromotionXMLReader sonettoPromotionXMLReader;

	@Mock
	private PriceServiceCSVReader rpmPriceReader;

	@Mock
	private PriceServiceCSVReader rpmPromoPriceReader;

	@Mock
	private PriceServiceCSVReader storeZoneReader;

	@Mock
	private PriceServiceCSVReader rpmPromotionReader;

	@Mock
	private PriceServiceCSVReader rpmPromotionDescReader;

	@Mock
	private UUIDGenerator uuidGenerator;

	@Mock
	public RepositoryImpl repositoryImpl;

	@Mock
	public AsyncCouchbaseWrapper asyncCouchbaseWrapper;

	@Mock
	public CouchbaseWrapper couchbaseWrapper;

	@Mock
	public OperationFuture<?> operationFuture;
	@Mock
	private ProductMapper mapper;

	@Mock
	BufferedWriter bufferedWriter;

	@Mock
	private CouchbaseTestManager couchbaseTestManager;

	private int zoneId = 1;
	private Promotion promotionForProduct = null;
	/* Added by Nitisha and Surya for Junit Corrections for PS-112 - Start */
	private String sellingUOM = "KG";
	/* Added by Nitisha and Surya for Junit Corrections for PS-112 - End */
	private static Configuration testConfiguration;

	@Before
	public void setUp() throws WriterBusinessException,IOException {

		testConfiguration = TestConfiguration.load();

		mapper = new ProductMapper();
		mapper.setConfiguration(testConfiguration);
		mapper.setRepository(repositoryImpl);

		rpmWriter = new RPMWriter(testConfiguration, couchbaseWrapper,
				repositoryImpl,  mapper,
				rpmPriceReader, rpmPromoPriceReader, storeZoneReader,
				rpmPromotionReader, rpmPromotionDescReader,
				sonettoPromotionXMLReader);

		rpmWriter.setRepository(repositoryImpl);


		when(rpmPriceReader.getNext()).thenReturn(null);
		when(rpmPromoPriceReader.getNext()).thenReturn(null);
		when(storeZoneReader.getNext()).thenReturn(null);
		when(rpmPromotionReader.getNext()).thenReturn(null);
		when(rpmPromotionDescReader.getNext()).thenReturn(null);

		when(uuidGenerator.getUUID()).thenReturn("uuid");
	}

	@Test
	public void shouldInsertPriceZonePrice() throws Exception {
		String tpnb = "059428124";
		String tpnc = "284347092";
		ProductVariant productVariant = new ProductVariant(tpnc);
		String price = "2.4";
		productVariant.addSaleInfo(new SaleInfo(zoneId, price));
		/* Added by Nitisha and Surya for PS-112 Junits corrections- Start */
		productVariant.setSellingUOM(sellingUOM);
		/* Added by Nitisha and Surya for PS-112 Junits corrections- Start */
		final Product product = createProduct(tpnb, productVariant);

		Map<String, String> productInfoMap = productInfoMap(tpnb, tpnc, zoneId,
				price);
		when(rpmPriceReader.getNext()).thenReturn(
				productInfoMap).thenReturn(null);

		when(repositoryImpl.getGenericObject(
				PriceConstants.PRODUCT_KEY_PREFIX +tpnb, Product.class,
				true)).thenReturn(
				Optional.<Product>absent());
		Mockito.doNothing()
				.when(repositoryImpl)
				.mapLookUps(Matchers.any(String.class),
						Matchers.any(String.class));

		Mockito.doAnswer(new Answer() {
			@Override
			public Object answer(InvocationOnMock invocation) throws Throwable {
				rpmWriter.getListener().onComplete(null);
				return null;
			}
		})
				.when(repositoryImpl)
				.insertObject(Matchers.any(String.class),
						Matchers.any(Product.class));

		rpmWriter.write(null);

		assertThat("done").isEqualTo(rpmWriter.getRpmWriteStatus());

	}

	@Test
	public void shouldInsertPriceZoneFail() throws Exception {
		String tpnb = "059428124";
		String tpnc = "284347092";
		ProductVariant productVariant = new ProductVariant(tpnc);
		String price = "2.4";
		productVariant.addSaleInfo(new SaleInfo(zoneId, price));
		/* Added by Nitisha and Surya for PS-112 Junits corrections- Start */
		productVariant.setSellingUOM(sellingUOM);
		/* Added by Nitisha and Surya for PS-112 Junits corrections- Start */

		final Product product = createProduct(tpnb, productVariant);

		Map<String, String> productInfoMap = productInfoMap(tpnb, tpnc, zoneId,
				price);
		when(rpmPriceReader.getNext()).thenReturn(
				productInfoMap).thenReturn(null);
		when(repositoryImpl.getGenericObject(
				PriceConstants.PRODUCT_KEY_PREFIX + tpnb, Product.class,
				true)).thenReturn(
				Optional.<Product>absent());
		Mockito.doNothing()
				.when(repositoryImpl)
				.mapLookUps(Matchers.any(String.class),
						Matchers.any(String.class));

		Mockito.doAnswer(new Answer() {
			@Override
			public Object answer(InvocationOnMock invocation) throws Throwable {
				rpmWriter.getListener().onException(null);
				return null;
			}
		})
				.when(repositoryImpl)
				.insertObject(Matchers.any(String.class),
						Matchers.any(Product.class));

		rpmWriter.write(null);

		assertThat("failed").isEqualTo(rpmWriter.getRpmWriteStatus());

	}

	@Test
	public void shouldInsertMultiplePriceZonePricesForAVariant()
			throws Exception {
		String itemNumber = "0123";
		String tpnc = "284347092";

		when(rpmPriceReader.getNext())
				.thenReturn(productInfoMap(itemNumber, tpnc, 2, "2.4"))
				.thenReturn(productInfoMap(itemNumber, tpnc, 4, "4.4"))
				.thenReturn(null);

		Product product = createProductWithVariant(itemNumber, tpnc);
		// Changes made By Surya for PS-120 . The JUnit should pass for the Code
		// which will Create a new Product for the first time and then amend
		// Multiple Price zones- Start
		when(repositoryImpl.getGenericObject(
				PriceConstants.PRODUCT_KEY_PREFIX + itemNumber, Product.class,
				true)).thenReturn(
				Optional.of(product));
		// Changes made By Surya for PS-120 . The JUnit should pass for the Code
		// which will Create a new Product for the first time and then amend
		// Multiple Price zones - End

		this.rpmWriter.write(null);

		InOrder inOrder = inOrder(repositoryImpl);

		ProductVariant expectedProductVariant = createProductVariant(tpnc, 2,
				"2.4", null);
		final Product expectedProduct = createProduct(itemNumber,
				expectedProductVariant);
		/*
		 * PS-238 Modified By Nibedita - to resolve errors after code
		 * modification - Start
		 */
		expectedProductVariant.addSaleInfo(new SaleInfo(4, "4.4"));
		/*
		 * PS-238 Modified By Nibedita - to resolve errors after code
		 * modification - End
		 */
		inOrder.verify(repositoryImpl).insertObject(any(String.class),
				argThat(new CapturingMatcher<Product>() {
					@Override
					public boolean matches(Object o) {
						Product prod = (Product) o;
						return new RPMComparator().compare(prod,
								expectedProduct);
					}
				}));
	}

	@Test
	public void shouldInsertPriceZonePricesForMultipleVariants()
			throws Exception {
		String tpnb = "1123";
		String tpnc = "284347092";
		String tpnc2 = "304347092";
		String itemNumber = String.format("%s-001", tpnb);
		String itemNumber2 = String.format("%s-002", tpnb);

		when(rpmPriceReader.getNext())
				.thenReturn(productInfoMap(tpnb, tpnc, 2, "2.4"))
				.thenReturn(productInfoMap(itemNumber2, tpnc2, 3, "3.0"))
				.thenReturn(null);

		Product product = createProductWithVariant(tpnb, tpnc);

		when(repositoryImpl.getGenericObject(
				PriceConstants.PRODUCT_KEY_PREFIX + tpnb, Product.class,
				true)).thenReturn(
				Optional.<Product> absent()).thenReturn(Optional.of(product));

		this.rpmWriter.write(null);

		InOrder inOrder = inOrder(repositoryImpl);
		final Product expectedProduct = createProductWithVariant(tpnb, tpnc);
		/*
		 * PS-238 Modified By Nibedita - to resolve errors after code
		 * modification - Start
		 */
		ProductVariant expectedProductVariant2 = createProductVariant(tpnc2, 3,
				"3.0", null);
		expectedProduct.addProductVariant(expectedProductVariant2);
		/*
		 * PS-238 Modified By Nibedita - to resolve errors after code
		 * modification - End
		 */
		inOrder.verify(repositoryImpl).insertObject(any(String.class),
				argThat(new CapturingMatcher<Product>() {
					@Override
					public boolean matches(Object o) {
						Product prod = (Product) o;
						return new RPMComparator().compare(prod,
								expectedProduct);
					}
				}));
	}

	@Test
	public void insertProductifCurrentItemNotEqualsPreviousItem()
			throws Exception {
		String tpnb = "1123";
		String tpnb2 = "1124";
		String tpnc = "284347092";
		String tpnc2 = "304347092";

		when(rpmPriceReader.getNext())
				.thenReturn(productInfoMap(tpnb, tpnc, 2, "2.4"))
				.thenReturn(productInfoMap(tpnb2, tpnc2, 2, "2.4"))
				.thenReturn(null);

		Product product = createProductWithVariant(tpnb, tpnc);
		Product product1 = createProductWithVariant(tpnb2, tpnc2);
		when(repositoryImpl.getGenericObject(
				PriceConstants.PRODUCT_KEY_PREFIX + tpnb, Product.class,
				true)).thenReturn(
				Optional.<Product> absent()).thenReturn(Optional.of(product));
		when(repositoryImpl.getGenericObject(
				PriceConstants.PRODUCT_KEY_PREFIX + tpnb2, Product.class,
				true)).thenReturn(
				Optional.<Product> absent()).thenReturn(Optional.of(product1));
		this.rpmWriter.write(null);

		InOrder inOrder = inOrder(repositoryImpl);
		final Product expectedProduct = createProductWithVariant(tpnb, tpnc);
		inOrder.verify(repositoryImpl).insertObject(any(String.class),
				argThat(new CapturingMatcher<Product>() {
					@Override
					public boolean matches(Object o) {
						Product prod = (Product) o;
						return new RPMComparator().compare(prod,
								expectedProduct);
					}
				}));
		final Product expectedProduct2 = createProductWithVariant(tpnb2, tpnc2);
		inOrder.verify(repositoryImpl).insertObject(any(String.class),
				argThat(new CapturingMatcher<Product>() {
					@Override
					public boolean matches(Object o) {
						Product prod = (Product) o;
						return new RPMComparator().compare(prod,
								expectedProduct2);
					}
				}));

	}

	private Map<String, String> productInfoMap(String itemNumber, String tpnc,
			int zoneId, String price) {
		Map<String, String> productInfoMap = new HashMap<>();
		productInfoMap.put(CSVHeaders.Price.ITEM, itemNumber);
		productInfoMap.put(CSVHeaders.Price.TPNC, tpnc);
		productInfoMap.put(CSVHeaders.Price.PRICE_ZONE_ID,
				String.valueOf(zoneId));
		productInfoMap.put(CSVHeaders.Price.PRICE_ZONE_PRICE, price);
		/* Added by Nitisha and Surya for PS-112 Junits corrections- Start */
		productInfoMap.put(CSVHeaders.Price.SELLING_UOM, sellingUOM);
		/* Added by Nitisha and Surya for PS-112 Junits corrections- End */

		return productInfoMap;
	}

	private Map<String, String> productPromoInfoMap(String itemNumber,
			String tpnc, int zoneId, String price) {
		Map<String, String> productInfoMap = new HashMap<>();
		productInfoMap.put(CSVHeaders.Price.ITEM, itemNumber);
		productInfoMap.put(CSVHeaders.Price.TPNC, tpnc);
		productInfoMap.put(CSVHeaders.Price.PROMO_ZONE_ID,
				String.valueOf(zoneId));
		productInfoMap.put(CSVHeaders.Price.PROMO_ZONE_PRICE, price);

		return productInfoMap;
	}

	@Test
	public void shouldInsertPromoZonePrice() throws Exception {
		// This will change when TPNC story is played
		final String tpnc = "284347092";
		int priceZoneId = 2;
		String price = "2.3";
		ProductVariant productVariant = createProductVariant(tpnc, priceZoneId,
				price, null);

		final String tpnb = "059428124";
		Product product = createProduct(tpnb, productVariant);

		int promoZoneId = 5;
		String promoPrice = "2.0";
		Map<String, String> productInfoMap = productPromoInfoMap(tpnb, tpnc,
				promoZoneId, promoPrice);

		when(repositoryImpl.getGenericObject(
				PriceConstants.PRODUCT_KEY_PREFIX + tpnb, Product.class,
				true))
				.thenReturn(Optional.of(product));
		when(rpmPromoPriceReader.getNext()).thenReturn(productInfoMap)
				.thenReturn(null);

		this.rpmWriter.write(null);

		ProductVariant expectedProductVariant = createProductVariant(tpnc,
				priceZoneId, price, null);
		expectedProductVariant
				.addSaleInfo(new SaleInfo(promoZoneId, promoPrice));

		final Product expectedProduct = createProduct(tpnb,
				expectedProductVariant);
		verify(repositoryImpl).insertObject(any(String.class),
				argThat(new CapturingMatcher<Product>() {
					@Override
					public boolean matches(Object o) {
						Product prod = (Product) o;
						return new RPMComparator().compare(prod,
								expectedProduct);
					}
				}));
	}

	@Test
	public void shouldInsertPromotionIntoProductPriceRepository()
			throws Exception {
		// This will change when TPNC story is played
		final String tpnc = "284347092";
		int zoneIds = 5;
		String price = "2.3";

		String tpnb = "070461113";
		String offerId = "A01";
		String offerName = "Test Offer Name";
		String startDate = "20130729";
		String endDate = "20130819";
		String description1 = "description1";
		String description2 = "description2";

		when(rpmPromotionReader.getNext()).thenReturn(
				promotionInfoMap(tpnb, tpnc, zoneIds, offerId, offerName,
						startDate, endDate)).thenReturn(null);
		when(rpmPromotionDescReader.getNext()).thenReturn(
				promotionDescInfoMap(tpnb, zoneIds, offerId, description1,
						description2)).thenReturn(null);

		ProductVariant productVariant = createProductVariant(tpnc, zoneIds,
				price, null);
		ProductVariant productVariant2 = createProductVariant(
				tpnc,
				zoneIds,
				price,
				createPromotion(offerId, zoneIds, offerName, startDate, endDate));
		when(repositoryImpl.getGenericObject(
				PriceConstants.PRODUCT_KEY_PREFIX + tpnb, Product.class,
				true)).thenReturn(
				Optional.of(createProduct(tpnb, productVariant)),
				Optional.of(createProduct(tpnb, productVariant2)));
		when(repositoryImpl.getMappedData(tpnb)).thenReturn(
				getTPNCForTPNB(tpnc));

		this.rpmWriter.write(null);

		ArgumentCaptor<Product> arguments = ArgumentCaptor
				.forClass(Product.class);
		verify(repositoryImpl, atLeastOnce()).insertObject(any(String.class),
				arguments.capture());

		Promotion expectedPromotion = createPromotion(offerId, zoneIds,
				offerName, startDate, endDate);
		ProductVariant expectedProductVariant = createProductVariant(tpnc,
				zoneIds, price, expectedPromotion);

		Product expectedProduct = createProduct(tpnb, expectedProductVariant);

		List<Product> actualProducts = arguments.getAllValues();
		assertThat(actualProducts.get(0)).isEqualTo(expectedProduct);

		expectedPromotion.setCFDescription1(description1);
		expectedPromotion.setCFDescription2(description2);
		assertThat(actualProducts.get(1)).isEqualTo(expectedProduct);
	}

	private Promotion createPromotion(String offerId, int zoneId,
			String offerName, String startDate, String endDate) {
		return new PromotionBuilder().offerId(offerId).zoneId(zoneId)
				.offerName(offerName).startDate(startDate).endDate(endDate)
				.description1(null).description2(null).createPromotion();
	}

	private Promotion createPromotion(String offerId, int zoneId,
			String offerName, String startDate, String endDate, String cfDesc1,
			String cfDesc2) {
		return new PromotionBuilder().offerId(offerId).zoneId(zoneId)
				.offerName(offerName).startDate(startDate).endDate(endDate)
				.description1(cfDesc1).description2(cfDesc2).createPromotion();
	}

	private Map<String, String> promotionDescInfoMap(String tpnb, int zoneId,
			String offerId, String description1, String description2) {
		Map<String, String> promotionInfoMap = new HashMap<>();
		promotionInfoMap.put(CSVHeaders.PromoDescExtract.ITEM, tpnb);
		promotionInfoMap.put(CSVHeaders.PromoDescExtract.ZONE_ID,
				String.valueOf(zoneId));
		promotionInfoMap.put(CSVHeaders.PromoDescExtract.OFFER_ID, offerId);
		promotionInfoMap.put(CSVHeaders.PromoDescExtract.DESC1, description1);
		promotionInfoMap.put(CSVHeaders.PromoDescExtract.DESC2, description2);
		return promotionInfoMap;

	}

	private Map<String, String> promotionInfoMap(String tpnb, String tpnc,
			int zoneId, String offerId, String offerName, String startDate,
			String endDate) {
		Map<String, String> promotionInfoMap = new HashMap<>();
		promotionInfoMap.put(CSVHeaders.PromoExtract.ITEM, tpnb);
		promotionInfoMap.put(CSVHeaders.PromoExtract.TPNC, tpnc);
		promotionInfoMap.put(CSVHeaders.PromoExtract.ZONE_ID,
				String.valueOf(zoneId));
		promotionInfoMap.put(CSVHeaders.PromoExtract.OFFER_ID, offerId);
		promotionInfoMap.put(CSVHeaders.PromoExtract.OFFER_NAME, offerName);
		promotionInfoMap.put(CSVHeaders.PromoExtract.START_DATE, startDate);
		promotionInfoMap.put(CSVHeaders.PromoExtract.END_DATE, endDate);
		return promotionInfoMap;
	}

	@Test
	@Ignore
	public void shouldInsertStorePriceZones() throws Exception {
		String firstStoreId = "2002";
		String secondStoreId = "2003";

		Store store1 = new Store(firstStoreId, Optional.of(1),
				Optional.<Integer> absent(), Optional.<Integer> absent(),
				"GBP", "GB");

		Store store2 = new Store(secondStoreId, Optional.of(1),
				Optional.<Integer> absent(), Optional.<Integer> absent(),
				"GBP", "GB");

		when(storeZoneReader.getNext())
				.thenReturn(getStoreInfoMap(firstStoreId, 1, 1, "GBP"))
				.thenReturn(getStoreInfoMap(secondStoreId, 2, 1, "EUR"))
				.thenReturn(null);

		when(repositoryImpl
				.getGenericObject(PriceConstants.STORE_KEY + firstStoreId,
						Store.class, true)).thenReturn(
				Optional.of(store1));
		when(repositoryImpl
				.getGenericObject(PriceConstants.STORE_KEY + secondStoreId,
						Store.class, true)).thenReturn(
				Optional.of(store2));

		Mockito.doAnswer(new Answer() {
			@Override
			public Object answer(InvocationOnMock invocation) throws Throwable {
				rpmWriter.getListener().onComplete(null);
				return null;
			}
		})
				.when(repositoryImpl)
				.insertObject(Matchers.anyString(), Matchers.any(Store.class));

		rpmWriter.write(null);

		assertThat("done").isEqualTo(rpmWriter.getRpmWriteStatus());

	}

	@Ignore
	@Test
	public void shouldInsertStorePriceAndPromoZones() throws Exception {
		String storeId = "2002";
		Store store = new Store(storeId, Optional.of(1), Optional.of(5),
				Optional.<Integer> absent(), "GBP", "GB");

		when(storeZoneReader.getNext())
				.thenReturn(getStoreInfoMap(storeId, 1, 1, "GBP"))
				.thenReturn(getStoreInfoMap(storeId, 5, 2, "GBP"))
				.thenReturn(null);

		// mockAsyncStoreInsert();
		when(repositoryImpl
				.getGenericObject(PriceConstants.STORE_KEY + storeId,
						Store.class, true))
				.thenReturn(Optional.of(store));

		Mockito.doAnswer(new Answer() {
			@Override
			public Object answer(InvocationOnMock invocation) throws Throwable {
				rpmWriter.getListener().onComplete(null);
				return null;
			}
		})
				.when(repositoryImpl)
				.insertObject(Matchers.anyString(), Matchers.any(Store.class));

		rpmWriter.write(null);

		assertThat("done").isEqualTo(rpmWriter.getRpmWriteStatus());

	}

	@Ignore
	@Test
	public void shouldInsertStorePricePromoAndClearanceZones()
			throws Exception {
		String storeId = "2002";
		Store store = new Store(storeId, Optional.of(1), Optional.of(5),
				Optional.of(20), "GBP", "GB");
		when(storeZoneReader.getNext())
				.thenReturn(getStoreInfoMap(storeId, 1, 1, "GBP"))
				.thenReturn(getStoreInfoMap(storeId, 5, 2, "GBP"))
				.thenReturn(getStoreInfoMap(storeId, 20, 3, "GBP"))
				.thenReturn(null);

		// mockAsyncStoreInsert();
		when(repositoryImpl
				.getGenericObject(PriceConstants.STORE_KEY + storeId,
						Store.class, true))
				.thenReturn(Optional.of(store));

		Mockito.doAnswer(new Answer() {
			@Override
			public Object answer(InvocationOnMock invocation) throws Throwable {
				rpmWriter.getListener().onComplete(null);
				return null;
			}
		})
				.when(repositoryImpl)
				.insertObject(Matchers.anyString(), Matchers.any(Store.class));

		rpmWriter.write(null);

		assertThat("done").isEqualTo(rpmWriter.getRpmWriteStatus());

	}

	private Map<String, String> getStoreInfoMap(String firstStoreId,
			int zoneId, int zoneType, String currency) {
		Map<String, String> storeInfoMap = new HashMap<>();
		storeInfoMap.put(CSVHeaders.StoreZone.STORE_ID, firstStoreId);
		storeInfoMap.put(CSVHeaders.StoreZone.ZONE_ID, String.valueOf(zoneId));
		storeInfoMap.put(CSVHeaders.StoreZone.ZONE_TYPE,
				String.valueOf(zoneType));
		storeInfoMap.put(CSVHeaders.StoreZone.CURRENCY_CODE, currency);

		return storeInfoMap;
	}

	private ProductVariant createProductVariant(String tpnc, int zoneId,
			String price, Promotion promotion) {
		ProductVariant productVariant = new ProductVariant(tpnc);
		SaleInfo saleInfo = new SaleInfo(zoneId, price);
		if (promotion != null) {
			promotionForProduct = promotion;
		}
		productVariant.addSaleInfo(saleInfo);
		/* Added by Nitisha and Surya for PS-112 Junits corrections- Start */
		productVariant.setSellingUOM(sellingUOM);
		/* Added by Nitisha and Surya for PS-112 Junits corrections- End */

		return productVariant;
	}

	private ProductVariant createProductVariantWithoutPromo(String tpnc,
			int zoneId, String price) {
		ProductVariant productVariant = new ProductVariant(tpnc);
		SaleInfo saleInfo = new SaleInfo(zoneId, price);
		productVariant.addSaleInfo(saleInfo);
		/* Added by Nitisha and Surya for PS-112 Junits corrections- Start */
		productVariant.setSellingUOM(sellingUOM);
		/* Added by Nitisha and Surya for PS-112 Junits corrections- End */

		return productVariant;
	}

	private Product createProductWithVariant(String tpnb, String tpnc) {
		ProductVariant productVariant = createProductVariant(tpnc, 2, "2.4",
				null);
		Product product = createProduct(tpnb, productVariant);

		return product;
	}

	private Product createProduct(String tpnb, ProductVariant productVariant) {
		Product product = new Product(tpnb);
		if (promotionForProduct != null) {
			product.addPromotion(promotionForProduct);
		}
		product.addProductVariant(productVariant);
		product.setLast_updated_date(Dockyard.getSysDate("yyyyMMdd"));
		return product;
	}

	private Product createProductWithPromo(String tpnb, Promotion promotion,
			ProductVariant productVariant) {
		Product product = new Product(tpnb);
		product.addPromotion(promotion);
		product.addProductVariant(productVariant);
		product.setLast_updated_date(Dockyard.getSysDate("yyyyMMdd"));
		return product;
	}

	private String getTPNCForTPNB(String tpnc) {

		return tpnc;
	}

	private Promotion aPromotionWithDescriptions() {
		Promotion promotion = new Promotion();
		promotion.setUniqueKey("uuid");
		promotion.setItemNumber("itemNumber");
		promotion.setZoneId(zoneId);
		promotion.setOfferId("promotionOfferId");
		promotion.setOfferName("promotionOfferName");
		promotion.setEffectiveDate("promotionStartDate");
		promotion.setEndDate("promotionEndDate");
		promotion.setCFDescription1("promotionCfDesc1");
		promotion.setCFDescription2("promotionCfDesc2");
		return promotion;
	}

	/**
	 * Added By Nibedita - PS-116 - Positive Scenario Given the Prom_extract(RPM
	 * - promotion) and prom_desc_extract(CMHOPOS) extract file , When the
	 * Prom_extract file doesn't have data for the item and CMHOPOS file has
	 * data and import rest call is triggered then the constructed product
	 * shouldn't contain CF descriptions in the promotion information block
	 */
	@Test
	public void shouldNotInsertCFDescWhenPromoExtractNotPresent()
			throws Exception {
		String tpnb = "09098000";
		Product product = new Product(tpnb);
		ProductVariant productVariant = createProductVariant("23232323", 1,
				"1", null);
		productVariant.addSaleInfo(new SaleInfo(5, "2"));
		product.addProductVariant(productVariant);
		product.setLast_updated_date(Dockyard.getSysDate("yyyymmdd"));
		String offerId = "A01";
		String description1 = "description1";
		String description2 = "description2";

		when(rpmPromotionDescReader.getNext()).thenReturn(
				promotionDescInfoMap(tpnb, zoneId, offerId, description1,
						description2)).thenReturn(null);

		when(repositoryImpl.getGenericObject(
				PriceConstants.PRODUCT_KEY_PREFIX + tpnb, Product.class,
				true))
				.thenReturn(Optional.of(product));
		when(repositoryImpl.getMappedData(tpnb)).thenReturn(
				getTPNCForTPNB("23232323"));
		this.rpmWriter.write(null);
		final Product expectedProduct = product;
		verify(repositoryImpl).insertObject(any(String.class),
				argThat(new CapturingMatcher<Product>() {
					@Override
					public boolean matches(Object o) {
						Product prod = (Product) o;
						return new RPMComparator().compare(prod,
								expectedProduct);
					}
				}));
	}

	/**
	 * Added By Nibedita - PS-116 - Negetive Scenario Given the Prom_zone,
	 * Prom_extract(RPM - promotion) and prom_desc_extract(CMHOPOS) extract ,
	 * When the prom_zone extract doesn't have data for a item and other 2
	 * extracts contains data and import rest call is triggered then the
	 * constructed product should contain promotion information with no price
	 * information
	 */
	@Test
	public void shouldInsertCFDescWhenPromoZoneNotPresent() throws Exception {
		final String tpnc = "284347092";
		int zoneIds = 5;
		String price = null;
		String tpnb = "070461113";
		String offerId = "A01";
		String offerId2 = "A02";
		String offerName = "Test Offer Name";
		String startDate = "20130729";
		String endDate = "20130819";
		String description1 = "description1";
		String description2 = "description2";

		when(rpmPromotionReader.getNext()).thenReturn(
				promotionInfoMap(tpnb, tpnc, zoneIds, offerId, offerName,
						startDate, endDate)).thenReturn(null);
		when(rpmPromotionDescReader.getNext()).thenReturn(
				promotionDescInfoMap(tpnb, zoneIds, offerId, description1,
						description2)).thenReturn(null);

		ProductVariant productVariant = createProductVariant(tpnc, zoneIds,
				price, null);
		ProductVariant productVariant2 = createProductVariant(
				tpnc,
				zoneIds,
				price,
				createPromotion(offerId, zoneIds, offerName, startDate, endDate));
		when(repositoryImpl.getGenericObject(
				PriceConstants.PRODUCT_KEY_PREFIX + tpnb, Product.class,
				true)).thenReturn(
				Optional.of(createProduct(tpnb, productVariant)),
				Optional.of(createProduct(tpnb, productVariant2)));
		when(repositoryImpl.getMappedData(tpnb)).thenReturn(
				getTPNCForTPNB(tpnc));

		this.rpmWriter.write(null);

		ArgumentCaptor<Product> arguments = ArgumentCaptor
				.forClass(Product.class);
		verify(repositoryImpl, atLeastOnce()).insertObject(any(String.class),
				arguments.capture());

		Promotion expectedPromotion = createPromotion(offerId, zoneIds,
				offerName, startDate, endDate);
		ProductVariant expectedProductVariant = createProductVariant(tpnc,
				zoneIds, price, expectedPromotion);

		Product expectedProduct = createProduct(tpnb, expectedProductVariant);

		List<Product> actualProducts = arguments.getAllValues();
		assertThat(actualProducts.get(0)).isEqualTo(expectedProduct);

		expectedPromotion.setCFDescription1(description1);
		expectedPromotion.setCFDescription2(description2);
		assertThat(actualProducts.get(1)).isEqualTo(expectedProduct);
	}

	/**
	 * Added By Nitisha - PS-112 - Apending SellingUOM info to Product variant
	 * Given the tpnb , tpnc ,Price_zone, selling reatil and selling UOM details
	 * , The product variant should carry the newly added SellingUOM details
	 * while building a PRODUCT
	 */

	@Test
	public void shouldAppendSellingUOMForPriceZoneExtarct() throws Exception {
		String tpnb = "123456789";
		String tpnc = "987654321";
		ProductVariant productVariant = new ProductVariant(tpnc);
		String price = "2.4";
		productVariant.addSaleInfo(new SaleInfo(zoneId, price));
		productVariant.setSellingUOM(sellingUOM);
		final Product product = createProduct(tpnb, productVariant);
		Map<String, String> productInfoMap = productInfoMap(tpnb, tpnc, zoneId,
				price);
		when(rpmPriceReader.getNext()).thenReturn(productInfoMap).thenReturn(
				null);
		when(repositoryImpl.getGenericObject(
				PriceConstants.PRODUCT_KEY_PREFIX + tpnb, Product.class,
				true)).thenReturn(
				Optional.<Product> absent());
		this.rpmWriter.write(null);
		verify(repositoryImpl).insertObject(any(String.class),
				argThat(new CapturingMatcher<Product>() {
					@Override
					public boolean matches(Object o) {
						Product prod = (Product) o;
						return new RPMComparator().compare(prod, product);
					}
				}));

	}

	/**
	 * Added By Abrar - PS-112 - Insert Null SellingUOM when Selling UOM data is
	 * not present in the Extract When the selling UOM is NULL(Data not
	 * available in Extract), a Null should be inserted. This test case will
	 * pass only if Mocked(Null SellingUOM) and Expected(Null sellingUOM)
	 * Products are same
	 */
	@Test
	public void shouldInsertNullwhenSellingUOMdataisMissinginExtarct()
			throws Exception {
		String TPNB = "123456789";
		String TPNC = "987654321";
		String selling_retail = "1.0";
		ProductVariant productVariant = new ProductVariant(TPNC);
		SaleInfo saleInfo = new SaleInfo(zoneId, selling_retail);
		productVariant.addSaleInfo(saleInfo);
		final Product expectedProduct = createProduct(TPNB, productVariant);
		Map<String, String> productInfoMap = new HashMap<>();
		productInfoMap.put(CSVHeaders.Price.ITEM, TPNB);
		productInfoMap.put(CSVHeaders.Price.TPNC, TPNC);
		productInfoMap.put(CSVHeaders.Price.PRICE_ZONE_ID,
				String.valueOf(zoneId));
		productInfoMap.put(CSVHeaders.Price.PRICE_ZONE_PRICE, selling_retail);
		when(rpmPriceReader.getNext()).thenReturn(productInfoMap).thenReturn(
				null);
		when(repositoryImpl.getGenericObject(
				PriceConstants.PRODUCT_KEY_PREFIX + TPNB, Product.class,
				true)).thenReturn(
				Optional.<Product> absent());

		this.rpmWriter.write(null);
		verify(repositoryImpl).insertObject(any(String.class),
				argThat(new CapturingMatcher<Product>() {
					@Override
					public boolean matches(Object o) {
						Product prod = (Product) o;
						return new RPMComparator().compare(prod,
								expectedProduct);
					}
				}));

	}

	@Test
	public void shouldInsertPromoInfoSinglelZoneSingleOffer()
			throws Exception {
		final String tpnc = "284347092";
		int zoneId1 = 5;
		int zoneId2 = 6;
		String price = "2.00";
		String tpnb = "070461113";
		String offerId = "A01";
		String offerName = "Test Offer Name";
		String startDate = "20130729";
		String endDate = "20130819";
		String description1 = "description1";
		String description2 = "description2";

		when(rpmPromotionReader.getNext()).thenReturn(
				promotionInfoMap(tpnb, tpnc, zoneId1, offerId, offerName,
						startDate, endDate)).thenReturn(null);
		when(rpmPromotionDescReader.getNext()).thenReturn(
				promotionDescInfoMap(tpnb, zoneId1, offerId, description1,
						description2)).thenReturn(null);

		ProductVariant productVariant = createProductVariant(tpnc, zoneId1,
				price, null);

		when(repositoryImpl.getGenericObject(
				PriceConstants.PRODUCT_KEY_PREFIX + tpnb, Product.class,
				true)).thenReturn(
				Optional.of(createProduct(tpnb, productVariant)));
		when(repositoryImpl.getMappedData(tpnb)).thenReturn(
				getTPNCForTPNB(tpnc));

		this.rpmWriter.write(null);

		ArgumentCaptor<Product> arguments = ArgumentCaptor
				.forClass(Product.class);
		verify(repositoryImpl, atLeastOnce()).insertObject(any(String.class),
				arguments.capture());

		Promotion expectedPromotion = createPromotion(offerId, zoneId1,
				offerName, startDate, endDate);

		expectedPromotion.setCFDescription1(description1);
		expectedPromotion.setCFDescription2(description2);
		ProductVariant expectedProductVariant = createProductVariant(tpnc,
				zoneId1, price, expectedPromotion);

		Product expectedProduct = createProduct(tpnb, expectedProductVariant);

		List<Product> actualProducts = arguments.getAllValues();
		assertThat(actualProducts.get(0)).isEqualTo(expectedProduct);

		assertThat(actualProducts.get(1)).isEqualTo(expectedProduct);
	}

	@Test
	public void shouldInsertPromoInfoForSingleOfferMultiZones()
			throws Exception {

		final String tpnc = "284347092";
		int priceZoneId = 1;
		String price = null;
		String tpnb = "070461113";
		String offerId = "A01";
		String offerName = "Test Offer Name";
		String startDate = "20130729";
		String endDate = "20130819";
		String description1 = "description1";
		String description2 = "description2";

		when(rpmPromotionReader.getNext())
				.thenReturn(
						promotionInfoMap(tpnb, tpnc, 5, offerId, offerName,
								startDate, endDate))
				.thenReturn(
						promotionInfoMap(tpnb, tpnc, 6, offerId, offerName,
								startDate, endDate)).thenReturn(null);
		when(rpmPromotionDescReader.getNext())
				.thenReturn(
						promotionDescInfoMap(tpnb, 5, offerId, description1,
								description2))
				.thenReturn(
						promotionDescInfoMap(tpnb, 6, offerId, description1,
								description2)).thenReturn(null);

		ProductVariant productVariant = createProductVariant(tpnc, priceZoneId,
				price, null);
		when(repositoryImpl.getGenericObject(
				PriceConstants.PRODUCT_KEY_PREFIX + tpnb, Product.class,
				true)).thenReturn(
				Optional.of(createProduct(tpnb, productVariant)));
		when(repositoryImpl.getMappedData(tpnb)).thenReturn(
				getTPNCForTPNB(tpnc));

		this.rpmWriter.write(null);

		ArgumentCaptor<Product> arguments = ArgumentCaptor
				.forClass(Product.class);
		verify(repositoryImpl, atLeastOnce()).insertObject(any(String.class),
				arguments.capture());

		Promotion promotionForZ5 = createPromotion(offerId, 5, offerName,
				startDate, endDate, description1, description2);
		Promotion promotionForZ6 = createPromotion(offerId, 6, offerName,
				startDate, endDate, description1, description2);

		ProductVariant expectedProductVariant = createProductVariant(tpnc,
				priceZoneId, price, null);

		Product expectedProduct = createProduct(tpnb, expectedProductVariant);
		expectedProduct.addPromotion(promotionForZ5);
		expectedProduct.addPromotion(promotionForZ6);

		List<Product> actualProducts = arguments.getAllValues();
		assertThat(actualProducts.get(0)).isEqualTo(expectedProduct);
	}

	@Test
	public void shouldReplacePipeWithSpaceWhenConfigurationTrue()
			throws Exception {

		String tpnb = "070461113";
		String offerId = "A29032446";
		String description1 = "Half Price Was 7.99 Now 3.99";
		String description2 = "TESCO |BRIGHT BEAR |FLEECE BLANKET $5 SP|";
		String offerName = "P 10 promotions";
		String startDate = "20101026";
		String endDate = "20351026";
		Product productToBeRetrived = new Product(tpnb);
		ProductVariant productVariant = createProductVariant("23232323", 1,
				"1", null);
		productToBeRetrived.addProductVariant(productVariant);

		Promotion promotion1 = createPromotion(offerId, zoneId, offerName,
				startDate, endDate);
		promotion1.setCFDescription1(description1);
		promotion1.setCFDescription2(description2);
		productToBeRetrived.addPromotion(promotion1);
		productToBeRetrived.setLast_updated_date(Dockyard
				.getSysDate("yyyymmdd"));

		when(rpmPromotionDescReader.getNext()).thenReturn(
				promotionDescInfoMap(tpnb, zoneId, offerId, description1,
						description2)).thenReturn(null);
		when(repositoryImpl.getGenericObject(
				PriceConstants.PRODUCT_KEY_PREFIX + tpnb, Product.class,
				true)).thenReturn(
				Optional.of(productToBeRetrived));
		when(repositoryImpl.getMappedData(tpnb)).thenReturn(
				getTPNCForTPNB("23232323"));
		this.rpmWriter.write(null);

		Promotion promotion = createPromotion(offerId, zoneId, offerName,
				startDate, endDate);
		promotion.setCFDescription1(description1);
		promotion.setCFDescription2(Dockyard.replaceOldValCharWithNewVal(
				description2, "|", " "));
		final Product expectedProduct = new Product(tpnb);
		expectedProduct.addPromotion(promotion);
		expectedProduct.addProductVariant(productVariant);
		expectedProduct.setLast_updated_date(Dockyard.getSysDate("yyyymmdd"));

		verify(repositoryImpl).insertObject(any(String.class),
				argThat(new CapturingMatcher<Product>() {
					@Override
					public boolean matches(Object o) {
						Product prod = (Product) o;
						return new RPMComparator().compare(prod,
								expectedProduct);
					}
				}));
	}

	@Test
	public void shouldNotReplacePipeWithSpaceWhenDescriptionNull()
			throws Exception {

		String tpnb = "070461113";
		String offerId = "A29032446";
		String description1 = "";
		String description2 = "";
		String offerName = "P 10 promotions";
		String startDate = "20101026";
		String endDate = "20351026";
		Product productToBeRetrived = new Product(tpnb);
		ProductVariant productVariant = createProductVariant("23232323", 1,
				"1", null);
		productToBeRetrived.addProductVariant(productVariant);
		Promotion promotion1 = createPromotion(offerId, zoneId, offerName,
				startDate, endDate);
		promotion1.setCFDescription1(description1);
		promotion1.setCFDescription2(description2);
		productToBeRetrived.addPromotion(promotion1);
		productToBeRetrived.setLast_updated_date(Dockyard
				.getSysDate("yyyymmdd"));

		when(rpmPromotionDescReader.getNext()).thenReturn(
				promotionDescInfoMap(tpnb, zoneId, offerId, description1,
						description2)).thenReturn(null);
		when(repositoryImpl.getGenericObject(
				PriceConstants.PRODUCT_KEY_PREFIX + tpnb, Product.class,
				true)).thenReturn(
				Optional.of(productToBeRetrived));
		when(repositoryImpl.getMappedData(tpnb)).thenReturn(
				getTPNCForTPNB("23232323"));
		this.rpmWriter.write(null);

		Promotion promotion = createPromotion(offerId, zoneId, offerName,
				startDate, endDate);
		promotion.setCFDescription1(description1);
		promotion.setCFDescription2(Dockyard.replaceOldValCharWithNewVal(
				description2, "|", " "));
		final Product expectedProduct = new Product(tpnb);
		expectedProduct.addPromotion(promotion);
		expectedProduct.addProductVariant(productVariant);
		expectedProduct.setLast_updated_date(Dockyard.getSysDate("yyyymmdd"));

		verify(repositoryImpl).insertObject(any(String.class),
				argThat(new CapturingMatcher<Product>() {
					@Override
					public boolean matches(Object o) {
						Product prod = (Product) o;
						return new RPMComparator().compare(prod,
								expectedProduct);
					}
				}));
	}

	@Test
	public void shouldReplacePipeWithSpaceWhenDescriptionIsWithPipe()
			throws Exception {

		String tpnb = "070461113";
		String offerId = "A29032446";
		String description1 = "Half|Price|Was 7.99|Now 3.99";
		String description2 = "TESCO BRIGHT BEAR FLEECE BLANKET 5 SP";
		String offerName = "P 10 promotions";
		String startDate = "20101026";
		String endDate = "20351026";
		Product productToBeRetrived = new Product(tpnb);
		ProductVariant productVariant = createProductVariant("23232323", 1,
				"1", null);
		productToBeRetrived.addProductVariant(productVariant);
		Promotion promotion1 = createPromotion(offerId, zoneId, offerName,
				startDate, endDate);
		promotion1.setCFDescription1(description1);
		promotion1.setCFDescription2(description2);
		productToBeRetrived.addPromotion(promotion1);
		productToBeRetrived.setLast_updated_date(Dockyard
				.getSysDate("yyyymmdd"));

		when(rpmPromotionDescReader.getNext()).thenReturn(
				promotionDescInfoMap(tpnb, zoneId, offerId, description1,
						description2)).thenReturn(null);
		when(repositoryImpl.getGenericObject(
				PriceConstants.PRODUCT_KEY_PREFIX + tpnb, Product.class,
				true)).thenReturn(
				Optional.of(productToBeRetrived));
		when(repositoryImpl.getMappedData(tpnb)).thenReturn(
				getTPNCForTPNB("23232323"));
		this.rpmWriter.write(null);

		Promotion promotion = createPromotion(offerId, zoneId, offerName,
				startDate, endDate);
		promotion.setCFDescription2(description2);
		promotion.setCFDescription1(Dockyard.replaceOldValCharWithNewVal(
				description1, "|", " "));
		final Product expectedProduct = new Product(tpnb);
		expectedProduct.addPromotion(promotion);
		expectedProduct.addProductVariant(productVariant);
		expectedProduct.setLast_updated_date(Dockyard.getSysDate("yyyymmdd"));

		verify(repositoryImpl).insertObject(any(String.class),
				argThat(new CapturingMatcher<Product>() {
					@Override
					public boolean matches(Object o) {
						Product prod = (Product) o;
						return new RPMComparator().compare(prod,
								expectedProduct);
					}
				}));
	}

	@Test
	public void shouldReplacePipeWithSpaceWhenDescriptionsIsWithPipe()
			throws Exception {

		String tpnb = "070461113";
		String offerId = "A29032446";
		String description1 = "Half|Price|Was 7.99|Now 3.99";
		String description2 = "TESCO|BRIGHT BEAR|FLEECE|BLANKET 5 SP|";
		String offerName = "P 10 promotions";
		String startDate = "20101026";
		String endDate = "20351026";
		Product productToBeRetrived = new Product(tpnb);
		ProductVariant productVariant = createProductVariant("23232323", 1,
				"1", null);
		productToBeRetrived.addProductVariant(productVariant);
		Promotion promotion1 = createPromotion(offerId, zoneId, offerName,
				startDate, endDate);
		promotion1.setCFDescription1(description1);
		promotion1.setCFDescription2(description2);
		productToBeRetrived.addPromotion(promotion1);
		productToBeRetrived.setLast_updated_date(Dockyard
				.getSysDate("yyyymmdd"));

		when(rpmPromotionDescReader.getNext()).thenReturn(
				promotionDescInfoMap(tpnb, zoneId, offerId, description1,
						description2)).thenReturn(null);
		when(repositoryImpl.getGenericObject(
				PriceConstants.PRODUCT_KEY_PREFIX + tpnb, Product.class,
				true)).thenReturn(
				Optional.of(productToBeRetrived));
		when(repositoryImpl.getMappedData(tpnb)).thenReturn(
				getTPNCForTPNB("23232323"));
		this.rpmWriter.write(null);

		Promotion promotion = createPromotion(offerId, zoneId, offerName,
				startDate, endDate);
		promotion.setCFDescription1(Dockyard.replaceOldValCharWithNewVal(
				description1, "|", " "));
		promotion.setCFDescription2(Dockyard.replaceOldValCharWithNewVal(
				description2, "|", " "));
		final Product expectedProduct = new Product(tpnb);
		expectedProduct.addPromotion(promotion);
		expectedProduct.addProductVariant(productVariant);
		expectedProduct.setLast_updated_date(Dockyard.getSysDate("yyyymmdd"));

		verify(repositoryImpl).insertObject(any(String.class),
				argThat(new CapturingMatcher<Product>() {
					@Override
					public boolean matches(Object o) {
						Product prod = (Product) o;
						return new RPMComparator().compare(prod,
								expectedProduct);
					}
				}));
	}

	@Test
	public void shouldNotReplacePipeWithSpaceWhenRpmDescriptionIsWithPipe()
			throws Exception {

		String tpnb = "070461113";
		String offerId = "A29032446";
		String description1 = "Half |Price |Was 7.99|Now 3.99";
		String description2 = "TESCO |BRIGHT BEAR |FLEECE |BLANKET 5.0 SP|";
		String offerName = "P |10|promotions|";
		String startDate = "20101026";
		String endDate = "20351026";
		Product productToBeRetrived = new Product(tpnb);
		ProductVariant productVariant = createProductVariant("23232323", 1,
				"1", null);
		productToBeRetrived.addProductVariant(productVariant);
		Promotion promotion1 = createPromotion(offerId, zoneId, offerName,
				startDate, endDate);
		promotion1.setCFDescription1(description1);
		promotion1.setCFDescription2(description2);
		productToBeRetrived.addPromotion(promotion1);
		productToBeRetrived.setLast_updated_date(Dockyard
				.getSysDate("yyyymmdd"));

		when(rpmPromotionDescReader.getNext()).thenReturn(
				promotionDescInfoMap(tpnb, zoneId, offerId, description1,
						description2)).thenReturn(null);
		when(repositoryImpl.getGenericObject(
				PriceConstants.PRODUCT_KEY_PREFIX + tpnb, Product.class,
				true)).thenReturn(
				Optional.of(productToBeRetrived));
		when(repositoryImpl.getMappedData(tpnb)).thenReturn(
				getTPNCForTPNB("23232323"));
		this.rpmWriter.write(null);

		Promotion promotion = createPromotion(offerId, zoneId, offerName,
				startDate, endDate);
		promotion.setCFDescription1(Dockyard.replaceOldValCharWithNewVal(
				description1, "|", " "));
		promotion.setCFDescription2(Dockyard.replaceOldValCharWithNewVal(
				description2, "|", " "));
		final Product expectedProduct = new Product(tpnb);
		expectedProduct.addPromotion(promotion);
		expectedProduct.addProductVariant(productVariant);
		expectedProduct.setLast_updated_date(Dockyard.getSysDate("yyyymmdd"));

		verify(repositoryImpl).insertObject(any(String.class),
				argThat(new CapturingMatcher<Product>() {
					@Override
					public boolean matches(Object o) {
						Product prod = (Product) o;
						return new RPMComparator().compare(prod,
								expectedProduct);
					}
				}));
	}

	@Test
	public void shouldWriteProductDetailsToRejectFileWhenDataIssueForPromoZoneFiles()
			throws Exception {
		String productId = "056376327";
		String tpnc = "252941940";
		int location = 5;
		String location_type = "Z";
		String price = "20.22";

		String filledProductIdWithError = "Tpnb: " + productId + " Tpnc: "
				+ tpnc + " Zone: " + location
				+ " from Promo Zone file doesn't contain Reg Price";
		Map<String, String> productInfoMap = productPromoInfoMap(productId,
				tpnc, location, price);

		when(repositoryImpl.getGenericObject(
				PriceConstants.PRODUCT_KEY_PREFIX + productId, Product.class,
				true)).thenReturn(
				Optional.<Product> absent());
		when(rpmPromoPriceReader.getNext()).thenReturn(productInfoMap)
				.thenReturn(null);

		Dockyard mockDock = mock(Dockyard.class);
		mockDock.setBufferedWriter(bufferedWriter);
		rpmWriter.setDockyard(mockDock);

		Mockito.doNothing().when(bufferedWriter).write(Matchers.anyString());
		Mockito.doNothing().when(bufferedWriter).flush();
		Mockito.doNothing().when(bufferedWriter).close();
		this.rpmWriter.write(null);

		// The product is not PRICE_ZONE.csv & present in PROM_ZONE.
		assertThat(repositoryImpl.getGenericObject(
				PriceConstants.PRODUCT_KEY_PREFIX + productId, Product.class,
				true).absent());

		// The product details should be there in Reject files
		// assertThat(getfailedProductInProviousRunIfExist(testConfiguration.getRejectFilePath()
		// + "/REJECT_FILE_promozone_" + Dockyard.getSysDate("yyyyMMddHHmmss") +
		// ".log")).isEqualTo(filledProductIdWithError);
	}

	@Test
	public void shouldWriteProductDetailsToRejectFileWhenDataIssueForPromotionFiles()
			throws Exception {
		String productId = "056376327";
		String tpnc = "252941940";
		int location = 5;
		String offerId = "A01";
		String offerName = "Test Offer Name";
		String startDate = "20130729";
		String endDate = "20130819";

		String filledProductIdWithError = "Tpnb: " + productId + " Tpnc: "
				+ tpnc + " Zone: " + location
				+ " from Promo Extract file doesn't contain Reg Price";
		Map<String, String> productInfoMap = promotionInfoMap(productId, tpnc,
				location, offerId, offerName, startDate, endDate);

		when(repositoryImpl.getGenericObject(
				PriceConstants.PRODUCT_KEY_PREFIX + productId, Product.class,
				true)).thenReturn(
				Optional.<Product> absent());
		when(rpmPromotionReader.getNext()).thenReturn(productInfoMap)
				.thenReturn(null);

		Dockyard mockDock = mock(Dockyard.class);
		mockDock.setBufferedWriter(bufferedWriter);
		rpmWriter.setDockyard(mockDock);

		Mockito.doNothing().when(bufferedWriter).write(Matchers.anyString());
		Mockito.doNothing().when(bufferedWriter).flush();
		Mockito.doNothing().when(bufferedWriter).close();
		this.rpmWriter.write(null);

		// The product is not PRICE_ZONE.csv & present in PROM_ZONE.
		assertThat(repositoryImpl.getGenericObject(
				PriceConstants.PRODUCT_KEY_PREFIX + productId, Product.class,
				true).absent());

		// The product details should be there in Reject files
		// assertThat(getfailedProductInProviousRunIfExist(testConfiguration.getRejectFilePath()
		// + "/REJECT_FILE_promoextract_" +
		// Dockyard.getSysDate("yyyyMMddHHmmss") +
		// ".log")).isEqualTo(filledProductIdWithError);
	}

	private String getfailedProductInProviousRunIfExist(String file)
			throws IOException {
		File promozoneFailedDatafile = new File(file);
		FileReader reader;
		String line;
		BufferedReader promozoneFailedFileReader = null;
		String failedProduct = "";
		try {
			reader = new FileReader(promozoneFailedDatafile);
			promozoneFailedFileReader = new BufferedReader(reader);
			while ((line = promozoneFailedFileReader.readLine()) != null) {
				failedProduct = line;
			}
			promozoneFailedFileReader.close();
		} catch (FileNotFoundException e) {
			return null;
		} catch (IOException e) {
			return null;
		}
		return failedProduct;
	}
}
