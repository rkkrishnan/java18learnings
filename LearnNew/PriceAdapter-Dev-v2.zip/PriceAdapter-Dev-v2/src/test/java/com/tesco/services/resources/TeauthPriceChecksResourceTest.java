package com.tesco.services.resources;

import com.tesco.couchbase.AsyncCouchbaseWrapper;
import com.tesco.couchbase.CouchbaseWrapper;
import com.tesco.couchbase.testutils.AsyncCouchbaseWrapperStub;
import com.tesco.couchbase.testutils.BucketTool;
import com.tesco.couchbase.testutils.CouchbaseTestManager;
import com.tesco.couchbase.testutils.CouchbaseWrapperStub;
import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.Import;
import com.tesco.services.adapters.core.ImportEanJob;
import com.tesco.services.adapters.core.PriceComparatorJob;
import io.dropwizard.testing.junit.ResourceTestRule;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.junit.After;
import org.junit.Before;
import org.junit.ClassRule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Semaphore;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

@RunWith(MockitoJUnitRunner.class)
public class TeauthPriceChecksResourceTest {

    private static Configuration testConfiguration = TestConfiguration.load();

    static PriceComparatorJob mockPriceComparatorJob = Mockito.mock(PriceComparatorJob.class);

    String runType = "uk";
    String fileName = "fileName";

    static ImportEanJob importEanJob = Mockito.mock(ImportEanJob.class);

    @Mock
    private CouchbaseTestManager couchbaseTestManager;

    @Mock
    private CouchbaseWrapper couchbaseWrapper;
    @Mock
    private AsyncCouchbaseWrapper asyncCouchbaseWrapper;

    @ClassRule
    public static final ResourceTestRule resources = ResourceTestRule.builder()
            .addResource(new TeauthPriceChecksResource(testConfiguration,
                    importEanJob, mockPriceComparatorJob)).build();

    @Before
    public void setUpResources() throws Exception {

        testConfiguration = TestConfiguration.load();

        if (testConfiguration.isDummyCouchbaseMode()){
            Map<String, ImmutablePair<Long, String>> fakeBase = new HashMap<>();
            couchbaseTestManager = new CouchbaseTestManager(new CouchbaseWrapperStub(fakeBase),
                    new AsyncCouchbaseWrapperStub(fakeBase),
                    mock(BucketTool.class));
        } else {
            couchbaseTestManager = new CouchbaseTestManager(testConfiguration.getCouchbaseBucket(),
                    testConfiguration.getCouchbaseUsername(),
                    testConfiguration.getCouchbasePassword(),
                    testConfiguration.getCouchbaseNodes(),
                    testConfiguration.getCouchbaseAdminUsername(),
                    testConfiguration.getCouchbaseAdminPassword());
        }

        couchbaseWrapper = couchbaseTestManager.getCouchbaseWrapper();
        asyncCouchbaseWrapper = couchbaseTestManager.getAsyncCouchbaseWrapper();
    }


    @Test
    public void shouldStartPriceChecks() throws IOException {
        Mockito.doNothing().when(mockPriceComparatorJob).
                run();

		WebTarget resource = resources.client()
                .target("/teauth/comparePrice/" + runType + "/" + fileName);
        Response response = resource.request()
                .accept(MediaType.APPLICATION_JSON)
                .post(Entity.entity("", MediaType.APPLICATION_JSON));
        String responseText = response.readEntity(String.class);

        assertThat(responseText)
                .isEqualTo("{\"message\":\"Price Comparison Job Started.\"}");
        assertThat(response.getStatus()).isEqualTo(200);
    }

    @Test
    public void shouldReturnInProgressWhenCalledChecksInProgress() throws IOException {
        fileName = "abc";
        TeauthPriceChecksResource.SEMAPHORE_MAP.put(fileName, new Semaphore(0));
        WebTarget resource = resources.client()
                .target("/teauth/checksInProgress/abc");
        Response response = resource.request().get();
        String responseText = response.readEntity(String.class);
        assertThat(responseText).isEqualTo("{\"import\":\"progress\"}");
    }

    @Test
    public void shouldReturnCompletedWhenCalledChecksInProgress() throws IOException {

        fileName = "xyz";
        TeauthPriceChecksResource.SEMAPHORE_MAP.put(fileName, new Semaphore(1));
        WebTarget resource = resources.client()
                .target("/teauth/checksInProgress/xyz");
        Response response = resource.request().get();
        String responseText = response.readEntity(String.class);
        assertThat(responseText).isEqualTo("{\"import\":\"completed\"}");
    }

    @Test
    public void shouldReturnErrorStringWhenCalledChecksInProgress() throws IOException {

        fileName = "123";
        TeauthPriceChecksResource.SEMAPHORE_MAP.put(fileName, new Semaphore(1));
        TeauthPriceChecksResource.setErrorString("123", "ERROR");
        WebTarget resource = resources.client()
                .target("/teauth/checksInProgress/123");
        Response response = resource.request().get();
        String responseText = response.readEntity(String.class);
        assertThat(responseText)
                .isEqualTo("{\"import\":\"aborted\",\n \"error\":\"ERROR\"}");
    }

    @Test
    public void shouldThrowInvalidIdentifierExceptionAnd400StatusCode() throws IOException {

        runType = "ind";
        fileName = "suv";
        TeauthPriceChecksResource.SEMAPHORE_MAP.put(fileName, new Semaphore(1));
        WebTarget resource = resources.client()
                .target("/teauth/comparePrice/" + runType + "/" + fileName);
        Response response = resource.request()
                .accept(MediaType.APPLICATION_JSON)
                .post(Entity.entity("", MediaType.APPLICATION_JSON));
        String responseText = response.readEntity(String.class);
        assertThat(responseText)
                .isEqualTo("{\"error\":\"Invalid Run Identifier\"}");
        assertThat(response.getStatus()).isEqualTo(400);
    }

    @Test
    public void shouldReturnPriceComparisonAlreadyRunning() throws IOException {

        runType = "uk";
        fileName = "abc";
        TeauthPriceChecksResource.SEMAPHORE_MAP.put(fileName, new Semaphore(0));
        WebTarget resource = resources.client()
                .target("/teauth/comparePrice/" + runType + "/" + fileName);
        Response response = resource.request()
                .accept(MediaType.APPLICATION_JSON)
                .post(Entity.entity("", MediaType.APPLICATION_JSON));
        String responseText = response.readEntity(String.class);
        assertThat(responseText).isEqualTo(
                "{\"message\":\"There is already an import in progress.\"}");
        assertThat(response.getStatus()).isEqualTo(409);

    }

    @Test
    public void eanImportAlreadyRunning() throws IOException {
        fileName = "abc";
        TeauthPriceChecksResource.SEMAPHORE_MAP.put(fileName, new Semaphore(0));
        Mockito.doNothing().when(importEanJob).run();
        WebTarget resource = resources.client()
                .target("/teauth/importEan/" + runType + "/" + fileName);
        Response response = resource.request()
                .accept(MediaType.APPLICATION_JSON)
                .post(Entity.entity("", MediaType.APPLICATION_JSON));
        String responseText = response.readEntity(String.class);
        assertThat(responseText).isEqualTo(
                "{\"message\":\"There is already an import in progress.\"}");
        assertThat(response.getStatus()).isEqualTo(409);
    }

    @Test
    public void eanImportThrowException() throws IOException {
        fileName = "abc";
        TeauthPriceChecksResource.SEMAPHORE_MAP.put(fileName, new Semaphore(0));
        Mockito.doNothing().when(importEanJob).run();
        WebTarget resource = resources.client()
                .target("/teauth/importEan/" + runType + "/" + fileName);
        Response response = resource.request()
                .accept(MediaType.APPLICATION_JSON)
                .post(Entity.entity("", MediaType.APPLICATION_JSON));
        String responseText = response.readEntity(String.class);
        assertThat(responseText).isEqualTo(
                "{\"message\":\"There is already an import in progress.\"}");
        assertThat(response.getStatus()).isEqualTo(409);
    }

    @Test
    public void eanImportResourceTest() throws IOException {
        runType = "uk";
        fileName = "KLL.KLAUTH.B3333";
        // Mockito.doNothing().when(mockImportEanJob).run();
        WebTarget resource = resources.client()
                .target("/teauth/importEan/" + runType + "/" + fileName);
        Response response = resource.request()
                .accept(MediaType.APPLICATION_JSON)
                .post(Entity.entity("", MediaType.APPLICATION_JSON));
        String responseText = response.readEntity(String.class);
        assertThat(responseText)
                .isEqualTo("{\"message\":\"Import Ean Job Started.\"}");
        assertThat(response.getStatus()).isEqualTo(200);
    }

    //@Ignore
    @Test
    public void eanImportResourceTestWithExceptions() throws IOException {
        runType = "uk";
        fileName = "KLL.KLAUTH.B";
        //will cover FileNotFoundException part of the code
        // Mockito.doNothing().when(mockImportEanJob).run();
        WebTarget resource = resources.client()
                .target("/teauth/importEan/" + runType + "/" + fileName);
        Response response = resource.request()
                .accept(MediaType.APPLICATION_JSON)
                .post(Entity.entity("", MediaType.APPLICATION_JSON));
        String responseText = response.readEntity(String.class);
        assertThat(responseText)
                .isEqualTo("{\"message\":\"Import Ean Job Started.\"}");
        assertThat(response.getStatus()).isEqualTo(200);
    }

    @After
    public void resetMocks() throws Exception {
        TeauthPriceChecksResource.getPriceChecksSemaphore(fileName).release();
    }
}
