package com.tesco.services.adapters.core.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.codahale.metrics.Counter;
import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.Timer;

/**
 * Created by vagrant on 6/10/2016.
 */
public class ZoneMetricsTest {

	ZoneMetrics zoneMetrics = null;
	MetricRegistry mmetricRegisty = null;
	Map metricsMap = null;

	@Before
	public void setUp() throws Exception {
		zoneMetrics = ZoneMetrics.getInstance();
		mmetricRegisty = ZoneMetrics.getMetricRegisty();
	}

	@After
	public void tearDown() throws Exception {

	}

	@Test
	public void logCreZoneProcessingStartTime() throws Exception {
		String name = MetricRegistry.name("com.tesco",
				"ZoneElapsedTimeAndRate", "time-to-process-cre-message");
		metricsMap = mmetricRegisty.getTimers();

		zoneMetrics.logCreZoneProcessingStartTime();
		zoneMetrics.logCreZoneProcessingEndTime();

		assertNotEquals(0, ((Timer) metricsMap.get(name)).getCount());
	}

	@Test
	public void logModZoneProcessingStartTime() throws Exception {
		String name = MetricRegistry.name("com.tesco",
				"ZoneElapsedTimeAndRate", "time-to-process-mod-message");
		metricsMap = mmetricRegisty.getTimers();

		zoneMetrics.logModZoneProcessingStartTime();
		zoneMetrics.logModZoneProcessingEndTime();
		assertNotEquals(0, ((Timer) metricsMap.get(name)).getCount());
	}

	@Test
	public void logDelZoneProcessingStartTime() throws Exception {
		String name = MetricRegistry.name("com.tesco",
				"ZoneElapsedTimeAndRate", "time-to-process-del-message");
		metricsMap = mmetricRegisty.getTimers();

		zoneMetrics.logDelZoneProcessingStartTime();
		zoneMetrics.logDelZoneProcessingEndTime();
		assertNotEquals(0, ((Timer) metricsMap.get(name)).getCount());
	}

	@Test
	public void logCreZoneGroupProcessingStartTime() throws Exception {
		String name = MetricRegistry.name("com.tesco",
				"ZoneElapsedTimeAndRate", "time-to-process-cre-group-message");
		metricsMap = mmetricRegisty.getTimers();

		zoneMetrics.logCreZoneGroupProcessingStartTime();
		zoneMetrics.logCreZoneGroupProcessingEndTime();
		assertNotEquals(0, ((Timer) metricsMap.get(name)).getCount());
	}

	@Test
	public void logModZoneGroupProcessingStartTime() throws Exception {
		String name = MetricRegistry.name("com.tesco",
				"ZoneElapsedTimeAndRate", "time-to-process-mod-group-message");
		metricsMap = mmetricRegisty.getTimers();

		zoneMetrics.logModZoneGroupProcessingStartTime();
		zoneMetrics.logModZoneGroupProcessingEndTime();

		assertNotEquals(0, ((Timer) metricsMap.get(name)).getCount());
	}

	@Test
	public void logDelZoneGroupProcessingStartTime() throws Exception {
		String name = MetricRegistry.name("com.tesco",
				"ZoneElapsedTimeAndRate", "time-to-process-del-group-message");
		metricsMap = mmetricRegisty.getTimers();

		zoneMetrics.logDelZoneGroupProcessingStartTime();
		zoneMetrics.logDelZoneGroupProcessingEndTime();

		assertNotEquals(0, ((Timer) metricsMap.get(name)).getCount());
	}

	@Test
	public void logCreZoneLocProcessingStartTime() throws Exception {
		String name = MetricRegistry.name("com.tesco",
				"ZoneElapsedTimeAndRate", "time-to-process-cre-loc-message");
		metricsMap = mmetricRegisty.getTimers();

		zoneMetrics.logCreZoneLocProcessingStartTime();
		zoneMetrics.logCreZoneLocProcessingEndTime();

		assertNotEquals(0, ((Timer) metricsMap.get(name)).getCount());
	}

	@Test
	public void logDelZoneLocProcessingStartTime() throws Exception {
		String name = MetricRegistry.name("com.tesco",
				"ZoneElapsedTimeAndRate", "time-to-process-del-loc-message");
		metricsMap = mmetricRegisty.getTimers();

		zoneMetrics.logDelZoneLocProcessingStartTime();
		zoneMetrics.logDelZoneLocProcessingEndTime();

		assertNotEquals(0, ((Timer) metricsMap.get(name)).getCount());
	}

	@Test
	public void logMessageProcessingStartTime() throws Exception {
		String name = MetricRegistry.name("com.tesco",
				"OverallZoneElapsedTimeAndRate", "time-to-process-message");
		metricsMap = mmetricRegisty.getTimers();
		zoneMetrics.logMessageProcessingStartTime();
		zoneMetrics.logMessageProcessingEndTime();
		assertNotEquals(0, ((Timer) metricsMap.get(name)).getCount());
	}

	@Ignore
	public void incrementErrorCount() throws Exception {
		String name = MetricRegistry.name("com.tesco",
				"ZoneMessageProcessingErrors", "total-error-count");
		zoneMetrics.incrementErrorCount();
		metricsMap = zoneMetrics.getMetricRegisty().getCounters();
		assertEquals(1, ((Counter) metricsMap.get(name)).getCount());
		zoneMetrics.resetMetrics();
		metricsMap = zoneMetrics.getMetricRegisty().getCounters();
		assertEquals(0, ((Counter) metricsMap.get(name)).getCount());
	}

}