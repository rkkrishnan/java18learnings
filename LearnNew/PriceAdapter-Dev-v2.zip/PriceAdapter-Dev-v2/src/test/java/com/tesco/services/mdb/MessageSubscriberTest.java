package com.tesco.services.mdb;

import static io.dropwizard.testing.FixtureHelpers.fixture;

import javax.jms.JMSException;
import javax.jms.TextMessage;
import javax.jms.TopicSession;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.tesco.services.Configuration;
import com.tesco.services.adapters.rpm.readers.MessageRouter;
import com.tesco.services.core.jms.JMSTopicTransactionHandler;
import com.tesco.services.exceptions.MessageRouterException;
import com.tesco.services.exceptions.PromoBusinessException;

@RunWith(MockitoJUnitRunner.class)
public class MessageSubscriberTest extends JMSTopicTransactionHandler {

	PromotionMessageSubscriber messageSubscriber;
	String xmlData;

	@Mock
	TextMessage message;

	@Mock
	Configuration configuration;

	@Mock
	MessageRouter promotionMessageRouter;

	@Before
	public void setUp() throws Exception {
		xmlData = fixture("com/tesco/services/core/fixtures/promotion/SimpleCreMessage.xml");

		Mockito.when(configuration.getRejectFilePath()).thenReturn("dummypath");
		TopicSession topicSession = Mockito.mock(TopicSession.class);

		messageSubscriber = new PromotionMessageSubscriber();
		messageSubscriber.setPromotionMessageRouter(promotionMessageRouter);
		messageSubscriber.setConfiguration(configuration);
		messageSubscriber.setTopicSession(topicSession);
		messageSubscriber.setRetryCount(1);

		Mockito.doNothing().when(promotionMessageRouter)
				.route(Mockito.anyString());
		Mockito.doNothing().when(topicSession).commit();
		Mockito.doNothing().when(topicSession).rollback();
	}

	@Test
	public void testOnMessage() throws JMSException, PromoBusinessException {
		Mockito.when(message.getText()).thenReturn(xmlData);
		messageSubscriber.onMessage(message);
	}

	@Test
	public void testOnMessageException() throws JMSException,
			MessageRouterException {
		Mockito.doThrow(new MessageRouterException("Mesage Router Exception"))
				.when(promotionMessageRouter).route(Mockito.anyString());
		messageSubscriber.onMessage(message);
		messageSubscriber.onMessage(message);
		Mockito.doThrow(new JMSException("JMS Exception")).when(message)
				.getText();
		messageSubscriber.onMessage(message);
	}
}
