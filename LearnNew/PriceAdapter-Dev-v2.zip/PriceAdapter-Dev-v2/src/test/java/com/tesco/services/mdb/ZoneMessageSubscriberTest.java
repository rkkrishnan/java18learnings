package com.tesco.services.mdb;

import static io.dropwizard.testing.FixtureHelpers.fixture;

import javax.jms.JMSException;
import javax.jms.TextMessage;
import javax.jms.TopicSession;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.tesco.services.Configuration;
import com.tesco.services.adapters.rpm.readers.MessageRouter;
import com.tesco.services.core.jms.JMSTopicTransactionHandler;
import com.tesco.services.exceptions.MessageRouterException;
import com.tesco.services.exceptions.PromoBusinessException;

@RunWith(MockitoJUnitRunner.class)
public class ZoneMessageSubscriberTest extends JMSTopicTransactionHandler {

	@Mock
	TextMessage message;

	@Mock
	Configuration configuration;

	@Mock
	MessageRouter zoneMessageRouter;

	String xmlData;

	ZoneMessageSubscriber zoneMessageSubscriber;

	@Before
	public void setUp() throws Exception {

		xmlData = fixture("com/tesco/services/core/fixtures/zone/ZoneCre.xml");

		Mockito.when(configuration.getRejectFilePath()).thenReturn("dummypath");

		TopicSession topicSession = Mockito.mock(TopicSession.class);

		zoneMessageSubscriber = new ZoneMessageSubscriber();
		zoneMessageSubscriber.setZoneMessageRouter(zoneMessageRouter);
		zoneMessageSubscriber.setConfiguration(configuration);
		zoneMessageSubscriber.setTopicSession(topicSession);
		zoneMessageSubscriber.setRetryCount(1);

		Mockito.doNothing().when(zoneMessageRouter).route(Mockito.anyString());
		Mockito.doNothing().when(topicSession).commit();
		Mockito.doNothing().when(topicSession).rollback();
	}

	@Test
	public void testOnMessage() throws JMSException, PromoBusinessException {
		Mockito.when(message.getText()).thenReturn(xmlData);
		zoneMessageSubscriber.onMessage(message);
	}

	@Test
	public void testOnMessageException()
			throws JMSException, MessageRouterException {
		Mockito.doThrow(new MessageRouterException("Message Router Exception"))
				.when(zoneMessageRouter).route(Mockito.anyString());
		zoneMessageSubscriber.onMessage(message);
		zoneMessageSubscriber.onMessage(message);
		Mockito.doThrow(new JMSException("JMS Exception")).when(message)
				.getText();
		zoneMessageSubscriber.onMessage(message);
	}

}
