package com.tesco.services.resources;

import com.tesco.services.core.jms.JMSAdapterStateManager;
import io.dropwizard.testing.junit.ResourceTestRule;
import org.junit.After;
import org.junit.Before;
import org.junit.ClassRule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

import static org.fest.assertions.api.Assertions.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class JMSResourceTest {

	private static JMSAdapterStateManager mockJmsAdapterStateManager = Mockito.mock(JMSAdapterStateManager.class);

	@ClassRule
	public static final ResourceTestRule resources = ResourceTestRule
			.builder().addResource(new JMSResource(mockJmsAdapterStateManager))
			.build();

	@Before
	public void setUpResources() throws Exception {
		Mockito.when(
				mockJmsAdapterStateManager.getJMSReceiverStatus("AMQCFG_1"))
				.thenReturn("running");
		Mockito.when(mockJmsAdapterStateManager.startJMSReceiver("AMQCFG_1"))
				.thenReturn("started");
		Mockito.when(mockJmsAdapterStateManager.stopJMSReceiver("AMQCFG_1"))
				.thenReturn("stopped");
	}

	@Test
	public void testGetStatus() {
		WebTarget resource = resources.client().target("/admin/jms/status/AMQCFG_1");
		Response response = resource.request().get();
		String responseText = response.readEntity(String.class);
		assertThat(responseText).isEqualTo("running");
		assertThat(response.getStatus()).isEqualTo(200);
	}

	@Test
	public void testGetStart() {
		WebTarget resource = resources.client().target("/admin/jms/start/AMQCFG_1");
		Response response = resource.request().get();
		String responseText = response.readEntity(String.class);
		assertThat(responseText).isEqualTo("started");
		assertThat(response.getStatus()).isEqualTo(200);
	}

	@Test
	public void testGetStop() {
		WebTarget resource = resources.client().target("/admin/jms/stop/AMQCFG_1");
		Response response = resource.request().get();
		String responseText = response.readEntity(String.class);
		assertThat(responseText).isEqualTo("stopped");
		assertThat(response.getStatus()).isEqualTo(200);
	}

	@Test
	public void testGetInvalid() {
		WebTarget resource = resources.client().target("/admin/jms/invalid/AMQCFG_1");
		Response response = resource.request().get();
		String responseText = response.readEntity(String.class);
		assertThat(responseText).isEqualTo("Invalid Command");
		assertThat(response.getStatus()).isEqualTo(200);
	}

	@After
	public void tearDown() throws Exception {
		Mockito.reset(mockJmsAdapterStateManager);
	}

}
