package com.tesco.services.adapters.promotion;

import static org.mockito.Mockito.mock;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.tesco.services.adapters.promotion.impl.MultiBuyPromotionHandler;
import com.tesco.services.adapters.promotion.impl.SimplePromotionHandler;
import com.tesco.services.adapters.promotion.impl.ThresholdPromotionHandler;
import com.tesco.services.repositories.RepositoryImpl;
import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tesco.couchbase.AsyncCouchbaseWrapper;
import com.tesco.couchbase.CouchbaseWrapper;
import com.tesco.couchbase.testutils.AsyncCouchbaseWrapperStub;
import com.tesco.couchbase.testutils.BucketTool;
import com.tesco.couchbase.testutils.CouchbaseTestManager;
import com.tesco.couchbase.testutils.CouchbaseWrapperStub;
import com.tesco.promotion.core.PrmPrcChgDesc;
import com.tesco.services.adapters.rpm.readers.impl.PromotionMessageRouter;
import com.tesco.services.adapters.rpm.writers.impl.PromotionWriter;
import com.tesco.services.core.promotion.PromotionEntity;
import com.tesco.services.exceptions.DataAccessException;
import com.tesco.services.exceptions.MessageRouterException;
import com.tesco.services.exceptions.ProductEncodeException;
import com.tesco.services.exceptions.PromoBusinessException;
import com.tesco.services.resources.TestConfiguration;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.PriceConstants;

@RunWith(MockitoJUnitRunner.class)
public class ThresholdPromotionHandlerTest {
	TestConfiguration testConfiguration = null;

	RepositoryImpl repositoryImpl;
	SimplePromotionHandler simplePromotionHandler;
	ThresholdPromotionHandler thresholdPromotionHandler;
	MultiBuyPromotionHandler multiBuyPromotionHandler;
	String promoMsgType;
	PrmPrcChgDesc promotions;
	PromotionMessageRouter promotionMessageRouter;
	PromotionWriter promotionWriter;
	@Mock
	public CouchbaseWrapper couchbaseWrapper;
	@Mock
	public AsyncCouchbaseWrapper asyncCouchbaseWrapper;

	ObjectMapper mapper;
	@Mock
	private CouchbaseTestManager couchbaseTestManager;

	@Mock
	private PromotionEventHandler promoEventHandler;

	@Before
	public void setUp() throws Exception {
		testConfiguration = TestConfiguration.load();
		mapper = new ObjectMapper();
		if (testConfiguration.isDummyCouchbaseMode()) {
			Map<String, ImmutablePair<Long, String>> fakeBase = new HashMap<>();
			couchbaseTestManager = new CouchbaseTestManager(
					new CouchbaseWrapperStub(fakeBase),
					new AsyncCouchbaseWrapperStub(fakeBase),
					mock(BucketTool.class));
		} else {
			couchbaseTestManager = new CouchbaseTestManager(
					testConfiguration.getCouchbaseBucket(),
					testConfiguration.getCouchbaseUsername(),
					testConfiguration.getCouchbasePassword(),
					testConfiguration.getCouchbaseNodes(),
					testConfiguration.getCouchbaseAdminUsername(),
					testConfiguration.getCouchbaseAdminPassword());
		}
		couchbaseWrapper = couchbaseTestManager.getCouchbaseWrapper();
		asyncCouchbaseWrapper = couchbaseTestManager.getAsyncCouchbaseWrapper();
		repositoryImpl = new RepositoryImpl(couchbaseWrapper,
				asyncCouchbaseWrapper, mapper);

		promotionWriter = new PromotionWriter(testConfiguration,
				repositoryImpl, mapper);

		thresholdPromotionHandler = new ThresholdPromotionHandler(
				repositoryImpl, promotionWriter, testConfiguration);

		promoEventHandler = Mockito.mock(PromotionEventHandler.class);

		promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promoEventHandler);
	}

	@After
	public void tearDown() throws Exception {

	}

	@Test
	public void testProcessCancelledThresholdPromotionWhereTheEndDateChanges()
			throws IOException, PromoBusinessException, ProductEncodeException,
			MessageRouterException, DataAccessException {

		String offerIdFromMsg = "29111596";
		String locType = "Z";
		String locRef = "5";
		SimpleDateFormat dateFormat = new SimpleDateFormat(
				PriceConstants.DATE_FORMAT_FOR_PROMOTION_END_DATE);
		Calendar cal = Calendar.getInstance();
		Date sysDate = cal.getTime();
		Date incrementDateByOne = DateUtils.addDays(sysDate,
				testConfiguration.getDaysToEndThresholdPromo());
		String formatDate = dateFormat.format(incrementDateByOne);
		String endDateThreshold = formatDate
				.concat(PriceConstants.APPEND_HOURS_MIN_SEC_TO_END_DATE);

		String masterKey = PriceConstants.PROMOTION_DOC_KEY_PREFIX
				+ offerIdFromMsg;
		String key = PriceConstants.PROMOTION_DOC_KEY_PREFIX + offerIdFromMsg
				+ "_" + locType + locRef;

		deleteDocs(masterKey, key, null, null);

		String credata = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.06.10 12:34:31.826|96</ribmessageID>\n"
				+ "<publishTime>2015-06-10 12:34:31.826 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;96044&lt;/promo_id&gt;&lt;promo_name&gt;threshold&lt;/promo_name&gt;&lt;promo_description&gt;threshold&lt;/promo_description&gt;&lt;promo_comp_id&gt;68628118&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;threshold&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;2237648&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;11&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1705&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;TILL DESC&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;29111596&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;1481&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;item&gt;053034697&lt;/item&gt;&lt;tsl_consumer_unit&gt;253535360&lt;/tsl_consumer_unit&gt;&lt;threshold_id&gt;15070&lt;/threshold_id&gt;&lt;threshold_name&gt;THRSH vouchr&lt;/threshold_name&gt;&lt;qualification_type&gt;0&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;V&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;002003824&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;threshold&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;2&lt;/threshold_value&gt;&lt;prm_chg_value&gt;0&lt;/prm_chg_value&gt;&lt;tsl_voucher_number&gt;11&lt;/tsl_voucher_number&gt;&lt;tsl_voucher_desc&gt;christmas spcl&lt;/tsl_voucher_desc&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		PromotionMessageRouter promotionMessageRouterAfterMod = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promoEventHandler);
		promotionMessageRouter.route(credata);

		PromotionEntity promotionEntity = (PromotionEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,
						PromotionEntity.class);

		String creDataNextZone = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGMOD</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.06.10 12:34:31.826|96</ribmessageID>\n"
				+ "<publishTime>2015-06-10 12:34:31.826 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;96044&lt;/promo_id&gt;&lt;promo_name&gt;threshold&lt;/promo_name&gt;&lt;promo_description&gt;threshold&lt;/promo_description&gt;&lt;promo_comp_id&gt;68628118&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;threshold&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;2237648&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;11&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1705&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.cancelled&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;TILL DESC&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;29111596&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;1481&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;item&gt;053034697&lt;/item&gt;&lt;tsl_consumer_unit&gt;253535360&lt;/tsl_consumer_unit&gt;&lt;threshold_id&gt;15070&lt;/threshold_id&gt;&lt;threshold_name&gt;THRSH vouchr&lt;/threshold_name&gt;&lt;qualification_type&gt;0&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;V&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;002003824&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;threshold&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;2&lt;/threshold_value&gt;&lt;prm_chg_value&gt;0&lt;/prm_chg_value&gt;&lt;tsl_voucher_number&gt;11&lt;/tsl_voucher_number&gt;&lt;tsl_voucher_desc&gt;christmas spcl&lt;/tsl_voucher_desc&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		promotionMessageRouterAfterMod = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promoEventHandler);

		promotionMessageRouterAfterMod.route(creDataNextZone);

		PromotionEntity promotionEntityMod = (PromotionEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,
						PromotionEntity.class);

		Assert.assertNotNull(promotionEntityMod);
		Assert.assertNotSame(promotionEntityMod.toString(),
				promotionEntity.toString());
		Assert.assertNotSame(
				promotionEntityMod.getPromoItemListEntities().get(0)
						.getPromoItems().get(0).getEndDate(),
				promotionEntity.getPromoItemListEntities().get(0)
						.getPromoItems().get(0).getEndDate());
		Assert.assertEquals(endDateThreshold, promotionEntityMod
				.getPromoItemListEntities().get(0).getPromoItems().get(0)
				.getEndDate().toString());

	}

	public void deleteDocs(String masterKey, String key,
			List<String> compDtlIds, List<String> hierkeys) {
		if (!Dockyard.isSpaceOrNull(masterKey)) {
			repositoryImpl.deleteProduct(masterKey);
		}
		repositoryImpl.deleteProduct(key);

		if (!Dockyard.isSpaceOrNull(compDtlIds)) {
			Iterator<String> it = compDtlIds.iterator();
			while (it.hasNext()) {
				String dtlId = it.next().toString();
				repositoryImpl.deleteProduct(dtlId);
			}
		}
		if (!Dockyard.isSpaceOrNull(compDtlIds)) {
			Iterator<String> it1 = hierkeys.iterator();
			while (it1.hasNext()) {
				String hierkey = it1.next().toString();
				repositoryImpl.deleteProduct(hierkey);
			}
		}

	}

}
