package com.tesco.services.resources;

import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.Import;
import com.tesco.services.adapters.core.ImportSubGroupDfltUomJob;
import com.tesco.services.utility.WebServiceCallBuilder;
import io.dropwizard.testing.junit.ResourceTestRule;
import org.junit.After;
import org.junit.Before;
import org.junit.ClassRule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.IOException;

import static org.fest.assertions.api.Assertions.assertThat;

/**
 * Created by qp65 on 5/21/2015.
 */

@RunWith(MockitoJUnitRunner.class)
public class ImportSubGroupDefaultResourceTest {

	@Mock
	private static Configuration testConfiguration;

	static Import importSubGroupJob = Mockito.mock(ImportSubGroupDfltUomJob.class);
	@Mock
	WebServiceCallBuilder serviceClient;

	@ClassRule
	public static final ResourceTestRule resources = ResourceTestRule.builder()
			.addResource(new ImportResource(testConfiguration, null, null, null,
					null, importSubGroupJob, null, null, null, null, null,
					null)).build();

	@Before
	public void setUpResources() throws Exception {

		Mockito.doNothing().when(importSubGroupJob).run();
		String runType = "onetime";

		Mockito.doReturn(runType).when(testConfiguration)
				.getRpmSubgroupDataDumpPath();
		ImportResource.getImportSemaphore().release();
	}

	@Test
	public void shouldStartSubGroupDfltImportScript() throws IOException {
		WebTarget resource = resources.client()
				.target("/admin/importSubGroupDefault/subgroup_dflt_uom/subgroup_dflt_uom_20160412.dat");
		Response response = resource.request()
				.accept(MediaType.APPLICATION_JSON)
				.post(Entity.entity("", MediaType.APPLICATION_JSON));
		String responseText = response.readEntity(String.class);

		assertThat(responseText).isEqualTo(
				"{\"message\":\"Import RPM Onetime SubGroup Default UOM Job Started.\"}");
		assertThat(response.getStatus()).isEqualTo(200);
	}

	@Test
	public void shouldSubGroupDfltImportScriptThrowException()
			throws IOException {
		WebTarget resource = resources.client()
				.target("/admin/importSubGroupDefault/invalidRunType/subgroup_dflt_uom_20160412.dat");
		Response response = resource.request()
				.accept(MediaType.APPLICATION_JSON)
				.post(Entity.entity("", MediaType.APPLICATION_JSON));

		assertThat(response.getStatus()).isEqualTo(400);
	}

//	@Test
//	public void testRefreshServiceURL() throws Exception {
//		String runType = "src/test/resources/com/tesco/services/adapters";
//		String[] serviceServerTypes = { "http://localhost:8082" };
//		String uriPath = "http://localhost:8082/v3/price/refreshSubGroupDefaultMapping";
//		URI uri = UriBuilder.fromUri(String.format(
//				uriPath)).build();
//		Response response = Response.ok().build();
//
//		Mockito.doReturn(runType).when(testConfiguration)
//				.getRpmSubgroupDataDumpPath();
//		Mockito.doReturn(serviceServerTypes).when(testConfiguration)
//				.getServiceServerUrlTypes();
//		Mockito.when(serviceClient.getResourceURIToRefreshService(uriPath))
//				.thenReturn(uri);
//		Mockito.when(serviceClient.callRemoteServer(uri))
//				.thenReturn(response);
//		rpmMapper = Mockito.mock(RPMSubGroupDfltUomMapper.class);
//		Mockito.doNothing().when(rpmMapper).write();
//
//		ImportResource.importSemaphoreForIdentifier
//				.put("subgroup_dflt_uom_20160412.dat", new Semaphore(1));
//		ImportSubGroupDfltUomJob importSubGroupDfltUomJob = new ImportSubGroupDfltUomJob(
//				testConfiguration, couchbaseWrapper, asyncCouchbaseWrapper,
//				"subgroup_dflt_uom", "subgroup_dflt_uom_20160412.dat", rpmMapper);
//		importSubGroupDfltUomJob.setServiceClient(serviceClient);
//		importSubGroupDfltUomJob.run();
//		assertThat(response.getStatus()).isEqualTo(200);
//	}

	@After
	public void resetMocks() throws Exception {
		Mockito.reset(importSubGroupJob);
		Mockito.reset(testConfiguration);
//		Mockito.reset(couchbaseWrapper);
//		Mockito.reset(asyncCouchbaseWrapper);
	}
}