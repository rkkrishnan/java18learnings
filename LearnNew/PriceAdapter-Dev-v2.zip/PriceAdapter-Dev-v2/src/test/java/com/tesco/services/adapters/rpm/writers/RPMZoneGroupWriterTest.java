package com.tesco.services.adapters.rpm.writers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tesco.couchbase.AsyncCouchbaseWrapper;
import com.tesco.couchbase.CouchbaseWrapper;
import com.tesco.couchbase.testutils.AsyncCouchbaseWrapperStub;
import com.tesco.couchbase.testutils.BucketTool;
import com.tesco.couchbase.testutils.CouchbaseTestManager;
import com.tesco.couchbase.testutils.CouchbaseWrapperStub;
import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.exceptions.ColumnNotFoundException;
import com.tesco.services.adapters.rpm.readers.PriceServiceCSVReader;
import com.tesco.services.adapters.rpm.writers.impl.RPMZoneGroupWriter;
import com.tesco.services.core.zone.ZoneGrpEntity;
import com.tesco.services.repositories.RepositoryImpl;
import com.tesco.services.resources.ImportResource;
import com.tesco.services.resources.TestConfiguration;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.PriceConstants;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Semaphore;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class RPMZoneGroupWriterTest {

	@Mock
	public RepositoryImpl repositoryImpl;
	@Mock
	public AsyncCouchbaseWrapper asyncCouchbaseWrapper;
	@Mock
	public CouchbaseWrapper couchbaseWrapper;
	@Mock
	private Configuration testConfiguration;
	@Mock
	private Configuration mockTestConfiguration;
	@Mock
	private ObjectMapper mapper;
	@Mock
	private PriceServiceCSVReader rpmZoneGroupReader;

	private RPMZoneGroupWriter rpmZoneGroupWriter;
	private String fileName = "zoneGroupFile";
	private String zoneGroupId = "2";
	private String zoneGroupName = "National Promotion Zone Group ..";
	private String zoneGroupType = "1";
	private String runIdentifier = "rpmzonegrouponetime";

	@Mock
	private CouchbaseTestManager couchbaseTestManager;

	@Before
	public void setUp() throws IOException, URISyntaxException,
			InterruptedException, ColumnNotFoundException {

		testConfiguration = TestConfiguration.load();

		if (testConfiguration.isDummyCouchbaseMode()) {
			Map<String, ImmutablePair<Long, String>> fakeBase = new HashMap<>();
			couchbaseTestManager = new CouchbaseTestManager(
					new CouchbaseWrapperStub(fakeBase),
					new AsyncCouchbaseWrapperStub(fakeBase),
					mock(BucketTool.class));
		} else {
			couchbaseTestManager = new CouchbaseTestManager(
					testConfiguration.getCouchbaseBucket(),
					testConfiguration.getCouchbaseUsername(),
					testConfiguration.getCouchbasePassword(),
					testConfiguration.getCouchbaseNodes(),
					testConfiguration.getCouchbaseAdminUsername(),
					testConfiguration.getCouchbaseAdminPassword());
		}

		couchbaseWrapper = couchbaseTestManager.getCouchbaseWrapper();

		repositoryImpl = new RepositoryImpl(couchbaseWrapper,
				asyncCouchbaseWrapper, new ObjectMapper());

		rpmZoneGroupWriter = new RPMZoneGroupWriter(testConfiguration,
				repositoryImpl, rpmZoneGroupReader);
		rpmZoneGroupWriter.setRunIdentifier(runIdentifier);

	}

	@Test
	public void readAndWriteRPMZoneDataForUK() throws Exception {

		Map<String, String> rpmZoneGroupMap = returnRPMZoneMap(zoneGroupId,
				zoneGroupName, zoneGroupType);

		when(rpmZoneGroupReader.getNext()).thenReturn(rpmZoneGroupMap)
				.thenReturn(null);
		ImportResource.importSemaphoreForIdentifier.put(fileName,
				new Semaphore(1));

		this.rpmZoneGroupWriter.write(fileName);

		ZoneGrpEntity expectedZoneGrpEntity = (ZoneGrpEntity) repositoryImpl
				.getGenericObject(
						PriceConstants.ZONE_GRP_KEY
								+ rpmZoneGroupMap
										.get(CSVHeaders.RPMZoneGroupHeaders.ZONE_GROUP_ID),
						ZoneGrpEntity.class);
		assertThat(expectedZoneGrpEntity).isNotNull();
		assertThat(expectedZoneGrpEntity.getZoneGroupName()).isEqualTo(
				rpmZoneGroupMap
						.get(CSVHeaders.RPMZoneGroupHeaders.ZONE_GROUP_NAME));

	}

	@Test
	public void testWriteRPMZoneDataForException() throws Exception {
		when(rpmZoneGroupReader.getNext()).thenThrow(
				new ArrayIndexOutOfBoundsException(
						"Array index out of bound Exception"));
		ImportResource.importSemaphoreForIdentifier.put(fileName,
				new Semaphore(1));
		this.rpmZoneGroupWriter.write(fileName);
		assertThat("Array index out of bound Exception").isEqualTo(
				ImportResource.getErrorString(fileName));
	}

	private Map<String, String> returnRPMZoneMap(String zoneGroupId,
			String zoneGroupName, String zoneGroupType) {
		Map<String, String> rpmZoneGroupMap = new HashMap<>();
		rpmZoneGroupMap.put(CSVHeaders.RPMZoneGroupHeaders.ZONE_GROUP_ID,
				zoneGroupId);
		rpmZoneGroupMap.put(CSVHeaders.RPMZoneGroupHeaders.ZONE_GROUP_NAME,
				zoneGroupName);
		rpmZoneGroupMap.put(CSVHeaders.RPMZoneGroupHeaders.ZONE_GROUP_TYPE,
				zoneGroupType);
		return rpmZoneGroupMap;
	}

	// Added for PRIS-2203 Data Loss Issue
	@Test
	public void readAndWriteRPMZoneDataForUK_testCBExceptionNullDocument()
			throws Exception {

		// Delete the document if existing
		String key = "ZONEGROUP_2";
		repositoryImpl.deleteProduct(key);

		// setting mock product repository
		RepositoryImpl repositoryImplMock = new RepositoryImpl(
				couchbaseWrapper, asyncCouchbaseWrapper, new ObjectMapper());
		repositoryImplMock = Mockito.mock(repositoryImplMock.getClass());
		RPMZoneGroupWriter rpmZoneGroupWriterMock = new RPMZoneGroupWriter(
				testConfiguration, repositoryImplMock, rpmZoneGroupReader);

		// Set the document in the couchbase
		Map<String, String> rpmZoneGroupMap = returnRPMZoneMap(zoneGroupId,
				zoneGroupName, zoneGroupType);
		ZoneGrpEntity zoneGroupEntity = setZoneGroupEntity(rpmZoneGroupMap);
		when(rpmZoneGroupReader.getNext()).thenReturn(rpmZoneGroupMap)
				.thenReturn(null);
		ImportResource.importSemaphoreForIdentifier.put(fileName,
				new Semaphore(1));

		Mockito.mock(zoneGroupEntity.getClass());
		rpmZoneGroupWriterMock.setZoneGrpEntity(zoneGroupEntity);
		Mockito.doThrow(new Exception()).when(repositoryImplMock)
				.insertObject(key, zoneGroupEntity);

		// Exception will be thrown here
		rpmZoneGroupWriterMock.write(fileName);

		// Check if the document exist in couchbase
		ZoneGrpEntity expectedZoneGrpEntity = (ZoneGrpEntity) repositoryImpl
				.getGenericObject(
						PriceConstants.ZONE_GRP_KEY
								+ rpmZoneGroupMap
										.get(CSVHeaders.RPMZoneGroupHeaders.ZONE_GROUP_ID),
						ZoneGrpEntity.class);

		// The document should not be present in the couchbase because of DB
		// error
		assertThat(expectedZoneGrpEntity).isNull();

	}

	// Added for PRIS-2203 Data Loss Issue
	public ZoneGrpEntity setZoneGroupEntity(
			Map<String, String> rpmZoneGroupInfoMap) {
		ZoneGrpEntity zoneGrpEntity = new ZoneGrpEntity();
		List<String> zoneIds = new ArrayList<>();
		String date = Dockyard.getSysDate(PriceConstants.ISO_8601_FORMAT);

		zoneGrpEntity.setZoneGroupId(rpmZoneGroupInfoMap
				.get(CSVHeaders.RPMZoneGroupHeaders.ZONE_GROUP_ID));
		zoneGrpEntity.setZoneGroupName(rpmZoneGroupInfoMap
				.get(CSVHeaders.RPMZoneGroupHeaders.ZONE_GROUP_NAME));
		zoneGrpEntity.setZoneGroupType(rpmZoneGroupInfoMap
				.get(CSVHeaders.RPMZoneGroupHeaders.ZONE_GROUP_TYPE));
		zoneGrpEntity.setCreatedDate(date);
		zoneGrpEntity.setCreatedById(PriceConstants.ONETIME_ZONE_CREATED_BY);
		zoneGrpEntity.setLastUpdateDate(date);
		zoneGrpEntity
				.setLastUpdatedById(PriceConstants.ONETIME_ZONE_CREATED_BY);
		zoneGrpEntity.setZoneIds(zoneIds);
		return zoneGrpEntity;
	}

	@Test
	public void testRPMZoneGroupForException() throws Exception {

		when(rpmZoneGroupReader.getNext()).thenThrow(
				new IOException("IO Exception")).thenReturn(null);

		ImportResource.importSemaphoreForIdentifier.put(fileName,
				new Semaphore(1));

		try {
			this.rpmZoneGroupWriter.write(fileName);
			fail("Suppose to fail");
		} catch (Exception e) {
			assertThat(e.getMessage().equals("IO Exception"));
		}
	}
}
