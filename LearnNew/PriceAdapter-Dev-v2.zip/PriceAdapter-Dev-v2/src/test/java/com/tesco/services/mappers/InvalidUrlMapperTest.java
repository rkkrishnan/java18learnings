package com.tesco.services.mappers;

import static org.fest.assertions.api.Assertions.assertThat;

import javax.ws.rs.NotFoundException;
import javax.ws.rs.core.Response;

import org.junit.Test;

public class InvalidUrlMapperTest {

    @Test
    public void shouldReturnCustom404Error(){
        InvalidUrlMapper invalidUrlMapper = new InvalidUrlMapper();
        NotFoundException exception = new NotFoundException("Not Found.");
        Response response = invalidUrlMapper.toResponse(exception);

        assertThat(response.getEntity().toString()).isEqualTo("{\"error\":\"Invalid request\"}");
        assertThat(response.getStatus() == 400);
    }
}
