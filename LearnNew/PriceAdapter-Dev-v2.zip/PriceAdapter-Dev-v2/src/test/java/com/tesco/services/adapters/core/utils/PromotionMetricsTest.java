package com.tesco.services.adapters.core.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.codahale.metrics.Counter;
import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.Timer;

/**
 * Created by vagrant on 6/13/2016.
 */
public class PromotionMetricsTest {

	PromotionMetrics promotionMetrics = null;
	MetricRegistry mmetricsRegistry = null;
	Map metricsMap = null;

	@Before
	public void setUp() throws Exception {
		promotionMetrics = PromotionMetrics.getInstance();
		mmetricsRegistry = PromotionMetrics.getMetricRegisty();
	}

	@After
	public void tearDown() throws Exception {

	}

	@Test
	public void logSimpleCreModPromoProcessingStartTime() throws Exception {
		String name = MetricRegistry.name("com.tesco",
				"SimplePromotionElapsedTimeAndRate",
				"time-to-process-cre-mod-message");
		metricsMap = mmetricsRegistry.getTimers();
		promotionMetrics.logSimpleCreModPromoProcessingStartTime();
		promotionMetrics.logSimpleCreModPromoProcessingEndTime();
		assertNotEquals(0, ((Timer) metricsMap.get(name)).getCount());
	}

	@Test
	public void logSimpleDelPromoProcessingStartTime() throws Exception {
		String name = MetricRegistry.name("com.tesco",
				"SimplePromotionElapsedTimeAndRate",
				"time-to-process-del-message");
		metricsMap = mmetricsRegistry.getTimers();
		promotionMetrics.logSimpleDelPromoProcessingStartTime();
		promotionMetrics.logSimpleDelPromoProcessingEndTime();
		assertNotEquals(0, ((Timer) metricsMap.get(name)).getCount());
	}

	@Test
	public void logThresholdCreModPromoProcessingStartTime() throws Exception {
		String name = MetricRegistry.name("com.tesco",
				"ThresholdPromotionElapsedTimeAndRate",
				"time-to-process-cre-mod-message");
		metricsMap = mmetricsRegistry.getTimers();
		promotionMetrics.logThresholdCreModPromoProcessingStartTime();
		promotionMetrics.logThresholdCreModPromoProcessingEndTime();
		assertNotEquals(0, ((Timer) metricsMap.get(name)).getCount());
	}

	@Test
	public void logThresholdDelPromoProcessingStartTime() throws Exception {
		String name = MetricRegistry.name("com.tesco",
				"ThresholdPromotionElapsedTimeAndRate",
				"time-to-process-del-message");
		metricsMap = mmetricsRegistry.getTimers();

		promotionMetrics.logThresholdDelPromoProcessingStartTime();
		promotionMetrics.logThresholdDelPromoProcessingEndTime();
		assertNotEquals(0, ((Timer) metricsMap.get(name)).getCount());
	}

	@Test
	public void logMultibuyCreModPromoProcessingStartTime() throws Exception {
		String name = MetricRegistry.name("com.tesco",
				"MultibuyPromotionElapsedTimeAndRate",
				"time-to-process-cre-mod-message");
		metricsMap = mmetricsRegistry.getTimers();

		promotionMetrics.logMultibuyCreModPromoProcessingStartTime();
		promotionMetrics.logMultibuyCreModPromoProcessingEndTime();
		assertNotEquals(0, ((Timer) metricsMap.get(name)).getCount());
	}

	@Test
	public void logMultibuyDelPromoProcessingStartTime() throws Exception {
		String name = MetricRegistry.name("com.tesco",
				"MultibuyPromotionElapsedTimeAndRate",
				"time-to-process-del-message");
		metricsMap = mmetricsRegistry.getTimers();

		promotionMetrics.logMultibuyDelPromoProcessingStartTime();
		promotionMetrics.logMultibuyDelPromoProcessingEndTime();
		assertNotEquals(0, ((Timer) metricsMap.get(name)).getCount());
	}

	@Test
	public void logMessageProcessingStartTime() throws Exception {
		String name = MetricRegistry
				.name("com.tesco", "OverallPromotionElapsedTimeAndRate",
						"time-to-process-message");
		metricsMap = mmetricsRegistry.getTimers();

		promotionMetrics.logMessageProcessingStartTime();
		promotionMetrics.logMessageProcessingEndTime();
		assertNotEquals(0, ((Timer) metricsMap.get(name)).getCount());
	}

	@Ignore
	public void incrementErrorCount() throws Exception {
		String name = MetricRegistry.name("com.tesco",
				"PromotionMessageProcessingErrors", "total-error-count");
		promotionMetrics.incrementErrorCount();
		metricsMap = promotionMetrics.getMetricRegisty().getCounters();
		assertEquals(1, ((Counter) metricsMap.get(name)).getCount());
		promotionMetrics.resetMetrics();
		metricsMap = promotionMetrics.getMetricRegisty().getCounters();
		assertEquals(0, ((Counter) metricsMap.get(name)).getCount());
	}

}