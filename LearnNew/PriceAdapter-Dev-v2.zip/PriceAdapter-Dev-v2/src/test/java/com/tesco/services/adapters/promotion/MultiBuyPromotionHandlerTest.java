package com.tesco.services.adapters.promotion;

import static io.dropwizard.testing.FixtureHelpers.fixture;
import static org.mockito.Mockito.mock;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;

import com.tesco.services.adapters.promotion.impl.MultiBuyPromotionHandler;
import com.tesco.services.adapters.promotion.impl.SimplePromotionHandler;
import com.tesco.services.adapters.promotion.impl.ThresholdPromotionHandler;
import com.tesco.services.adapters.rpm.writers.PromotionMessageWriter;
import com.tesco.services.repositories.RepositoryImpl;
import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.reflect.Whitebox;
import org.xml.sax.SAXException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tesco.couchbase.AsyncCouchbaseWrapper;
import com.tesco.couchbase.CouchbaseWrapper;
import com.tesco.couchbase.testutils.AsyncCouchbaseWrapperStub;
import com.tesco.couchbase.testutils.BucketTool;
import com.tesco.couchbase.testutils.CouchbaseTestManager;
import com.tesco.couchbase.testutils.CouchbaseWrapperStub;
import com.tesco.promotion.core.PrmPrcChgDesc;
import com.tesco.promotion.core.PrmPrcChgDtl;
import com.tesco.promotion.core.PrmPrcChgRef;
import com.tesco.services.adapters.rpm.readers.impl.PromotionMessageRouter;
import com.tesco.services.adapters.rpm.writers.impl.PromotionWriter;
import com.tesco.services.core.promotion.ProductOffersEntity;
import com.tesco.services.core.promotion.PromotionEntity;
import com.tesco.services.exceptions.DataAccessException;
import com.tesco.services.exceptions.PromoBusinessException;
import com.tesco.services.resources.TestConfiguration;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.ParseMessageUtil;
import com.tesco.services.utility.PriceConstants;

@RunWith(MockitoJUnitRunner.class)
public class MultiBuyPromotionHandlerTest {
	TestConfiguration testConfiguration = null;
	private CouchbaseTestManager couchbaseTestManager;
	public CouchbaseWrapper couchbaseWrapper;
	public AsyncCouchbaseWrapper asyncCouchbaseWrapper;
	RepositoryImpl repositoryImpl;
	ObjectMapper mapper;
	SimplePromotionHandler simplePromotionHandler;
	ThresholdPromotionHandler thresholdPromotionHandler;
	MultiBuyPromotionHandler multiBuyPromotionHandler;
	PromotionMessageRouter promotionMessageRouter;
	PromotionMessageWriter promotionWriter;
	String promoMsgType;
	PrmPrcChgDesc promotions;

	@Mock
	private PromotionEventHandler promoEventHandler;

	@Before
	public void setUp() throws Exception {
		testConfiguration = TestConfiguration.load();
		mapper = new ObjectMapper();
		if (testConfiguration.isDummyCouchbaseMode()) {
			Map<String, ImmutablePair<Long, String>> fakeBase = new HashMap<>();
			couchbaseTestManager = new CouchbaseTestManager(
					new CouchbaseWrapperStub(fakeBase),
					new AsyncCouchbaseWrapperStub(fakeBase),
					mock(BucketTool.class));
		} else {
			couchbaseTestManager = new CouchbaseTestManager(
					testConfiguration.getCouchbaseBucket(),
					testConfiguration.getCouchbaseUsername(),
					testConfiguration.getCouchbasePassword(),
					testConfiguration.getCouchbaseNodes(),
					testConfiguration.getCouchbaseAdminUsername(),
					testConfiguration.getCouchbaseAdminPassword());
		}
		couchbaseWrapper = couchbaseTestManager.getCouchbaseWrapper();
		asyncCouchbaseWrapper = couchbaseTestManager.getAsyncCouchbaseWrapper();
		repositoryImpl = new RepositoryImpl(couchbaseWrapper,
				asyncCouchbaseWrapper, mapper);
		promotionWriter = new PromotionWriter(testConfiguration,
				repositoryImpl, mapper);
		multiBuyPromotionHandler = new MultiBuyPromotionHandler(
				repositoryImpl, promotionWriter, testConfiguration);
		promoEventHandler = Mockito.mock(PromotionEventHandler.class);
		promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,promoEventHandler);

	}

	@After
	public void tearDown() throws Exception {

	}

	@Test
	public void processCreMessageLinkSaveTest() throws PromoBusinessException,
			IOException, XPathExpressionException, SAXException,
			ParserConfigurationException, JAXBException, DataAccessException {
		String xmlData = fixture("com/tesco/services/core/fixtures/promotion/MultibuyCreMessage.xml");
		ParseMessageUtil parseMessageUtil = ParseMessageUtil.getInstance();
		promoMsgType = parseMessageUtil.getNodeData(xmlData,
				PriceConstants.PROMO_MSG_TYPE_PATH);
		String promoDescData = parseMessageUtil.getNodeData(xmlData,
				PriceConstants.PROMO_MSG_DATA_PATH);
		promotions = (PrmPrcChgDesc) parseMessageUtil
				.getMappedObjectForXmlData(PrmPrcChgDesc.class, promoDescData);
		String promoMsgForZoneId = promotions.getTslZoneId().toString();
		String promoMsgLocType = promotions.getLocType();
		String promoMsgOfferType = null;
		String promoMsgState = null;
		String offerId = null;
		for (PrmPrcChgDtl prmPrcChgDtl : promotions.getPrmPrcChgDtl()) {
			offerId = prmPrcChgDtl.getTslPromoCompDisplayId();
			if (Dockyard.isSpaceOrNull(promoMsgOfferType)
					&& Dockyard.isSpaceOrNull(promoMsgState)) {
				promoMsgOfferType = promotionMessageRouter
						.getOfferTypeForDetail(prmPrcChgDtl);
				promoMsgState = promotionMessageRouter
						.getPromoStateForDetail(prmPrcChgDtl.getTslState());
			}
			if (PriceConstants.PROMO_MB_OFFER_TYPE.equals(promoMsgOfferType)) {

				multiBuyPromotionHandler.processCreMessage(null,
						promotions.getPrmPrcChgDtl(), promoMsgForZoneId,
						promoMsgState, promoMsgOfferType, promoMsgLocType);

			}
			break;
		}
		Assert.assertNotNull(repositoryImpl.getGenericObject(
				PriceConstants.PROMOTION_DOC_KEY_PREFIX + offerId + "_"
						+ promoMsgLocType + promoMsgForZoneId,
				PromotionEntity.class));
	}

	@Test
	public void processDelMessageTest() throws SAXException,
			ParserConfigurationException, XPathExpressionException,
			IOException, PromoBusinessException, JAXBException,
			DataAccessException {
		String xmlData = fixture("com/tesco/services/core/fixtures/promotion/MultibuyCreMessage.xml");
		ParseMessageUtil parseMessageUtil = ParseMessageUtil.getInstance();
		promoMsgType = parseMessageUtil.getNodeData(xmlData,
				PriceConstants.PROMO_MSG_TYPE_PATH);
		String promoDescData = parseMessageUtil.getNodeData(xmlData,
				PriceConstants.PROMO_MSG_DATA_PATH);
		promotions = (PrmPrcChgDesc) parseMessageUtil
				.getMappedObjectForXmlData(PrmPrcChgDesc.class, promoDescData);
		String promoMsgForZoneId = promotions.getTslZoneId().toString();
		String promoMsgLocType = promotions.getLocType();
		String promoMsgOfferType = null;
		String promoMsgState = null;
		String offerId = null;
		for (PrmPrcChgDtl prmPrcChgDtl : promotions.getPrmPrcChgDtl()) {
			offerId = prmPrcChgDtl.getTslPromoCompDisplayId();
			if (Dockyard.isSpaceOrNull(promoMsgOfferType)
					&& Dockyard.isSpaceOrNull(promoMsgState)) {
				promoMsgOfferType = promotionMessageRouter
						.getOfferTypeForDetail(prmPrcChgDtl);
				promoMsgState = promotionMessageRouter
						.getPromoStateForDetail(prmPrcChgDtl.getTslState());
			}
			if (PriceConstants.PROMO_MB_OFFER_TYPE.equals(promoMsgOfferType)) {

				multiBuyPromotionHandler.processCreMessage(null,
						promotions.getPrmPrcChgDtl(), promoMsgForZoneId,
						promoMsgState, promoMsgOfferType, promoMsgLocType);

			}
			break;
		}
		Assert.assertNotNull(repositoryImpl.getGenericObject(
				PriceConstants.PROMOTION_DOC_KEY_PREFIX + offerId + "_"
						+ promoMsgLocType + promoMsgForZoneId,
				PromotionEntity.class));
		String xmlDelData = fixture("com/tesco/services/core/fixtures/promotion/MultibuyDelMessage.xml");
		promoMsgType = parseMessageUtil.getNodeData(xmlDelData,
				PriceConstants.PROMO_MSG_TYPE_PATH);
		promoDescData = parseMessageUtil.getNodeData(xmlDelData,
				PriceConstants.PROMO_MSG_DATA_PATH);
		PrmPrcChgRef promotionsToBeDeleted = (PrmPrcChgRef) parseMessageUtil
				.getMappedObjectForXmlData(PrmPrcChgRef.class, promoDescData);
		multiBuyPromotionHandler.processDelMessage(
				promotionsToBeDeleted.getPrmPrcChgDtlRef(), promoMsgLocType
						+ promoMsgForZoneId);
		Assert.assertNull(repositoryImpl.getGenericObject(
				PriceConstants.PROMOTION_DOC_KEY_PREFIX + offerId + "_"
						+ promoMsgLocType + promoMsgForZoneId,
				PromotionEntity.class));

	}

	@Test
	public void processCreMessageMealDealTest() throws PromoBusinessException,
			IOException, XPathExpressionException, SAXException,
			ParserConfigurationException, JAXBException, DataAccessException {
		String xmlData = fixture("com/tesco/services/core/fixtures/promotion/MultiBuyCreMealDeal.xml");
		ParseMessageUtil parseMessageUtil = ParseMessageUtil.getInstance();
		promoMsgType = parseMessageUtil.getNodeData(xmlData,
				PriceConstants.PROMO_MSG_TYPE_PATH);
		String promoDescData = parseMessageUtil.getNodeData(xmlData,
				PriceConstants.PROMO_MSG_DATA_PATH);
		promotions = (PrmPrcChgDesc) parseMessageUtil
				.getMappedObjectForXmlData(PrmPrcChgDesc.class, promoDescData);
		String promoMsgForZoneId = promotions.getTslZoneId().toString();
		String promoMsgLocType = promotions.getLocType();
		String promoMsgOfferType = null;
		String promoMsgState = null;
		String offerId = null;
		for (PrmPrcChgDtl prmPrcChgDtl : promotions.getPrmPrcChgDtl()) {
			offerId = prmPrcChgDtl.getTslPromoCompDisplayId();
			if (Dockyard.isSpaceOrNull(promoMsgOfferType)
					&& Dockyard.isSpaceOrNull(promoMsgState)) {
				promoMsgOfferType = promotionMessageRouter
						.getOfferTypeForDetail(prmPrcChgDtl);
				promoMsgState = promotionMessageRouter
						.getPromoStateForDetail(prmPrcChgDtl.getTslState());
			}
			if (PriceConstants.PROMO_MB_OFFER_TYPE.equals(promoMsgOfferType)) {

				multiBuyPromotionHandler.processCreMessage(null,
						promotions.getPrmPrcChgDtl(), promoMsgForZoneId,
						promoMsgState, promoMsgOfferType, promoMsgLocType);

			}
			break;
		}
		Assert.assertNotNull(repositoryImpl.getGenericObject(
				PriceConstants.PROMOTION_DOC_KEY_PREFIX + offerId + "_"
						+ promoMsgLocType + promoMsgForZoneId,
				PromotionEntity.class));

	}

	@Test
	public void processModMessageForCancellationChoiceSaveTestToUpdateEndDate()
			throws PromoBusinessException, IOException,
			XPathExpressionException, SAXException,
			ParserConfigurationException, JAXBException, DataAccessException {
		String xmlData = fixture("com/tesco/services/core/fixtures/promotion/MultibuyModChoiceSave.xml");
		ParseMessageUtil parseMessageUtil = ParseMessageUtil.getInstance();
		promoMsgType = parseMessageUtil.getNodeData(xmlData,
				PriceConstants.PROMO_MSG_TYPE_PATH);
		String promoDescData = parseMessageUtil.getNodeData(xmlData,
				PriceConstants.PROMO_MSG_DATA_PATH);
		promotions = (PrmPrcChgDesc) parseMessageUtil
				.getMappedObjectForXmlData(PrmPrcChgDesc.class, promoDescData);
		String promoMsgForZoneId = promotions.getTslZoneId().toString();
		String promoMsgLocType = promotions.getLocType();
		String promoMsgOfferType = null;
		String promoMsgState = null;
		String offerId = null;
		SimpleDateFormat dateFormat = new SimpleDateFormat(
				PriceConstants.DATE_FORMAT_FOR_PROMOTION_END_DATE);
		Calendar cal = Calendar.getInstance();
		Date sysDate = cal.getTime();
		Date incrementDateByOne = DateUtils.addDays(sysDate,
				testConfiguration.getDaysToEndMultibuyPromo());
		String formatDate = dateFormat.format(incrementDateByOne);
		String endDateMultibuy = formatDate
				.concat(PriceConstants.APPEND_HOURS_MIN_SEC_TO_END_DATE);
		for (PrmPrcChgDtl prmPrcChgDtl : promotions.getPrmPrcChgDtl()) {
			offerId = prmPrcChgDtl.getTslPromoCompDisplayId();
			if (Dockyard.isSpaceOrNull(promoMsgOfferType)
					&& Dockyard.isSpaceOrNull(promoMsgState)) {
				promoMsgOfferType = promotionMessageRouter
						.getOfferTypeForDetail(prmPrcChgDtl);
				promoMsgState = promotionMessageRouter
						.getPromoStateForDetail(prmPrcChgDtl.getTslState());
			}
			if (PriceConstants.PROMO_MB_OFFER_TYPE.equals(promoMsgOfferType)) {

				multiBuyPromotionHandler.processCreMessage(null,
						promotions.getPrmPrcChgDtl(), promoMsgForZoneId,
						promoMsgState, promoMsgOfferType, promoMsgLocType);

			}
			break;
		}
		PromotionEntity promotionEntity = (PromotionEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerId + "_" + promoMsgLocType + promoMsgForZoneId,
						PromotionEntity.class);
		Assert.assertNotNull(repositoryImpl.getGenericObject(
				PriceConstants.PROMOTION_DOC_KEY_PREFIX + offerId + "_"
						+ promoMsgLocType + promoMsgForZoneId,
				PromotionEntity.class));
		Assert.assertEquals(endDateMultibuy, promotionEntity
				.getPromoItemListEntities().get(0).getPromoItems().get(0)
				.getEndDate().toString());

	}

	@Test
	public void getChangeTypeTest() throws Exception {
		int[] list = new int[] { 0, 1, 2, 5, 6, 8, 9 };
		String[] listo = new String[] { "P", "A", "F", "C", "V", "P", null };
		for (int i = 0; i < list.length; i++) {
			String outPut = Whitebox.<String> invokeMethod(
					multiBuyPromotionHandler, "getChangeType", list[i]);
			org.junit.Assert.assertEquals(listo[i], outPut);
		}
	}

	@Test
	public void processModMessageMealDealTest() throws PromoBusinessException,
			IOException, XPathExpressionException, SAXException,
			ParserConfigurationException, JAXBException, DataAccessException {
		String xmlData = fixture("com/tesco/services/core/fixtures/promotion/MultiBuyCreMealDeal.xml");

		ParseMessageUtil parseMessageUtil = ParseMessageUtil.getInstance();
		promoMsgType = parseMessageUtil.getNodeData(xmlData,
				PriceConstants.PROMO_MSG_TYPE_PATH);
		String promoDescData = parseMessageUtil.getNodeData(xmlData,
				PriceConstants.PROMO_MSG_DATA_PATH);
		promotions = (PrmPrcChgDesc) parseMessageUtil
				.getMappedObjectForXmlData(PrmPrcChgDesc.class, promoDescData);
		String promoMsgForZoneId = promotions.getTslZoneId().toString();
		String promoMsgLocType = promotions.getLocType();
		String promoMsgOfferType = null;
		String promoMsgState = null;
		String offerId = null;
		for (PrmPrcChgDtl prmPrcChgDtl : promotions.getPrmPrcChgDtl()) {
			offerId = prmPrcChgDtl.getTslPromoCompDisplayId();
			if (Dockyard.isSpaceOrNull(promoMsgOfferType)
					&& Dockyard.isSpaceOrNull(promoMsgState)) {
				promoMsgOfferType = promotionMessageRouter
						.getOfferTypeForDetail(prmPrcChgDtl);
				promoMsgState = promotionMessageRouter
						.getPromoStateForDetail(prmPrcChgDtl.getTslState());
			}
			if (PriceConstants.PROMO_MB_OFFER_TYPE.equals(promoMsgOfferType)) {

				multiBuyPromotionHandler.processCreMessage(null,
						promotions.getPrmPrcChgDtl(), promoMsgForZoneId,
						promoMsgState, promoMsgOfferType, promoMsgLocType);

			}
			break;
		}
		PromotionEntity inputPromotion = (PromotionEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerId + "_" + promoMsgLocType + promoMsgForZoneId,
						PromotionEntity.class);
		Assert.assertNotNull(inputPromotion);
		Assert.assertNotNull(repositoryImpl.getGenericObject(
				PriceConstants.PROD_OFFERS + "064833888" + "_"
						+ promoMsgLocType + promoMsgForZoneId,
				ProductOffersEntity.class));
		Assert.assertNotNull(repositoryImpl.getGenericObject(
				PriceConstants.PROD_OFFERS + "064833899" + "_"
						+ promoMsgLocType + promoMsgForZoneId,
				ProductOffersEntity.class));
		Assert.assertNotNull(repositoryImpl.getGenericObject(
				PriceConstants.PROD_OFFERS + "055923517" + "_"
						+ promoMsgLocType + promoMsgForZoneId,
				ProductOffersEntity.class));
		Assert.assertNotNull(repositoryImpl.getGenericObject(
				PriceConstants.PROD_OFFERS + "055923333" + "_"
						+ promoMsgLocType + promoMsgForZoneId,
				ProductOffersEntity.class));
		Assert.assertNotNull(repositoryImpl.getGenericObject(
				PriceConstants.PROD_OFFERS + "055923444" + "_"
						+ promoMsgLocType + promoMsgForZoneId,
				ProductOffersEntity.class));
		Assert.assertNotNull(repositoryImpl.getGenericObject(
				PriceConstants.PROD_OFFERS + "055923555" + "_"
						+ promoMsgLocType + promoMsgForZoneId,
				ProductOffersEntity.class));

		String xmlModData = fixture("com/tesco/services/core/fixtures/promotion/MultiBuyModDelItemsMealDeal.xml");
		List<String> deletedItems = new ArrayList<String>();
		deletedItems.add("064833888");
		deletedItems.add("055923333");
		deletedItems.add("055923444");
		promoMsgType = parseMessageUtil.getNodeData(xmlModData,
				PriceConstants.PROMO_MSG_TYPE_PATH);
		promoDescData = parseMessageUtil.getNodeData(xmlModData,
				PriceConstants.PROMO_MSG_DATA_PATH);
		promotions = (PrmPrcChgDesc) parseMessageUtil
				.getMappedObjectForXmlData(PrmPrcChgDesc.class, promoDescData);
		promoMsgForZoneId = promotions.getTslZoneId().toString();
		promoMsgLocType = promotions.getLocType();

		for (PrmPrcChgDtl prmPrcChgDtl : promotions.getPrmPrcChgDtl()) {
			offerId = prmPrcChgDtl.getTslPromoCompDisplayId();
			if (Dockyard.isSpaceOrNull(promoMsgOfferType)
					&& Dockyard.isSpaceOrNull(promoMsgState)) {
				promoMsgOfferType = promotionMessageRouter
						.getOfferTypeForDetail(prmPrcChgDtl);
				promoMsgState = promotionMessageRouter
						.getPromoStateForDetail(prmPrcChgDtl.getTslState());
			}
			if (PriceConstants.PROMO_MB_OFFER_TYPE.equals(promoMsgOfferType)) {

				multiBuyPromotionHandler.processCreMessage(inputPromotion,
						promotions.getPrmPrcChgDtl(), promoMsgForZoneId,
						promoMsgState, promoMsgOfferType, promoMsgLocType);

			}
			break;
		}
		Assert.assertNotNull(repositoryImpl.getGenericObject(
				PriceConstants.PROMOTION_DOC_KEY_PREFIX + offerId + "_"
						+ promoMsgLocType + promoMsgForZoneId,
				PromotionEntity.class));
		Assert.assertNotNull(repositoryImpl.getGenericObject(
				PriceConstants.PROD_OFFERS + "064833852" + "_"
						+ promoMsgLocType + promoMsgForZoneId,
				ProductOffersEntity.class));
		Assert.assertNull(repositoryImpl.getGenericObject(
				PriceConstants.PROD_OFFERS + "064833888" + "_"
						+ promoMsgLocType + promoMsgForZoneId,
				ProductOffersEntity.class));
		Assert.assertNotNull(repositoryImpl.getGenericObject(
				PriceConstants.PROD_OFFERS + "064833899" + "_"
						+ promoMsgLocType + promoMsgForZoneId,
				ProductOffersEntity.class));
		Assert.assertNotNull(repositoryImpl.getGenericObject(
				PriceConstants.PROD_OFFERS + "055923517" + "_"
						+ promoMsgLocType + promoMsgForZoneId,
				ProductOffersEntity.class));
		Assert.assertNull(repositoryImpl.getGenericObject(
				PriceConstants.PROD_OFFERS + "055923333" + "_"
						+ promoMsgLocType + promoMsgForZoneId,
				ProductOffersEntity.class));
		Assert.assertNull(repositoryImpl.getGenericObject(
				PriceConstants.PROD_OFFERS + "055923444" + "_"
						+ promoMsgLocType + promoMsgForZoneId,
				ProductOffersEntity.class));
		Assert.assertNotNull(repositoryImpl.getGenericObject(
				PriceConstants.PROD_OFFERS + "055923555" + "_"
						+ promoMsgLocType + promoMsgForZoneId,
				ProductOffersEntity.class));

	}

	@Test
	public void processCreMessageForProdOffersLinkSaveTest()
			throws PromoBusinessException, IOException,
			XPathExpressionException, SAXException,
			ParserConfigurationException, JAXBException, DataAccessException {

		String xmlData = fixture("com/tesco/services/core/fixtures/promotion/MultiBuyLinkSaveCre.xml");
		ParseMessageUtil parseMessageUtil = ParseMessageUtil.getInstance();
		promoMsgType = parseMessageUtil.getNodeData(xmlData,
				PriceConstants.PROMO_MSG_TYPE_PATH);
		String promoDescData = parseMessageUtil.getNodeData(xmlData,
				PriceConstants.PROMO_MSG_DATA_PATH);
		promotions = (PrmPrcChgDesc) parseMessageUtil
				.getMappedObjectForXmlData(PrmPrcChgDesc.class, promoDescData);
		String promoMsgForZoneId = promotions.getTslZoneId().toString();
		String promoMsgLocType = promotions.getLocType();
		String promoMsgOfferType = null;
		String promoMsgState = null;
		String offerId = null;
		for (PrmPrcChgDtl prmPrcChgDtl : promotions.getPrmPrcChgDtl()) {
			offerId = prmPrcChgDtl.getTslPromoCompDisplayId();
			if (Dockyard.isSpaceOrNull(promoMsgOfferType)
					&& Dockyard.isSpaceOrNull(promoMsgState)) {
				promoMsgOfferType = promotionMessageRouter
						.getOfferTypeForDetail(prmPrcChgDtl);
				promoMsgState = promotionMessageRouter
						.getPromoStateForDetail(prmPrcChgDtl.getTslState());
			}
			if (PriceConstants.PROMO_MB_OFFER_TYPE.equals(promoMsgOfferType)) {

				multiBuyPromotionHandler.processCreMessage(null,
						promotions.getPrmPrcChgDtl(), promoMsgForZoneId,
						promoMsgState, promoMsgOfferType, promoMsgLocType);

			}
			break;
		}
		Assert.assertNotNull(repositoryImpl.getGenericObject(
				PriceConstants.PROMOTION_DOC_KEY_PREFIX + offerId + "_"
						+ promoMsgLocType + promoMsgForZoneId,
				PromotionEntity.class));
		Assert.assertNotNull(repositoryImpl.getGenericObject(
				PriceConstants.PROD_OFFERS + "080000011" + "_"
						+ promoMsgLocType + promoMsgForZoneId,
				ProductOffersEntity.class));
		Assert.assertNotNull(repositoryImpl.getGenericObject(
				PriceConstants.PROD_OFFERS + "080000012" + "_"
						+ promoMsgLocType + promoMsgForZoneId,
				ProductOffersEntity.class));
		Assert.assertNotNull(repositoryImpl.getGenericObject(
				PriceConstants.PROD_OFFERS + "080000013" + "_"
						+ promoMsgLocType + promoMsgForZoneId,
				ProductOffersEntity.class));
		Assert.assertNotNull(repositoryImpl.getGenericObject(
				PriceConstants.PROD_OFFERS + "080000014" + "_"
						+ promoMsgLocType + promoMsgForZoneId,
				ProductOffersEntity.class));
		Assert.assertNotNull(repositoryImpl.getGenericObject(
				PriceConstants.PROD_OFFERS + "080000015" + "_"
						+ promoMsgLocType + promoMsgForZoneId,
				ProductOffersEntity.class));
		Assert.assertNotNull(repositoryImpl.getGenericObject(
				PriceConstants.PROD_OFFERS + "080000016" + "_"
						+ promoMsgLocType + promoMsgForZoneId,
				ProductOffersEntity.class));

	}
}
