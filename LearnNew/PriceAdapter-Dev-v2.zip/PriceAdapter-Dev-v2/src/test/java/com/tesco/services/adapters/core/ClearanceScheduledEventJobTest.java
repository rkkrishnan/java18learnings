package com.tesco.services.adapters.core;

import static com.tesco.services.utility.PriceConstants.CLEARANCE_END_EVENT_TYPE;
import static com.tesco.services.utility.PriceConstants.CLEARANCE_START_EVENT_TYPE;
import static io.dropwizard.testing.FixtureHelpers.fixture;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.Response;

import org.assertj.core.api.Assertions;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tesco.services.Configuration;
import com.tesco.services.CouchbaseViewConfig;
import com.tesco.services.event.core.EventTemplate;
import com.tesco.services.event.core.impl.MapEvent;
import com.tesco.services.event.exception.EventPublishException;
import com.tesco.services.repositories.views.WebViewTemplate;
import com.tesco.services.utility.PriceConstants;

@RunWith(MockitoJUnitRunner.class)
public class ClearanceScheduledEventJobTest {

	@Mock
	Configuration configuration;
	@Mock
	private EventTemplate eventTemplate;
	@Captor
	private ArgumentCaptor<MapEvent> argument;

	private ClearanceScheduledEventJob scheduledEventJob = null;
	private ObjectMapper mapper = new ObjectMapper();
	String couchbaseViewUrl = null;
	String couchbaseClearanceStartViewUrl = null;
	private ClearanceScheduledEventJob scheduledClearanceStartEventJob = null;

	@Mock
	private WebViewTemplate mockWebViewTemplate;

	@Before
	public void setUp() throws IOException {

		scheduledEventJob = new ClearanceScheduledEventJob(configuration,
				mapper, eventTemplate, mockWebViewTemplate,
				CLEARANCE_END_EVENT_TYPE);

		scheduledClearanceStartEventJob = new ClearanceScheduledEventJob(
				configuration, mapper, eventTemplate, mockWebViewTemplate,
				CLEARANCE_START_EVENT_TYPE);

		DateTime currentDate = new DateTime();
		DateTime currentDateWithOffset = currentDate.withZone(DateTimeZone
				.forID("+00:00"));
		String cleranceEndEffectiveEndDate = currentDateWithOffset
				.toLocalDate().toString();
		DateTime effectiveDate = currentDateWithOffset.plusDays(1);
		DateTime truncatedMonth = effectiveDate.dayOfMonth().roundFloorCopy();
		String effectiveEndDate = truncatedMonth.toLocalDate().toString();
	}

	@Test
	public void shouldTriggerClearanceEndMMStoreEventForEffectiveDateTomorrow()
			throws IOException, EventPublishException {
		String expectedCleranceData = "[{pricingLocation={locRef=1111, locType=S}, clearanceOfferId=MM},"
				+ " {pricingLocation={locRef=2222, locType=S}, clearanceOfferId=MM}]";
		String clearanceInputString = fixture("com/tesco/services/core/fixtures/clearance/SCHEDULED_CLEARANCEEND_STORE.json");

		CouchbaseViewConfig mockViewConfig = Mockito
				.mock(CouchbaseViewConfig.class);

		Map<String, String> viewQueryParams = new HashMap<String, String>();
		viewQueryParams.put("stale.state", "false");
		viewQueryParams.put("page.size", "2");
		viewQueryParams.put("timeout.interval", "60000");

		Map<String, String> viewQueryAddlParams = new HashMap<String, String>();
		viewQueryAddlParams.put("offset", "+00:00");
		viewQueryAddlParams.put("effectiveday", "0");
		viewQueryAddlParams.put("country", "UK");

		Mockito.when(mockViewConfig.getViewQueryParams()).thenReturn(
				viewQueryParams);

		Mockito.when(mockViewConfig.getViewAdditionalProperties()).thenReturn(
				viewQueryAddlParams);

		Map<String, CouchbaseViewConfig> clearanceViewConfig = new HashMap<String, CouchbaseViewConfig>();
		clearanceViewConfig.put("ClearanceEnd", mockViewConfig);

		Mockito.when(configuration.getCouchbaseViewConfig()).thenReturn(
				clearanceViewConfig);

		Response webViewResponse = Mockito.mock(Response.class);

		Mockito.when(webViewResponse.readEntity(String.class))
				.thenReturn(clearanceInputString).thenReturn(null);

		Mockito.when(
				mockWebViewTemplate.queryView(Matchers.anyMap(),
						Matchers.anyMap())).thenReturn(webViewResponse);

		scheduledEventJob.processScheduledEvents();
		Mockito.verify(eventTemplate, Mockito.times(1)).publishEvent(
				argument.capture());
		assertEquals("ClearanceEnd",
				(argument.getValue()).getHeaderData().get("EventType"));
		assertEquals("tpnb:050195631", (argument.getValue()).getPayloadData()
				.get("prodRef"));
		assertEquals(expectedCleranceData, (argument.getValue())
				.getPayloadData().get("clearances").toString());

	}

	@Test
	public void shouldTriggerClearanceEndRPMStoreEventForEffectiveDateTomorrow()
			throws IOException, EventPublishException {
		String expectedCleranceData = "[{pricingLocation={locRef=1111, locType=S}, clearanceOfferId=MM},"
				+ " {pricingLocation={locRef=2222, locType=S}, clearanceOfferId=MM}]";
		String clearanceInputString = fixture("com/tesco/services/core/fixtures/clearance/SCHEDULED_CLEARANCEEND_RPM.json");

		CouchbaseViewConfig mockViewConfig = Mockito
				.mock(CouchbaseViewConfig.class);

		Map<String, String> viewQueryParams = new HashMap<String, String>();
		viewQueryParams.put("stale.state", "false");
		viewQueryParams.put("page.size", "2");
		viewQueryParams.put("timeout.interval", "60000");

		Map<String, String> viewQueryAddlParams = new HashMap<String, String>();
		viewQueryAddlParams.put("offset", "+00:00");
		viewQueryAddlParams.put("effectiveday", "0");
		viewQueryAddlParams.put("country", "UK");

		Mockito.when(mockViewConfig.getViewQueryParams()).thenReturn(
				viewQueryParams);

		Mockito.when(mockViewConfig.getViewAdditionalProperties()).thenReturn(
				viewQueryAddlParams);

		Map<String, CouchbaseViewConfig> clearanceViewConfig = new HashMap<String, CouchbaseViewConfig>();
		clearanceViewConfig.put("ClearanceEnd", mockViewConfig);

		Mockito.when(configuration.getCouchbaseViewConfig()).thenReturn(
				clearanceViewConfig);

		Response webViewResponse = Mockito.mock(Response.class);

		Mockito.when(webViewResponse.readEntity(String.class))
				.thenReturn(clearanceInputString).thenReturn(null);

		Mockito.when(
				mockWebViewTemplate.queryView(Matchers.anyMap(),
						Matchers.anyMap())).thenReturn(webViewResponse);

		scheduledEventJob.processScheduledEvents();

		Mockito.verify(eventTemplate, Mockito.times(1)).publishEvent(
				argument.capture());
		assertEquals("ClearanceEnd",
				(argument.getValue()).getHeaderData().get("EventType"));
		assertEquals("tpnc:050195631", (argument.getValue()).getPayloadData()
				.get("prodRef"));
		assertEquals(expectedCleranceData, (argument.getValue())
				.getPayloadData().get("clearances").toString());
	}

	@Test
	public void shouldTriggerClearanceEndMMNationalEventForEffectiveDateTomorrow()
			throws IOException, EventPublishException {
		String expectedCleranceData1 = "[{pricingLocation={locRef=1111, locType=Z}, clearanceOfferId=MM}]";
		String expectedCleranceData2 = "[{pricingLocation={locRef=2222, locType=Z}, clearanceOfferId=MM}]";
		String clearanceInputString = fixture("com/tesco/services/core/fixtures/clearance/SCHEDULED_CLEARANCEEND_NATIONAL.json");

		CouchbaseViewConfig mockViewConfig = Mockito
				.mock(CouchbaseViewConfig.class);

		Map<String, String> viewQueryParams = new HashMap<String, String>();
		viewQueryParams.put("stale.state", "false");
		viewQueryParams.put("page.size", "2");
		viewQueryParams.put("timeout.interval", "60000");

		Map<String, String> viewQueryAddlParams = new HashMap<String, String>();
		viewQueryAddlParams.put("offset", "+00:00");
		viewQueryAddlParams.put("effectiveday", "0");
		viewQueryAddlParams.put("country", "UK");

		Mockito.when(mockViewConfig.getViewQueryParams()).thenReturn(
				viewQueryParams);

		Mockito.when(mockViewConfig.getViewAdditionalProperties()).thenReturn(
				viewQueryAddlParams);

		Map<String, CouchbaseViewConfig> clearanceViewConfig = new HashMap<String, CouchbaseViewConfig>();
		clearanceViewConfig.put("ClearanceEnd", mockViewConfig);

		Mockito.when(configuration.getCouchbaseViewConfig()).thenReturn(
				clearanceViewConfig);

		Response webViewResponse = Mockito.mock(Response.class);

		Mockito.when(webViewResponse.readEntity(String.class))
				.thenReturn(clearanceInputString).thenReturn(null);

		Mockito.when(
				mockWebViewTemplate.queryView(Matchers.anyMap(),
						Matchers.anyMap())).thenReturn(webViewResponse);

		scheduledEventJob.processScheduledEvents();
		Mockito.verify(eventTemplate, Mockito.times(2)).publishEvent(
				argument.capture());
		assertEquals("ClearanceEnd",
				(argument.getValue()).getHeaderData().get("EventType"));
		assertEquals("tpnb:050195631", (argument.getValue()).getPayloadData()
				.get("prodRef"));
		assertEquals("tpnb:050195631", (argument.getAllValues().get(1))
				.getPayloadData().get("prodRef"));
		assertEquals(expectedCleranceData1, (argument.getAllValues().get(0))
				.getPayloadData().get("clearances").toString());
		assertEquals(expectedCleranceData2, (argument.getAllValues().get(1))
				.getPayloadData().get("clearances").toString());
	}

	@Test
	public void shouldTriggerClearanceStartMMStoreEventForEffectiveDateTomorrow()
			throws IOException, EventPublishException {
		String clrStartString = fixture("com/tesco/services/core/fixtures/clearance/SCHEDULED_CLEARANCESTART_STORE.json");

		CouchbaseViewConfig mockViewConfig = Mockito
				.mock(CouchbaseViewConfig.class);

		Map<String, String> viewQueryParams = new HashMap<String, String>();
		viewQueryParams.put("stale.state", "false");
		viewQueryParams.put("page.size", "2");
		viewQueryParams.put("timeout.interval", "60000");

		Map<String, String> viewQueryAddlParams = new HashMap<String, String>();
		viewQueryAddlParams.put("offset", "+00:00");
		viewQueryAddlParams.put("effectiveday", "0");
		viewQueryAddlParams.put("country", "UK");

		Mockito.when(mockViewConfig.getViewQueryParams()).thenReturn(
				viewQueryParams);

		Mockito.when(mockViewConfig.getViewAdditionalProperties()).thenReturn(
				viewQueryAddlParams);

		Map<String, CouchbaseViewConfig> clearanceViewConfig = new HashMap<String, CouchbaseViewConfig>();
		clearanceViewConfig.put("ClearanceStart", mockViewConfig);

		Mockito.when(configuration.getCouchbaseViewConfig()).thenReturn(
				clearanceViewConfig);

		Response webViewResponse = Mockito.mock(Response.class);

		Mockito.when(webViewResponse.readEntity(String.class))
				.thenReturn(clrStartString).thenReturn(null);

		Mockito.when(
				mockWebViewTemplate.queryView(Matchers.anyMap(),
						Matchers.anyMap())).thenReturn(webViewResponse);

		scheduledClearanceStartEventJob.processScheduledEvents();
		Mockito.verify(eventTemplate, Mockito.times(1)).publishEvent(
				argument.capture());
		assertSame(PriceConstants.CLEARANCE_START_EVENT_TYPE, argument
				.getValue().getEventType());
		Map<String, String> headerMap = argument.getValue().getHeaderData();
		assertEquals("GB", headerMap.get(PriceConstants.COUNTRY));
		assertEquals(PriceConstants.CLEARANCE_START_EVENT_TYPE,
				headerMap.get(PriceConstants.EVENT_TYPE));
		assertEquals("1", headerMap.get(PriceConstants.LEAD_TIME_DAYS));
		assertEquals("tpnb:075777636", (argument.getValue()).getPayloadData()
				.get(PriceConstants.PRODUCT_REF));
		List<Map<String, Object>> locations = new ArrayList<Map<String, Object>>();
		Map<String, Object> clearanceMap = new HashMap<>();
		Map<String, Object> locationMap = new HashMap<String, Object>();
		locationMap.put(PriceConstants.LOC_TYPE, "S");
		locationMap.put(PriceConstants.LOC_REF, "6869");
		clearanceMap.put(PriceConstants.PRICING_LOC, locationMap);
		clearanceMap.put(PriceConstants.CLEARANCE_OFFER_ID, "MM");
		locations.add(clearanceMap);

		Map<String, Object> clearanceSecondStoreMap = new HashMap<>();
		Map<String, Object> locationStoreMap = new HashMap<String, Object>();
		locationStoreMap.put(PriceConstants.LOC_TYPE, "S");
		locationStoreMap.put(PriceConstants.LOC_REF, "2002");
		clearanceSecondStoreMap.put(PriceConstants.PRICING_LOC,
				locationStoreMap);
		clearanceSecondStoreMap.put(PriceConstants.CLEARANCE_OFFER_ID, "MM");
		locations.add(clearanceSecondStoreMap);
		Assertions.assertThat(locations).containsAll(
				(Iterable<? extends Map<String, Object>>) (argument.getValue())
						.getPayloadData().get(PriceConstants.CLEARANCES));
	}

	@Test
	public void shouldTriggerClearanceStartRPMStoreEventForEffectiveDateTomorrow()
			throws IOException, EventPublishException {
		String clrStartString = fixture("com/tesco/services/core/fixtures/clearance/SCHEDULED_CLEARANCESTART_RPM.json");

		CouchbaseViewConfig mockViewConfig = Mockito
				.mock(CouchbaseViewConfig.class);

		Map<String, String> viewQueryParams = new HashMap<String, String>();
		viewQueryParams.put("stale.state", "false");
		viewQueryParams.put("page.size", "2");
		viewQueryParams.put("timeout.interval", "60000");

		Map<String, String> viewQueryAddlParams = new HashMap<String, String>();
		viewQueryAddlParams.put("offset", "+00:00");
		viewQueryAddlParams.put("effectiveday", "0");
		viewQueryAddlParams.put("country", "UK");

		Mockito.when(mockViewConfig.getViewQueryParams()).thenReturn(
				viewQueryParams);

		Mockito.when(mockViewConfig.getViewAdditionalProperties()).thenReturn(
				viewQueryAddlParams);

		Map<String, CouchbaseViewConfig> clearanceViewConfig = new HashMap<String, CouchbaseViewConfig>();
		clearanceViewConfig.put("ClearanceStart", mockViewConfig);

		Mockito.when(configuration.getCouchbaseViewConfig()).thenReturn(
				clearanceViewConfig);

		Response webViewResponse = Mockito.mock(Response.class);

		Mockito.when(webViewResponse.readEntity(String.class))
				.thenReturn(clrStartString).thenReturn(null);

		Mockito.when(
				mockWebViewTemplate.queryView(Matchers.anyMap(),
						Matchers.anyMap())).thenReturn(webViewResponse);

		scheduledClearanceStartEventJob.processScheduledEvents();
		Mockito.verify(eventTemplate, Mockito.times(1)).publishEvent(
				argument.capture());
		assertSame(PriceConstants.CLEARANCE_START_EVENT_TYPE, argument
				.getValue().getEventType());
		Map<String, String> headerMap = argument.getValue().getHeaderData();
		assertEquals("GB", headerMap.get(PriceConstants.COUNTRY));
		assertEquals(PriceConstants.CLEARANCE_START_EVENT_TYPE,
				headerMap.get(PriceConstants.EVENT_TYPE));
		assertEquals("1", headerMap.get(PriceConstants.LEAD_TIME_DAYS));
		assertEquals("tpnc:270693174", (argument.getValue()).getPayloadData()
				.get(PriceConstants.PRODUCT_REF));
		List<Map<String, Object>> locations = new ArrayList<Map<String, Object>>();
		Map<String, Object> clearanceMap = new HashMap<>();
		Map<String, Object> locationMap = new HashMap<String, Object>();
		locationMap.put(PriceConstants.LOC_TYPE, "S");
		locationMap.put(PriceConstants.LOC_REF, "9999");
		clearanceMap.put(PriceConstants.PRICING_LOC, locationMap);
		clearanceMap.put(PriceConstants.CLEARANCE_OFFER_ID, "acayg-2");
		locations.add(clearanceMap);

		Map<String, Object> clearanceSecondStoreMap = new HashMap<>();
		Map<String, Object> locationStoreMap = new HashMap<String, Object>();
		locationStoreMap.put(PriceConstants.LOC_TYPE, "S");
		locationStoreMap.put(PriceConstants.LOC_REF, "9998");
		clearanceSecondStoreMap.put(PriceConstants.PRICING_LOC,
				locationStoreMap);
		clearanceSecondStoreMap.put(PriceConstants.CLEARANCE_OFFER_ID,
				"acayg-1");
		locations.add(clearanceSecondStoreMap);
		assertEquals(
				locations,
				(argument.getValue()).getPayloadData().get(
						PriceConstants.CLEARANCES));
	}

	@Test
	public void shouldTriggerClearanceStartMMNationalEventForEffectiveDateTomorrow()
			throws IOException, EventPublishException {
		String clrStartString = fixture("com/tesco/services/core/fixtures/clearance/SCHEDULED_CLEARANCESTART_NATIONAL.json");

		CouchbaseViewConfig mockViewConfig = Mockito
				.mock(CouchbaseViewConfig.class);

		Map<String, String> viewQueryParams = new HashMap<String, String>();
		viewQueryParams.put("stale.state", "false");
		viewQueryParams.put("page.size", "2");
		viewQueryParams.put("timeout.interval", "60000");

		Map<String, String> viewQueryAddlParams = new HashMap<String, String>();
		viewQueryAddlParams.put("offset", "+00:00");
		viewQueryAddlParams.put("effectiveday", "0");
		viewQueryAddlParams.put("country", "UK");

		Mockito.when(mockViewConfig.getViewQueryParams()).thenReturn(
				viewQueryParams);

		Mockito.when(mockViewConfig.getViewAdditionalProperties()).thenReturn(
				viewQueryAddlParams);

		Map<String, CouchbaseViewConfig> clearanceViewConfig = new HashMap<String, CouchbaseViewConfig>();
		clearanceViewConfig.put("ClearanceStart", mockViewConfig);

		Mockito.when(configuration.getCouchbaseViewConfig()).thenReturn(
				clearanceViewConfig);

		Response webViewResponse = Mockito.mock(Response.class);

		Mockito.when(webViewResponse.readEntity(String.class))
				.thenReturn(clrStartString).thenReturn(null);

		Mockito.when(
				mockWebViewTemplate.queryView(Matchers.anyMap(),
						Matchers.anyMap())).thenReturn(webViewResponse);

		scheduledClearanceStartEventJob.processScheduledEvents();

		Mockito.verify(eventTemplate, Mockito.times(1)).publishEvent(
				argument.capture());
		assertSame(PriceConstants.CLEARANCE_START_EVENT_TYPE, argument
				.getValue().getEventType());
		Map<String, String> headerMap = argument.getValue().getHeaderData();
		assertEquals("GB", headerMap.get(PriceConstants.COUNTRY));
		assertEquals(PriceConstants.CLEARANCE_START_EVENT_TYPE,
				headerMap.get(PriceConstants.EVENT_TYPE));
		assertEquals("1", headerMap.get(PriceConstants.LEAD_TIME_DAYS));
		assertEquals("tpnb:075777636", (argument.getValue()).getPayloadData()
				.get(PriceConstants.PRODUCT_REF));
		List<Map<String, Object>> locations = new ArrayList<Map<String, Object>>();
		Map<String, Object> clearanceMap = new HashMap<>();
		Map<String, Object> locationMap = new HashMap<String, Object>();
		locationMap.put(PriceConstants.LOC_TYPE, "Z");
		locationMap.put(PriceConstants.LOC_REF, "20");
		clearanceMap.put(PriceConstants.PRICING_LOC, locationMap);
		clearanceMap.put(PriceConstants.CLEARANCE_OFFER_ID, "MM");
		locations.add(clearanceMap);
		assertEquals(
				locations,
				(argument.getValue()).getPayloadData().get(
						PriceConstants.CLEARANCES));
	}

}
