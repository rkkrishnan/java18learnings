package com.tesco.services.resources;

import static org.fest.assertions.api.Assertions.assertThat;
import io.dropwizard.testing.junit.ResourceTestRule;

import java.io.IOException;

import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.junit.After;
import org.junit.Before;
import org.junit.ClassRule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.Import;
import com.tesco.services.adapters.core.ImportItemDefaultUomJob;

@RunWith(MockitoJUnitRunner.class)
public class ImportItemDefaultUomResourceTest {

	@Mock
	private static Configuration testConfiguration = TestConfiguration.load();

	private static Import importItemDefaultUomJob = Mockito
			.mock(ImportItemDefaultUomJob.class);

	@Before
	public void setUpResources() throws Exception {
		String runType = "onetime";
		Mockito.doReturn(runType).when(testConfiguration)
				.getRpmItemDefaultUomDump();
		ImportResource.getImportSemaphore().release();
	}

	@ClassRule
	public static final ResourceTestRule resources = ResourceTestRule
			.builder()
			.addResource(
					new ImportResource(testConfiguration, null, null, null,
							null, null, null, null, null, null, null,
							importItemDefaultUomJob)).build();

	@Test
	public void shouldStartItemDfltImportScript() throws IOException {
		WebTarget resource = resources
				.client()
				.target("/admin/importItemDefaultUom/item_dflt_uom/item_dflt_uom_20160413.dat");
		Response response = resource.request()
				.accept(MediaType.APPLICATION_JSON)
				.post(Entity.entity("", MediaType.APPLICATION_JSON));
		String responseText = response.readEntity(String.class);

		assertThat(responseText).isEqualTo(
				"{\"message\":\"Import Item Default UOM Job Started.\"}");
		assertThat(response.getStatus()).isEqualTo(200);
	}

	@Test
	public void itemDfltImportScriptThrowException() throws IOException {
		WebTarget resource = resources
				.client()
				.target("/admin/importItemDefaultUom/invalidRunType/item_dflt_uom_20160413.dat");
		Response response = resource.request()
				.accept(MediaType.APPLICATION_JSON)
				.post(Entity.entity("", MediaType.APPLICATION_JSON));

		assertThat(response.getStatus()).isEqualTo(400);
	}

	@After
	public void resetMocks() throws Exception {
		Mockito.reset(importItemDefaultUomJob);
		Mockito.reset(testConfiguration);
	}

}
