package com.tesco.services.adapters.rpm.readers;

import com.couchbase.client.CouchbaseClient;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tesco.services.core.*;
import com.tesco.services.repositories.CouchbaseConnectionManager;
import com.tesco.services.resources.TestConfiguration;
import com.tesco.services.utility.Dockyard;
import org.junit.Ignore;
import org.junit.Test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;

/**
 * Created by QU17 on 07/11/2014.
 */
public class MMFileReaderTest {

    ClearanceProduct clearanceProduct = null;
    ClearanceProductVariant clearanceProductVariant = null;
    ObjectMapper mapper = new ObjectMapper();
    TestConfiguration testConfiguration = TestConfiguration.load();
    CouchbaseConnectionManager couchbaseConnectionManager ;
    CouchbaseClient couchbaseClient ;
    @Ignore
    @Test
    public void shouldReadMMFileAndStoreDataInPojo() throws Exception{
        File mmDatafile = new File("C:\\Users\\qu17\\Desktop\\MMClearanceFile.dat");
        FileReader reader = new FileReader(mmDatafile);
        BufferedReader br = new BufferedReader(reader);
        String line;
        couchbaseConnectionManager = new CouchbaseConnectionManager(testConfiguration);
        couchbaseClient = couchbaseConnectionManager.getCouchbaseClient();
        String prevItem = null;
        String curItem = null;
        boolean isNewProduct = false;


        while (((line = br.readLine()) != null)) {
                if(!(line.startsWith("0") || line.startsWith("9"))){
                    curItem = line.substring(1,10);
                    if(Dockyard.isSpaceOrNull(prevItem) && !Dockyard.isSpaceOrNull(curItem)) {
                        isNewProduct = true;
                    } else if(prevItem != null && !curItem.equals(prevItem)) {
                        isNewProduct = true;
                        String clearanceProductJson = mapper.writeValueAsString(clearanceProduct);
                        System.out.print(clearanceProductJson);
                        couchbaseClient.set(getClearanceProductKey(clearanceProduct.getProductId()),clearanceProductJson);
                    }
                    if(line.startsWith("6")) {
                        clearanceProduct = getDatafromLineWithStoreDetailsAndBuildClearanceProductJson(line, isNewProduct);
                    }else{
                        clearanceProduct = getDatafromLineWithOutStoreDetailsAndBuildClearanceProductJson(line, isNewProduct);
                    }
                    prevItem = curItem;
                    isNewProduct = false;
                }
            }

        br.close();
    }
   /* string(9) BASE_PRODUCT_NO;
    string(4) FILLER;
    string(5) RETAIL_OUTLET_NO;
    date("YYYYMMDD") SELL_PRICE_EFF_DATE;
    string(1) CHARGE_TYPE_CODE; *//* NATIONAL_MARKDOWN = "N" STORE_UNIQUE = "S" DYNAMIC_MARKDOWN = "D" *//*
    string(1) ACTION; *//* INSERT = "I" DELETE = "D"  UPDATE = "U" *//*
    string(3) CCY_CDE; *//* GBP:"GBP" EU:"EU" *//*
    decimal(10.2) SELLING_PRICE;
    string(2) SYSTEM_ID; *//* MM:"MM" MI:"MI" *//*
    date("YYYYMMDD") SELL_PRICE_EFFV_END;
   */
    //6075777636         20141013NUEUR0000003.00MM20141102HP20013
    //6070461113     296420140721SUGBP0000011.70MM20141029GX40011


    public ClearanceProduct getDatafromLineWithStoreDetailsAndBuildClearanceProductJson(String line, boolean isNewProduct) throws IOException, ParseException {
         //line = "6070461113     296420140721SUGBP0000011.70MM20141029GX40011";
        String docType = "datedPrice";
        String dateTimeFormat = "ISO8601";
        String countryFormat = "ISO3166";
        String currenrcyFormat = "ISO4217";
        String version = "1.0";
        String prodType = "tpnb";
        String productId = line.substring(1,10);
        String filer = line.substring(10,14);
        String storeId = line.substring(14,19);
        String effevDate = line.substring(19,27);
        String chargeType = line.substring(27,28);
        String action = line.substring(28,29);
        String currencyCode = line.substring(29,32);
        String clearancePrice = line.substring(32,42);
        String sourcesystem = line.substring(42,44);
        String endDate = line.substring(44,52);

        if(action.equalsIgnoreCase("U")){
            if(isNewProduct){
                String clearanceProductJson;
                clearanceProductJson = (String)couchbaseClient.get(getClearanceProductKey(productId));
                clearanceProduct = mapper.readValue(clearanceProductJson,ClearanceProduct.class);

                clearanceProduct.setVersionNo(version);
                clearanceProduct.setDocType(docType);
                clearanceProduct.setCountryFormat(countryFormat);
                clearanceProduct.setCurrencyFormat(currenrcyFormat);
                clearanceProduct.setDateTimeFormat(dateTimeFormat);
                clearanceProduct.setProdType(prodType);
                clearanceProduct.setSellingUom("EA");
                clearanceProductVariant = new ClearanceProductVariant("234567891");//should get tpnc from look up

            }

            ClearanceByDateTime clearanceByDateTime = new ClearanceByDateTime();
            clearanceByDateTime.setClearancePrice(clearancePrice);
            clearanceByDateTime.setClearanceRef(sourcesystem);
            clearanceByDateTime.setEffvDateTime(effevDate);
            clearanceByDateTime.setEndDateTime(endDate);

            if(chargeType.equals("S")){
                ClearanceStoreSaleInfo clearanceStoreSaleInfo = new ClearanceStoreSaleInfo();
                clearanceStoreSaleInfo.setClearanceStoreId(storeId);
                clearanceStoreSaleInfo.setCurrency(currencyCode);
                if(currencyCode.equalsIgnoreCase("EUR")){
                    clearanceStoreSaleInfo.setCountryCode("IE");
                }else{
                    clearanceStoreSaleInfo.setCountryCode("UK");
                }
                clearanceStoreSaleInfo.addStoreClearanceByDateTime(clearanceByDateTime);
                clearanceProductVariant.addClearanceStoreSaleInfo(clearanceStoreSaleInfo);
            } else{
                ClearanceZoneSaleInfo clearanceZoneSaleInfo = new ClearanceZoneSaleInfo();
                if(currencyCode.equalsIgnoreCase("EUR")){
                    clearanceZoneSaleInfo.setClearanceZoneId("21");
                    clearanceZoneSaleInfo.setCountryCode("IE");

                }else{
                    clearanceZoneSaleInfo.setClearanceZoneId("20");
                    clearanceZoneSaleInfo.setCountryCode("UK");
                }
                clearanceZoneSaleInfo.addZoneClearanceByDateTime(clearanceByDateTime);
                clearanceProductVariant.addClearanceZoneSaleInfo(clearanceZoneSaleInfo);
            }
            clearanceProduct.addClearanceProductVariant(clearanceProductVariant);
        }else if(action.equalsIgnoreCase("I")){
            if(isNewProduct){

                clearanceProduct.setVersionNo(version);
                clearanceProduct.setDocType(docType);
                clearanceProduct.setCountryFormat(countryFormat);
                clearanceProduct.setCurrencyFormat(currenrcyFormat);
                clearanceProduct.setDateTimeFormat(dateTimeFormat);
                clearanceProduct.setProdType(prodType);
                clearanceProduct.setSellingUom("EA");
                clearanceProductVariant = new ClearanceProductVariant("234567891");//should get tpnc from look up

            }

            ClearanceByDateTime clearanceByDateTime = new ClearanceByDateTime();
            clearanceByDateTime.setClearancePrice(clearancePrice);
            clearanceByDateTime.setClearanceRef("MM");
            clearanceByDateTime.setEffvDateTime(effevDate);
            clearanceByDateTime.setEndDateTime(endDate);

            if(chargeType.equals("S")){
                ClearanceStoreSaleInfo clearanceStoreSaleInfo = new ClearanceStoreSaleInfo();
                clearanceStoreSaleInfo.setClearanceStoreId(storeId);
                clearanceStoreSaleInfo.setCurrency(currencyCode);
                if(currencyCode.equalsIgnoreCase("EUR")){
                    clearanceStoreSaleInfo.setCountryCode("IE");
                }else{
                    clearanceStoreSaleInfo.setCountryCode("UK");
                }
                clearanceStoreSaleInfo.addStoreClearanceByDateTime(clearanceByDateTime);
                clearanceProductVariant.addClearanceStoreSaleInfo(clearanceStoreSaleInfo);
            } else{
                ClearanceZoneSaleInfo clearanceZoneSaleInfo = new ClearanceZoneSaleInfo();
                if(currencyCode.equalsIgnoreCase("EUR")){
                    clearanceZoneSaleInfo.setClearanceZoneId("21");
                    clearanceZoneSaleInfo.setCountryCode("IE");

                }else{
                    clearanceZoneSaleInfo.setClearanceZoneId("20");
                    clearanceZoneSaleInfo.setCountryCode("UK");
                }
                clearanceZoneSaleInfo.addZoneClearanceByDateTime(clearanceByDateTime);
                clearanceProductVariant.addClearanceZoneSaleInfo(clearanceZoneSaleInfo);
            }
            clearanceProduct.addClearanceProductVariant(clearanceProductVariant);
        }else{
            if(isNewProduct){
                String clearanceProductJson;
                clearanceProductJson = (String)couchbaseClient.get(getClearanceProductKey(productId));
                clearanceProduct = mapper.readValue(clearanceProductJson,ClearanceProduct.class);
            }
            if(chargeType.equals("S")){
                clearanceProductVariant = clearanceProduct.getClearanceProductVariantByTPNC("");
                ClearanceStoreSaleInfo clearanceStoreSaleInfo = clearanceProductVariant.getClearanceStoreSaleInfo(storeId);
                clearanceProductVariant.deleteClearanceStoreSaleInfo(clearanceStoreSaleInfo);
            } else{
                clearanceProductVariant = clearanceProduct.getClearanceProductVariantByTPNC("");
                ClearanceZoneSaleInfo clearanceZoneSaleInfo;
                if(currencyCode.equalsIgnoreCase("EUR")){
                    clearanceZoneSaleInfo = clearanceProductVariant.getClearanceZoneSaleInfo("21");
                }else{
                    clearanceZoneSaleInfo = clearanceProductVariant.getClearanceZoneSaleInfo("20");
                }
                clearanceProductVariant.deleteClearanceZoneSaleInfo(clearanceZoneSaleInfo);
            }
            clearanceProduct.addClearanceProductVariant(clearanceProductVariant);
        }


        return clearanceProduct;
    }

   /* if (rec_type == '8')
    record
    string(9) mmxpe_bpr_tpn;
    string(4) filler3;
    string(8) mmxpe_effv_date;
    string(1) mmxpe_charge_type_code;
    string(1) mmxpe_action;
    string(3) mmxpe_curcy_code;
    decimal(10,2) mmxpe_selling_price;
    string(2) mmxpe_system_id;
    string(8) mmxpe_end_date;
    string(1) newline = "\n";
    end mmxpe_regular_price_chng_rec;*/

    public ClearanceProduct getDatafromLineWithOutStoreDetailsAndBuildClearanceProductJson(String line, boolean isNewProduct) {
        //line = "6070461113     296420140721SUGBP0000011.70MM20141029GX40011";
        String docType = "datedPrice";
        String dateTimeFormat = "ISO8601";
        String countryFormat = "ISO3166";
        String currenrcyFormat = "ISO4217";
        String version = "1.0";
        String prodType = "tpnb";
        String productId = line.substring(1,10);
       /* String filer = line.substring(10,14);
        String storeId = line.substring(14,19);*/
        String effevDate = line.substring(14,22);
        String chargeType = line.substring(22,23);
        String action = line.substring(23,24);
        String currencyCode = line.substring(24,27);
        String clearancePrice = line.substring(27,37);
        String sourcesystem = line.substring(38,40);
        String endDate = line.substring(40,48);
       /* String EVENT_REF = line.substring(52,55);
        String MKDWN_REF = line.substring(55,58);
        String EVENT_PHASE = line.substring(58,59);*/
        /*String COVER_GROUP = line.substring(59,60);
        String EVENT_POS_IND = line.substring(60,61);
        String EVENT_SEL_IND = line.substring(61,62);
        String HOPOS_TEMPLATE_ID = line.substring(62,70);*/

        return clearanceProduct;
    }
    private String getClearanceProductKey(String tpnb) {
        return String.format("CLRPROD_%s", tpnb);
    }
}
