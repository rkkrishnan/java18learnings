package com.tesco.services.adapters.rpm.readers;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;

import com.tesco.services.adapters.rpm.readers.impl.PriceMessageRouter;
import com.tesco.services.repositories.RepositoryImpl;

import org.apache.commons.lang3.tuple.ImmutablePair;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.xml.sax.SAXParseException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tesco.couchbase.AsyncCouchbaseWrapper;
import com.tesco.couchbase.CouchbaseWrapper;
import com.tesco.couchbase.testutils.AsyncCouchbaseWrapperStub;
import com.tesco.couchbase.testutils.BucketTool;
import com.tesco.couchbase.testutils.CouchbaseTestManager;
import com.tesco.couchbase.testutils.CouchbaseWrapperStub;
import com.tesco.price.core.RegPrcChgDesc;
import com.tesco.price.core.RegPrcChgRef;
import com.tesco.services.Configuration;
import com.tesco.services.adapters.price.PriceEventHandler;
import com.tesco.services.adapters.price.impl.PriceHandlerImpl;
import com.tesco.services.adapters.rpm.writers.impl.PriceWriter;
import com.tesco.services.core.price.PriceEntity;
import com.tesco.services.exceptions.MessageRouterException;
import com.tesco.services.exceptions.PriceBusinessException;
import com.tesco.services.resources.TestConfiguration;
import com.tesco.services.utility.ParseMessageUtil;
import com.tesco.services.utility.PriceConstants;

/**
 * Created by qp65 on 9/8/2015.
 */
public class PriceMessageRouterTest {

	private ObjectMapper mapper;
	private static Configuration testConfiguration;

	@Mock
	private PriceWriter priceWriter;

	@Mock
	private CouchbaseTestManager couchbaseTestManager;

	@Mock
	private CouchbaseWrapper couchbaseWrapper;

	@Mock
	private AsyncCouchbaseWrapper asyncCouchbaseWrapper;

	@Mock
	private RepositoryImpl repositoryImpl;

	@Mock
	private PriceHandlerImpl priceHandler;

	@Mock
	private PriceEventHandler priceEventHandler;

	@Before
	public void setUp() throws Exception {
		testConfiguration = TestConfiguration.load();

		if (testConfiguration.isDummyCouchbaseMode()) {
			Map<String, ImmutablePair<Long, String>> fakeBase = new HashMap<>();
			couchbaseTestManager = new CouchbaseTestManager(
					new CouchbaseWrapperStub(fakeBase),
					new AsyncCouchbaseWrapperStub(fakeBase),
					mock(BucketTool.class));
		} else {
			couchbaseTestManager = new CouchbaseTestManager(
					testConfiguration.getCouchbaseBucket(),
					testConfiguration.getCouchbaseUsername(),
					testConfiguration.getCouchbasePassword(),
					testConfiguration.getCouchbaseNodes(),
					testConfiguration.getCouchbaseAdminUsername(),
					testConfiguration.getCouchbaseAdminPassword());
		}

		couchbaseWrapper = couchbaseTestManager.getCouchbaseWrapper();
		asyncCouchbaseWrapper = couchbaseTestManager.getAsyncCouchbaseWrapper();
		mapper = new ObjectMapper();
		repositoryImpl = new RepositoryImpl(this.couchbaseWrapper,
				asyncCouchbaseWrapper, mapper);
		priceEventHandler = Mockito.mock(PriceEventHandler.class);
		priceHandler = Mockito.mock(PriceHandlerImpl.class);
	}

	@Test
	public void shouldUnmarshallAndProcessPriceCreMsg() throws Exception {

		RegPrcChgDesc regPrcChgDesc = null;
		String item = "075360150";
		String cb_key = PriceConstants.PRICE_DOC_KEY_PREFIX + item + "Z_" + 10;
		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "  <ribMessage>\n"
				+ "    <family>REGPRCCHG</family>\n"
				+ "    <type>REGPRCCHGCRE</type>\n"
				+ "    <ribmessageID>12.0|RIBMessagePublisherEjb|REGPRCCHG|2015.06.09 13:01:19.275|914</ribmessageID>\n"
				+ "    <publishTime>2015-06-09 13:01:19.275 BST</publishTime>\n"
				+ "    <messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "&lt;RegPrcChgDesc&gt;&lt;location&gt;10&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;RegPrcChgDtl&gt;&lt;price_change_id&gt;40686471&lt;/price_change_id&gt;&lt;item&gt;075360150&lt;/item&gt;&lt;tsl_consumer_unit&gt;281011436&lt;/tsl_consumer_unit&gt;&lt;effective_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;10&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/effective_date&gt;&lt;selling_retail_changed_ind&gt;1&lt;/selling_retail_changed_ind&gt;&lt;selling_unit_retail&gt;2&lt;/selling_unit_retail&gt;&lt;selling_uom&gt;EA&lt;/selling_uom&gt;&lt;selling_currency&gt;EUR&lt;/selling_currency&gt;&lt;multi_unit_changed_ind&gt;0&lt;/multi_unit_changed_ind&gt;&lt;/RegPrcChgDtl&gt;&lt;RegPrcChgDtl&gt;&lt;price_change_id&gt;40686427&lt;/price_change_id&gt;&lt;item&gt;070479830&lt;/item&gt;&lt;tsl_consumer_unit&gt;270926442&lt;/tsl_consumer_unit&gt;&lt;effective_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;10&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/effective_date&gt;&lt;selling_retail_changed_ind&gt;1&lt;/selling_retail_changed_ind&gt;&lt;selling_unit_retail&gt;3.16&lt;/selling_unit_retail&gt;&lt;selling_uom&gt;EA&lt;/selling_uom&gt;&lt;selling_currency&gt;EUR&lt;/selling_currency&gt;&lt;multi_unit_changed_ind&gt;0&lt;/multi_unit_changed_ind&gt;&lt;/RegPrcChgDtl&gt;&lt;RegPrcChgDtl&gt;&lt;price_change_id&gt;40686515&lt;/price_change_id&gt;&lt;item&gt;071897051&lt;/item&gt;&lt;tsl_consumer_unit&gt;273823052&lt;/tsl_consumer_unit&gt;&lt;effective_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;10&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/effective_date&gt;&lt;selling_retail_changed_ind&gt;1&lt;/selling_retail_changed_ind&gt;&lt;selling_unit_retail&gt;1.57&lt;/selling_unit_retail&gt;&lt;selling_uom&gt;EA&lt;/selling_uom&gt;&lt;selling_currency&gt;EUR&lt;/selling_currency&gt;&lt;multi_unit_changed_ind&gt;0&lt;/multi_unit_changed_ind&gt;&lt;/RegPrcChgDtl&gt;&lt;RegPrcChgDtl&gt;&lt;price_change_id&gt;40686393&lt;/price_change_id&gt;&lt;item&gt;075097375&lt;/item&gt;&lt;tsl_consumer_unit&gt;280484050&lt;/tsl_consumer_unit&gt;&lt;effective_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;10&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/effective_date&gt;&lt;selling_retail_changed_ind&gt;1&lt;/selling_retail_changed_ind&gt;&lt;selling_unit_retail&gt;1.92&lt;/selling_unit_retail&gt;&lt;selling_uom&gt;EA&lt;/selling_uom&gt;&lt;selling_currency&gt;EUR&lt;/selling_currency&gt;&lt;multi_unit_changed_ind&gt;0&lt;/multi_unit_changed_ind&gt;&lt;/RegPrcChgDtl&gt;&lt;/RegPrcChgDesc&gt;</messageData>\n"
				+ "    <customData>\n" + "    </customData>\n"
				+ "    <customFlag>F</customFlag>\n" + "  </ribMessage>\n"
				+ "</RibMessages>";

		PriceMessageRouter priceMessageRouter = new PriceMessageRouter(
				priceHandler, priceEventHandler);

		Mockito.doNothing().when(priceHandler).processCre(regPrcChgDesc);
		Mockito.when(priceEventHandler.processCreEvent(regPrcChgDesc))
				.thenReturn("10");

		priceMessageRouter.route(data);
		Assert.assertNull(repositoryImpl.getGenericObject(cb_key,
				PriceEntity.class));
	}

	@Test
	public void shouldUnmarshallAndProcessPriceDelMsg() throws Exception {

		RegPrcChgRef regPrcChgRef = null;
		String item = "050959379-024";
		String cb_key = PriceConstants.PRICE_DOC_KEY_PREFIX + item + "Z_" + 11;

		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "  <ribMessage>\n"
				+ "    <family>REGPRCCHG</family>\n"
				+ "    <type>REGPRCCHGDEL</type>\n"
				+ "    <ribmessageID>12.0|RIBMessagePublisherEjb|REGPRCCHG|2015.06.12 16:17:00.417|1754</ribmessageID>\n"
				+ "    <publishTime>2015-06-12 16:17:00.417 BST</publishTime>\n"
				+ "    <messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "&lt;RegPrcChgRef&gt;&lt;location&gt;11&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;RegPrcChgDtlRef&gt;&lt;price_change_id&gt;40696405&lt;/price_change_id&gt;&lt;item&gt;050959379-024&lt;/item&gt;&lt;tsl_consumer_unit&gt;280780603&lt;/tsl_consumer_unit&gt;&lt;/RegPrcChgDtlRef&gt;&lt;/RegPrcChgRef&gt;</messageData>\n"
				+ "    <customData>\n" + "    </customData>\n"
				+ "    <customFlag>F</customFlag>\n" + "  </ribMessage>\n"
				+ "</RibMessages>";

		PriceMessageRouter priceMessageRouter = new PriceMessageRouter(
				priceHandler, priceEventHandler);
		PriceEntity pe = new PriceEntity();
		String eventType = "Reg";
		pe.setLocRef("GB");
		pe.setLocType("Z");
		pe.setProdRef("1234");
		pe.setProdType("hhh");
		Map<String, PriceEntity> map11 = new HashMap<String, PriceEntity>();
		map11.put(eventType, pe);

		Mockito.doNothing().when(priceHandler).processDel(regPrcChgRef);

		Mockito.when(priceEventHandler.getPriceEntityData(regPrcChgRef))
				.thenReturn(map11);
		Mockito.when(priceEventHandler.processDelEvent(regPrcChgRef, map11))
				.thenReturn("10");
		priceMessageRouter.route(data);
		Assert.assertNull(repositoryImpl.getGenericObject(cb_key,
				PriceEntity.class));
	}

	@Test
	public void invalidPriceMsgType() throws Exception {

		RegPrcChgRef regPrcChgRef = null;
		String item = "050959379-024";
		String cb_key = PriceConstants.PRICE_DOC_KEY_PREFIX + item + "Z_" + 11;
		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "  <ribMessage>\n"
				+ "    <family>REGPRCCHG</family>\n"
				+ "    <type>INVALID_TYPE</type>\n"
				+ "    <ribmessageID>12.0|RIBMessagePublisherEjb|REGPRCCHG|2015.06.12 16:17:00.417|1754</ribmessageID>\n"
				+ "    <publishTime>2015-06-12 16:17:00.417 BST</publishTime>\n"
				+ "    <messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "&lt;RegPrcChgRef&gt;&lt;location&gt;11&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;RegPrcChgDtlRef&gt;&lt;price_change_id&gt;40696405&lt;/price_change_id&gt;&lt;item&gt;050959379-024&lt;/item&gt;&lt;tsl_consumer_unit&gt;280780603&lt;/tsl_consumer_unit&gt;&lt;/RegPrcChgDtlRef&gt;&lt;/RegPrcChgRef&gt;</messageData>\n"
				+ "    <customData>\n" + "    </customData>\n"
				+ "    <customFlag>F</customFlag>\n" + "  </ribMessage>\n"
				+ "</RibMessages>";

		PriceMessageRouter priceMessageRouter = new PriceMessageRouter(
				priceHandler, priceEventHandler);

		Mockito.doNothing().when(priceHandler).processDel(regPrcChgRef);

		try {
			priceMessageRouter.route(data);
		} catch (MessageRouterException e) {
			Assert.assertTrue(e.getMessage().equals(
					"Invalid Message tyoe --> INVALID_TYPE"));
		}
	}

	@Test
	public void testSAXParseException() throws Exception {
		PriceMessageRouter priceMessageRouter = new PriceMessageRouter(
				priceHandler, priceEventHandler);
		ParseMessageUtil parseMessageUtilMock = mock(ParseMessageUtil.class);
		when(
				parseMessageUtilMock.getNodeData(Matchers.any(String.class),
						Matchers.any(String.class))).thenThrow(
				SAXParseException.class);

		String data = "";
		try {
			priceMessageRouter.route(data);
		} catch (MessageRouterException e) {
			Assert.assertTrue(e.getCause() instanceof SAXParseException);

		}
	}

	@Test(expected = MessageRouterException.class)
	public void shouldThrowExceptionWhenProcessDeleteOperationFailed()
			throws Exception {
		PriceMessageRouter priceMessageRouter = new PriceMessageRouter(
				priceHandler, priceEventHandler);
		Mockito.doThrow(new PriceBusinessException()).when(priceHandler)
				.processDel(Matchers.any(RegPrcChgRef.class));

		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "  <ribMessage>\n"
				+ "    <family>REGPRCCHG</family>\n"
				+ "    <type>REGPRCCHGDEL</type>\n"
				+ "    <ribmessageID>12.0|RIBMessagePublisherEjb|REGPRCCHG|2015.06.12 16:17:00.417|1754</ribmessageID>\n"
				+ "    <publishTime>2015-06-12 16:17:00.417 BST</publishTime>\n"
				+ "    <messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "&lt;RegPrcChgRef&gt;&lt;location&gt;11&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;RegPrcChgDtlRef&gt;&lt;price_change_id&gt;40696405&lt;/price_change_id&gt;&lt;item&gt;050959379-024&lt;/item&gt;&lt;tsl_consumer_unit&gt;280780603&lt;/tsl_consumer_unit&gt;&lt;/RegPrcChgDtlRef&gt;&lt;/RegPrcChgRef&gt;</messageData>\n"
				+ "    <customData>\n" + "    </customData>\n"
				+ "    <customFlag>F</customFlag>\n" + "  </ribMessage>\n"
				+ "</RibMessages>";

		priceMessageRouter.route(data);

	}

	@Test(expected = MessageRouterException.class)
	public void testMessageRouterException() throws MessageRouterException {
		PriceMessageRouter priceMessageRouter = new PriceMessageRouter(
				priceHandler,  priceEventHandler);

		// provided the invalid type so it should throw MessageRouterException
		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
				+ "<RibMessages><ribMessage><family>REGPRCCHG</family><type>REGPRCCHGCRE1</type><ribmessageID>12.0|RIBMessagePublisherEjb|REGPRCCHG|2015.06.09 13:01:19.275|914</ribmessageID><publishTime>2015-06-09 13:01:19.275 BST</publishTime><messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;"
				+ "&lt;RegPrcChgDesc&gt;&lt;location&gt;1&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;RegPrcChgDtl&gt;&lt;price_change_id&gt;40686693&lt;/price_change_id&gt;&lt;item&gt;071075851&lt;/item&gt;&lt;tsl_consumer_unit&gt;272166306&lt;/tsl_consumer_unit&gt;&lt;effective_date&gt;&lt;year&gt;2019&lt;/year&gt;&lt;month&gt;3&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/effective_date&gt;&lt;selling_retail_changed_ind&gt;1&lt;/selling_retail_changed_ind&gt;&lt;selling_unit_retail&gt;9.56&lt;/selling_unit_retail&gt;&lt;selling_uom&gt;EA&lt;/selling_uom&gt;&lt;selling_currency&gt;EUR&lt;/selling_currency&gt;&lt;multi_unit_changed_ind&gt;0&lt;/multi_unit_changed_ind&gt;&lt;/RegPrcChgDtl&gt;&lt;RegPrcChgDtl&gt;&lt;price_change_id&gt;40686835&lt;/price_change_id&gt;&lt;item&gt;073334058&lt;/item&gt;&lt;tsl_consumer_unit&gt;276704488&lt;/tsl_consumer_unit&gt;&lt;effective_date&gt;&lt;year&gt;2019&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;10&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/effective_date&gt;&lt;selling_retail_changed_ind&gt;1&lt;/selling_retail_changed_ind&gt;&lt;selling_unit_retail&gt;14.77&lt;/selling_unit_retail&gt;&lt;selling_uom&gt;EA&lt;/selling_uom&gt;&lt;selling_currency&gt;EUR&lt;/selling_currency&gt;&lt;multi_unit_changed_ind&gt;0&lt;/multi_unit_changed_ind&gt;&lt;/RegPrcChgDtl&gt;&lt;/RegPrcChgDesc&gt;</messageData><customData /><customFlag>F</customFlag></ribMessage></RibMessages>";

		priceMessageRouter.route(data);

	}

}
