package com.tesco.services.adapters.rpm.writers;

import com.tesco.services.adapters.rpm.comparators.RPMComparator;
import com.tesco.services.adapters.rpm.events.ClearanceEventHandler;
import com.tesco.services.adapters.rpm.writers.impl.MMWriter;
import com.tesco.services.core.ClearanceByDateTime;
import com.tesco.services.core.ClearanceMMProduct;
import com.tesco.services.core.ClearanceStoreSaleInfo;
import com.tesco.services.core.ClearanceZoneSaleInfo;
import com.tesco.services.resources.ImportResource;
import com.tesco.services.utility.PriceConstants;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.io.BufferedReader;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.concurrent.Semaphore;

import static org.mockito.Mockito.when;

/**
 * Created by IV16 on 03/02/2015.
 */
@RunWith(MockitoJUnitRunner.class)
public class MMWriterOneTimeTest extends MMWriterTest {
	public MMWriter mmWriter;

	String runIdentifier = "mmondemand";

	private ClearanceEventHandler clearanceEventHandler;

	@Mock
	protected BufferedReader mmClrFileReader;

	@Before
	@Override
	public void setUp() throws IOException, URISyntaxException,
			InterruptedException {
		super.setUp();
		clearanceEventHandler = Mockito.mock(ClearanceEventHandler.class);
		mmWriter = new MMWriter(testConfiguration, repositoryImpl, mmClrFileReader,
				clearanceEventHandler,clearanceProductMapper);
		mmWriter.setRunIdentifier(runIdentifier);
		ImportResource.importSemaphoreForIdentifier.put(runIdentifier,
				new Semaphore(1));
	}

	@Test
	public void readAndWriteMMClrForUKNat() throws Exception {
		String line1 = "6075777636         20150125NIGBP0000002.00MM20160125";
		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "GBP";
		ConstructProductAndTpncMapping(productId, tpnc);
		when(mmClrFileReader.readLine()).thenReturn(line1).thenReturn(null);
		ClearanceByDateTime clearanceByDateTimeForNationalZone = createClearanceByDateTime(
				"20150125", "20160125", "MM", "0000002.00");

		ClearanceZoneSaleInfo clearanceZoneSaleInfo = createClearanceZoneSaleInfo(
				"20", "UK", "GBP", clearanceByDateTimeForNationalZone);

		final ClearanceMMProduct expectedClearanceMMProduct = createClearanceMMProduct(
				productId, clearanceZoneSaleInfo, null);

		this.mmWriter.write(null);
		ClearanceMMProduct actualClearanceProduct = (ClearanceMMProduct) repositoryImpl
				.getGenericObject(PriceConstants.CLEARANCE_MM_PRODUCT_KEY_PREFIX
						+ productId, ClearanceMMProduct.class);;
		boolean isEqual = new RPMComparator().compare(actualClearanceProduct,
				expectedClearanceMMProduct);
		Assert.assertTrue(isEqual);
	}

	@Test
	public void readAndWriteMMClrForUKStore() throws Exception {
		String line1 = "6075777636     296420150125SIGBP0000003.00MM20160125";
		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "GBP";
		ConstructProductAndTpncMapping(productId, tpnc);
		when(mmClrFileReader.readLine()).thenReturn(line1).thenReturn(null);
		ClearanceByDateTime clearanceByDateTimeForStore = createClearanceByDateTime(
				"20150125", "20160125", "MM", "0000003.00");
		ClearanceStoreSaleInfo clearanceStoreSaleInfo = createClearanceStoreSaleInfo(
				" 2964", "UK", "GBP", clearanceByDateTimeForStore);
		final ClearanceMMProduct expectedClearanceMMProduct = createClearanceMMProduct(
				productId, null, clearanceStoreSaleInfo);

		this.mmWriter.write(null);
		ClearanceMMProduct actualClearanceProduct = (ClearanceMMProduct) repositoryImpl
				.getGenericObject(PriceConstants.CLEARANCE_MM_PRODUCT_KEY_PREFIX
						+ productId, ClearanceMMProduct.class);;
		boolean isEqual = new RPMComparator().compare(actualClearanceProduct,
				expectedClearanceMMProduct);
		Assert.assertTrue(isEqual);
	}

	@Test
	public void readAndWriteMMClrForROINat() throws Exception {
		String line1 = "6075777636         20150125NIEU 0000002.00MM20160125";
		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "EUR";
		ConstructProductAndTpncMapping(productId, tpnc);
		when(mmClrFileReader.readLine()).thenReturn(line1).thenReturn(null);
		ClearanceByDateTime clearanceByDateTimeForNationalZone = createClearanceByDateTime(
				"20150125", "20160125", "MM", "0000002.00");

		ClearanceZoneSaleInfo clearanceZoneSaleInfo = createClearanceZoneSaleInfo(
				"21", "IE", "EUR", clearanceByDateTimeForNationalZone);

		final ClearanceMMProduct expectedClearanceMMProduct = createClearanceMMProduct(
				productId, clearanceZoneSaleInfo, null);

		this.mmWriter.write(null);
		ClearanceMMProduct actualClearanceProduct = (ClearanceMMProduct) repositoryImpl
				.getGenericObject(PriceConstants.CLEARANCE_MM_PRODUCT_KEY_PREFIX
						+ productId,ClearanceMMProduct.class);
		boolean isEqual = new RPMComparator().compare(actualClearanceProduct,
				expectedClearanceMMProduct);
		Assert.assertTrue(isEqual);
	}

	@Test
	public void readAndWriteMMClrForROIStore() throws Exception {
		String line1 = "6075777636     645620150125SIEU 0000003.00MM20160125";
		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "EUR";
		ConstructProductAndTpncMapping(productId, tpnc);
		when(mmClrFileReader.readLine()).thenReturn(line1).thenReturn(null);
		ClearanceByDateTime clearanceByDateTimeForStore = createClearanceByDateTime(
				"20150125", "20160125", "MM", "0000003.00");
		ClearanceStoreSaleInfo clearanceStoreSaleInfo = createClearanceStoreSaleInfo(
				" 6456", "IE", "EUR", clearanceByDateTimeForStore);
		final ClearanceMMProduct expectedClearanceMMProduct = createClearanceMMProduct(
				productId, null, clearanceStoreSaleInfo);

		this.mmWriter.write(null);
		ClearanceMMProduct actualClearanceProduct = (ClearanceMMProduct) repositoryImpl
				.getGenericObject(PriceConstants.CLEARANCE_MM_PRODUCT_KEY_PREFIX
						+ productId, ClearanceMMProduct.class);
		boolean isEqual = new RPMComparator().compare(actualClearanceProduct,
				expectedClearanceMMProduct);
		Assert.assertTrue(isEqual);
	}

	@Test
	public void readAndWriteMMClrForUKNatOverwriteExistData() throws Exception {
		String line1 = "6075777636         20150125NIGBP0000002.00MM20160125";
		String line2 = "6075777636         20160125NIGBP0000002.00MM20170125";
		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "GBP";
		ConstructProductAndTpncMapping(productId, tpnc);
		insertClearanceProduct(clearanceProductMapper
				.mapLineDataToClearanceMMProduct(line1, true, runIdentifier));

		when(mmClrFileReader.readLine()).thenReturn(line2).thenReturn(null);
		ClearanceByDateTime clearanceByDateTimeForNationalZone = createClearanceByDateTime(
				"20160125", "20170125", "MM", "0000002.00");

		ClearanceZoneSaleInfo clearanceZoneSaleInfo = createClearanceZoneSaleInfo(
				"20", "UK", "GBP", clearanceByDateTimeForNationalZone);

		final ClearanceMMProduct expectedClearanceMMProduct = createClearanceMMProduct(
				productId, clearanceZoneSaleInfo, null);

		this.mmWriter.write(null);
		ClearanceMMProduct actualClearanceProduct = (ClearanceMMProduct) repositoryImpl
				.getGenericObject(PriceConstants.CLEARANCE_MM_PRODUCT_KEY_PREFIX
						+ productId, ClearanceMMProduct.class);;
		boolean isEqual = new RPMComparator().compare(actualClearanceProduct,
				expectedClearanceMMProduct);
		Assert.assertTrue(isEqual);
	}

	@Test
	public void readAndWriteMMClrForROINatOverwriteExistData() throws Exception {
		String line1 = "6075777636         20150125NIEU 0000002.00MM20160125";
		String line2 = "6075777636         20160125NIEU 0000002.00MM20170125";
		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "EUR";
		ConstructProductAndTpncMapping(productId, tpnc);
		insertClearanceProduct(clearanceProductMapper
				.mapLineDataToClearanceMMProduct(line1, true, runIdentifier));

		when(mmClrFileReader.readLine()).thenReturn(line2).thenReturn(null);
		ClearanceByDateTime clearanceByDateTimeForNationalZone = createClearanceByDateTime(
				"20160125", "20170125", "MM", "0000002.00");

		ClearanceZoneSaleInfo clearanceZoneSaleInfo = createClearanceZoneSaleInfo(
				"21", "IE", "EUR", clearanceByDateTimeForNationalZone);

		final ClearanceMMProduct expectedClearanceMMProduct = createClearanceMMProduct(
				productId, clearanceZoneSaleInfo, null);

		this.mmWriter.write(null);
		ClearanceMMProduct actualClearanceProduct = (ClearanceMMProduct) repositoryImpl
				.getGenericObject(PriceConstants.CLEARANCE_MM_PRODUCT_KEY_PREFIX+productId,ClearanceMMProduct.class);
		boolean isEqual = new RPMComparator().compare(actualClearanceProduct,
				expectedClearanceMMProduct);
		Assert.assertTrue(isEqual);
	}

	@Test
	public void readAndWriteMMClrForUKStoreOverwriteExistData()
			throws Exception {
		String line1 = "6075777636     296420150125SIGBP0000003.00MM20160125";
		String line2 = "6075777636     296420160125SIGBP0000003.00MM20170125";
		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "GBP";
		ConstructProductAndTpncMapping(productId, tpnc);
		insertClearanceProduct(clearanceProductMapper
				.mapLineDataToClearanceMMProduct(line1, true, runIdentifier));

		when(mmClrFileReader.readLine()).thenReturn(line2).thenReturn(null);
		ClearanceByDateTime clearanceByDateTimeForStore = createClearanceByDateTime(
				"20160125", "20170125", "MM", "0000003.00");

		ClearanceStoreSaleInfo clearanceStoreSaleInfo = createClearanceStoreSaleInfo(
				" 2964", "UK", "GBP", clearanceByDateTimeForStore);

		final ClearanceMMProduct expectedClearanceMMProduct = createClearanceMMProduct(
				productId, null, clearanceStoreSaleInfo);

		this.mmWriter.write(null);
		ClearanceMMProduct actualClearanceProduct = (ClearanceMMProduct) repositoryImpl
				.getGenericObject(PriceConstants.CLEARANCE_MM_PRODUCT_KEY_PREFIX
						+ productId, ClearanceMMProduct.class);;
		Assert.assertEquals(actualClearanceProduct,expectedClearanceMMProduct);
	}

	@Test
	public void readAndWriteMMClrForROIStoreOverwriteExistData()
			throws Exception {
		String line1 = "6075777636     645620150125SIEU 0000003.00MM20160125";
		String line2 = "6075777636     645620160125SIEU 0000003.00MM20170125";
		String tpnc = "281837179";
		String productId = "075777636";
		currencyCode = "EUR";
		ConstructProductAndTpncMapping(productId, tpnc);
		insertClearanceProduct(clearanceProductMapper
				.mapLineDataToClearanceMMProduct(line1, true, runIdentifier));

		when(mmClrFileReader.readLine()).thenReturn(line2).thenReturn(null);
		ClearanceByDateTime clearanceByDateTimeForStore = createClearanceByDateTime(
				"20160125", "20170125", "MM", "0000003.00");

		ClearanceStoreSaleInfo clearanceStoreSaleInfo = createClearanceStoreSaleInfo(
				" 6456", "IE", "EUR", clearanceByDateTimeForStore);

		final ClearanceMMProduct expectedClearanceMMProduct = createClearanceMMProduct(
				productId, null, clearanceStoreSaleInfo);

		this.mmWriter.write(null);
		ClearanceMMProduct actualClearanceProduct = (ClearanceMMProduct) repositoryImpl
				.getGenericObject(PriceConstants.CLEARANCE_MM_PRODUCT_KEY_PREFIX
						+ productId, ClearanceMMProduct.class);;
		boolean isEqual = new RPMComparator().compare(actualClearanceProduct,
				expectedClearanceMMProduct);
		Assert.assertTrue(isEqual);
	}

}
