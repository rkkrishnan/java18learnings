package com.tesco.services.adapters.rpm.readers;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tesco.couchbase.AsyncCouchbaseWrapper;
import com.tesco.couchbase.CouchbaseWrapper;
import com.tesco.couchbase.testutils.AsyncCouchbaseWrapperStub;
import com.tesco.couchbase.testutils.BucketTool;
import com.tesco.couchbase.testutils.CouchbaseTestManager;
import com.tesco.couchbase.testutils.CouchbaseWrapperStub;
import com.tesco.promotion.core.*;
import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.exceptions.PromotionEventException;
import com.tesco.services.adapters.promotion.impl.MultiBuyPromotionHandler;
import com.tesco.services.adapters.promotion.PromotionEventHandler;
import com.tesco.services.adapters.promotion.impl.SimplePromotionHandler;
import com.tesco.services.adapters.promotion.impl.ThresholdPromotionHandler;
import com.tesco.services.adapters.rpm.readers.impl.PromotionMessageRouter;
import com.tesco.services.adapters.rpm.writers.impl.PromotionWriter;
import com.tesco.services.core.promotion.*;
import com.tesco.services.event.core.EventTemplate;
import com.tesco.services.event.exception.EventPublishException;
import com.tesco.services.exceptions.DataAccessException;
import com.tesco.services.exceptions.MessageRouterException;
import com.tesco.services.exceptions.ProductEncodeException;
import com.tesco.services.exceptions.PromoBusinessException;
import com.tesco.services.leadtime.core.LeadTimeUtility;
import com.tesco.services.repositories.RepositoryImpl;
import com.tesco.services.resources.TestConfiguration;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.ParseMessageUtil;
import com.tesco.services.utility.PriceConstants;
import com.tesco.services.utility.PriceUtility;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.joda.time.DateTime;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.tesco.services.utility.PriceConstants.*;
import static io.dropwizard.testing.FixtureHelpers.fixture;
import static org.fest.assertions.api.Assertions.assertThat;
import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by qu17 on 5/20/2015.
 */

@RunWith(MockitoJUnitRunner.class)
public class PromotionMessageRouterTest {
	private static Configuration testConfiguration;
	private CouchbaseTestManager couchbaseTestManager;
	private CouchbaseWrapper couchbaseWrapper;
	private AsyncCouchbaseWrapper asyncCouchbaseWrapper;
	private ObjectMapper mapper;
	private RepositoryImpl repositoryImpl;
	private PromotionWriter promotionWriter;

	private SimplePromotionHandler simplePromotionHandler;
	private ThresholdPromotionHandler thresholdPromotionHandler;
	private MultiBuyPromotionHandler multiBuyPromotionHandler;

	private PromotionEventHandler promotionEventHandler;

	@Mock
	private EventTemplate eventTemplate;

	private ArgumentCaptor<PrmPrcChgDesc> argument = ArgumentCaptor
			.forClass(PrmPrcChgDesc.class);

	@Before
	public void setUp() throws Exception {
		testConfiguration = TestConfiguration.load();

		if (testConfiguration.isDummyCouchbaseMode()) {
			Map<String, ImmutablePair<Long, String>> fakeBase = new HashMap<>();
			couchbaseTestManager = new CouchbaseTestManager(
					new CouchbaseWrapperStub(fakeBase),
					new AsyncCouchbaseWrapperStub(fakeBase),
					mock(BucketTool.class));
		} else {
			couchbaseTestManager = new CouchbaseTestManager(
					testConfiguration.getCouchbaseBucket(),
					testConfiguration.getCouchbaseUsername(),
					testConfiguration.getCouchbasePassword(),
					testConfiguration.getCouchbaseNodes(),
					testConfiguration.getCouchbaseAdminUsername(),
					testConfiguration.getCouchbaseAdminPassword());
		}

		couchbaseWrapper = couchbaseTestManager.getCouchbaseWrapper();
		asyncCouchbaseWrapper = couchbaseTestManager.getAsyncCouchbaseWrapper();
		mapper = new ObjectMapper();
		repositoryImpl = new RepositoryImpl(this.couchbaseWrapper,
				asyncCouchbaseWrapper, mapper);
		promotionWriter = new PromotionWriter(testConfiguration,
				repositoryImpl, mapper);

		simplePromotionHandler = new SimplePromotionHandler(repositoryImpl,
				promotionWriter);
		thresholdPromotionHandler = new ThresholdPromotionHandler(
				repositoryImpl, promotionWriter, testConfiguration);
		multiBuyPromotionHandler = new MultiBuyPromotionHandler(
				repositoryImpl, promotionWriter, testConfiguration);

		promotionEventHandler = Mockito.mock(PromotionEventHandler.class);

	}

	@Test
	public void shouldUnmarshallAndProcessSimplePromoCreMsg() throws Exception {

		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "  <ribMessage>\n"
				+ "    <family>PRMPRCCHG</family>\n"
				+ "    <type>PRMPRCCHGCRE</type>\n"
				+ "    <ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.04.29 07:26:36.903|2</ribmessageID>\n"
				+ "    <publishTime>2015-04-29 07:26:36.903 BST</publishTime>\n"
				+ "    <messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;13&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;13&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1559883&lt;/promo_id&gt;&lt;promo_name&gt;ROI Foyers&lt;/promo_name&gt;&lt;promo_description&gt;ROI Foyers&lt;/promo_description&gt;&lt;promo_comp_id&gt;167241&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;Fairy Non Bio Powder 4.22kg 65 wash:Now 15.00&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;39519142&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;2&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;2&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;Now 15.00&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;248458&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31742663&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;1435&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;3&lt;/subclass&gt;&lt;item&gt;071104000&lt;/item&gt;&lt;tsl_consumer_unit&gt;272249883&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;15&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;15&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;021232725&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;Fairy Non Bio Powder 4.22kg 65 wash:Now 15.00&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1559883&lt;/promo_id&gt;&lt;promo_name&gt;ROI Foyers&lt;/promo_name&gt;&lt;promo_description&gt;ROI Foyers&lt;/promo_description&gt;&lt;promo_comp_id&gt;167241&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;Fairy Non Bio Powder 4.22kg 65 wash:Now 15.00&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;39519144&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;2&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;2&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;Now 15.00&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;248458&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31742663&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;1435&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;3&lt;/subclass&gt;&lt;item&gt;071104000-001&lt;/item&gt;&lt;tsl_consumer_unit&gt;282048351&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;15&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;15&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;0&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;026310924&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;Fairy Non Bio Powder 4.22kg 65 wash:Now 15.00&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "    <customData>\n" + "    </customData>\n"
				+ "    <customFlag>F</customFlag>\n" + "  </ribMessage>\n"
				+ "</RibMessages>";
		String offerIdFromMsg = "31742663";
		String locType = "Z";
		String locRef = "13";

		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);

		promotionMessageRouter.route(data);
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));
	}

	@Test
	public void shouldUnmarshallAndProcessSimplePromoModMsg() throws Exception {

		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "  <ribMessage>\n"
				+ "    <family>PRMPRCCHG</family>\n"
				+ "    <type>PRMPRCCHGMOD</type>\n"
				+ "    <ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.04.29 07:26:36.903|2</ribmessageID>\n"
				+ "    <publishTime>2015-04-29 07:26:36.903 BST</publishTime>\n"
				+ "    <messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;13&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;13&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1559883&lt;/promo_id&gt;&lt;promo_name&gt;ROI Foyers&lt;/promo_name&gt;&lt;promo_description&gt;ROI Foyers&lt;/promo_description&gt;&lt;promo_comp_id&gt;167241&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;Fairy Non Bio Powder 4.22kg 65 wash:Now 15.00&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;39519142&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;2&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;2&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;Now 15.00&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;248458&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31742663&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;1435&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;3&lt;/subclass&gt;&lt;item&gt;071104000&lt;/item&gt;&lt;tsl_consumer_unit&gt;272249883&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;15&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;15&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;021232725&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;Fairy Non Bio Powder 4.22kg 65 wash:Now 15.00&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1559883&lt;/promo_id&gt;&lt;promo_name&gt;ROI Foyers&lt;/promo_name&gt;&lt;promo_description&gt;ROI Foyers&lt;/promo_description&gt;&lt;promo_comp_id&gt;167241&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;Fairy Non Bio Powder 4.22kg 65 wash:Now 15.00&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;39519144&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;2&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;2&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;Now 15.00&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;248458&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31742663&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;1435&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;3&lt;/subclass&gt;&lt;item&gt;071104000-001&lt;/item&gt;&lt;tsl_consumer_unit&gt;282048351&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;15&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;15&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;0&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;026310924&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;Fairy Non Bio Powder 4.22kg 65 wash:Now 15.00&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "    <customData>\n" + "    </customData>\n"
				+ "    <customFlag>F</customFlag>\n" + "  </ribMessage>\n"
				+ "</RibMessages>";
		String offerIdFromMsg = "31742663";
		String locType = "Z";
		String locRef = "13";
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(data);
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));
	}

	@Test
	public void shouldUnmarshallAndProcessSimplePromoCreMsgWithDiffOffers()
			throws Exception {

		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "  <ribMessage>\n"
				+ "    <family>PRMPRCCHG</family>\n"
				+ "    <type>PRMPRCCHGCRE</type>\n"
				+ "    <ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.04.29 07:26:36.903|2</ribmessageID>\n"
				+ "    <publishTime>2015-04-29 07:26:36.903 BST</publishTime>\n"
				+ "    <messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;13&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;13&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1559883&lt;/promo_id&gt;&lt;promo_name&gt;ROI Foyers&lt;/promo_name&gt;&lt;promo_description&gt;ROI Foyers&lt;/promo_description&gt;&lt;promo_comp_id&gt;167241&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;Fairy Non Bio Powder 4.22kg 65 wash:Now 15.00&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;39519142&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;2&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;2&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;Now 15.00&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;248458&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31742662&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;1435&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;3&lt;/subclass&gt;&lt;item&gt;071104000&lt;/item&gt;&lt;tsl_consumer_unit&gt;272249883&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;15&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;15&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;021232725&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;Fairy Non Bio Powder 4.22kg 65 wash:Now 15.00&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1559883&lt;/promo_id&gt;&lt;promo_name&gt;ROI Foyers&lt;/promo_name&gt;&lt;promo_description&gt;ROI Foyers&lt;/promo_description&gt;&lt;promo_comp_id&gt;167241&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;Fairy Non Bio Powder 4.22kg 65 wash:Now 15.00&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;39519144&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;2&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;2&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;Now 15.00&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;248458&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31742663&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;1435&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;3&lt;/subclass&gt;&lt;item&gt;071104000-001&lt;/item&gt;&lt;tsl_consumer_unit&gt;282048351&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;15&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;15&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;0&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;026310924&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;Fairy Non Bio Powder 4.22kg 65 wash:Now 15.00&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "    <customData>\n" + "    </customData>\n"
				+ "    <customFlag>F</customFlag>\n" + "  </ribMessage>\n"
				+ "</RibMessages>";
		String offerIdFromMsg1 = "31742662";
		String offerIdFromMsg2 = "31742663";
		String locType = "Z";
		String locRef = "13";
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(data);
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg1 + "_" + locType + locRef,PromotionEntity.class));
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg2 + "_" + locType + locRef,PromotionEntity.class));

	}

	@Test
	public void shouldUnmarshallAndProcessSimplePromoModMsgWithDiffOffers()
			throws Exception {

		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "  <ribMessage>\n"
				+ "    <family>PRMPRCCHG</family>\n"
				+ "    <type>PRMPRCCHGMOD</type>\n"
				+ "    <ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.04.29 07:26:36.903|2</ribmessageID>\n"
				+ "    <publishTime>2015-04-29 07:26:36.903 BST</publishTime>\n"
				+ "    <messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;13&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;13&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1559883&lt;/promo_id&gt;&lt;promo_name&gt;ROI Foyers&lt;/promo_name&gt;&lt;promo_description&gt;ROI Foyers&lt;/promo_description&gt;&lt;promo_comp_id&gt;167241&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;Fairy Non Bio Powder 4.22kg 65 wash:Now 15.00&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;39519142&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;2&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;2&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;Now 15.00&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;248458&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31742662&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;1435&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;3&lt;/subclass&gt;&lt;item&gt;071104000&lt;/item&gt;&lt;tsl_consumer_unit&gt;272249883&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;15&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;15&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;021232725&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;Fairy Non Bio Powder 4.22kg 65 wash:Now 15.00&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1559883&lt;/promo_id&gt;&lt;promo_name&gt;ROI Foyers&lt;/promo_name&gt;&lt;promo_description&gt;ROI Foyers&lt;/promo_description&gt;&lt;promo_comp_id&gt;167241&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;Fairy Non Bio Powder 4.22kg 65 wash:Now 15.00&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;39519144&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;2&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;2&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;Now 15.00&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;248458&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31742663&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;1435&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;3&lt;/subclass&gt;&lt;item&gt;071104000-001&lt;/item&gt;&lt;tsl_consumer_unit&gt;282048351&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;15&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;15&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;0&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;026310924&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;Fairy Non Bio Powder 4.22kg 65 wash:Now 15.00&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "    <customData>\n" + "    </customData>\n"
				+ "    <customFlag>F</customFlag>\n" + "  </ribMessage>\n"
				+ "</RibMessages>";
		String offerIdFromMsg1 = "31742662";
		String offerIdFromMsg2 = "31742663";
		String locType = "Z";
		String locRef = "13";
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(data);
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg1 + "_" + locType + locRef,PromotionEntity.class));
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg2 + "_" + locType + locRef,PromotionEntity.class));

	}

	@Test
	public void shouldCoverCodeForSimplePromoDelMsg() throws Exception {

		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "  <ribMessage>\n"
				+ "    <family>PRMPRCCHG</family>\n"
				+ "    <type>PRMPRCCHGDEL</type>\n"
				+ "    <ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.05.13 11:03:37.258|465</ribmessageID>\n"
				+ "    <publishTime>2015-05-13 11:03:37.258 BST</publishTime>\n"
				+ "    <messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "&lt;PrmPrcChgRef&gt;&lt;location&gt;6&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;6&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtlRef&gt;&lt;promo_comp_detail_id&gt;39583974&lt;/promo_comp_detail_id&gt;&lt;tsl_promo_comp_id&gt;171369&lt;/tsl_promo_comp_id&gt;&lt;tsl_state&gt;pcd.deleted&lt;/tsl_state&gt;&lt;PrmPrcChgSmpDtlRef&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;865&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;5&lt;/subclass&gt;&lt;item&gt;071238832&lt;/item&gt;&lt;tsl_consumer_unit&gt;272507359&lt;/tsl_consumer_unit&gt;&lt;/PrmPrcChgSmpDtlRef&gt;&lt;/PrmPrcChgDtlRef&gt;&lt;PrmPrcChgDtlRef&gt;&lt;promo_comp_detail_id&gt;39583978&lt;/promo_comp_detail_id&gt;&lt;tsl_promo_comp_id&gt;171370&lt;/tsl_promo_comp_id&gt;&lt;tsl_state&gt;pcd.deleted&lt;/tsl_state&gt;&lt;PrmPrcChgSmpDtlRef&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;865&lt;/dept&gt;&lt;class&gt;3&lt;/class&gt;&lt;subclass&gt;3&lt;/subclass&gt;&lt;item&gt;071216121&lt;/item&gt;&lt;tsl_consumer_unit&gt;272457089&lt;/tsl_consumer_unit&gt;&lt;/PrmPrcChgSmpDtlRef&gt;&lt;/PrmPrcChgDtlRef&gt;&lt;PrmPrcChgDtlRef&gt;&lt;promo_comp_detail_id&gt;39583982&lt;/promo_comp_detail_id&gt;&lt;tsl_promo_comp_id&gt;171371&lt;/tsl_promo_comp_id&gt;&lt;tsl_state&gt;pcd.deleted&lt;/tsl_state&gt;&lt;PrmPrcChgSmpDtlRef&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;865&lt;/dept&gt;&lt;class&gt;10&lt;/class&gt;&lt;subclass&gt;3&lt;/subclass&gt;&lt;item&gt;057879007&lt;/item&gt;&lt;tsl_consumer_unit&gt;255992661&lt;/tsl_consumer_unit&gt;&lt;/PrmPrcChgSmpDtlRef&gt;&lt;/PrmPrcChgDtlRef&gt;&lt;PrmPrcChgDtlRef&gt;&lt;promo_comp_detail_id&gt;39583986&lt;/promo_comp_detail_id&gt;&lt;tsl_promo_comp_id&gt;171372&lt;/tsl_promo_comp_id&gt;&lt;tsl_state&gt;pcd.deleted&lt;/tsl_state&gt;&lt;PrmPrcChgSmpDtlRef&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;865&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;5&lt;/subclass&gt;&lt;item&gt;073289566&lt;/item&gt;&lt;tsl_consumer_unit&gt;276618325&lt;/tsl_consumer_unit&gt;&lt;/PrmPrcChgSmpDtlRef&gt;&lt;/PrmPrcChgDtlRef&gt;&lt;PrmPrcChgDtlRef&gt;&lt;promo_comp_detail_id&gt;39583991&lt;/promo_comp_detail_id&gt;&lt;tsl_promo_comp_id&gt;171373&lt;/tsl_promo_comp_id&gt;&lt;tsl_state&gt;pcd.deleted&lt;/tsl_state&gt;&lt;PrmPrcChgSmpDtlRef&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;865&lt;/dept&gt;&lt;class&gt;5&lt;/class&gt;&lt;subclass&gt;2&lt;/subclass&gt;&lt;item&gt;075725635&lt;/item&gt;&lt;tsl_consumer_unit&gt;281735478&lt;/tsl_consumer_unit&gt;&lt;/PrmPrcChgSmpDtlRef&gt;&lt;/PrmPrcChgDtlRef&gt;&lt;PrmPrcChgDtlRef&gt;&lt;promo_comp_detail_id&gt;39583994&lt;/promo_comp_detail_id&gt;&lt;tsl_promo_comp_id&gt;171374&lt;/tsl_promo_comp_id&gt;&lt;tsl_state&gt;pcd.deleted&lt;/tsl_state&gt;&lt;PrmPrcChgSmpDtlRef&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;865&lt;/dept&gt;&lt;class&gt;3&lt;/class&gt;&lt;subclass&gt;3&lt;/subclass&gt;&lt;item&gt;050898433&lt;/item&gt;&lt;tsl_consumer_unit&gt;252561788&lt;/tsl_consumer_unit&gt;&lt;/PrmPrcChgSmpDtlRef&gt;&lt;/PrmPrcChgDtlRef&gt;&lt;PrmPrcChgDtlRef&gt;&lt;promo_comp_detail_id&gt;39583998&lt;/promo_comp_detail_id&gt;&lt;tsl_promo_comp_id&gt;171375&lt;/tsl_promo_comp_id&gt;&lt;tsl_state&gt;pcd.deleted&lt;/tsl_state&gt;&lt;PrmPrcChgSmpDtlRef&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;865&lt;/dept&gt;&lt;class&gt;3&lt;/class&gt;&lt;subclass&gt;3&lt;/subclass&gt;&lt;item&gt;059769970&lt;/item&gt;&lt;tsl_consumer_unit&gt;261092179&lt;/tsl_consumer_unit&gt;&lt;/PrmPrcChgSmpDtlRef&gt;&lt;/PrmPrcChgDtlRef&gt;&lt;PrmPrcChgDtlRef&gt;&lt;promo_comp_detail_id&gt;39584002&lt;/promo_comp_detail_id&gt;&lt;tsl_promo_comp_id&gt;171376&lt;/tsl_promo_comp_id&gt;&lt;tsl_state&gt;pcd.deleted&lt;/tsl_state&gt;&lt;PrmPrcChgSmpDtlRef&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;865&lt;/dept&gt;&lt;class&gt;3&lt;/class&gt;&lt;subclass&gt;3&lt;/subclass&gt;&lt;item&gt;065562646&lt;/item&gt;&lt;tsl_consumer_unit&gt;266246647&lt;/tsl_consumer_unit&gt;&lt;/PrmPrcChgSmpDtlRef&gt;&lt;/PrmPrcChgDtlRef&gt;&lt;PrmPrcChgDtlRef&gt;&lt;promo_comp_detail_id&gt;39584006&lt;/promo_comp_detail_id&gt;&lt;tsl_promo_comp_id&gt;171377&lt;/tsl_promo_comp_id&gt;&lt;tsl_state&gt;pcd.deleted&lt;/tsl_state&gt;&lt;PrmPrcChgSmpDtlRef&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;865&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;5&lt;/subclass&gt;&lt;item&gt;078643911&lt;/item&gt;&lt;tsl_consumer_unit&gt;287527151&lt;/tsl_consumer_unit&gt;&lt;/PrmPrcChgSmpDtlRef&gt;&lt;/PrmPrcChgDtlRef&gt;&lt;PrmPrcChgDtlRef&gt;&lt;promo_comp_detail_id&gt;39584015&lt;/promo_comp_detail_id&gt;&lt;tsl_promo_comp_id&gt;171379&lt;/tsl_promo_comp_id&gt;&lt;tsl_state&gt;pcd.deleted&lt;/tsl_state&gt;&lt;PrmPrcChgSmpDtlRef&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;865&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;5&lt;/subclass&gt;&lt;item&gt;074523478&lt;/item&gt;&lt;tsl_consumer_unit&gt;279315016&lt;/tsl_consumer_unit&gt;&lt;/PrmPrcChgSmpDtlRef&gt;&lt;/PrmPrcChgDtlRef&gt;&lt;PrmPrcChgDtlRef&gt;&lt;promo_comp_detail_id&gt;39584018&lt;/promo_comp_detail_id&gt;&lt;tsl_promo_comp_id&gt;171380&lt;/tsl_promo_comp_id&gt;&lt;tsl_state&gt;pcd.deleted&lt;/tsl_state&gt;&lt;PrmPrcChgSmpDtlRef&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;865&lt;/dept&gt;&lt;class&gt;3&lt;/class&gt;&lt;subclass&gt;3&lt;/subclass&gt;&lt;item&gt;057522228&lt;/item&gt;&lt;tsl_consumer_unit&gt;255126000&lt;/tsl_consumer_unit&gt;&lt;/PrmPrcChgSmpDtlRef&gt;&lt;/PrmPrcChgDtlRef&gt;&lt;PrmPrcChgDtlRef&gt;&lt;promo_comp_detail_id&gt;39584022&lt;/promo_comp_detail_id&gt;&lt;tsl_promo_comp_id&gt;171381&lt;/tsl_promo_comp_id&gt;&lt;tsl_state&gt;pcd.deleted&lt;/tsl_state&gt;&lt;PrmPrcChgSmpDtlRef&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;865&lt;/dept&gt;&lt;class&gt;3&lt;/class&gt;&lt;subclass&gt;3&lt;/subclass&gt;&lt;item&gt;078446246&lt;/item&gt;&lt;tsl_consumer_unit&gt;287126936&lt;/tsl_consumer_unit&gt;&lt;/PrmPrcChgSmpDtlRef&gt;&lt;/PrmPrcChgDtlRef&gt;&lt;PrmPrcChgDtlRef&gt;&lt;promo_comp_detail_id&gt;39584026&lt;/promo_comp_detail_id&gt;&lt;tsl_promo_comp_id&gt;171382&lt;/tsl_promo_comp_id&gt;&lt;tsl_state&gt;pcd.deleted&lt;/tsl_state&gt;&lt;PrmPrcChgSmpDtlRef&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;865&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;5&lt;/subclass&gt;&lt;item&gt;075544238&lt;/item&gt;&lt;tsl_consumer_unit&gt;281374864&lt;/tsl_consumer_unit&gt;&lt;/PrmPrcChgSmpDtlRef&gt;&lt;/PrmPrcChgDtlRef&gt;&lt;PrmPrcChgDtlRef&gt;&lt;promo_comp_detail_id&gt;39584030&lt;/promo_comp_detail_id&gt;&lt;tsl_promo_comp_id&gt;171383&lt;/tsl_promo_comp_id&gt;&lt;tsl_state&gt;pcd.deleted&lt;/tsl_state&gt;&lt;PrmPrcChgSmpDtlRef&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;865&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;5&lt;/subclass&gt;&lt;item&gt;075770966&lt;/item&gt;&lt;tsl_consumer_unit&gt;281821629&lt;/tsl_consumer_unit&gt;&lt;/PrmPrcChgSmpDtlRef&gt;&lt;/PrmPrcChgDtlRef&gt;&lt;PrmPrcChgDtlRef&gt;&lt;promo_comp_detail_id&gt;39584034&lt;/promo_comp_detail_id&gt;&lt;tsl_promo_comp_id&gt;171384&lt;/tsl_promo_comp_id&gt;&lt;tsl_state&gt;pcd.deleted&lt;/tsl_state&gt;&lt;PrmPrcChgSmpDtlRef&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;865&lt;/dept&gt;&lt;class&gt;3&lt;/class&gt;&lt;subclass&gt;3&lt;/subclass&gt;&lt;item&gt;070886872&lt;/item&gt;&lt;tsl_consumer_unit&gt;271781794&lt;/tsl_consumer_unit&gt;&lt;/PrmPrcChgSmpDtlRef&gt;&lt;/PrmPrcChgDtlRef&gt;&lt;PrmPrcChgDtlRef&gt;&lt;promo_comp_detail_id&gt;39584038&lt;/promo_comp_detail_id&gt;&lt;tsl_promo_comp_id&gt;171385&lt;/tsl_promo_comp_id&gt;&lt;tsl_state&gt;pcd.deleted&lt;/tsl_state&gt;&lt;PrmPrcChgSmpDtlRef&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;865&lt;/dept&gt;&lt;class&gt;5&lt;/class&gt;&lt;subclass&gt;2&lt;/subclass&gt;&lt;item&gt;070112032&lt;/item&gt;&lt;tsl_consumer_unit&gt;270407803&lt;/tsl_consumer_unit&gt;&lt;/PrmPrcChgSmpDtlRef&gt;&lt;/PrmPrcChgDtlRef&gt;&lt;PrmPrcChgDtlRef&gt;&lt;promo_comp_detail_id&gt;39584010&lt;/promo_comp_detail_id&gt;&lt;tsl_promo_comp_id&gt;171378&lt;/tsl_promo_comp_id&gt;&lt;tsl_state&gt;pcd.deleted&lt;/tsl_state&gt;&lt;PrmPrcChgSmpDtlRef&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;865&lt;/dept&gt;&lt;class&gt;3&lt;/class&gt;&lt;subclass&gt;3&lt;/subclass&gt;&lt;item&gt;075544371&lt;/item&gt;&lt;tsl_consumer_unit&gt;281375212&lt;/tsl_consumer_unit&gt;&lt;/PrmPrcChgSmpDtlRef&gt;&lt;/PrmPrcChgDtlRef&gt;&lt;/PrmPrcChgRef&gt;</messageData>\n"
				+ "    <customData>\n" + "    </customData>\n"
				+ "    <customFlag>F</customFlag>\n" + "  </ribMessage>\n"
				+ "</RibMessages>";
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(data);

	}

	@Test
	public void shouldReturnSimpleOfferTypeForDetail() {
		PrmPrcChgDtl prmPrcChgDtl = new PrmPrcChgDtl();
		PrmPrcChgSmp prmPrcChgSmp = new PrmPrcChgSmp();
		prmPrcChgDtl.setPrmPrcChgSmp(prmPrcChgSmp);
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		assertThat(promotionMessageRouter.getOfferTypeForDetail(prmPrcChgDtl))
				.isEqualTo(PriceConstants.PROMO_SIMPLE_OFFER_TYPE);

	}

	@Test
	public void shouldReturnThrOfferTypeForDetail() {
		PrmPrcChgDtl prmPrcChgDtl = new PrmPrcChgDtl();
		PrmPrcChgThr prmPrcChgThr = new PrmPrcChgThr();
		prmPrcChgDtl.setPrmPrcChgThr(prmPrcChgThr);
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		assertThat(promotionMessageRouter.getOfferTypeForDetail(prmPrcChgDtl))
				.isEqualTo(PriceConstants.PROMO_THRESHOLD_OFFER_TYPE);

	}

	@Test
	public void shouldReturnMBOfferTypeForDetail() {
		PrmPrcChgDtl prmPrcChgDtl = new PrmPrcChgDtl();
		TSLPrmPrcChgMultiBuy tslPrmPrcChgMultiBuy = new TSLPrmPrcChgMultiBuy();
		prmPrcChgDtl.setTSLPrmPrcChgMultiBuy(tslPrmPrcChgMultiBuy);
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		assertThat(promotionMessageRouter.getOfferTypeForDetail(prmPrcChgDtl))
				.isEqualTo(PriceConstants.PROMO_MB_OFFER_TYPE);

	}

	@Test
	public void shouldReturnSimpleOfferTypeForDeleteMsg() {
		PrmPrcChgDtlRef prmPrcChgDtlRef = new PrmPrcChgDtlRef();
		PrmPrcChgSmpDtlRef prmPrcChgSmpRef = new PrmPrcChgSmpDtlRef();
		prmPrcChgDtlRef.setPrmPrcChgSmpDtlRef(prmPrcChgSmpRef);
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		assertThat(
				promotionMessageRouter
						.getOfferTypeForDeleteMsg(prmPrcChgDtlRef)).isEqualTo(
				PriceConstants.PROMO_SIMPLE_OFFER_TYPE);

	}

	@Test
	public void shouldReturnThrOfferTypeForDeleteMsg() {
		PrmPrcChgDtlRef prmPrcChgDtlRef = new PrmPrcChgDtlRef();
		PrmPrcChgThrDtlRef prmPrcChgThrDtlRef = new PrmPrcChgThrDtlRef();
		prmPrcChgDtlRef.setPrmPrcChgThrDtlRef(prmPrcChgThrDtlRef);
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		assertThat(
				promotionMessageRouter
						.getOfferTypeForDeleteMsg(prmPrcChgDtlRef)).isEqualTo(
				PriceConstants.PROMO_THRESHOLD_OFFER_TYPE);

	}

	@Test
	public void shouldReturnMBOfferTypeForDeleteMsg() {
		PrmPrcChgDtlRef prmPrcChgDtlRef = new PrmPrcChgDtlRef();
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		assertThat(
				promotionMessageRouter
						.getOfferTypeForDeleteMsg(prmPrcChgDtlRef)).isEqualTo(
				PriceConstants.PROMO_MB_OFFER_TYPE);

	}

	@Test
	public void shouldReturnApprovedStateForPcdNewAndPcdReapprovedState() {
		String stateFromMsg = "pcd.new";
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		assertThat(promotionMessageRouter.getPromoStateForDetail(stateFromMsg))
				.isEqualTo(PriceConstants.PROMO_MSG_APPROVED_STATE);
	}

	@Test
	public void shouldReturnApprovedStateForPcdCancelledState() {
		String stateFromMsg = "pcd.cancelled";
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		assertThat(promotionMessageRouter.getPromoStateForDetail(stateFromMsg))
				.isEqualTo(PriceConstants.PROMO_MSG_APPROVED_STATE);
	}

	@Test
	public void shouldReturnDeletedStateForPcdDeleteState() {
		String stateFromMsg = "pcd.deleted";
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		assertThat(promotionMessageRouter.getPromoStateForDetail(stateFromMsg))
				.isEqualTo(PriceConstants.PROMO_MSG_DELETED_STATE);
	}

	@Test
	public void testSAXParseException() throws Exception {
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		ParseMessageUtil parseMessageUtilMock = mock(ParseMessageUtil.class);
		promotionMessageRouter.setParseMessageUtil(parseMessageUtilMock);
		when(
				parseMessageUtilMock.getNodeData(Matchers.any(String.class),
						Matchers.any(String.class))).thenThrow(
				SAXParseException.class);
		String data = "";
		try {
			promotionMessageRouter.route(data);
		} catch (MessageRouterException e) {
			Assert.assertTrue(e.getCause() instanceof SAXParseException);

		}
	}

	@Test
	public void testIOException() throws Exception {
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		ParseMessageUtil parseMessageUtilMock = mock(ParseMessageUtil.class);
		promotionMessageRouter.setParseMessageUtil(parseMessageUtilMock);
		when(
				parseMessageUtilMock.getNodeData(Matchers.any(String.class),
						Matchers.any(String.class))).thenThrow(
				IOException.class);
		String data = "";
		try {
			promotionMessageRouter.route(data);
		} catch (Exception e) {
			Assert.assertTrue(e.getCause() instanceof IOException);

		}
	}

	@Test
	public void testParserConfigurationException() throws Exception {
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		ParseMessageUtil parseMessageUtilMock = mock(ParseMessageUtil.class);
		promotionMessageRouter.setParseMessageUtil(parseMessageUtilMock);
		when(
				parseMessageUtilMock.getNodeData(Matchers.any(String.class),
						Matchers.any(String.class))).thenThrow(
				ParserConfigurationException.class);
		String data = "";
		try {
			promotionMessageRouter.route(data);
		} catch (Exception e) {
			Assert.assertTrue(e.getCause() instanceof ParserConfigurationException);

		}
	}

	@Test
	public void testJAXBException() throws Exception {
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		ParseMessageUtil parseMessageUtilMock = mock(ParseMessageUtil.class);
		promotionMessageRouter.setParseMessageUtil(parseMessageUtilMock);
		when(
				parseMessageUtilMock.getNodeData(Matchers.any(String.class),
						Matchers.any(String.class))).thenThrow(
				JAXBException.class);
		String data = "";
		try {
			promotionMessageRouter.route(data);
		} catch (Exception e) {
			Assert.assertTrue(e.getCause() instanceof JAXBException);

		}
	}

	@Test
	public void testXPathExpressionException() throws Exception {
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		ParseMessageUtil parseMessageUtilMock = mock(ParseMessageUtil.class);
		promotionMessageRouter.setParseMessageUtil(parseMessageUtilMock);
		when(
				parseMessageUtilMock.getNodeData(Matchers.any(String.class),
						Matchers.any(String.class))).thenThrow(
				XPathExpressionException.class);
		String data = "";
		try {
			promotionMessageRouter.route(data);
		} catch (Exception e) {
			Assert.assertTrue(e.getCause() instanceof XPathExpressionException);

		}
	}

	@Test
	public void testException() throws Exception {
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		ParseMessageUtil parseMessageUtilMock = mock(ParseMessageUtil.class);
		promotionMessageRouter.setParseMessageUtil(parseMessageUtilMock);
		when(
				parseMessageUtilMock.getNodeData(Matchers.any(String.class),
						Matchers.any(String.class))).thenThrow(Exception.class);
		String data = "";
		try {
			promotionMessageRouter.route(data);
		} catch (Exception e) {
			Assert.assertTrue(e.getCause() instanceof Exception);

		}
	}

	@Test
	public void shouldUnmarshallAndProcessThrPromoCreMsg() throws Exception {

		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "  <ribMessage>\n"
				+ "    <family>PRMPRCCHG</family>\n"
				+ "    <type>PRMPRCCHGCRE</type>\n"
				+ "    <ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.05.26 10:01:34.795|385</ribmessageID>\n"
				+ "    <publishTime>2015-05-26 10:01:34.795 BST</publishTime>\n"
				+ "    <messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1563254&lt;/promo_id&gt;&lt;promo_name&gt;25% off swimwear&lt;/promo_name&gt;&lt;promo_description&gt;25% off swimwear&lt;/promo_description&gt;&lt;promo_comp_id&gt;185515&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;25% off swimwear&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;39868714&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;5&lt;/month&gt;&lt;day&gt;28&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;5&lt;/month&gt;&lt;day&gt;31&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1966&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;25% off swimwear&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;248864&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31760505&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;871&lt;/dept&gt;&lt;class&gt;22&lt;/class&gt;&lt;subclass&gt;3&lt;/subclass&gt;&lt;item&gt;076233224&lt;/item&gt;&lt;tsl_consumer_unit&gt;282747606&lt;/tsl_consumer_unit&gt;&lt;threshold_id&gt;473283&lt;/threshold_id&gt;&lt;threshold_name&gt;25% off clothing &lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;P&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;026691386&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;25% off swimwear&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;1&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-0.25&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1563254&lt;/promo_id&gt;&lt;promo_name&gt;25% off swimwear&lt;/promo_name&gt;&lt;promo_description&gt;25% off swimwear&lt;/promo_description&gt;&lt;promo_comp_id&gt;185515&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;25% off swimwear&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;39868654&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;5&lt;/month&gt;&lt;day&gt;28&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;5&lt;/month&gt;&lt;day&gt;31&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1966&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;25% off swimwear&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;248864&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31760505&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;871&lt;/dept&gt;&lt;class&gt;22&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;item&gt;074723414&lt;/item&gt;&lt;tsl_consumer_unit&gt;279739234&lt;/tsl_consumer_unit&gt;&lt;threshold_id&gt;473283&lt;/threshold_id&gt;&lt;threshold_name&gt;25% off clothing &lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;P&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;025098704&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;25% off swimwear&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;1&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-0.25&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "    <customData>\n" + "    </customData>\n"
				+ "    <customFlag>F</customFlag>\n" + "  </ribMessage>\n"
				+ "</RibMessages>";
		String offerIdFromMsg = "31760505";
		String locType = "Z";
		String locRef = "5";
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(data);
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));
	}

	@Test
	public void shouldUnmarshallAndProcessThrPromoModMsg() throws Exception {

		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "  <ribMessage>\n"
				+ "    <family>PRMPRCCHG</family>\n"
				+ "    <type>PRMPRCCHGMOD</type>\n"
				+ "    <ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.05.26 10:01:34.795|385</ribmessageID>\n"
				+ "    <publishTime>2015-05-26 10:01:34.795 BST</publishTime>\n"
				+ "    <messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1563254&lt;/promo_id&gt;&lt;promo_name&gt;25% off swimwear&lt;/promo_name&gt;&lt;promo_description&gt;25% off swimwear&lt;/promo_description&gt;&lt;promo_comp_id&gt;185515&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;25% off swimwear&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;39868714&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;5&lt;/month&gt;&lt;day&gt;28&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;5&lt;/month&gt;&lt;day&gt;31&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1966&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;25% off swimwear&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;248864&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31760505&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;871&lt;/dept&gt;&lt;class&gt;22&lt;/class&gt;&lt;subclass&gt;3&lt;/subclass&gt;&lt;item&gt;076233224&lt;/item&gt;&lt;tsl_consumer_unit&gt;282747606&lt;/tsl_consumer_unit&gt;&lt;threshold_id&gt;473283&lt;/threshold_id&gt;&lt;threshold_name&gt;25% off clothing &lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;P&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;026691386&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;25% off swimwear&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;1&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-0.25&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1563254&lt;/promo_id&gt;&lt;promo_name&gt;25% off swimwear&lt;/promo_name&gt;&lt;promo_description&gt;25% off swimwear&lt;/promo_description&gt;&lt;promo_comp_id&gt;185515&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;25% off swimwear&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;39868654&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;5&lt;/month&gt;&lt;day&gt;28&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;5&lt;/month&gt;&lt;day&gt;31&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1966&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;25% off swimwear&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;248864&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31760505&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;871&lt;/dept&gt;&lt;class&gt;22&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;item&gt;074723414&lt;/item&gt;&lt;tsl_consumer_unit&gt;279739234&lt;/tsl_consumer_unit&gt;&lt;threshold_id&gt;473283&lt;/threshold_id&gt;&lt;threshold_name&gt;25% off clothing &lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;P&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;025098704&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;25% off swimwear&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;1&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-0.25&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "    <customData>\n" + "    </customData>\n"
				+ "    <customFlag>F</customFlag>\n" + "  </ribMessage>\n"
				+ "</RibMessages>";
		String offerIdFromMsg = "31760505";
		String locType = "Z";
		String locRef = "5";
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(data);
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));
	}

	@Test
	public void shouldUnmarshallAndProcessThrPromoCreMsgWithMultipleOffers()
			throws Exception {

		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "  <ribMessage>\n"
				+ "    <family>PRMPRCCHG</family>\n"
				+ "    <type>PRMPRCCHGCRE</type>\n"
				+ "    <ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.05.26 10:01:34.795|385</ribmessageID>\n"
				+ "    <publishTime>2015-05-26 10:01:34.795 BST</publishTime>\n"
				+ "    <messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1563254&lt;/promo_id&gt;&lt;promo_name&gt;25% off swimwear&lt;/promo_name&gt;&lt;promo_description&gt;25% off swimwear&lt;/promo_description&gt;&lt;promo_comp_id&gt;185515&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;25% off swimwear&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;39868714&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;5&lt;/month&gt;&lt;day&gt;28&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;5&lt;/month&gt;&lt;day&gt;31&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1966&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;25% off swimwear&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;248864&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31760504&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;871&lt;/dept&gt;&lt;class&gt;22&lt;/class&gt;&lt;subclass&gt;3&lt;/subclass&gt;&lt;item&gt;076233224&lt;/item&gt;&lt;tsl_consumer_unit&gt;282747606&lt;/tsl_consumer_unit&gt;&lt;threshold_id&gt;473283&lt;/threshold_id&gt;&lt;threshold_name&gt;25% off clothing &lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;P&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;026691386&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;25% off swimwear&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;1&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-0.25&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1563254&lt;/promo_id&gt;&lt;promo_name&gt;25% off swimwear&lt;/promo_name&gt;&lt;promo_description&gt;25% off swimwear&lt;/promo_description&gt;&lt;promo_comp_id&gt;185515&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;25% off swimwear&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;39868654&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;5&lt;/month&gt;&lt;day&gt;28&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;5&lt;/month&gt;&lt;day&gt;31&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1966&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;25% off swimwear&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;248864&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31760505&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;871&lt;/dept&gt;&lt;class&gt;22&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;item&gt;074723414&lt;/item&gt;&lt;tsl_consumer_unit&gt;279739234&lt;/tsl_consumer_unit&gt;&lt;threshold_id&gt;473283&lt;/threshold_id&gt;&lt;threshold_name&gt;25% off clothing &lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;P&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;025098704&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;25% off swimwear&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;1&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-0.25&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "    <customData>\n" + "    </customData>\n"
				+ "    <customFlag>F</customFlag>\n" + "  </ribMessage>\n"
				+ "</RibMessages>";
		String offerIdFromMsg1 = "31760504";
		String offerIdFromMsg2 = "31760505";
		String locType = "Z";
		String locRef = "5";
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(data);
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg1 + "_" + locType + locRef,PromotionEntity.class));
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg2 + "_" + locType + locRef,PromotionEntity.class));

	}

	@Test
	public void shouldUnmarshallAndProcessThrPromoDelMsgWholeDocumentShouldGetDeleted()
			throws Exception {
		String detailIdFromMsg = "39868714";

		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "  <ribMessage>\n"
				+ "    <family>PRMPRCCHG</family>\n"
				+ "    <type>PRMPRCCHGCRE</type>\n"
				+ "    <ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.05.26 10:01:34.795|385</ribmessageID>\n"
				+ "    <publishTime>2015-05-26 10:01:34.795 BST</publishTime>\n"
				+ "    <messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1563254&lt;/promo_id&gt;&lt;promo_name&gt;25% off swimwear&lt;/promo_name&gt;&lt;promo_description&gt;25% off swimwear&lt;/promo_description&gt;&lt;promo_comp_id&gt;185515&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;25% off swimwear&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;39868714&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;5&lt;/month&gt;&lt;day&gt;28&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;5&lt;/month&gt;&lt;day&gt;31&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1966&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;25% off swimwear&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;248864&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31760505&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;871&lt;/dept&gt;&lt;class&gt;22&lt;/class&gt;&lt;subclass&gt;3&lt;/subclass&gt;&lt;item&gt;076233224&lt;/item&gt;&lt;tsl_consumer_unit&gt;282747606&lt;/tsl_consumer_unit&gt;&lt;threshold_id&gt;473283&lt;/threshold_id&gt;&lt;threshold_name&gt;25% off clothing &lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;P&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;026691386&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;25% off swimwear&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;1&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-0.25&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1563254&lt;/promo_id&gt;&lt;promo_name&gt;25% off swimwear&lt;/promo_name&gt;&lt;promo_description&gt;25% off swimwear&lt;/promo_description&gt;&lt;promo_comp_id&gt;185515&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;25% off swimwear&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;39868654&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;5&lt;/month&gt;&lt;day&gt;28&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;5&lt;/month&gt;&lt;day&gt;31&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1966&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;25% off swimwear&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;248864&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31760505&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;871&lt;/dept&gt;&lt;class&gt;22&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;item&gt;074723414&lt;/item&gt;&lt;tsl_consumer_unit&gt;279739234&lt;/tsl_consumer_unit&gt;&lt;threshold_id&gt;473283&lt;/threshold_id&gt;&lt;threshold_name&gt;25% off clothing &lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;P&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;025098704&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;25% off swimwear&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;1&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-0.25&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "    <customData>\n" + "    </customData>\n"
				+ "    <customFlag>F</customFlag>\n" + "  </ribMessage>\n"
				+ "</RibMessages>";
		String offerIdFromMsg = "31760505";
		String locType = "Z";
		String locRef = "5";
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(data);
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMO_DETAIL_ID_KEY
						+ detailIdFromMsg,String.class));

		String delMsg = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "  <ribMessage>\n"
				+ "    <family>PRMPRCCHG</family>\n"
				+ "    <type>PRMPRCCHGDEL</type>\n"
				+ "    <ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.05.13 12:31:01.770|925</ribmessageID>\n"
				+ "    <publishTime>2015-05-13 12:31:01.770 BST</publishTime>\n"
				+ "    <messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "&lt;PrmPrcChgRef&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtlRef&gt;&lt;promo_comp_detail_id&gt;39868714&lt;/promo_comp_detail_id&gt;&lt;tsl_ext_promo_id&gt;1966&lt;/tsl_ext_promo_id&gt;&lt;tsl_promo_comp_id&gt;151956&lt;/tsl_promo_comp_id&gt;&lt;tsl_state&gt;pcd.deleted&lt;/tsl_state&gt;&lt;PrmPrcChgThrDtlRef&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;2331&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;4&lt;/subclass&gt;&lt;item&gt;076233224&lt;/item&gt;&lt;tsl_consumer_unit&gt;250629398&lt;/tsl_consumer_unit&gt;&lt;/PrmPrcChgThrDtlRef&gt;&lt;/PrmPrcChgDtlRef&gt;&lt;PrmPrcChgDtlRef&gt;&lt;promo_comp_detail_id&gt;39868654&lt;/promo_comp_detail_id&gt;&lt;tsl_ext_promo_id&gt;1966&lt;/tsl_ext_promo_id&gt;&lt;tsl_promo_comp_id&gt;151956&lt;/tsl_promo_comp_id&gt;&lt;tsl_state&gt;pcd.deleted&lt;/tsl_state&gt;&lt;PrmPrcChgThrDtlRef&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;2331&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;4&lt;/subclass&gt;&lt;item&gt;074723414&lt;/item&gt;&lt;tsl_consumer_unit&gt;250630418&lt;/tsl_consumer_unit&gt;&lt;/PrmPrcChgThrDtlRef&gt;&lt;/PrmPrcChgDtlRef&gt;&lt;/PrmPrcChgRef&gt;</messageData>\n"
				+ "    <customData>\n" + "    </customData>\n"
				+ "    <customFlag>F</customFlag>\n" + "  </ribMessage>\n"
				+ "</RibMessages>";
		promotionMessageRouter.route(delMsg);
		Assert.assertNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));
		Assert.assertNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMO_DETAIL_ID_KEY
						+ detailIdFromMsg,String.class));
	}

	@Test
	public void shouldUnmarshallAndProcessThrPromoDelMsgOnlyOneItemShouldGetDeleted()
			throws Exception {
		String detailIdFromMsg = "39868714";
		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "  <ribMessage>\n"
				+ "    <family>PRMPRCCHG</family>\n"
				+ "    <type>PRMPRCCHGCRE</type>\n"
				+ "    <ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.05.26 10:01:34.795|385</ribmessageID>\n"
				+ "    <publishTime>2015-05-26 10:01:34.795 BST</publishTime>\n"
				+ "    <messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1563254&lt;/promo_id&gt;&lt;promo_name&gt;25% off swimwear&lt;/promo_name&gt;&lt;promo_description&gt;25% off swimwear&lt;/promo_description&gt;&lt;promo_comp_id&gt;185515&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;25% off swimwear&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;39868714&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;5&lt;/month&gt;&lt;day&gt;28&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;5&lt;/month&gt;&lt;day&gt;31&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1966&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;25% off swimwear&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;248864&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31760505&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;871&lt;/dept&gt;&lt;class&gt;22&lt;/class&gt;&lt;subclass&gt;3&lt;/subclass&gt;&lt;item&gt;076233224&lt;/item&gt;&lt;tsl_consumer_unit&gt;282747606&lt;/tsl_consumer_unit&gt;&lt;threshold_id&gt;473283&lt;/threshold_id&gt;&lt;threshold_name&gt;25% off clothing &lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;P&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;026691386&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;25% off swimwear&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;1&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-0.25&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1563254&lt;/promo_id&gt;&lt;promo_name&gt;25% off swimwear&lt;/promo_name&gt;&lt;promo_description&gt;25% off swimwear&lt;/promo_description&gt;&lt;promo_comp_id&gt;185515&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;25% off swimwear&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;39868654&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;5&lt;/month&gt;&lt;day&gt;28&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;5&lt;/month&gt;&lt;day&gt;31&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1966&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;25% off swimwear&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;248864&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31760505&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;871&lt;/dept&gt;&lt;class&gt;22&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;item&gt;074723414&lt;/item&gt;&lt;tsl_consumer_unit&gt;279739234&lt;/tsl_consumer_unit&gt;&lt;threshold_id&gt;473283&lt;/threshold_id&gt;&lt;threshold_name&gt;25% off clothing &lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;P&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;025098704&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;25% off swimwear&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;1&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-0.25&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "    <customData>\n" + "    </customData>\n"
				+ "    <customFlag>F</customFlag>\n" + "  </ribMessage>\n"
				+ "</RibMessages>";
		String offerIdFromMsg = "31760505";
		String locType = "Z";
		String locRef = "5";
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(data);
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMO_DETAIL_ID_KEY
						+ detailIdFromMsg,String.class));
		String delMsg = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "  <ribMessage>\n"
				+ "    <family>PRMPRCCHG</family>\n"
				+ "    <type>PRMPRCCHGDEL</type>\n"
				+ "    <ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.05.13 12:31:01.770|925</ribmessageID>\n"
				+ "    <publishTime>2015-05-13 12:31:01.770 BST</publishTime>\n"
				+ "    <messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "&lt;PrmPrcChgRef&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtlRef&gt;&lt;promo_comp_detail_id&gt;39868714&lt;/promo_comp_detail_id&gt;&lt;tsl_ext_promo_id&gt;1966&lt;/tsl_ext_promo_id&gt;&lt;tsl_promo_comp_id&gt;151956&lt;/tsl_promo_comp_id&gt;&lt;tsl_state&gt;pcd.deleted&lt;/tsl_state&gt;&lt;PrmPrcChgThrDtlRef&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;2331&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;4&lt;/subclass&gt;&lt;item&gt;076233224&lt;/item&gt;&lt;tsl_consumer_unit&gt;250629398&lt;/tsl_consumer_unit&gt;&lt;/PrmPrcChgThrDtlRef&gt;&lt;/PrmPrcChgDtlRef&gt;&lt;/PrmPrcChgRef&gt;</messageData>\n"
				+ "    <customData>\n" + "    </customData>\n"
				+ "    <customFlag>F</customFlag>\n" + "  </ribMessage>\n"
				+ "</RibMessages>";
		promotionMessageRouter.route(delMsg);
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));
		Assert.assertNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMO_DETAIL_ID_KEY
						+ detailIdFromMsg,String.class));

	}

	@Test
	public void shouldUnmarshallAndProcessThrStepPromoCreMsg() throws Exception {

		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "  <ribMessage>\n"
				+ "    <family>PRMPRCCHG</family>\n"
				+ "    <type>PRMPRCCHGCRE</type>\n"
				+ "    <ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.05.29 15:21:41.933|1585</ribmessageID>\n"
				+ "    <publishTime>2015-05-29 15:21:41.933 BST</publishTime>\n"
				+ "    <messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;6&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;6&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1560414&lt;/promo_id&gt;&lt;promo_name&gt;UK - 2 fr &#163;7 /3 fr &#163;10&lt;/promo_name&gt;&lt;promo_description&gt;N4 @Meat/Poultry/Fish/Beer 2 fr &#163;7 /3 fr &#163;10&lt;/promo_description&gt;&lt;promo_comp_id&gt;160919&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;N4 @Meat/Poultry/Fish/Beer 2 fr &#163;7 /3 fr &#163;10&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;39983256&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;10&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;30&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1672&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;MEAT/BEER 2fr7/3fr10&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;87062&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31736469&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;657&lt;/dept&gt;&lt;class&gt;4&lt;/class&gt;&lt;subclass&gt;8&lt;/subclass&gt;&lt;item&gt;063753717&lt;/item&gt;&lt;tsl_consumer_unit&gt;264388846&lt;/tsl_consumer_unit&gt;&lt;threshold_id&gt;187687&lt;/threshold_id&gt;&lt;threshold_name&gt;Meat 2 for &#163;7 / 3 for &#163;10&lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;A&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;022823071&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;N4 @Meat/Poultry/Fish/Beer 2 fr &#163;7 /3 fr &#163;10&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;A0000336&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_pos_description1&gt;SELECTED|MEAT, FISH,|POULTRY OR SAN MIGUEL|4X330ML&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description3&gt;10&lt;/tsl_pos_description3&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;2&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-1&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;3&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-2&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1560414&lt;/promo_id&gt;&lt;promo_name&gt;UK - 2 fr &#163;7 /3 fr &#163;10&lt;/promo_name&gt;&lt;promo_description&gt;N4 @Meat/Poultry/Fish/Beer 2 fr &#163;7 /3 fr &#163;10&lt;/promo_description&gt;&lt;promo_comp_id&gt;160919&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;N4 @Meat/Poultry/Fish/Beer 2 fr &#163;7 /3 fr &#163;10&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;39960767&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;10&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;30&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1672&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;MEAT/BEER 2fr7/3fr10&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;87062&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31736469&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;653&lt;/dept&gt;&lt;class&gt;15&lt;/class&gt;&lt;subclass&gt;3&lt;/subclass&gt;&lt;item&gt;067927322-001&lt;/item&gt;&lt;tsl_consumer_unit&gt;274446197&lt;/tsl_consumer_unit&gt;&lt;threshold_id&gt;187687&lt;/threshold_id&gt;&lt;threshold_name&gt;Meat 2 for &#163;7 / 3 for &#163;10&lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;A&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;0&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;022410283&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;N4 @Meat/Poultry/Fish/Beer 2 fr &#163;7 /3 fr &#163;10&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;A0000336&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_pos_description1&gt;SELECTED|MEAT, FISH,|POULTRY OR SAN MIGUEL|4X330ML&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description3&gt;10&lt;/tsl_pos_description3&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;2&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-1&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;3&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-2&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1560414&lt;/promo_id&gt;&lt;promo_name&gt;UK - 2 fr &#163;7 /3 fr &#163;10&lt;/promo_name&gt;&lt;promo_description&gt;N4 @Meat/Poultry/Fish/Beer 2 fr &#163;7 /3 fr &#163;10&lt;/promo_description&gt;&lt;promo_comp_id&gt;160919&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;N4 @Meat/Poultry/Fish/Beer 2 fr &#163;7 /3 fr &#163;10&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;39960770&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;10&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;30&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1672&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;MEAT/BEER 2fr7/3fr10&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;87062&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31736469&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;653&lt;/dept&gt;&lt;class&gt;15&lt;/class&gt;&lt;subclass&gt;3&lt;/subclass&gt;&lt;item&gt;067927322&lt;/item&gt;&lt;tsl_consumer_unit&gt;268674505&lt;/tsl_consumer_unit&gt;&lt;threshold_id&gt;187687&lt;/threshold_id&gt;&lt;threshold_name&gt;Meat 2 for &#163;7 / 3 for &#163;10&lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;A&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;019916000&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;N4 @Meat/Poultry/Fish/Beer 2 fr &#163;7 /3 fr &#163;10&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;A0000336&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_pos_description1&gt;SELECTED|MEAT, FISH,|POULTRY OR SAN MIGUEL|4X330ML&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description3&gt;10&lt;/tsl_pos_description3&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;2&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-1&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;3&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-2&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1560414&lt;/promo_id&gt;&lt;promo_name&gt;UK - 2 fr &#163;7 /3 fr &#163;10&lt;/promo_name&gt;&lt;promo_description&gt;N4 @Meat/Poultry/Fish/Beer 2 fr &#163;7 /3 fr &#163;10&lt;/promo_description&gt;&lt;promo_comp_id&gt;160919&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;N4 @Meat/Poultry/Fish/Beer 2 fr &#163;7 /3 fr &#163;10&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;39983238&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;10&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;30&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1672&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;MEAT/BEER 2fr7/3fr10&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;87062&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31736469&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;657&lt;/dept&gt;&lt;class&gt;4&lt;/class&gt;&lt;subclass&gt;8&lt;/subclass&gt;&lt;item&gt;066504732&lt;/item&gt;&lt;tsl_consumer_unit&gt;267213063&lt;/tsl_consumer_unit&gt;&lt;threshold_id&gt;187687&lt;/threshold_id&gt;&lt;threshold_name&gt;Meat 2 for &#163;7 / 3 for &#163;10&lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;A&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;022823007&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;N4 @Meat/Poultry/Fish/Beer 2 fr &#163;7 /3 fr &#163;10&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;A0000336&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_pos_description1&gt;SELECTED|MEAT, FISH,|POULTRY OR SAN MIGUEL|4X330ML&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description3&gt;10&lt;/tsl_pos_description3&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;2&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-1&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;3&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-2&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1560414&lt;/promo_id&gt;&lt;promo_name&gt;UK - 2 fr &#163;7 /3 fr &#163;10&lt;/promo_name&gt;&lt;promo_description&gt;N4 @Meat/Poultry/Fish/Beer 2 fr &#163;7 /3 fr &#163;10&lt;/promo_description&gt;&lt;promo_comp_id&gt;160919&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;N4 @Meat/Poultry/Fish/Beer 2 fr &#163;7 /3 fr &#163;10&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;39983241&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;10&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;30&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1672&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;MEAT/BEER 2fr7/3fr10&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;87062&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31736469&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;657&lt;/dept&gt;&lt;class&gt;4&lt;/class&gt;&lt;subclass&gt;3&lt;/subclass&gt;&lt;item&gt;075872828&lt;/item&gt;&lt;tsl_consumer_unit&gt;282060928&lt;/tsl_consumer_unit&gt;&lt;threshold_id&gt;187687&lt;/threshold_id&gt;&lt;threshold_name&gt;Meat 2 for &#163;7 / 3 for &#163;10&lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;A&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;026312560&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;N4 @Meat/Poultry/Fish/Beer 2 fr &#163;7 /3 fr &#163;10&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;A0000336&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_pos_description1&gt;SELECTED|MEAT, FISH,|POULTRY OR SAN MIGUEL|4X330ML&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description3&gt;10&lt;/tsl_pos_description3&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;2&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-1&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;3&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-2&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1560414&lt;/promo_id&gt;&lt;promo_name&gt;UK - 2 fr &#163;7 /3 fr &#163;10&lt;/promo_name&gt;&lt;promo_description&gt;N4 @Meat/Poultry/Fish/Beer 2 fr &#163;7 /3 fr &#163;10&lt;/promo_description&gt;&lt;promo_comp_id&gt;160919&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;N4 @Meat/Poultry/Fish/Beer 2 fr &#163;7 /3 fr &#163;10&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;39983250&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;10&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;30&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1672&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;MEAT/BEER 2fr7/3fr10&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;87062&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31736469&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;657&lt;/dept&gt;&lt;class&gt;4&lt;/class&gt;&lt;subclass&gt;8&lt;/subclass&gt;&lt;item&gt;063753717-001&lt;/item&gt;&lt;tsl_consumer_unit&gt;281693371&lt;/tsl_consumer_unit&gt;&lt;threshold_id&gt;187687&lt;/threshold_id&gt;&lt;threshold_name&gt;Meat 2 for &#163;7 / 3 for &#163;10&lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;A&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;0&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;026108860&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;N4 @Meat/Poultry/Fish/Beer 2 fr &#163;7 /3 fr &#163;10&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;A0000336&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_pos_description1&gt;SELECTED|MEAT, FISH,|POULTRY OR SAN MIGUEL|4X330ML&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description3&gt;10&lt;/tsl_pos_description3&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;2&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-1&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;3&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-2&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1560414&lt;/promo_id&gt;&lt;promo_name&gt;UK - 2 fr &#163;7 /3 fr &#163;10&lt;/promo_name&gt;&lt;promo_description&gt;N4 @Meat/Poultry/Fish/Beer 2 fr &#163;7 /3 fr &#163;10&lt;/promo_description&gt;&lt;promo_comp_id&gt;160919&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;N4 @Meat/Poultry/Fish/Beer 2 fr &#163;7 /3 fr &#163;10&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;39983259&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;10&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;30&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1672&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;MEAT/BEER 2fr7/3fr10&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;87062&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31736469&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;657&lt;/dept&gt;&lt;class&gt;4&lt;/class&gt;&lt;subclass&gt;8&lt;/subclass&gt;&lt;item&gt;073529940-001&lt;/item&gt;&lt;tsl_consumer_unit&gt;281693238&lt;/tsl_consumer_unit&gt;&lt;threshold_id&gt;187687&lt;/threshold_id&gt;&lt;threshold_name&gt;Meat 2 for &#163;7 / 3 for &#163;10&lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;A&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;0&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;026108744&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;N4 @Meat/Poultry/Fish/Beer 2 fr &#163;7 /3 fr &#163;10&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;A0000336&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_pos_description1&gt;SELECTED|MEAT, FISH,|POULTRY OR SAN MIGUEL|4X330ML&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description3&gt;10&lt;/tsl_pos_description3&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;2&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-1&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;3&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-2&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1560414&lt;/promo_id&gt;&lt;promo_name&gt;UK - 2 fr &#163;7 /3 fr &#163;10&lt;/promo_name&gt;&lt;promo_description&gt;N4 @Meat/Poultry/Fish/Beer 2 fr &#163;7 /3 fr &#163;10&lt;/promo_description&gt;&lt;promo_comp_id&gt;160919&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;N4 @Meat/Poultry/Fish/Beer 2 fr &#163;7 /3 fr &#163;10&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;39983253&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;10&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;30&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1672&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;MEAT/BEER 2fr7/3fr10&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;87062&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31736469&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;657&lt;/dept&gt;&lt;class&gt;4&lt;/class&gt;&lt;subclass&gt;8&lt;/subclass&gt;&lt;item&gt;066504732-001&lt;/item&gt;&lt;tsl_consumer_unit&gt;281693702&lt;/tsl_consumer_unit&gt;&lt;threshold_id&gt;187687&lt;/threshold_id&gt;&lt;threshold_name&gt;Meat 2 for &#163;7 / 3 for &#163;10&lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;A&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;0&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;026109035&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;N4 @Meat/Poultry/Fish/Beer 2 fr &#163;7 /3 fr &#163;10&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;A0000336&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_pos_description1&gt;SELECTED|MEAT, FISH,|POULTRY OR SAN MIGUEL|4X330ML&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description3&gt;10&lt;/tsl_pos_description3&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;2&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-1&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;3&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-2&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1560414&lt;/promo_id&gt;&lt;promo_name&gt;UK - 2 fr &#163;7 /3 fr &#163;10&lt;/promo_name&gt;&lt;promo_description&gt;N4 @Meat/Poultry/Fish/Beer 2 fr &#163;7 /3 fr &#163;10&lt;/promo_description&gt;&lt;promo_comp_id&gt;160919&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;N4 @Meat/Poultry/Fish/Beer 2 fr &#163;7 /3 fr &#163;10&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;39983244&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;10&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;30&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1672&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;MEAT/BEER 2fr7/3fr10&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;87062&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31736469&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;657&lt;/dept&gt;&lt;class&gt;4&lt;/class&gt;&lt;subclass&gt;8&lt;/subclass&gt;&lt;item&gt;077256841&lt;/item&gt;&lt;tsl_consumer_unit&gt;284831797&lt;/tsl_consumer_unit&gt;&lt;threshold_id&gt;187687&lt;/threshold_id&gt;&lt;threshold_name&gt;Meat 2 for &#163;7 / 3 for &#163;10&lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;A&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;027775804&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;N4 @Meat/Poultry/Fish/Beer 2 fr &#163;7 /3 fr &#163;10&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;A0000336&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_pos_description1&gt;SELECTED|MEAT, FISH,|POULTRY OR SAN MIGUEL|4X330ML&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description3&gt;10&lt;/tsl_pos_description3&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;2&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-1&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;3&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-2&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1560414&lt;/promo_id&gt;&lt;promo_name&gt;UK - 2 fr &#163;7 /3 fr &#163;10&lt;/promo_name&gt;&lt;promo_description&gt;N4 @Meat/Poultry/Fish/Beer 2 fr &#163;7 /3 fr &#163;10&lt;/promo_description&gt;&lt;promo_comp_id&gt;160919&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;N4 @Meat/Poultry/Fish/Beer 2 fr &#163;7 /3 fr &#163;10&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;39983247&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;10&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;30&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1672&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;MEAT/BEER 2fr7/3fr10&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;87062&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31736469&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;657&lt;/dept&gt;&lt;class&gt;4&lt;/class&gt;&lt;subclass&gt;8&lt;/subclass&gt;&lt;item&gt;073529940&lt;/item&gt;&lt;tsl_consumer_unit&gt;277132834&lt;/tsl_consumer_unit&gt;&lt;threshold_id&gt;187687&lt;/threshold_id&gt;&lt;threshold_name&gt;Meat 2 for &#163;7 / 3 for &#163;10&lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;A&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;023841462&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;N4 @Meat/Poultry/Fish/Beer 2 fr &#163;7 /3 fr &#163;10&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;A0000336&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_pos_description1&gt;SELECTED|MEAT, FISH,|POULTRY OR SAN MIGUEL|4X330ML&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description3&gt;10&lt;/tsl_pos_description3&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;2&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-1&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;3&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-2&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "    <customData>\n" + "    </customData>\n"
				+ "    <customFlag>F</customFlag>\n" + "  </ribMessage>\n"
				+ "</RibMessages>";
		String offerIdFromMsg = "31736469";
		String locType = "Z";
		String locRef = "6";
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(data);
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));
	}

	@Test
	public void shouldUnmarshallAndProcessThrPromoDelMsgWhenNoPromoDisplayLookUpFound()
			throws Exception {

		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);

		String delMsg = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "  <ribMessage>\n"
				+ "    <family>PRMPRCCHG</family>\n"
				+ "    <type>PRMPRCCHGDEL</type>\n"
				+ "    <ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.05.13 12:31:01.770|925</ribmessageID>\n"
				+ "    <publishTime>2015-05-13 12:31:01.770 BST</publishTime>\n"
				+ "    <messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "&lt;PrmPrcChgRef&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtlRef&gt;&lt;promo_comp_detail_id&gt;39868714&lt;/promo_comp_detail_id&gt;&lt;tsl_ext_promo_id&gt;1966&lt;/tsl_ext_promo_id&gt;&lt;tsl_promo_comp_id&gt;151956&lt;/tsl_promo_comp_id&gt;&lt;tsl_state&gt;pcd.deleted&lt;/tsl_state&gt;&lt;PrmPrcChgThrDtlRef&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;2331&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;4&lt;/subclass&gt;&lt;item&gt;076233224&lt;/item&gt;&lt;tsl_consumer_unit&gt;250629398&lt;/tsl_consumer_unit&gt;&lt;/PrmPrcChgThrDtlRef&gt;&lt;/PrmPrcChgDtlRef&gt;&lt;/PrmPrcChgRef&gt;</messageData>\n"
				+ "    <customData>\n" + "    </customData>\n"
				+ "    <customFlag>F</customFlag>\n" + "  </ribMessage>\n"
				+ "</RibMessages>";
		promotionMessageRouter.route(delMsg);

	}

	@Test
	public void shouldUnmarshallAndProcessThrPromoDelMsgWhenNoPromotionDocumentPresent()
			throws Exception {

		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "  <ribMessage>\n"
				+ "    <family>PRMPRCCHG</family>\n"
				+ "    <type>PRMPRCCHGCRE</type>\n"
				+ "    <ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.05.26 10:01:34.795|385</ribmessageID>\n"
				+ "    <publishTime>2015-05-26 10:01:34.795 BST</publishTime>\n"
				+ "    <messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1563254&lt;/promo_id&gt;&lt;promo_name&gt;25% off swimwear&lt;/promo_name&gt;&lt;promo_description&gt;25% off swimwear&lt;/promo_description&gt;&lt;promo_comp_id&gt;185515&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;25% off swimwear&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;39868714&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;5&lt;/month&gt;&lt;day&gt;28&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;5&lt;/month&gt;&lt;day&gt;31&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1966&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;25% off swimwear&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;248864&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31760505&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;871&lt;/dept&gt;&lt;class&gt;22&lt;/class&gt;&lt;subclass&gt;3&lt;/subclass&gt;&lt;item&gt;076233224&lt;/item&gt;&lt;tsl_consumer_unit&gt;282747606&lt;/tsl_consumer_unit&gt;&lt;threshold_id&gt;473283&lt;/threshold_id&gt;&lt;threshold_name&gt;25% off clothing &lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;P&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;026691386&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;25% off swimwear&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;1&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-0.25&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1563254&lt;/promo_id&gt;&lt;promo_name&gt;25% off swimwear&lt;/promo_name&gt;&lt;promo_description&gt;25% off swimwear&lt;/promo_description&gt;&lt;promo_comp_id&gt;185515&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;25% off swimwear&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;39868654&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;5&lt;/month&gt;&lt;day&gt;28&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;5&lt;/month&gt;&lt;day&gt;31&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1966&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;25% off swimwear&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;248864&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31760505&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;871&lt;/dept&gt;&lt;class&gt;22&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;item&gt;074723414&lt;/item&gt;&lt;tsl_consumer_unit&gt;279739234&lt;/tsl_consumer_unit&gt;&lt;threshold_id&gt;473283&lt;/threshold_id&gt;&lt;threshold_name&gt;25% off clothing &lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;P&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;025098704&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;25% off swimwear&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;1&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-0.25&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "    <customData>\n" + "    </customData>\n"
				+ "    <customFlag>F</customFlag>\n" + "  </ribMessage>\n"
				+ "</RibMessages>";
		String offerIdFromMsg = "31760505";
		String locType = "Z";
		String locRef = "5";
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(data);
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));
		repositoryImpl.deleteProduct(PriceConstants.PROMOTION_DOC_KEY_PREFIX
				+ offerIdFromMsg + "_" + locType + locRef);
		String delMsg = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "  <ribMessage>\n"
				+ "    <family>PRMPRCCHG</family>\n"
				+ "    <type>PRMPRCCHGDEL</type>\n"
				+ "    <ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.05.13 12:31:01.770|925</ribmessageID>\n"
				+ "    <publishTime>2015-05-13 12:31:01.770 BST</publishTime>\n"
				+ "    <messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "&lt;PrmPrcChgRef&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtlRef&gt;&lt;promo_comp_detail_id&gt;39868714&lt;/promo_comp_detail_id&gt;&lt;tsl_ext_promo_id&gt;1966&lt;/tsl_ext_promo_id&gt;&lt;tsl_promo_comp_id&gt;151956&lt;/tsl_promo_comp_id&gt;&lt;tsl_state&gt;pcd.deleted&lt;/tsl_state&gt;&lt;PrmPrcChgThrDtlRef&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;2331&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;4&lt;/subclass&gt;&lt;item&gt;076233224&lt;/item&gt;&lt;tsl_consumer_unit&gt;250629398&lt;/tsl_consumer_unit&gt;&lt;/PrmPrcChgThrDtlRef&gt;&lt;/PrmPrcChgDtlRef&gt;&lt;/PrmPrcChgRef&gt;</messageData>\n"
				+ "    <customData>\n" + "    </customData>\n"
				+ "    <customFlag>F</customFlag>\n" + "  </ribMessage>\n"
				+ "</RibMessages>";
		promotionMessageRouter.route(delMsg);

	}

	@Test
	public void shouldUnmarshallAndProcessThrPromoDelMsgWhenItemFromMsgNotFoundInPromoDocument()
			throws Exception {

		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "  <ribMessage>\n"
				+ "    <family>PRMPRCCHG</family>\n"
				+ "    <type>PRMPRCCHGCRE</type>\n"
				+ "    <ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.05.26 10:01:34.795|385</ribmessageID>\n"
				+ "    <publishTime>2015-05-26 10:01:34.795 BST</publishTime>\n"
				+ "    <messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1563254&lt;/promo_id&gt;&lt;promo_name&gt;25% off swimwear&lt;/promo_name&gt;&lt;promo_description&gt;25% off swimwear&lt;/promo_description&gt;&lt;promo_comp_id&gt;185515&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;25% off swimwear&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;39868714&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;5&lt;/month&gt;&lt;day&gt;28&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;5&lt;/month&gt;&lt;day&gt;31&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1966&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;25% off swimwear&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;248864&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31760505&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;871&lt;/dept&gt;&lt;class&gt;22&lt;/class&gt;&lt;subclass&gt;3&lt;/subclass&gt;&lt;item&gt;076233224&lt;/item&gt;&lt;tsl_consumer_unit&gt;282747606&lt;/tsl_consumer_unit&gt;&lt;threshold_id&gt;473283&lt;/threshold_id&gt;&lt;threshold_name&gt;25% off clothing &lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;P&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;026691386&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;25% off swimwear&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;1&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-0.25&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1563254&lt;/promo_id&gt;&lt;promo_name&gt;25% off swimwear&lt;/promo_name&gt;&lt;promo_description&gt;25% off swimwear&lt;/promo_description&gt;&lt;promo_comp_id&gt;185515&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;25% off swimwear&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;39868654&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;5&lt;/month&gt;&lt;day&gt;28&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;5&lt;/month&gt;&lt;day&gt;31&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1966&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;25% off swimwear&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;248864&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31760505&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;871&lt;/dept&gt;&lt;class&gt;22&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;item&gt;074723414&lt;/item&gt;&lt;tsl_consumer_unit&gt;279739234&lt;/tsl_consumer_unit&gt;&lt;threshold_id&gt;473283&lt;/threshold_id&gt;&lt;threshold_name&gt;25% off clothing &lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;P&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;025098704&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;25% off swimwear&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;1&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-0.25&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "    <customData>\n" + "    </customData>\n"
				+ "    <customFlag>F</customFlag>\n" + "  </ribMessage>\n"
				+ "</RibMessages>";
		String offerIdFromMsg = "31760505";
		String locType = "Z";
		String locRef = "5";
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(data);
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));
		String delMsg = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "  <ribMessage>\n"
				+ "    <family>PRMPRCCHG</family>\n"
				+ "    <type>PRMPRCCHGDEL</type>\n"
				+ "    <ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.05.13 12:31:01.770|925</ribmessageID>\n"
				+ "    <publishTime>2015-05-13 12:31:01.770 BST</publishTime>\n"
				+ "    <messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "&lt;PrmPrcChgRef&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtlRef&gt;&lt;promo_comp_detail_id&gt;39868714&lt;/promo_comp_detail_id&gt;&lt;tsl_ext_promo_id&gt;1966&lt;/tsl_ext_promo_id&gt;&lt;tsl_promo_comp_id&gt;151956&lt;/tsl_promo_comp_id&gt;&lt;tsl_state&gt;pcd.deleted&lt;/tsl_state&gt;&lt;PrmPrcChgThrDtlRef&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;2331&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;4&lt;/subclass&gt;&lt;item&gt;076232222&lt;/item&gt;&lt;tsl_consumer_unit&gt;250629398&lt;/tsl_consumer_unit&gt;&lt;/PrmPrcChgThrDtlRef&gt;&lt;/PrmPrcChgDtlRef&gt;&lt;/PrmPrcChgRef&gt;</messageData>\n"
				+ "    <customData>\n" + "    </customData>\n"
				+ "    <customFlag>F</customFlag>\n" + "  </ribMessage>\n"
				+ "</RibMessages>";
		promotionMessageRouter.route(delMsg);
	}

	@Test
	public void shouldUnmarshallAndProcessThrPromoDelMsgWhenMasterDocNotFound()
			throws Exception {
		String detailIdFromMsg = "39868714";
		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "  <ribMessage>\n"
				+ "    <family>PRMPRCCHG</family>\n"
				+ "    <type>PRMPRCCHGCRE</type>\n"
				+ "    <ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.05.26 10:01:34.795|385</ribmessageID>\n"
				+ "    <publishTime>2015-05-26 10:01:34.795 BST</publishTime>\n"
				+ "    <messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1563254&lt;/promo_id&gt;&lt;promo_name&gt;25% off swimwear&lt;/promo_name&gt;&lt;promo_description&gt;25% off swimwear&lt;/promo_description&gt;&lt;promo_comp_id&gt;185515&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;25% off swimwear&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;39868714&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;5&lt;/month&gt;&lt;day&gt;28&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;5&lt;/month&gt;&lt;day&gt;31&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1966&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;25% off swimwear&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;248864&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31760505&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;871&lt;/dept&gt;&lt;class&gt;22&lt;/class&gt;&lt;subclass&gt;3&lt;/subclass&gt;&lt;item&gt;076233224&lt;/item&gt;&lt;tsl_consumer_unit&gt;282747606&lt;/tsl_consumer_unit&gt;&lt;threshold_id&gt;473283&lt;/threshold_id&gt;&lt;threshold_name&gt;25% off clothing &lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;P&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;026691386&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;25% off swimwear&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;1&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-0.25&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1563254&lt;/promo_id&gt;&lt;promo_name&gt;25% off swimwear&lt;/promo_name&gt;&lt;promo_description&gt;25% off swimwear&lt;/promo_description&gt;&lt;promo_comp_id&gt;185515&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;25% off swimwear&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;39868654&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;5&lt;/month&gt;&lt;day&gt;28&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;5&lt;/month&gt;&lt;day&gt;31&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1966&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;25% off swimwear&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;248864&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31760505&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;871&lt;/dept&gt;&lt;class&gt;22&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;item&gt;074723414&lt;/item&gt;&lt;tsl_consumer_unit&gt;279739234&lt;/tsl_consumer_unit&gt;&lt;threshold_id&gt;473283&lt;/threshold_id&gt;&lt;threshold_name&gt;25% off clothing &lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;P&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;025098704&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;25% off swimwear&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;1&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-0.25&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "    <customData>\n" + "    </customData>\n"
				+ "    <customFlag>F</customFlag>\n" + "  </ribMessage>\n"
				+ "</RibMessages>";
		String offerIdFromMsg = "31760505";
		String locType = "Z";
		String locRef = "5";
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(data);
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMO_DETAIL_ID_KEY
						+ detailIdFromMsg,String.class));
		repositoryImpl.deleteProduct(PriceConstants.PROMOTION_DOC_KEY_PREFIX
				+ offerIdFromMsg);

		String delMsg = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "  <ribMessage>\n"
				+ "    <family>PRMPRCCHG</family>\n"
				+ "    <type>PRMPRCCHGDEL</type>\n"
				+ "    <ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.05.13 12:31:01.770|925</ribmessageID>\n"
				+ "    <publishTime>2015-05-13 12:31:01.770 BST</publishTime>\n"
				+ "    <messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "&lt;PrmPrcChgRef&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtlRef&gt;&lt;promo_comp_detail_id&gt;39868714&lt;/promo_comp_detail_id&gt;&lt;tsl_ext_promo_id&gt;1966&lt;/tsl_ext_promo_id&gt;&lt;tsl_promo_comp_id&gt;151956&lt;/tsl_promo_comp_id&gt;&lt;tsl_state&gt;pcd.deleted&lt;/tsl_state&gt;&lt;PrmPrcChgThrDtlRef&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;2331&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;4&lt;/subclass&gt;&lt;item&gt;076233224&lt;/item&gt;&lt;tsl_consumer_unit&gt;250629398&lt;/tsl_consumer_unit&gt;&lt;/PrmPrcChgThrDtlRef&gt;&lt;/PrmPrcChgDtlRef&gt;&lt;PrmPrcChgDtlRef&gt;&lt;promo_comp_detail_id&gt;39868654&lt;/promo_comp_detail_id&gt;&lt;tsl_ext_promo_id&gt;1966&lt;/tsl_ext_promo_id&gt;&lt;tsl_promo_comp_id&gt;151956&lt;/tsl_promo_comp_id&gt;&lt;tsl_state&gt;pcd.deleted&lt;/tsl_state&gt;&lt;PrmPrcChgThrDtlRef&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;2331&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;4&lt;/subclass&gt;&lt;item&gt;074723414&lt;/item&gt;&lt;tsl_consumer_unit&gt;250630418&lt;/tsl_consumer_unit&gt;&lt;/PrmPrcChgThrDtlRef&gt;&lt;/PrmPrcChgDtlRef&gt;&lt;/PrmPrcChgRef&gt;</messageData>\n"
				+ "    <customData>\n" + "    </customData>\n"
				+ "    <customFlag>F</customFlag>\n" + "  </ribMessage>\n"
				+ "</RibMessages>";
		promotionMessageRouter.route(delMsg);
		Assert.assertNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMO_DETAIL_ID_KEY
						+ detailIdFromMsg,String.class));
	}

	@Test
	public void shouldUnmarshallAndProcessSmpPromoDelMsgWhenNoPromotionDocumentPresent()
			throws Exception {

		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "  <ribMessage>\n"
				+ "    <family>PRMPRCCHG</family>\n"
				+ "    <type>PRMPRCCHGCRE</type>\n"
				+ "    <ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.05.26 10:01:34.795|385</ribmessageID>\n"
				+ "    <publishTime>2015-05-26 10:01:34.795 BST</publishTime>\n"
				+ "    <messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "    &lt;PrmPrcChgDesc&gt;&lt;location&gt;13&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;13&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1562795&lt;/promo_id&gt;&lt;promo_name&gt;ROI BAKERY P5&lt;/promo_name&gt;&lt;promo_description&gt;WHITE CHOCOLATE COOKIES 5 PACK W 2 N 1.5 S 0.5&lt;/promo_description&gt;&lt;promo_comp_id&gt;182534&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;HOVIS BEST OF BOTH THICK WHITE Only 1.69&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;39778795&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;2&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;22&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;save&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;248790&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31757666&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;231&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;6&lt;/subclass&gt;&lt;item&gt;056574421&lt;/item&gt;&lt;tsl_consumer_unit&gt;253294471&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;1.69&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;N&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0&lt;/prm_chg_value&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;023667034&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;HOVIS BEST OF BOTH THICK WHITE Only 1.69&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n "
				+ "    <customData>\n" + "    </customData>\n"
				+ "    <customFlag>F</customFlag>\n" + "  </ribMessage>\n"
				+ "</RibMessages>";
		String offerIdFromMsg = "31757666";
		String locType = "Z";
		String locRef = "13";
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(data);
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));
		repositoryImpl.deleteProduct(PriceConstants.PROMOTION_DOC_KEY_PREFIX
				+ offerIdFromMsg + "_" + locType + locRef);
		String delMsg = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "  <ribMessage>\n"
				+ "    <family>PRMPRCCHG</family>\n"
				+ "    <type>PRMPRCCHGDEL</type>\n"
				+ "    <ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.05.13 12:31:01.770|925</ribmessageID>\n"
				+ "    <publishTime>2015-05-13 12:31:01.770 BST</publishTime>\n"
				+ " <messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ " &lt;PrmPrcChgRef&gt;&lt;location&gt;13&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;13&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtlRef&gt;&lt;promo_comp_detail_id&gt;39778795&lt;/promo_comp_detail_id&gt;&lt;tsl_promo_comp_id&gt;149233&lt;/tsl_promo_comp_id&gt;&lt;tsl_state&gt;pcd.deleted&lt;/tsl_state&gt;&lt;PrmPrcChgSmpDtlRef&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;2331&lt;/dept&gt;&lt;class&gt;7&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;item&gt;056574421&lt;/item&gt;&lt;tsl_consumer_unit&gt;250016772&lt;/tsl_consumer_unit&gt;&lt;/PrmPrcChgSmpDtlRef&gt;&lt;/PrmPrcChgDtlRef&gt;&lt;PrmPrcChgDtlRef&gt;&lt;promo_comp_detail_id&gt;39186503&lt;/promo_comp_detail_id&gt;&lt;tsl_promo_comp_id&gt;149233&lt;/tsl_promo_comp_id&gt;&lt;tsl_state&gt;pcd.deleted&lt;/tsl_state&gt;&lt;PrmPrcChgSmpDtlRef&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;2331&lt;/dept&gt;&lt;class&gt;7&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;item&gt;056172165-001&lt;/item&gt;&lt;tsl_consumer_unit&gt;264439797&lt;/tsl_consumer_unit&gt;&lt;/PrmPrcChgSmpDtlRef&gt;&lt;/PrmPrcChgDtlRef&gt;&lt;/PrmPrcChgRef&gt;</messageData>\n "
				+ "    <customData>\n" + "    </customData>\n"
				+ "    <customFlag>F</customFlag>\n" + "  </ribMessage>\n"
				+ "</RibMessages>";
		promotionMessageRouter.route(delMsg);

	}

	@Test
	public void shouldUnmarshallAndProcessSmpPromoDelMsgWhenDeleteOnlyOneItem()
			throws Exception {

		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "  <ribMessage>\n"
				+ "    <family>PRMPRCCHG</family>\n"
				+ "    <type>PRMPRCCHGCRE</type>\n"
				+ "    <ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.05.26 10:01:34.795|385</ribmessageID>\n"
				+ "    <publishTime>2015-05-26 10:01:34.795 BST</publishTime>\n"
				+ "    <messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "    &lt;PrmPrcChgDesc&gt;&lt;location&gt;13&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;13&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1562795&lt;/promo_id&gt;&lt;promo_name&gt;ROI BAKERY P5&lt;/promo_name&gt;&lt;promo_description&gt;WHITE CHOCOLATE COOKIES 5 PACK W 2 N 1.5 S 0.5&lt;/promo_description&gt;&lt;promo_comp_id&gt;182534&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;HOVIS BEST OF BOTH THICK WHITE Only 1.69&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;39778795&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;2&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;22&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;save&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;248790&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31757666&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;231&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;6&lt;/subclass&gt;&lt;item&gt;056574421&lt;/item&gt;&lt;tsl_consumer_unit&gt;253294471&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;1.69&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;N&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0&lt;/prm_chg_value&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;023667034&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;HOVIS BEST OF BOTH THICK WHITE Only 1.69&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n "
				+ "    <customData>\n" + "    </customData>\n"
				+ "    <customFlag>F</customFlag>\n" + "  </ribMessage>\n"
				+ "</RibMessages>";
		String offerIdFromMsg = "31757666";
		String locType = "Z";
		String locRef = "13";
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(data);
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));
		String delMsg = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "  <ribMessage>\n"
				+ "    <family>PRMPRCCHG</family>\n"
				+ "    <type>PRMPRCCHGDEL</type>\n"
				+ "    <ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.05.13 12:31:01.770|925</ribmessageID>\n"
				+ "    <publishTime>2015-05-13 12:31:01.770 BST</publishTime>\n"
				+ " <messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ " &lt;PrmPrcChgRef&gt;&lt;location&gt;13&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;13&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtlRef&gt;&lt;promo_comp_detail_id&gt;39778795&lt;/promo_comp_detail_id&gt;&lt;tsl_promo_comp_id&gt;149233&lt;/tsl_promo_comp_id&gt;&lt;tsl_state&gt;pcd.deleted&lt;/tsl_state&gt;&lt;PrmPrcChgSmpDtlRef&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;2331&lt;/dept&gt;&lt;class&gt;7&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;item&gt;056574421&lt;/item&gt;&lt;tsl_consumer_unit&gt;250016772&lt;/tsl_consumer_unit&gt;&lt;/PrmPrcChgSmpDtlRef&gt;&lt;/PrmPrcChgDtlRef&gt;&lt;PrmPrcChgDtlRef&gt;&lt;promo_comp_detail_id&gt;39186503&lt;/promo_comp_detail_id&gt;&lt;tsl_promo_comp_id&gt;149233&lt;/tsl_promo_comp_id&gt;&lt;tsl_state&gt;pcd.deleted&lt;/tsl_state&gt;&lt;PrmPrcChgSmpDtlRef&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;2331&lt;/dept&gt;&lt;class&gt;7&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;item&gt;056172165-001&lt;/item&gt;&lt;tsl_consumer_unit&gt;264439797&lt;/tsl_consumer_unit&gt;&lt;/PrmPrcChgSmpDtlRef&gt;&lt;/PrmPrcChgDtlRef&gt;&lt;/PrmPrcChgRef&gt;</messageData>\n "
				+ "    <customData>\n" + "    </customData>\n"
				+ "    <customFlag>F</customFlag>\n" + "  </ribMessage>\n"
				+ "</RibMessages>";
		promotionMessageRouter.route(delMsg);

	}

	@Test
	public void shouldUnmarshallAndProcessSmpPromoDelMsgWhenMasterDocNotFound()
			throws Exception {

		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "  <ribMessage>\n"
				+ "    <family>PRMPRCCHG</family>\n"
				+ "    <type>PRMPRCCHGCRE</type>\n"
				+ "    <ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.05.26 10:01:34.795|385</ribmessageID>\n"
				+ "    <publishTime>2015-05-26 10:01:34.795 BST</publishTime>\n"
				+ "    <messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "    &lt;PrmPrcChgDesc&gt;&lt;location&gt;13&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;13&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1562795&lt;/promo_id&gt;&lt;promo_name&gt;ROI BAKERY P5&lt;/promo_name&gt;&lt;promo_description&gt;WHITE CHOCOLATE COOKIES 5 PACK W 2 N 1.5 S 0.5&lt;/promo_description&gt;&lt;promo_comp_id&gt;182534&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;HOVIS BEST OF BOTH THICK WHITE Only 1.69&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;39778795&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;2&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;22&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;save&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;248790&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31757666&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;231&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;6&lt;/subclass&gt;&lt;item&gt;056574421&lt;/item&gt;&lt;tsl_consumer_unit&gt;253294471&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;1.69&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;N&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0&lt;/prm_chg_value&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;023667034&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;HOVIS BEST OF BOTH THICK WHITE Only 1.69&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n "
				+ "    <customData>\n" + "    </customData>\n"
				+ "    <customFlag>F</customFlag>\n" + "  </ribMessage>\n"
				+ "</RibMessages>";
		String offerIdFromMsg = "31757666";
		String locType = "Z";
		String locRef = "13";
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(data);
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));
		repositoryImpl.deleteProduct(PriceConstants.PROMOTION_DOC_KEY_PREFIX
				+ offerIdFromMsg);

		String delMsg = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "  <ribMessage>\n"
				+ "    <family>PRMPRCCHG</family>\n"
				+ "    <type>PRMPRCCHGDEL</type>\n"
				+ "    <ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.05.13 12:31:01.770|925</ribmessageID>\n"
				+ "    <publishTime>2015-05-13 12:31:01.770 BST</publishTime>\n"
				+ " <messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ " &lt;PrmPrcChgRef&gt;&lt;location&gt;13&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;13&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtlRef&gt;&lt;promo_comp_detail_id&gt;39778795&lt;/promo_comp_detail_id&gt;&lt;tsl_promo_comp_id&gt;149233&lt;/tsl_promo_comp_id&gt;&lt;tsl_state&gt;pcd.deleted&lt;/tsl_state&gt;&lt;PrmPrcChgSmpDtlRef&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;2331&lt;/dept&gt;&lt;class&gt;7&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;item&gt;056574421&lt;/item&gt;&lt;tsl_consumer_unit&gt;250016772&lt;/tsl_consumer_unit&gt;&lt;/PrmPrcChgSmpDtlRef&gt;&lt;/PrmPrcChgDtlRef&gt;&lt;PrmPrcChgDtlRef&gt;&lt;promo_comp_detail_id&gt;39186503&lt;/promo_comp_detail_id&gt;&lt;tsl_promo_comp_id&gt;149233&lt;/tsl_promo_comp_id&gt;&lt;tsl_state&gt;pcd.deleted&lt;/tsl_state&gt;&lt;PrmPrcChgSmpDtlRef&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;2331&lt;/dept&gt;&lt;class&gt;7&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;item&gt;056172165-001&lt;/item&gt;&lt;tsl_consumer_unit&gt;264439797&lt;/tsl_consumer_unit&gt;&lt;/PrmPrcChgSmpDtlRef&gt;&lt;/PrmPrcChgDtlRef&gt;&lt;/PrmPrcChgRef&gt;</messageData>\n "
				+ "    <customData>\n" + "    </customData>\n"
				+ "    <customFlag>F</customFlag>\n" + "  </ribMessage>\n"
				+ "</RibMessages>";
		promotionMessageRouter.route(delMsg);
	}

	@Test
	public void shouldUnmarshallAndProcessSmpPromoDelMsgWhenItemFromMsgNotFoundInPromoDocument()
			throws Exception {

		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "  <ribMessage>\n"
				+ "    <family>PRMPRCCHG</family>\n"
				+ "    <type>PRMPRCCHGCRE</type>\n"
				+ "    <ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.05.26 10:01:34.795|385</ribmessageID>\n"
				+ "    <publishTime>2015-05-26 10:01:34.795 BST</publishTime>\n"
				+ "    <messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "    &lt;PrmPrcChgDesc&gt;&lt;location&gt;13&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;13&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1562795&lt;/promo_id&gt;&lt;promo_name&gt;ROI BAKERY P5&lt;/promo_name&gt;&lt;promo_description&gt;WHITE CHOCOLATE COOKIES 5 PACK W 2 N 1.5 S 0.5&lt;/promo_description&gt;&lt;promo_comp_id&gt;182534&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;HOVIS BEST OF BOTH THICK WHITE Only 1.69&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;39778795&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;2&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;22&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;save&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;248790&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31757666&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;231&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;6&lt;/subclass&gt;&lt;item&gt;056574421&lt;/item&gt;&lt;tsl_consumer_unit&gt;253294471&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;1.69&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;N&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0&lt;/prm_chg_value&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;023667034&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;HOVIS BEST OF BOTH THICK WHITE Only 1.69&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n "
				+ "    <customData>\n" + "    </customData>\n"
				+ "    <customFlag>F</customFlag>\n" + "  </ribMessage>\n"
				+ "</RibMessages>";
		String offerIdFromMsg = "31757666";
		String locType = "Z";
		String locRef = "13";
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(data);
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));
		String delMsg = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "  <ribMessage>\n"
				+ "    <family>PRMPRCCHG</family>\n"
				+ "    <type>PRMPRCCHGDEL</type>\n"
				+ "    <ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.05.13 12:31:01.770|925</ribmessageID>\n"
				+ "    <publishTime>2015-05-13 12:31:01.770 BST</publishTime>\n"
				+ " <messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ " &lt;PrmPrcChgRef&gt;&lt;location&gt;13&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;13&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtlRef&gt;&lt;promo_comp_detail_id&gt;39778795&lt;/promo_comp_detail_id&gt;&lt;tsl_promo_comp_id&gt;149233&lt;/tsl_promo_comp_id&gt;&lt;tsl_state&gt;pcd.deleted&lt;/tsl_state&gt;&lt;PrmPrcChgSmpDtlRef&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;2331&lt;/dept&gt;&lt;class&gt;7&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;item&gt;056574420&lt;/item&gt;&lt;tsl_consumer_unit&gt;250016772&lt;/tsl_consumer_unit&gt;&lt;/PrmPrcChgSmpDtlRef&gt;&lt;/PrmPrcChgDtlRef&gt;&lt;PrmPrcChgDtlRef&gt;&lt;promo_comp_detail_id&gt;39186503&lt;/promo_comp_detail_id&gt;&lt;tsl_promo_comp_id&gt;149233&lt;/tsl_promo_comp_id&gt;&lt;tsl_state&gt;pcd.deleted&lt;/tsl_state&gt;&lt;PrmPrcChgSmpDtlRef&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;2331&lt;/dept&gt;&lt;class&gt;7&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;item&gt;056172165-001&lt;/item&gt;&lt;tsl_consumer_unit&gt;264439797&lt;/tsl_consumer_unit&gt;&lt;/PrmPrcChgSmpDtlRef&gt;&lt;/PrmPrcChgDtlRef&gt;&lt;/PrmPrcChgRef&gt;</messageData>\n "
				+ "    <customData>\n" + "    </customData>\n"
				+ "    <customFlag>F</customFlag>\n" + "  </ribMessage>\n"
				+ "</RibMessages>";
		promotionMessageRouter.route(delMsg);
	}

	@Test
	public void shouldUnmarshallAndProcessSmpPromoDelMsgWhenNoPromoDisplayLookUpFound()
			throws Exception {

		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);

		String delMsg = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "  <ribMessage>\n"
				+ "    <family>PRMPRCCHG</family>\n"
				+ "    <type>PRMPRCCHGDEL</type>\n"
				+ "    <ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.05.13 12:31:01.770|925</ribmessageID>\n"
				+ "    <publishTime>2015-05-13 12:31:01.770 BST</publishTime>\n"
				+ " <messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ " &lt;PrmPrcChgRef&gt;&lt;location&gt;8&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;8&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtlRef&gt;&lt;promo_comp_detail_id&gt;39778795&lt;/promo_comp_detail_id&gt;&lt;tsl_promo_comp_id&gt;149233&lt;/tsl_promo_comp_id&gt;&lt;tsl_state&gt;pcd.deleted&lt;/tsl_state&gt;&lt;PrmPrcChgSmpDtlRef&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;2331&lt;/dept&gt;&lt;class&gt;7&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;item&gt;056574420&lt;/item&gt;&lt;tsl_consumer_unit&gt;250016772&lt;/tsl_consumer_unit&gt;&lt;/PrmPrcChgSmpDtlRef&gt;&lt;/PrmPrcChgDtlRef&gt;&lt;PrmPrcChgDtlRef&gt;&lt;promo_comp_detail_id&gt;39186503&lt;/promo_comp_detail_id&gt;&lt;tsl_promo_comp_id&gt;149233&lt;/tsl_promo_comp_id&gt;&lt;tsl_state&gt;pcd.deleted&lt;/tsl_state&gt;&lt;PrmPrcChgSmpDtlRef&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;2331&lt;/dept&gt;&lt;class&gt;7&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;item&gt;056172165-001&lt;/item&gt;&lt;tsl_consumer_unit&gt;264439797&lt;/tsl_consumer_unit&gt;&lt;/PrmPrcChgSmpDtlRef&gt;&lt;/PrmPrcChgDtlRef&gt;&lt;/PrmPrcChgRef&gt;</messageData>\n "
				+ "    <customData>\n" + "    </customData>\n"
				+ "    <customFlag>F</customFlag>\n" + "  </ribMessage>\n"
				+ "</RibMessages>";
		promotionMessageRouter.route(delMsg);

	}

	@Test
	public void testProcessThesholdCreHierarchyPromotionsFromMsg()
			throws IOException, MessageRouterException, ProductEncodeException,
			DataAccessException {

		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.06.24 14:26:13.719|237</ribmessageID>\n"
				+ "<publishTime>2015-06-24 14:26:13.719 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1555356&lt;/promo_id&gt;&lt;promo_name&gt;promo&lt;/promo_name&gt;&lt;promo_description&gt;test&lt;/promo_description&gt;&lt;promo_comp_id&gt;120814&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;test&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;38833278&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;29&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;1&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;28&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;till&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31697456&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;\n"
				+ "&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;1&lt;/merch_type&gt;&lt;dept&gt;245&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;23&lt;/subclass&gt;&lt;threshold_id&gt;472348&lt;/threshold_id&gt;&lt;threshold_name&gt;test&lt;/threshold_name&gt;&lt;qualification_type&gt;0&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_comp_detail_level_desc&gt;test&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;4&lt;/threshold_value&gt;&lt;prm_chg_value&gt;0.1&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1555356&lt;/promo_id&gt;&lt;promo_name&gt;promo&lt;/promo_name&gt;&lt;promo_description&gt;test&lt;/promo_description&gt;&lt;promo_comp_id&gt;120814&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;test&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;38833275&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;29&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;1&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;28&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;till&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31697456&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;\n"
				+ "&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;1&lt;/merch_type&gt;&lt;dept&gt;245&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;3&lt;/subclass&gt;&lt;threshold_id&gt;472348&lt;/threshold_id&gt;&lt;threshold_name&gt;test&lt;/threshold_name&gt;&lt;qualification_type&gt;0&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_comp_detail_level_desc&gt;test&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;4&lt;/threshold_value&gt;&lt;prm_chg_value&gt;0.1&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		String offerIdFromMsg = "31697456";
		String locType = "Z";
		String locRef = "5";
		String section = "245";
		String classs = "1";
		String subclass = "23";
		String promoHierKey1 = PriceConstants.HIERARCHY_PROMO_PREFIX
				.concat(PriceUtility.convertRMStoTesco(section, classs,
						subclass));
		subclass = "3";
		String promoHierKey2 = PriceConstants.HIERARCHY_PROMO_PREFIX
				.concat(PriceUtility.convertRMStoTesco(section, classs,
						subclass));
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(data);
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));
		Assert.assertNotNull(repositoryImpl.getGenericObject(promoHierKey1,
				PromotionHierarchyEntity.class));
		Assert.assertNotNull(repositoryImpl.getGenericObject(promoHierKey2,
				PromotionHierarchyEntity.class));

	}

	@Test
	public void testProcessThesholdCreHierarchyPromotionsFromMsgWhenSubclassIsNull()
			throws IOException, MessageRouterException, ProductEncodeException,
			DataAccessException {

		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.02.01 11:05:00.744|4</ribmessageID>\n"
				+ "<publishTime>2015-02-01 11:05:00.744 GMT</publishTime>\n"
				+ "<messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1550913&lt;/promo_id&gt;&lt;promo_name&gt;ROI 6 bottles of wine&lt;/promo_name&gt;&lt;promo_description&gt;* Save 5% off on 6 bottles of wine&lt;/promo_description&gt;&lt;promo_comp_id&gt;93388&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;* Save 5% off on 6 bottles of wine&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;38144779&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;2&lt;/month&gt;&lt;day&gt;3&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2017&lt;/year&gt;&lt;month&gt;2&lt;/month&gt;&lt;day&gt;1&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1671&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;Save 5% off Wine&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;247798&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31670780&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;\n"
				+ "&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;1&lt;/merch_type&gt;&lt;dept&gt;2349&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;threshold_id&gt;471669&lt;/threshold_id&gt;&lt;threshold_name&gt;Save 5% off 6 bottles of wine&lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;P&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_comp_detail_level_desc&gt;* Save 5% off on 6 bottles of wine&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;6&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-0.05&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;\n"
				+ "&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData>\n" + "</customData>\n"
				+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
				+ "</RibMessages>";

		String offerIdFromMsg = "31670780";
		String locType = "Z";
		String locRef = "5";
		String section = "2349";
		String classs = "1";
		String promoHierKey1 = PriceConstants.HIERARCHY_PROMO_PREFIX
				.concat(PriceUtility.convertRMStoTesco(section, classs, null));
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(data);
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));
		Assert.assertNotNull(repositoryImpl.getGenericObject(promoHierKey1,
				PromotionHierarchyEntity.class));

	}

	@Test
	public void testProcessThesholdCreHierarchyPromotionsFromMsgWhenClassIsNull()
			throws IOException, MessageRouterException, ProductEncodeException,
			DataAccessException {

		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.02.01 11:05:00.744|4</ribmessageID>\n"
				+ "<publishTime>2015-02-01 11:05:00.744 GMT</publishTime>\n"
				+ "<messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1550913&lt;/promo_id&gt;&lt;promo_name&gt;ROI 6 bottles of wine&lt;/promo_name&gt;&lt;promo_description&gt;* Save 5% off on 6 bottles of wine&lt;/promo_description&gt;&lt;promo_comp_id&gt;93388&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;* Save 5% off on 6 bottles of wine&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;38144779&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;2&lt;/month&gt;&lt;day&gt;3&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2017&lt;/year&gt;&lt;month&gt;2&lt;/month&gt;&lt;day&gt;1&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1671&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;Save 5% off Wine&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;247798&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31670780&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;\n"
				+ "&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;1&lt;/merch_type&gt;&lt;dept&gt;2349&lt;/dept&gt;&lt;threshold_id&gt;471669&lt;/threshold_id&gt;&lt;threshold_name&gt;Save 5% off 6 bottles of wine&lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;P&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_comp_detail_level_desc&gt;* Save 5% off on 6 bottles of wine&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;6&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-0.05&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;\n"
				+ "&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData>\n" + "</customData>\n"
				+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
				+ "</RibMessages>";

		String offerIdFromMsg = "31670780";
		String locType = "Z";
		String locRef = "5";
		String section = "2349";
		String promoHierKey1 = PriceConstants.HIERARCHY_PROMO_PREFIX
				.concat(PriceUtility.convertRMStoTesco(section, null, null));
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(data);
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));
		Assert.assertNotNull(repositoryImpl.getGenericObject(promoHierKey1,
				PromotionHierarchyEntity.class));

	}

	@Test
	public void testProcessThesholdCreHierarchyPromotionsFromMsgWhenMultipleOfferPresentForSameHierarchy()
			throws IOException, MessageRouterException, ProductEncodeException,
			DataAccessException {

		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.02.01 11:05:00.744|4</ribmessageID>\n"
				+ "<publishTime>2015-02-01 11:05:00.744 GMT</publishTime>\n"
				+ "<messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1550913&lt;/promo_id&gt;&lt;promo_name&gt;ROI 6 bottles of wine&lt;/promo_name&gt;&lt;promo_description&gt;* Save 5% off on 6 bottles of wine&lt;/promo_description&gt;&lt;promo_comp_id&gt;93388&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;* Save 5% off on 6 bottles of wine&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;38144779&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;2&lt;/month&gt;&lt;day&gt;3&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2017&lt;/year&gt;&lt;month&gt;2&lt;/month&gt;&lt;day&gt;1&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1671&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;Save 5% off Wine&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;247798&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31670780&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;\n"
				+ "&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;1&lt;/merch_type&gt;&lt;dept&gt;2349&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;threshold_id&gt;471669&lt;/threshold_id&gt;&lt;threshold_name&gt;Save 5% off 6 bottles of wine&lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;P&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_comp_detail_level_desc&gt;* Save 5% off on 6 bottles of wine&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;6&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-0.05&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;\n"
				+ "&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData>\n" + "</customData>\n"
				+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
				+ "</RibMessages>";

		String offerIdFromMsg = "31670780";
		String locType = "Z";
		String locRef = "5";
		String section = "2349";
		String subclass = "1";
		String classs = "1";
		String promoHierKey1 = PriceConstants.HIERARCHY_PROMO_PREFIX
				.concat(PriceUtility.convertRMStoTesco(section, classs,
						subclass));
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(data);
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));
		Assert.assertNotNull(repositoryImpl.getGenericObject(promoHierKey1,
				PromotionHierarchyEntity.class));

		data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.02.01 11:05:00.744|4</ribmessageID>\n"
				+ "<publishTime>2015-02-01 11:05:00.744 GMT</publishTime>\n"
				+ "<messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1550913&lt;/promo_id&gt;&lt;promo_name&gt;ROI 6 bottles of wine&lt;/promo_name&gt;&lt;promo_description&gt;* Save 5% off on 6 bottles of wine&lt;/promo_description&gt;&lt;promo_comp_id&gt;93388&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;* Save 5% off on 6 bottles of wine&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;38144770&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;2&lt;/month&gt;&lt;day&gt;3&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2017&lt;/year&gt;&lt;month&gt;2&lt;/month&gt;&lt;day&gt;1&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1671&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;Save 5% off Wine&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;247798&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31670781&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;\n"
				+ "&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;1&lt;/merch_type&gt;&lt;dept&gt;2349&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;threshold_id&gt;471669&lt;/threshold_id&gt;&lt;threshold_name&gt;Save 5% off 6 bottles of wine&lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;P&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_comp_detail_level_desc&gt;* Save 5% off on 6 bottles of wine&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;6&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-0.05&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;\n"
				+ "&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData>\n" + "</customData>\n"
				+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
				+ "</RibMessages>";

		offerIdFromMsg = "31670781";
		promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(data);
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));
		Assert.assertNotNull(repositoryImpl.getGenericObject(promoHierKey1,
				PromotionHierarchyEntity.class));

	}

	@Test
	public void testProcessThesholdCreHierarchyPromotionsFromMsgWhenSubclassIsNullFor2ndDetail()
			throws IOException, MessageRouterException, ProductEncodeException,
			DataAccessException {

		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.06.24 14:26:13.719|237</ribmessageID>\n"
				+ "<publishTime>2015-06-24 14:26:13.719 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1555356&lt;/promo_id&gt;&lt;promo_name&gt;promo&lt;/promo_name&gt;&lt;promo_description&gt;test&lt;/promo_description&gt;&lt;promo_comp_id&gt;120814&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;test&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;38833278&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;29&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;1&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;28&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;till&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31697456&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;1&lt;/merch_type&gt;&lt;dept&gt;245&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;23&lt;/subclass&gt;&lt;threshold_id&gt;472348&lt;/threshold_id&gt;&lt;threshold_name&gt;test&lt;/threshold_name&gt;&lt;qualification_type&gt;0&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_comp_detail_level_desc&gt;test&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;4&lt;/threshold_value&gt;&lt;prm_chg_value&gt;0.1&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1555356&lt;/promo_id&gt;&lt;promo_name&gt;promo&lt;/promo_name&gt;&lt;promo_description&gt;test&lt;/promo_description&gt;&lt;promo_comp_id&gt;120814&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;test&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;38833275&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;29&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;1&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;28&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;till&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31697456&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;1&lt;/merch_type&gt;&lt;dept&gt;245&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;threshold_id&gt;472348&lt;/threshold_id&gt;&lt;threshold_name&gt;test&lt;/threshold_name&gt;&lt;qualification_type&gt;0&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_comp_detail_level_desc&gt;test&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;4&lt;/threshold_value&gt;&lt;prm_chg_value&gt;0.1&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		String offerIdFromMsg = "31697456";
		String locType = "Z";
		String locRef = "5";
		String section = "245";
		String classs = "1";
		String subclass = "23";
		String promoHierKey1 = PriceConstants.HIERARCHY_PROMO_PREFIX
				.concat(PriceUtility.convertRMStoTesco(section, classs,
						subclass));
		String promoHierKey2 = PriceConstants.HIERARCHY_PROMO_PREFIX
				.concat(PriceUtility.convertRMStoTesco(section, classs, null));
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(data);
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));
		Assert.assertNotNull(repositoryImpl.getGenericObject(promoHierKey1,
				PromotionHierarchyEntity.class));
		Assert.assertNotNull(repositoryImpl.getGenericObject(promoHierKey2,
				PromotionHierarchyEntity.class));

	}

	@Test
	public void testProcessThesholdCreHierarchyPromotionsFromMsgWhenClassIsNullFor2ndDetail()
			throws IOException, MessageRouterException, ProductEncodeException,
			DataAccessException {

		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.06.24 14:26:13.719|237</ribmessageID>\n"
				+ "<publishTime>2015-06-24 14:26:13.719 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1555356&lt;/promo_id&gt;&lt;promo_name&gt;promo&lt;/promo_name&gt;&lt;promo_description&gt;test&lt;/promo_description&gt;&lt;promo_comp_id&gt;120814&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;test&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;38833278&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;29&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;1&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;28&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;till&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31697456&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;1&lt;/merch_type&gt;&lt;dept&gt;245&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;23&lt;/subclass&gt;&lt;threshold_id&gt;472348&lt;/threshold_id&gt;&lt;threshold_name&gt;test&lt;/threshold_name&gt;&lt;qualification_type&gt;0&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_comp_detail_level_desc&gt;test&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;4&lt;/threshold_value&gt;&lt;prm_chg_value&gt;0.1&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1555356&lt;/promo_id&gt;&lt;promo_name&gt;promo&lt;/promo_name&gt;&lt;promo_description&gt;test&lt;/promo_description&gt;&lt;promo_comp_id&gt;120814&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;test&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;38833275&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;29&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;1&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;28&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;till&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31697456&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;1&lt;/merch_type&gt;&lt;dept&gt;245&lt;/dept&gt;&lt;threshold_id&gt;472348&lt;/threshold_id&gt;&lt;threshold_name&gt;test&lt;/threshold_name&gt;&lt;qualification_type&gt;0&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_comp_detail_level_desc&gt;test&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;4&lt;/threshold_value&gt;&lt;prm_chg_value&gt;0.1&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		String offerIdFromMsg = "31697456";
		String locType = "Z";
		String locRef = "5";
		String section = "245";
		String classs = "1";
		String subclass = "23";
		String promoHierKey1 = PriceConstants.HIERARCHY_PROMO_PREFIX
				.concat(PriceUtility.convertRMStoTesco(section, classs,
						subclass));
		String promoHierKey2 = PriceConstants.HIERARCHY_PROMO_PREFIX
				.concat(PriceUtility.convertRMStoTesco(section, null, null));
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(data);
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));
		Assert.assertNotNull(repositoryImpl.getGenericObject(promoHierKey1,
				PromotionHierarchyEntity.class));
		Assert.assertNotNull(repositoryImpl.getGenericObject(promoHierKey2,
				PromotionHierarchyEntity.class));

	}

	@Test
	public void testProcessThesholdCreHierarchyPromotionsFromMsgWhenPromotionIsNotHierarchyType()
			throws IOException, MessageRouterException, ProductEncodeException,
			DataAccessException {

		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "  <ribMessage>\n"
				+ "    <family>PRMPRCCHG</family>\n"
				+ "    <type>PRMPRCCHGCRE</type>\n"
				+ "    <ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.05.26 10:01:34.795|385</ribmessageID>\n"
				+ "    <publishTime>2015-05-26 10:01:34.795 BST</publishTime>\n"
				+ "    <messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "    &lt;PrmPrcChgDesc&gt;&lt;location&gt;13&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;13&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1562795&lt;/promo_id&gt;&lt;promo_name&gt;ROI BAKERY P5&lt;/promo_name&gt;&lt;promo_description&gt;WHITE CHOCOLATE COOKIES 5 PACK W 2 N 1.5 S 0.5&lt;/promo_description&gt;&lt;promo_comp_id&gt;182534&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;HOVIS BEST OF BOTH THICK WHITE Only 1.69&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;39778795&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;2&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;22&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;save&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;248790&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31757666&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;231&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;6&lt;/subclass&gt;&lt;item&gt;056574421&lt;/item&gt;&lt;tsl_consumer_unit&gt;253294471&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;1.69&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;N&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0&lt;/prm_chg_value&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;023667034&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;HOVIS BEST OF BOTH THICK WHITE Only 1.69&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n "
				+ "    <customData>\n" + "    </customData>\n"
				+ "    <customFlag>F</customFlag>\n" + "  </ribMessage>\n"
				+ "</RibMessages>";
		String offerIdFromMsg = "31757666";
		String locType = "Z";
		String locRef = "13";
		String promoHierKey = PriceUtility.convertRMStoTesco("231", "1", "6");
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(data);
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));
		Assert.assertNull(repositoryImpl.getGenericObject(promoHierKey,
				PromotionHierarchyEntity.class));
	}

	@Test
	public void testProcessThesholdModHierarchyPromotionsFromMsg()
			throws IOException, MessageRouterException, ProductEncodeException,
			DataAccessException {

		String credata = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.06.24 14:26:13.719|237</ribmessageID>\n"
				+ "<publishTime>2015-06-24 14:26:13.719 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;96142&lt;/promo_id&gt;&lt;promo_name&gt;thh&lt;/promo_name&gt;&lt;promo_description&gt;thh&lt;/promo_description&gt;&lt;promo_comp_id&gt;68628794&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;thh&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;2241207&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;10&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;12&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;28&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;dsd&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;29111680&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;1&lt;/merch_type&gt;&lt;dept&gt;245&lt;/dept&gt;&lt;class&gt;4&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;threshold_id&gt;15104&lt;/threshold_id&gt;&lt;threshold_name&gt;tgh&lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_comp_detail_level_desc&gt;thh&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;1&lt;/threshold_value&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		String offerIdFromMsg = "29111680";
		String locType = "Z";
		String locRef = "5";
		String section = "245";
		String classs = "4";
		String subclass = "1";
		String promoHierKey1 = PriceConstants.HIERARCHY_PROMO_PREFIX
				.concat(PriceUtility.convertRMStoTesco(section, classs,
						subclass));
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(credata);
		PromotionEntity promotionEntity = (PromotionEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class);
		PromotionHierarchyEntity promotionHierarchyEntity = (PromotionHierarchyEntity) repositoryImpl
				.getGenericObject(promoHierKey1, PromotionHierarchyEntity.class);

		String modData = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGMOD</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.06.24 14:26:13.719|237</ribmessageID>\n"
				+ "<publishTime>2015-06-29 11:38:57.055 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;96142&lt;/promo_id&gt;&lt;promo_name&gt;thh&lt;/promo_name&gt;&lt;promo_description&gt;thh&lt;/promo_description&gt;&lt;promo_comp_id&gt;68628794&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;thh&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;2241207&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;10&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;12&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;28&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.reapproved&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;dsd&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;29111680&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;1&lt;/merch_type&gt;&lt;dept&gt;245&lt;/dept&gt;&lt;class&gt;4&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;threshold_id&gt;15106&lt;/threshold_id&gt;&lt;threshold_name&gt;mod thresh&lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_comp_detail_level_desc&gt;thh&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;1&lt;/threshold_value&gt;&lt;prm_chg_value&gt;0.2&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		PromotionMessageRouter promotionMessageRouterAfterMod = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouterAfterMod.route(modData);
		PromotionEntity promotionEntityAfterMod = (PromotionEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class);
		PromotionHierarchyEntity promotionHierarchyEntityAfterMod = (PromotionHierarchyEntity) repositoryImpl
				.getGenericObject(promoHierKey1, PromotionHierarchyEntity.class);
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));
		Assert.assertNotNull(repositoryImpl.getGenericObject(promoHierKey1,
				PromotionHierarchyEntity.class));
		Assert.assertNotSame(promotionEntityAfterMod, promotionEntity);

	}

	@Test
	public void testProcessHierarchySimplePromotionsFromMsg()
			throws IOException, MessageRouterException, ProductEncodeException,
			DataAccessException {

		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.06.29 12:27:05.809|844</ribmessageID>\n"
				+ "<publishTime>2015-06-29 12:27:05.809 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;96146&lt;/promo_id&gt;&lt;promo_name&gt;thre&lt;/promo_name&gt;&lt;promo_description&gt;thre&lt;/promo_description&gt;&lt;promo_comp_id&gt;68628800&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;thre&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;2241231&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;5&lt;/month&gt;&lt;day&gt;6&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;5&lt;/month&gt;&lt;day&gt;7&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;till desc&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;29111686&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;2349&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;5&lt;/subclass&gt;&lt;item&gt;050022785&lt;/item&gt;&lt;tsl_consumer_unit&gt;250041902&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;9.99&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;P&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;-0.001&lt;/prm_chg_value&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;000014463&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;thre&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		String offerIdFromMsg = "29111686";
		String locType = "Z";
		String locRef = "5";
		String section = "2349";
		String classs = "1";
		String subclass = "5";
		String promoHierKey1 = PriceConstants.HIERARCHY_PROMO_PREFIX
				.concat(PriceUtility.convertRMStoTesco(section, classs,
						subclass));
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(data);
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));
		Assert.assertNull(repositoryImpl.getGenericObject(promoHierKey1,
				PromotionHierarchyEntity.class));

	}

	@Test
	public void testProcessHierarchyMultibuyPromotionsFromMsg()
			throws IOException, MessageRouterException, ProductEncodeException,
			DataAccessException {

		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.06.26 10:01:01.748|837</ribmessageID>\n"
				+ "<publishTime>2015-06-26 10:01:01.748 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;96138&lt;/promo_id&gt;&lt;promo_name&gt;mb hier&lt;/promo_name&gt;&lt;promo_description&gt;mb hier&lt;/promo_description&gt;&lt;promo_comp_id&gt;68628790&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;mb hier&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;2241176&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;0&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;5&lt;/month&gt;&lt;day&gt;7&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;5&lt;/month&gt;&lt;day&gt;8&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;888&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;till desc&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;29111676&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;TSLPrmPrcChgMultiBuy&gt;&lt;multi_buy_promo_type&gt;C&lt;/multi_buy_promo_type&gt;&lt;coupon_trg_ind&gt;N&lt;/coupon_trg_ind&gt;&lt;TSLPrmPrcChgBuyList&gt;&lt;list_id&gt;14501&lt;/list_id&gt;&lt;buy_item_type&gt;1&lt;/buy_item_type&gt;&lt;buy_item_value&gt;2&lt;/buy_item_value&gt;&lt;TSLPrmPrcChgBuyListItem&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;245&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;item&gt;050010701&lt;/item&gt;&lt;tsl_consumer_unit&gt;250024232&lt;/tsl_consumer_unit&gt;&lt;tsl_TPND&gt;000002713&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;mb hier&lt;/tsl_comp_detail_level_desc&gt;&lt;/TSLPrmPrcChgBuyListItem&gt;&lt;TSLPrmPrcChgBuyListItem&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;245&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;item&gt;050036976&lt;/item&gt;&lt;tsl_consumer_unit&gt;250092392&lt;/tsl_consumer_unit&gt;&lt;tsl_TPND&gt;000040206&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;mb hier&lt;/tsl_comp_detail_level_desc&gt;&lt;/TSLPrmPrcChgBuyListItem&gt;&lt;/TSLPrmPrcChgBuyList&gt;&lt;TSLPrmPrcChgReward&gt;&lt;list_id&gt;14502&lt;/list_id&gt;&lt;change_type&gt;8&lt;/change_type&gt;&lt;get_quantity&gt;1&lt;/get_quantity&gt;&lt;change_percent&gt;-1.000000&lt;/change_percent&gt;&lt;/TSLPrmPrcChgReward&gt;&lt;/TSLPrmPrcChgMultiBuy&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		String offerIdFromMsg = "29111676";
		String locType = "Z";
		String locRef = "5";
		String section = "245";
		String classs = "1";
		String subclass = "1";
		String promoHierKey1 = PriceConstants.HIERARCHY_PROMO_PREFIX
				.concat(PriceUtility.convertRMStoTesco(section, classs,
						subclass));
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(data);
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));
		Assert.assertNull(repositoryImpl.getGenericObject(promoHierKey1,
				PromotionHierarchyEntity.class));

	}

	@Test
	public void testProcessHierarchySimplePromotionsWithNonZeroMerchFromMsg()
			throws IOException, MessageRouterException, ProductEncodeException,
			DataAccessException {

		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.06.29 12:27:05.809|844</ribmessageID>\n"
				+ "<publishTime>2015-06-29 12:27:05.809 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;96146&lt;/promo_id&gt;&lt;promo_name&gt;thre&lt;/promo_name&gt;&lt;promo_description&gt;thre&lt;/promo_description&gt;&lt;promo_comp_id&gt;68628800&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;thre&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;2241231&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;5&lt;/month&gt;&lt;day&gt;6&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;5&lt;/month&gt;&lt;day&gt;7&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;till desc&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;29111686&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;1&lt;/merch_type&gt;&lt;dept&gt;2349&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;5&lt;/subclass&gt;&lt;promo_selling_retail&gt;9.99&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;P&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;-0.001&lt;/prm_chg_value&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;000014463&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;thre&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		String offerIdFromMsg = "29111686";
		String locType = "Z";
		String locRef = "5";
		String section = "2349";
		String classs = "1";
		String subclass = "5";
		String promoHierKey1 = PriceConstants.HIERARCHY_PROMO_PREFIX
				.concat(PriceUtility.convertRMStoTesco(section, classs,
						subclass));
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		try {
			promotionMessageRouter.route(data);
		} catch (MessageRouterException pbe) {
			Assert.assertTrue(true);
			Assert.assertEquals(
					"Invalid Message - with non zero merch type - Simple promotion",
					pbe.getMessage());
		} finally {
			Assert.assertNull(repositoryImpl
					.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
							+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));
			Assert.assertNull(repositoryImpl.getGenericObject(promoHierKey1,
					PromotionHierarchyEntity.class));
		}

	}

	@Test
	public void testProcessHierarchyMultibuyPromotionsWithNonZeroMerchFromMsg()
			throws IOException, MessageRouterException, ProductEncodeException,
			DataAccessException {

		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.06.26 10:01:01.748|837</ribmessageID>\n"
				+ "<publishTime>2015-06-26 10:01:01.748 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;96138&lt;/promo_id&gt;&lt;promo_name&gt;mb hier&lt;/promo_name&gt;&lt;promo_description&gt;mb hier&lt;/promo_description&gt;&lt;promo_comp_id&gt;68628790&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;mb hier&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;2241176&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;0&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;5&lt;/month&gt;&lt;day&gt;7&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;5&lt;/month&gt;&lt;day&gt;8&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;888&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;till desc&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;29111676&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;TSLPrmPrcChgMultiBuy&gt;&lt;multi_buy_promo_type&gt;C&lt;/multi_buy_promo_type&gt;&lt;coupon_trg_ind&gt;N&lt;/coupon_trg_ind&gt;&lt;TSLPrmPrcChgBuyList&gt;&lt;list_id&gt;14501&lt;/list_id&gt;&lt;buy_item_type&gt;1&lt;/buy_item_type&gt;&lt;buy_item_value&gt;2&lt;/buy_item_value&gt;&lt;TSLPrmPrcChgBuyListItem&gt;&lt;merch_type&gt;1&lt;/merch_type&gt;&lt;dept&gt;245&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;tsl_comp_detail_level_desc&gt;mb hier&lt;/tsl_comp_detail_level_desc&gt;&lt;/TSLPrmPrcChgBuyListItem&gt;&lt;TSLPrmPrcChgBuyListItem&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;245&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;item&gt;050036976&lt;/item&gt;&lt;tsl_consumer_unit&gt;250092392&lt;/tsl_consumer_unit&gt;&lt;tsl_TPND&gt;000040206&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;mb hier&lt;/tsl_comp_detail_level_desc&gt;&lt;/TSLPrmPrcChgBuyListItem&gt;&lt;/TSLPrmPrcChgBuyList&gt;&lt;TSLPrmPrcChgReward&gt;&lt;list_id&gt;14502&lt;/list_id&gt;&lt;change_type&gt;8&lt;/change_type&gt;&lt;get_quantity&gt;1&lt;/get_quantity&gt;&lt;change_percent&gt;-1.000000&lt;/change_percent&gt;&lt;/TSLPrmPrcChgReward&gt;&lt;/TSLPrmPrcChgMultiBuy&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		String offerIdFromMsg = "29111676";
		String locType = "Z";
		String locRef = "5";
		String section = "245";
		String classs = "1";
		String subclass = "1";
		String promoHierKey1 = PriceConstants.HIERARCHY_PROMO_PREFIX
				.concat(PriceUtility.convertRMStoTesco(section, classs,
						subclass));
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		try {
			promotionMessageRouter.route(data);
		} catch (MessageRouterException pbe) {
			Assert.assertTrue(true);
			Assert.assertEquals(
					"Invalid Message - with non zero merch type - Multi buy",
					pbe.getMessage());
		} finally {
			Assert.assertNull(repositoryImpl
					.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
							+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));
			Assert.assertNull(repositoryImpl.getGenericObject(promoHierKey1,
					PromotionHierarchyEntity.class));
		}

	}

	@Test
	public void shouldUnmarshallAndProcessThrHierPromoDelMsgWholeDocumentShouldGetDeleted()
			throws Exception {
		String detailIdFromMsg = "38833278";

		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.02.01 11:05:00.744|4</ribmessageID>\n"
				+ "<publishTime>2015-02-01 11:05:00.744 GMT</publishTime>\n"
				+ "<messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1555356&lt;/promo_id&gt;&lt;promo_name&gt;ROI 6 bottles of wine&lt;/promo_name&gt;&lt;promo_description&gt;* Save 5% off on 6 bottles of wine&lt;/promo_description&gt;&lt;promo_comp_id&gt;120814&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;* Save 5% off on 6 bottles of wine&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;38833278&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;2&lt;/month&gt;&lt;day&gt;3&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2017&lt;/year&gt;&lt;month&gt;2&lt;/month&gt;&lt;day&gt;1&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1671&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;Save 5% off Wine&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;247798&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31697456&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;\n"
				+ "&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;1&lt;/merch_type&gt;&lt;dept&gt;245&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;23&lt;/subclass&gt;&lt;threshold_id&gt;471669&lt;/threshold_id&gt;&lt;threshold_name&gt;Save 5% off 6 bottles of wine&lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;P&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_comp_detail_level_desc&gt;* Save 5% off on 6 bottles of wine&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;6&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-0.05&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;\n"
				+ "&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData>\n" + "</customData>\n"
				+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
				+ "</RibMessages>";
		String offerIdFromMsg = "31697456";
		String locType = "Z";
		String locRef = "5";
		String section = "245";
		String classs = "1";
		String subclass = "23";
		String promoHierKey1 = PriceConstants.HIERARCHY_PROMO_PREFIX
				.concat(PriceUtility.convertRMStoTesco(section, classs,
						subclass));
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(data);
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg,PromotionEntity.class));
		Assert.assertNotNull(repositoryImpl.getGenericObject(promoHierKey1,
				PromotionHierarchyEntity.class));
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMO_DETAIL_ID_KEY
						+ detailIdFromMsg,String.class));

		String delMsg = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGDEL</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.06.29 12:04:07.855|843</ribmessageID>\n"
				+ "<publishTime>2015-06-29 12:04:07.855 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgRef&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtlRef&gt;&lt;promo_comp_detail_id&gt;38833278&lt;/promo_comp_detail_id&gt;&lt;tsl_promo_comp_id&gt;120814&lt;/tsl_promo_comp_id&gt;&lt;tsl_state&gt;pcd.unapproved&lt;/tsl_state&gt;&lt;PrmPrcChgThrDtlRef&gt;&lt;merch_type&gt;1&lt;/merch_type&gt;&lt;dept&gt;245&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;23&lt;/subclass&gt;&lt;/PrmPrcChgThrDtlRef&gt;&lt;/PrmPrcChgDtlRef&gt;&lt;/PrmPrcChgRef&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";
		promotionMessageRouter.route(delMsg);
		Assert.assertNull(repositoryImpl
				.getGenericObject(PriceConstants.HIERARCHY_PROMO_PREFIX
						.concat(PriceUtility.convertRMStoTesco(section, classs,
								subclass)),PromotionEntity.class));
		Assert.assertNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));
		Assert.assertNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMO_DETAIL_ID_KEY
						+ detailIdFromMsg,String.class));
		Assert.assertNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg,PromotionEntity.class));
	}

	@Test
	public void shouldUnmarshallAndProcessThrHierPromoDelMsgWhenSubclassIsNull()
			throws Exception {
		String detailIdFromMsg = "38144779";

		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.02.01 11:05:00.744|4</ribmessageID>\n"
				+ "<publishTime>2015-02-01 11:05:00.744 GMT</publishTime>\n"
				+ "<messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1550913&lt;/promo_id&gt;&lt;promo_name&gt;ROI 6 bottles of wine&lt;/promo_name&gt;&lt;promo_description&gt;* Save 5% off on 6 bottles of wine&lt;/promo_description&gt;&lt;promo_comp_id&gt;93388&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;* Save 5% off on 6 bottles of wine&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;38144779&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;2&lt;/month&gt;&lt;day&gt;3&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2017&lt;/year&gt;&lt;month&gt;2&lt;/month&gt;&lt;day&gt;1&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1671&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;Save 5% off Wine&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;247798&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31670780&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;\n"
				+ "&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;1&lt;/merch_type&gt;&lt;dept&gt;2349&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;threshold_id&gt;471669&lt;/threshold_id&gt;&lt;threshold_name&gt;Save 5% off 6 bottles of wine&lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;P&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_comp_detail_level_desc&gt;* Save 5% off on 6 bottles of wine&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;6&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-0.05&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;\n"
				+ "&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData>\n" + "</customData>\n"
				+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
				+ "</RibMessages>";
		String offerIdFromMsg = "31670780";
		String locType = "Z";
		String locRef = "5";
		String section = "2349";
		String classs = "1";
		String promoHierKey1 = PriceConstants.HIERARCHY_PROMO_PREFIX
				.concat(PriceUtility.convertRMStoTesco(section, classs, null));
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(data);
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg,PromotionEntity.class));
		Assert.assertNotNull(repositoryImpl.getGenericObject(promoHierKey1,
				PromotionHierarchyEntity.class));
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMO_DETAIL_ID_KEY
						+ detailIdFromMsg,String.class));

		String delMsg = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGDEL</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.06.29 12:04:07.855|843</ribmessageID>\n"
				+ "<publishTime>2015-06-29 12:04:07.855 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgRef&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtlRef&gt;&lt;promo_comp_detail_id&gt;38144779&lt;/promo_comp_detail_id&gt;&lt;tsl_promo_comp_id&gt;120814&lt;/tsl_promo_comp_id&gt;&lt;tsl_state&gt;pcd.unapproved&lt;/tsl_state&gt;&lt;PrmPrcChgThrDtlRef&gt;&lt;merch_type&gt;1&lt;/merch_type&gt;&lt;dept&gt;2349&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;/PrmPrcChgThrDtlRef&gt;&lt;/PrmPrcChgDtlRef&gt;&lt;/PrmPrcChgRef&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";
		promotionMessageRouter.route(delMsg);
		Assert.assertNull(repositoryImpl
				.getGenericObject(PriceConstants.HIERARCHY_PROMO_PREFIX
						.concat(PriceUtility.convertRMStoTesco(section, classs,
								null)),PromotionEntity.class));
		Assert.assertNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));
		Assert.assertNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMO_DETAIL_ID_KEY
						+ detailIdFromMsg,String.class));
		Assert.assertNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg,PromotionEntity.class));

	}

	@Test
	public void shouldUnmarshallAndProcessThrHierPromoDelMsgWithMultipleZoneForSameHierarchy()
			throws IOException, MessageRouterException, ProductEncodeException,
			DataAccessException {
		String detailIdFromMsg = "38144779";
		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.02.01 11:05:00.744|4</ribmessageID>\n"
				+ "<publishTime>2015-02-01 11:05:00.744 GMT</publishTime>\n"
				+ "<messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1550913&lt;/promo_id&gt;&lt;promo_name&gt;ROI 6 bottles of wine&lt;/promo_name&gt;&lt;promo_description&gt;* Save 5% off on 6 bottles of wine&lt;/promo_description&gt;&lt;promo_comp_id&gt;93388&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;* Save 5% off on 6 bottles of wine&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;38144779&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;2&lt;/month&gt;&lt;day&gt;3&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2017&lt;/year&gt;&lt;month&gt;2&lt;/month&gt;&lt;day&gt;1&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1671&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;Save 5% off Wine&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;247798&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31670780&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;\n"
				+ "&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;1&lt;/merch_type&gt;&lt;dept&gt;2349&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;threshold_id&gt;471669&lt;/threshold_id&gt;&lt;threshold_name&gt;Save 5% off 6 bottles of wine&lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;P&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_comp_detail_level_desc&gt;* Save 5% off on 6 bottles of wine&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;6&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-0.05&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;\n"
				+ "&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData>\n" + "</customData>\n"
				+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
				+ "</RibMessages>";

		String offerIdFromMsg = "31670780";
		String locType = "Z";
		String locRef = "5";
		String section = "2349";
		String classs = "1";
		String subclass = "1";
		String promoHierKey1 = PriceConstants.HIERARCHY_PROMO_PREFIX
				.concat(PriceUtility.convertRMStoTesco(section, classs,
						subclass));
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(data);
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg,PromotionEntity.class));
		Assert.assertNotNull(repositoryImpl.getGenericObject(promoHierKey1,
				PromotionHierarchyEntity.class));
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMO_DETAIL_ID_KEY
						+ detailIdFromMsg,String.class));

		detailIdFromMsg = "38144770";
		data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.02.01 11:05:00.744|4</ribmessageID>\n"
				+ "<publishTime>2015-02-01 11:05:00.744 GMT</publishTime>\n"
				+ "<messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;6&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1550913&lt;/promo_id&gt;&lt;promo_name&gt;ROI 6 bottles of wine&lt;/promo_name&gt;&lt;promo_description&gt;* Save 5% off on 6 bottles of wine&lt;/promo_description&gt;&lt;promo_comp_id&gt;93388&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;* Save 5% off on 6 bottles of wine&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;38144770&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;2&lt;/month&gt;&lt;day&gt;3&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2017&lt;/year&gt;&lt;month&gt;2&lt;/month&gt;&lt;day&gt;1&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1671&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;Save 5% off Wine&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;247798&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31670780&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;\n"
				+ "&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;1&lt;/merch_type&gt;&lt;dept&gt;2549&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;threshold_id&gt;471669&lt;/threshold_id&gt;&lt;threshold_name&gt;Save 5% off 6 bottles of wine&lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;P&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_comp_detail_level_desc&gt;* Save 5% off on 6 bottles of wine&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;6&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-0.05&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;\n"
				+ "&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData>\n" + "</customData>\n"
				+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
				+ "</RibMessages>";

		offerIdFromMsg = "31670780";
		locType = "Z";
		locRef = "6";
		promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(data);
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg,PromotionEntity.class));
		Assert.assertNotNull(repositoryImpl.getGenericObject(promoHierKey1,
				PromotionHierarchyEntity.class));
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMO_DETAIL_ID_KEY
						+ detailIdFromMsg,String.class));

		String delMsg = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGDEL</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.06.29 12:04:07.855|843</ribmessageID>\n"
				+ "<publishTime>2015-06-29 12:04:07.855 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgRef&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtlRef&gt;&lt;promo_comp_detail_id&gt;38144779&lt;/promo_comp_detail_id&gt;&lt;tsl_promo_comp_id&gt;120814&lt;/tsl_promo_comp_id&gt;&lt;tsl_state&gt;pcd.unapproved&lt;/tsl_state&gt;&lt;PrmPrcChgThrDtlRef&gt;&lt;merch_type&gt;1&lt;/merch_type&gt;&lt;dept&gt;2349&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;/PrmPrcChgThrDtlRef&gt;&lt;/PrmPrcChgDtlRef&gt;&lt;/PrmPrcChgRef&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";
		promotionMessageRouter.route(delMsg);
		Assert.assertNull(repositoryImpl
				.getGenericObject(PriceConstants.HIERARCHY_PROMO_PREFIX
						.concat(PriceUtility.convertRMStoTesco(section, classs,
								subclass)),PromotionEntity.class));
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg,PromotionEntity.class));

	}

	@Test
	public void testProcessSimpleModDescRewardAmendPromotionsFromMsg()
			throws IOException, MessageRouterException, ProductEncodeException,
			DataAccessException {

		String offerIdFromMsg = "31802214";
		String locType = "Z";
		String locRef = "5";
		String dtlId1 = "40690952";
		String dtlId2 = "40690954";
		List dtlIds = new ArrayList();
		dtlIds.add(dtlId1);
		dtlIds.add(dtlId2);

		String masterKey = PriceConstants.PROMOTION_DOC_KEY_PREFIX
				+ offerIdFromMsg;
		String key = PriceConstants.PROMOTION_DOC_KEY_PREFIX + offerIdFromMsg
				+ "_" + locType + locRef;
		String compDtlId1 = "PROMO_COMP_DETAIL_ID_" + dtlId1;
		String compDtlId2 = "PROMO_COMP_DETAIL_ID_" + dtlId2;
		List hierkey = new ArrayList();
		deleteDocs(masterKey, key, dtlIds, hierkey);

		String credata = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.08.25 14:26:13.719|237</ribmessageID>\n"
				+ "<publishTime>2015-08-25 14:26:13.719 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690952&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802214&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;063165054&lt;/item&gt;&lt;tsl_consumer_unit&gt;259661056&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;014685527&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;0.29&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;1.29&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.28&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690954&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802214&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;064727108&lt;/item&gt;&lt;tsl_consumer_unit&gt;265389479&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;016407285&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;1&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;2&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.99&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(credata);
		PromotionEntity promotionEntity = (PromotionEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class);
		PromotionMasterEntity promotionMasterEntity = (PromotionMasterEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg, PromotionMasterEntity.class);

		String modData = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGMOD</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.06.24 14:26:13.719|237</ribmessageID>\n"
				+ "<publishTime>2015-06-29 11:38:57.055 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP_Update1&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690954&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.reapproved&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP_UPdate1&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802214&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;064727108&lt;/item&gt;&lt;tsl_consumer_unit&gt;265389479&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;016407285&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;1&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;2&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.99&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP_Update1&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690952&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.reapproved&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP_UPdate1&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802214&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;063165054&lt;/item&gt;&lt;tsl_consumer_unit&gt;259661056&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;014685527&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;0.29&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;1.29&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.28&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		PromotionMessageRouter promotionMessageRouterAfterMod = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);

		promotionMessageRouterAfterMod.route(modData);

		PromotionEntity promotionEntityAfterMod = (PromotionEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class);
		PromotionMasterEntity promotionMasterEntityMod = (PromotionMasterEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg, PromotionMasterEntity.class);

		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));

		Assert.assertNotNull(promotionMasterEntityMod);
		Assert.assertNotSame(promotionEntityAfterMod, promotionEntity);

		deleteDocs(masterKey, key, dtlIds, hierkey);

	}

	@Test
	public void testProcessSimpleModAdditionofItemwithExistingItemPromotionsFromMsg()
			throws IOException, MessageRouterException, ProductEncodeException,
			DataAccessException {

		String offerIdFromMsg = "31802214";
		String locType = "Z";
		String locRef = "5";
		String dtlId1 = "40690952";
		String dtlId2 = "40690954";
		String dtlId3 = "40690977";
		List dtlIds = new ArrayList();
		dtlIds.add(dtlId1);
		dtlIds.add(dtlId2);
		dtlIds.add(dtlId3);

		String masterKey = PriceConstants.PROMOTION_DOC_KEY_PREFIX
				+ offerIdFromMsg;
		String key = PriceConstants.PROMOTION_DOC_KEY_PREFIX + offerIdFromMsg
				+ "_" + locType + locRef;
		String compDtlId1 = "PROMO_COMP_DETAIL_ID_" + dtlId1;
		String compDtlId2 = "PROMO_COMP_DETAIL_ID_" + dtlId2;
		String compDtlId3 = "PROMO_COMP_DETAIL_ID_" + dtlId3;

		deleteDocs(masterKey, key, dtlIds, null);

		String credata = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.08.25 14:26:13.719|237</ribmessageID>\n"
				+ "<publishTime>2015-08-25 14:26:13.719 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690952&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802214&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;063165054&lt;/item&gt;&lt;tsl_consumer_unit&gt;259661056&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;014685527&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;0.29&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;1.29&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.28&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690954&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802214&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;064727108&lt;/item&gt;&lt;tsl_consumer_unit&gt;265389479&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;016407285&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;1&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;2&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.99&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(credata);
		PromotionEntity promotionEntity = (PromotionEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class);
		PromotionMasterEntity promotionMasterEntity = (PromotionMasterEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg, PromotionMasterEntity.class);

		String modData = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.06.24 14:26:13.719|237</ribmessageID>\n"
				+ "<publishTime>2015-06-29 11:38:57.055 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP_Update1&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690954&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.reapproved&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP_UPdate1&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802214&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;064727108&lt;/item&gt;&lt;tsl_consumer_unit&gt;265389479&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;016407285&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;1&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;2&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.99&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP_Update1&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690977&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.reapproved&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP_UPdate1&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802214&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;063165077&lt;/item&gt;&lt;tsl_consumer_unit&gt;259661056&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;014685527&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;0.29&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;1.29&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.28&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		PromotionMessageRouter promotionMessageRouterAfterMod = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);

		promotionMessageRouterAfterMod.route(modData);

		PromotionEntity promotionEntityAfterMod = (PromotionEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class);
		PromotionMasterEntity promotionMasterEntityMod = (PromotionMasterEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg, PromotionMasterEntity.class);

		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));

		Assert.assertNotNull(promotionMasterEntityMod);
		Assert.assertNotSame(promotionEntityAfterMod, promotionEntity);

		deleteDocs(masterKey, key, dtlIds, null);

	}

	@Test
	public void testProcessSimpleModNewItemAdditionPromotionsFromMsg()
			throws IOException, MessageRouterException, ProductEncodeException,
			DataAccessException {

		String offerIdFromMsg = "31802214";
		String locType = "Z";
		String locRef = "5";
		String dtlId1 = "40690952";
		String dtlId2 = "40690954";
		String dtlId3 = "40690998";
		String dtlId4 = "40690996";
		List dtlIds = new ArrayList();
		dtlIds.add(dtlId1);
		dtlIds.add(dtlId2);
		dtlIds.add(dtlId3);
		dtlIds.add(dtlId4);

		String masterKey = PriceConstants.PROMOTION_DOC_KEY_PREFIX
				+ offerIdFromMsg;
		String key = PriceConstants.PROMOTION_DOC_KEY_PREFIX + offerIdFromMsg
				+ "_" + locType + locRef;
		String compDtlId1 = "PROMO_COMP_DETAIL_ID_" + dtlId1;
		String compDtlId2 = "PROMO_COMP_DETAIL_ID_" + dtlId2;
		String compDtlId3 = "PROMO_COMP_DETAIL_ID_" + dtlId3;
		String compDtlId4 = "PROMO_COMP_DETAIL_ID_" + dtlId4;

		deleteDocs(masterKey, key, dtlIds, null);

		String credata = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.08.25 14:26:13.719|237</ribmessageID>\n"
				+ "<publishTime>2015-08-25 14:26:13.719 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP_Update1&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690996&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.reapproved&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP_UPdate1&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802214&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;0647271968&lt;/item&gt;&lt;tsl_consumer_unit&gt;265389479&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;016407285&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;1&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;2&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.99&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP_Update1&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690998&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.reapproved&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP_UPdate1&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802214&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;063165099&lt;/item&gt;&lt;tsl_consumer_unit&gt;259661056&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;014685527&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;0.29&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;1.29&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.28&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(credata);
		PromotionEntity promotionEntity = (PromotionEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class);
		PromotionMasterEntity promotionMasterEntity = (PromotionMasterEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg, PromotionMasterEntity.class);

		String modData = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.06.24 14:26:13.719|237</ribmessageID>\n"
				+ "<publishTime>2015-06-29 11:38:57.055 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP_Update1&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690954&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.reapproved&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP_UPdate1&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802214&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;064727108&lt;/item&gt;&lt;tsl_consumer_unit&gt;265389479&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;016407285&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;1&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;2&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.99&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP_Update1&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690952&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.reapproved&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP_UPdate1&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802214&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;063165054&lt;/item&gt;&lt;tsl_consumer_unit&gt;259661056&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;014685527&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;0.29&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;1.29&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.28&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		PromotionMessageRouter promotionMessageRouterAfterMod = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);

		promotionMessageRouterAfterMod.route(modData);

		PromotionEntity promotionEntityAfterMod = (PromotionEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class);
		PromotionMasterEntity promotionMasterEntityMod = (PromotionMasterEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg, PromotionMasterEntity.class);

		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));

		Assert.assertNotNull(promotionMasterEntityMod);
		Assert.assertNotSame(promotionEntityAfterMod, promotionEntity);
		deleteDocs(masterKey, key, dtlIds, null);

	}

	@Test
	public void testProcessSimpleModNewItemAdditionWithoutPOSPromotionsFromMsg()
			throws IOException, MessageRouterException, ProductEncodeException,
			DataAccessException {

		String offerIdFromMsg = "31802214";
		String locType = "Z";
		String locRef = "5";
		String dtlId1 = "40690952";
		String dtlId2 = "40690954";
		String dtlId3 = "40690998";
		String dtlId4 = "40690996";
		List dtlIds = new ArrayList();
		dtlIds.add(dtlId1);
		dtlIds.add(dtlId2);
		dtlIds.add(dtlId3);
		dtlIds.add(dtlId4);

		String masterKey = PriceConstants.PROMOTION_DOC_KEY_PREFIX
				+ offerIdFromMsg;
		String key = PriceConstants.PROMOTION_DOC_KEY_PREFIX + offerIdFromMsg
				+ "_" + locType + locRef;
		String compDtlId1 = "PROMO_COMP_DETAIL_ID_" + dtlId1;
		String compDtlId2 = "PROMO_COMP_DETAIL_ID_" + dtlId2;
		String compDtlId3 = "PROMO_COMP_DETAIL_ID_" + dtlId3;
		String compDtlId4 = "PROMO_COMP_DETAIL_ID_" + dtlId4;

		deleteDocs(masterKey, key, dtlIds, null);

		String credata = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.08.25 14:26:13.719|237</ribmessageID>\n"
				+ "<publishTime>2015-08-25 14:26:13.719 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP_Update1&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690996&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.reapproved&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP_UPdate1&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802214&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;0647271968&lt;/item&gt;&lt;tsl_consumer_unit&gt;265389479&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;016407285&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;1&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;2&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.99&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP_Update1&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690998&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.reapproved&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP_UPdate1&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802214&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;063165099&lt;/item&gt;&lt;tsl_consumer_unit&gt;259661056&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;014685527&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;0.29&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;1.29&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.28&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(credata);
		PromotionEntity promotionEntity = (PromotionEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class);
		PromotionMasterEntity promotionMasterEntity = (PromotionMasterEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg, PromotionMasterEntity.class);

		String modData = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.06.24 14:26:13.719|237</ribmessageID>\n"
				+ "<publishTime>2015-06-29 11:38:57.055 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP_Update1&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690954&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.reapproved&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP_UPdate1&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802214&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;064727108&lt;/item&gt;&lt;tsl_consumer_unit&gt;265389479&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;016407285&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;1&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;2&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.99&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP_Update1&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690952&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.reapproved&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP_UPdate1&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802214&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;063165054&lt;/item&gt;&lt;tsl_consumer_unit&gt;259661056&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;014685527&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_was_price&gt;0.29&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;1.29&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.28&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		PromotionMessageRouter promotionMessageRouterAfterMod = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);

		promotionMessageRouterAfterMod.route(modData);

		PromotionEntity promotionEntityAfterMod = (PromotionEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class);
		PromotionMasterEntity promotionMasterEntityMod = (PromotionMasterEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg, PromotionMasterEntity.class);

		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));

		Assert.assertNotNull(promotionMasterEntityMod);
		Assert.assertNotSame(promotionEntityAfterMod, promotionEntity);
		deleteDocs(masterKey, key, dtlIds, null);

	}

	@Test
	public void testProcessThresholdModNewHierarchyAdditionPromotionsFromMsg()
			throws IOException, MessageRouterException, ProductEncodeException,
			DataAccessException {

		String offerIdFromMsg = "31697456";
		String locType = "Z";
		String locRef = "5";
		String dtlId1 = "38838805";
		String dtlId2 = "38838811";
		String dtlId3 = "38838812";
		String dtlId4 = "38838813";

		String hierkey1 = "PROMOHIER_"
				+ PriceUtility.convertRMStoTesco("345", "2", "20");
		String hierkey2 = "PROMOHIER_"
				+ PriceUtility.convertRMStoTesco("1045", "11", "1");
		String hierkey3 = "PROMOHIER_"
				+ PriceUtility.convertRMStoTesco("1045", "12", "2");
		String hierkey4 = "PROMOHIER_"
				+ PriceUtility.convertRMStoTesco("1045", "11", "1");

		List dtlIds = new ArrayList();
		dtlIds.add(dtlId1);
		dtlIds.add(dtlId2);
		dtlIds.add(dtlId3);
		dtlIds.add(dtlId4);

		List hierkeys = new ArrayList();
		hierkeys.add(hierkey1);
		hierkeys.add(hierkey2);
		hierkeys.add(hierkey3);
		hierkeys.add(hierkey4);

		String masterKey = PriceConstants.PROMOTION_DOC_KEY_PREFIX
				+ offerIdFromMsg;
		String key = PriceConstants.PROMOTION_DOC_KEY_PREFIX + offerIdFromMsg
				+ "_" + locType + locRef;
		String compDtlId1 = "PROMO_COMP_DETAIL_ID_" + dtlId1;
		String compDtlId2 = "PROMO_COMP_DETAIL_ID_" + dtlId2;
		String compDtlId3 = "PROMO_COMP_DETAIL_ID_" + dtlId3;
		String compDtlId4 = "PROMO_COMP_DETAIL_ID_" + dtlId4;

		deleteDocs(masterKey, key, dtlIds, hierkeys);

		String credata = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.06.24 14:26:13.719|237</ribmessageID>\n"
				+ "<publishTime>2015-06-29 11:38:57.055 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1555356&lt;/promo_id&gt;&lt;promo_name&gt;promo&lt;/promo_name&gt;&lt;promo_description&gt;test&lt;/promo_description&gt;&lt;promo_comp_id&gt;120814&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;test&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;38838805&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;29&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;1&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;28&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;till&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31697456&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;\n"
				+ "&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;1&lt;/merch_type&gt;&lt;dept&gt;345&lt;/dept&gt;&lt;class&gt;2&lt;/class&gt;&lt;subclass&gt;20&lt;/subclass&gt;&lt;threshold_id&gt;472348&lt;/threshold_id&gt;&lt;threshold_name&gt;test&lt;/threshold_name&gt;&lt;qualification_type&gt;0&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_comp_detail_level_desc&gt;test&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;4&lt;/threshold_value&gt;&lt;prm_chg_value&gt;0.1&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1555356&lt;/promo_id&gt;&lt;promo_name&gt;promo&lt;/promo_name&gt;&lt;promo_description&gt;test&lt;/promo_description&gt;&lt;promo_comp_id&gt;120814&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;test&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;38838811&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;29&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;1&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;28&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;till&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31697456&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;\n"
				+ "&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;1&lt;/merch_type&gt;&lt;dept&gt;1045&lt;/dept&gt;&lt;class&gt;11&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;threshold_id&gt;472348&lt;/threshold_id&gt;&lt;threshold_name&gt;test&lt;/threshold_name&gt;&lt;qualification_type&gt;0&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_comp_detail_level_desc&gt;test&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;4&lt;/threshold_value&gt;&lt;prm_chg_value&gt;0.1&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(credata);
		PromotionEntity promotionEntity = (PromotionEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class);
		PromotionMasterEntity promotionMasterEntity = (PromotionMasterEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg, PromotionMasterEntity.class);

		String modData = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.06.24 14:26:13.719|237</ribmessageID>\n"
				+ "<publishTime>2015-06-29 11:38:57.055 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1555356&lt;/promo_id&gt;&lt;promo_name&gt;promo&lt;/promo_name&gt;&lt;promo_description&gt;test&lt;/promo_description&gt;&lt;promo_comp_id&gt;120814&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;test&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;38838812&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;29&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;1&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;28&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;till&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31697456&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;\n"
				+ "&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;1&lt;/merch_type&gt;&lt;dept&gt;1045&lt;/dept&gt;&lt;class&gt;12&lt;/class&gt;&lt;subclass&gt;2&lt;/subclass&gt;&lt;threshold_id&gt;472348&lt;/threshold_id&gt;&lt;threshold_name&gt;test&lt;/threshold_name&gt;&lt;qualification_type&gt;0&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_comp_detail_level_desc&gt;test&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;4&lt;/threshold_value&gt;&lt;prm_chg_value&gt;0.1&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1555356&lt;/promo_id&gt;&lt;promo_name&gt;promo&lt;/promo_name&gt;&lt;promo_description&gt;test&lt;/promo_description&gt;&lt;promo_comp_id&gt;120814&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;test&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;38838813&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;29&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;1&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;28&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;till&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31697456&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;\n"
				+ "&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;1&lt;/merch_type&gt;&lt;dept&gt;1045&lt;/dept&gt;&lt;class&gt;11&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;threshold_id&gt;472348&lt;/threshold_id&gt;&lt;threshold_name&gt;test&lt;/threshold_name&gt;&lt;qualification_type&gt;0&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_comp_detail_level_desc&gt;test&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;4&lt;/threshold_value&gt;&lt;prm_chg_value&gt;0.1&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		PromotionMessageRouter promotionMessageRouterAfterMod = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);

		promotionMessageRouterAfterMod.route(modData);

		PromotionEntity promotionEntityAfterMod = (PromotionEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class);
		PromotionMasterEntity promotionMasterEntityMod = (PromotionMasterEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg, PromotionMasterEntity.class);

		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));

		Assert.assertNotNull(repositoryImpl.getGenericObject(hierkey1,PromotionEntity.class));

		Assert.assertNotNull(repositoryImpl.getGenericObject(hierkey2,PromotionEntity.class));

		Assert.assertNotNull(repositoryImpl.getGenericObject(hierkey3,PromotionEntity.class));

		Assert.assertNotNull(repositoryImpl.getGenericObject(hierkey4,PromotionEntity.class));

		Assert.assertNotNull(promotionMasterEntityMod);
		Assert.assertNotSame(promotionEntityAfterMod, promotionEntity);
		deleteDocs(masterKey, key, dtlIds, hierkeys);

	}

	@Test
	public void testProcessThresholdModNewHierarchyAdditionWithexistingPromotionsFromMsg()
			throws IOException, MessageRouterException, ProductEncodeException,
			DataAccessException {

		String offerIdFromMsg = "31697456";
		String locType = "Z";
		String locRef = "5";
		String dtlId1 = "38838805";
		String dtlId2 = "38838811";
		String dtlId3 = "38838812";
		String dtlId4 = "38838813";

		String hierkey1 = "PROMOHIER_"
				+ PriceUtility.convertRMStoTesco("345", "2", "20");
		String hierkey2 = "PROMOHIER_"
				+ PriceUtility.convertRMStoTesco("1045", "11", "1");
		String hierkey3 = "PROMOHIER_"
				+ PriceUtility.convertRMStoTesco("1045", "12", "2");
		String hierkey4 = "PROMOHIER_"
				+ PriceUtility.convertRMStoTesco("1045", "11", "1");
		;

		List dtlIds = new ArrayList();
		dtlIds.add(dtlId1);
		dtlIds.add(dtlId2);
		dtlIds.add(dtlId3);
		dtlIds.add(dtlId4);

		List hierkeys = new ArrayList();
		hierkeys.add(hierkey1);
		hierkeys.add(hierkey2);
		hierkeys.add(hierkey3);
		hierkeys.add(hierkey4);

		String masterKey = PriceConstants.PROMOTION_DOC_KEY_PREFIX
				+ offerIdFromMsg;
		String key = PriceConstants.PROMOTION_DOC_KEY_PREFIX + offerIdFromMsg
				+ "_" + locType + locRef;
		String compDtlId1 = "PROMO_COMP_DETAIL_ID_" + dtlId1;
		String compDtlId2 = "PROMO_COMP_DETAIL_ID_" + dtlId2;
		String compDtlId3 = "PROMO_COMP_DETAIL_ID_" + dtlId3;
		String compDtlId4 = "PROMO_COMP_DETAIL_ID_" + dtlId4;

		deleteDocs(masterKey, key, dtlIds, hierkeys);

		String credata = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.06.24 14:26:13.719|237</ribmessageID>\n"
				+ "<publishTime>2015-06-29 11:38:57.055 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1555356&lt;/promo_id&gt;&lt;promo_name&gt;promo&lt;/promo_name&gt;&lt;promo_description&gt;test&lt;/promo_description&gt;&lt;promo_comp_id&gt;120814&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;test&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;38838805&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;29&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;1&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;28&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;till&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31697456&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;\n"
				+ "&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;1&lt;/merch_type&gt;&lt;dept&gt;345&lt;/dept&gt;&lt;class&gt;2&lt;/class&gt;&lt;subclass&gt;20&lt;/subclass&gt;&lt;threshold_id&gt;472348&lt;/threshold_id&gt;&lt;threshold_name&gt;test&lt;/threshold_name&gt;&lt;qualification_type&gt;0&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_comp_detail_level_desc&gt;test&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;4&lt;/threshold_value&gt;&lt;prm_chg_value&gt;0.1&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1555356&lt;/promo_id&gt;&lt;promo_name&gt;promo&lt;/promo_name&gt;&lt;promo_description&gt;test&lt;/promo_description&gt;&lt;promo_comp_id&gt;120814&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;test&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;38838811&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;29&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;1&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;28&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;till&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31697456&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;\n"
				+ "&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;1&lt;/merch_type&gt;&lt;dept&gt;1045&lt;/dept&gt;&lt;class&gt;11&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;threshold_id&gt;472348&lt;/threshold_id&gt;&lt;threshold_name&gt;test&lt;/threshold_name&gt;&lt;qualification_type&gt;0&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_comp_detail_level_desc&gt;test&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;4&lt;/threshold_value&gt;&lt;prm_chg_value&gt;0.1&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(credata);
		PromotionEntity promotionEntity = (PromotionEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class);
		PromotionMasterEntity promotionMasterEntity = (PromotionMasterEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg, PromotionMasterEntity.class);

		String modData = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.06.24 14:26:13.719|237</ribmessageID>\n"
				+ "<publishTime>2015-06-29 11:38:57.055 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1555356&lt;/promo_id&gt;&lt;promo_name&gt;promo&lt;/promo_name&gt;&lt;promo_description&gt;test&lt;/promo_description&gt;&lt;promo_comp_id&gt;120814&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;test&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;38838805&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;29&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;1&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;28&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;till&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31697456&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;\n"
				+ "&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;1&lt;/merch_type&gt;&lt;dept&gt;345&lt;/dept&gt;&lt;class&gt;2&lt;/class&gt;&lt;subclass&gt;20&lt;/subclass&gt;&lt;threshold_id&gt;472348&lt;/threshold_id&gt;&lt;threshold_name&gt;test&lt;/threshold_name&gt;&lt;qualification_type&gt;0&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_comp_detail_level_desc&gt;test&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;4&lt;/threshold_value&gt;&lt;prm_chg_value&gt;0.1&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1555356&lt;/promo_id&gt;&lt;promo_name&gt;promo&lt;/promo_name&gt;&lt;promo_description&gt;test&lt;/promo_description&gt;&lt;promo_comp_id&gt;120814&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;test&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;38838813&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;29&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;1&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;28&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;till&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31697456&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;\n"
				+ "&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;1&lt;/merch_type&gt;&lt;dept&gt;1045&lt;/dept&gt;&lt;class&gt;11&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;threshold_id&gt;472348&lt;/threshold_id&gt;&lt;threshold_name&gt;test&lt;/threshold_name&gt;&lt;qualification_type&gt;0&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_comp_detail_level_desc&gt;test&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;4&lt;/threshold_value&gt;&lt;prm_chg_value&gt;0.1&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		PromotionMessageRouter promotionMessageRouterAfterMod = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);

		promotionMessageRouterAfterMod.route(modData);

		PromotionEntity promotionEntityAfterMod = (PromotionEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class);
		PromotionMasterEntity promotionMasterEntityMod = (PromotionMasterEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg, PromotionMasterEntity.class);

		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));

		Assert.assertNotNull(repositoryImpl.getGenericObject(hierkey1,PromotionEntity.class));

		Assert.assertNotNull(repositoryImpl.getGenericObject(hierkey2,PromotionEntity.class));

		Assert.assertNull(repositoryImpl.getGenericObject(hierkey3,PromotionEntity.class));

		Assert.assertNotNull(repositoryImpl.getGenericObject(hierkey4,PromotionEntity.class));

		Assert.assertNotNull(promotionMasterEntityMod);
		Assert.assertNotSame(promotionEntityAfterMod, promotionEntity);
		deleteDocs(masterKey, key, dtlIds, hierkeys);

	}

	@Test
	public void testProcessThresholdModNewHierarchyAdditionPromotionsFromMsgWhenSubclassIsNull()
			throws IOException, MessageRouterException, ProductEncodeException,
			DataAccessException {

		String offerIdFromMsg = "31697456";
		String locType = "Z";
		String locRef = "5";
		String dtlId1 = "38838805";
		String dtlId2 = "38838811";
		String dtlId3 = "38838812";
		String dtlId4 = "38838813";

		String hierkey1 = "PROMOHIER_"
				+ PriceUtility.convertRMStoTesco("345", "2", "20");
		String hierkey2 = "PROMOHIER_"
				+ PriceUtility.convertRMStoTesco("1045", "11", "1");
		String hierkey3 = "PROMOHIER_"
				+ PriceUtility.convertRMStoTesco("1045", "12", null);
		String hierkey4 = "PROMOHIER_"
				+ PriceUtility.convertRMStoTesco("1045", "11", null);

		List dtlIds = new ArrayList();
		dtlIds.add(dtlId1);
		dtlIds.add(dtlId2);
		dtlIds.add(dtlId3);
		dtlIds.add(dtlId4);

		List hierkeys = new ArrayList();
		hierkeys.add(hierkey1);
		hierkeys.add(hierkey2);
		hierkeys.add(hierkey3);
		hierkeys.add(hierkey4);

		String masterKey = PriceConstants.PROMOTION_DOC_KEY_PREFIX
				+ offerIdFromMsg;
		String key = PriceConstants.PROMOTION_DOC_KEY_PREFIX + offerIdFromMsg
				+ "_" + locType + locRef;
		String compDtlId1 = "PROMO_COMP_DETAIL_ID_" + dtlId1;
		String compDtlId2 = "PROMO_COMP_DETAIL_ID_" + dtlId2;
		String compDtlId3 = "PROMO_COMP_DETAIL_ID_" + dtlId3;
		String compDtlId4 = "PROMO_COMP_DETAIL_ID_" + dtlId4;

		deleteDocs(masterKey, key, dtlIds, hierkeys);

		String credata = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.06.24 14:26:13.719|237</ribmessageID>\n"
				+ "<publishTime>2015-06-29 11:38:57.055 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1555356&lt;/promo_id&gt;&lt;promo_name&gt;promo&lt;/promo_name&gt;&lt;promo_description&gt;test&lt;/promo_description&gt;&lt;promo_comp_id&gt;120814&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;test&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;38838805&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;29&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;1&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;28&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;till&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31697456&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;\n"
				+ "&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;1&lt;/merch_type&gt;&lt;dept&gt;345&lt;/dept&gt;&lt;class&gt;2&lt;/class&gt;&lt;subclass&gt;20&lt;/subclass&gt;&lt;threshold_id&gt;472348&lt;/threshold_id&gt;&lt;threshold_name&gt;test&lt;/threshold_name&gt;&lt;qualification_type&gt;0&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_comp_detail_level_desc&gt;test&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;4&lt;/threshold_value&gt;&lt;prm_chg_value&gt;0.1&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1555356&lt;/promo_id&gt;&lt;promo_name&gt;promo&lt;/promo_name&gt;&lt;promo_description&gt;test&lt;/promo_description&gt;&lt;promo_comp_id&gt;120814&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;test&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;38838811&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;29&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;1&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;28&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;till&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31697456&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;\n"
				+ "&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;1&lt;/merch_type&gt;&lt;dept&gt;1045&lt;/dept&gt;&lt;class&gt;11&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;threshold_id&gt;472348&lt;/threshold_id&gt;&lt;threshold_name&gt;test&lt;/threshold_name&gt;&lt;qualification_type&gt;0&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_comp_detail_level_desc&gt;test&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;4&lt;/threshold_value&gt;&lt;prm_chg_value&gt;0.1&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(credata);
		PromotionEntity promotionEntity = (PromotionEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class);
		PromotionMasterEntity promotionMasterEntity = (PromotionMasterEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg, PromotionMasterEntity.class);

		String modData = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.06.24 14:26:13.719|237</ribmessageID>\n"
				+ "<publishTime>2015-06-29 11:38:57.055 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1555356&lt;/promo_id&gt;&lt;promo_name&gt;promo&lt;/promo_name&gt;&lt;promo_description&gt;test&lt;/promo_description&gt;&lt;promo_comp_id&gt;120814&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;test&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;38838812&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;29&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;1&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;28&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;till&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31697456&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;\n"
				+ "&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;1&lt;/merch_type&gt;&lt;dept&gt;1045&lt;/dept&gt;&lt;class&gt;12&lt;/class&gt;&lt;threshold_id&gt;472348&lt;/threshold_id&gt;&lt;threshold_name&gt;test&lt;/threshold_name&gt;&lt;qualification_type&gt;0&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_comp_detail_level_desc&gt;test&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;4&lt;/threshold_value&gt;&lt;prm_chg_value&gt;0.1&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1555356&lt;/promo_id&gt;&lt;promo_name&gt;promo&lt;/promo_name&gt;&lt;promo_description&gt;test&lt;/promo_description&gt;&lt;promo_comp_id&gt;120814&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;test&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;38838813&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;29&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;1&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;28&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;till&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31697456&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;\n"
				+ "&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;1&lt;/merch_type&gt;&lt;dept&gt;1045&lt;/dept&gt;&lt;class&gt;11&lt;/class&gt;&lt;threshold_id&gt;472348&lt;/threshold_id&gt;&lt;threshold_name&gt;test&lt;/threshold_name&gt;&lt;qualification_type&gt;0&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_comp_detail_level_desc&gt;test&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;4&lt;/threshold_value&gt;&lt;prm_chg_value&gt;0.1&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		PromotionMessageRouter promotionMessageRouterAfterMod = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);

		promotionMessageRouterAfterMod.route(modData);

		PromotionEntity promotionEntityAfterMod = (PromotionEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class);
		PromotionMasterEntity promotionMasterEntityMod = (PromotionMasterEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg, PromotionMasterEntity.class);

		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));

		Assert.assertNotNull(repositoryImpl.getGenericObject(hierkey1,PromotionEntity.class));

		Assert.assertNotNull(repositoryImpl.getGenericObject(hierkey2,PromotionEntity.class));

		Assert.assertNotNull(repositoryImpl.getGenericObject(hierkey3,PromotionEntity.class));

		Assert.assertNotNull(repositoryImpl.getGenericObject(hierkey4,PromotionEntity.class));

		Assert.assertNotNull(promotionMasterEntityMod);
		Assert.assertNotSame(promotionEntityAfterMod, promotionEntity);
		deleteDocs(masterKey, key, dtlIds, hierkeys);

	}

	@Test
	public void testProcessThresholdModNewHierarchyAdditionPromotionsFromMsgWhenClassIsNull()
			throws IOException, MessageRouterException, ProductEncodeException,
			DataAccessException {

		String offerIdFromMsg = "31697456";
		String locType = "Z";
		String locRef = "5";
		String dtlId1 = "38838805";
		String dtlId2 = "38838811";
		String dtlId3 = "38838812";
		String dtlId4 = "38838813";

		String hierkey1 = "PROMOHIER_"
				+ PriceUtility.convertRMStoTesco("345", "2", "20");
		String hierkey2 = "PROMOHIER_"
				+ PriceUtility.convertRMStoTesco("1045", "11", "1");
		String hierkey3 = "PROMOHIER_"
				+ PriceUtility.convertRMStoTesco("1045", null, null);
		String hierkey4 = "PROMOHIER_"
				+ PriceUtility.convertRMStoTesco("1045", null, null);

		List dtlIds = new ArrayList();
		dtlIds.add(dtlId1);
		dtlIds.add(dtlId2);
		dtlIds.add(dtlId3);
		dtlIds.add(dtlId4);

		List hierkeys = new ArrayList();
		hierkeys.add(hierkey1);
		hierkeys.add(hierkey2);
		hierkeys.add(hierkey3);
		hierkeys.add(hierkey4);

		String masterKey = PriceConstants.PROMOTION_DOC_KEY_PREFIX
				+ offerIdFromMsg;
		String key = PriceConstants.PROMOTION_DOC_KEY_PREFIX + offerIdFromMsg
				+ "_" + locType + locRef;
		String compDtlId1 = "PROMO_COMP_DETAIL_ID_" + dtlId1;
		String compDtlId2 = "PROMO_COMP_DETAIL_ID_" + dtlId2;
		String compDtlId3 = "PROMO_COMP_DETAIL_ID_" + dtlId3;
		String compDtlId4 = "PROMO_COMP_DETAIL_ID_" + dtlId4;

		deleteDocs(masterKey, key, dtlIds, hierkeys);

		String credata = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.06.24 14:26:13.719|237</ribmessageID>\n"
				+ "<publishTime>2015-06-29 11:38:57.055 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1555356&lt;/promo_id&gt;&lt;promo_name&gt;promo&lt;/promo_name&gt;&lt;promo_description&gt;test&lt;/promo_description&gt;&lt;promo_comp_id&gt;120814&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;test&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;38838805&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;29&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;1&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;28&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;till&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31697456&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;\n"
				+ "&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;1&lt;/merch_type&gt;&lt;dept&gt;345&lt;/dept&gt;&lt;class&gt;2&lt;/class&gt;&lt;subclass&gt;20&lt;/subclass&gt;&lt;threshold_id&gt;472348&lt;/threshold_id&gt;&lt;threshold_name&gt;test&lt;/threshold_name&gt;&lt;qualification_type&gt;0&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_comp_detail_level_desc&gt;test&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;4&lt;/threshold_value&gt;&lt;prm_chg_value&gt;0.1&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1555356&lt;/promo_id&gt;&lt;promo_name&gt;promo&lt;/promo_name&gt;&lt;promo_description&gt;test&lt;/promo_description&gt;&lt;promo_comp_id&gt;120814&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;test&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;38838811&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;29&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;1&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;28&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;till&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31697456&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;\n"
				+ "&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;1&lt;/merch_type&gt;&lt;dept&gt;1045&lt;/dept&gt;&lt;class&gt;11&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;threshold_id&gt;472348&lt;/threshold_id&gt;&lt;threshold_name&gt;test&lt;/threshold_name&gt;&lt;qualification_type&gt;0&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_comp_detail_level_desc&gt;test&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;4&lt;/threshold_value&gt;&lt;prm_chg_value&gt;0.1&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(credata);
		PromotionEntity promotionEntity = (PromotionEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class);
		PromotionMasterEntity promotionMasterEntity = (PromotionMasterEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg, PromotionMasterEntity.class);

		String modData = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.06.24 14:26:13.719|237</ribmessageID>\n"
				+ "<publishTime>2015-06-29 11:38:57.055 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1555356&lt;/promo_id&gt;&lt;promo_name&gt;promo&lt;/promo_name&gt;&lt;promo_description&gt;test&lt;/promo_description&gt;&lt;promo_comp_id&gt;120814&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;test&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;38838812&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;29&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;1&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;28&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;till&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31697456&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;\n"
				+ "&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;1&lt;/merch_type&gt;&lt;dept&gt;1045&lt;/dept&gt;&lt;threshold_id&gt;472348&lt;/threshold_id&gt;&lt;threshold_name&gt;test&lt;/threshold_name&gt;&lt;qualification_type&gt;0&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_comp_detail_level_desc&gt;test&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;4&lt;/threshold_value&gt;&lt;prm_chg_value&gt;0.1&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1555356&lt;/promo_id&gt;&lt;promo_name&gt;promo&lt;/promo_name&gt;&lt;promo_description&gt;test&lt;/promo_description&gt;&lt;promo_comp_id&gt;120814&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;test&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;38838813&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;29&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;1&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;28&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;till&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31697456&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;\n"
				+ "&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;1&lt;/merch_type&gt;&lt;dept&gt;1045&lt;/dept&gt;&lt;threshold_id&gt;472348&lt;/threshold_id&gt;&lt;threshold_name&gt;test&lt;/threshold_name&gt;&lt;qualification_type&gt;0&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_comp_detail_level_desc&gt;test&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;4&lt;/threshold_value&gt;&lt;prm_chg_value&gt;0.1&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		PromotionMessageRouter promotionMessageRouterAfterMod = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);

		promotionMessageRouterAfterMod.route(modData);

		PromotionEntity promotionEntityAfterMod = (PromotionEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class);
		PromotionMasterEntity promotionMasterEntityMod = (PromotionMasterEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg, PromotionMasterEntity.class);

		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));

		Assert.assertNotNull(repositoryImpl.getGenericObject(hierkey1,PromotionEntity.class));

		Assert.assertNotNull(repositoryImpl.getGenericObject(hierkey2,PromotionEntity.class));

		Assert.assertNotNull(repositoryImpl.getGenericObject(hierkey3,PromotionEntity.class));

		Assert.assertNotNull(repositoryImpl.getGenericObject(hierkey4,PromotionEntity.class));

		Assert.assertNotNull(promotionMasterEntityMod);
		Assert.assertNotSame(promotionEntityAfterMod, promotionEntity);
		deleteDocs(masterKey, key, dtlIds, hierkeys);

	}

	@Test
	public void testProcessThresholdModHierarchyForDescAmendment()
			throws IOException, MessageRouterException, ProductEncodeException,
			DataAccessException {

		String offerIdFromMsg = "31697456";
		String locType = "Z";
		String locRef = "5";
		String dtlId1 = "38838805";
		String dtlId2 = "38838811";
		String dtlId3 = "38838812";
		String dtlId4 = "38838813";

		String hierkey1 = "PROMOHIER_"
				+ PriceUtility.convertRMStoTesco("345", "2", "20");
		String hierkey2 = "PROMOHIER_"
				+ PriceUtility.convertRMStoTesco("1045", "11", "1");
		String hierkey3 = "PROMOHIER_"
				+ PriceUtility.convertRMStoTesco("1045", "12", "2");
		String hierkey4 = "PROMOHIER_"
				+ PriceUtility.convertRMStoTesco("1045", "11", "1");
		;

		List dtlIds = new ArrayList();
		dtlIds.add(dtlId1);
		dtlIds.add(dtlId2);
		dtlIds.add(dtlId3);
		dtlIds.add(dtlId4);

		List hierkeys = new ArrayList();
		hierkeys.add(hierkey1);
		hierkeys.add(hierkey2);
		hierkeys.add(hierkey3);
		hierkeys.add(hierkey4);

		String masterKey = PriceConstants.PROMOTION_DOC_KEY_PREFIX
				+ offerIdFromMsg;
		String key = PriceConstants.PROMOTION_DOC_KEY_PREFIX + offerIdFromMsg
				+ "_" + locType + locRef;
		String compDtlId1 = "PROMO_COMP_DETAIL_ID_" + dtlId1;
		String compDtlId2 = "PROMO_COMP_DETAIL_ID_" + dtlId2;
		String compDtlId3 = "PROMO_COMP_DETAIL_ID_" + dtlId3;
		String compDtlId4 = "PROMO_COMP_DETAIL_ID_" + dtlId4;

		deleteDocs(masterKey, key, dtlIds, hierkeys);

		String credata = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.06.24 14:26:13.719|237</ribmessageID>\n"
				+ "<publishTime>2015-06-29 11:38:57.055 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1555356&lt;/promo_id&gt;&lt;promo_name&gt;promo&lt;/promo_name&gt;&lt;promo_description&gt;test&lt;/promo_description&gt;&lt;promo_comp_id&gt;120814&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;test&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;38838805&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;29&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;1&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;28&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;till&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31697456&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;\n"
				+ "&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;1&lt;/merch_type&gt;&lt;dept&gt;345&lt;/dept&gt;&lt;class&gt;2&lt;/class&gt;&lt;subclass&gt;20&lt;/subclass&gt;&lt;threshold_id&gt;472348&lt;/threshold_id&gt;&lt;threshold_name&gt;test&lt;/threshold_name&gt;&lt;qualification_type&gt;0&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_comp_detail_level_desc&gt;test&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;4&lt;/threshold_value&gt;&lt;prm_chg_value&gt;0.1&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1555356&lt;/promo_id&gt;&lt;promo_name&gt;promo&lt;/promo_name&gt;&lt;promo_description&gt;test&lt;/promo_description&gt;&lt;promo_comp_id&gt;120814&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;test&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;38838811&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;29&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;1&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;28&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;till&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31697456&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;\n"
				+ "&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;1&lt;/merch_type&gt;&lt;dept&gt;1045&lt;/dept&gt;&lt;class&gt;11&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;threshold_id&gt;472348&lt;/threshold_id&gt;&lt;threshold_name&gt;test&lt;/threshold_name&gt;&lt;qualification_type&gt;0&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_comp_detail_level_desc&gt;test&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;4&lt;/threshold_value&gt;&lt;prm_chg_value&gt;0.1&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(credata);
		PromotionEntity promotionEntity = (PromotionEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class);
		PromotionMasterEntity promotionMasterEntity = (PromotionMasterEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg, PromotionMasterEntity.class);

		String modData = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGMOD</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.06.24 14:26:13.719|237</ribmessageID>\n"
				+ "<publishTime>2015-06-29 11:38:57.055 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1555356&lt;/promo_id&gt;&lt;promo_name&gt;promo&lt;/promo_name&gt;&lt;promo_description&gt;test&lt;/promo_description&gt;&lt;promo_comp_id&gt;120814&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;test&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;38838805&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;29&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;1&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;28&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;till_Threshold&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31697456&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;\n"
				+ "&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;1&lt;/merch_type&gt;&lt;dept&gt;345&lt;/dept&gt;&lt;class&gt;2&lt;/class&gt;&lt;subclass&gt;20&lt;/subclass&gt;&lt;threshold_id&gt;472348&lt;/threshold_id&gt;&lt;threshold_name&gt;test&lt;/threshold_name&gt;&lt;qualification_type&gt;0&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_comp_detail_level_desc&gt;test&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;4&lt;/threshold_value&gt;&lt;prm_chg_value&gt;0.1&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1555356&lt;/promo_id&gt;&lt;promo_name&gt;promo&lt;/promo_name&gt;&lt;promo_description&gt;test&lt;/promo_description&gt;&lt;promo_comp_id&gt;120814&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;test&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;38838811&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;29&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2028&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;1&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;28&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;till_Threshold&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31697456&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;\n"
				+ "&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;1&lt;/merch_type&gt;&lt;dept&gt;1045&lt;/dept&gt;&lt;class&gt;11&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;threshold_id&gt;472348&lt;/threshold_id&gt;&lt;threshold_name&gt;test&lt;/threshold_name&gt;&lt;qualification_type&gt;0&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_comp_detail_level_desc&gt;test&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;4&lt;/threshold_value&gt;&lt;prm_chg_value&gt;0.1&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		PromotionMessageRouter promotionMessageRouterAfterMod = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);

		promotionMessageRouterAfterMod.route(modData);

		PromotionEntity promotionEntityAfterMod = (PromotionEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class);
		PromotionMasterEntity promotionMasterEntityMod = (PromotionMasterEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg, PromotionMasterEntity.class);

		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));

		Assert.assertNotNull(repositoryImpl.getGenericObject(hierkey1,PromotionEntity.class));

		Assert.assertNotNull(repositoryImpl.getGenericObject(hierkey2,PromotionEntity.class));

		Assert.assertNull(repositoryImpl.getGenericObject(hierkey3,PromotionEntity.class));

		Assert.assertNotNull(repositoryImpl.getGenericObject(hierkey4,PromotionEntity.class));

		Assert.assertNotNull(promotionMasterEntityMod);
		Assert.assertNotSame(promotionEntityAfterMod, promotionEntity);
		deleteDocs(masterKey, key, dtlIds, hierkeys);

	}

	@Test
	public void testProcessThresholdModAdditionofItemwithExistingItemPromotionsFromMsg()
			throws IOException, MessageRouterException, ProductEncodeException,
			DataAccessException {

		String offerIdFromMsg = "31802200";
		String locType = "Z";
		String locRef = "5";
		String dtlId1 = "40690868";
		String dtlId2 = "40690867";
		String dtlId3 = "40690899";
		List dtlIds = new ArrayList();
		dtlIds.add(dtlId1);
		dtlIds.add(dtlId2);
		dtlIds.add(dtlId3);

		String masterKey = PriceConstants.PROMOTION_DOC_KEY_PREFIX
				+ offerIdFromMsg;
		String key = PriceConstants.PROMOTION_DOC_KEY_PREFIX + offerIdFromMsg
				+ "_" + locType + locRef;

		deleteDocs(masterKey, key, dtlIds, null);

		String credata = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<publishetname />\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.08.04 13:42:17.070|73</ribmessageID>\n"
				+ "<publishTime>2015-08-04 13:42:17.070 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569746&lt;/promo_id&gt;&lt;promo_name&gt;TH_PO&lt;/promo_name&gt;&lt;promo_comp_id&gt;228176&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;TH_PO&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690868&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2020&lt;/year&gt;&lt;month&gt;11&lt;/month&gt;&lt;day&gt;23&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2020&lt;/year&gt;&lt;month&gt;11&lt;/month&gt;&lt;day&gt;24&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1719&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;TH_PO&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802200&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;064727108&lt;/item&gt;&lt;tsl_consumer_unit&gt;265389479&lt;/tsl_consumer_unit&gt;&lt;threshold_id&gt;470513&lt;/threshold_id&gt;&lt;threshold_name&gt;3 for 25% Off&lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;P&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;016407285&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;TH_PO&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;A0000041&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_pos_description1&gt;TH_PO_POS&lt;/tsl_pos_description1&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;3&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-0.25&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569746&lt;/promo_id&gt;&lt;promo_name&gt;TH_PO&lt;/promo_name&gt;&lt;promo_comp_id&gt;228176&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;TH_PO&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690867&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2020&lt;/year&gt;&lt;month&gt;11&lt;/month&gt;&lt;day&gt;23&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2020&lt;/year&gt;&lt;month&gt;11&lt;/month&gt;&lt;day&gt;24&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1719&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;TH_PO&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802200&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;063165054&lt;/item&gt;&lt;tsl_consumer_unit&gt;259661056&lt;/tsl_consumer_unit&gt;&lt;threshold_id&gt;470513&lt;/threshold_id&gt;&lt;threshold_name&gt;3 for 25% Off&lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;P&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;014685527&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;TH_PO&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;A0000041&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_pos_description1&gt;TH_PO_POS&lt;/tsl_pos_description1&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;3&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-0.25&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData />\n" + "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n" + "</RibMessages>";

		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(credata);
		PromotionEntity promotionEntity = (PromotionEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class);

		String modData = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<publishetname />\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.08.04 13:42:17.070|73</ribmessageID>\n"
				+ "<publishTime>2015-08-04 13:42:17.070 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569746&lt;/promo_id&gt;&lt;promo_name&gt;TH_PO&lt;/promo_name&gt;&lt;promo_comp_id&gt;228176&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;TH_PO&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690868&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2020&lt;/year&gt;&lt;month&gt;11&lt;/month&gt;&lt;day&gt;23&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2020&lt;/year&gt;&lt;month&gt;11&lt;/month&gt;&lt;day&gt;24&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1719&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;TH_PO&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802200&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;064727108&lt;/item&gt;&lt;tsl_consumer_unit&gt;265389479&lt;/tsl_consumer_unit&gt;&lt;threshold_id&gt;470513&lt;/threshold_id&gt;&lt;threshold_name&gt;3 for 25% Off&lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;P&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;016407285&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;TH_PO&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;A0000041&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_pos_description1&gt;TH_PO_POS&lt;/tsl_pos_description1&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;3&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-0.25&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569746&lt;/promo_id&gt;&lt;promo_name&gt;TH_PO&lt;/promo_name&gt;&lt;promo_comp_id&gt;228176&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;TH_PO&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690899&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2020&lt;/year&gt;&lt;month&gt;11&lt;/month&gt;&lt;day&gt;23&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2020&lt;/year&gt;&lt;month&gt;11&lt;/month&gt;&lt;day&gt;24&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1719&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;TH_PO&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802200&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;050000016&lt;/item&gt;&lt;tsl_consumer_unit&gt;259661056&lt;/tsl_consumer_unit&gt;&lt;threshold_id&gt;470513&lt;/threshold_id&gt;&lt;threshold_name&gt;3 for 25% Off&lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;P&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;014685527&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;TH_PO&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;A0000041&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_pos_description1&gt;TH_PO_POS&lt;/tsl_pos_description1&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;3&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-0.25&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData />\n" + "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n" + "</RibMessages>";

		PromotionMessageRouter promotionMessageRouterAfterMod = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);

		promotionMessageRouterAfterMod.route(modData);

		PromotionEntity promotionEntityAfterMod = (PromotionEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class);
		PromotionMasterEntity promotionMasterEntityMod = (PromotionMasterEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg, PromotionMasterEntity.class);

		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));

		Assert.assertNotNull(promotionMasterEntityMod);
		Assert.assertNotSame(promotionEntityAfterMod, promotionEntity);

		deleteDocs(masterKey, key, dtlIds, null);

	}

	@Test
	public void testProcessThresholdModNewItemAdditionPromotionsFromMsg()
			throws IOException, MessageRouterException, ProductEncodeException,
			DataAccessException {

		String offerIdFromMsg = "31802200";
		String locType = "Z";
		String locRef = "5";
		String dtlId1 = "40690868";
		String dtlId2 = "40690867";
		String dtlId3 = "40690855";
		String dtlId4 = "40690844";
		List dtlIds = new ArrayList();
		dtlIds.add(dtlId1);
		dtlIds.add(dtlId2);
		dtlIds.add(dtlId3);
		dtlIds.add(dtlId4);

		String masterKey = PriceConstants.PROMOTION_DOC_KEY_PREFIX
				+ offerIdFromMsg;
		String key = PriceConstants.PROMOTION_DOC_KEY_PREFIX + offerIdFromMsg
				+ "_" + locType + locRef;

		deleteDocs(masterKey, key, dtlIds, null);

		String credata = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<publishetname />\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.08.04 13:42:17.070|73</ribmessageID>\n"
				+ "<publishTime>2015-08-04 13:42:17.070 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569746&lt;/promo_id&gt;&lt;promo_name&gt;TH_PO&lt;/promo_name&gt;&lt;promo_comp_id&gt;228176&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;TH_PO&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690868&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2020&lt;/year&gt;&lt;month&gt;11&lt;/month&gt;&lt;day&gt;23&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2020&lt;/year&gt;&lt;month&gt;11&lt;/month&gt;&lt;day&gt;24&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1719&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;TH_PO&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802200&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;064727108&lt;/item&gt;&lt;tsl_consumer_unit&gt;265389479&lt;/tsl_consumer_unit&gt;&lt;threshold_id&gt;470513&lt;/threshold_id&gt;&lt;threshold_name&gt;3 for 25% Off&lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;P&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;016407285&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;TH_PO&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;A0000041&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_pos_description1&gt;TH_PO_POS&lt;/tsl_pos_description1&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;3&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-0.25&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569746&lt;/promo_id&gt;&lt;promo_name&gt;TH_PO&lt;/promo_name&gt;&lt;promo_comp_id&gt;228176&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;TH_PO&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690867&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2020&lt;/year&gt;&lt;month&gt;11&lt;/month&gt;&lt;day&gt;23&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2020&lt;/year&gt;&lt;month&gt;11&lt;/month&gt;&lt;day&gt;24&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1719&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;TH_PO&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802200&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;063165054&lt;/item&gt;&lt;tsl_consumer_unit&gt;259661056&lt;/tsl_consumer_unit&gt;&lt;threshold_id&gt;470513&lt;/threshold_id&gt;&lt;threshold_name&gt;3 for 25% Off&lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;P&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;014685527&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;TH_PO&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;A0000041&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_pos_description1&gt;TH_PO_POS&lt;/tsl_pos_description1&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;3&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-0.25&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData />\n" + "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n" + "</RibMessages>";

		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(credata);
		PromotionEntity promotionEntity = (PromotionEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class);

		String modData = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<publishetname />\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.08.04 13:42:17.070|73</ribmessageID>\n"
				+ "<publishTime>2015-08-04 13:42:17.070 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569746&lt;/promo_id&gt;&lt;promo_name&gt;TH_PO&lt;/promo_name&gt;&lt;promo_comp_id&gt;228176&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;TH_PO&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690855&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2020&lt;/year&gt;&lt;month&gt;11&lt;/month&gt;&lt;day&gt;23&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2020&lt;/year&gt;&lt;month&gt;11&lt;/month&gt;&lt;day&gt;24&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1719&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;TH_PO&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802200&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;050000017&lt;/item&gt;&lt;tsl_consumer_unit&gt;265389479&lt;/tsl_consumer_unit&gt;&lt;threshold_id&gt;470513&lt;/threshold_id&gt;&lt;threshold_name&gt;3 for 25% Off&lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;P&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;016407285&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;TH_PO&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;A0000041&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_pos_description1&gt;TH_PO_POS&lt;/tsl_pos_description1&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;3&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-0.25&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569746&lt;/promo_id&gt;&lt;promo_name&gt;TH_PO&lt;/promo_name&gt;&lt;promo_comp_id&gt;228176&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;TH_PO&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690844&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2020&lt;/year&gt;&lt;month&gt;11&lt;/month&gt;&lt;day&gt;23&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2020&lt;/year&gt;&lt;month&gt;11&lt;/month&gt;&lt;day&gt;24&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1719&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;TH_PO&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802200&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;050000019&lt;/item&gt;&lt;tsl_consumer_unit&gt;259661056&lt;/tsl_consumer_unit&gt;&lt;threshold_id&gt;470513&lt;/threshold_id&gt;&lt;threshold_name&gt;3 for 25% Off&lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;P&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;014685527&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;TH_PO&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;A0000041&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_pos_description1&gt;TH_PO_POS&lt;/tsl_pos_description1&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;3&lt;/threshold_value&gt;&lt;prm_chg_value&gt;-0.25&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData />\n" + "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n" + "</RibMessages>";
		PromotionMessageRouter promotionMessageRouterAfterMod = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);

		promotionMessageRouterAfterMod.route(modData);

		PromotionEntity promotionEntityAfterMod = (PromotionEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class);
		PromotionMasterEntity promotionMasterEntityMod = (PromotionMasterEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg, PromotionMasterEntity.class);

		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));

		Assert.assertNotNull(promotionMasterEntityMod);
		Assert.assertNotSame(promotionEntityAfterMod, promotionEntity);
		deleteDocs(masterKey, key, dtlIds, null);
	}

	public void deleteDocs(String masterKey, String key, List compDtlIds,
			List hierkeys) {
		if (!Dockyard.isSpaceOrNull(masterKey)) {
			repositoryImpl.deleteProduct(masterKey);
		}
		repositoryImpl.deleteProduct(key);

		if (!Dockyard.isSpaceOrNull(compDtlIds)) {
			Iterator it = compDtlIds.iterator();
			while (it.hasNext()) {
				String dtlId = it.next().toString();
				repositoryImpl.deleteProduct(dtlId);
			}
		}

		if (!Dockyard.isSpaceOrNull(compDtlIds)) {
			Iterator it1 = compDtlIds.iterator();
			while (it1.hasNext()) {
				String hierkey = it1.next().toString();
				repositoryImpl.deleteProduct(hierkey);
			}
		}

	}

	@Test
	public void testProcessMultiBuyDelAfterCreMessage()
			throws ProductEncodeException, MessageRouterException,DataAccessException {

		String detailIdFromMsg = "30044016";

		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "    <ribMessage>\n"
				+ "        <family>PRMPRCCHG</family>\n"
				+ "        <type>PRMPRCCHGCRE</type>\n"
				+ "        <ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.05.07 13:49:37.970|1070</ribmessageID>\n"
				+ "        <publishTime>2015-05-07 13:49:37.970 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;\n"
				+ "&lt;location&gt;5&lt;/location&gt;\n"
				+ "&lt;loc_type&gt;Z&lt;/loc_type&gt;\n"
				+ "&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;\n"
				+ "&lt;PrmPrcChgDtl&gt;\n"
				+ "&lt;promo_id&gt;1512130&lt;/promo_id&gt;\n"
				+ "&lt;promo_name&gt;MBLS_Promotion2&lt;/promo_name&gt;\n"
				+ "&lt;promo_description&gt;PM032694&lt;/promo_description&gt;\n"
				+ "&lt;promo_comp_id&gt;66866447&lt;/promo_comp_id&gt;\n"
				+ "&lt;promo_comp_desc&gt;PM032694&lt;/promo_comp_desc&gt;\n"
				+ "&lt;promo_comp_detail_id&gt;30044016&lt;/promo_comp_detail_id&gt;\n"
				+ "&lt;apply_order&gt;0&lt;/apply_order&gt;\n"
				+ "&lt;start_date&gt;\n"
				+ "&lt;year&gt;2017&lt;/year&gt;\n"
				+ "&lt;month&gt;1&lt;/month&gt;\n"
				+ "&lt;day&gt;1&lt;/day&gt;\n"
				+ "&lt;hour&gt;0&lt;/hour&gt;\n"
				+ "&lt;minute&gt;0&lt;/minute&gt;\n"
				+ "\t&lt;second&gt;0&lt;/second&gt;\n"
				+ "&lt;/start_date&gt;\n"
				+ "&lt;end_date&gt;\n"
				+ "&lt;year&gt;2017&lt;/year&gt;\n"
				+ "&lt;month&gt;1&lt;/month&gt;\n"
				+ "&lt;day&gt;31&lt;/day&gt;\n"
				+ "&lt;hour&gt;23&lt;/hour&gt;\n"
				+ "&lt;minute&gt;59&lt;/minute&gt;\n"
				+ "\t&lt;second&gt;59&lt;/second&gt;\n"
				+ "&lt;/end_date&gt;\n"
				+ "&lt;tsl_ext_promo_id&gt;2073&lt;/tsl_ext_promo_id&gt;\n"
				+ "&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;\n"
				+ "&lt;tsl_comp_level_till_desc&gt;MBLS_Approved&lt;/tsl_comp_level_till_desc&gt;\n"
				+ "&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;\n"
				+ "&lt;tsl_promo_comp_display_id&gt;31423485&lt;/tsl_promo_comp_display_id&gt;\n"
				+ "&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;\n"
				+ "&lt;TSLPrmPrcChgMultiBuy&gt;\n"
				+ "&lt;multi_buy_promo_type&gt;L&lt;/multi_buy_promo_type&gt;\n"
				+ "&lt;coupon_trg_ind&gt;N&lt;/coupon_trg_ind&gt;\n"
				+ "&lt;tsl_template_id&gt;A0000027&lt;/tsl_template_id&gt;\n"
				+ "&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;\n"
				+ "&lt;tsl_pos_description1&gt;MBLS_Approved&lt;/tsl_pos_description1&gt;\n"
				+ "&lt;tsl_pos_description2&gt;Test&lt;/tsl_pos_description2&gt;\n"
				+ "&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;\n"
				+ "&lt;TSLPrmPrcChgBuyList&gt;\n"
				+ "&lt;list_id&gt;50979&lt;/list_id&gt;\n"
				+ "&lt;buy_item_type&gt;1&lt;/buy_item_type&gt;\n"
				+ "&lt;buy_item_value&gt;1&lt;/buy_item_value&gt;\n"
				+ "&lt;TSLPrmPrcChgBuyListItem&gt;\n"
				+ "&lt;merch_type&gt;0&lt;/merch_type&gt;\n"
				+ "&lt;dept&gt;1435&lt;/dept&gt;\n"
				+ "&lt;class&gt;7&lt;/class&gt;\n"
				+ "&lt;subclass&gt;9&lt;/subclass&gt;\n"
				+ "&lt;item&gt;067291404&lt;/item&gt;\n"
				+ "&lt;tsl_consumer_unit&gt;268021305&lt;/tsl_consumer_unit&gt;\n"
				+ "&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;\n"
				+ "&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;\n"
				+ "&lt;tsl_TPND&gt;019131444&lt;/tsl_TPND&gt;\n"
				+ "&lt;tsl_comp_detail_level_desc&gt;PM032694&lt;/tsl_comp_detail_level_desc&gt;\n"
				+ "&lt;/TSLPrmPrcChgBuyListItem&gt;\n"
				+ "&lt;/TSLPrmPrcChgBuyList&gt;\n"
				+ "&lt;TSLPrmPrcChgGetList&gt;\n"
				+ "&lt;list_id&gt;50980&lt;/list_id&gt;\n"
				+ "&lt;change_type&gt;1&lt;/change_type&gt;\n"
				+ "&lt;change_amount&gt;-1&lt;/change_amount&gt;\n"
				+ "&lt;get_quantity&gt;1&lt;/get_quantity&gt;\n"
				+ "&lt;TSLPrmPrcChgGetListItem&gt;\t\n"
				+ "&lt;merch_type&gt;0&lt;/merch_type&gt;\n"
				+ "&lt;dept&gt;1435&lt;/dept&gt;\n"
				+ "&lt;class&gt;13&lt;/class&gt;\n"
				+ "&lt;subclass&gt;7&lt;/subclass&gt;\n"
				+ "&lt;item&gt;058821783&lt;/item&gt;\n"
				+ "&lt;tsl_consumer_unit&gt;260113428&lt;/tsl_consumer_unit&gt;\n"
				+ "&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;\n"
				+ "&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;\n"
				+ "&lt;tsl_TPND&gt;010115081&lt;/tsl_TPND&gt;\n"
				+ "&lt;tsl_comp_detail_level_desc&gt;PM032694&lt;/tsl_comp_detail_level_desc&gt;\n"
				+ "&lt;/TSLPrmPrcChgGetListItem&gt;\n"
				+ "&lt;/TSLPrmPrcChgGetList&gt;\n"
				+ "&lt;/TSLPrmPrcChgMultiBuy&gt;\n" + "&lt;/PrmPrcChgDtl&gt;\n"
				+ "&lt;/PrmPrcChgDesc&gt;\n" + "</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
				+ "</RibMessages>";
		String offerIdFromMsg = "31423485";
		String locType = "Z";
		String locRef = "5";
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(data);
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg,PromotionEntity.class));
		Assert.assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMO_DETAIL_ID_KEY
						+ detailIdFromMsg,String.class));

		String delMsg = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "    <ribMessage>\n"
				+ "        <family>PRMPRCCHG</family>\n"
				+ "        <type>PRMPRCCHGDEL</type>\n"
				+ "        <ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.05.06 15:18:35.940|1277</ribmessageID>\n"
				+ "        <publishTime>2015-05-06 15:18:35.940 BST</publishTime>\n"
				+ "        <messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "            &lt;PrmPrcChgRef&gt;\n"
				+ "                &lt;location&gt;5&lt;/location&gt;\n"
				+ "                &lt;loc_type&gt;Z&lt;/loc_type&gt;\n"
				+ "                &lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;\n"
				+ "                &lt;PrmPrcChgDtlRef&gt;\n"
				+ "                    &lt;promo_comp_detail_id&gt;30044016&lt;/promo_comp_detail_id&gt;\n"
				+ "                    &lt;tsl_promo_comp_id&gt;165904&lt;/tsl_promo_comp_id&gt;\n"
				+ "                    &lt;tsl_state&gt;pcd.deleted&lt;/tsl_state&gt;\n"
				+ "                &lt;/PrmPrcChgDtlRef&gt;\n"
				+ "            &lt;/PrmPrcChgRef&gt;\n"
				+ "        </messageData>\n"
				+ "        <customData></customData>\n"
				+ "        <customFlag>F</customFlag>\n"
				+ "    </ribMessage>\n" + "</RibMessages>";
		promotionMessageRouter.route(delMsg);
		Assert.assertNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));
		Assert.assertNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMO_DETAIL_ID_KEY
						+ detailIdFromMsg,String.class));
		Assert.assertNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg,PromotionEntity.class));

	}

	@Test
	public void shouldProcessPromotionDetailsChangedSimplePromotionAtOfferLevel()
			throws IOException, PromoBusinessException, ProductEncodeException,
			MessageRouterException, DataAccessException,
			PromotionEventException, ParseException {
		String offerIdFromMsg = "31802215";
		String locType = "Z";
		String locRef = "5";
		String masterKey = PriceConstants.PROMOTION_DOC_KEY_PREFIX
				+ offerIdFromMsg;
		String key = PriceConstants.PROMOTION_DOC_KEY_PREFIX + offerIdFromMsg
				+ "_" + locType + locRef;

		deleteDocs(masterKey, key, null, null);

		String credata = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.08.25 14:26:13.719|237</ribmessageID>\n"
				+ "<publishTime>2015-08-25 14:26:13.719 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690111&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802215&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;063165054&lt;/item&gt;&lt;tsl_consumer_unit&gt;259661056&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;014685527&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;0.29&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;1.29&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.28&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690222&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802215&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;064727108&lt;/item&gt;&lt;tsl_consumer_unit&gt;265389479&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;016407285&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;1&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;2&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.99&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(credata);

		String modData = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGMOD</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.06.24 14:26:13.719|237</ribmessageID>\n"
				+ "<publishTime>2015-06-29 11:38:57.055 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP_Update1&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690111&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP_UPdate1&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802215&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;064727108&lt;/item&gt;&lt;tsl_consumer_unit&gt;265389479&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.02&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;016407285&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;1&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;2&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.99&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP_Update1&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690222&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP_UPdate1&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802215&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;063165054&lt;/item&gt;&lt;tsl_consumer_unit&gt;259661056&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;014685527&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;0.29&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;1.29&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.28&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		PromotionMessageRouter promotionMessageRouterAfterMod = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);

		promotionMessageRouterAfterMod.route(modData);

		List<PromoThresholdEntity> promoThresholdEntities = new ArrayList<>();
		List<PromoRewardEntity> promoRewardEntities = new ArrayList<>();
		List<PromoRewardEntity> existingPromoRewardEntities = new ArrayList<>();
		PromoThresholdEntity promoThresholdEntity = new PromoThresholdEntity();
		promoThresholdEntity.thresholdType = PriceConstants.SIMPLE_PROMO_THR_TYPE;
		promoThresholdEntity.thresholdAmount = PriceConstants.SIMPLE_PROMO_THR_AMT;
		promoThresholdEntity.thresholdCurrency = null;
		promoThresholdEntity.thresholdQty = PriceConstants.SIMPLE_PROMO_THR_QTY;
		promoThresholdEntities.add(promoThresholdEntity);

		PromoRewardEntity existingPromoRewardEntity = new PromoRewardEntity();
		existingPromoRewardEntity.changeType = "F";
		existingPromoRewardEntity.changeAmount = Double.valueOf("0.01");
		existingPromoRewardEntity.changeUom = "EA";
		existingPromoRewardEntity.changeCurrency = null;
		existingPromoRewardEntity.changeQty = 1;
		existingPromoRewardEntities.add(existingPromoRewardEntity);

		PromoRewardEntity promoRewardEntity = new PromoRewardEntity();
		promoRewardEntity.changeType = "F";
		promoRewardEntity.changeAmount = Double.valueOf("0.02");
		promoRewardEntity.changeUom = "EA";
		promoRewardEntity.changeCurrency = null;
		promoRewardEntity.changeQty = 1;
		promoRewardEntities.add(promoRewardEntity);

		Map<String, Object> argumentData = new HashMap<>();
		argumentData.put("existingPromotionThresholdEntities",
				promoThresholdEntities);
		argumentData.put("modifiedPromotionThresholdEntities",
				promoThresholdEntities);
		argumentData.put("existingPromoRewardEntities",
				existingPromoRewardEntities);
		argumentData.put("modifiedPromoRewardsEntities", promoRewardEntities);
		argumentData.put("offerId", "31802215");
		Map<String, DateTime> offLeveleffectiveDateMap = new HashMap<>();

		String expectedDate = Dockyard.getFormattedDate("2027-07-13T00:00:00",
				PriceConstants.DATE_FORMAT_YYYYMMDDHHMMSS,
				PriceConstants.ISO_8601_FORMAT);
		offLeveleffectiveDateMap.put("31802215", new DateTime(expectedDate));
		argumentData.put("offLeveleffectiveDateMap", offLeveleffectiveDateMap);

		ArgumentCaptor<Map> argument = ArgumentCaptor.forClass(Map.class);
		ArgumentCaptor<String> argumentZoneId = ArgumentCaptor
				.forClass(String.class);
		ArgumentCaptor<String> argumentLocType = ArgumentCaptor
				.forClass(String.class);
		ArgumentCaptor<String> argumentMsgType = ArgumentCaptor
				.forClass(String.class);
		Mockito.verify(promotionEventHandler, Mockito.times(2))
				.processPromotionEvents(argumentMsgType.capture(),
						argumentZoneId.capture(), argumentLocType.capture(),
						argument.capture());

		Map<String, Object> promotionDetailsChangedOfferLevelEventMap = (Map<String, Object>) argument
				.getValue().get(PROMOTION_DETAILS_CHANGED_OFFER_LEVEL_KEY);
		Map<String, Object> actualArgumentData = (Map<String, Object>) promotionDetailsChangedOfferLevelEventMap
				.get("31802215");
		assertEquals(promoThresholdEntities,
				actualArgumentData.get("existingPromotionThresholdEntities"));
		assertEquals(promoThresholdEntities,
				actualArgumentData.get("modifiedPromotionThresholdEntities"));
		assertEquals(existingPromoRewardEntities,
				actualArgumentData.get("existingPromoRewardEntities"));
		assertEquals(promoRewardEntities,
				actualArgumentData.get("modifiedPromoRewardsEntities"));
		assertEquals("5", argumentZoneId.getValue());
		assertEquals("Z", argumentLocType.getValue());
		assertEquals("31802215", actualArgumentData.get("offerId"));
		assertEquals(offLeveleffectiveDateMap,
				actualArgumentData.get("offLeveleffectiveDateMap"));
		assertEquals(PriceConstants.PROMO_MSG_TYPE_MOD,
				argumentMsgType.getValue());
		deleteDocs(masterKey, key, null, null);
	}

	@Test
	public void shouldProcessPromotionDetailsChangedThresholdAtOfferLevel()
			throws IOException, PromoBusinessException, ProductEncodeException,
			MessageRouterException, DataAccessException,
			PromotionEventException, ParseException {
		String offerIdFromMsg = "29111592";
		String locType = "Z";
		String locRef = "5";
		String masterKey = PriceConstants.PROMOTION_DOC_KEY_PREFIX
				+ offerIdFromMsg;
		String key = PriceConstants.PROMOTION_DOC_KEY_PREFIX + offerIdFromMsg
				+ "_" + locType + locRef;

		deleteDocs(masterKey, key, null, null);

		String credata = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.06.10 11:53:10.052|95</ribmessageID>\n"
				+ "<publishTime>2015-06-10 11:53:10.052 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;96039&lt;/promo_id&gt;&lt;promo_name&gt;threshold FP by qty&lt;/promo_name&gt;&lt;promo_description&gt;threshold FP by qty&lt;/promo_description&gt;&lt;promo_comp_id&gt;68628114&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;threshold FP by qty&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;2237617&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;1&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;5&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;28&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;till desc&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;29111592&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;1481&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;item&gt;053034697&lt;/item&gt;&lt;tsl_consumer_unit&gt;253535360&lt;/tsl_consumer_unit&gt;&lt;threshold_id&gt;15064&lt;/threshold_id&gt;&lt;threshold_name&gt;Threshold FP&lt;/threshold_name&gt;&lt;qualification_type&gt;0&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;002003824&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;threshold FP by qty&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;A0000041&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_pos_description1&gt;POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;POS&lt;/tsl_pos_description3&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;2&lt;/threshold_value&gt;&lt;prm_chg_value&gt;90&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(credata);

		String modData = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGMOD</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.06.15 12:29:49.485|239</ribmessageID>\n"
				+ "<publishTime>2015-06-15 12:29:49.485 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;96039&lt;/promo_id&gt;&lt;promo_name&gt;threshold Amnt off&lt;/promo_name&gt;&lt;promo_description&gt;Threshold Amnt&lt;/promo_description&gt;&lt;promo_comp_id&gt;68628114&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;Threshold Amnt off&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;2237617&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;1&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;5&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;28&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;till desc&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;29111592&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;1481&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;item&gt;053034697&lt;/item&gt;&lt;tsl_consumer_unit&gt;253535360&lt;/tsl_consumer_unit&gt;&lt;threshold_id&gt;15064&lt;/threshold_id&gt;&lt;threshold_name&gt;Threshold Amnt off&lt;/threshold_name&gt;&lt;qualification_type&gt;0&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;002003824&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;Threshold Amnt off&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;A0000041&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_pos_description1&gt;POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;POS&lt;/tsl_pos_description3&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;1&lt;/threshold_value&gt;&lt;prm_chg_value&gt;90&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>"
				+ "<customFlag>F</customFlag>"
				+ "</ribMessage>\n" + "</RibMessages>";

		PromotionMessageRouter promotionMessageRouterAfterMod = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);

		promotionMessageRouterAfterMod.route(modData);

		List<PromoThresholdEntity> existingPromoThresholdEntities = new ArrayList<>();
		List<PromoThresholdEntity> modifiedPromoThresholdEntities = new ArrayList<>();
		List<PromoRewardEntity> existingPromoRewardEntities = new ArrayList<>();
		PromoThresholdEntity promoThresholdEntity = new PromoThresholdEntity();
		promoThresholdEntity.thresholdType = "Q";
		promoThresholdEntity.thresholdAmount = Double.valueOf("0");
		promoThresholdEntity.thresholdCurrency = null;
		promoThresholdEntity.thresholdQty = Integer.valueOf("2");
		existingPromoThresholdEntities.add(promoThresholdEntity);

		PromoRewardEntity promoRewardEntity = new PromoRewardEntity();
		promoRewardEntity.changeType = "F";
		promoRewardEntity.changeAmount = Double.valueOf("90");
		promoRewardEntity.changeUom = null;
		promoRewardEntity.changeCurrency = null;
		promoRewardEntity.changeQty = 1;
		existingPromoRewardEntities.add(promoRewardEntity);

		PromoThresholdEntity modifiedPromoThresholdEntity = new PromoThresholdEntity();
		modifiedPromoThresholdEntity.thresholdType = "Q";
		modifiedPromoThresholdEntity.thresholdAmount = Double.valueOf("0");
		modifiedPromoThresholdEntity.thresholdCurrency = null;
		modifiedPromoThresholdEntity.thresholdQty = Integer.valueOf("1");
		modifiedPromoThresholdEntities.add(modifiedPromoThresholdEntity);

		Map<Object, Object> argumentData = new HashMap<>();
		argumentData.put("existingPromotionThresholdEntities",
				existingPromoThresholdEntities);
		argumentData.put("modifiedPromotionThresholdEntities",
				modifiedPromoThresholdEntities);
		argumentData.put("existingPromoRewardEntities",
				existingPromoRewardEntities);
		argumentData.put("modifiedPromoRewardsEntities",
				existingPromoRewardEntities);
		argumentData.put("promoMsgForZoneId", locRef);
		argumentData.put("promoMsgLocType", locType);
		argumentData.put("offerId", offerIdFromMsg);
		Map<String, DateTime> offLeveleffectiveDateMap = new HashMap<>();
		offLeveleffectiveDateMap.put(offerIdFromMsg, new DateTime(
				expectedDatewithOffset("2015-07-01T00:00:00")));
		argumentData.put("offLeveleffectiveDateMap", offLeveleffectiveDateMap);

		ArgumentCaptor<Map> argument = ArgumentCaptor.forClass(Map.class);
		ArgumentCaptor<String> argumentZoneId = ArgumentCaptor
				.forClass(String.class);
		ArgumentCaptor<String> argumentLocType = ArgumentCaptor
				.forClass(String.class);
		ArgumentCaptor<String> argumentMsgType = ArgumentCaptor
				.forClass(String.class);
		Mockito.verify(promotionEventHandler, Mockito.times(2))
				.processPromotionEvents(argumentMsgType.capture(),
						argumentZoneId.capture(), argumentLocType.capture(),
						argument.capture());

		Map<String, Object> promotionDetailsChangedOfferLevelEventMap = (Map<String, Object>) argument
				.getValue().get(PROMOTION_DETAILS_CHANGED_OFFER_LEVEL_KEY);
		Map<String, Object> actualArgumentData = (Map<String, Object>) promotionDetailsChangedOfferLevelEventMap
				.get(offerIdFromMsg);
		assertEquals(existingPromoThresholdEntities,
				actualArgumentData.get("existingPromotionThresholdEntities"));
		assertEquals(modifiedPromoThresholdEntities,
				actualArgumentData.get("modifiedPromotionThresholdEntities"));
		assertEquals(existingPromoRewardEntities,
				actualArgumentData.get("existingPromoRewardEntities"));
		assertEquals(existingPromoRewardEntities,
				actualArgumentData.get("modifiedPromoRewardsEntities"));
		assertEquals("5", argumentZoneId.getValue());
		assertEquals("Z", argumentLocType.getValue());
		assertEquals(offerIdFromMsg, actualArgumentData.get("offerId"));
		assertEquals(PriceConstants.PROMO_MSG_TYPE_MOD,
				argumentMsgType.getValue());
		assertEquals(offLeveleffectiveDateMap,
				actualArgumentData.get("offLeveleffectiveDateMap"));
		deleteDocs(masterKey, key, null, null);
	}

	@Test
	public void shouldProcessPromotionDetailsChangedAtProductLevel()
			throws IOException, PromoBusinessException, ProductEncodeException,
			MessageRouterException, DataAccessException,
			PromotionEventException, ParseException {
		String offerIdFromMsg = "31802215";
		String locType = "Z";
		String locRef = "5";
		String masterKey = PriceConstants.PROMOTION_DOC_KEY_PREFIX
				+ offerIdFromMsg;
		String key = PriceConstants.PROMOTION_DOC_KEY_PREFIX + offerIdFromMsg
				+ "_" + locType + locRef;

		deleteDocs(masterKey, key, null, null);

		String creData = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.08.25 14:26:13.719|237</ribmessageID>\n"
				+ "<publishTime>2015-08-25 14:26:13.719 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690111&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802215&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;063165054&lt;/item&gt;&lt;tsl_consumer_unit&gt;259661056&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;014685527&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;0.29&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;1.29&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.28&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690222&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802215&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;064727108&lt;/item&gt;&lt;tsl_consumer_unit&gt;265389479&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;016407285&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;1&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;2&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.99&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(creData);

		String modData = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGMOD</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.08.25 14:26:13.719|237</ribmessageID>\n"
				+ "<publishTime>2015-08-25 14:26:13.719 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690111&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802215&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;063165054&lt;/item&gt;&lt;tsl_consumer_unit&gt;259661056&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;014685527&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;0.19&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;1.29&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.28&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690222&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802215&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;064727108&lt;/item&gt;&lt;tsl_consumer_unit&gt;265389479&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;016407285&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;1&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;2&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.99&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		PromotionMessageRouter promotionMessageRouterAfterMod = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);

		promotionMessageRouterAfterMod.route(modData);

		List<PromoItemEntity> existingPromoItemEntities = new ArrayList<>();
		PromoItemEntity promoItemEntity = new PromoItemEntity();
		promoItemEntity.effectiveDate = expectedDatewithOffset("2027-07-13T00:00:00");
		;
		promoItemEntity.endDate = expectedDatewithOffset("2027-07-15T23:59:59");
		promoItemEntity.itemType = PriceConstants.PROMO_ITEM_TYPE;
		promoItemEntity.itemRef = "063165054";
		promoItemEntity.setWasPrice("0.29");
		promoItemEntity.setWasWasPrice("1.29");
		promoItemEntity.setPosLabelReqInd(PriceConstants.POS_LABEL_Y);
		promoItemEntity.setRpmPromoCompDetailId("40690111");
		existingPromoItemEntities.add(promoItemEntity);

		PromoItemEntity promoItemEntitySecond = new PromoItemEntity();
		promoItemEntitySecond.effectiveDate = expectedDatewithOffset("2027-07-13T00:00:00");
		promoItemEntitySecond.endDate = expectedDatewithOffset("2027-07-15T23:59:59");
		promoItemEntitySecond.itemType = PriceConstants.PROMO_ITEM_TYPE;
		promoItemEntitySecond.itemRef = "064727108";
		promoItemEntitySecond.setWasPrice("1");
		promoItemEntitySecond.setWasWasPrice("2");
		promoItemEntitySecond.setPosLabelReqInd(PriceConstants.POS_LABEL_Y);
		promoItemEntitySecond.setRpmPromoCompDetailId("40690222");
		existingPromoItemEntities.add(promoItemEntitySecond);

		List<PromoItemEntity> modifiedPromoItemEntities = new ArrayList<>();
		PromoItemEntity modifiedPromoItemEntity = new PromoItemEntity();

		modifiedPromoItemEntity.effectiveDate = expectedDatewithOffset("2027-07-13T00:00:00");
		modifiedPromoItemEntity.endDate = expectedDatewithOffset("2027-07-15T23:59:59");
		modifiedPromoItemEntity.itemType = PriceConstants.PROMO_ITEM_TYPE;
		modifiedPromoItemEntity.itemRef = "063165054";
		modifiedPromoItemEntity.setWasPrice("0.19");
		modifiedPromoItemEntity.setWasWasPrice("1.29");
		modifiedPromoItemEntity.setPosLabelReqInd(PriceConstants.POS_LABEL_Y);
		modifiedPromoItemEntity.setRpmPromoCompDetailId("40690111");
		modifiedPromoItemEntities.add(modifiedPromoItemEntity);
		modifiedPromoItemEntities.add(promoItemEntitySecond);

		Map<Object, Object> argumentData = new HashMap<>();
		argumentData
				.put("existingPromoItemEntities", existingPromoItemEntities);
		argumentData
				.put("modifiedPromoItemEntities", modifiedPromoItemEntities);
		argumentData.put("promoMsgForZoneId", "5");
		argumentData.put("promoMsgLocType", "Z");
		argumentData.put("offerId", "31802215");
		ArgumentCaptor<Map> argument = ArgumentCaptor.forClass(Map.class);
		ArgumentCaptor<String> argumentZoneId = ArgumentCaptor
				.forClass(String.class);
		ArgumentCaptor<String> argumentLocType = ArgumentCaptor
				.forClass(String.class);
		ArgumentCaptor<String> argumentMsgType = ArgumentCaptor
				.forClass(String.class);
		Mockito.verify(promotionEventHandler, Mockito.times(2))
				.processPromotionEvents(argumentMsgType.capture(),
						argumentZoneId.capture(), argumentLocType.capture(),
						argument.capture());

		Map<String, Object> promotionDetailsChangedOfferLevelEventMap = (Map<String, Object>) argument
				.getValue().get(PROMOTION_DETAILS_CHANGED_PRODUCT_LEVEL_KEY);
		Map<String, Object> actualArgumentData = (Map<String, Object>) promotionDetailsChangedOfferLevelEventMap
				.get(offerIdFromMsg);

		assertEquals(existingPromoItemEntities,
				actualArgumentData.get("existingPromoItemEntities"));
		assertEquals(modifiedPromoItemEntities,
				actualArgumentData.get("modifiedPromoItemEntities"));

		assertEquals("5", argumentZoneId.getValue());
		assertEquals("Z", argumentLocType.getValue());
		assertEquals(offerIdFromMsg, actualArgumentData.get("offerId"));
		assertEquals(PriceConstants.PROMO_MSG_TYPE_MOD,
				argumentMsgType.getValue());

		deleteDocs(masterKey, key, null, null);
	}

	@Test
	public void shouldNotProcessPromotionDetailsChangedAtProductLevel()
			throws IOException, PromoBusinessException, ProductEncodeException,
			MessageRouterException, DataAccessException,
			PromotionEventException, ParseException {
		String offerIdFromMsg = "31802215";
		String locType = "Z";
		String locRef = "5";
		String masterKey = PriceConstants.PROMOTION_DOC_KEY_PREFIX
				+ offerIdFromMsg;
		String key = PriceConstants.PROMOTION_DOC_KEY_PREFIX + offerIdFromMsg
				+ "_" + locType + locRef;

		deleteDocs(masterKey, key, null, null);

		String creData = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.08.25 14:26:13.719|237</ribmessageID>\n"
				+ "<publishTime>2015-08-25 14:26:13.719 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690111&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802215&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;063165054&lt;/item&gt;&lt;tsl_consumer_unit&gt;259661056&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;014685527&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;0.29&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;1.29&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.28&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690222&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802215&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;064727108&lt;/item&gt;&lt;tsl_consumer_unit&gt;265389479&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;016407285&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;1&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;2&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.99&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(creData);

		String modData = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>PRMPRCCHG</family>\n"
				+ "<type>PRMPRCCHGCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.08.25 14:26:13.719|237</ribmessageID>\n"
				+ "<publishTime>2015-08-25 14:26:13.719 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690111&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802215&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;063165054&lt;/item&gt;&lt;tsl_consumer_unit&gt;259661056&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;014685527&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;0.29&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;1.29&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.28&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1569759&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_description&gt;SP_FP&lt;/promo_description&gt;&lt;promo_comp_id&gt;228190&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;40690222&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2027&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;15&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31802215&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;064727108&lt;/item&gt;&lt;tsl_consumer_unit&gt;265389479&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;0.01&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0.01&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;016407285&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;1&lt;/tsl_was_price&gt;&lt;tsl_was_was_price&gt;2&lt;/tsl_was_was_price&gt;&lt;tsl_price_saving&gt;1.99&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		PromotionMessageRouter promotionMessageRouterAfterMod = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);

		promotionMessageRouterAfterMod.route(modData);

		ArgumentCaptor<Map> argument = ArgumentCaptor.forClass(Map.class);
		ArgumentCaptor<String> argumentZoneId = ArgumentCaptor
				.forClass(String.class);
		ArgumentCaptor<String> argumentLocType = ArgumentCaptor
				.forClass(String.class);
		ArgumentCaptor<String> argumentMsgType = ArgumentCaptor
				.forClass(String.class);
		Mockito.verify(promotionEventHandler, Mockito.times(2))
				.processPromotionEvents(argumentMsgType.capture(),
						argumentZoneId.capture(), argumentLocType.capture(),
						argument.capture());

		deleteDocs(masterKey, key, null, null);
	}

	@Test
	public void shouldProcessPromotionEndDateChangedEventForSimplePromotionWhenActivePromotionIsCanceled()
			throws PromotionEventException, MessageRouterException,
			DataAccessException, JsonParseException, JsonMappingException,
			IOException, ParseException {
		String offerIdFromMsg = "29233927";
		String locType = "Z";
		String locRef = "6";

		String modXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
				+ "<RibMessages>  <ribMessage>   <family>PRMPRCCHG</family>    <type>PRMPRCCHGMOD</type>"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2011.10.18 13:46:48.294|546</ribmessageID>"
				+ "<publishTime>2011-10-18 13:46:48.294 BST</publishTime>"
				+ "<messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;6&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;6&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;253662&lt;/promo_id&gt;&lt;promo_name&gt;UK ADHOC SP&lt;/promo_name&gt;&lt;promo_description&gt;FRIZZ EASE S/POO/COND 1.75-1.40 S 35p&lt;/promo_description&gt;&lt;promo_comp_id&gt;65157351&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;FRIZZ EASE S/POO/COND 1.75-1.40 S 35p&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;4844474&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2011&lt;/year&gt;&lt;month&gt;10&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2011&lt;/year&gt;&lt;month&gt;10&lt;/month&gt;&lt;day&gt;18&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.cancelled&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SAVE 35p&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;37863&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;29233927&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;1455&lt;/dept&gt;&lt;class&gt;20&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;062299496&lt;/item&gt;&lt;tsl_consumer_unit&gt;263577906&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;1.4&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;1.4&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;014659997&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;FRIZZ EASE S/POO/COND 1.75-1.40 S 35p&lt;/tsl_comp_detail_level_desc&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;253662&lt;/promo_id&gt;&lt;promo_name&gt;UK ADHOC SP&lt;/promo_name&gt;&lt;promo_description&gt;FRIZZ EASE S/POO/COND 1.75-1.40 S 35p&lt;/promo_description&gt;&lt;promo_comp_id&gt;65157351&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;FRIZZ EASE S/POO/COND 1.75-1.40 S 35p&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;4844478&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2011&lt;/year&gt;&lt;month&gt;10&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2011&lt;/year&gt;&lt;month&gt;10&lt;/month&gt;&lt;day&gt;18&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.cancelled&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SAVE 35p&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;37863&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;29233927&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;1455&lt;/dept&gt;&lt;class&gt;20&lt;/class&gt;&lt;subclass&gt;7&lt;/subclass&gt;&lt;item&gt;062299507&lt;/item&gt;&lt;tsl_consumer_unit&gt;263577916&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;1.4&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;1.4&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;014659686&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;FRIZZ EASE S/POO/COND 1.75-1.40 S 35p&lt;/tsl_comp_detail_level_desc&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>"
				+ "<customData>  </customData>" + "<customFlag>F</customFlag>"
				+ "</ribMessage></RibMessages>";

		RepositoryImpl repositoryImpl = Mockito
				.mock(RepositoryImpl.class);
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);

		String promotionEntityString = fixture("com/tesco/services/core/fixtures/promotion/PromotionEndDateChangedModeMockData.json");
		String expectedEndDate = expectedDatewithOffset("2011-10-18T00:00:00");
		Map<String, Object> expectedMap = new HashMap<>();
		Map<String, String> expectedMapData = new HashMap<>();
		expectedMapData.put("prodRef", "tpnb:071104000-001");
		expectedMapData.put("endDate", expectedEndDate);
		expectedMapData.put("offerId", "29233927");
		expectedMap.put("29233927", expectedMapData);

		PromotionEntity promotionEntity = mapper.readValue(
				promotionEntityString, PromotionEntity.class);

		Mockito.when(
				repositoryImpl.getGenericObject("PROMOTION_29233927_Z6",
						PromotionEntity.class)).thenReturn(promotionEntity);
		promotionMessageRouter.route(modXml);

		ArgumentCaptor<Map> argument = ArgumentCaptor.forClass(Map.class);
		ArgumentCaptor<String> argumentZoneId = ArgumentCaptor
				.forClass(String.class);
		ArgumentCaptor<String> argumentLocType = ArgumentCaptor
				.forClass(String.class);
		ArgumentCaptor<String> argumentMsgType = ArgumentCaptor
				.forClass(String.class);

		Mockito.verify(promotionEventHandler, Mockito.times(1))
				.processPromotionEvents(argumentMsgType.capture(),
						argumentZoneId.capture(), argumentLocType.capture(),
						argument.capture());
		assertEquals("Z", (argumentLocType.getValue()));
		assertEquals("6", (argumentZoneId.getValue()));
		assertEquals("PRMPRCCHGMOD", (argumentMsgType.getValue()));
		assertEquals(expectedMap,
				(argument.getValue().get("PromotionEndDateChanged")));

	}

	@Test
	public void shouldProcessPromotionEndDateChangedEventForThresholdWhenActivePromotionIsCanceled()
			throws PromotionEventException, MessageRouterException,
			DataAccessException, JsonParseException, JsonMappingException,
			IOException {
		String offerIdFromMsg = "222222222";
		String locType = "Z";
		String locRef = "6";

		String threshHoldModXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
				+ "<RibMessages>  <ribMessage>    <family>PRMPRCCHG</family>"
				+ "    <type>PRMPRCCHGMOD</type>  <ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2011.10.13 15:47:01.235|4187</ribmessageID>"
				+ "    <publishTime>2011-10-13 15:47:01.235 BST</publishTime>"
				+ "    <messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;6&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;6&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;199352&lt;/promo_id&gt;&lt;promo_name&gt;p10-Lindt Lindor choc 100g 2 for &#163;3&lt;/promo_name&gt;&lt;promo_description&gt;Lindt Lindor choc 100g 2 for &#163;3&lt;/promo_description&gt;&lt;promo_comp_id&gt;62394334&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;Lindt Lindor choc 100g 2 for &#163;3&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;3838136&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2011&lt;/year&gt;&lt;month&gt;9&lt;/month&gt;&lt;day&gt;19&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2011&lt;/year&gt;&lt;month&gt;10&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.cancelled&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;Lindt Lindor 100g 2f &#163;3&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;16007&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;222222222&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;778&lt;/dept&gt;&lt;class&gt;5&lt;/class&gt;&lt;subclass&gt;12&lt;/subclass&gt;&lt;item&gt;066400706&lt;/item&gt;&lt;tsl_consumer_unit&gt;267107581&lt;/tsl_consumer_unit&gt;&lt;threshold_id&gt;11027&lt;/threshold_id&gt;&lt;threshold_name&gt;impulse 2 for &#163;3&lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;50&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;018183994&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;Lindt Lindor choc 100g 2 for &#163;3&lt;/tsl_comp_detail_level_desc&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;2&lt;/threshold_value&gt;&lt;prm_chg_value&gt;3&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;199352&lt;/promo_id&gt;&lt;promo_name&gt;p10-Lindt Lindor choc 100g 2 for &#163;3&lt;/promo_name&gt;&lt;promo_description&gt;Lindt Lindor choc 100g 2 for &#163;3&lt;/promo_description&gt;&lt;promo_comp_id&gt;62394334&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;Lindt Lindor choc 100g 2 for &#163;3&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;3838144&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2011&lt;/year&gt;&lt;month&gt;9&lt;/month&gt;&lt;day&gt;19&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2011&lt;/year&gt;&lt;month&gt;10&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.cancelled&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;Lindt Lindor 100g 2f &#163;3&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;16007&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;29186835&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;778&lt;/dept&gt;&lt;class&gt;5&lt;/class&gt;&lt;subclass&gt;12&lt;/subclass&gt;&lt;item&gt;066400906&lt;/item&gt;&lt;tsl_consumer_unit&gt;267107788&lt;/tsl_consumer_unit&gt;&lt;threshold_id&gt;11027&lt;/threshold_id&gt;&lt;threshold_name&gt;impulse 2 for &#163;3&lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;50&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;018184152&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;Lindt Lindor choc 100g 2 for &#163;3&lt;/tsl_comp_detail_level_desc&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;2&lt;/threshold_value&gt;&lt;prm_chg_value&gt;3&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;199352&lt;/promo_id&gt;&lt;promo_name&gt;p10-Lindt Lindor choc 100g 2 for &#163;3&lt;/promo_name&gt;&lt;promo_description&gt;Lindt Lindor choc 100g 2 for &#163;3&lt;/promo_description&gt;&lt;promo_comp_id&gt;62394334&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;Lindt Lindor choc 100g 2 for &#163;3&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;3838140&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;2&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2011&lt;/year&gt;&lt;month&gt;9&lt;/month&gt;&lt;day&gt;19&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2011&lt;/year&gt;&lt;month&gt;10&lt;/month&gt;&lt;day&gt;13&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.cancelled&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;Lindt Lindor 100g 2f &#163;3&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;16007&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;29186835&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgThr&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;778&lt;/dept&gt;&lt;class&gt;5&lt;/class&gt;&lt;subclass&gt;12&lt;/subclass&gt;&lt;item&gt;066495401&lt;/item&gt;&lt;tsl_consumer_unit&gt;267203530&lt;/tsl_consumer_unit&gt;&lt;threshold_id&gt;11027&lt;/threshold_id&gt;&lt;threshold_name&gt;impulse 2 for &#163;3&lt;/threshold_name&gt;&lt;qualification_type&gt;1&lt;/qualification_type&gt;&lt;threshold_type&gt;Q&lt;/threshold_type&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;018283806&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;Lindt Lindor choc 100g 2 for &#163;3&lt;/tsl_comp_detail_level_desc&gt;&lt;PrmPrcChgThrDtl&gt;&lt;threshold_value&gt;2&lt;/threshold_value&gt;&lt;prm_chg_value&gt;3&lt;/prm_chg_value&gt;&lt;/PrmPrcChgThrDtl&gt;&lt;/PrmPrcChgThr&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>"
				+ " <customData>  </customData>"
				+ " <customFlag>F</customFlag>"
				+ " </ribMessage></RibMessages>";

		RepositoryImpl repositoryImpl = Mockito
				.mock(RepositoryImpl.class);
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);

		String promotionEntityString = fixture("com/tesco/services/core/fixtures/OneTimeLoadJson/EndDateChangeThresholdPromotion.json");
		SimpleDateFormat dateFormat = new SimpleDateFormat(
				PriceConstants.DATE_FORMAT_FOR_PROMOTION_END_DATE);
		Calendar cal = Calendar.getInstance();
		Date sysDate = cal.getTime();
		Date incrementDateByOne = DateUtils.addDays(sysDate,
				testConfiguration.getDaysToEndThresholdPromo());
		String formatDate = dateFormat.format(incrementDateByOne);
		String endDateThreshold = formatDate
				.concat(PriceConstants.APPEND_HOURS_MIN_SEC_TO_END_DATE);
		Map<String, Object> expectedMap = new HashMap<>();
		Map<String, String> expectedMapData = new HashMap<>();
		expectedMapData.put("endDate", endDateThreshold);
		expectedMapData.put("prodRef", "tpnb:054444444");
		expectedMapData.put("offerId", "222222222");
		expectedMap.put("222222222", expectedMapData);

		PromotionEntity promotionEntity = mapper.readValue(
				promotionEntityString, PromotionEntity.class);

		Mockito.when(
				repositoryImpl.getGenericObject("PROMOTION_222222222_Z6",
						PromotionEntity.class)).thenReturn(promotionEntity);
		promotionMessageRouter.route(threshHoldModXml);

		ArgumentCaptor<Map> argument = ArgumentCaptor.forClass(Map.class);
		ArgumentCaptor<String> argumentZoneId = ArgumentCaptor
				.forClass(String.class);
		ArgumentCaptor<String> argumentLocType = ArgumentCaptor
				.forClass(String.class);
		ArgumentCaptor<String> argumentMsgType = ArgumentCaptor
				.forClass(String.class);

		Mockito.verify(promotionEventHandler, Mockito.times(1))
				.processPromotionEvents(argumentMsgType.capture(),
						argumentZoneId.capture(), argumentLocType.capture(),
						argument.capture());
		assertEquals("Z", (argumentLocType.getValue()));
		assertEquals("6", (argumentZoneId.getValue()));
		assertEquals("PRMPRCCHGMOD", (argumentMsgType.getValue()));
		assertEquals(expectedMap,
				(argument.getValue().get("PromotionEndDateChanged")));

	}

	@Test
	public void shouldProcessPromotionEndDateChangedEventForMultiBuyPromotionWhenActivePromotionIsCanceled()
			throws PromotionEventException, MessageRouterException,
			DataAccessException, JsonParseException, JsonMappingException,
			IOException {
		String offerIdFromMsg = "31747782";
		String locType = "Z";
		String locRef = "5";

		String modXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
				+ "<RibMessages>  <ribMessage>  <family>PRMPRCCHG</family>"
				+ "<type>PRMPRCCHGCRE</type>   <ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2011.09.28 15:37:49.447|20748</ribmessageID>"
				+ "<publishTime>2011-09-28 15:37:49.447 BST</publishTime>"
				+ "<messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;"
				+ "&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;226795&lt;/promo_id&gt;&lt;promo_name&gt;RECIPE DEAL WK35&lt;/promo_name&gt;&lt;promo_description&gt;* TESCO RECIPE DEAL &#163;5.00&lt;/promo_description&gt;&lt;promo_comp_id&gt;63808333&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;* TESCO RECIPE DEAL &#163;5.00&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;4203608&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;0&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2011&lt;/year&gt;&lt;month&gt;10&lt;/month&gt;&lt;day&gt;24&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2011&lt;/year&gt;&lt;month&gt;10&lt;/month&gt;&lt;day&gt;30&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_ext_promo_id&gt;1577&lt;/tsl_ext_promo_id&gt;&lt;tsl_state&gt;pcd.reapproved&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;T.RECIPE DEAL &#163;5.00&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;31568&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31747782&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;TSLPrmPrcChgMultiBuy&gt;&lt;multi_buy_promo_type&gt;M&lt;/multi_buy_promo_type&gt;&lt;coupon_trg_ind&gt;N&lt;/coupon_trg_ind&gt;&lt;TSLPrmPrcChgBuyList&gt;&lt;list_id&gt;9801&lt;/list_id&gt;&lt;buy_item_type&gt;1&lt;/buy_item_type&gt;&lt;buy_item_value&gt;1&lt;/buy_item_value&gt;&lt;TSLPrmPrcChgBuyListItem&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;631&lt;/dept&gt;&lt;class&gt;4&lt;/class&gt;&lt;subclass&gt;4&lt;/subclass&gt;&lt;item&gt;067902737&lt;/item&gt;&lt;tsl_consumer_unit&gt;268649536&lt;/tsl_consumer_unit&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;Y&lt;/tsl_feature_space_ind&gt;&lt;tsl_feature_space_end_num&gt;F1&lt;/tsl_feature_space_end_num&gt;&lt;tsl_TPND&gt;019724238&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;* TESCO RECIPE DEAL &#163;5.00&lt;/tsl_comp_detail_level_desc&gt;&lt;/TSLPrmPrcChgBuyListItem&gt;&lt;/TSLPrmPrcChgBuyList&gt;&lt;TSLPrmPrcChgBuyList&gt;&lt;list_id&gt;9802&lt;/list_id&gt;&lt;buy_item_type&gt;1&lt;/buy_item_type&gt;&lt;buy_item_value&gt;5&lt;/buy_item_value&gt;&lt;TSLPrmPrcChgBuyListItem&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;611&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;5&lt;/subclass&gt;&lt;item&gt;051351439&lt;/item&gt;&lt;tsl_consumer_unit&gt;256667354&lt;/tsl_consumer_unit&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;Y&lt;/tsl_feature_space_ind&gt;&lt;tsl_feature_space_end_num&gt;F1&lt;/tsl_feature_space_end_num&gt;&lt;tsl_TPND&gt;000457589&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;* TESCO RECIPE DEAL &#163;5.00&lt;/tsl_comp_detail_level_desc&gt;&lt;/TSLPrmPrcChgBuyListItem&gt;&lt;TSLPrmPrcChgBuyListItem&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;615&lt;/dept&gt;&lt;class&gt;19&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;item&gt;050503441&lt;/item&gt;&lt;tsl_consumer_unit&gt;258423611&lt;/tsl_consumer_unit&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;Y&lt;/tsl_feature_space_ind&gt;&lt;tsl_feature_space_end_num&gt;F1&lt;/tsl_feature_space_end_num&gt;&lt;tsl_TPND&gt;010168668&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;* TESCO RECIPE DEAL &#163;5.00&lt;/tsl_comp_detail_level_desc&gt;&lt;/TSLPrmPrcChgBuyListItem&gt;&lt;TSLPrmPrcChgBuyListItem&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;616&lt;/dept&gt;&lt;class&gt;3&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;item&gt;059797588&lt;/item&gt;&lt;tsl_consumer_unit&gt;261120055&lt;/tsl_consumer_unit&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;Y&lt;/tsl_feature_space_ind&gt;&lt;tsl_feature_space_end_num&gt;F1&lt;/tsl_feature_space_end_num&gt;&lt;tsl_TPND&gt;015781423&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;* TESCO RECIPE DEAL &#163;5.00&lt;/tsl_comp_detail_level_desc&gt;&lt;/TSLPrmPrcChgBuyListItem&gt;&lt;TSLPrmPrcChgBuyListItem&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;651&lt;/dept&gt;&lt;class&gt;18&lt;/class&gt;&lt;subclass&gt;3&lt;/subclass&gt;&lt;item&gt;062489473&lt;/item&gt;&lt;tsl_consumer_unit&gt;263772685&lt;/tsl_consumer_unit&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;Y&lt;/tsl_feature_space_ind&gt;&lt;tsl_feature_space_end_num&gt;F1&lt;/tsl_feature_space_end_num&gt;&lt;tsl_TPND&gt;013967864&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;* TESCO RECIPE DEAL &#163;5.00&lt;/tsl_comp_detail_level_desc&gt;&lt;/TSLPrmPrcChgBuyListItem&gt;&lt;/TSLPrmPrcChgBuyList&gt;&lt;TSLPrmPrcChgReward&gt;&lt;list_id&gt;9806&lt;/list_id&gt;&lt;change_type&gt;2&lt;/change_type&gt;&lt;change_amount&gt;5&lt;/change_amount&gt;&lt;get_quantity&gt;0&lt;/get_quantity&gt;&lt;/TSLPrmPrcChgReward&gt;&lt;/TSLPrmPrcChgMultiBuy&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>"
				+ "<customData>    </customData>"
				+ " <customFlag>F</customFlag>" + "</ribMessage></RibMessages>";

		RepositoryImpl repositoryImpl = Mockito
				.mock(RepositoryImpl.class);
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);

		String promotionEntityString = fixture("com/tesco/services/core/fixtures/OneTimeLoadJson/EndDateChangedMultiBuyMockData.json");

		Map<String, Object> expectedMap = new HashMap<>();
		Map<String, String> expectedMapData = new HashMap<>();
		expectedMapData.put("066257027", "2019-12-22T23:59:59+05:30");
		expectedMapData.put("066257028", "2019-12-22T23:59:59+05:30");
		expectedMapData.put("066257029", "2019-12-22T23:59:59+05:30");
		expectedMapData.put("066257030", "2019-12-22T23:59:59+05:30");
		expectedMap.put("31747782", expectedMapData);
		PromotionEntity promotionEntity = mapper.readValue(
				promotionEntityString, PromotionEntity.class);

		Mockito.when(
				repositoryImpl.getGenericObject("PROMOTION_31747782_Z5",
						PromotionEntity.class)).thenReturn(promotionEntity);
		promotionMessageRouter.route(modXml);

		ArgumentCaptor<Map> argument = ArgumentCaptor.forClass(Map.class);
		ArgumentCaptor<String> argumentZoneId = ArgumentCaptor
				.forClass(String.class);
		ArgumentCaptor<String> argumentLocType = ArgumentCaptor
				.forClass(String.class);
		ArgumentCaptor<String> argumentMsgType = ArgumentCaptor
				.forClass(String.class);

		Mockito.verify(promotionEventHandler, Mockito.times(1))
				.processPromotionEvents(argumentMsgType.capture(),
						argumentZoneId.capture(), argumentLocType.capture(),
						argument.capture());
		assertEquals("Z", (argumentLocType.getValue()));
		assertEquals("5", (argumentZoneId.getValue()));
		assertEquals("PRMPRCCHGCRE", (argumentMsgType.getValue()));
		assertEquals(expectedMap,
				(argument.getValue().get("PromotionEndDateChangedPerItem")));

	}

	@Test
	public void shouldInvokePublishEventWithPromotionCreatedEventWhenPromotionNotExist()
			throws MessageRouterException, XPathExpressionException,
			IOException, SAXException, ParserConfigurationException,
			JAXBException, ParseException, EventPublishException,
			PromotionEventException {
		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "  <ribMessage>\n"
				+ "    <family>PRMPRCCHG</family>\n"
				+ "    <type>PRMPRCCHGCRE</type>\n"
				+ "    <ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.05.26 10:01:34.795|385</ribmessageID>\n"
				+ "    <publishTime>2015-05-26 10:01:34.795 BST</publishTime>\n"
				+ "    <messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "    &lt;PrmPrcChgDesc&gt;&lt;location&gt;13&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;13&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1562795&lt;/promo_id&gt;&lt;promo_name&gt;ROI BAKERY P5&lt;/promo_name&gt;&lt;promo_description&gt;WHITE CHOCOLATE COOKIES 5 PACK W 2 N 1.5 S 0.5&lt;/promo_description&gt;&lt;promo_comp_id&gt;182534&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;HOVIS BEST OF BOTH THICK WHITE Only 1.69&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;39778795&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;2&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;22&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;save&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;248790&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31757666&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;231&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;6&lt;/subclass&gt;&lt;item&gt;056574421&lt;/item&gt;&lt;tsl_consumer_unit&gt;253294471&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;1.69&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;N&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0&lt;/prm_chg_value&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;023667034&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;HOVIS BEST OF BOTH THICK WHITE Only 1.69&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n "
				+ "    <customData>\n" + "    </customData>\n"
				+ "    <customFlag>F</customFlag>\n" + "  </ribMessage>\n"
				+ "</RibMessages>";
		String offerIdFromMsg = "31757666";
		String locType = "Z";
		String locRef = "13";
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);

		ParseMessageUtil parseMessageUtil = ParseMessageUtil.getInstance();

		String promoDescData = parseMessageUtil.getNodeData(data,
				PriceConstants.PROMO_MSG_DATA_PATH);

		PrmPrcChgDesc promotions = (PrmPrcChgDesc) parseMessageUtil
				.getMappedObjectForXmlData(PrmPrcChgDesc.class, promoDescData);

		PrmPrcChgDtl prmPrcChgDtls = promotions.getPrmPrcChgDtl().get(0);
		String promoEffectiveDate = PriceUtility.getDate(prmPrcChgDtls
				.getStartDate().getYear().toString(), prmPrcChgDtls
				.getStartDate().getMonth().toString(), prmPrcChgDtls
				.getStartDate().getDay().toString(), prmPrcChgDtls
				.getStartDate().getHour().toString(), prmPrcChgDtls
				.getStartDate().getMinute().toString(), prmPrcChgDtls
				.getStartDate().getSecond().toString());
		String promoPublicationDate = Dockyard
				.getSysDate(PriceConstants.ISO_8601_FORMAT);
		promoEffectiveDate = Dockyard.getFormattedDate(promoEffectiveDate,
				PriceConstants.DATE_FORMAT_YYYYMMDDHHMMSS,
				PriceConstants.ISO_8601_FORMAT);
		promoPublicationDate = Dockyard.getFormattedDate(promoPublicationDate,
				PriceConstants.DATE_FORMAT_YYYYMMDDHHMMSS,
				PriceConstants.ISO_8601_FORMAT);
		DateTime promoEffectiveDateObj = new DateTime(promoEffectiveDate);
		DateTime promoPublicationDateObj = new DateTime(promoPublicationDate);
		int leadDays = LeadTimeUtility.getLeadTime(promoEffectiveDateObj,
				promoPublicationDateObj);

		promotionMessageRouter.route(data);

		Map<String, Object> allEventsDataMap = prepareExpectedEventDataMap("PromotionCreated");

		Mockito.verify(promotionEventHandler, Mockito.times(1))
				.processPromotionEvents("PRMPRCCHGCRE", "13", "Z",
						allEventsDataMap);

	}

	@Test
	public void shouldInvokePublishEventWithPromotionLocationAddedEventWhenLocationNotExist()
			throws Exception {
		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "  <ribMessage>\n"
				+ "    <family>PRMPRCCHG</family>\n"
				+ "    <type>PRMPRCCHGCRE</type>\n"
				+ "    <ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.05.26 10:01:34.795|385</ribmessageID>\n"
				+ "    <publishTime>2015-05-26 10:01:34.795 BST</publishTime>\n"
				+ "    <messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "    &lt;PrmPrcChgDesc&gt;&lt;location&gt;13&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;13&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1562795&lt;/promo_id&gt;&lt;promo_name&gt;ROI BAKERY P5&lt;/promo_name&gt;&lt;promo_description&gt;WHITE CHOCOLATE COOKIES 5 PACK W 2 N 1.5 S 0.5&lt;/promo_description&gt;&lt;promo_comp_id&gt;182534&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;HOVIS BEST OF BOTH THICK WHITE Only 1.69&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;39778795&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;2&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;22&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;save&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;248790&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31757666&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;231&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;6&lt;/subclass&gt;&lt;item&gt;056574421&lt;/item&gt;&lt;tsl_consumer_unit&gt;253294471&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;1.69&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;N&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0&lt;/prm_chg_value&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;023667034&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;HOVIS BEST OF BOTH THICK WHITE Only 1.69&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n "
				+ "    <customData>\n" + "    </customData>\n"
				+ "    <customFlag>F</customFlag>\n" + "  </ribMessage>\n"
				+ "</RibMessages>";
		String offerIdFromMsg = "31757666";
		String locType = "Z";
		String locRef = "13";
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);

		ParseMessageUtil parseMessageUtil = ParseMessageUtil.getInstance();

		String promoDescData = parseMessageUtil.getNodeData(data,
				PriceConstants.PROMO_MSG_DATA_PATH);

		PrmPrcChgDesc promotions = (PrmPrcChgDesc) parseMessageUtil
				.getMappedObjectForXmlData(PrmPrcChgDesc.class, promoDescData);

		PrmPrcChgDtl prmPrcChgDtls = promotions.getPrmPrcChgDtl().get(0);
		String promoEffectiveDate = PriceUtility.getDate(prmPrcChgDtls
				.getStartDate().getYear().toString(), prmPrcChgDtls
				.getStartDate().getMonth().toString(), prmPrcChgDtls
				.getStartDate().getDay().toString(), prmPrcChgDtls
				.getStartDate().getHour().toString(), prmPrcChgDtls
				.getStartDate().getMinute().toString(), prmPrcChgDtls
				.getStartDate().getSecond().toString());
		String promoPublicationDate = Dockyard
				.getSysDate(PriceConstants.ISO_8601_FORMAT);
		promoEffectiveDate = Dockyard.getFormattedDate(promoEffectiveDate,
				PriceConstants.DATE_FORMAT_YYYYMMDDHHMMSS,
				PriceConstants.ISO_8601_FORMAT);
		promoPublicationDate = Dockyard.getFormattedDate(promoPublicationDate,
				PriceConstants.DATE_FORMAT_YYYYMMDDHHMMSS,
				PriceConstants.ISO_8601_FORMAT);
		DateTime promoEffectiveDateObj = new DateTime(promoEffectiveDate);
		DateTime promoPublicationDateObj = new DateTime(promoPublicationDate);
		int leadDays = LeadTimeUtility.getLeadTime(promoEffectiveDateObj,
				promoPublicationDateObj);
		PromotionMasterEntity mastreDocToInsert = constructMaster();
		insertMasterEntity("PROMOTION_31757666", mastreDocToInsert);

		promotionMessageRouter.route(data);
		Map<String, Object> allEventsDataMap = prepareExpectedEventDataMap("PromotionLocationAdded");

		Mockito.verify(promotionEventHandler, Mockito.times(1))
				.processPromotionEvents("PRMPRCCHGCRE", "13", "Z",
						allEventsDataMap);

	}

	@Test
	public void shouldInvokePublishEventWithPromotionProductAddedEventWhenProductNotExist()
			throws Exception {
		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "  <ribMessage>\n"
				+ "    <family>PRMPRCCHG</family>\n"
				+ "    <type>PRMPRCCHGCRE</type>\n"
				+ "    <ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.05.26 10:01:34.795|385</ribmessageID>\n"
				+ "    <publishTime>2015-05-26 10:01:34.795 BST</publishTime>\n"
				+ "    <messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "    &lt;PrmPrcChgDesc&gt;&lt;location&gt;13&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;13&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;1562795&lt;/promo_id&gt;&lt;promo_name&gt;ROI BAKERY P5&lt;/promo_name&gt;&lt;promo_description&gt;WHITE CHOCOLATE COOKIES 5 PACK W 2 N 1.5 S 0.5&lt;/promo_description&gt;&lt;promo_comp_id&gt;182534&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;HOVIS BEST OF BOTH THICK WHITE Only 1.69&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;39778795&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;2&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;22&lt;/day&gt;&lt;hour&gt;23&lt;/hour&gt;&lt;minute&gt;59&lt;/minute&gt;&lt;second&gt;59&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;save&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;248790&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;31757666&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;231&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;6&lt;/subclass&gt;&lt;item&gt;056574421&lt;/item&gt;&lt;tsl_consumer_unit&gt;253294471&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;1.69&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;N&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;0&lt;/prm_chg_value&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;023667034&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;HOVIS BEST OF BOTH THICK WHITE Only 1.69&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_pos_label_req_ind&gt;0&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData>\n "
				+ "    <customData>\n" + "    </customData>\n"
				+ "    <customFlag>F</customFlag>\n" + "  </ribMessage>\n"
				+ "</RibMessages>";
		String offerIdFromMsg = "31757666";
		String locType = "Z";
		String locRef = "13";
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);

		ParseMessageUtil parseMessageUtil = ParseMessageUtil.getInstance();

		String promoDescData = parseMessageUtil.getNodeData(data,
				PriceConstants.PROMO_MSG_DATA_PATH);

		PrmPrcChgDesc promotions = (PrmPrcChgDesc) parseMessageUtil
				.getMappedObjectForXmlData(PrmPrcChgDesc.class, promoDescData);

		PrmPrcChgDtl prmPrcChgDtls = promotions.getPrmPrcChgDtl().get(0);
		String promoEffectiveDate = PriceUtility.getDate(prmPrcChgDtls
				.getStartDate().getYear().toString(), prmPrcChgDtls
				.getStartDate().getMonth().toString(), prmPrcChgDtls
				.getStartDate().getDay().toString(), prmPrcChgDtls
				.getStartDate().getHour().toString(), prmPrcChgDtls
				.getStartDate().getMinute().toString(), prmPrcChgDtls
				.getStartDate().getSecond().toString());
		String promoPublicationDate = Dockyard
				.getSysDate(PriceConstants.ISO_8601_FORMAT);
		promoEffectiveDate = Dockyard.getFormattedDate(promoEffectiveDate,
				PriceConstants.DATE_FORMAT_YYYYMMDDHHMMSS,
				PriceConstants.ISO_8601_FORMAT);
		promoPublicationDate = Dockyard.getFormattedDate(promoPublicationDate,
				PriceConstants.DATE_FORMAT_YYYYMMDDHHMMSS,
				PriceConstants.ISO_8601_FORMAT);
		DateTime promoEffectiveDateObj = new DateTime(promoEffectiveDate);
		DateTime promoPublicationDateObj = new DateTime(promoPublicationDate);
		int leadDays = LeadTimeUtility.getLeadTime(promoEffectiveDateObj,
				promoPublicationDateObj);

		PromotionEntity promotionEntity = createPromoEntity();
		insertPromotionEntity("PROMOTION_31757666_Z13", promotionEntity);
		PromotionMasterEntity mastreDocToInsert = constructMaster();
		insertMasterEntity("PROMOTION_31757666", mastreDocToInsert);
		promotionMessageRouter.route(data);
		Map<String, Object> allEventsDataMap = prepareExpectedEventDataMap("PromotionProductAdded");

		ArgumentCaptor<Map> argument = ArgumentCaptor.forClass(Map.class);
		ArgumentCaptor<String> argumentZoneId = ArgumentCaptor
				.forClass(String.class);
		ArgumentCaptor<String> argumentLocType = ArgumentCaptor
				.forClass(String.class);
		ArgumentCaptor<String> argumentMsgType = ArgumentCaptor
				.forClass(String.class);

		Mockito.verify(promotionEventHandler, Mockito.times(1))
				.processPromotionEvents(argumentMsgType.capture(),
						argumentZoneId.capture(), argumentLocType.capture(),
						argument.capture());
		Map<String, Object> promotionProductAddedtMap = (Map<String, Object>) argument
				.getValue()
				.get(PriceConstants.PROMOTION_CREATED_LOCATION_ADDED_PRODUCT_ADDED_KEY);
		assertEquals(
				allEventsDataMap
						.get(PROMOTION_CREATED_LOCATION_ADDED_PRODUCT_ADDED_KEY),
				promotionProductAddedtMap);
		assertEquals("13", argumentZoneId.getValue());
		assertEquals("Z", argumentLocType.getValue());
	}

	private Map<String, Object> prepareExpectedEventDataMap(String eventType)
			throws ParseException {
		Map<String, Object> allEventsDataMap = new HashMap<>();
		Map<String, Object> eventsData = new HashMap<>();
		Map<String, String> productMap = new HashMap<>();
		if (eventType.equals(PriceConstants.PROMO_PRODUCT_ADDED)) {

			productMap.put("056574421",
					expectedDatewithOffset("2015-06-02T00:00:00"));
			eventsData.put(PriceConstants.PROMO_PRODUCT_ITEM_LIST, productMap);
		}
		eventsData.put(PriceConstants.EVENT_TYPE, eventType);
		eventsData.put(PriceConstants.EFFECTIVE_DATE,
				expectedDatewithOffset("2015-06-02T00:00:00"));
		eventsData.put(PriceConstants.OFFER_ID, "31757666");

		allEventsDataMap
				.put(PriceConstants.PROMOTION_CREATED_LOCATION_ADDED_PRODUCT_ADDED_KEY,
						eventsData);
		return allEventsDataMap;
	}

	private PromotionMasterEntity constructMaster() throws ParseException {

		PromotionMasterEntity pme = new PromotionMasterEntity();
		pme.setOfferType("SIMPLE");
		pme.setCreatedDate(expectedDatewithOffset("2015-06-02T00:00:00"));
		pme.setCreatedById("RPM");
		Set<String> zoneLoc = new HashSet<>();
		zoneLoc.add("PROMOTION_31757666_Z13");
		pme.setOfferLocRef(zoneLoc);
		return pme;
	}

	private PromotionEntity createPromoEntity() throws ParseException {

		Map<String, PromotionEntity> promotionEntityMap = new HashMap<>();
		List<PromoThresholdEntity> promoThresholdEntities = new ArrayList<>();
		List<PromoRewardEntity> promoRewardEntities = new ArrayList<>();
		List<PromoItemListEntity> promoItemListEntities = new ArrayList<>();
		List<PromoItemEntity> promoItemEntities;
		PromoItemListEntity promoItemBuyListEntity = new PromoItemListEntity();
		PromoItemListEntity promoItemGetListEntity = new PromoItemListEntity();

		String effectiveDate = expectedDatewithOffset("2015-06-02T00:00:00");
		String endDate = expectedDatewithOffset("2015-06-22T23:59:59");

		PromotionEntity promotionEntityFromMap = new PromotionEntity();
		promotionEntityFromMap.offerRef = "31757666";
		promotionEntityFromMap.offerType = "SIMPLE";
		promotionEntityFromMap.state = "APPROVED";
		promotionEntityFromMap.name = "Nicky";
		promotionEntityFromMap.tillRollDescription = "";
		promotionEntityFromMap.locType = "Z";
		promotionEntityFromMap.locRef = "13";
		promotionEntityFromMap.createdById = "RPM";
		promotionEntityFromMap.createdDate = Dockyard
				.getSysDate(PriceConstants.ISO_8601_FORMAT);
		promotionEntityFromMap.lastUpdatedById = PriceConstants.PROMO_CREATED_ID_RPM;
		promotionEntityFromMap.lastUpdateDate = Dockyard
				.getSysDate(PriceConstants.ISO_8601_FORMAT);

		PromoThresholdEntity promoThresholdEntity = new PromoThresholdEntity();
		promoThresholdEntity.thresholdType = PriceConstants.SIMPLE_PROMO_THR_TYPE;
		promoThresholdEntity.thresholdAmount = PriceConstants.SIMPLE_PROMO_THR_AMT;
		promoThresholdEntity.thresholdCurrency = "GBP";
		promoThresholdEntity.thresholdQty = PriceConstants.SIMPLE_PROMO_THR_QTY;
		promoThresholdEntities.add(promoThresholdEntity);
		promotionEntityFromMap
				.setPromoThresholdEntities(promoThresholdEntities);

		PromoRewardEntity promoRewardEntity = new PromoRewardEntity();
		promoRewardEntity.changePercent = 200;
		promoRewardEntity.changeAmount = 1.41;
		promoRewardEntity.changeType = "F";
		promoRewardEntity.changeUom = "EA";
		promoRewardEntity.changeCurrency = "GBP";
		promoRewardEntities.add(promoRewardEntity);
		promotionEntityFromMap.setPromoRewardEntities(promoRewardEntities);

		promoItemBuyListEntity.listType = PriceConstants.PROMO_ITEM_LIST_BUY_TYPE;
		int[] thresholdRefs = setThrRewardRefs(promotionEntityFromMap
				.getPromoThresholdEntities().size());
		promoItemBuyListEntity.setThresholdRefs(thresholdRefs);
		promoItemEntities = new ArrayList<>();

		PromoItemEntity promoItemEntity = new PromoItemEntity();
		promoItemEntity.effectiveDate = effectiveDate;
		promoItemEntity.endDate = endDate;
		promoItemEntity.itemType = PriceConstants.PROMO_ITEM_TYPE;
		promoItemEntity.itemRef = "056574421";
		promoItemEntity.setPosLabelReqInd(PriceConstants.POS_LABEL_Y);
		promoItemEntity.setRpmPromoCompDetailId("12345");
		promoItemEntities.add(promoItemEntity);
		promoItemBuyListEntity.setPromoItems(promoItemEntities);
		promoItemListEntities.add(promoItemBuyListEntity);

		promoItemGetListEntity.listType = PriceConstants.PROMO_ITEM_LIST_GET_TYPE;
		int[] rewardsRefs = setThrRewardRefs(1);
		promoItemGetListEntity.setRewardRefs(rewardsRefs);
		promoItemListEntities.add(promoItemGetListEntity);

		promotionEntityFromMap.setPromoItemListEntities(promoItemListEntities);
		promotionEntityMap.put(promotionEntityFromMap.getOfferRef(),
				promotionEntityFromMap);
		PromotionEntity promotionEntity = null;
		for (String offerId : promotionEntityMap.keySet()) {
			promotionEntity = promotionEntityMap.get(offerId);
		}
		return promotionEntity;

	}

	private int[] setThrRewardRefs(int size) {
		int[] referance = {};
		for (int inc = 0; inc < size; inc++) {
			referance = ArrayUtils.add(referance, inc);
		}
		return referance;
	}

	private void insertPromotionEntity(String Key,
			PromotionEntity promotionEntity) throws Exception {
		repositoryImpl.insertObject(Key, promotionEntity);
	}

	private void insertMasterEntity(String Key,
			PromotionMasterEntity promotionMasterEntity)
			throws Exception {
		repositoryImpl.insertObject(Key, promotionMasterEntity);

	}

	@Test
	public void shouldTriggerPromotiondeletedMessage()
			throws ProductEncodeException, MessageRouterException,
			PromotionEventException, ParseException, DataAccessException {

		String detailIdFromMsg = "30044016";

		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "    <ribMessage>\n"
				+ "        <family>PRMPRCCHG</family>\n"
				+ "        <type>PRMPRCCHGCRE</type>\n"
				+ "        <ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.05.07 13:49:37.970|1070</ribmessageID>\n"
				+ "        <publishTime>2015-05-07 13:49:37.970 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "&lt;PrmPrcChgDesc&gt;\n"
				+ "&lt;location&gt;5&lt;/location&gt;\n"
				+ "&lt;loc_type&gt;Z&lt;/loc_type&gt;\n"
				+ "&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;\n"
				+ "&lt;PrmPrcChgDtl&gt;\n"
				+ "&lt;promo_id&gt;1512130&lt;/promo_id&gt;\n"
				+ "&lt;promo_name&gt;MBLS_Promotion2&lt;/promo_name&gt;\n"
				+ "&lt;promo_description&gt;PM032694&lt;/promo_description&gt;\n"
				+ "&lt;promo_comp_id&gt;66866447&lt;/promo_comp_id&gt;\n"
				+ "&lt;promo_comp_desc&gt;PM032694&lt;/promo_comp_desc&gt;\n"
				+ "&lt;promo_comp_detail_id&gt;30044016&lt;/promo_comp_detail_id&gt;\n"
				+ "&lt;apply_order&gt;0&lt;/apply_order&gt;\n"
				+ "&lt;start_date&gt;\n"
				+ "&lt;year&gt;2017&lt;/year&gt;\n"
				+ "&lt;month&gt;1&lt;/month&gt;\n"
				+ "&lt;day&gt;1&lt;/day&gt;\n"
				+ "&lt;hour&gt;0&lt;/hour&gt;\n"
				+ "&lt;minute&gt;0&lt;/minute&gt;\n"
				+ "\t&lt;second&gt;0&lt;/second&gt;\n"
				+ "&lt;/start_date&gt;\n"
				+ "&lt;end_date&gt;\n"
				+ "&lt;year&gt;2017&lt;/year&gt;\n"
				+ "&lt;month&gt;1&lt;/month&gt;\n"
				+ "&lt;day&gt;31&lt;/day&gt;\n"
				+ "&lt;hour&gt;23&lt;/hour&gt;\n"
				+ "&lt;minute&gt;59&lt;/minute&gt;\n"
				+ "\t&lt;second&gt;59&lt;/second&gt;\n"
				+ "&lt;/end_date&gt;\n"
				+ "&lt;tsl_ext_promo_id&gt;2073&lt;/tsl_ext_promo_id&gt;\n"
				+ "&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;\n"
				+ "&lt;tsl_comp_level_till_desc&gt;MBLS_Approved&lt;/tsl_comp_level_till_desc&gt;\n"
				+ "&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;\n"
				+ "&lt;tsl_promo_comp_display_id&gt;31423485&lt;/tsl_promo_comp_display_id&gt;\n"
				+ "&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;\n"
				+ "&lt;TSLPrmPrcChgMultiBuy&gt;\n"
				+ "&lt;multi_buy_promo_type&gt;L&lt;/multi_buy_promo_type&gt;\n"
				+ "&lt;coupon_trg_ind&gt;N&lt;/coupon_trg_ind&gt;\n"
				+ "&lt;tsl_template_id&gt;A0000027&lt;/tsl_template_id&gt;\n"
				+ "&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;\n"
				+ "&lt;tsl_pos_description1&gt;MBLS_Approved&lt;/tsl_pos_description1&gt;\n"
				+ "&lt;tsl_pos_description2&gt;Test&lt;/tsl_pos_description2&gt;\n"
				+ "&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;\n"
				+ "&lt;TSLPrmPrcChgBuyList&gt;\n"
				+ "&lt;list_id&gt;50979&lt;/list_id&gt;\n"
				+ "&lt;buy_item_type&gt;1&lt;/buy_item_type&gt;\n"
				+ "&lt;buy_item_value&gt;1&lt;/buy_item_value&gt;\n"
				+ "&lt;TSLPrmPrcChgBuyListItem&gt;\n"
				+ "&lt;merch_type&gt;0&lt;/merch_type&gt;\n"
				+ "&lt;dept&gt;1435&lt;/dept&gt;\n"
				+ "&lt;class&gt;7&lt;/class&gt;\n"
				+ "&lt;subclass&gt;9&lt;/subclass&gt;\n"
				+ "&lt;item&gt;067291404&lt;/item&gt;\n"
				+ "&lt;tsl_consumer_unit&gt;268021305&lt;/tsl_consumer_unit&gt;\n"
				+ "&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;\n"
				+ "&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;\n"
				+ "&lt;tsl_TPND&gt;019131444&lt;/tsl_TPND&gt;\n"
				+ "&lt;tsl_comp_detail_level_desc&gt;PM032694&lt;/tsl_comp_detail_level_desc&gt;\n"
				+ "&lt;/TSLPrmPrcChgBuyListItem&gt;\n"
				+ "&lt;/TSLPrmPrcChgBuyList&gt;\n"
				+ "&lt;TSLPrmPrcChgGetList&gt;\n"
				+ "&lt;list_id&gt;50980&lt;/list_id&gt;\n"
				+ "&lt;change_type&gt;1&lt;/change_type&gt;\n"
				+ "&lt;change_amount&gt;-1&lt;/change_amount&gt;\n"
				+ "&lt;get_quantity&gt;1&lt;/get_quantity&gt;\n"
				+ "&lt;TSLPrmPrcChgGetListItem&gt;\t\n"
				+ "&lt;merch_type&gt;0&lt;/merch_type&gt;\n"
				+ "&lt;dept&gt;1435&lt;/dept&gt;\n"
				+ "&lt;class&gt;13&lt;/class&gt;\n"
				+ "&lt;subclass&gt;7&lt;/subclass&gt;\n"
				+ "&lt;item&gt;058821783&lt;/item&gt;\n"
				+ "&lt;tsl_consumer_unit&gt;260113428&lt;/tsl_consumer_unit&gt;\n"
				+ "&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;\n"
				+ "&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;\n"
				+ "&lt;tsl_TPND&gt;010115081&lt;/tsl_TPND&gt;\n"
				+ "&lt;tsl_comp_detail_level_desc&gt;PM032694&lt;/tsl_comp_detail_level_desc&gt;\n"
				+ "&lt;/TSLPrmPrcChgGetListItem&gt;\n"
				+ "&lt;/TSLPrmPrcChgGetList&gt;\n"
				+ "&lt;/TSLPrmPrcChgMultiBuy&gt;\n" + "&lt;/PrmPrcChgDtl&gt;\n"
				+ "&lt;/PrmPrcChgDesc&gt;\n" + "</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
				+ "</RibMessages>";
		String offerIdFromMsg = "31423485";
		String locType = "Z";
		String locRef = "5";
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(data);
		assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,
						PromotionEntity.class));
		assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg,PromotionEntity.class));
		assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMO_DETAIL_ID_KEY
						+ detailIdFromMsg,String.class));

		String delMsg = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "    <ribMessage>\n"
				+ "        <family>PRMPRCCHG</family>\n"
				+ "        <type>PRMPRCCHGDEL</type>\n"
				+ "        <ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.05.06 15:18:35.940|1277</ribmessageID>\n"
				+ "        <publishTime>2015-05-06 15:18:35.940 BST</publishTime>\n"
				+ "        <messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;\n"
				+ "            &lt;PrmPrcChgRef&gt;\n"
				+ "                &lt;location&gt;5&lt;/location&gt;\n"
				+ "                &lt;loc_type&gt;Z&lt;/loc_type&gt;\n"
				+ "                &lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;\n"
				+ "                &lt;PrmPrcChgDtlRef&gt;\n"
				+ "                    &lt;promo_comp_detail_id&gt;30044016&lt;/promo_comp_detail_id&gt;\n"
				+ "                    &lt;tsl_promo_comp_id&gt;165904&lt;/tsl_promo_comp_id&gt;\n"
				+ "                    &lt;tsl_state&gt;pcd.deleted&lt;/tsl_state&gt;\n"
				+ "                &lt;/PrmPrcChgDtlRef&gt;\n"
				+ "            &lt;/PrmPrcChgRef&gt;\n"
				+ "        </messageData>\n"
				+ "        <customData></customData>\n"
				+ "        <customFlag>F</customFlag>\n"
				+ "    </ribMessage>\n" + "</RibMessages>";
		promotionMessageRouter.route(delMsg);
		assertNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));
		assertNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMO_DETAIL_ID_KEY
						+ detailIdFromMsg,String.class));
		assertNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg,PromotionEntity.class));
		Map<String, Object> allEventsDataMap = new HashMap<>();
		Map<String, Object> eventsData = new HashMap<>();
		eventsData.put("31423485",
				expectedDatewithOffset("2017-01-01T00:00:00"));
		allEventsDataMap.put("PromotionDeleted", eventsData);
		Mockito.verify(promotionEventHandler, Mockito.times(1))
				.processPromotionEvents("PRMPRCCHGDEL", "5", "Z",
						allEventsDataMap);

	}

	@Test
	public void shouldTriggerPromotionProductRemovedMessage() throws Exception {

		String detailIdFromMsg = "2237015";
		ArgumentCaptor<Map> argumentCaptor = ArgumentCaptor.forClass(Map.class);
		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages><ribMessage><family>PRMPRCCHG</family><type>PRMPRCCHGCRE</type><ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.06.10 11:53:10.052|95</ribmessageID><publishTime>2015-06-10 11:53:10.052 BST</publishTime><messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;95997&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_comp_id&gt;68628075&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;2237015&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2016&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;10&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;5&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;29111553&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;683&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;item&gt;050014015&lt;/item&gt;&lt;tsl_consumer_unit&gt;250015215&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;45&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;45&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;000007057&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;50&lt;/tsl_was_price&gt;&lt;tsl_price_saving&gt;5&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;95997&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_comp_id&gt;68628075&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;2237025&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2016&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;1&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2016&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;30&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;29111553&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;683&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;item&gt;050014025&lt;/item&gt;&lt;tsl_consumer_unit&gt;250015225&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;45&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;45&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;000007057&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;50&lt;/tsl_was_price&gt;&lt;tsl_price_saving&gt;5&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData><customData /><customFlag>F</customFlag></ribMessage></RibMessages>";
		String offerIdFromMsg = "29111553";
		String locType = "Z";
		String locRef = "5";
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(data);
		assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));
		assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg,PromotionEntity.class));
		assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMO_DETAIL_ID_KEY
						+ detailIdFromMsg,String.class));

		String delMsg = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages><ribMessage><family>PRMPRCCHG</family><type>PRMPRCCHGDEL</type><ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.05.13 12:31:01.770|925</ribmessageID><publishTime>2015-05-13 12:31:01.770 BST</publishTime><messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;&lt;PrmPrcChgRef&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtlRef&gt;&lt;promo_comp_detail_id&gt;2237015&lt;/promo_comp_detail_id&gt;&lt;tsl_promo_comp_id&gt;151956&lt;/tsl_promo_comp_id&gt;&lt;tsl_state&gt;pcd.deleted&lt;/tsl_state&gt;&lt;PrmPrcChgSmpDtlRef&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;762&lt;/dept&gt;&lt;class&gt;10&lt;/class&gt;&lt;subclass&gt;4&lt;/subclass&gt;&lt;item&gt;050014015&lt;/item&gt;&lt;tsl_consumer_unit&gt;250015215&lt;/tsl_consumer_unit&gt;&lt;/PrmPrcChgSmpDtlRef&gt;&lt;/PrmPrcChgDtlRef&gt;&lt;/PrmPrcChgRef&gt;</messageData><customData/><customFlag>F</customFlag></ribMessage></RibMessages>";
		promotionMessageRouter.route(delMsg);
		assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));
		assertNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMO_DETAIL_ID_KEY
						+ detailIdFromMsg,String.class));
		assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg,PromotionEntity.class));
		Map<String, Object> allEventsDataMap = new HashMap<>();
		Map<String, Object> eventsData = new HashMap<>();
		List itemList = new ArrayList<>();
		itemList.add(expectedDatewithOffset("2016-06-01T00:00:00")
				+ "|tpnb:050014015");
		eventsData.put("29111553", itemList);
		allEventsDataMap.put("PromotionProductRemoved", eventsData);
		Mockito.verify(promotionEventHandler, Mockito.times(1))
				.processPromotionEvents("PRMPRCCHGDEL", "5", "Z",
						allEventsDataMap);

	}

	@Test
	public void shouldTriggerPromotiondLocationRemovedMessage()
			throws ProductEncodeException, MessageRouterException,
			PromotionEventException, ParseException, DataAccessException {

		String detailIdFromMsg = "2237015";

		ArgumentCaptor<Map> argumentCaptor = ArgumentCaptor.forClass(Map.class);
		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages><ribMessage><family>PRMPRCCHG</family><type>PRMPRCCHGCRE</type><ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.06.10 11:53:10.052|95</ribmessageID><publishTime>2015-06-10 11:53:10.052 BST</publishTime><messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;&lt;PrmPrcChgDesc&gt;&lt;location&gt;5&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;5&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;95997&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_comp_id&gt;68628075&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;2237015&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2016&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;10&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;5&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;29111553&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;683&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;item&gt;050014015&lt;/item&gt;&lt;tsl_consumer_unit&gt;250015215&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;45&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;45&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;000007057&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;50&lt;/tsl_was_price&gt;&lt;tsl_price_saving&gt;5&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;95997&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_comp_id&gt;68628075&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;2237025&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2016&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;1&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2016&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;30&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;29111553&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;683&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;item&gt;050014025&lt;/item&gt;&lt;tsl_consumer_unit&gt;250015225&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;45&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;45&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;000007057&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;50&lt;/tsl_was_price&gt;&lt;tsl_price_saving&gt;5&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData><customData /><customFlag>F</customFlag></ribMessage></RibMessages>";
		String offerIdFromMsg = "29111553";
		String locType = "Z";
		String locRef = "5";
		PromotionMessageRouter promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(data);
		assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));
		assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg,PromotionEntity.class));
		assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMO_DETAIL_ID_KEY
						+ detailIdFromMsg,String.class));

		detailIdFromMsg = "2237015";
		data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages><ribMessage><family>PRMPRCCHG</family><type>PRMPRCCHGCRE</type><ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.06.10 11:53:10.052|95</ribmessageID><publishTime>2015-06-10 11:53:10.052 BST</publishTime><messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;&lt;PrmPrcChgDesc&gt;&lt;location&gt;6&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;6&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtl&gt;&lt;promo_id&gt;95997&lt;/promo_id&gt;&lt;promo_name&gt;SP_FP&lt;/promo_name&gt;&lt;promo_comp_id&gt;68628075&lt;/promo_comp_id&gt;&lt;promo_comp_desc&gt;SP_FP&lt;/promo_comp_desc&gt;&lt;promo_comp_detail_id&gt;2237115&lt;/promo_comp_detail_id&gt;&lt;apply_order&gt;1&lt;/apply_order&gt;&lt;start_date&gt;&lt;year&gt;2016&lt;/year&gt;&lt;month&gt;6&lt;/month&gt;&lt;day&gt;16&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/start_date&gt;&lt;end_date&gt;&lt;year&gt;2015&lt;/year&gt;&lt;month&gt;7&lt;/month&gt;&lt;day&gt;5&lt;/day&gt;&lt;hour&gt;0&lt;/hour&gt;&lt;minute&gt;0&lt;/minute&gt;&lt;second&gt;0&lt;/second&gt;&lt;/end_date&gt;&lt;tsl_state&gt;pcd.new&lt;/tsl_state&gt;&lt;tsl_comp_level_till_desc&gt;SP_FP&lt;/tsl_comp_level_till_desc&gt;&lt;tsl_promo_event_id&gt;4922&lt;/tsl_promo_event_id&gt;&lt;tsl_promo_comp_display_id&gt;29111553&lt;/tsl_promo_comp_display_id&gt;&lt;tsl_funding_percent&gt;0&lt;/tsl_funding_percent&gt;&lt;PrmPrcChgSmp&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;683&lt;/dept&gt;&lt;class&gt;1&lt;/class&gt;&lt;subclass&gt;1&lt;/subclass&gt;&lt;item&gt;050014115&lt;/item&gt;&lt;tsl_consumer_unit&gt;250015215&lt;/tsl_consumer_unit&gt;&lt;promo_selling_retail&gt;45&lt;/promo_selling_retail&gt;&lt;promo_selling_uom&gt;EA&lt;/promo_selling_uom&gt;&lt;prm_chg_type&gt;F&lt;/prm_chg_type&gt;&lt;prm_chg_value&gt;45&lt;/prm_chg_value&gt;&lt;prm_chg_uom&gt;EA&lt;/prm_chg_uom&gt;&lt;tsl_coupon_trg_ind&gt;N&lt;/tsl_coupon_trg_ind&gt;&lt;tsl_uplift_percent&gt;1&lt;/tsl_uplift_percent&gt;&lt;tsl_feature_space_ind&gt;N&lt;/tsl_feature_space_ind&gt;&lt;tsl_TPND&gt;000007057&lt;/tsl_TPND&gt;&lt;tsl_comp_detail_level_desc&gt;SP_FP&lt;/tsl_comp_detail_level_desc&gt;&lt;tsl_template_id&gt;B0000328&lt;/tsl_template_id&gt;&lt;tsl_pos_label_req_ind&gt;1&lt;/tsl_pos_label_req_ind&gt;&lt;tsl_was_price&gt;50&lt;/tsl_was_price&gt;&lt;tsl_price_saving&gt;5&lt;/tsl_price_saving&gt;&lt;tsl_weee_indicator&gt;0&lt;/tsl_weee_indicator&gt;&lt;tsl_pos_description1&gt;SP_FP_POS&lt;/tsl_pos_description1&gt;&lt;tsl_pos_description2&gt;SP_FP_POS&lt;/tsl_pos_description2&gt;&lt;tsl_pos_description3&gt;SP_FP_POS&lt;/tsl_pos_description3&gt;&lt;tsl_local_sourced_ind&gt;0&lt;/tsl_local_sourced_ind&gt;&lt;/PrmPrcChgSmp&gt;&lt;/PrmPrcChgDtl&gt;&lt;/PrmPrcChgDesc&gt;</messageData><customData /><customFlag>F</customFlag></ribMessage></RibMessages>";
		offerIdFromMsg = "29111553";
		locType = "Z";
		locRef = "6";
		promotionMessageRouter = new PromotionMessageRouter(
				simplePromotionHandler, thresholdPromotionHandler,
				multiBuyPromotionHandler, repositoryImpl,
				promotionEventHandler);
		promotionMessageRouter.route(data);
		assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));
		assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg,PromotionEntity.class));
		assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMO_DETAIL_ID_KEY
						+ detailIdFromMsg,String.class));

		String delMsg = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages><ribMessage><family>PRMPRCCHG</family><type>PRMPRCCHGDEL</type><ribmessageID>12.0|RIBMessagePublisherEjb|PRMPRCCHG|2015.05.13 12:31:01.770|925</ribmessageID><publishTime>2015-05-13 12:31:01.770 BST</publishTime><messageData>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;&lt;PrmPrcChgRef&gt;&lt;location&gt;6&lt;/location&gt;&lt;loc_type&gt;Z&lt;/loc_type&gt;&lt;tsl_zone_id&gt;6&lt;/tsl_zone_id&gt;&lt;PrmPrcChgDtlRef&gt;&lt;promo_comp_detail_id&gt;2237115&lt;/promo_comp_detail_id&gt;&lt;tsl_promo_comp_id&gt;151956&lt;/tsl_promo_comp_id&gt;&lt;tsl_state&gt;pcd.deleted&lt;/tsl_state&gt;&lt;PrmPrcChgSmpDtlRef&gt;&lt;merch_type&gt;0&lt;/merch_type&gt;&lt;dept&gt;762&lt;/dept&gt;&lt;class&gt;10&lt;/class&gt;&lt;subclass&gt;4&lt;/subclass&gt;&lt;item&gt;050014115&lt;/item&gt;&lt;tsl_consumer_unit&gt;250015215&lt;/tsl_consumer_unit&gt;&lt;/PrmPrcChgSmpDtlRef&gt;&lt;/PrmPrcChgDtlRef&gt;&lt;/PrmPrcChgRef&gt;</messageData><customData/><customFlag>F</customFlag></ribMessage></RibMessages>";
		promotionMessageRouter.route(delMsg);
		assertNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg + "_" + locType + locRef,PromotionEntity.class));
		assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMO_DETAIL_ID_KEY
						+ detailIdFromMsg,String.class));
		assertNotNull(repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdFromMsg,PromotionEntity.class));
		Map<String, Object> allEventsDataMap = new HashMap<>();
		Map<String, Object> eventsData = new HashMap<>();
		eventsData.put("29111553",
				expectedDatewithOffset("2016-06-16T00:00:00"));
		allEventsDataMap.put("PromotionLocationRemoved", eventsData);
		Mockito.verify(promotionEventHandler, Mockito.times(1))
				.processPromotionEvents("PRMPRCCHGDEL", "6", "Z",
						allEventsDataMap);
	}

	private String expectedDatewithOffset(String DateTime)
			throws ParseException {
		return Dockyard.getFormattedDate(DateTime,
				PriceConstants.DATE_FORMAT_YYYYMMDDHHMMSS,
				PriceConstants.ISO_8601_FORMAT);
	}
}