package com.tesco.services.core;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tesco.couchbase.AsyncCouchbaseWrapper;
import com.tesco.couchbase.CouchbaseWrapper;
import com.tesco.couchbase.testutils.AsyncCouchbaseWrapperStub;
import com.tesco.couchbase.testutils.BucketTool;
import com.tesco.couchbase.testutils.CouchbaseTestManager;
import com.tesco.couchbase.testutils.CouchbaseWrapperStub;
import com.tesco.services.Configuration;
import com.tesco.services.repositories.RepositoryImpl;
import com.tesco.services.resources.TestConfiguration;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.PriceConstants;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

/**
 * Created by QU17 on 4/2/2015.
 */
@RunWith(MockitoJUnitRunner.class)
public class MemchacheBucketConnectionTest {
    @Mock
    public RepositoryImpl repositoryImpl;

    @Mock
    public AsyncCouchbaseWrapper asyncCouchbaseWrapper;

    @Mock
    public CouchbaseWrapper couchbaseWrapper;

    @Mock
    private ObjectMapper mapper;

    @Mock
    protected Configuration testConfiguration;

    @Mock
    private CouchbaseTestManager couchbaseTestManager;

    @Before
    public void setUp() throws IOException, URISyntaxException, InterruptedException {

        testConfiguration = TestConfiguration.load();
        if (testConfiguration.isDummyCouchbaseMode()){
            Map<String, ImmutablePair<Long, String>> fakeBase = new HashMap<>();
            couchbaseTestManager = new CouchbaseTestManager(new CouchbaseWrapperStub(fakeBase),
                    new AsyncCouchbaseWrapperStub(fakeBase),
                    mock(BucketTool.class));
        } else {
            couchbaseTestManager = new CouchbaseTestManager(testConfiguration.getMemchacheBucket(),
                    testConfiguration.getMemchacheUsername(),
                    testConfiguration.getMemchachePassword(),
                    testConfiguration.getCouchbaseNodes(),
                    testConfiguration.getCouchbaseAdminUsername(),
                    testConfiguration.getCouchbaseAdminPassword());

        }
        couchbaseWrapper = couchbaseTestManager.getCouchbaseWrapper();
        asyncCouchbaseWrapper = couchbaseTestManager.getAsyncCouchbaseWrapper();

        mapper = new ObjectMapper();
        repositoryImpl = new RepositoryImpl(couchbaseWrapper,asyncCouchbaseWrapper, mapper);
    }

    @Test
    public void shouldInsertEanMappingIntoMemchacheBucket() throws Exception {

        final String sysdate = Dockyard.getSysDate("yyyyMMdd");
        String tpnc ="234567891";
        String ean="5123456789123";
        Ean eanObject = new Ean(tpnc);
        eanObject.setLastUpdatedDate(sysdate);

        repositoryImpl
                .insertObject(PriceConstants.EAN_KEY_PREFIX + ean, eanObject);
        Ean eanObjFromDb = mapper.readValue(((String) couchbaseWrapper.get(
                PriceConstants.EAN_KEY_PREFIX + ean)), Ean.class);
        assertThat(eanObjFromDb).isEqualTo(eanObject);

    }
}
