package com.tesco.services.resources;

import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.Import;
import com.tesco.services.adapters.core.ImportProductAvgWeightJob;
import io.dropwizard.testing.junit.ResourceTestRule;
import org.junit.After;
import org.junit.Before;
import org.junit.ClassRule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.util.concurrent.Semaphore;

import static org.fest.assertions.api.Assertions.assertThat;

/**
 * Created by PO47 on 03/11/2015.
 */

@RunWith(MockitoJUnitRunner.class)
public class ImportProductAvgWeightResourceTest {

	@Mock
	private static Configuration testConfiguration;

	@Mock
	private static Import mockImportProductAvgWeightJob = Mockito.mock(ImportProductAvgWeightJob.class);

	@Before
	public void setUpResources() throws Exception {

		Mockito.doNothing().when(mockImportProductAvgWeightJob).run();

		ImportResource.getImportSemaphore().release();

	}

	@ClassRule
	public static final ResourceTestRule resources = ResourceTestRule.builder()
			.addResource(new ImportResource(testConfiguration, null, null, null,
					null, null, null, mockImportProductAvgWeightJob, null, null,
					null, null)).build();

	@Test
	public void shouldStartProductAvgWeightUkImport() throws IOException {
		ImportResource.getImportSemaphoreForIdentifier()
				.put("Products_20151027.xml", new Semaphore(1));
		WebTarget resource = resources.client().target("/admin/importavgweight/sonettouk/Products_20151027.xml");
		Response response = resource.request().accept(MediaType.APPLICATION_JSON).post(Entity.entity("", MediaType.APPLICATION_JSON));
		String responseText = response.readEntity(String.class);
		System.out.println(responseText);
		assertThat(responseText).isEqualTo(
				"{\"message\":\"Import Product Avg Weight Job Started.\"}");
		assertThat(response.getStatus()).isEqualTo(200);
	}

	@Test
	public void shouldStartProductAvgWeightUkImportalreadyRunning()
			throws IOException {
		ImportResource.getImportSemaphoreForIdentifier().put(
				"Products_20151027.xml", new Semaphore(0));
		WebTarget resource = resources.client().target("/admin/importavgweight/sonettouk/Products_20151027.xml");
		Response response = resource.request().accept(MediaType.APPLICATION_JSON).post(Entity.entity("", MediaType.APPLICATION_JSON));
		String responseText = response.readEntity(String.class);

		assertThat(responseText).isEqualTo(
				"{\"message\":\"There is already an import in progress.\"}");
		assertThat(response.getStatus()).isEqualTo(409);
	}

	@Test
	public void shouldStartProductAvgWeightUkImportInvalidRunidentifier()
			throws IOException {

		WebTarget resource = resources.client().target("/admin/importavgweight/sonettou/Products_20151027.xml");
		Response response = resource.request().accept(MediaType.APPLICATION_JSON).post(Entity.entity("", MediaType.APPLICATION_JSON));
		String responseText = response.readEntity(String.class);
		assertThat(responseText)
				.isEqualTo("{\"error\":\"Invalid Run Identifier\"}");
		assertThat(response.getStatus()).isEqualTo(400);
	}

	@Test
	public void shouldStartProductAvgWeightRoiImport() throws IOException {
		ImportResource.getImportSemaphoreForIdentifier()
				.put("Products_20151027.xml", new Semaphore(1));
		WebTarget resource = resources.client().target("/admin/importavgweight/sonettoroi/Products_20151027.xml");
		Response response = resource.request().accept(MediaType.APPLICATION_JSON).post(Entity.entity("", MediaType.APPLICATION_JSON));
		String responseText = response.readEntity(String.class);
		System.out.println(responseText);
		assertThat(responseText).isEqualTo(
				"{\"message\":\"Import Product Avg Weight Job Started.\"}");
		assertThat(response.getStatus()).isEqualTo(200);
	}

	@Test
	public void shouldStartProductAvgWeightRoiImportalreadyRunning()
			throws IOException {
		ImportResource.getImportSemaphoreForIdentifier()
				.put("Products_20151027.xml", new Semaphore(0));
		WebTarget resource = resources.client().target("/admin/importavgweight/sonettoroi/Products_20151027.xml");
		Response response = resource.request().accept(MediaType.APPLICATION_JSON).post(Entity.entity("", MediaType.APPLICATION_JSON));
		String responseText = response.readEntity(String.class);

		assertThat(responseText).isEqualTo(
				"{\"message\":\"There is already an import in progress.\"}");
		assertThat(response.getStatus()).isEqualTo(409);
	}

	@Test
	public void shouldStartProductAvgWeightRoiImportInvalidRunidentifier()
			throws IOException {
		WebTarget resource = resources.client().target("/admin/importavgweight/sonettoro/Product_20151027.xml");
		Response response = resource.request().accept(MediaType.APPLICATION_JSON).post(Entity.entity("", MediaType.APPLICATION_JSON));
		String responseText = response.readEntity(String.class);

		assertThat(responseText)
				.isEqualTo("{\"error\":\"Invalid Run Identifier\"}");
		assertThat(response.getStatus()).isEqualTo(400);
	}

	@After
	public void resetMocks() throws Exception {
		Mockito.reset(mockImportProductAvgWeightJob);
		Mockito.reset(testConfiguration);
	}

	@Before
	public void reset() {
		ImportResource.getImportSemaphoreForIdentifier().clear();
	}
}
