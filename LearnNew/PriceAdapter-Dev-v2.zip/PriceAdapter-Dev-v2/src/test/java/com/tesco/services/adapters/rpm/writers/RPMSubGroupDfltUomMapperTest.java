package com.tesco.services.adapters.rpm.writers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tesco.couchbase.AsyncCouchbaseWrapper;
import com.tesco.couchbase.CouchbaseWrapper;
import com.tesco.couchbase.testutils.AsyncCouchbaseWrapperStub;
import com.tesco.couchbase.testutils.BucketTool;
import com.tesco.couchbase.testutils.CouchbaseTestManager;
import com.tesco.couchbase.testutils.CouchbaseWrapperStub;
import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.exceptions.ColumnNotFoundException;
import com.tesco.services.adapters.core.exceptions.WriterBusinessException;
import com.tesco.services.adapters.rpm.readers.PriceServiceCSVReader;
import com.tesco.services.adapters.rpm.writers.impl.RPMSubGroupDfltUomMapper;
import com.tesco.services.core.SubGroupContentEntity;
import com.tesco.services.repositories.RepositoryImpl;
import com.tesco.services.resources.ImportResource;
import com.tesco.services.resources.TestConfiguration;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.PriceConstants;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.io.BufferedReader;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Semaphore;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class RPMSubGroupDfltUomMapperTest {

	@Mock
	public RepositoryImpl repositoryImpl;
	@Mock
	public AsyncCouchbaseWrapper asyncCouchbaseWrapper;
	@Mock
	public CouchbaseWrapper couchbaseWrapper;
	@Mock
	private Configuration testConfiguration;
	@Mock
	private Configuration mockTestConfiguration;
	@Mock
	private ObjectMapper mapper;
	@Mock
	private BufferedReader bufferedReader;
	@Mock
	private CouchbaseTestManager couchbaseTestManager;
	@Mock
	private PriceServiceCSVReader rpmUOMMappingReader;

	private RPMSubGroupDfltUomMapper rpmSubGroupDfltUomMapper;
	String runIdentifier = PriceConstants.SUBGRP_DFLT_RUN_IDENTIFIER;
	String fileName = PriceConstants.ONETIME_SUBGRP_DFLT_UOM_FILENAME;
	String subGroup = "B45AG";
	String defaultUOM = "EACH";
	String contentUOM = "SNG";
	String conversionFactor = "00010000";

	@Before
	public void setUp() throws IOException, URISyntaxException,
			InterruptedException, ColumnNotFoundException {

		testConfiguration = TestConfiguration.load();
		if (testConfiguration.isDummyCouchbaseMode()) {
			Map<String, ImmutablePair<Long, String>> fakeBase = new HashMap<>();
			couchbaseTestManager = new CouchbaseTestManager(
					new CouchbaseWrapperStub(fakeBase),
					new AsyncCouchbaseWrapperStub(fakeBase),
					mock(BucketTool.class));
		} else {
			couchbaseTestManager = new CouchbaseTestManager(
					testConfiguration.getCouchbaseBucket(),
					testConfiguration.getCouchbaseUsername(),
					testConfiguration.getCouchbasePassword(),
					testConfiguration.getCouchbaseNodes(),
					testConfiguration.getCouchbaseAdminUsername(),
					testConfiguration.getCouchbaseAdminPassword());
		}

		couchbaseWrapper = couchbaseTestManager.getCouchbaseWrapper();
		asyncCouchbaseWrapper = couchbaseTestManager.getAsyncCouchbaseWrapper();

		repositoryImpl = new RepositoryImpl(couchbaseWrapper,
				asyncCouchbaseWrapper, new ObjectMapper());
		rpmSubGroupDfltUomMapper = new RPMSubGroupDfltUomMapper(
				testConfiguration, repositoryImpl, rpmUOMMappingReader);
		rpmSubGroupDfltUomMapper.setRunIdentifier(runIdentifier);
	}

	@Test
	public void readAndWriteSubGroupDefaultData() throws Exception {

		Map<String, String> rpmUomMappingMap = returnRpmUomMappingMap(subGroup,
				defaultUOM, contentUOM, conversionFactor);

		when(rpmUOMMappingReader.getNext()).thenReturn(rpmUomMappingMap)
				.thenReturn(null);
		ImportResource.importSemaphoreForIdentifier.put(fileName,
				new Semaphore(1));

		this.rpmSubGroupDfltUomMapper.write(fileName);

		SubGroupContentEntity expectedSubGroupEntity = (SubGroupContentEntity) repositoryImpl
				.getGenericObject(PriceConstants.SUBGRP_DFLT_UOM_KEY,
						SubGroupContentEntity.class);
		assertThat(expectedSubGroupEntity).isNotNull();
	}

	@Test
	public void readAndWriteSubGroupDefaultDataForNullContentUOM()
			throws Exception {
		contentUOM = "";
		Map<String, String> rpmUomMappingMap = returnRpmUomMappingMap(subGroup,
				defaultUOM, contentUOM, conversionFactor);

		when(rpmUOMMappingReader.getNext()).thenReturn(rpmUomMappingMap)
				.thenReturn(null);
		ImportResource.importSemaphoreForIdentifier.put(fileName,
				new Semaphore(1));

		this.rpmSubGroupDfltUomMapper.write(fileName);

		SubGroupContentEntity expectedSubGroupEntity = (SubGroupContentEntity) repositoryImpl
				.getGenericObject(PriceConstants.SUBGRP_DFLT_UOM_KEY,
						SubGroupContentEntity.class);
		assertThat(expectedSubGroupEntity.getSubgroup().size()).isEqualTo(0);
	}

	private Map<String, String> returnRpmUomMappingMap(String subGroup,
			String defaultUOM, String contentUOM, String conversionFactor) {
		Map<String, String> rpmUomMappingMap = new HashMap<>();
		rpmUomMappingMap.put(CSVHeaders.SubGroupDefaultUOMHeaders.SUB_GROUP,
				subGroup);
		rpmUomMappingMap.put(CSVHeaders.SubGroupDefaultUOMHeaders.DEFAULT_UOM,
				defaultUOM);
		rpmUomMappingMap.put(CSVHeaders.SubGroupDefaultUOMHeaders.CONTENT_UOM,
				contentUOM);
		rpmUomMappingMap.put(
				CSVHeaders.SubGroupDefaultUOMHeaders.CONVERSTION_FACTOR,
				conversionFactor);
		return rpmUomMappingMap;
	}

	// Added for PRIS-2203 Data Loss Issue
	@Test
	public void readAndWriteSubGroupDefault_testCBExceptionNullDocument()
			throws Exception {

		// Delete the document if existing
		String key = "SUBGRP_DFLT_UOM";
		repositoryImpl.deleteProduct(key);

		// setting mock product repository
		RepositoryImpl repositoryImplMock = new RepositoryImpl(
				couchbaseWrapper, asyncCouchbaseWrapper, new ObjectMapper());
		repositoryImplMock = Mockito.mock(repositoryImplMock.getClass());
		RPMSubGroupDfltUomMapper rpmSubGroupDfltUomMapperMock = new RPMSubGroupDfltUomMapper(
				testConfiguration, repositoryImplMock, rpmUOMMappingReader);

		// Set the document in the couchbase
		Map<String, String> rpmUomMappingMap = returnRpmUomMappingMap(subGroup,
				defaultUOM, contentUOM, conversionFactor);
		when(rpmUOMMappingReader.getNext()).thenReturn(rpmUomMappingMap)
				.thenReturn(null);
		SubGroupContentEntity subGroupContentEntity = setSubGroupEntity();
		ImportResource.importSemaphoreForIdentifier.put(fileName,
				new Semaphore(1));

		Mockito.mock(subGroupContentEntity.getClass());
		rpmSubGroupDfltUomMapperMock.setSubGroupEntity(subGroupContentEntity);
		Mockito.doThrow(new Exception()).when(repositoryImplMock)
				.insertObject(key, subGroupContentEntity);

		// Exception will be thrown here
		rpmSubGroupDfltUomMapperMock.write(fileName);

		// Check if the document exist in couchbase
		SubGroupContentEntity expectedSubGroupContentEntity = (SubGroupContentEntity) repositoryImpl
				.getGenericObject(PriceConstants.SUBGRP_DFLT_UOM_KEY,
						SubGroupContentEntity.class);

		// The document should not be present in the couchbase because of DB
		// error
		assertThat(expectedSubGroupContentEntity).isNull();
	}

	// Added for PRIS-2203 Data Loss Issue
	public SubGroupContentEntity setSubGroupEntity() {
		SubGroupContentEntity subGroupEntity = new SubGroupContentEntity();
		Map<String, String> mappingEntity = new HashMap<>();
		Set<String> rejectList = new HashSet<>();

		subGroupEntity.setSubgroup(mappingEntity);
		subGroupEntity
				.setLastUpdatedById(PriceConstants.ONETIME_SUBGRP_DFLT_UPDATED_BY);
		subGroupEntity.setLastUpdateDate(Dockyard
				.getSysDate(PriceConstants.ISO_8601_FORMAT));
		subGroupEntity.setRejectedProducts(rejectList);

		return subGroupEntity;
	}

	@Test
	public void testwriteForArrayIndexOutOfBoundException() throws Exception {

		when(rpmUOMMappingReader.getNext()).thenThrow(
				ArrayIndexOutOfBoundsException.class);
		ImportResource.importSemaphoreForIdentifier.put(fileName,
				new Semaphore(1));
		try {
			this.rpmSubGroupDfltUomMapper.write(fileName);
		} catch (ArrayIndexOutOfBoundsException e) {
			assertThat(true);
		}
	}

	@Test
	public void testRPMSubGroupWriteForException() throws Exception {

		when(rpmUOMMappingReader.getNext()).thenThrow(
				new IOException("IO Exception")).thenReturn(null);

		ImportResource.importSemaphoreForIdentifier.put(fileName,
				new Semaphore(1));

		try {
			this.rpmSubGroupDfltUomMapper.write(fileName);
			fail("Suppose to fail");
		} catch (WriterBusinessException e) {
			assertThat(e.getMessage().equals("IO Exception"));
		}
	}

}
