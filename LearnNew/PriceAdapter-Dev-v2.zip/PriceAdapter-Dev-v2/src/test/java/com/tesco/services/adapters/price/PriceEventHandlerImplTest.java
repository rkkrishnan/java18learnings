package com.tesco.services.adapters.price;

import static com.tesco.services.utility.PriceConstants.LEAD_TIME_DAYS;
import static com.tesco.services.utility.PriceConstants.LOCATION_ID;
import static com.tesco.services.utility.PriceConstants.PRICE_REF;
import static com.tesco.services.utility.PriceConstants.PRODUCT_REF;
import static com.tesco.services.utility.PriceConstants.SCHEDULED_FUTURE_PRICE_MSG_TYPE_CRE;
import static io.dropwizard.testing.FixtureHelpers.fixture;
import static org.joda.time.DateTimeUtils.setCurrentMillisSystem;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.io.StringReader;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.joda.time.DateTimeUtils;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tesco.price.core.RegPrcChgDesc;
import com.tesco.price.core.RegPrcChgDtlRef;
import com.tesco.price.core.RegPrcChgRef;
import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.exceptions.PriceEventException;
import com.tesco.services.adapters.core.exceptions.WriterBusinessException;
import com.tesco.services.adapters.price.impl.PriceEventHandlerImpl;
import com.tesco.services.adapters.rpm.writers.impl.PriceWriter;
import com.tesco.services.core.ZoneEntity;
import com.tesco.services.core.price.PriceByDateTime;
import com.tesco.services.core.price.PriceEntity;
import com.tesco.services.core.price.ProductVariant;
import com.tesco.services.event.core.EventTemplate;
import com.tesco.services.event.core.impl.MapEvent;
import com.tesco.services.event.exception.EventPublishException;
import com.tesco.services.exceptions.DataAccessException;
import com.tesco.services.exceptions.PriceBusinessException;
import com.tesco.services.repositories.RepositoryImpl;
import com.tesco.services.resources.TestConfiguration;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.PriceConstants;

/**
 * Created by IV16 on 9/7/2015.
 */
@RunWith(MockitoJUnitRunner.class)
public class PriceEventHandlerImplTest {
	@Mock
	private RepositoryImpl repositoryImpl;
	@Mock
	private EventTemplate eventTemplate;
	@Mock
	private PriceWriter priceWriter;
	@Mock
	private Configuration configuration;

	@Mock
	private ObjectMapper mapper;

	private TestConfiguration testConfiguration = null;
	private PriceEventHandler priceEventHandler;

	@Captor
	private ArgumentCaptor<MapEvent> argument;

	@Before
	public void setUp() throws Exception {
		testConfiguration = TestConfiguration.load();
		priceEventHandler = new PriceEventHandlerImpl(eventTemplate,
				priceWriter, repositoryImpl);
		DateTimeUtils.setCurrentMillisFixed(Long.valueOf("1459950268375")
				.longValue());

		ZoneEntity zoneUK = new ZoneEntity();
		zoneUK.setZoneId("10");
		zoneUK.setZoneGroupId("90");
		zoneUK.setZoneName("testZone");
		Mockito.when(
				repositoryImpl.getGenericObject("ZONE_10", ZoneEntity.class))
				.thenReturn(zoneUK);

		ZoneEntity zoneIE = new ZoneEntity();
		zoneIE.setZoneId("1");
		zoneIE.setZoneGroupId("90");
		zoneIE.setZoneName("testZone");
		Mockito.when(
				repositoryImpl.getGenericObject("ZONE_1", ZoneEntity.class))
				.thenReturn(zoneIE);
		RegPrcChgRef regPrcChgRef = getRegPrcChgTestData();
		List<String> docKeys = getPriceEntityTestData(regPrcChgRef);
		Map<String, PriceEntity> inputData = getProcessDelEventInput(
				"212223242", "REGPRICE_050000016_Z1");
		Mockito.when(
				priceWriter.getBulkDeserialized(docKeys, PriceEntity.class))
				.thenReturn(inputData);
	}

	@Test
	public void shouldTriggerRegularPriceChngCreateEvent()
			throws PriceEventException, IOException, EventPublishException,
			JAXBException, ParseException, DataAccessException {
		String xmlData = fixture("com/tesco/services/core/fixtures/price/PriceCreEvent.xml");
		RegPrcChgDesc regPrcChgDesc = getRegPrcChgDescTestData(xmlData);
		ZoneEntity zone = new ZoneEntity();
		zone.setTslCountryCode("IE");
		Mockito.when(
				repositoryImpl.getGenericObject("ZONE_10", ZoneEntity.class))
				.thenReturn(zone);
		priceEventHandler.processCreEvent(regPrcChgDesc);
		String expectedDate = Dockyard.getFormattedDate("2016-04-14T00:00:00",
				PriceConstants.DATE_FORMAT_YYYYMMDDHHMMSS,
				PriceConstants.ISO_8601_FORMAT);
		Mockito.verify(eventTemplate, Mockito.times(1)).publishEvent(
				argument.capture());
		assertEquals(PriceConstants.PRICE_MSG_TYPE_CRE,
				(argument.getValue()).getEventType());
		assertEquals(
				"IE:Z:10",
				(argument.getValue()).getHeaderData().get(
						PriceConstants.LOCATION_ID));
		assertEquals(
				"8",
				(argument.getValue()).getHeaderData().get(
						PriceConstants.LEAD_TIME_DAYS));
		assertEquals(
				expectedDate,
				(argument.getValue()).getPayloadData().get(
						PriceConstants.EVENT_EFFECTIVE_DATE));
		assertEquals(
				"40686835",
				(argument.getValue()).getPayloadData().get(
						PriceConstants.PRICE_REF));
		assertEquals("tpnc:276704488", (argument.getValue()).getPayloadData()
				.get(PriceConstants.PRODUCT_REF));

	}

	/*
	 * This is the negative test case to check when effectiveDate is >
	 * publishing Date. As per this testcase, LeadTime < 1 and not able to
	 * publish the event .
	 */
	@Test
	public void shouldNotTriggerPriceChangeEventWhenLeadTimeLessThanOne()
			throws PriceEventException, IOException, EventPublishException,
			JAXBException, ParseException, DataAccessException {
		String xmlData = fixture("com/tesco/services/core/fixtures/price/PriceCreEventLeadTimeNegative.xml");
		RegPrcChgDesc regPrcChgDesc = getRegPrcChgDescTestData(xmlData);
		priceEventHandler.processCreEvent(regPrcChgDesc);
		Mockito.verify(eventTemplate, Mockito.times(0)).publishEvent(
				argument.capture());
	}

	@Test
	public void shouldTriggerDeleteEventWhenTpnbAndTpncPresent()
			throws PriceEventException, IOException, EventPublishException,
			JAXBException, PriceBusinessException, WriterBusinessException,
			DataAccessException {
		Map<String, PriceEntity> inputData = getProcessDelEventInput(
				"212223242", "REGPRICE_050000016_Z1");
		priceWriter = Mockito.mock(PriceWriter.class);
		RegPrcChgRef regPrcChgRef = getRegPrcChgTestData();
		ZoneEntity zone = new ZoneEntity();
		zone.setTslCountryCode("IE");
		Mockito.when(
				repositoryImpl.getGenericObject("ZONE_1", ZoneEntity.class))
				.thenReturn(zone);
		List<String> docKeys = getPriceEntityTestData(regPrcChgRef);
		Mockito.when(
				priceWriter.getBulkDeserialized(docKeys, PriceEntity.class))
				.thenReturn(inputData);
		priceEventHandler.processDelEvent(regPrcChgRef, inputData);
		Mockito.verify(eventTemplate, Mockito.times(1)).publishEvent(
				argument.capture());
		assertEquals(PriceConstants.PRICE_MSG_TYPE_DEL,
				(argument.getValue()).getEventType());
		assertEquals(
				"IE:Z:1",
				(argument.getValue()).getHeaderData().get(
						PriceConstants.LOCATION_ID));
		assertEquals(
				"38",
				(argument.getValue()).getHeaderData().get(
						PriceConstants.LEAD_TIME_DAYS));
		assertEquals(
				"40686693",
				(argument.getValue()).getPayloadData().get(
						PriceConstants.PRICE_REF));
		assertEquals("2016-05-14T01:00:00+01:00", (argument.getValue())
				.getPayloadData().get(PriceConstants.EVENT_EFFECTIVE_DATE));
		assertEquals("tpnc:212223242", (argument.getValue()).getPayloadData()
				.get(PriceConstants.PRODUCT_REF));

	}

	/* It is negative test where item (tpnb )is not present. */

	@Test
	public void shouldNotTriggerDelEventWhenTpnbNotPresent()
			throws PriceEventException, IOException, EventPublishException,
			JAXBException, PriceBusinessException, WriterBusinessException,
			DataAccessException {
		Map<String, PriceEntity> inputData = getProcessDelEventInput(
				"212223242", "212521245");
		priceWriter = Mockito.mock(PriceWriter.class);
		RegPrcChgRef regPrcChgRef = getRegPrcChgTestData();
		List<String> docKeys = getPriceEntityTestData(regPrcChgRef);
		Mockito.when(
				priceWriter.getBulkDeserialized(docKeys, PriceEntity.class))
				.thenReturn(inputData);
		priceEventHandler.processDelEvent(regPrcChgRef, inputData);
		Mockito.verify(eventTemplate, Mockito.times(0)).publishEvent(
				argument.capture());

	}

	@Test
	public void shouldTriggerDelEventWhenTpnbPresent()
			throws PriceEventException, IOException, EventPublishException,
			JAXBException, PriceBusinessException, WriterBusinessException,
			DataAccessException {
		Map<String, PriceEntity> inputData = getProcessDelEventInput(
				"212223242", "REGPRICE_050000016_Z1");
		priceWriter = Mockito.mock(PriceWriter.class);
		RegPrcChgRef regPrcChgRef = getRegPrcChgTestData();
		List<String> docKeys = getPriceEntityTestData(regPrcChgRef);
		ZoneEntity zone = new ZoneEntity();
		zone.setTslCountryCode("IE");
		Mockito.when(
				repositoryImpl.getGenericObject("ZONE_1", ZoneEntity.class))
				.thenReturn(zone);
		Mockito.when(
				priceWriter.getBulkDeserialized(docKeys, PriceEntity.class))
				.thenReturn(inputData);
		priceEventHandler.processDelEvent(regPrcChgRef, inputData);
		Mockito.verify(eventTemplate, Mockito.times(1)).publishEvent(
				argument.capture());
		assertEquals(PriceConstants.PRICE_MSG_TYPE_DEL,
				(argument.getValue()).getEventType());
		assertEquals(
				"38",
				(argument.getValue()).getHeaderData().get(
						PriceConstants.LEAD_TIME_DAYS));
		assertEquals(
				"IE:Z:1",
				(argument.getValue()).getHeaderData().get(
						PriceConstants.LOCATION_ID));
		assertEquals(
				"40686693",
				(argument.getValue()).getPayloadData().get(
						PriceConstants.PRICE_REF));
		assertEquals("2016-05-14T01:00:00+01:00", (argument.getValue())
				.getPayloadData().get(PriceConstants.EVENT_EFFECTIVE_DATE));
		assertEquals("tpnc:212223242", (argument.getValue()).getPayloadData()
				.get(PriceConstants.PRODUCT_REF));

	}

	/*
	 * It is negative test where TPNC not present. This test check if TPNC not
	 * available then processDelEvent should return null
	 */

	@Test
	public void shouldNotTriggerDeleteEventWhenTpncNotPresent()
			throws PriceEventException, IOException, EventPublishException,
			JAXBException, PriceBusinessException, WriterBusinessException {
		// Using generic helper method to get input data
		Map<String, PriceEntity> inputData = getProcessDelEventInput("yyy",
				"212521245");
		priceWriter = Mockito.mock(PriceWriter.class);
		RegPrcChgRef regPrcChgRef = getRegPrcChgTestData();
		List<String> docKeys = getPriceEntityTestData(regPrcChgRef);
		// (mocking expected data which should return from couch base)
		Mockito.when(
				priceWriter.getBulkDeserialized(docKeys, PriceEntity.class))
				.thenReturn(inputData);
		Mockito.verify(eventTemplate, Mockito.times(0)).publishEvent(
				argument.capture());
	}

	@Test
	public void shouldTriggerDeleteEventWhenTpncPresent()
			throws PriceEventException, IOException, EventPublishException,
			JAXBException, PriceBusinessException, DataAccessException {
		// Using generic helper method to get input data equivalent to couch
		// base data
		Map<String, PriceEntity> inputData = getProcessDelEventInput(
				"212223242", "REGPRICE_050000016_Z1");
		RegPrcChgRef regPrcChgRef = getRegPrcChgTestData();
		ZoneEntity zone = new ZoneEntity();
		zone.setTslCountryCode("IE");
		Mockito.when(
				repositoryImpl.getGenericObject("ZONE_1", ZoneEntity.class))
				.thenReturn(zone);
		priceEventHandler.processDelEvent(regPrcChgRef, inputData);
		Mockito.verify(eventTemplate, Mockito.times(1)).publishEvent(
				argument.capture());
		assertEquals(PriceConstants.PRICE_MSG_TYPE_DEL,
				(argument.getValue()).getEventType());
		assertEquals(
				"38",
				(argument.getValue()).getHeaderData().get(
						PriceConstants.LEAD_TIME_DAYS));
		assertEquals(
				"IE:Z:1",
				(argument.getValue()).getHeaderData().get(
						PriceConstants.LOCATION_ID));
		assertEquals(
				"40686693",
				(argument.getValue()).getPayloadData().get(
						PriceConstants.PRICE_REF));
		assertEquals("2016-05-14T01:00:00+01:00", (argument.getValue())
				.getPayloadData().get(PriceConstants.EVENT_EFFECTIVE_DATE));
		assertEquals("tpnc:212223242", (argument.getValue()).getPayloadData()
				.get(PriceConstants.PRODUCT_REF));

	}

	/*
	 * PriceEntity data should be populating properly from xml and should not be
	 * null
	 */
	@Test
	public void getPriceEntityDataTest() throws PriceEventException,
			IOException, EventPublishException, JAXBException,
			PriceBusinessException, WriterBusinessException {
		priceWriter = Mockito.mock(PriceWriter.class);
		Map<String, PriceEntity> inputData = getProcessDelEventInput(
				"212223242", "REGPRICE_050000016_Z1");
		RegPrcChgRef regPrcChgRef = getRegPrcChgTestData();
		List<String> docKeys = getPriceEntityTestData(regPrcChgRef);
		Mockito.when(
				priceWriter.getBulkDeserialized(docKeys, PriceEntity.class))
				.thenReturn(inputData);
		Assert.assertEquals(
				inputData.get("REGPRICE_050000016_Z1").getProdRef(),
				priceEventHandler.getPriceEntityData(regPrcChgRef)
						.get("REGPRICE_050000016_Z1").getProdRef());
		Assert.assertEquals(
				inputData.get("REGPRICE_050000016_Z1").getLocRef(),
				priceEventHandler.getPriceEntityData(regPrcChgRef)
						.get("REGPRICE_050000016_Z1").getLocRef());
		Assert.assertEquals(
				inputData.get("REGPRICE_050000016_Z1")
						.getTpncToProductVariant().get("212223242").getTpnc(),
				priceEventHandler.getPriceEntityData(regPrcChgRef)
						.get("REGPRICE_050000016_Z1").getTpncToProductVariant()
						.get("212223242").getTpnc());
	}

	@Test
	public void shouldTriggerPriceChngScheduledEventForEffectiveDateTomorrow()
			throws PriceEventException, IOException, EventPublishException,
			JAXBException, ParseException, DataAccessException {

		String priceEntityString = fixture("com/tesco/services/core/fixtures/price/SCHEDULED_REGPRICE_Z.json");
		when(mapper.readValue(priceEntityString, Map.class)).thenReturn(
				getMapData());
		ZoneEntity zone = new ZoneEntity();
		zone.setTslCountryCode("IE");
		when(repositoryImpl.getGenericObject("ZONE_2", ZoneEntity.class))
				.thenReturn(zone);
		priceEventHandler.processScheduledEvent(getMapData());
		verify(eventTemplate, times(1)).publishEvent(argument.capture());
		assertEquals("IE:Z:2",
				(argument.getValue()).getHeaderData().get(LOCATION_ID));
		assertEquals(SCHEDULED_FUTURE_PRICE_MSG_TYPE_CRE,
				(argument.getValue()).getEventType());
		assertEquals("tpnc:270088424", (argument.getValue()).getPayloadData()
				.get(PRODUCT_REF));
		assertEquals("1",
				(argument.getValue()).getHeaderData().get(LEAD_TIME_DAYS));
		assertEquals("40686693",
				(argument.getValue()).getPayloadData().get(PRICE_REF));
		assertEquals("IE:Z:2",
				(argument.getValue()).getHeaderData().get(LOCATION_ID));

	}

	@After
	public void tearDown() {
		setCurrentMillisSystem();
	}

	/*
	 * helper method to return RegPrcChgDesc data from xml
	 */
	private RegPrcChgDesc getRegPrcChgDescTestData(String xmlData)
			throws IOException, JAXBException {

		StringReader priceObjectFromXml = new StringReader(xmlData);
		JAXBContext jaxbContextForPromoDetail = JAXBContext
				.newInstance(RegPrcChgDesc.class);
		Unmarshaller unmarshallerPromoDetail = jaxbContextForPromoDetail
				.createUnmarshaller();
		RegPrcChgDesc regPrcChgDesc = (RegPrcChgDesc) unmarshallerPromoDetail
				.unmarshal(priceObjectFromXml);

		return regPrcChgDesc;
	}

	/*
	 * helper method to return RegPrcChgRef data from xml
	 */
	private RegPrcChgRef getRegPrcChgTestData() throws IOException,
			JAXBException {

		String xmlDelData = fixture("com/tesco/services/core/fixtures/price/PriceDel.xml");
		StringReader priceDelObjectFromXml = new StringReader(xmlDelData);
		JAXBContext jaxbContextDel = JAXBContext
				.newInstance(RegPrcChgRef.class);
		Unmarshaller unmarshallerDel = jaxbContextDel.createUnmarshaller();
		RegPrcChgRef regPrcChgRefData = (RegPrcChgRef) unmarshallerDel
				.unmarshal(priceDelObjectFromXml);

		return regPrcChgRefData;
	}

	/*
	 * helper method to return ProcessDelEventInput data(mock data) which should
	 * come from couch base
	 */
	private Map<String, PriceEntity> getProcessDelEventInput(
			String productVariant, String regularPricechngKey) {

		/*
		 * regularPricechngKey is = REGPRICE_050000016_Z1 when tpnb or tpnc
		 * present otherwise null
		 */
		String keyforChangeEvent = regularPricechngKey;
		PriceByDateTime pbDate = new PriceByDateTime();
		pbDate.setEffvDateTime("2016-05-14T01:00:00+01:00");
		pbDate.setPriceRef("40686693");

		Map<String, PriceByDateTime> mapDate = new HashMap<String, PriceByDateTime>();
		mapDate.put("date", pbDate);

		ProductVariant pd = new ProductVariant();
		pd.setTpnc("212223242");
		pd.setEffectiveDate(mapDate);
		Map<String, ProductVariant> mapProduct = new HashMap<String, ProductVariant>();
		mapProduct.put(productVariant, pd);

		PriceEntity pe = new PriceEntity();
		pe.setLocRef("GB");
		pe.setLocType("Z");
		pe.setProdRef("050000016");
		pe.setProdType("tpnb");
		pe.setTpncToProductVariant(mapProduct);
		Map<String, PriceEntity> mapPrice = new HashMap<String, PriceEntity>();
		mapPrice.put(keyforChangeEvent, pe);
		return mapPrice;
	}

	private List<String> getPriceEntityTestData(RegPrcChgRef regPrcChgRef) {
		List<RegPrcChgDtlRef> listOfPriceDetails = regPrcChgRef
				.getRegPrcChgDtlRef();
		String locType = regPrcChgRef.getLocType().toString();
		String loc = String.valueOf(regPrcChgRef.getLocation());
		List<String> docKeys = new ArrayList<>();
		for (RegPrcChgDtlRef priceDetail : listOfPriceDetails) {
			String item = priceDetail.getItem().split("-")[0];
			docKeys.add(PriceConstants.PRICE_DOC_KEY_PREFIX.concat(item)
					.concat("_").concat(locType).concat(loc));
		}
		return docKeys;
	}

	private Map<String, String> getMapData() {

		Map<String, String> mockMapData = new HashMap<String, String>();
		mockMapData.put("prodType", "tpnb");
		mockMapData.put("EventType", "PriceChanged");
		mockMapData.put("prodRef", "071075851");
		mockMapData.put("locRef", "2");
		mockMapData.put("locType", "Z");
		mockMapData.put("tpnc", "270088424");
		mockMapData.put("priceRef", "40686693");
		mockMapData.put("effvDateTime", "2016-05-26T00:00:00.000+00:00");

		return mockMapData;

	}

}
