package com.tesco.services.utility;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.joda.time.DateTime;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.tesco.services.event.core.EventTemplate;
import com.tesco.services.event.core.impl.EventData;
import com.tesco.services.event.core.impl.MapEvent;
import com.tesco.services.event.exception.EventPublishException;
@RunWith(MockitoJUnitRunner.class)
public class CommonEventPublishingUtilityTest {
	@Mock
	private EventTemplate eventTemplate;
	
	@Captor 
	private ArgumentCaptor<MapEvent> argument;
	
	@Test
	public void createPriceEventDataTest(){
      
		String eventType = "PriceChangeCreated";
		String locationId ="IE:Z:10";
		int leadDays =5;
		String priceChangeID = "40686471";
		String tpnc = "234567";
		String effectiveDate = "2016-06-10T00:00:00+01:00";
		String key = "REGPRICE_075360152_Z10";
		MapEvent event = CommonEventPublishingUtility.createPriceEventData(eventType, locationId, leadDays, priceChangeID, tpnc, effectiveDate, key);
		
		Map<String, String> headerMap = new HashMap<String, String>();
		Map<String, Object> payloadMap = new HashMap<String, Object>();		
		headerMap.put(PriceConstants.LOCATION_ID, "IE:Z:10");
		headerMap.put(PriceConstants.LEAD_TIME_DAYS, "5");
		headerMap.put(PriceConstants.EVENT_TYPE, "PriceChangeCreated");
		headerMap.put(PriceConstants.EVENT_CORR_ID, "EVENT_" + "REGPRICE_075360152_Z10");
		payloadMap.put(PriceConstants.PRICE_REF, "40686471");
		payloadMap.put(PriceConstants.PRODUCT_REF, "tpnc:" + "234567");
		payloadMap.put(PriceConstants.EVENT_EFFECTIVE_DATE, "2016-06-10T00:00:00+01:00");
		MapEvent expectedEvent = new MapEvent();
		expectedEvent.setHeaderData(headerMap);
		expectedEvent.setPayloadData(payloadMap);		
		assertEquals(expectedEvent, event);
	}
		
	@Test
	public void createPromoEventDataTest(){
		
		String eventType = "PromotionCreated";
		String locationId ="IE:Z:10";
		int leadDays =5;
		String promotionId = "056745";
		MapEvent event = CommonEventPublishingUtility.createPromoEventData(leadDays, locationId, eventType, promotionId);
		
		String expectedEvent = "EventData [headerData={EventType=PromotionCreated, LeadTimeDays=5, LocationID=IE:Z:10, EventCorrelationID=EVENT_056745}, payloadData={offerId=056745}, eventType=null]";

		assertEquals(expectedEvent, event.toString());
	}

	@Test
	public void createClearanceEventDataTest() {
		String key = "tpnb:050058938_N_2012-11-20T00:00:00_GBP_I";
		String eventType = "ClearanceCreated";
		List<Map<String,Object>>locations = new ArrayList<>();
		Map<String,Object> clearanceMap = new HashMap<>();
		Map<String,Object> locationMap = new HashMap<String,Object>();
		locationMap.put(PriceConstants.LOC_TYPE, "Z");
		locationMap.put(PriceConstants.LOC_REF, "20");
		clearanceMap.put(PriceConstants.PRICING_LOC, locationMap);
		clearanceMap.put(PriceConstants.CLEARANCE_OFFER_ID, "MM");
		locations.add(clearanceMap);
		String leadDays = "5";
		String prdId = "tpnb:50058938";
		String country = "GB";
		MapEvent event = CommonEventPublishingUtility.createClearanceEventData(prdId, leadDays, country, locations,
				key, eventType);
		String expectedEvent = "EventData [headerData={country=GB, EventType=ClearanceCreated, LeadTimeDays=5, EventCorrelationID=EVENT_tpnb:050058938_N_2012-11-20T00:00:00_GBP_I}, payloadData={prodRef=tpnb:50058938, clearances=[{pricingLocation={locRef=20, locType=Z}, clearanceOfferId=MM}]}, eventType=ClearanceCreated]";
		assertEquals(expectedEvent, event.toString());
	}

	@Test(expected = EventPublishException.class)
	public void shouldThrowExceptionWhilePublishEventTest() throws Exception {
		String key = "tpnb:055229003_N_2012-11-20T00:00:00_GBP_I";
		MapEvent data = new MapEvent();
		data.setEventType("ClearanceCreated");
		HashMap<String, Object> payloadMap = new HashMap<>();
		payloadMap.put(PriceConstants.PRODUCT_REF, "tpnb:055229003");
		List<Map<String,Object>>locations = new ArrayList<>();
		Map<String,Object> clearanceMap = new HashMap<>();
		Map<String,Object> locationMap = new HashMap<String,Object>();
		locationMap.put(PriceConstants.LOC_TYPE, "Z");
		locationMap.put(PriceConstants.LOC_REF, "20");
		clearanceMap.put(PriceConstants.PRICING_LOC, locationMap);
		clearanceMap.put(PriceConstants.CLEARANCE_OFFER_ID, "MM");
		locations.add(clearanceMap);
		payloadMap.put(PriceConstants.CLEARANCES, locations);
		data.setPayloadData(payloadMap);

		HashMap<String, String> headerMap = new HashMap<>();
		headerMap.put(PriceConstants.EVENT_CORR_ID, PriceConstants.EVENT_CORR_ID_PREFIX + key);
		headerMap.put(PriceConstants.COUNTRY, "GB");
		headerMap.put(PriceConstants.EVENT_TYPE, "ClearanceCreated");
		headerMap.put(PriceConstants.LEAD_TIME_DAYS, "-1232");
		data.setHeaderData(headerMap);
		eventTemplate = Mockito.mock(EventTemplate.class);
		Mockito.when(eventTemplate.publishEvent(data)).thenThrow(new EventPublishException(new Exception(), "Error"));
		CommonEventPublishingUtility.publishEvent(eventTemplate, data);
	}

	@Test
	public void shouldPublishEventTest() throws Exception {
		String key = "tpnb:055229003_N_2012-11-20T00:00:00_GBP_I";
		MapEvent data = new MapEvent();
		data.setEventType("ClearanceCreated");
		HashMap<String, Object> payloadMap = new HashMap<>();
		payloadMap.put(PriceConstants.PRODUCT_REF, "tpnb:055229003");
		List<Map<String,Object>>locations = new ArrayList<>();
		Map<String,Object> clearanceMap = new HashMap<>();
		Map<String,Object> locationMap = new HashMap<String,Object>();
		locationMap.put(PriceConstants.LOC_TYPE, "Z");
		locationMap.put(PriceConstants.LOC_REF, "20");
		clearanceMap.put(PriceConstants.PRICING_LOC, locationMap);
		clearanceMap.put(PriceConstants.CLEARANCE_OFFER_ID, "MM");
		locations.add(clearanceMap);
		payloadMap.put(PriceConstants.CLEARANCES, locations);
		data.setPayloadData(payloadMap);

		HashMap<String, String> headerMap = new HashMap<>();
		headerMap.put(PriceConstants.EVENT_CORR_ID, PriceConstants.EVENT_CORR_ID_PREFIX + key);
		headerMap.put(PriceConstants.COUNTRY, "GB");
		headerMap.put(PriceConstants.EVENT_TYPE, "ClearanceCreated");
		headerMap.put(PriceConstants.LEAD_TIME_DAYS, "-1232");
		data.setHeaderData(headerMap);
		eventTemplate = Mockito.mock(EventTemplate.class);
		CommonEventPublishingUtility.publishEvent(eventTemplate, data);
		Mockito.verify(eventTemplate, Mockito.times(1)).publishEvent(argument.capture());
		Map<String, String> headerMapActual = argument.getValue().getHeaderData();
		Assert.assertEquals("EVENT_" + key, headerMapActual.get(PriceConstants.EVENT_CORR_ID));
		Assert.assertEquals("GB", headerMapActual.get(PriceConstants.COUNTRY));
		Assert.assertEquals(PriceConstants.CLEARANCE_CREATED_EVENT_TYPE,
				headerMapActual.get(PriceConstants.EVENT_TYPE));
		Assert.assertEquals("-1232", headerMapActual.get(PriceConstants.LEAD_TIME_DAYS));

		Map<String, Object> payloadMapActual = argument.getValue().getPayloadData();
		Assert.assertEquals("tpnb:055229003", payloadMapActual.get(PriceConstants.PRODUCT_REF));
		Assert.assertEquals(locations, payloadMapActual.get(PriceConstants.CLEARANCES));
	}

	@Test
	public void createClearanceEventDataDeleteTest() {
		String key = "tpnb:050058938_N_2012-11-20T00:00:00_GBP_D";
		String eventType = "ClearanceDeleted";
		List<Map<String,Object>>locations = new ArrayList<>();
		Map<String,Object> clearanceMap = new HashMap<>();
		Map<String,Object> locationMap = new HashMap<String,Object>();
		locationMap.put(PriceConstants.LOC_TYPE, "Z");
		locationMap.put(PriceConstants.LOC_REF, "20");
		clearanceMap.put(PriceConstants.PRICING_LOC, locationMap);
		clearanceMap.put(PriceConstants.CLEARANCE_OFFER_ID, "MM");
		locations.add(clearanceMap);
		String leadDays = "0";
		String prdId = "tpnb:50058938";
		String country = "GB";
		MapEvent event = CommonEventPublishingUtility.createClearanceEventData(prdId, leadDays, country, locations,
				key, eventType);
		Map<String, String> headerMapActual = event.getHeaderData();
		Assert.assertEquals(country, headerMapActual.get(PriceConstants.COUNTRY));
		Assert.assertEquals(eventType,
				headerMapActual.get(PriceConstants.EVENT_TYPE));
		Assert.assertEquals("0", headerMapActual.get(PriceConstants.LEAD_TIME_DAYS));

		Map<String, Object> payloadMapActual = event.getPayloadData();
		Assert.assertEquals(prdId, payloadMapActual.get(PriceConstants.PRODUCT_REF));
		Assert.assertEquals(locations, payloadMapActual.get(PriceConstants.CLEARANCES));
	}

	@Test(expected = EventPublishException.class)
	public void shouldThrowExceptionWhilePublishEventDeleteTest() throws Exception {
		String key = "tpnb:055229003_N_2012-11-20T00:00:00_GBP_D";
		MapEvent data = new MapEvent();
		data.setEventType("ClearanceDeleted");
		HashMap<String, Object> payloadMap = new HashMap<>();
		payloadMap.put(PriceConstants.PRODUCT_REF, "tpnb:055229003");
		List<Map<String,Object>>locations = new ArrayList<>();
		Map<String,Object> clearanceMap = new HashMap<>();
		Map<String,Object> locationMap = new HashMap<String,Object>();
		locationMap.put(PriceConstants.LOC_TYPE, "Z");
		locationMap.put(PriceConstants.LOC_REF, "20");
		clearanceMap.put(PriceConstants.PRICING_LOC, locationMap);
		clearanceMap.put(PriceConstants.CLEARANCE_OFFER_ID, "MM");
		locations.add(clearanceMap);
		payloadMap.put(PriceConstants.CLEARANCES, locations);
		data.setPayloadData(payloadMap);

		HashMap<String, String> headerMap = new HashMap<>();
		headerMap.put(PriceConstants.EVENT_CORR_ID, PriceConstants.EVENT_CORR_ID_PREFIX + key);
		headerMap.put(PriceConstants.COUNTRY, "GB");
		headerMap.put(PriceConstants.EVENT_TYPE, "ClearanceDeleted");
		headerMap.put(PriceConstants.LEAD_TIME_DAYS, "0");
		data.setHeaderData(headerMap);

		Mockito.when(eventTemplate.publishEvent(data)).thenThrow(new EventPublishException(new Exception(), "Error"));
		CommonEventPublishingUtility.publishEvent(eventTemplate, data);
	}

	@Test
	public void shouldPublishEventDeleteTest() throws Exception {
		String key = "tpnb:055229003_N_2012-11-20T00:00:00_GBP_D";
		MapEvent data = new MapEvent();
		data.setEventType("ClearanceCreated");
		HashMap<String, Object> payloadMap = new HashMap<>();
		payloadMap.put(PriceConstants.PRODUCT_REF, "tpnb:055229003");
		List<Map<String,Object>>locations = new ArrayList<>();
		Map<String,Object> clearanceMap = new HashMap<>();
		Map<String,Object> locationMap = new HashMap<String,Object>();
		locationMap.put(PriceConstants.LOC_TYPE, "Z");
		locationMap.put(PriceConstants.LOC_REF, "20");
		clearanceMap.put(PriceConstants.PRICING_LOC, locationMap);
		clearanceMap.put(PriceConstants.CLEARANCE_OFFER_ID, "MM");
		locations.add(clearanceMap);
		payloadMap.put(PriceConstants.CLEARANCES, locations);
		data.setPayloadData(payloadMap);

		HashMap<String, String> headerMap = new HashMap<>();
		headerMap.put(PriceConstants.EVENT_CORR_ID, PriceConstants.EVENT_CORR_ID_PREFIX + key);
		headerMap.put(PriceConstants.COUNTRY, "GB");
		headerMap.put(PriceConstants.EVENT_TYPE, "ClearanceDeleted");
		headerMap.put(PriceConstants.LEAD_TIME_DAYS, "0");
		data.setHeaderData(headerMap);

		CommonEventPublishingUtility.publishEvent(eventTemplate, data);
		ArgumentCaptor<EventData> argument = ArgumentCaptor.forClass(EventData.class);
		Mockito.verify(eventTemplate, Mockito.times(1)).publishEvent(argument.capture());
		Map<String, String> headerMapActual = argument.getValue().getHeaderData();
		Assert.assertEquals("GB", headerMapActual.get(PriceConstants.COUNTRY));
		Assert.assertEquals(PriceConstants.CLEARANCE_DELETED_EVENT_TYPE,
				headerMapActual.get(PriceConstants.EVENT_TYPE));
		Assert.assertEquals("0", headerMapActual.get(PriceConstants.LEAD_TIME_DAYS));

		Map<?, ?> payloadMapActual = (Map<?, ?>) (argument.getValue()).getPayloadData();
		Assert.assertEquals("tpnb:055229003", payloadMapActual.get(PriceConstants.PRODUCT_REF));
		Assert.assertEquals(locations, payloadMapActual.get(PriceConstants.CLEARANCES));
	}
	
	@Test
	public void shouldAddOnlyLeastDateInMapTest() throws Exception {
		String date = "2016-06-14T00:00:00+01:00";
		String previousDate = "2016-06-13T00:00:00+01:00";
		String leastDateString = "2016-06-12T00:00:00+01:00";
		DateTime leastDate = new DateTime(leastDateString);
		Map<String,DateTime>leastEffectiveDateMap = new HashMap<>();
		CommonEventPublishingUtility.addOnlyLeastEffectiveDate(leastEffectiveDateMap, date, "12345");
		CommonEventPublishingUtility.addOnlyLeastEffectiveDate(leastEffectiveDateMap, previousDate, "12345");
		CommonEventPublishingUtility.addOnlyLeastEffectiveDate(leastEffectiveDateMap, leastDateString, "12345");
		Assert.assertEquals( leastDate,leastEffectiveDateMap.get("12345"));
	}
}