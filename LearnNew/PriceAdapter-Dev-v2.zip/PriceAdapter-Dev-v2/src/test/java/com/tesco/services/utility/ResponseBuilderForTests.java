package com.tesco.services.utility;

import com.google.common.base.Optional;
import com.tesco.services.core.*;
import com.tesco.services.repositories.RepositoryImpl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by QU17 on 19/03/2015.
 */
public class ResponseBuilderForTests {
    private RepositoryImpl repositoryImpl;

    public ResponseBuilderForTests(RepositoryImpl repositoryImpl){
        this.repositoryImpl = repositoryImpl;
    }
    public Map<String, Object> getExpectedProductPriceMap(Product pricePromoProduct,ClearanceProduct rpmClrProd,ClearanceMMProduct mmClrProd,Store store) throws Exception {
        Map<String, Object> priceInfo = new LinkedHashMap<>();
        List<Map<String, Object>> variants = new ArrayList<>();
        Map<String, Object> variantInfo;
        List<Map<String, String>> promotions ;
        Optional<Integer> priceZone;
        Optional<Integer> promoZone;
        String storeId=null;
        Map<String,String> pricingLocMap= new LinkedHashMap<String,String>();

        if(store!=null){
            storeId = store.getStoreId();
            priceZone = store.getPriceZoneId();
            promoZone = store.getPromoZoneId();
            promotions = addPromotionInfo(pricePromoProduct,promoZone.get().toString());
            String mmClrPrice = mmClrProd!=null?getMmClrPrice(mmClrProd,storeId):null;
            pricingLocMap.put(PriceConstants.LOC_TYPE,PriceConstants.STORE);
            pricingLocMap.put(PriceConstants.LOC_REF,storeId);
            for (ProductVariant productVariant : pricePromoProduct.getProductVariantByTPNC().values()) {
                variantInfo = new LinkedHashMap<>();
                variantInfo.put(PriceConstants.TPNC_IDENTIFIER,productVariant.getTPNC());
                variantInfo.put(PriceConstants.CURRENCY,store.getCurrency());
                variantInfo.put(PriceConstants.SELLING_UOM,productVariant.getSellingUOM());
                String regPrice = getPriceForVariant(productVariant, priceZone.get().toString());
                if(regPrice!=null) {
                    variantInfo.put(PriceConstants.PRICE, Dockyard.priceScaleRoundHalfUp(store.getCurrency(),regPrice));
                }
                variantInfo.put(PriceConstants.PROMO_PRICE,Dockyard.priceScaleRoundHalfUp(store.getCurrency(), getPriceForVariant(productVariant,promoZone.get().toString())));
                String rpmClrPrice = rpmClrProd!=null?getRpmClrPrice(rpmClrProd.getClearanceProductVariantByTPNC(productVariant.getTPNC()), storeId):null;
                variantInfo.put(PriceConstants.CLEARANCE_PRICE, Dockyard.lowestOfTwoNum(mmClrPrice,rpmClrPrice));
                String authPrice = Dockyard.lowestOfTwoNum(Dockyard.lowestOfTwoNum(
                                (String) variantInfo.get(PriceConstants.PROMO_PRICE),
                                (String) variantInfo.get(PriceConstants.CLEARANCE_PRICE)),
                        (String) variantInfo.get(PriceConstants.PRICE));
                variantInfo.put(PriceConstants.AUTH_PRICE, authPrice);
                variants.add(variantInfo);
            }

        }else{
            priceZone = Optional.of(1);
            promoZone = Optional.of(5);
            promotions = addPromotionInfo(pricePromoProduct,promoZone.get().toString());
            String mmClrPrice = mmClrProd!=null?getMmClrPrice(mmClrProd,storeId):null;
            pricingLocMap.put(PriceConstants.LOC_TYPE,PriceConstants.NATIONAL);
            pricingLocMap.put(PriceConstants.LOC_REF,PriceConstants.LOC_REF_COUNTRY);
            for (ProductVariant productVariant : pricePromoProduct.getProductVariantByTPNC().values()) {
                variantInfo = new LinkedHashMap<>();
                variantInfo.put(PriceConstants.TPNC_IDENTIFIER,productVariant.getTPNC());
                variantInfo.put(PriceConstants.CURRENCY,"GBP");
                variantInfo.put(PriceConstants.SELLING_UOM,productVariant.getSellingUOM());
                String regPrice = getPriceForVariant(productVariant, priceZone.get().toString());
                if(regPrice!=null) {
                    variantInfo.put(PriceConstants.PRICE, Dockyard.priceScaleRoundHalfUp("GBP",regPrice));
                }
                variantInfo.put(PriceConstants.PROMO_PRICE,Dockyard.priceScaleRoundHalfUp("GBP", getPriceForVariant(productVariant,promoZone.get().toString())));
                String rpmClrPrice = rpmClrProd!=null?getRpmClrPrice(rpmClrProd.getClearanceProductVariantByTPNC(productVariant.getTPNC()), storeId):null;
                variantInfo.put(PriceConstants.CLEARANCE_PRICE, Dockyard.lowestOfTwoNum(mmClrPrice,rpmClrPrice));
                String authPrice = Dockyard.lowestOfTwoNum(Dockyard.lowestOfTwoNum(
                                (String) variantInfo.get(PriceConstants.PROMO_PRICE),
                                (String) variantInfo.get(PriceConstants.CLEARANCE_PRICE)),
                        (String) variantInfo.get(PriceConstants.PRICE));
                variantInfo.put(PriceConstants.AUTH_PRICE, authPrice);
                variants.add(variantInfo);
            }


        }
        priceInfo.put(PriceConstants.TPNB_IDENTIFIER,pricePromoProduct.getTPNB());
        priceInfo.put(PriceConstants.PRICING_DATE,Dockyard.getSysDate("yyyyMMdd"));
        priceInfo.put(PriceConstants.PRICING_LOC,pricingLocMap);
        priceInfo.put(PriceConstants.VARIANTS,variants);
        priceInfo.put(PriceConstants.PROMOTION_INFO,promotions);
        return priceInfo;
    }
    private List<Map<String, String>> addPromotionInfo(Product product,String zoneId) {
        Collection<Promotion> promotions = product.getPromotions();
        List<Map<String, String>> promotionInfo = new ArrayList<>();
        if (promotions.isEmpty()) {
            return null;
        }
        for (Promotion promotion : promotions) {
            if (Integer.parseInt(zoneId)==promotion.getZoneId()) {
                Map<String, String> promotionInfoMap = new LinkedHashMap<>();
                promotionInfoMap.put(PriceConstants.OFFER_ID, promotion.getOfferId());
                promotionInfoMap.put(PriceConstants.OFFER_NAME, promotion.getOfferName());
                promotionInfoMap.put(PriceConstants.EFFECTIVE_DATE,
                        promotion.getEffectiveDate());
                promotionInfoMap.put(PriceConstants.END_DATE, promotion.getEndDate());
                promotionInfoMap.put(PriceConstants.CUSTOMER_FRIENDLY_DESCRIPTION_1,
                        promotion.getCFDescription1());
                promotionInfoMap.put(PriceConstants.CUSTOMER_FRIENDLY_DESCRIPTION_2,
                        promotion.getCFDescription2());
                promotionInfo.add(promotionInfoMap);
            }
        }
        return promotionInfo;
    }
    private String getMmClrPrice(ClearanceMMProduct clearanceMMProduct,String storeId) throws Exception {
        String mmClrPrice="";
        ClearanceZoneSaleInfo mmclearZoneSaleInfo = null ;
        ClearanceStoreSaleInfo mmClearStoreSaleInfo = null;

        if(storeId!=null){
            mmClearStoreSaleInfo = clearanceMMProduct.getClearanceStoreSaleInfo(storeId);
            mmclearZoneSaleInfo = clearanceMMProduct.getClearanceZoneSaleInfo("20");
            mmClrPrice = checkStoreAndZoneForClrPrice(mmclearZoneSaleInfo, mmClearStoreSaleInfo);
        }else{
            mmclearZoneSaleInfo = clearanceMMProduct.getClearanceZoneSaleInfo("20");
            mmClrPrice = checkStoreAndZoneForClrPrice(mmclearZoneSaleInfo, mmClearStoreSaleInfo);
        }
        return mmClrPrice;
    }
    private String checkStoreAndZoneForClrPrice( ClearanceZoneSaleInfo mmclearZoneSaleInfo, ClearanceStoreSaleInfo mmClearStoreSaleInfo) throws Exception {

        String clrPrice=null;
        if (!Dockyard.isSpaceOrNull(mmclearZoneSaleInfo)) {
            for (ClearanceByDateTime clearanceByDateTime : mmclearZoneSaleInfo
                    .getZoneClearancePriceByDateTime().values()) {
                if (Dockyard.checkActiveaClear(
                        clearanceByDateTime.getEffvDateTime(),
                        clearanceByDateTime.getEndDateTime())) {

                    clrPrice = String.valueOf(Dockyard.lowestOfTwoNum(
                            clrPrice,
                            clearanceByDateTime.getClearancePrice()));
                    break;

                }
            }
        }
        if (!Dockyard.isSpaceOrNull(mmClearStoreSaleInfo)) {
            for (ClearanceByDateTime clearanceByDateTime : mmClearStoreSaleInfo
                    .getStoresClearancePriceByDateTime()) {

                if (Dockyard.checkActiveaClear(
                        clearanceByDateTime.getEffvDateTime(),
                        clearanceByDateTime.getEndDateTime())) {
                    clrPrice = String.valueOf(Dockyard.lowestOfTwoNum(
                            clrPrice,
                            clearanceByDateTime.getClearancePrice()));
                    break;

                }
            }
        }
        return clrPrice;
    }
    private String getPriceForVariant(ProductVariant productVariant,String zoneId){
        SaleInfo saleInfo = productVariant.getSaleInfo(Integer.parseInt(zoneId));
        return saleInfo!=null?saleInfo.getPrice():null;
    }
    private String getRpmClrPrice(ClearanceProductVariant clearanceProductVariant,String storeId) throws Exception {
        String rpmClrPrice;
        ClearanceZoneSaleInfo rpmClearZoneSaleInfo = null ;
        ClearanceStoreSaleInfo rpmClearStoreSaleInfo = null;

        if(storeId!=null){
            rpmClearStoreSaleInfo = clearanceProductVariant.getClearanceStoreSaleInfo(storeId);
            rpmClearZoneSaleInfo = clearanceProductVariant.getClearanceZoneSaleInfo("20");
            rpmClrPrice = checkStoreAndZoneForClrPrice(rpmClearZoneSaleInfo, rpmClearStoreSaleInfo);
        }else{
            rpmClearZoneSaleInfo = clearanceProductVariant.getClearanceZoneSaleInfo("20");
            rpmClrPrice = checkStoreAndZoneForClrPrice(rpmClearZoneSaleInfo, rpmClearStoreSaleInfo);
        }

        return rpmClrPrice;
    }
    public Product getProductForVaraint(Product product, String tpnc) {
        Collection<Promotion> promotionsInProduct;
        Product productForVar = new Product(product.getTPNB());
        ProductVariant productVariant ;
        promotionsInProduct = product.getPromotions();
        for (Promotion promotion : promotionsInProduct) {
            productForVar.addPromotion(promotion);
        }
        productVariant = product.getProductVariantByTPNC(tpnc);
        productForVar.addProductVariant(productVariant);
        return productForVar;
    }
    public ClearanceProduct getClrProductForVaraint(ClearanceProduct rpmClrProd, String tpnc) {
        ClearanceProductVariant toBeMainTainedVar = rpmClrProd.getClearanceProductVariantByTPNC(tpnc);
        rpmClrProd.getTpncToClearanceProductVariant().clear();
        rpmClrProd.addClearanceProductVariant(toBeMainTainedVar);
        return rpmClrProd;
    }

    public Map<String,ProductVariant> createProductVariants(List<String> tpncList,String sellingUom,Map<Integer,String> priceZone, Map<Integer,String> promoZone){

        Map<String,ProductVariant> varaints = new LinkedHashMap<>();
        ProductVariant productVariant = null;
        for(String tpnc:tpncList) {
            productVariant =  new ProductVariant(tpnc);
            for (Integer priceZoneId : priceZone.keySet()) {
                String price = priceZone.get(priceZoneId);
                productVariant.addSaleInfo(new SaleInfo(priceZoneId, price));
            }
            for (Integer promoZoneId : promoZone.keySet()) {
                String price = promoZone.get(promoZoneId);
                productVariant.addSaleInfo(new SaleInfo(promoZoneId, price));
            }
            productVariant.setSellingUOM(sellingUom);
            varaints.put(tpnc,productVariant);
        }
        return varaints;
    }
    public Product createProductWithVaraintsAndPromotions(String tpnb,Map<String,ProductVariant> variants,List<Promotion> promotions)
            throws Exception {
        Product product = new Product(tpnb);
        product.setLast_updated_date(Dockyard.getSysDate("yyyymmdd"));
        int variantCount =0;
        for(String tpnc:variants.keySet()){
            ProductVariant productVariant = variants.get(tpnc);
            product.addProductVariant(productVariant);
            if(variantCount>0){
                tpnb = tpnb+"-00"+variantCount;
            }
            repositoryImpl.mapLookUps(tpnc, tpnb);
            variantCount++;
        }
        if(promotions!=null) {
            for (Promotion promotion : promotions) {
                product.addPromotion(promotion);
            }
        }
        repositoryImpl.insertObject(
                PriceConstants.PRODUCT_KEY_PREFIX + product.getTPNB(), product);
        return product ;
    }
    public Promotion createPromotion(int zoneId,String offerId) {
        DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
        Calendar cal = Calendar.getInstance();
        String effectiveDate = dateFormat.format(cal.getTime());
        cal.add(Calendar.DATE,+(30));
        String endDate = dateFormat.format(cal.getTime());
        Promotion promotion = new Promotion();
        promotion.setOfferId(offerId);
        promotion.setZoneId(zoneId);
        promotion.setEffectiveDate(effectiveDate);
        promotion.setEndDate(endDate);
        promotion.setOfferName("Test Offer Name " + offerId);
        promotion.setCFDescription1("Test Description 1 " + offerId);
        promotion.setCFDescription2("Test Description 2 " + offerId);
        return promotion;
    }
    public ClearanceProduct createRpmClearanceWithVaraints(String productId, List<String> tpncList, String zoneSellingPrice, String storeSellingPrice,String currencyCode,Store store) throws Exception {
        DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");
        Calendar cal = Calendar.getInstance();
        String eff_date = dateFormat.format(cal.getTime());
        cal.add(Calendar.DATE, 10);
        String end_date = dateFormat.format(cal.getTime());
        String clearance_id = "ACY-1224988440";
        ClearanceZoneSaleInfo clearanceZoneSaleInfo = null;
        ClearanceStoreSaleInfo clearanceStoreSaleInfo =null;

        ClearanceProduct expectedClearanceProduct =createClearanceProduct(productId);
        if(zoneSellingPrice!=null) {
            ClearanceByDateTime clearanceByDateTimeForZone = createClearanceByDateTime(eff_date, end_date, clearance_id,currencyCode, zoneSellingPrice);
            clearanceZoneSaleInfo = createClearanceZoneSaleInfo(currencyCode.equals("GBP")?"20":"21", currencyCode, currencyCode.equals("GBP")?"UK":"IE", clearanceByDateTimeForZone);
        }
        if(storeSellingPrice!=null) {
            ClearanceByDateTime clearanceByDateTimeForStore = createClearanceByDateTime(eff_date, end_date, clearance_id, currencyCode, storeSellingPrice);
            clearanceStoreSaleInfo = createClearanceStoreSaleInfo(store, clearanceByDateTimeForStore);
        }
        for(String tpnc:tpncList) {
            ClearanceProductVariant clearanceProductVariant = createClearanceProductVariant(tpnc, clearanceZoneSaleInfo, clearanceStoreSaleInfo);
            expectedClearanceProduct.addClearanceProductVariant(clearanceProductVariant);
        }
        repositoryImpl.insertObject(
                PriceConstants.CLEARANCE_KEY_PREFIX + expectedClearanceProduct
                        .getProductId(), expectedClearanceProduct);
        return expectedClearanceProduct;
    }
    public ClearanceMMProduct createMMClearance(String productId, String zoneSellingPrice, String storeSellingPrice,String currencyCode,Store store) throws Exception {
        DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");
        Calendar cal = Calendar.getInstance();
        String eff_date = dateFormat.format(cal.getTime());
        cal.add(Calendar.DATE, 10);
        String end_date = dateFormat.format(cal.getTime());
        String clearance_id = "MM";
        ClearanceZoneSaleInfo clearanceZoneSaleInfo = null;
        ClearanceStoreSaleInfo clearanceStoreSaleInfo = null;

        if(zoneSellingPrice!=null) {
            ClearanceByDateTime clearanceByDateTimeForZone = createClearanceByDateTime(eff_date, end_date, clearance_id,currencyCode, zoneSellingPrice);
            clearanceZoneSaleInfo = createClearanceZoneSaleInfo("20", "UK", "GBP", clearanceByDateTimeForZone);
        }
        if(storeSellingPrice!=null) {
            ClearanceByDateTime clearanceByDateTimeForStore = createClearanceByDateTime(eff_date, end_date, clearance_id, currencyCode,storeSellingPrice);
            clearanceStoreSaleInfo = createClearanceStoreSaleInfo(store, clearanceByDateTimeForStore);

        }
        ClearanceMMProduct expectedClearanceProduct = createClearanceMMProduct(productId, clearanceZoneSaleInfo, clearanceStoreSaleInfo);
        repositoryImpl.insertObject(
                PriceConstants.CLEARANCE_MM_PRODUCT_KEY_PREFIX
                        + expectedClearanceProduct.getProductId(),
                expectedClearanceProduct);
        return expectedClearanceProduct;
    }
    public ClearanceProduct createClearanceProduct(String productId) {
        ClearanceProduct clearanceProduct = new ClearanceProduct(productId);
        String docType = "datedPrice";
        String dateTimeFormat = "ISO8601";
        String countryFormat = "ISO3166";
        String currencyFormat = "ISO4217";
        String version = "1.0";
        String prodType = "tpnb";
        clearanceProduct.setVersionNo(version);
        clearanceProduct.setDocType(docType);
        clearanceProduct.setCountryFormat(countryFormat);
        clearanceProduct.setCurrencyFormat(currencyFormat);
        clearanceProduct.setDateTimeFormat(dateTimeFormat);
        clearanceProduct.setProdType(prodType);
        clearanceProduct.setSellingUom("EA");

        return clearanceProduct;
    }
    public ClearanceMMProduct createClearanceMMProduct(String productId, ClearanceZoneSaleInfo clearanceZoneSaleInfo, ClearanceStoreSaleInfo clearanceStoreSaleInfo) {
        ClearanceMMProduct clearanceProduct = new ClearanceMMProduct(productId);
        String docType = "datedPrice";
        String dateTimeFormat = "ISO8601";
        String countryFormat = "ISO3166";
        String currencyFormat = "ISO4217";
        String version = "1.0";
        String prodType = "tpnb";
        clearanceProduct.setVersionNo(version);
        clearanceProduct.setDocType(docType);
        clearanceProduct.setCountryFormat(countryFormat);
        clearanceProduct.setCurrencyFormat(currencyFormat);
        clearanceProduct.setDateTimeFormat(dateTimeFormat);
        clearanceProduct.setProdType(prodType);
        clearanceProduct.setSellingUom("EA");
        if (clearanceZoneSaleInfo != null) {
            clearanceProduct.addClearanceZoneSaleInfo(clearanceZoneSaleInfo);
        }
        if (clearanceStoreSaleInfo != null) {
            clearanceProduct.addClearanceStoreSaleInfo(clearanceStoreSaleInfo);
        }
        return clearanceProduct;
    }
    public ClearanceStoreSaleInfo createClearanceStoreSaleInfo(Store store, ClearanceByDateTime clearanceByDateTime) throws Exception {
        ClearanceStoreSaleInfo clearanceStoreSaleInfo = new ClearanceStoreSaleInfo();
        clearanceStoreSaleInfo.setClearanceStoreId(store.getStoreId());
        clearanceStoreSaleInfo.setCountryCode(store.getCurrency().equals("GBP")?"UK":"IE");
        clearanceStoreSaleInfo.setCurrency(store.getCurrency());
        if (clearanceByDateTime != null) {
            clearanceStoreSaleInfo.addStoreClearanceByDateTime(clearanceByDateTime);
        }
        return clearanceStoreSaleInfo;
    }

    public ClearanceByDateTime createClearanceByDateTime(String effcDate, String endDate, String clrRef,String currencyCode, String clrPrice) throws Exception {
        ClearanceByDateTime clearanceByDateTime = new ClearanceByDateTime();
        clearanceByDateTime.setEffvDateTime(Dockyard.getISO8601FormatStartDateForRpmClr(effcDate));
        clearanceByDateTime.setEndDateTime(Dockyard.getISO8601FormatEndDateForRPMClr(endDate));
        clearanceByDateTime.setClearanceRef(clrRef);
        clearanceByDateTime.setClearancePrice(Dockyard.priceScaleRoundHalfUp(currencyCode, clrPrice));
        return clearanceByDateTime;
    }
    public ClearanceZoneSaleInfo createClearanceZoneSaleInfo(String zone, String country, String currency, ClearanceByDateTime clearanceByDateTime) throws Exception {
        ClearanceZoneSaleInfo clearanceZoneSaleInfo = new ClearanceZoneSaleInfo();
        clearanceZoneSaleInfo.setClearanceZoneId(zone);
        clearanceZoneSaleInfo.setCountryCode(country);
        clearanceZoneSaleInfo.setCurrency(currency);
        if (clearanceByDateTime != null) {
            clearanceZoneSaleInfo.addZoneClearanceByDateTime(clearanceByDateTime);
        }
        return clearanceZoneSaleInfo;
    }
    public ClearanceProductVariant createClearanceProductVariant(String tpnc, ClearanceZoneSaleInfo clearanceZoneSaleInfo, ClearanceStoreSaleInfo clearanceStoreSaleInfo) {
        ClearanceProductVariant clearanceProductVariant = new ClearanceProductVariant(tpnc);
        if (clearanceZoneSaleInfo != null) {
            clearanceProductVariant.addClearanceZoneSaleInfo(clearanceZoneSaleInfo);
        }
        if (clearanceStoreSaleInfo != null) {
            clearanceProductVariant.addClearanceStoreSaleInfo(clearanceStoreSaleInfo);
        }
        return clearanceProductVariant;
    }
    public Map<String,Object> getExpectedErrorMap(String productId, int responseStatusCode, String errorMessage) {
        Map<String,Object> errorMap = new LinkedHashMap<>();
        errorMap.put(PriceConstants.ERROR_PROD_ID,productId);
        errorMap.put(PriceConstants.ERROR_STATUS_CODE,responseStatusCode);
        errorMap.put(PriceConstants.ERROR_MESSAGE,errorMessage);
        return errorMap;
    }
    public List<String> getDynamicItem(String id,int itemsCount){
        java.util.Random rand = new java.util.Random();
        List<String> itemsList = new LinkedList<>();
        int newData;
        for(int i =1;i<=itemsCount;i++)
        {
            newData = (Integer.parseInt(id) + rand.nextInt(1000000));
            String newItem = Integer.toString(newData);
            newItem = id.startsWith("0")?"0"+newItem:newItem;
            itemsList.add(newItem);

        }
        Collections.sort(itemsList);
        return itemsList;
    }
}
