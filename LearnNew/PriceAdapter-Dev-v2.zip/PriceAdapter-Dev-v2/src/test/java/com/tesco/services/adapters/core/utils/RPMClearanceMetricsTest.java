package com.tesco.services.adapters.core.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.codahale.metrics.Counter;
import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.Timer;

public class RPMClearanceMetricsTest {

	static RPMClearanceMetrics rpmClearanceMetrics = RPMClearanceMetrics
			.getInstance();;
	static MetricRegistry mmetricRegisty = RPMClearanceMetrics
			.getMetricsRegistry();
	Map metricsMap = null;

	@Before
	public void setUp() throws Exception {
		mmetricRegisty = RPMClearanceMetrics.getMetricsRegistry();
	}

	@After
	public void tearDown() throws Exception {

	}

	@Test
	public void logMessageProcessingStartTime() throws Exception {
		String name = MetricRegistry.name("com.tesco",
				"RPMClearanceElapsedTimeAndRate", "time-to-process-message");
		metricsMap = mmetricRegisty.getTimers();
		rpmClearanceMetrics.logMessageProcessingStartTime();
		rpmClearanceMetrics.logMessageProcessingEndTime();
		assertNotEquals(0, ((Timer) metricsMap.get(name)).getCount());
	}

	@Test
	public void logCreClearanceProcessingStartTime() throws Exception {
		String name = MetricRegistry
				.name("com.tesco", "RPMClearanceElapsedTimeAndRate",
						"time-to-process-cre-message");
		metricsMap = mmetricRegisty.getTimers();

		rpmClearanceMetrics.logCreClearanceProcessingStartTime();
		rpmClearanceMetrics.logCreClearanceProcessingEndTime();
		assertNotEquals(0, ((Timer) metricsMap.get(name)).getCount());
	}

	@Test
	public void logModClearanceProcessingStartTime() throws Exception {
		String name = MetricRegistry
				.name("com.tesco", "RPMClearanceElapsedTimeAndRate",
						"time-to-process-mod-message");
		metricsMap = mmetricRegisty.getTimers();

		rpmClearanceMetrics.logModClearanceProcessingStartTime();
		rpmClearanceMetrics.logModClearanceProcessingEndTime();

		assertNotEquals(0, ((Timer) metricsMap.get(name)).getCount());
	}

	@Test
	public void logDelClearanceProcessingStartTime() throws Exception {
		String name = MetricRegistry
				.name("com.tesco", "RPMClearanceElapsedTimeAndRate",
						"time-to-process-del-message");
		metricsMap = mmetricRegisty.getTimers();

		rpmClearanceMetrics.logDelClearanceProcessingStartTime();
		rpmClearanceMetrics.logDelClearanceProcessingEndTime();
		assertNotEquals(0, ((Timer) metricsMap.get(name)).getCount());
	}

	@Ignore
	public void incrementCreErrorCount() throws Exception {
		String name = MetricRegistry.name("com.tesco",
				"RPMClearanceMessageProcessingErrors",
				"total-cre-error-message-count");
		metricsMap = rpmClearanceMetrics.getMetricsRegistry().getCounters();

		rpmClearanceMetrics.incrementCreErrorCount();
		assertEquals(1, ((Counter) metricsMap.get(name)).getCount());
	}

	@Ignore
	public void incrementModErrorCount() throws Exception {
		String name = MetricRegistry.name("com.tesco",
				"RPMClearanceMessageProcessingErrors",
				"total-mod-error-message-count");
		metricsMap = rpmClearanceMetrics.getMetricsRegistry().getCounters();

		rpmClearanceMetrics.incrementModErrorCount();
		assertEquals(1, ((Counter) metricsMap.get(name)).getCount());
	}

	@Ignore
	public void incrementDelErrorCount() throws Exception {
		String name = MetricRegistry.name("com.tesco",
				"RPMClearanceMessageProcessingErrors",
				"total-del-error-message-count");
		metricsMap = rpmClearanceMetrics.getMetricsRegistry().getCounters();
		rpmClearanceMetrics.incrementDelErrorCount();
		assertEquals(1, ((Counter) metricsMap.get(name)).getCount());
	}

	@Ignore
	public void resetCounters() throws Exception {
		String name = MetricRegistry.name("com.tesco",
				"RPMClearanceMessageProcessingErrors",
				"total-cre-error-message-count");
		rpmClearanceMetrics.incrementCreErrorCount();
		metricsMap = rpmClearanceMetrics.getMetricsRegistry().getCounters();
		assertEquals(1, ((Counter) metricsMap.get(name)).getCount());
		rpmClearanceMetrics.resetCounters();
		metricsMap = rpmClearanceMetrics.getMetricsRegistry().getCounters();
		assertEquals(0, ((Counter) metricsMap.get(name)).getCount());
	}

}
