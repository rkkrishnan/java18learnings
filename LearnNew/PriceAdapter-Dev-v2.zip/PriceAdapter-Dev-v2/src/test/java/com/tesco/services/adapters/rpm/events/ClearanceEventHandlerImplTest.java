package com.tesco.services.adapters.rpm.events;

import static com.tesco.services.utility.PriceConstants.CLEARANCES;
import static com.tesco.services.utility.PriceConstants.CLEARANCE_CREATED_EVENT_TYPE;
import static com.tesco.services.utility.PriceConstants.CLEARANCE_DELETED_EVENT_TYPE;
import static com.tesco.services.utility.PriceConstants.CLEARANCE_END_DATE_CHANGED_EVENT_TYPE;
import static com.tesco.services.utility.PriceConstants.CLEARANCE_OFFER_ID;
import static com.tesco.services.utility.PriceConstants.CLEARANCE_PREV_PRICE_CHANGE_EVENT_TYPE;
import static com.tesco.services.utility.PriceConstants.COUNTRY;
import static com.tesco.services.utility.PriceConstants.EVENT_CORR_ID;
import static com.tesco.services.utility.PriceConstants.EVENT_CORR_ID_PREFIX;
import static com.tesco.services.utility.PriceConstants.EVENT_TYPE;
import static com.tesco.services.utility.PriceConstants.LEAD_TIME_DAYS;
import static com.tesco.services.utility.PriceConstants.LOC_REF;
import static com.tesco.services.utility.PriceConstants.LOC_TYPE;
import static com.tesco.services.utility.PriceConstants.PRICING_LOC;
import static com.tesco.services.utility.PriceConstants.PRODUCT_REF;
import static org.junit.Assert.*;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.tesco.services.adapters.rpm.events.impl.ClearanceEventData;
import com.tesco.services.adapters.rpm.events.impl.ClearanceEventHandlerImpl;
import org.joda.time.DateTime;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.tesco.services.event.core.EventTemplate;
import com.tesco.services.event.core.impl.EventData;
import com.tesco.services.event.core.impl.MapEvent;
import com.tesco.services.event.exception.EventPublishException;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.PriceConstants;

/**
 * This is the test class for ClearanceEventHandlerImpl for it's public methods
 */
@RunWith(MockitoJUnitRunner.class)
public class ClearanceEventHandlerImplTest {

	@Mock
	private EventTemplate eventTemplate;

	private ClearanceEventHandlerImpl clearanceEventHandler;
	
	@Captor 
	private ArgumentCaptor<MapEvent> argument;

	@Test
	public void shouldSendEventsDataForMMNationalInsertTest() throws ParseException, EventPublishException {
		ClearanceEventData clearanceEventMap = new ClearanceEventData();
		DateTime dateTime = new DateTime();
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		String eff_date2 = dateFormat.format(dateTime.toDate().getTime());
		String formattedEffDate = Dockyard.getISO8601FormatStartDate(eff_date2);
		String key = "tpnb:055229003_N_"+formattedEffDate+"_GBP_I";
		Set<String> nationalSet = new HashSet<String>();
		nationalSet.add("Z_20_MM");
		clearanceEventMap.put(key, nationalSet);
		clearanceEventHandler.publishEventsForClearances(clearanceEventMap);
		Mockito.verify(eventTemplate, Mockito.times(1)).publishEvent(argument.capture());
		assertSame(CLEARANCE_CREATED_EVENT_TYPE, argument.getValue().getEventType());

		Map<String, String> headerMap = argument.getValue().getHeaderData();
		assertEquals("GB", headerMap.get(PriceConstants.COUNTRY));
		assertEquals(CLEARANCE_CREATED_EVENT_TYPE, headerMap.get(EVENT_TYPE));
		assertEquals("0", headerMap.get(LEAD_TIME_DAYS));

		Map<String, Object> payloadMap = argument.getValue().getPayloadData();
		assertEquals("tpnb:055229003", payloadMap.get(PriceConstants.PRODUCT_REF));
		List<Map<String,Object>> locations = new ArrayList<Map<String,Object>>();
		Map<String,Object> clearanceMap = new HashMap<>();
		Map<String,Object> locationMap = new HashMap<String,Object>();
		locationMap.put(LOC_TYPE, "Z");
		locationMap.put(LOC_REF, "20");
		clearanceMap.put(PRICING_LOC, locationMap);
		clearanceMap.put(CLEARANCE_OFFER_ID, "MM");
		locations.add(clearanceMap);
		assertEquals(locations, payloadMap.get(CLEARANCES));
	}

	@Test(expected = EventPublishException.class)
	public void shouldThrowExceptionOnEventsDataForMMNationalInsertTest() throws Exception {
		DateTime dateTime = new DateTime();
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		String eff_date2 = dateFormat.format(dateTime.toDate().getTime());
		String formattedEffDate = Dockyard.getISO8601FormatStartDate(eff_date2);
		String key = "tpnb:055229003_N_"+formattedEffDate+"_GBP_I";
		MapEvent data = new MapEvent();
		data.setEventType("ClearanceCreated");
		
		List<Map<String,Object>> locations = new ArrayList<Map<String,Object>>();
		Map<String,Object> clearanceMap = new HashMap<>();
		Map<String,Object> locationMap = new HashMap<String,Object>();
		locationMap.put(PriceConstants.LOC_TYPE, "Z");
		locationMap.put(PriceConstants.LOC_REF, "20");
		clearanceMap.put(PriceConstants.PRICING_LOC, locationMap);
		clearanceMap.put(PriceConstants.CLEARANCE_OFFER_ID, "MM");
		locations.add(clearanceMap);
		
		HashMap<String, Object> payloadMap = new HashMap<>();
		payloadMap.put(PriceConstants.PRODUCT_REF, "tpnb:055229003");
		payloadMap.put(PriceConstants.CLEARANCES, locations);
		data.setPayloadData(payloadMap);

		HashMap<String, String> headerMap = new HashMap<>();
		headerMap.put(EVENT_CORR_ID, EVENT_CORR_ID_PREFIX+key);
		headerMap.put(COUNTRY, "GB");
		headerMap.put(EVENT_TYPE, "ClearanceCreated");
		headerMap.put(LEAD_TIME_DAYS, "0");
		data.setHeaderData(headerMap);
		Mockito.when(eventTemplate.publishEvent(data)).thenThrow(new EventPublishException(new Exception(), "Error"));

		ClearanceEventData clearanceEventMap = new ClearanceEventData();
		Set<String> nationalSet = new HashSet<String>();
		nationalSet.add("Z_20_MM");
		clearanceEventMap.put(key, nationalSet);
		clearanceEventHandler.publishEventsForClearances(clearanceEventMap);
	}

	@Before
	public void setUp() throws Exception {
		clearanceEventHandler = new ClearanceEventHandlerImpl(eventTemplate);
	}
	
		@Test
		public void shouldSendEventsDataForMMNationalDeleteTest() throws ParseException, EventPublishException {
			ClearanceEventData clearanceEventMap = new ClearanceEventData();
			String key = "tpnb:055229003_N_2012-11-20T00:00:00_GBP_D";
			Set<String> nationalSet = new HashSet<String>();
			nationalSet.add("Z_20_MM");
			clearanceEventMap.put(key, nationalSet);
			clearanceEventHandler.publishEventsForClearances(clearanceEventMap);
			ArgumentCaptor<EventData> argument = ArgumentCaptor.forClass(EventData.class);
			Mockito.verify(eventTemplate, Mockito.times(1)).publishEvent(argument.capture());
			assertSame(CLEARANCE_DELETED_EVENT_TYPE, argument.getValue().getEventType());
	
			Map<String, String> headerMap = (argument.getValue()).getHeaderData();
			assertEquals("GB", headerMap.get(COUNTRY));
			assertEquals(CLEARANCE_DELETED_EVENT_TYPE, headerMap.get(EVENT_TYPE));
			assertEquals("0", headerMap.get(LEAD_TIME_DAYS));
	
			Map<String, Object> payloadMap = (Map<String, Object>) (argument.getValue()).getPayloadData();
			assertEquals("tpnb:055229003", payloadMap.get(PRODUCT_REF));
			List<Map<String,Object>> locations = new ArrayList<Map<String,Object>>();
			Map<String,Object> clearanceMap = new HashMap<>();
			Map<String,Object> locationMap = new HashMap<String,Object>();
			locationMap.put(LOC_TYPE, "Z");
			locationMap.put(LOC_REF, "20");
			clearanceMap.put(PRICING_LOC, locationMap);
			clearanceMap.put(CLEARANCE_OFFER_ID, "MM");
			locations.add(clearanceMap);
			assertEquals(locations, payloadMap.get(CLEARANCES));
		}
	
		@Test(expected = EventPublishException.class)
		public void shouldThrowExceptionOnEventsDataForMMNationalDeleteTest() throws Exception {
			String key = "tpnb:055229003_N_2012-11-20T00:00:00_GBP_D";
			MapEvent data = new MapEvent();
			data.setEventType("ClearanceDeleted");
			HashMap<String, Object> payloadMap = new HashMap<>();
			payloadMap.put(PRODUCT_REF, "tpnb:055229003");
			List<Map<String,Object>> locations = new ArrayList<Map<String,Object>>();
			Map<String,Object> clearanceMap = new HashMap<>();
			Map<String,Object> locationMap = new HashMap<String,Object>();
			locationMap.put(LOC_TYPE, "Z");
			locationMap.put(LOC_REF, "20");
			clearanceMap.put(PRICING_LOC, locationMap);
			clearanceMap.put(CLEARANCE_OFFER_ID, "MM");
			locations.add(clearanceMap);
			payloadMap.put(CLEARANCES, locations);
			data.setPayloadData(payloadMap);
	
			HashMap<String, String> headerMap = new HashMap<>();
			headerMap.put(EVENT_CORR_ID, EVENT_CORR_ID_PREFIX + key);
			headerMap.put(COUNTRY, "GB");
			headerMap.put(EVENT_TYPE, "ClearanceDeleted");
			headerMap.put(LEAD_TIME_DAYS, "0");
			data.setHeaderData(headerMap);
	
			Mockito.when(eventTemplate.publishEvent(data)).thenThrow(new EventPublishException(new Exception(), "Error"));
	
			ClearanceEventData clearanceEventMap = new ClearanceEventData();
			Set<String> nationalSet = new HashSet<String>();
			nationalSet.add("Z_20_MM");
			clearanceEventMap.put(key, nationalSet);
			clearanceEventHandler.publishEventsForClearances(clearanceEventMap);
		}
		
		@Test
		public void shouldSendEventsDataForMMNationalClearanceEndDateChangedUpdateTest() throws ParseException, EventPublishException {
			ClearanceEventData clearanceEventMap = new ClearanceEventData();
			DateTime dateTime = new DateTime();
			DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
			String endDate = dateFormat.format(dateTime.toDate().getTime());
			String formattedEndDate = Dockyard.getISO8601FormatStartDate(endDate);
			String key = "tpnb:055229003_N_"+formattedEndDate+"_GBP_U-CLR-END-DATE";
			Set<String> nationalSet = new HashSet<String>();
			nationalSet.add("Z_20_MM");
			clearanceEventMap.put(key, nationalSet);
			clearanceEventHandler.publishEventsForClearances(clearanceEventMap);
			ArgumentCaptor<EventData> argument = ArgumentCaptor.forClass(EventData.class);
			Mockito.verify(eventTemplate, Mockito.times(1)).publishEvent(argument.capture());
			assertSame(CLEARANCE_END_DATE_CHANGED_EVENT_TYPE, argument.getValue().getEventType());
	
			Map<String, String> headerMap = (argument.getValue()).getHeaderData();
			assertEquals("GB", headerMap.get(COUNTRY));
			assertEquals(CLEARANCE_END_DATE_CHANGED_EVENT_TYPE, headerMap.get(EVENT_TYPE));
			assertEquals("0", headerMap.get(LEAD_TIME_DAYS));
	
			Map<String, String> payloadMap = (Map<String, String>) (argument.getValue()).getPayloadData();
			assertEquals("tpnb:055229003", payloadMap.get(PRODUCT_REF));
			List<Map<String,Object>> locations = new ArrayList<Map<String,Object>>();
			Map<String,Object> clearanceMap = new HashMap<>();
			Map<String,Object> locationMap = new HashMap<String,Object>();
			locationMap.put(LOC_TYPE, "Z");
			locationMap.put(LOC_REF, "20");
			clearanceMap.put(PRICING_LOC, locationMap);
			clearanceMap.put(CLEARANCE_OFFER_ID, "MM");
			locations.add(clearanceMap);
		    assertEquals(locations, payloadMap.get(CLEARANCES));
		}
		
		@Test(expected = EventPublishException.class)
		public void shouldThrowExceptionOnEventsDataForMMNationalClearanceEndDateChangedUpdateTest() throws Exception {
			DateTime dateTime = new DateTime();
			DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
			String endDate = dateFormat.format(dateTime.toDate().getTime());
			String formattedEndDate = Dockyard.getISO8601FormatStartDate(endDate);
			String key = "tpnb:055229003_N_"+formattedEndDate+"_GBP_U-CLR-END-DATE";
			MapEvent data = new MapEvent();
			data.setEventType("ClearanceEndDateChanged");
			HashMap<String, Object> payloadMap = new HashMap<>();
			payloadMap.put(PriceConstants.PRODUCT_REF, "tpnb:055229003");
			List<Map<String,Object>> locations = new ArrayList<Map<String,Object>>();
			Map<String,Object> clearanceMap = new HashMap<>();
			Map<String,Object> locationMap = new HashMap<String,Object>();
			locationMap.put(LOC_TYPE, "Z");
			locationMap.put(LOC_REF, "20");
			clearanceMap.put(PRICING_LOC, locationMap);
			clearanceMap.put(CLEARANCE_OFFER_ID, "MM");
			locations.add(clearanceMap);
			payloadMap.put(CLEARANCES, locations);
			data.setPayloadData(payloadMap);

			HashMap<String, String> headerMap = new HashMap<>();
			headerMap.put(EVENT_CORR_ID, EVENT_CORR_ID_PREFIX+key);
			headerMap.put(COUNTRY, "GB");
			headerMap.put(EVENT_TYPE, "ClearanceEndDateChanged");
			headerMap.put(LEAD_TIME_DAYS, "0");
			data.setHeaderData(headerMap);

			Mockito.when(eventTemplate.publishEvent(data)).thenThrow(new EventPublishException(new Exception(), "Error"));

			ClearanceEventData clearanceEventMap = new ClearanceEventData();
			Set<String> nationalSet = new HashSet<String>();
			nationalSet.add("Z_20_MM");
			clearanceEventMap.put(key, nationalSet);
			clearanceEventHandler.publishEventsForClearances(clearanceEventMap);
		}
		
	@Test
	public void shouldPublishEventsForPreviousPriceChangeClearanceTest()
			throws ParseException, EventPublishException {
		ClearanceEventData clearanceEventMap = new ClearanceEventData();

		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 5);
		String effectiveDate = dateFormat.format(cal.getTime());

		String eventCorrelationKey = "tpnc:250000024_Z_" + effectiveDate + "_GB";
		Set<String> clearanceSet = new HashSet<String>();
		clearanceSet.add("Z_20_CL-1479643884");
		clearanceEventMap.put(eventCorrelationKey, clearanceSet);
		clearanceEventHandler.publishEventsForPreviousPriceChangeClearances(clearanceEventMap);

		ArgumentCaptor<EventData> argument = ArgumentCaptor.forClass(EventData.class);
		Mockito.verify(eventTemplate, Mockito.times(1)).publishEvent(argument.capture());
		assertSame(CLEARANCE_PREV_PRICE_CHANGE_EVENT_TYPE, argument.getValue().getEventType());

		Map<String, String> headerMap = (argument.getValue()).getHeaderData();
		assertEquals("GB", headerMap.get(COUNTRY));
		assertEquals(CLEARANCE_PREV_PRICE_CHANGE_EVENT_TYPE, headerMap.get(EVENT_TYPE));
		assertEquals("5", headerMap.get(LEAD_TIME_DAYS));

		Map<String, String> payloadMap = (Map<String, String>) (argument.getValue()).getPayloadData();
		assertEquals("tpnc:250000024", payloadMap.get(PriceConstants.PRODUCT_REF));
		List<Map<String, Object>> locations = new ArrayList<Map<String, Object>>();
		Map<String, Object> clearanceMap = new HashMap<>();
		Map<String, Object> locationMap = new HashMap<>();
		locationMap.put(LOC_TYPE, "Z");
		locationMap.put(LOC_REF, "20");
		clearanceMap.put(PRICING_LOC, locationMap);
		clearanceMap.put(CLEARANCE_OFFER_ID, "CL-1479643884");
		locations.add(clearanceMap);
		assertEquals(locations, payloadMap.get(CLEARANCES));
	}

	@Test(expected = EventPublishException.class)
	public void shouldThrowExceptionOnEventPublishingForEventsForPreviousPriceChangeClearancesTest() throws Exception {

		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 5);
		String effectiveDate = dateFormat.format(cal.getTime());
		String eventCorrelationKey = "tpnc:250000024_Z_" + effectiveDate + "_GB";
		MapEvent data = new MapEvent();
		data.setEventType("ClearancePrevPriceChanged");
		HashMap<String, Object> payloadMap = new HashMap<>();
		payloadMap.put(PriceConstants.PRODUCT_REF, "tpnc:250000024");
		List<Map<String, Object>> locations = new ArrayList<Map<String, Object>>();
		Map<String, Object> clearanceMap = new HashMap<>();
		Map<String, Object> locationMap = new HashMap<String, Object>();
		locationMap.put(LOC_TYPE, "Z");
		locationMap.put(LOC_REF, "20");
		clearanceMap.put(PRICING_LOC, locationMap);
		clearanceMap.put(CLEARANCE_OFFER_ID, "CL-1479643884");
		locations.add(clearanceMap);
		payloadMap.put(CLEARANCES, locations);
		data.setPayloadData(payloadMap);

		HashMap<String, String> headerMap = new HashMap<>();
		headerMap.put(EVENT_CORR_ID, EVENT_CORR_ID_PREFIX + eventCorrelationKey);
		headerMap.put(COUNTRY, "GB");
		headerMap.put(EVENT_TYPE, "ClearancePrevPriceChanged");
		headerMap.put(LEAD_TIME_DAYS, "5");
		data.setHeaderData(headerMap);

		Mockito.when(eventTemplate.publishEvent(data)).thenThrow(new EventPublishException(new Exception(), "Error"));

		ClearanceEventData clearanceEventMap = new ClearanceEventData();
		Set<String> clearanceSet = new HashSet<String>();
		clearanceSet.add("Z_20_CL-1479643884");
		clearanceEventMap.put(eventCorrelationKey, clearanceSet);
		clearanceEventHandler.publishEventsForPreviousPriceChangeClearances(clearanceEventMap);
	}
}