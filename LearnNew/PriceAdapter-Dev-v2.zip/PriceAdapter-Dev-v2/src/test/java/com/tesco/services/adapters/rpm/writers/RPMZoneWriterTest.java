package com.tesco.services.adapters.rpm.writers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Optional;
import com.tesco.couchbase.AsyncCouchbaseWrapper;
import com.tesco.couchbase.CouchbaseWrapper;
import com.tesco.couchbase.testutils.AsyncCouchbaseWrapperStub;
import com.tesco.couchbase.testutils.BucketTool;
import com.tesco.couchbase.testutils.CouchbaseTestManager;
import com.tesco.couchbase.testutils.CouchbaseWrapperStub;
import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.exceptions.ColumnNotFoundException;
import com.tesco.services.adapters.rpm.readers.PriceServiceCSVReader;
import com.tesco.services.adapters.rpm.writers.impl.RPMZoneWriter;
import com.tesco.services.core.Store;
import com.tesco.services.core.ZoneEntity;
import com.tesco.services.core.zone.ZoneGrpEntity;
import com.tesco.services.repositories.RepositoryImpl;
import com.tesco.services.resources.ImportResource;
import com.tesco.services.resources.TestConfiguration;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.PriceConstants;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.*;
import java.util.concurrent.Semaphore;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class RPMZoneWriterTest {

	@Mock
	private RepositoryImpl repositoryImpl;
	@Mock
	public AsyncCouchbaseWrapper asyncCouchbaseWrapper;
	@Mock
	public CouchbaseWrapper couchbaseWrapper;
	@Mock
	private Configuration testConfiguration;
	@Mock
	private ObjectMapper mapper;
	@Mock
	private CouchbaseTestManager couchbaseTestManager;
	@Mock
	private PriceServiceCSVReader rpmZoneReader;

	private RPMZoneWriter rpmZoneWriter;
	String runIdentifier = "rpmzoneonetime";
	String zoneGroupId = "1";
	String zoneGroupName = "Test Zone";
	String zoneGroupType = "1";
	String zoneIdUK = "7";
	String zoneIdROI = "8";
	String zoneNameUK = "UK test";
	String zoneNameROI = "ROI test";
	String baseInd = "1";
	String currencyCode = "GBP";
	String tslCountryCode = "GB";
	String storeIds = "5711|5722|5733|5744";
	String rpmZoneFilename = "tsl_rpm_zone_onetime.csv";

	@Before
	public void setUp() throws IOException, URISyntaxException,
			InterruptedException, ColumnNotFoundException {

		testConfiguration = TestConfiguration.load();
		if (testConfiguration.isDummyCouchbaseMode()) {
			Map<String, ImmutablePair<Long, String>> fakeBase = new HashMap<>();
			couchbaseTestManager = new CouchbaseTestManager(
					new CouchbaseWrapperStub(fakeBase),
					new AsyncCouchbaseWrapperStub(fakeBase),
					mock(BucketTool.class));
		} else {
			couchbaseTestManager = new CouchbaseTestManager(
					testConfiguration.getCouchbaseBucket(),
					testConfiguration.getCouchbaseUsername(),
					testConfiguration.getCouchbasePassword(),
					testConfiguration.getCouchbaseNodes(),
					testConfiguration.getCouchbaseAdminUsername(),
					testConfiguration.getCouchbaseAdminPassword());
		}

		couchbaseWrapper = couchbaseTestManager.getCouchbaseWrapper();
		asyncCouchbaseWrapper = couchbaseTestManager.getAsyncCouchbaseWrapper();
		repositoryImpl = new RepositoryImpl(couchbaseWrapper,
				asyncCouchbaseWrapper, new ObjectMapper());
		repositoryImpl = new RepositoryImpl(couchbaseWrapper,
				asyncCouchbaseWrapper, new ObjectMapper());
		rpmZoneWriter = new RPMZoneWriter(testConfiguration, mapper,
				repositoryImpl, rpmZoneReader);
	}

	@Test
	public void readAndWriteRPMZoneDataForUK() throws Exception {

		Map zoneGrpDataMap = new HashMap();

		Map<String, String> rpmZoneMap = returnRPMZoneMap(zoneGroupId,
				zoneGroupName, zoneGroupType, zoneIdUK, zoneNameUK, baseInd,
				currencyCode, tslCountryCode, storeIds);

		when(rpmZoneReader.getNext()).thenReturn(rpmZoneMap).thenReturn(null);

		zoneGrpDataMap.put("zoneGroupId", "1");
		zoneGrpDataMap.put("zoneGroupName", "Test Zone");
		zoneGrpDataMap.put("zoneGroupType", "1");
		List zoneIds = new LinkedList<String>();
		ZoneGrpEntity zoneGrpEntity = createZoneGroupEntity(zoneGrpDataMap,
				zoneIds);
		repositoryImpl.insertObject("ZONEGROUP_1", zoneGrpEntity);

		ZoneGrpEntity zoneGrpEntityCre = (ZoneGrpEntity) repositoryImpl
				.getGenericObject("ZONEGROUP_1", ZoneGrpEntity.class);
		Assert.assertNotNull(zoneGrpEntityCre);

		ImportResource.importSemaphoreForIdentifier.put(rpmZoneFilename,
				new Semaphore(1));

		this.rpmZoneWriter.write(rpmZoneFilename);

		ZoneEntity expectedZoneEntity = (ZoneEntity) repositoryImpl.getGenericObject(
				"ZONE_"
						+ rpmZoneMap.get(CSVHeaders.RPMZoneHeaders.ZONE_ID),
				ZoneEntity.class);
		assertThat(expectedZoneEntity).isNotNull();
		assertThat(expectedZoneEntity.getZoneName()).isEqualTo(
				rpmZoneMap.get(CSVHeaders.RPMZoneHeaders.ZONE_NAME));

		ZoneGrpEntity zoneGrpEntityModified = (ZoneGrpEntity) repositoryImpl
				.getGenericObject("ZONEGROUP_1", ZoneGrpEntity.class);
		Assert.assertNotNull(zoneGrpEntityModified);

		List zoneIdsforexpected = new LinkedList<String>();
		zoneIdsforexpected.add("7");
		Assert.assertEquals(zoneIdsforexpected,
				zoneGrpEntityModified.getZoneIds());
		Assert.assertEquals(1, zoneGrpEntityModified.getZoneIds().size());
	}

	@Test
	public void readAndWriteRPMZoneDataForROI() throws Exception {
		tslCountryCode = "IE";
		Map zoneGrpDataMap = new HashMap();
		Map<String, String> rpmZoneMap = returnRPMZoneMap(zoneGroupId,
				zoneGroupName, zoneGroupType, zoneIdROI, zoneNameROI, baseInd,
				currencyCode, tslCountryCode, storeIds);

		when(rpmZoneReader.getNext()).thenReturn(rpmZoneMap).thenReturn(null);

		repositoryImpl.deleteProduct("ZONEGROUP_1");

		zoneGrpDataMap.put("zoneGroupId", "1");
		zoneGrpDataMap.put("zoneGroupName", "Test Zone");
		zoneGrpDataMap.put("zoneGroupType", "1");
		List zoneIds = new LinkedList<String>();
		ZoneGrpEntity zoneGrpEntity = createZoneGroupEntity(zoneGrpDataMap,
				zoneIds);
		repositoryImpl.insertObject("ZONEGROUP_1", zoneGrpEntity);

		ZoneGrpEntity zoneGrpEntityCre = (ZoneGrpEntity) repositoryImpl
				.getGenericObject("ZONEGROUP_1", ZoneGrpEntity.class);
		Assert.assertNotNull(zoneGrpEntityCre);

		ImportResource.importSemaphoreForIdentifier.put(rpmZoneFilename,
				new Semaphore(1));

		this.rpmZoneWriter.write(rpmZoneFilename);

		ZoneEntity expectedZoneEntity = (ZoneEntity) repositoryImpl.getGenericObject(
				"ZONE_"
						+ rpmZoneMap.get(CSVHeaders.RPMZoneHeaders.ZONE_ID),
				ZoneEntity.class);
		assertThat(expectedZoneEntity).isNotNull();
		assertThat(expectedZoneEntity.getZoneName()).isEqualTo(
				rpmZoneMap.get(CSVHeaders.RPMZoneHeaders.ZONE_NAME));

		ZoneGrpEntity zoneGrpEntityModified = (ZoneGrpEntity) repositoryImpl
				.getGenericObject("ZONEGROUP_1", ZoneGrpEntity.class);
		Assert.assertNotNull(zoneGrpEntityModified);

		List zoneIdsforexpected = new LinkedList<String>();
		zoneIdsforexpected.add("8");
		Assert.assertEquals(zoneIdsforexpected,
				zoneGrpEntityModified.getZoneIds());
		Assert.assertEquals(1, zoneGrpEntityModified.getZoneIds().size());

	}

	@Test
	public void readAndWriteRPMZoneDataForPromoStore() throws Exception {
		Map zoneGrpDataMap = new HashMap();
		String store = "5711";
		Store actualStore = new Store();
		actualStore.setStoreId(store);
		actualStore.setPromoZoneId(Optional.of(Integer.parseInt(zoneIdUK)));
		actualStore.setPriceZoneId(Optional.<Integer> absent());
		actualStore.setClearanceZoneId(Optional.<Integer> absent());
		actualStore.setCountryId(tslCountryCode);
		actualStore.setCurrency(currencyCode);

		Map<String, String> rpmZoneMap = returnRPMZoneMap(zoneGroupId,
				zoneGroupName, zoneGroupType, zoneIdUK, zoneNameUK, baseInd,
				currencyCode, tslCountryCode, storeIds);

		when(rpmZoneReader.getNext()).thenReturn(rpmZoneMap).thenReturn(null);

		repositoryImpl.deleteProduct("ZONEGROUP_1");

		zoneGrpDataMap.put("zoneGroupId", "1");
		zoneGrpDataMap.put("zoneGroupName", "Test Zone");
		zoneGrpDataMap.put("zoneGroupType", "1");
		List zoneIds = new LinkedList<String>();
		ZoneGrpEntity zoneGrpEntity = createZoneGroupEntity(zoneGrpDataMap,
				zoneIds);
		repositoryImpl.insertObject("ZONEGROUP_1", zoneGrpEntity);

		ZoneGrpEntity zoneGrpEntityCre = (ZoneGrpEntity) repositoryImpl
				.getGenericObject("ZONEGROUP_1", ZoneGrpEntity.class);
		Assert.assertNotNull(zoneGrpEntityCre);

		ImportResource.importSemaphoreForIdentifier.put(rpmZoneFilename,
				new Semaphore(1));

		this.rpmZoneWriter.write(rpmZoneFilename);

		Store expectedStoreEntity = (Store) repositoryImpl.getGenericObject(
				"STORE_" + store, Store.class);
		assertThat(expectedStoreEntity).isNotNull();
		assertThat(expectedStoreEntity.toString()).isEqualTo(
				actualStore.toString());

	}

	@Test
	public void readAndWriteRPMZoneDataForPriceStore() throws Exception {
		Map zoneGrpDataMap = new HashMap();
		zoneGroupType = "2";
		String store = "5711";
		Store actualStore = new Store();
		actualStore.setStoreId(store);
		actualStore.setPriceZoneId(Optional.of(Integer.parseInt(zoneIdUK)));
		actualStore.setPromoZoneId(Optional.<Integer> absent());
		actualStore.setClearanceZoneId(Optional.<Integer> absent());
		actualStore.setCountryId(tslCountryCode);
		actualStore.setCurrency(currencyCode);

		Map<String, String> rpmZoneMap = returnRPMZoneMap(zoneGroupId,
				zoneGroupName, zoneGroupType, zoneIdUK, zoneNameUK, baseInd,
				currencyCode, tslCountryCode, storeIds);

		when(rpmZoneReader.getNext()).thenReturn(rpmZoneMap).thenReturn(null);

		repositoryImpl.deleteProduct("ZONEGROUP_1");

		zoneGrpDataMap.put("zoneGroupId", "1");
		zoneGrpDataMap.put("zoneGroupName", "Test Zone");
		zoneGrpDataMap.put("zoneGroupType", "1");
		List zoneIds = new LinkedList<String>();
		ZoneGrpEntity zoneGrpEntity = createZoneGroupEntity(zoneGrpDataMap,
				zoneIds);
		repositoryImpl.insertObject("ZONEGROUP_1", zoneGrpEntity);

		ZoneGrpEntity zoneGrpEntityCre = (ZoneGrpEntity) repositoryImpl
				.getGenericObject("ZONEGROUP_1", ZoneGrpEntity.class);
		Assert.assertNotNull(zoneGrpEntityCre);

		ImportResource.importSemaphoreForIdentifier.put(rpmZoneFilename,
				new Semaphore(1));

		this.rpmZoneWriter.write(rpmZoneFilename);

		Store expectedStoreEntity = (Store) repositoryImpl.getGenericObject(
				"STORE_" + store, Store.class);
		assertThat(expectedStoreEntity).isNotNull();
		assertThat(expectedStoreEntity.toString()).isEqualTo(
				actualStore.toString());

	}

	@Test
	public void readAndWriteRPMZoneDataForClearanceStore() throws Exception {
		Map zoneGrpDataMap = new HashMap();
		zoneGroupType = "0";
		String store = "5711";
		Store actualStore = new Store();
		actualStore.setStoreId(store);
		actualStore.setClearanceZoneId(Optional.of(Integer.parseInt(zoneIdUK)));
		actualStore.setPromoZoneId(Optional.<Integer> absent());
		actualStore.setPriceZoneId(Optional.<Integer> absent());
		actualStore.setCountryId(tslCountryCode);
		actualStore.setCurrency(currencyCode);

		Map<String, String> rpmZoneMap = returnRPMZoneMap(zoneGroupId,
				zoneGroupName, zoneGroupType, zoneIdUK, zoneNameUK, baseInd,
				currencyCode, tslCountryCode, storeIds);

		when(rpmZoneReader.getNext()).thenReturn(rpmZoneMap).thenReturn(null);

		repositoryImpl.deleteProduct("ZONEGROUP_1");

		zoneGrpDataMap.put("zoneGroupId", "1");
		zoneGrpDataMap.put("zoneGroupName", "Test Zone");
		zoneGrpDataMap.put("zoneGroupType", "1");
		List zoneIds = new LinkedList<String>();
		ZoneGrpEntity zoneGrpEntity = createZoneGroupEntity(zoneGrpDataMap,
				zoneIds);
		repositoryImpl.insertObject("ZONEGROUP_1", zoneGrpEntity);

		ZoneGrpEntity zoneGrpEntityCre = (ZoneGrpEntity) repositoryImpl
				.getGenericObject("ZONEGROUP_1", ZoneGrpEntity.class);
		Assert.assertNotNull(zoneGrpEntityCre);

		ImportResource.importSemaphoreForIdentifier.put(rpmZoneFilename,
				new Semaphore(1));

		this.rpmZoneWriter.write(rpmZoneFilename);

		Store expectedStoreEntity = (Store) repositoryImpl.getGenericObject(
				"STORE_" + store, Store.class);
		assertThat(expectedStoreEntity).isNotNull();
		assertThat(expectedStoreEntity.toString()).isEqualTo(
				actualStore.toString());

	}

	@Ignore
	@Test
	public void testWriteRPMZoneDataForException() throws Exception {
		Map<String, String> rpmZoneMap = null;
		Mockito.doThrow(
				new ArrayIndexOutOfBoundsException(
						"Array index out of bound Exception"))
				.when(rpmZoneWriter).setZoneEntity(rpmZoneMap);
		ImportResource.importSemaphoreForIdentifier.put("rpmzoneonetime",
				new Semaphore(1));
		this.rpmZoneWriter.write(rpmZoneFilename);
		assertThat("Array index out of bound Exception").isEqualTo(
				ImportResource.getErrorString(rpmZoneFilename));

	}

	private Map<String, String> returnRPMZoneMap(String zoneGroupId,
			String zoneGroupName, String zoneGroupType, String zoneId,
			String zoneName, String baseInd, String currencyCode,
			String tslCountryCode, String storeIds) {
		Map<String, String> rpmZoneMap = new HashMap<>();
		rpmZoneMap.put(CSVHeaders.RPMZoneHeaders.ZONE_GROUP_ID, zoneGroupId);
		rpmZoneMap
				.put(CSVHeaders.RPMZoneHeaders.ZONE_GROUP_NAME, zoneGroupName);
		rpmZoneMap
				.put(CSVHeaders.RPMZoneHeaders.ZONE_GROUP_TYPE, zoneGroupType);
		rpmZoneMap.put(CSVHeaders.RPMZoneHeaders.ZONE_ID, zoneId);
		rpmZoneMap.put(CSVHeaders.RPMZoneHeaders.ZONE_NAME, zoneName);
		rpmZoneMap.put(CSVHeaders.RPMZoneHeaders.BASE_IND, baseInd);
		rpmZoneMap.put(CSVHeaders.RPMZoneHeaders.CURRENCY_CODE, currencyCode);
		rpmZoneMap.put(CSVHeaders.RPMZoneHeaders.TSL_COUNTRY_CODE,
				tslCountryCode);
		rpmZoneMap.put(CSVHeaders.RPMZoneHeaders.STORE_IDS, storeIds);
		return rpmZoneMap;
	}

	public ZoneGrpEntity createZoneGroupEntity(Map zoneGrpDataMap, List zoneIds) {
		ZoneGrpEntity zoneGrpEntity = new ZoneGrpEntity();
		zoneGrpEntity.setZoneGroupId(zoneGrpDataMap.get("zoneGroupId")
				.toString());
		zoneGrpEntity.setZoneGroupName(zoneGrpDataMap.get("zoneGroupName")
				.toString());
		zoneGrpEntity.setZoneGroupType(zoneGrpDataMap.get("zoneGroupType")
				.toString());
		zoneGrpEntity.setCreatedDate("createdDate");
		zoneGrpEntity.setCreatedById("RPM");
		zoneGrpEntity.setLastUpdateDate("lastUpdatedDate");
		zoneGrpEntity.setLastUpdatedById("RPM");
		if (Dockyard.isSpaceOrNull(zoneIds) || zoneIds.isEmpty()) {
			zoneGrpEntity.setZoneIds(zoneIds);
		} else {
			zoneGrpEntity.setZoneIds(zoneIds);
		}

		return zoneGrpEntity;
	}

	// Added for PRIS-2203 Data Loss Issue
	@Test
	public void writeRPMZoneToCB_CBExceptionNullDocument() throws Exception {

		// Delete the document if existing
		String key = "ZONE_7";
		repositoryImpl.deleteProduct(key);

		// setting mock product repository
		RepositoryImpl repositoryImplMock = new RepositoryImpl(
				couchbaseWrapper, asyncCouchbaseWrapper, new ObjectMapper());
		repositoryImplMock = Mockito.mock(repositoryImplMock.getClass());
		RPMZoneWriter rpmZoneWriterMock = new RPMZoneWriter(testConfiguration,
				mapper, repositoryImplMock, rpmZoneReader);

		// Set the document in the couchbase
		Map<String, String> rpmZoneMap = returnRPMZoneMap(zoneGroupId,
				zoneGroupName, zoneGroupType, zoneIdUK, zoneNameUK, baseInd,
				currencyCode, tslCountryCode, storeIds);
		ZoneEntity zoneEntity = setZoneEntity(rpmZoneMap);
		when(rpmZoneReader.getNext()).thenReturn(rpmZoneMap).thenReturn(null);
		ImportResource.importSemaphoreForIdentifier.put(rpmZoneFilename,
				new Semaphore(1));

		Mockito.mock(zoneEntity.getClass());
		rpmZoneWriterMock.setZoneEntity(zoneEntity);
		Mockito.doThrow(new Exception()).when(repositoryImplMock)
				.insertObject(key, zoneEntity);

		// Exception will be thrown here
		rpmZoneWriterMock.write(rpmZoneFilename);

		// Check if the document exist in couchbase
		ZoneEntity expectedZoneGrpEntity = (ZoneEntity) repositoryImpl
				.getGenericObject(
						PriceConstants.ZONE_KEY
								+ rpmZoneMap
										.get(CSVHeaders.RPMZoneHeaders.ZONE_ID),
						ZoneEntity.class);

		// The document should not be present in the couchbase because of DB
		// error
		assertThat(expectedZoneGrpEntity).isNull();

	}

	// Added for PRIS-2203 Data Loss Issue
	public ZoneEntity setZoneEntity(Map<String, String> rpmZoneInfoMap) {
		ZoneEntity zoneEntity = new ZoneEntity();
		String date = Dockyard.getSysDate(PriceConstants.ISO_8601_FORMAT);
		String zoneId = PriceConstants.ZONE_KEY
				+ rpmZoneInfoMap.get(CSVHeaders.RPMZoneHeaders.ZONE_ID);
		String storeId = rpmZoneInfoMap
				.get(CSVHeaders.RPMZoneHeaders.STORE_IDS);

		StringTokenizer st = new StringTokenizer(storeId, "|");
		List<String> storeIds = new ArrayList<String>();
		while (st.hasMoreElements()) {
			storeIds.add(st.nextElement().toString());
		}

		if (PriceConstants.TSL_COUNTRY_GB.equals(rpmZoneInfoMap
				.get(CSVHeaders.RPMZoneHeaders.TSL_COUNTRY_CODE))) {
			zoneEntity.setOfferPrefix(PriceConstants.OFFER_PREFIX_UK);
		} else if (PriceConstants.TSL_COUNTRY_IE.equals(rpmZoneInfoMap
				.get(CSVHeaders.RPMZoneHeaders.TSL_COUNTRY_CODE))) {
			zoneEntity.setOfferPrefix(PriceConstants.OFFER_PREFIX_ROI);
		}

		zoneEntity.setZoneGroupId(rpmZoneInfoMap
				.get(CSVHeaders.RPMZoneHeaders.ZONE_GROUP_ID));
		zoneEntity.setZoneGroupName(rpmZoneInfoMap
				.get(CSVHeaders.RPMZoneHeaders.ZONE_GROUP_NAME));
		zoneEntity.setZoneGroupType(rpmZoneInfoMap
				.get(CSVHeaders.RPMZoneHeaders.ZONE_GROUP_TYPE));
		zoneEntity.setZoneId(rpmZoneInfoMap
				.get(CSVHeaders.RPMZoneHeaders.ZONE_ID));
		zoneEntity.setZoneName(rpmZoneInfoMap
				.get(CSVHeaders.RPMZoneHeaders.ZONE_NAME));
		zoneEntity.setBaseInd(rpmZoneInfoMap
				.get(CSVHeaders.RPMZoneHeaders.BASE_IND));
		zoneEntity.setCurrencyCode(rpmZoneInfoMap
				.get(CSVHeaders.RPMZoneHeaders.CURRENCY_CODE));
		zoneEntity.setTslCountryCode(rpmZoneInfoMap
				.get(CSVHeaders.RPMZoneHeaders.TSL_COUNTRY_CODE));
		zoneEntity.setCreatedDate(date);
		zoneEntity.setCreatedById(PriceConstants.ONETIME_ZONE_CREATED_BY);
		zoneEntity.setLastUpdateDate(date);
		zoneEntity.setStoreIds(storeIds);

		return zoneEntity;
	}

	@Test
	public void testRPMZoneWriterForException() throws Exception {

		when(rpmZoneReader.getNext())
				.thenThrow(new IOException("IO Exception")).thenReturn(null);

		ImportResource.importSemaphoreForIdentifier.put(rpmZoneFilename,
				new Semaphore(1));

		try {
			this.rpmZoneWriter.write(rpmZoneFilename);
			fail("Suppose to fail");
		} catch (Exception e) {
			assertThat(e.getMessage().equals("IO Exception"));
		}
	}

	@Test
	public void testRPMZoneWriterArrayIndexOutOfBoundForException()
			throws Exception {

		when(rpmZoneReader.getNext()).thenThrow(
				new ArrayIndexOutOfBoundsException(
						"Array index out of bound Exception"));
		ImportResource.importSemaphoreForIdentifier.put(rpmZoneFilename,
				new Semaphore(1));
		this.rpmZoneWriter.write(rpmZoneFilename);
		assertThat("Array index out of bound Exception").isEqualTo(
				ImportResource.getErrorString(rpmZoneFilename));
	}
}
