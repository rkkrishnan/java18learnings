package com.tesco.services.adapters.rpm.writers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.RuntimeJsonMappingException;
import com.tesco.couchbase.AsyncCouchbaseWrapper;
import com.tesco.couchbase.CouchbaseWrapper;
import com.tesco.couchbase.testutils.AsyncCouchbaseWrapperStub;
import com.tesco.couchbase.testutils.BucketTool;
import com.tesco.couchbase.testutils.CouchbaseTestManager;
import com.tesco.couchbase.testutils.CouchbaseWrapperStub;
import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.exceptions.ColumnNotFoundException;
import com.tesco.services.adapters.promotion.PromotionEventHandler;
import com.tesco.services.adapters.rpm.readers.PriceServiceCSVReader;
import com.tesco.services.adapters.rpm.writers.impl.FutureOfferDescWritter;
import com.tesco.services.core.promotion.ProductOffersEntity;
import com.tesco.services.core.promotion.PromotionEntity;
import com.tesco.services.exceptions.DataAccessException;
import com.tesco.services.repositories.RepositoryImpl;
import com.tesco.services.resources.ImportResource;
import com.tesco.services.resources.TestConfiguration;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.PriceConstants;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.reflect.Whitebox;

import java.io.IOException;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Semaphore;

import static io.dropwizard.testing.FixtureHelpers.fixture;
import static org.fest.assertions.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by QP65 on 12/16/2015.
 */
@RunWith(MockitoJUnitRunner.class)
public class OneTimeFutureOfferDescImportTest {

	@Mock
	public RepositoryImpl repositoryImpl;
	@Mock
	public AsyncCouchbaseWrapper asyncCouchbaseWrapper;
	@Mock
	public CouchbaseWrapper couchbaseWrapper;
	@Mock
	private Configuration testConfiguration;
	@Mock
	private CouchbaseTestManager couchbaseTestManager;
	@Mock
	private PriceServiceCSVReader futureOfferDescReader;
	@Mock
	private PromotionEventHandler promotionEventHandler;

	private FutureOfferDescWritter futureOfferDescWritter;
	private ObjectMapper mapper = new ObjectMapper();
	private String runIdentifier = "oneTimeFutureOfferDesc";
	private String fileName = "OneTimeOfferDesc.csv";
	private Map<String, String> futureOfferDescMap1;

	@Before
	public void setUp() throws IOException, URISyntaxException,
			InterruptedException, ColumnNotFoundException {

		testConfiguration = TestConfiguration.load();
		if (testConfiguration.isDummyCouchbaseMode()) {
			Map<String, ImmutablePair<Long, String>> fakeBase = new HashMap<>();
			couchbaseTestManager = new CouchbaseTestManager(
					new CouchbaseWrapperStub(fakeBase),
					new AsyncCouchbaseWrapperStub(fakeBase),
					mock(BucketTool.class));
		} else {
			couchbaseTestManager = new CouchbaseTestManager(
					testConfiguration.getCouchbaseBucket(),
					testConfiguration.getCouchbaseUsername(),
					testConfiguration.getCouchbasePassword(),
					testConfiguration.getCouchbaseNodes(),
					testConfiguration.getCouchbaseAdminUsername(),
					testConfiguration.getCouchbaseAdminPassword());
		}

		couchbaseWrapper = couchbaseTestManager.getCouchbaseWrapper();
		asyncCouchbaseWrapper = couchbaseTestManager.getAsyncCouchbaseWrapper();

		futureOfferDescWritter = new FutureOfferDescWritter(testConfiguration,
				repositoryImpl, futureOfferDescReader, promotionEventHandler);
		futureOfferDescWritter.setRunIdentifier(runIdentifier);
	}

	@Test
	public void readAndWriteFutureOfferDesc() throws Exception {
		String tpnb = "050000419";
		String offerId = "A12345";
		String offerIdNo = "12345";
		String zone = "5";
		String cfDesc1 = "description1";
		String cfDesc2 = "description2";
		String dateFormats = "MMM dd yyyy hh:mma";
		SimpleDateFormat dateFormat = new SimpleDateFormat(dateFormats);
		Calendar cal = Calendar.getInstance();
		cal.setTime(dateFormat.parse(Dockyard.getSysDate(dateFormats)));
		cal.add(Calendar.DATE,
				PriceConstants.FUTURE_OFFER_DESC_RANGE.RANGE_BEGIN.value() - 50);
		String startDate = dateFormat.format(cal.getTime());

		cal.add(Calendar.DATE,
				PriceConstants.FUTURE_OFFER_DESC_RANGE.RANGE_BEGIN.value() + 80);
		String endDate = dateFormat.format(cal.getTime());

		PromotionEntity promotionDoc = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/futureOfferDesc/PROMOTION_12345_Z5.json"),
						PromotionEntity.class);
		ProductOffersEntity productOffersEntity = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/futureOfferDesc/PRODOFFERS_050000419_Z5.json"),
						ProductOffersEntity.class);

		futureOfferDescMap1 = returnFutureOfferDesc(offerId, tpnb, zone,
				startDate, cfDesc1, cfDesc2, endDate);

		when(futureOfferDescReader.getNext()).thenReturn(futureOfferDescMap1)
				.thenReturn(null);
		when(
				repositoryImpl.getGenericObject(
						PriceConstants.PROMOTION_DOC_KEY_PREFIX + offerIdNo
								+ "_Z5", PromotionEntity.class)).thenReturn(
				promotionDoc);
		when(
				repositoryImpl.getGenericObject(PriceConstants.PROD_OFFERS
						+ tpnb + "_Z" + zone, ProductOffersEntity.class))
				.thenReturn(productOffersEntity);

		ImportResource.importSemaphoreForIdentifier.put(fileName,
				new Semaphore(1));

		this.futureOfferDescWritter.write(fileName);
		/** Build expected promotion doc */
		PromotionEntity expectedPromoDoc = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/futureOfferDesc/PROMOTION_12345_Z5.json"),
						PromotionEntity.class);
		ProductOffersEntity expectedProductOffersEntity = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/futureOfferDesc/PRODOFFERS_050000419_Z5.json"),
						ProductOffersEntity.class);
		expectedProductOffersEntity.getProductOffersPromotionMap()
				.get(offerIdNo).setCfDescription1(cfDesc1);
		expectedProductOffersEntity.getProductOffersPromotionMap()
				.get(offerIdNo).setCfDescription2(cfDesc2);

		PromotionEntity actualPromotionEntity = (PromotionEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdNo + "_Z5", PromotionEntity.class);
		ProductOffersEntity actualProductOffersEntity = (ProductOffersEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROD_OFFERS + tpnb + "_Z"
						+ zone, ProductOffersEntity.class);
		/** Ignoring the date */
		actualPromotionEntity.setLastUpdateDate("");
		expectedPromoDoc.setLastUpdateDate("");

		actualProductOffersEntity.setLastUpdateDateTime("");
		actualProductOffersEntity.getProductOffersPromotionMap().get(offerIdNo)
				.setLastUpdateDateTime("");
		expectedProductOffersEntity.setLastUpdateDateTime("");
		expectedProductOffersEntity.getProductOffersPromotionMap()
				.get(offerIdNo).setLastUpdateDateTime("");

		assertThat(actualPromotionEntity).isNotNull();

		assertThat(actualPromotionEntity.toString()).isEqualTo(
				expectedPromoDoc.toString());

		assertThat(actualProductOffersEntity.toString()).isEqualTo(
				expectedProductOffersEntity.toString());

	}

	@Test
	public void testSavePromotion() {
		try {
			PromotionEntity promotionDoc1 = mapper
					.readValue(
							fixture("com/tesco/services/core/fixtures/futureOfferDesc/PROMOTION_12345_Z5.json"),
							PromotionEntity.class);
			Mockito.doThrow(
					new RuntimeJsonMappingException("json mapping exception"))
					.when(repositoryImpl)
					.insertObject(Matchers.anyString(),
							Matchers.anyObject());
			Whitebox.<Void> invokeMethod(futureOfferDescWritter,
					"savePromotion", "PROMOTION_12345_Z5", promotionDoc1);
		} catch (DataAccessException e) {
			assertThat(true);
		} catch (Exception e1) {
			assertThat(false);
		}
	}

	@Test
	public void readAndWriteFutureOfferDescMultipleOffers() throws Exception {
		String tpnb1 = "050000419";
		String tpnb2 = "050000519";
		String offerId = "A12345";
		String offerIdNo = "12345";
		String offerId2 = "A6789";
		String offerIdNo2 = "6789";
		String zone = "5";
		String cfDesc1 = "description1";
		String cfDesc2 = "description2";
		String dateFormats = "MMM dd yyyy hh:mma";
		SimpleDateFormat dateFormat = new SimpleDateFormat(dateFormats);
		Calendar cal = Calendar.getInstance();
		cal.setTime(dateFormat.parse(Dockyard.getSysDate(dateFormats)));
		cal.add(Calendar.DATE,
				PriceConstants.FUTURE_OFFER_DESC_RANGE.RANGE_BEGIN.value() - 50);
		String startDate = dateFormat.format(cal.getTime());

		cal.add(Calendar.DATE,
				PriceConstants.FUTURE_OFFER_DESC_RANGE.RANGE_BEGIN.value() + 80);
		String endDate = dateFormat.format(cal.getTime());

		PromotionEntity promotionDoc1 = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/futureOfferDesc/PROMOTION_12345_Z5.json"),
						PromotionEntity.class);
		ProductOffersEntity productOffersEntity1 = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/futureOfferDesc/PRODOFFERS_050000419_Z5.json"),
						ProductOffersEntity.class);

		PromotionEntity promotionDoc2 = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/futureOfferDesc/PROMOTION_6789_Z5.json"),
						PromotionEntity.class);
		ProductOffersEntity productOffersEntity2 = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/futureOfferDesc/PRODOFFERS_050000519_Z5.json"),
						ProductOffersEntity.class);

		Map<String, String> futureOfferDescMap2;
		futureOfferDescMap1 = returnFutureOfferDesc(offerId, tpnb1, zone,
				startDate, cfDesc1, cfDesc2, endDate);
		futureOfferDescMap2 = returnFutureOfferDesc(offerId2, tpnb2, zone,
				startDate, cfDesc1, cfDesc2, endDate);
		when(futureOfferDescReader.getNext()).thenReturn(futureOfferDescMap1)
				.thenReturn(futureOfferDescMap2).thenReturn(null);
		when(
				repositoryImpl.getGenericObject(
						PriceConstants.PROMOTION_DOC_KEY_PREFIX + offerIdNo
								+ "_Z5", PromotionEntity.class)).thenReturn(
				promotionDoc1);
		when(
				repositoryImpl.getGenericObject(PriceConstants.PROD_OFFERS
						+ tpnb1 + "_Z" + zone, ProductOffersEntity.class))
				.thenReturn(productOffersEntity1);

		when(
				repositoryImpl.getGenericObject(
						PriceConstants.PROMOTION_DOC_KEY_PREFIX + offerIdNo2
								+ "_Z5", PromotionEntity.class)).thenReturn(
				promotionDoc2);
		when(
				repositoryImpl.getGenericObject(PriceConstants.PROD_OFFERS
						+ tpnb2 + "_Z" + zone, ProductOffersEntity.class))
				.thenReturn(productOffersEntity2);

		ImportResource.importSemaphoreForIdentifier.put(fileName,
				new Semaphore(1));

		this.futureOfferDescWritter.write(fileName);
		/** Build expected promotion doc */
		PromotionEntity expectedPromoDoc1 = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/futureOfferDesc/PROMOTION_12345_Z5.json"),
						PromotionEntity.class);

		ProductOffersEntity expectedProductOffersEntity1 = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/futureOfferDesc/PRODOFFERS_050000419_Z5.json"),
						ProductOffersEntity.class);
		expectedProductOffersEntity1.getProductOffersPromotionMap()
				.get(offerIdNo).setCfDescription1(cfDesc1);
		expectedProductOffersEntity1.getProductOffersPromotionMap()
				.get(offerIdNo).setCfDescription2(cfDesc2);

		PromotionEntity expectedPromoDoc2 = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/futureOfferDesc/PROMOTION_6789_Z5.json"),
						PromotionEntity.class);
		ProductOffersEntity expectedProductOffersEntity2 = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/futureOfferDesc/PRODOFFERS_050000519_Z5.json"),
						ProductOffersEntity.class);
		expectedProductOffersEntity2.getProductOffersPromotionMap()
				.get(offerIdNo2).setCfDescription1(cfDesc1);
		expectedProductOffersEntity2.getProductOffersPromotionMap()
				.get(offerIdNo2).setCfDescription2(cfDesc2);

		/** Actual docs from CB */
		PromotionEntity actualPromotionEntity = (PromotionEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdNo + "_Z5", PromotionEntity.class);
		ProductOffersEntity actualProductOffersEntity = (ProductOffersEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROD_OFFERS + tpnb1 + "_Z"
						+ zone, ProductOffersEntity.class);

		PromotionEntity actualPromotionEntity2 = (PromotionEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdNo2 + "_Z5", PromotionEntity.class);
		ProductOffersEntity actualProductOffersEntity2 = (ProductOffersEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROD_OFFERS + tpnb2 + "_Z"
						+ zone, ProductOffersEntity.class);
		/** Ignoring the date */
		actualPromotionEntity.setLastUpdateDate("");
		expectedPromoDoc1.setLastUpdateDate("");
		actualPromotionEntity2.setLastUpdateDate("");
		expectedPromoDoc2.setLastUpdateDate("");

		actualProductOffersEntity.setLastUpdateDateTime("");
		actualProductOffersEntity.getProductOffersPromotionMap().get(offerIdNo)
				.setLastUpdateDateTime("");
		expectedProductOffersEntity1.setLastUpdateDateTime("");
		expectedProductOffersEntity1.getProductOffersPromotionMap()
				.get(offerIdNo).setLastUpdateDateTime("");

		actualProductOffersEntity2.setLastUpdateDateTime("");
		actualProductOffersEntity2.getProductOffersPromotionMap()
				.get(offerIdNo2).setLastUpdateDateTime("");
		expectedProductOffersEntity2.setLastUpdateDateTime("");
		expectedProductOffersEntity2.getProductOffersPromotionMap()
				.get(offerIdNo2).setLastUpdateDateTime("");

		assertThat(actualPromotionEntity.toString()).isEqualTo(
				expectedPromoDoc1.toString());

		assertThat(actualProductOffersEntity.toString()).isEqualTo(
				expectedProductOffersEntity1.toString());

		assertThat(actualPromotionEntity2.toString()).isEqualTo(
				expectedPromoDoc2.toString());

		assertThat(actualProductOffersEntity2.toString()).isEqualTo(
				expectedProductOffersEntity2.toString());

	}

	private Map<String, String> returnFutureOfferDesc(String offerId,
			String tpnb, String zone, String startDate, String cfDesc1,
			String cfDesc2, String endDate) {

		Map<String, String> futureOfferDesc = new HashMap<>();

		futureOfferDesc.put(CSVHeaders.PromoDescExtract.ITEM, tpnb);
		futureOfferDesc.put(CSVHeaders.PromoDescExtract.ZONE_ID, zone);
		futureOfferDesc.put(CSVHeaders.PromoDescExtract.OFFER_ID, offerId);
		futureOfferDesc.put(CSVHeaders.PromoDescExtract.DESC1, cfDesc1);
		futureOfferDesc.put(CSVHeaders.PromoDescExtract.DESC2, cfDesc2);
		futureOfferDesc.put(CSVHeaders.PromoDescExtract.START_DATE, startDate);
		futureOfferDesc.put(CSVHeaders.PromoDescExtract.END_DATE, endDate);

		return futureOfferDesc;
	}

}
