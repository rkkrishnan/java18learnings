package com.tesco.services.adapters.promotion;

import com.tesco.promotion.core.PrmPrcChgDesc;
import com.tesco.promotion.core.PrmPrcChgDtl;
import com.tesco.services.adapters.core.exceptions.PromotionEventException;
import com.tesco.services.adapters.promotion.impl.PromotionEventHandlerImpl;
import com.tesco.services.core.ZoneEntity;
import com.tesco.services.event.core.EventTemplate;
import com.tesco.services.event.core.impl.MapEvent;
import com.tesco.services.event.exception.EventPublishException;
import com.tesco.services.leadtime.core.LeadTimeUtility;
import com.tesco.services.repositories.RepositoryImpl;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.ParseMessageUtil;
import com.tesco.services.utility.PriceUtility;
import org.joda.time.DateTime;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;

import static com.tesco.services.utility.PriceConstants.*;
import static io.dropwizard.testing.FixtureHelpers.fixture;
import static org.junit.Assert.assertEquals;

@RunWith(MockitoJUnitRunner.class)
public class MBPromotionEventCreationTest {

	PrmPrcChgDesc promotions;
	PrmPrcChgDesc promotionsWD;

	@Mock
	private EventTemplate eventTemplate;

	private PromotionEventHandler promoEventHandler;

	@Mock
	private RepositoryImpl repositoryImpl;

	@Captor
	private ArgumentCaptor<MapEvent> argument;

	@Before
	public void setUp() throws Exception {
		promoEventHandler = new PromotionEventHandlerImpl(eventTemplate,
				repositoryImpl);
		String xmlData = fixture("com/tesco/services/core/fixtures/promotion/MultibuyCreMessage.xml");
		ParseMessageUtil parseMessageUtil = ParseMessageUtil.getInstance();
		String promoDescData = parseMessageUtil.getNodeData(xmlData,
				PROMO_MSG_DATA_PATH);
		promotions = (PrmPrcChgDesc) parseMessageUtil
				.getMappedObjectForXmlData(PrmPrcChgDesc.class, promoDescData);
		ZoneEntity ze = new ZoneEntity();
		ze.setZoneId("5");
		ze.setTslCountryCode("GB");
		ze.setZoneGroupId("90");
		ze.setZoneName("testZone");
		Mockito.when(repositoryImpl.getGenericObject("ZONE_5",ZoneEntity.class)).thenReturn(ze);
	}

	@Test
	public void testEventCreatedForMBPromotion()
			throws PromotionEventException, ParseException,
			EventPublishException {
		PrmPrcChgDtl prmPrcChgDtls = promotions.getPrmPrcChgDtl().get(0);
		String promoEffectiveDate = PriceUtility.getDate(prmPrcChgDtls
				.getStartDate().getYear().toString(), prmPrcChgDtls
				.getStartDate().getMonth().toString(), prmPrcChgDtls
				.getStartDate().getDay().toString(), prmPrcChgDtls
				.getStartDate().getHour().toString(), prmPrcChgDtls
				.getStartDate().getMinute().toString(), prmPrcChgDtls
				.getStartDate().getSecond().toString());
		String promoPublicationDate = Dockyard.getSysDate(ISO_8601_FORMAT);
		promoEffectiveDate = Dockyard.getFormattedDate(promoEffectiveDate,
				DATE_FORMAT_YYYYMMDDHHMMSS, ISO_8601_FORMAT);
		promoPublicationDate = Dockyard.getFormattedDate(promoPublicationDate,
				DATE_FORMAT_YYYYMMDDHHMMSS, ISO_8601_FORMAT);
		promoEffectiveDate = PriceUtility
				.replaceOffsetDesignatorForZeroWithNumerals(promoEffectiveDate);
		DateTime promoEffectiveDateObj = new DateTime(promoEffectiveDate);
		DateTime promoPublicationDateObj = new DateTime(promoPublicationDate);
		int leadDays = LeadTimeUtility.getLeadTime(promoEffectiveDateObj,
				promoPublicationDateObj);
		Map<String, String> eventDataMap = prepareEventDataMap(promoEffectiveDate);
		promoEventHandler.publishPromotionEvent(eventDataMap);
		Mockito.verify(eventTemplate, Mockito.times(1)).publishEvent(
				argument.capture());
		assertEquals(
				PROMOTION_MSG_TYPE_CRE,
				String.valueOf((argument.getValue()).getHeaderData().get(
						"EventType")));
		assertEquals(
				leadDays,
				Integer.valueOf(
						(argument.getValue()).getHeaderData().get(
								"LeadTimeDays")).intValue());
		assertEquals("GB:Z:5",
				(argument.getValue()).getHeaderData().get(LOCATION_ID));
		assertEquals("1512130",
				(argument.getValue()).getPayloadData().get(OFFER_ID));

	}

	private Map<String, String> prepareEventDataMap(String effectiveDate) {
		Map<String, String> promotionEventDataMap = new HashMap<>();

		promotionEventDataMap.put(LOC_REF, "5");
		promotionEventDataMap.put(LOC_TYPE, "Z");
		promotionEventDataMap.put(OFFER_ID, "1512130");
		promotionEventDataMap.put(EFFECTIVE_DATE, effectiveDate);
		promotionEventDataMap.put(EVENT_TYPE, PROMOTION_MSG_TYPE_CRE);
		return promotionEventDataMap;
	}

}
