package com.tesco.services.resources;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.Import;
import com.tesco.services.core.Promotion;
import com.tesco.services.resources.model.PromotionRequest;
import com.tesco.services.resources.model.PromotionRequestList;
import io.dropwizard.jackson.Jackson;
import io.dropwizard.testing.junit.ResourceTestRule;
import org.junit.*;
import org.mockito.Mock;

import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.util.List;

import static com.tesco.services.builder.PromotionBuilder.aPromotion;
import static com.tesco.services.builder.PromotionRequestBuilder.aPromotionRequest;
import static org.fest.assertions.api.Assertions.assertThat;
import static org.fest.util.Lists.newArrayList;

public class PromotionResourceTest {

	@Mock
	private static Import importPromotionJob;

	private static final String PROMOTION_FIND_ENDPOINT = "/promotion/find";
	private static Configuration testConfiguration = TestConfiguration.load();

	private static ObjectMapper objectMapper = Jackson.newObjectMapper();

	@ClassRule
	public static final ResourceTestRule resources = ResourceTestRule
			.builder()
			.addResource(
					new PromotionResource(importPromotionJob)).build();

	@Before
	public void setUpResources() throws Exception {
	}

	@BeforeClass
	public static void setUp() throws IOException {
		// TODO: insert the following data into couch for testing
		//        storeCollection.insert(new TestStoreDBObject("2000").withZoneId("5").build());

		Promotion promotion = aPromotion()
				.offerId("A29721688")
				.tpnc("070918248")
				.zoneId(5)
				.startDate("31-Apr-12")
				.endDate("04-May-13")
				.offerName("3 LIONS KICK & TRICK BALL 1.00 SPECIAL PURCHASE")
				.description1("SPECIAL PURCHASE 50p")
				.description2("3 LIONS|WATERBOTTLE")
				.shelfTalker("OnSale.png")
				.uniqueKey("uuid1")
				.build();

		Promotion promotion1 = aPromotion()
				.offerId("R29029470")
				.tpnc("66367922")
				.zoneId(12)
				.startDate("25-Sep-10")
				.endDate("22/09/35")
				.offerName("ROI HARDWARE")
				.description1("SPECIAL PURCHASE 50p")
				.description2("3 LIONS|WATERBOTTLE")
				.uniqueKey("uuid2")
				.build();

		Promotion promotion2 = aPromotion()
				.offerId("A29721690")
				.tpnc("70918248")
				.zoneId(4)
				.startDate("31-Jun-12")
				.endDate("04-Jul-13")
				.offerName("3 LIONS KICK & TRICK BALL 3.00 SPECIAL PURCHASE")
				.description1("SPECIAL PURCHASE 50p")
				.description2("3 LIONS|CAR FLAG")
				.uniqueKey("uuid3")
				.build();

		Promotion promotion3 = aPromotion().offerId("345").build();

	}

	@AfterClass
	public static void tearDown() throws Exception {
	}

	@Test
	@Ignore
	public void shouldReturnMultiplePromotions() throws Exception {
		PromotionRequest promotionRequest = aPromotionRequest()
				.offerId("A29721688")
				.itemNumber("070918248")
				.zoneId(5)
				.build();

		PromotionRequest promotionRequest1 = aPromotionRequest()
				.offerId("A29721690")
				.itemNumber("70918248")
				.zoneId(4)
				.build();

		PromotionRequestList promotionRequestList = new PromotionRequestList();
		promotionRequestList.setPromotions(
				newArrayList(promotionRequest, promotionRequest1));

		WebTarget resource = resources.client().target(PROMOTION_FIND_ENDPOINT);
		Response response = resource.request()
				.accept(MediaType.APPLICATION_JSON)
				.post(Entity.entity(promotionRequestList,MediaType.APPLICATION_JSON));
		assertThat(response.getStatus()).isEqualTo(200);

		/*String jsonResponse = resource.request()
				.accept(MediaType.APPLICATION_JSON)
				.post(String.class, asJson(promotionRequestList));*/

		Response response2 = resource.request()
				.accept(MediaType.APPLICATION_JSON)
				.post(Entity.entity(promotionRequestList,MediaType.APPLICATION_JSON));

		assertThat(objectMapper.writeValueAsString(response2)).doesNotContain("uniqueKey");

		/*List<Promotion> promotions = fromJson(jsonResponse,
				new TypeReference<List<Promotion>>() {
				});*/
		List<Promotion> promotions = response2.readEntity(new GenericType<List<Promotion>>() {});
		assertThat(promotions).hasSize(2);

		Promotion firstPromotion = promotions.get(0);
		assertThat(firstPromotion.getOfferId()).isEqualTo("A29721688");
		assertThat(firstPromotion.getItemNumber()).isEqualTo("070918248");
		assertThat(firstPromotion.getZoneId()).isEqualTo(5);
		assertThat(firstPromotion.getOfferName())
				.isEqualTo("3 LIONS KICK & TRICK BALL 1.00 SPECIAL PURCHASE");
		assertThat(firstPromotion.getEffectiveDate()).isEqualTo("31-Apr-12");
		assertThat(firstPromotion.getEndDate()).isEqualTo("04-May-13");
		assertThat(firstPromotion.getCFDescription1())
				.isEqualTo("SPECIAL PURCHASE 50p");
		assertThat(firstPromotion.getCFDescription2())
				.isEqualTo("3 LIONS|WATERBOTTLE");
		assertThat(firstPromotion.getShelfTalkerImage())
				.isEqualTo("OnSale.png");

		Promotion secondPromotion = promotions.get(1);
		assertThat(secondPromotion.getOfferId()).isEqualTo("A29721690");
		assertThat(secondPromotion.getItemNumber()).isEqualTo("70918248");
		assertThat(secondPromotion.getZoneId()).isEqualTo(4);
		assertThat(secondPromotion.getOfferName())
				.isEqualTo("3 LIONS KICK & TRICK BALL 3.00 SPECIAL PURCHASE");
		assertThat(secondPromotion.getEffectiveDate()).isEqualTo("31-Jun-12");
		assertThat(secondPromotion.getEndDate()).isEqualTo("04-Jul-13");
		assertThat(secondPromotion.getCFDescription1())
				.isEqualTo("SPECIAL PURCHASE 50p");
		assertThat(secondPromotion.getCFDescription2())
				.isEqualTo("3 LIONS|CAR FLAG");

	}

	@Test
	@Ignore
	public void shouldReturnEmptyList() throws Exception {
		PromotionRequest promotionRequest = aPromotionRequest()
				.zoneId(5)
				.itemNumber("something wrong")
				.offerId("something wrong")
				.build();

		PromotionRequestList promotionRequestList = new PromotionRequestList();
		promotionRequestList.setPromotions(newArrayList(promotionRequest));

		WebTarget resource = resources.client().target(PROMOTION_FIND_ENDPOINT);
		Response response = resource.request()
				.accept(MediaType.APPLICATION_JSON)
				.post(Entity.entity(promotionRequestList,MediaType.APPLICATION_JSON));
		assertThat(response.getStatus()).isEqualTo(200);

		List<Promotion> promotions =
				resource.request().accept(MediaType.APPLICATION_JSON)
						.post(Entity.entity(promotionRequestList,
								MediaType.APPLICATION_JSON)).readEntity(new GenericType<List<Promotion>>() {});

		assertThat(promotions).isEmpty();
	}

	@Test
	@Ignore
	public void shouldReturnEmptyListGivenMissingAttribute() throws Exception {
		PromotionRequest promotionRequest = aPromotionRequest()
				.offerId("A29721688")
				.build();

		PromotionRequestList promotionRequestList = new PromotionRequestList();
		promotionRequestList.setPromotions(newArrayList(promotionRequest));

		WebTarget resource = resources.client().target(PROMOTION_FIND_ENDPOINT);
		Response response = resource.request()
				.accept(MediaType.APPLICATION_JSON)
				.post(Entity.entity(promotionRequestList,MediaType.APPLICATION_JSON));
		assertThat(response.getStatus()).isEqualTo(200);

		//        List<DBObject> promotions = (List<DBObject>) JSON.parse(resource.request() 				.accept(MediaType.APPLICATION_JSON).post(String.class, asJson(promotionRequestList)));
		//
		//        assertThat(promotions).isEmpty();
	}

	@Test
	@Ignore
	public void shouldReturnValueForCorrectRequestItemOnly() throws Exception {
		PromotionRequest promotionRequest = aPromotionRequest()
				.zoneId(5)
				.itemNumber("070918248")
				.offerId("A29721688")
				.build();

		PromotionRequest promotionRequest1 = aPromotionRequest()
				.offerId("A29721690")
				.build();

		PromotionRequestList promotionRequestList = new PromotionRequestList();
		promotionRequestList.setPromotions(
				newArrayList(promotionRequest, promotionRequest1));

		WebTarget resource = resources.client().target(PROMOTION_FIND_ENDPOINT);
		Response response = resource.request()
				.accept(MediaType.APPLICATION_JSON)
				.post(Entity.entity(promotionRequestList,MediaType.APPLICATION_JSON));
		assertThat(response.getStatus()).isEqualTo(200);

		List<Promotion> promotions = resource.request()
				.accept(MediaType.APPLICATION_JSON).post(Entity
						.entity(promotionRequestList,
								MediaType.APPLICATION_JSON))
				.readEntity(new GenericType<List<Promotion>>() {
				});

		assertThat(promotions.size()).isEqualTo(1);
		Promotion firstPromotion = promotions.get(0);
		assertThat(firstPromotion.getOfferId()).isEqualTo("A29721688");
		assertThat(firstPromotion.getItemNumber()).isEqualTo("070918248");
		assertThat(firstPromotion.getZoneId()).isEqualTo(5);
		assertThat(firstPromotion.getOfferName())
				.isEqualTo("3 LIONS KICK & TRICK BALL 1.00 SPECIAL PURCHASE");
		assertThat(firstPromotion.getEffectiveDate()).isEqualTo("31-Apr-12");
		assertThat(firstPromotion.getEndDate()).isEqualTo("04-May-13");
		assertThat(firstPromotion.getCFDescription1())
				.isEqualTo("SPECIAL PURCHASE 50p");
		assertThat(firstPromotion.getCFDescription2())
				.isEqualTo("3 LIONS|WATERBOTTLE");
		assertThat(firstPromotion.getShelfTalkerImage())
				.isEqualTo("OnSale.png");
	}

	@Test
	@Ignore
	public void shouldReturnOnlyOneResultGivenDuplicateRequests()
			throws Exception {
		PromotionRequest promotionRequest = aPromotionRequest()
				.zoneId(5)
				.itemNumber("070918248")
				.offerId("A29721688")
				.build();

		PromotionRequest promotionRequest1 = aPromotionRequest()
				.zoneId(5)
				.itemNumber("070918248")
				.offerId("A29721688")
				.build();

		PromotionRequestList promotionRequestList = new PromotionRequestList();
		promotionRequestList.setPromotions(
				newArrayList(promotionRequest, promotionRequest1));

		WebTarget resource = resources.client().target(PROMOTION_FIND_ENDPOINT);
		Response response = resource.request()
				.accept(MediaType.APPLICATION_JSON)
				.post(Entity.entity(promotionRequestList,MediaType.APPLICATION_JSON));
		assertThat(response.getStatus()).isEqualTo(200);

		List<Promotion> promotions = resource.request()
				.accept(MediaType.APPLICATION_JSON).post(Entity
						.entity(promotionRequestList,
								MediaType.APPLICATION_JSON))
				.readEntity(new GenericType<List<Promotion>>() {
				});

		Promotion firstPromotion = promotions.get(0);
		assertThat(firstPromotion.getOfferId()).isEqualTo("A29721688");
		assertThat(firstPromotion.getItemNumber()).isEqualTo("070918248");
		assertThat(firstPromotion.getZoneId()).isEqualTo(5);
		assertThat(firstPromotion.getOfferName())
				.isEqualTo("3 LIONS KICK & TRICK BALL 1.00 SPECIAL PURCHASE");
		assertThat(firstPromotion.getEffectiveDate()).isEqualTo("31-Apr-12");
		assertThat(firstPromotion.getEndDate()).isEqualTo("04-May-13");
		assertThat(firstPromotion.getCFDescription1())
				.isEqualTo("SPECIAL PURCHASE 50p");
		assertThat(firstPromotion.getCFDescription2())
				.isEqualTo("3 LIONS|WATERBOTTLE");
		assertThat(firstPromotion.getShelfTalkerImage())
				.isEqualTo("OnSale.png");
	}
}
