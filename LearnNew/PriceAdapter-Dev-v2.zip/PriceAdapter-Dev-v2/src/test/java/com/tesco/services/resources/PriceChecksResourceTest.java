package com.tesco.services.resources;

import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.Import;
import com.tesco.services.adapters.core.ImportEanJob;
import com.tesco.services.adapters.core.PriceComparatorJob;
import io.dropwizard.testing.junit.ResourceTestRule;
import org.junit.After;
import org.junit.ClassRule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.util.concurrent.Semaphore;

import static org.fest.assertions.api.Assertions.assertThat;


@RunWith(MockitoJUnitRunner.class)
public class PriceChecksResourceTest {

    private static Configuration testConfiguration = TestConfiguration.load();

	static Import mockPriceComparatorJob = Mockito.mock(PriceComparatorJob.class);

    String runType = "uk";
    String fileName = "fileName";

	static Import mockImportEanJob = Mockito.mock(ImportEanJob.class);

    @ClassRule
	public static final ResourceTestRule resources = ResourceTestRule
			.builder().addResource(
					new PriceChecksResource(testConfiguration, mockImportEanJob,
							mockPriceComparatorJob)).build();

    @Test
    public void shouldStartPriceChecks() throws IOException {
        WebTarget resource = resources.client()
                .target("/price/check/comparePrice/" + runType + "/"
                        + fileName);
        Response response = resource.request()
                .accept(MediaType.APPLICATION_JSON)
                .post(Entity.entity("", MediaType.APPLICATION_JSON));
        String responseText = response.readEntity(String.class);
        assertThat(responseText)
                .isEqualTo("{\"message\":\"Price Comparison Job Started.\"}");
        assertThat(response.getStatus()).isEqualTo(200);
    }

    @Test
    public void shouldReturnInProgressWhenCalledChecksInProgress() throws IOException {
        fileName = "abc";
        PriceChecksResource.semaphore.put(fileName, new Semaphore(0));
        WebTarget resource = resources.client()
                .target("/price/check/checksInProgress/abc");
        Response response = resource.request().get();
        String responseText = response.readEntity(String.class);
        assertThat(responseText).isEqualTo("{\"import\":\"progress\"}");
    }
    @Test
    public void shouldReturnCompletedWhenCalledChecksInProgress() throws IOException {
        fileName = "xyz";
        PriceChecksResource.semaphore.put(fileName, new Semaphore(1));
        WebTarget resource = resources.client()
                .target("/price/check/checksInProgress/xyz");
        Response response = resource.request().get();
        String responseText = response.readEntity(String.class);
        assertThat(responseText).isEqualTo("{\"import\":\"completed\"}");
    }
    @Test
    public void shouldReturnErrorStringWhenCalledChecksInProgress() throws IOException {
        fileName = "123";
        PriceChecksResource.semaphore.put(fileName, new Semaphore(1));
        PriceChecksResource.setErrorString("123", "ERROR");
        WebTarget resource = resources.client()
                .target("/price/check/checksInProgress/123");
        Response response = resource.request().get();
        String responseText = response.readEntity(String.class);
        assertThat(responseText)
                .isEqualTo("{\"import\":\"aborted\",\n \"error\":\"ERROR\"}");
    }

    @Test
    public void shouldThrowInvalidIdentifierExceptionAnd400StatusCode() throws IOException {
        runType = "ind";
        fileName = "suv";
        PriceChecksResource.semaphore.put(fileName, new Semaphore(1));
        WebTarget resource = resources.client()
                .target("/price/check/comparePrice/" + runType + "/"
                        + fileName);
        Response response = resource.request()
                .accept(MediaType.APPLICATION_JSON)
                .post(Entity.entity("", MediaType.APPLICATION_JSON));
        String responseText = response.readEntity(String.class);
        assertThat(responseText)
                .isEqualTo("{\"error\":\"Invalid Run Identifier\"}");
        assertThat(response.getStatus()).isEqualTo(400);
    }

    @Test
    public void shouldReturnPriceComparisonalreadyRunning() throws IOException {
        runType = "uk";
        fileName = "abc";
        PriceChecksResource.semaphore.put(fileName, new Semaphore(0));
        WebTarget resource = resources.client()
                .target("/price/check/comparePrice/" + runType + "/"
                        + fileName);
        Response response = resource.request()
                .accept(MediaType.APPLICATION_JSON)
                .post(Entity.entity("", MediaType.APPLICATION_JSON));
        String responseText = response.readEntity(String.class);
        assertThat(responseText).isEqualTo(
                "{\"message\":\"There is already an import in progress.\"}");
        assertThat(response.getStatus()).isEqualTo(409);
    }

    @Test
    public void eanImportResourceTest() throws IOException {
        Mockito.doNothing().when(mockImportEanJob).run();
        WebTarget resource = resources.client()
                .target("/price/check/importEan/" + runType + "/" + fileName);
        Response response = resource.request()
                .accept(MediaType.APPLICATION_JSON)
                .post(Entity.entity("", MediaType.APPLICATION_JSON));
        String responseText = response.readEntity(String.class);
        assertThat(responseText)
                .isEqualTo("{\"message\":\"Import Ean Job Started.\"}");
        assertThat(response.getStatus()).isEqualTo(200);
    }

    @Test
    public void eanImportAlreadyRunning() throws IOException {
        fileName = "abc";
        PriceChecksResource.semaphore.put(fileName, new Semaphore(0));
        Mockito.doNothing().when(mockImportEanJob).run();
        WebTarget resource = resources.client()
                .target("/price/check/importEan/" + runType + "/" + fileName);
        Response response = resource.request()
                .accept(MediaType.APPLICATION_JSON)
                .post(Entity.entity("", MediaType.APPLICATION_JSON));
        String responseText = response.readEntity(String.class);
        assertThat(responseText).isEqualTo(
                "{\"message\":\"There is already an import in progress.\"}");
        assertThat(response.getStatus()).isEqualTo(409);
    }

    @Test
    public void eanImportThrowException() throws IOException {
        fileName = "abc";
        PriceChecksResource.semaphore.put(fileName, new Semaphore(0));
        Mockito.doNothing().when(mockImportEanJob).run();
        WebTarget resource = resources.client()
                .target("/price/check/importEan/" + runType + "/" + fileName);
        Response response = resource.request()
                .accept(MediaType.APPLICATION_JSON)
                .post(Entity.entity("", MediaType.APPLICATION_JSON));
        String responseText = response.readEntity(String.class);
        assertThat(responseText).isEqualTo(
                "{\"message\":\"There is already an import in progress.\"}");
        assertThat(response.getStatus()).isEqualTo(409);
    }

    @After
    public void resetMocks() throws Exception {
        PriceChecksResource.getPriceChecksSemaphore(fileName).release();
    }
}
