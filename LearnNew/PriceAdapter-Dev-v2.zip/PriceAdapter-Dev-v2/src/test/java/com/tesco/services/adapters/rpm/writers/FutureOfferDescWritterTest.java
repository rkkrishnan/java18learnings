package com.tesco.services.adapters.rpm.writers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tesco.couchbase.CouchbaseWrapper;
import com.tesco.couchbase.testutils.AsyncCouchbaseWrapperStub;
import com.tesco.couchbase.testutils.BucketTool;
import com.tesco.couchbase.testutils.CouchbaseTestManager;
import com.tesco.couchbase.testutils.CouchbaseWrapperStub;
import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.exceptions.ColumnNotFoundException;
import com.tesco.services.adapters.promotion.PromotionEventHandler;
import com.tesco.services.adapters.rpm.readers.PriceServiceCSVReader;
import com.tesco.services.adapters.rpm.writers.impl.FutureOfferDescWritter;
import com.tesco.services.core.ZoneEntity;
import com.tesco.services.core.promotion.ProductOffersEntity;
import com.tesco.services.core.promotion.PromotionEntity;
import com.tesco.services.core.promotion.PromotionMasterEntity;
import com.tesco.services.repositories.RepositoryImpl;
import com.tesco.services.resources.ImportResource;
import com.tesco.services.resources.TestConfiguration;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.PriceConstants;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.assertj.core.api.Assertions;
import org.glassfish.hk2.api.ServiceLocator;
import org.joda.time.DateTimeUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.io.IOException;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Semaphore;

import static com.tesco.services.utility.PriceConstants.*;
import static io.dropwizard.testing.FixtureHelpers.fixture;
import static org.fest.assertions.api.Assertions.assertThat;
import static org.joda.time.DateTimeUtils.setCurrentMillisFixed;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

/**
 * Created by QP65 on 12/16/2015.
 */
@RunWith(MockitoJUnitRunner.class)
public class FutureOfferDescWritterTest {

	@Mock
	public RepositoryImpl repositoryImpl;
	@Mock
	public CouchbaseWrapper couchbaseWrapper;
	@Mock
	private Configuration testConfiguration;
	@Mock
	private Configuration mockTestConfiguration;
	@Mock
	private CouchbaseTestManager couchbaseTestManager;
	@Mock
	private PriceServiceCSVReader futureOfferDescReader;
	@Mock
	private PromotionEventHandler promotionEventHandler;

	private FutureOfferDescWritter futureOfferDescWritter;
	private ObjectMapper mapper = new ObjectMapper();

	private String runIdentifier = "futureOfferDesc";
	private String fileName = "FutureOfferDesc.csv";
	private Map<String, String> futureOfferDescMap1;

	@Mock
	public ServiceLocator serviceLocator;

	@Before
	public void setUp() throws IOException, URISyntaxException,
			InterruptedException, ColumnNotFoundException {
		testConfiguration = TestConfiguration.load();
		mapper = new ObjectMapper();
		if (testConfiguration.isDummyCouchbaseMode()) {
			Map<String, ImmutablePair<Long, String>> fakeBase = new HashMap<>();
			couchbaseTestManager = new CouchbaseTestManager(
					new CouchbaseWrapperStub(fakeBase),
					new AsyncCouchbaseWrapperStub(fakeBase),
					mock(BucketTool.class));
		} else {
			couchbaseTestManager = new CouchbaseTestManager(
					testConfiguration.getCouchbaseBucket(),
					testConfiguration.getCouchbaseUsername(),
					testConfiguration.getCouchbasePassword(),
					testConfiguration.getCouchbaseNodes(),
					testConfiguration.getCouchbaseAdminUsername(),
					testConfiguration.getCouchbaseAdminPassword());
		}

		couchbaseWrapper = couchbaseTestManager.getCouchbaseWrapper();

		Mockito.when(
				serviceLocator.getService(CouchbaseWrapper.class,
						"couchbaseWrapper")).thenReturn(couchbaseWrapper);
		Mockito.when(
				serviceLocator.getService(ObjectMapper.class, "jsonmapper"))
				.thenReturn(mapper);

		/*
		 * productRepository = new ProductRepository(couchbaseWrapper,
		 * asyncCouchbaseWrapper, new ObjectMapper());
		 */
		futureOfferDescWritter = new FutureOfferDescWritter(testConfiguration,
				repositoryImpl, futureOfferDescReader, promotionEventHandler);
		futureOfferDescWritter.setRunIdentifier(runIdentifier);

	}

	@Test
	public void readAndWriteFutureOfferDesc() throws Exception {
		String tpnb = "050000419";
		String offerId = "A12345";
		String offerIdNo = "12345";
		String zone = "5";
		String cfDesc1 = "description1";
		String cfDesc2 = "description2";
		String dateFormats = "MMM dd yyyy hh:mma";
		SimpleDateFormat dateFormat = new SimpleDateFormat(dateFormats);
		Calendar cal = Calendar.getInstance();
		cal.setTime(dateFormat.parse(Dockyard.getSysDate(dateFormats)));
		cal.add(Calendar.DATE,
				PriceConstants.FUTURE_OFFER_DESC_RANGE.RANGE_BEGIN.value() + 1);
		String startDate = dateFormat.format(cal.getTime());

		PromotionEntity promotionDoc = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/futureOfferDesc/PROMOTION_12345_Z5.json"),
						PromotionEntity.class);
		ProductOffersEntity productOffersEntity = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/futureOfferDesc/PRODOFFERS_050000419_Z5.json"),
						ProductOffersEntity.class);

		futureOfferDescMap1 = returnFutureOfferDesc(offerId, tpnb, zone,
				startDate, cfDesc1, cfDesc2);

		when(futureOfferDescReader.getNext()).thenReturn(futureOfferDescMap1)
				.thenReturn(null);
		when(
				repositoryImpl.getGenericObject(
						PriceConstants.PROMOTION_DOC_KEY_PREFIX + offerIdNo
								+ "_Z5", PromotionEntity.class)).thenReturn(
				promotionDoc);
		when(
				repositoryImpl.getGenericObject(PriceConstants.PROD_OFFERS
						+ tpnb + "_Z" + zone, ProductOffersEntity.class))
				.thenReturn(productOffersEntity);

		ImportResource.importSemaphoreForIdentifier.put(fileName,
				new Semaphore(1));

		this.futureOfferDescWritter.write(fileName);
		/** Build expected promotion doc */
		PromotionEntity expectedPromoDoc = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/futureOfferDesc/PROMOTION_12345_Z5.json"),
						PromotionEntity.class);
		ProductOffersEntity expectedProductOffersEntity = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/futureOfferDesc/PRODOFFERS_050000419_Z5.json"),
						ProductOffersEntity.class);
		expectedProductOffersEntity.getProductOffersPromotionMap()
				.get(offerIdNo).setCfDescription1(cfDesc1);
		expectedProductOffersEntity.getProductOffersPromotionMap()
				.get(offerIdNo).setCfDescription2(cfDesc2);

		PromotionEntity actualPromotionEntity = (PromotionEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdNo + "_Z5", PromotionEntity.class);
		ProductOffersEntity actualProductOffersEntity = (ProductOffersEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROD_OFFERS + tpnb + "_Z"
						+ zone, ProductOffersEntity.class);
		/** Ignoring the date */
		actualPromotionEntity.setLastUpdateDate("");
		expectedPromoDoc.setLastUpdateDate("");

		actualProductOffersEntity.setLastUpdateDateTime("");
		actualProductOffersEntity.getProductOffersPromotionMap().get(offerIdNo)
				.setLastUpdateDateTime("");
		expectedProductOffersEntity.setLastUpdateDateTime("");
		expectedProductOffersEntity.getProductOffersPromotionMap()
				.get(offerIdNo).setLastUpdateDateTime("");

		assertThat(actualPromotionEntity).isNotNull();

		assertThat(actualPromotionEntity.toString()).isEqualTo(
				expectedPromoDoc.toString());

		assertThat(actualProductOffersEntity.toString()).isEqualTo(
				expectedProductOffersEntity.toString());

	}

	@Test
	public void readAndWriteFutureOfferDescMultipleOffers() throws Exception {
		String tpnb1 = "050000419";
		String tpnb2 = "050000519";
		String offerId = "A12345";
		String offerIdNo = "12345";
		String offerId2 = "A6789";
		String offerIdNo2 = "6789";
		String zone = "5";
		String cfDesc1 = "description1";
		String cfDesc2 = "description2";
		String dateFormats = "MMM dd yyyy hh:mma";
		SimpleDateFormat dateFormat = new SimpleDateFormat(dateFormats);
		Calendar cal = Calendar.getInstance();
		cal.setTime(dateFormat.parse(Dockyard.getSysDate(dateFormats)));
		cal.add(Calendar.DATE,
				PriceConstants.FUTURE_OFFER_DESC_RANGE.RANGE_BEGIN.value() + 1);
		String startDate = dateFormat.format(cal.getTime());

		PromotionEntity promotionDoc1 = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/futureOfferDesc/PROMOTION_12345_Z5.json"),
						PromotionEntity.class);
		ProductOffersEntity productOffersEntity1 = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/futureOfferDesc/PRODOFFERS_050000419_Z5.json"),
						ProductOffersEntity.class);

		PromotionEntity promotionDoc2 = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/futureOfferDesc/PROMOTION_6789_Z5.json"),
						PromotionEntity.class);
		ProductOffersEntity productOffersEntity2 = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/futureOfferDesc/PRODOFFERS_050000519_Z5.json"),
						ProductOffersEntity.class);

		Map<String, String> futureOfferDescMap2;
		futureOfferDescMap1 = returnFutureOfferDesc(offerId, tpnb1, zone,
				startDate, cfDesc1, cfDesc2);
		futureOfferDescMap2 = returnFutureOfferDesc(offerId2, tpnb2, zone,
				startDate, cfDesc1, cfDesc2);
		when(futureOfferDescReader.getNext()).thenReturn(futureOfferDescMap1)
				.thenReturn(futureOfferDescMap2).thenReturn(null);
		when(
				repositoryImpl.getGenericObject(
						PriceConstants.PROMOTION_DOC_KEY_PREFIX + offerIdNo
								+ "_Z5", PromotionEntity.class)).thenReturn(
				promotionDoc1);
		when(
				repositoryImpl.getGenericObject(PriceConstants.PROD_OFFERS
						+ tpnb1 + "_Z" + zone, ProductOffersEntity.class))
				.thenReturn(productOffersEntity1);

		when(
				repositoryImpl.getGenericObject(
						PriceConstants.PROMOTION_DOC_KEY_PREFIX + offerIdNo2
								+ "_Z5", PromotionEntity.class)).thenReturn(
				promotionDoc2);
		when(
				repositoryImpl.getGenericObject(PriceConstants.PROD_OFFERS
						+ tpnb2 + "_Z" + zone, ProductOffersEntity.class))
				.thenReturn(productOffersEntity2);

		ImportResource.importSemaphoreForIdentifier.put(fileName,
				new Semaphore(1));

		this.futureOfferDescWritter.write(fileName);
		/** Build expected promotion doc */
		PromotionEntity expectedPromoDoc1 = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/futureOfferDesc/PROMOTION_12345_Z5.json"),
						PromotionEntity.class);

		ProductOffersEntity expectedProductOffersEntity1 = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/futureOfferDesc/PRODOFFERS_050000419_Z5.json"),
						ProductOffersEntity.class);
		expectedProductOffersEntity1.getProductOffersPromotionMap()
				.get(offerIdNo).setCfDescription1(cfDesc1);
		expectedProductOffersEntity1.getProductOffersPromotionMap()
				.get(offerIdNo).setCfDescription2(cfDesc2);

		PromotionEntity expectedPromoDoc2 = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/futureOfferDesc/PROMOTION_6789_Z5.json"),
						PromotionEntity.class);
		ProductOffersEntity expectedProductOffersEntity2 = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/futureOfferDesc/PRODOFFERS_050000519_Z5.json"),
						ProductOffersEntity.class);
		expectedProductOffersEntity2.getProductOffersPromotionMap()
				.get(offerIdNo2).setCfDescription1(cfDesc1);
		expectedProductOffersEntity2.getProductOffersPromotionMap()
				.get(offerIdNo2).setCfDescription2(cfDesc2);

		/** Actual docs from CB */
		PromotionEntity actualPromotionEntity = (PromotionEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdNo + "_Z5", PromotionEntity.class);
		ProductOffersEntity actualProductOffersEntity = (ProductOffersEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROD_OFFERS + tpnb1 + "_Z"
						+ zone, ProductOffersEntity.class);

		PromotionEntity actualPromotionEntity2 = (PromotionEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdNo2 + "_Z5", PromotionEntity.class);
		ProductOffersEntity actualProductOffersEntity2 = (ProductOffersEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROD_OFFERS + tpnb2 + "_Z"
						+ zone, ProductOffersEntity.class);
		/** Ignoring the date */
		actualPromotionEntity.setLastUpdateDate("");
		expectedPromoDoc1.setLastUpdateDate("");
		actualPromotionEntity2.setLastUpdateDate("");
		expectedPromoDoc2.setLastUpdateDate("");

		actualProductOffersEntity.setLastUpdateDateTime("");
		actualProductOffersEntity.getProductOffersPromotionMap().get(offerIdNo)
				.setLastUpdateDateTime("");
		expectedProductOffersEntity1.setLastUpdateDateTime("");
		expectedProductOffersEntity1.getProductOffersPromotionMap()
				.get(offerIdNo).setLastUpdateDateTime("");

		actualProductOffersEntity2.setLastUpdateDateTime("");
		actualProductOffersEntity2.getProductOffersPromotionMap()
				.get(offerIdNo2).setLastUpdateDateTime("");
		expectedProductOffersEntity2.setLastUpdateDateTime("");
		expectedProductOffersEntity2.getProductOffersPromotionMap()
				.get(offerIdNo2).setLastUpdateDateTime("");

		assertThat(actualPromotionEntity.toString()).isEqualTo(
				expectedPromoDoc1.toString());

		assertThat(actualProductOffersEntity.toString()).isEqualTo(
				expectedProductOffersEntity1.toString());

		assertThat(actualPromotionEntity2.toString()).isEqualTo(
				expectedPromoDoc2.toString());

		assertThat(actualProductOffersEntity2.toString()).isEqualTo(
				expectedProductOffersEntity2.toString());

	}

	@Test
	public void readAndWriteFutureOfferDescAboveDateThreshold()
			throws Exception {
		String tpnb = "050000419";
		String offerId = "A12345";
		String offerIdNo = "12345";
		String zone = "5";
		String cfDesc1 = "description1";
		String cfDesc2 = "description2";
		String dateFormats = "MMM dd yyyy hh:mma";
		SimpleDateFormat dateFormat = new SimpleDateFormat(dateFormats);
		Calendar cal = Calendar.getInstance();
		cal.setTime(dateFormat.parse(Dockyard.getSysDate(dateFormats)));
		cal.add(Calendar.DATE,
				PriceConstants.FUTURE_OFFER_DESC_RANGE.RANGE_END.value() + 2);
		String startDate = dateFormat.format(cal.getTime());

		PromotionEntity promotionDoc = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/futureOfferDesc/PROMOTION_12345_Z5.json"),
						PromotionEntity.class);
		ProductOffersEntity productOffersEntity = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/futureOfferDesc/PRODOFFERS_050000419_Z5.json"),
						ProductOffersEntity.class);

		futureOfferDescMap1 = returnFutureOfferDesc(offerId, tpnb, zone,
				startDate, cfDesc1, cfDesc2);

		when(futureOfferDescReader.getNext()).thenReturn(futureOfferDescMap1)
				.thenReturn(null);
		when(
				repositoryImpl.getGenericObject(
						PriceConstants.PROMOTION_DOC_KEY_PREFIX + offerIdNo
								+ "_Z5", PromotionEntity.class)).thenReturn(
				promotionDoc);
		when(
				repositoryImpl.getGenericObject(PriceConstants.PROD_OFFERS
						+ tpnb + "_Z" + zone, ProductOffersEntity.class))
				.thenReturn(productOffersEntity);

		ImportResource.importSemaphoreForIdentifier.put(fileName,
				new Semaphore(1));

		this.futureOfferDescWritter.write(fileName);

		PromotionEntity actualPromotionEntity = (PromotionEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdNo + "_Z5", PromotionEntity.class);
		ProductOffersEntity actualProductOffersEntity = (ProductOffersEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROD_OFFERS + tpnb + "_Z"
						+ zone, ProductOffersEntity.class);
		/** Ignoring the date */
		actualPromotionEntity.setLastUpdateDate("");
		promotionDoc.setLastUpdateDate("");

		actualProductOffersEntity.setLastUpdateDateTime("");
		actualProductOffersEntity.getProductOffersPromotionMap().get(offerIdNo)
				.setLastUpdateDateTime("");
		productOffersEntity.setLastUpdateDateTime("");
		productOffersEntity.getProductOffersPromotionMap().get(offerIdNo)
				.setLastUpdateDateTime("");

		assertThat(actualPromotionEntity).isNotNull();

		assertThat(actualPromotionEntity.toString()).isEqualTo(
				promotionDoc.toString());

		assertThat(actualProductOffersEntity.toString()).isEqualTo(
				productOffersEntity.toString());

	}

	@Test
	public void readAndWriteFutureOfferDescRejects() throws Exception {
		String tpnb = "050000419";
		String offerId = "A12345";
		String offerIdNo = "12345";
		String zone = "5";
		String cfDesc1 = "description1";
		String cfDesc2 = "description2";
		String dateFormats = "MMM dd yyyy hh:mma";
		SimpleDateFormat dateFormat = new SimpleDateFormat(dateFormats);
		Calendar cal = Calendar.getInstance();
		cal.setTime(dateFormat.parse(Dockyard.getSysDate(dateFormats)));
		cal.add(Calendar.DATE,
				PriceConstants.FUTURE_OFFER_DESC_RANGE.RANGE_BEGIN.value() + 1);
		String startDate = dateFormat.format(cal.getTime());

		PromotionEntity promotionDoc = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/futureOfferDesc/PROMOTION_12345_Z5.json"),
						PromotionEntity.class);
		ProductOffersEntity productOffersEntity = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/futureOfferDesc/PRODOFFERS_050000419_Z5.json"),
						ProductOffersEntity.class);
		ProductOffersEntity productOffersEntity2 = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/futureOfferDesc/PRODOFFERS_050000619_Z5.json"),
						ProductOffersEntity.class);
		Map<String, String> futureOfferDescMap2;
		Map<String, String> futureOfferDescMap3;
		futureOfferDescMap1 = returnFutureOfferDesc("3456", tpnb, zone,
				startDate, cfDesc1, cfDesc2);
		futureOfferDescMap2 = returnFutureOfferDesc(offerId, "12345", zone,
				startDate, cfDesc1, cfDesc2);
		futureOfferDescMap3 = returnFutureOfferDesc(offerId, "050000619", zone,
				startDate, cfDesc1, cfDesc2);

		when(futureOfferDescReader.getNext()).thenReturn(futureOfferDescMap1)
				.thenReturn(futureOfferDescMap2)
				.thenReturn(futureOfferDescMap3).thenReturn(null);
		when(
				repositoryImpl.getGenericObject(
						PriceConstants.PROMOTION_DOC_KEY_PREFIX + offerIdNo
								+ "_Z5", PromotionEntity.class)).thenReturn(
				promotionDoc);
		when(
				repositoryImpl.getGenericObject(PriceConstants.PROD_OFFERS
						+ tpnb + "_Z" + zone, ProductOffersEntity.class))
				.thenReturn(productOffersEntity);
		when(
				repositoryImpl.getGenericObject(PriceConstants.PROD_OFFERS
						+ "050000619" + "_Z" + zone, ProductOffersEntity.class))
				.thenReturn(productOffersEntity2);
		ImportResource.importSemaphoreForIdentifier.put(fileName,
				new Semaphore(1));

		this.futureOfferDescWritter.write(fileName);

		PromotionEntity actualPromotionEntity = (PromotionEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdNo + "_Z5", PromotionEntity.class);
		ProductOffersEntity actualProductOffersEntity = (ProductOffersEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROD_OFFERS + tpnb + "_Z"
						+ zone, ProductOffersEntity.class);
		/** Ignoring the date */
		actualPromotionEntity.setLastUpdateDate("");
		promotionDoc.setLastUpdateDate("");

		actualProductOffersEntity.setLastUpdateDateTime("");
		actualProductOffersEntity.getProductOffersPromotionMap().get(offerIdNo)
				.setLastUpdateDateTime("");
		productOffersEntity.setLastUpdateDateTime("");
		productOffersEntity.getProductOffersPromotionMap().get(offerIdNo)
				.setLastUpdateDateTime("");

		assertThat(actualPromotionEntity).isNotNull();

		assertThat(actualPromotionEntity.toString()).isEqualTo(
				promotionDoc.toString());

		assertThat(actualProductOffersEntity.toString()).isEqualTo(
				productOffersEntity.toString());

	}

	@Ignore
	@Test
	public void readAndWriteFutureOfferDescexceptionForCBOperation()
			throws Exception {
		String tpnb = "050000419";
		String offerId = "A12345";
		String offerIdNo = "12345";
		String zone = "5";
		String cfDesc1 = "description1";
		String cfDesc2 = "description2";
		String dateFormats = "MMM dd yyyy hh:mma";
		SimpleDateFormat dateFormat = new SimpleDateFormat(dateFormats);
		Calendar cal = Calendar.getInstance();
		cal.setTime(dateFormat.parse(Dockyard.getSysDate(dateFormats)));
		cal.add(Calendar.DATE,
				PriceConstants.FUTURE_OFFER_DESC_RANGE.RANGE_BEGIN.value() + 1);
		String startDate = dateFormat.format(cal.getTime());

		PromotionMasterEntity promotionDoc = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/futureOfferDesc/PROMOTION_12345.json"),
						PromotionMasterEntity.class);
		ProductOffersEntity productOffersEntity = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/futureOfferDesc/PRODOFFERS_050000419_Z5.json"),
						ProductOffersEntity.class);
		ProductOffersEntity productOffersEntity2 = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/futureOfferDesc/PRODOFFERS_050000619_Z5.json"),
						ProductOffersEntity.class);
		Map<String, String> futureOfferDescMap2;
		Map<String, String> futureOfferDescMap3;
		futureOfferDescMap1 = returnFutureOfferDesc("3456", tpnb, zone,
				startDate, cfDesc1, cfDesc2);
		futureOfferDescMap2 = returnFutureOfferDesc(offerId, "12345", zone,
				startDate, cfDesc1, cfDesc2);
		futureOfferDescMap3 = returnFutureOfferDesc(offerId, "050000619", zone,
				startDate, cfDesc1, cfDesc2);

		when(futureOfferDescReader.getNext()).thenReturn(futureOfferDescMap1)
				.thenReturn(futureOfferDescMap2)
				.thenReturn(futureOfferDescMap3).thenReturn(null);
		when(
				repositoryImpl.getGenericObject(
						PriceConstants.PROMOTION_DOC_KEY_PREFIX + offerIdNo,
						PromotionMasterEntity.class)).thenReturn(promotionDoc);
		when(
				repositoryImpl.getGenericObject(PriceConstants.PROD_OFFERS
						+ tpnb + "_Z" + zone, ProductOffersEntity.class))
				.thenReturn(productOffersEntity);
		when(
				repositoryImpl.getGenericObject(PriceConstants.PROD_OFFERS
						+ "050000619" + "_Z" + zone, ProductOffersEntity.class))
				.thenReturn(productOffersEntity2);
		ImportResource.importSemaphoreForIdentifier.put(fileName,
				new Semaphore(1));
		Mockito.doThrow(new Exception("JsonProcessing Exception"))
				.when(repositoryImpl)
				.insertObject(Mockito.anyString(), Mockito.anyObject());

		this.futureOfferDescWritter.write(fileName);

		PromotionMasterEntity actualPromotionMasterEntity = (PromotionMasterEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdNo, PromotionMasterEntity.class);
		ProductOffersEntity actualProductOffersEntity = (ProductOffersEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROD_OFFERS + tpnb + "_Z"
						+ zone, ProductOffersEntity.class);
		/** Ignoring the date */
		actualPromotionMasterEntity.setLastUpdateDate("");
		promotionDoc.setLastUpdateDate("");

		actualProductOffersEntity.setLastUpdateDateTime("");
		actualProductOffersEntity.getProductOffersPromotionMap().get(offerIdNo)
				.setLastUpdateDateTime("");
		productOffersEntity.setLastUpdateDateTime("");
		productOffersEntity.getProductOffersPromotionMap().get(offerIdNo)
				.setLastUpdateDateTime("");

		assertThat(actualPromotionMasterEntity).isNotNull();

		assertThat(actualPromotionMasterEntity.toString()).isEqualTo(
				promotionDoc.toString());

		assertThat(actualProductOffersEntity.toString()).isEqualTo(
				productOffersEntity.toString());

	}

	@Test
	public void testArrayIndexOutOfBoundExcpetions() throws Exception {
		when(futureOfferDescReader.getNext()).thenThrow(
				new ArrayIndexOutOfBoundsException(
						"Array index out of bound Exception"));
		ImportResource.importSemaphoreForIdentifier.put(fileName,
				new Semaphore(1));
		this.futureOfferDescWritter.write(fileName);
		assertThat("Array index out of bound Exception").isEqualTo(
				ImportResource.getErrorString(fileName));

	}

	@Test
	public void testgenericExcpetions() throws Exception {
		when(futureOfferDescReader.getNext()).thenThrow(
				new IOException("io exception"));
		ImportResource.importSemaphoreForIdentifier.put(fileName,
				new Semaphore(1));
		this.futureOfferDescWritter.write(fileName);
		assertThat("java.io.IOException: io exception").isEqualTo(
				ImportResource.getErrorString(fileName));

	}

	private Map<String, String> returnFutureOfferDesc(String offerId,
			String tpnb, String zone, String startDate, String cfDesc1,
			String cfDesc2) {

		Map<String, String> futureOfferDesc = new HashMap<>();

		futureOfferDesc.put(CSVHeaders.PromoDescExtract.ITEM, tpnb);
		futureOfferDesc.put(CSVHeaders.PromoDescExtract.ZONE_ID, zone);
		futureOfferDesc.put(CSVHeaders.PromoDescExtract.OFFER_ID, offerId);
		futureOfferDesc.put(CSVHeaders.PromoDescExtract.DESC1, cfDesc1);
		futureOfferDesc.put(CSVHeaders.PromoDescExtract.DESC2, cfDesc2);
		futureOfferDesc.put(CSVHeaders.PromoDescExtract.START_DATE, startDate);

		return futureOfferDesc;
	}

	// Added for PRIS-2007 Support change to cf desc while product is on promo
	private Map<String, String> returnFutureOfferDesc(String offerId,
			String tpnb, String zone, String startDate, String endDate,
			String cfDesc1, String cfDesc2) {

		Map<String, String> futureOfferDesc = new HashMap<>();

		futureOfferDesc.put(CSVHeaders.PromoDescExtract.ITEM, tpnb);
		futureOfferDesc.put(CSVHeaders.PromoDescExtract.ZONE_ID, zone);
		futureOfferDesc.put(CSVHeaders.PromoDescExtract.OFFER_ID, offerId);
		futureOfferDesc.put(CSVHeaders.PromoDescExtract.DESC1, cfDesc1);
		futureOfferDesc.put(CSVHeaders.PromoDescExtract.DESC2, cfDesc2);
		futureOfferDesc.put(CSVHeaders.PromoDescExtract.START_DATE, startDate);
		futureOfferDesc.put(CSVHeaders.PromoDescExtract.END_DATE, endDate);

		return futureOfferDesc;
	}

	// Added for PRIS-2007 Support change to cf desc while product is on promo
	@Test
	public void readAndWriteActiveOfferDesc() throws Exception {
		String tpnb = "050000419";
		String offerId = "A12345";
		String offerIdNo = "12345";
		String zone = "5";
		String cfDesc1 = "description1";
		String cfDesc2 = "description2";
		String dateFormats = "MMM dd yyyy hh:mma";
		SimpleDateFormat dateFormat = new SimpleDateFormat(dateFormats);
		Calendar cal = Calendar.getInstance();
		cal.setTime(dateFormat.parse(Dockyard.getSysDate(dateFormats)));
		cal.add(Calendar.DATE, -2);
		String startDate = dateFormat.format(cal.getTime());

		cal.setTime(dateFormat.parse(Dockyard.getSysDate(dateFormats)));
		cal.add(Calendar.DATE, 5);
		String endDate = dateFormat.format(cal.getTime());

		PromotionEntity promotionDoc = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/futureOfferDesc/PROMOTION_12345_Z5.json"),
						PromotionEntity.class);
		ProductOffersEntity productOffersEntity = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/futureOfferDesc/PRODOFFERS_050000419_Z5.json"),
						ProductOffersEntity.class);

		futureOfferDescMap1 = returnFutureOfferDesc(offerId, tpnb, zone,
				startDate, endDate, cfDesc1, cfDesc2);

		when(futureOfferDescReader.getNext()).thenReturn(futureOfferDescMap1)
				.thenReturn(null);
		when(
				repositoryImpl.getGenericObject(
						PriceConstants.PROMOTION_DOC_KEY_PREFIX + offerIdNo
								+ "_Z5", PromotionEntity.class)).thenReturn(
				promotionDoc);
		when(
				repositoryImpl.getGenericObject(PriceConstants.PROD_OFFERS
						+ tpnb + "_Z" + zone, ProductOffersEntity.class))
				.thenReturn(productOffersEntity);

		ImportResource.importSemaphoreForIdentifier.put(fileName,
				new Semaphore(1));

		this.futureOfferDescWritter.write(fileName);
		/** Build expected promotion doc */
		PromotionEntity expectedPromoDoc = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/futureOfferDesc/PROMOTION_12345_Z5.json"),
						PromotionEntity.class);
		ProductOffersEntity expectedProductOffersEntity = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/futureOfferDesc/PRODOFFERS_050000419_Z5.json"),
						ProductOffersEntity.class);
		expectedProductOffersEntity.getProductOffersPromotionMap()
				.get(offerIdNo).setCfDescription1(cfDesc1);
		expectedProductOffersEntity.getProductOffersPromotionMap()
				.get(offerIdNo).setCfDescription2(cfDesc2);

		PromotionEntity actualPromotionEntity = (PromotionEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdNo + "_Z5", PromotionEntity.class);
		ProductOffersEntity actualProductOffersEntity = (ProductOffersEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROD_OFFERS + tpnb + "_Z"
						+ zone, ProductOffersEntity.class);
		/** Ignoring the date */
		actualPromotionEntity.setLastUpdateDate("");
		expectedPromoDoc.setLastUpdateDate("");

		actualProductOffersEntity.setLastUpdateDateTime("");
		actualProductOffersEntity.getProductOffersPromotionMap().get(offerIdNo)
				.setLastUpdateDateTime("");
		expectedProductOffersEntity.setLastUpdateDateTime("");
		expectedProductOffersEntity.getProductOffersPromotionMap()
				.get(offerIdNo).setLastUpdateDateTime("");

		assertThat(actualPromotionEntity).isNotNull();

		Assertions.assertThat(actualPromotionEntity)
				.isEqualToComparingFieldByFieldRecursively(expectedPromoDoc);

		Assertions.assertThat(actualProductOffersEntity)
				.isEqualToComparingFieldByFieldRecursively(
						expectedProductOffersEntity);

	}

	@Test
	public void readAndWriteFutureOfferDescNegativeExceptionInInsertion()
			throws Exception {

		String tpnb = "050000419";
		String offerId = "A12345";
		String offerIdNo = "12345";
		String zone = "5";
		String cfDesc1 = "description1";
		String cfDesc2 = "description2";
		String dateFormats = "MMM dd yyyy hh:mma";
		SimpleDateFormat dateFormat = new SimpleDateFormat(dateFormats);
		Calendar cal = Calendar.getInstance();
		cal.setTime(dateFormat.parse(Dockyard.getSysDate(dateFormats)));
		cal.add(Calendar.DATE, -2);
		String startDate = dateFormat.format(cal.getTime());

		cal.setTime(dateFormat.parse(Dockyard.getSysDate(dateFormats)));
		cal.add(Calendar.DATE, 5);
		String endDate = dateFormat.format(cal.getTime());

		PromotionEntity promotionDoc = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/futureOfferDesc/PROMOTION_12345_Z5.json"),
						PromotionEntity.class);
		ProductOffersEntity productOffersEntity = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/futureOfferDesc/PRODOFFERS_050000419_Z5.json"),
						ProductOffersEntity.class);

		futureOfferDescMap1 = returnFutureOfferDesc(offerId, tpnb, zone,
				startDate, endDate, cfDesc1, cfDesc2);

		when(futureOfferDescReader.getNext()).thenReturn(futureOfferDescMap1)
				.thenReturn(null);
		when(
				repositoryImpl.getGenericObject(
						PriceConstants.PROMOTION_DOC_KEY_PREFIX + offerIdNo
								+ "_Z5", PromotionEntity.class)).thenReturn(
				promotionDoc);
		when(
				repositoryImpl.getGenericObject(PriceConstants.PROD_OFFERS
						+ tpnb + "_Z" + zone, ProductOffersEntity.class))
				.thenReturn(productOffersEntity);
		doThrow(new Exception("Exception")).when(repositoryImpl)
				.insertObject(anyString(), anyObject());

		ImportResource.importSemaphoreForIdentifier.put(fileName,
				new Semaphore(1));

		this.futureOfferDescWritter.write(fileName);

		PromotionEntity actualPromotionEntity = (PromotionEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ offerIdNo + "_Z5", PromotionEntity.class);
		ProductOffersEntity actualProductOffersEntity = (ProductOffersEntity) repositoryImpl
				.getGenericObject(PriceConstants.PROD_OFFERS + tpnb + "_Z"
						+ zone, ProductOffersEntity.class);

		/** Build expected promotion doc */
		PromotionEntity expectedPromoDoc = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/futureOfferDesc/PROMOTION_12345_Z5.json"),
						PromotionEntity.class);
		ProductOffersEntity expectedProductOffersEntity = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/futureOfferDesc/PRODOFFERS_050000419_Z5.json"),
						ProductOffersEntity.class);

		/** Ignoring the date */
		actualPromotionEntity.setLastUpdateDate("");
		expectedPromoDoc.setLastUpdateDate("");

		actualProductOffersEntity.setLastUpdateDateTime("");
		actualProductOffersEntity.getProductOffersPromotionMap().get(offerIdNo)
				.setLastUpdateDateTime("");
		expectedProductOffersEntity.setLastUpdateDateTime("");
		expectedProductOffersEntity.getProductOffersPromotionMap()
				.get(offerIdNo).setLastUpdateDateTime("");

		assertThat(actualPromotionEntity).isNotNull();

		Assertions.assertThat(actualPromotionEntity)
				.isEqualToComparingFieldByFieldRecursively(expectedPromoDoc);

		Assertions.assertThat(actualProductOffersEntity)
				.isEqualToComparingFieldByFieldRecursively(
						expectedProductOffersEntity);
	}

	@Test
	public void shouldSendPromotionDetailChangeEventWhenCustomerFriendlyDescriptionChanged()
			throws Exception {
		String offerId = "1108";
		String customerFriendlyDescription1 = "SAVE &#163;9.80 Was &#163;31.20 Now &#163;23.40";
		String customerFriendlyDescription2 = "PHD NUTRITION|DIET WHEY Test 111";
		String locRef = "5";
		String locType = "Z";
		String OFFER_ID_VALUE_1108 = "1108";
		String PROMO_KEY_1108 = "PROMOTION_1108_Z5";
		String countryCodeGB = "GB";
		String effectiveDate = "Jun 08 2016 12:00AM";
		String leadTimeDaysExpected = "0";
		setCurrentMillisFixed(1465368087471l);
		ZoneEntity zoneEntity = new ZoneEntity();
		zoneEntity.setTslCountryCode(countryCodeGB);
		PromotionEntity promotionEntityMock = mapper
				.readValue(
						fixture("com/tesco/services/core/fixtures/futureOfferDesc/PROMOTION_1108_Z5.json"),
						PromotionEntity.class);
		when(
				repositoryImpl.getGenericObject(PROMO_KEY_1108,
						PromotionEntity.class)).thenReturn(promotionEntityMock);
		when(
				repositoryImpl.getGenericObject(ZONE_KEY
						+ promotionEntityMock.getLocRef(),ZoneEntity.class)).thenReturn(
				zoneEntity);
		futureOfferDescWritter.processFutureOfferDescPromotionEntity(offerId,
				customerFriendlyDescription1, customerFriendlyDescription2,
				locRef, effectiveDate);
		Map<String, String> promotionMapDataMock = new HashMap<>();
		promotionMapDataMock.put(OFFER_ID, OFFER_ID_VALUE_1108);
		promotionMapDataMock.put(LOC_REF, locRef);
		promotionMapDataMock.put(LOC_TYPE, locType);
		promotionMapDataMock.put(EVENT_TYPE,
				PROMOTION_DETAILS_CHANGED_EVENT_TYPE);
		promotionMapDataMock.put(LEAD_TIME_DAYS, leadTimeDaysExpected);
		verify(promotionEventHandler, times(1)).publishPromotionEvent(
				promotionMapDataMock);

	}

	@After
	public void tearDown() {
		DateTimeUtils.setCurrentMillisSystem();
	}
}
