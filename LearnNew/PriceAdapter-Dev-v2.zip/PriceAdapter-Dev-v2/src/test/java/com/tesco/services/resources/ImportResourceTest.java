package com.tesco.services.resources;

import static org.fest.assertions.api.Assertions.assertThat;
import io.dropwizard.testing.junit.ResourceTestRule;

import java.io.IOException;
import java.util.concurrent.Semaphore;

import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.junit.After;
import org.junit.Before;
import org.junit.ClassRule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.Import;
import com.tesco.services.adapters.core.ImportFutureOfferDescJob;
import com.tesco.services.adapters.core.ImportJob;
import com.tesco.services.adapters.core.ImportPriceJob;

@RunWith(MockitoJUnitRunner.class)
public class ImportResourceTest {

	private static Configuration testConfiguration = TestConfiguration.load();

	private static Import mockImportJob = Mockito.mock(ImportJob.class);

	private static Import importFutureOfferDescJob = Mockito
			.mock(ImportFutureOfferDescJob.class);

	private static Import importPriceJob = Mockito.mock(ImportPriceJob.class);

	@Before
	public void setUpResources() throws Exception {

		Mockito.doNothing().when(mockImportJob).run();
		Mockito.doNothing().when(mockImportJob).run();

		ImportResource.getImportSemaphore().release();
	}

	@ClassRule
	public static final ResourceTestRule resources = ResourceTestRule
			.builder()
			.addResource(
					new ImportResource(testConfiguration, mockImportJob, null,
							null, null, null, importPriceJob, null, null, null,
							importFutureOfferDescJob, null)).build();

	@Test
	public void shouldStartImportScript() throws IOException {
		WebTarget resource = resources.client().target("/admin/import");
		Response response = resource.request()
				.accept(MediaType.APPLICATION_JSON)
				.post(Entity.entity("", MediaType.APPLICATION_JSON));
		String responseText = response.readEntity(String.class);

		assertThat(responseText).isEqualTo("{\"message\":\"Import Started.\"}");
		assertThat(response.getStatus()).isEqualTo(200);
	}

	@Test
	public void shouldStartPriceImport() throws IOException {
		ImportResource.getImportSemaphoreForIdentifier().put(
				"tsl_onetimeprice.dat", new Semaphore(1));
		WebTarget resource = resources.client().target(
				"/admin/importPrice/onetimeprice/tsl_onetimeprice.dat");
		Response response = resource.request()
				.accept(MediaType.APPLICATION_JSON)
				.post(Entity.entity("", MediaType.APPLICATION_JSON));
		String responseText = response.readEntity(String.class);
		System.out.println(responseText);
		assertThat(responseText).isEqualTo(
				"{\"message\":\"Import Price Onetime load Job Started.\"}");
		assertThat(response.getStatus()).isEqualTo(200);
	}

	@Test
	public void shouldStartPriceImportInvalidRunidentifier() throws IOException {
		WebTarget resource = resources.client().target(
				"/admin/importPrice/onetime/tsl_onetimeprice.dat");
		Response response = resource.request()
				.accept(MediaType.APPLICATION_JSON)
				.post(Entity.entity("", MediaType.APPLICATION_JSON));
		String responseText = response.readEntity(String.class);

		assertThat(responseText).isEqualTo(
				"{\"error\":\"Invalid Run Identifier\"}");
		assertThat(response.getStatus()).isEqualTo(400);
	}

	@Test
	public void shouldStartPriceImportImportalreadyRunning() throws IOException {
		ImportResource.getImportSemaphoreForIdentifier().put(
				"tsl_onetimeprice.dat", new Semaphore(0));
		WebTarget resource = resources.client().target(
				"/admin/importPrice/onetimeprice/tsl_onetimeprice.dat");
		Response response = resource.request()
				.accept(MediaType.APPLICATION_JSON)
				.post(Entity.entity("", MediaType.APPLICATION_JSON));
		String responseText = response.readEntity(String.class);

		assertThat(responseText).isEqualTo(
				"{\"message\":\"There is already an import in progress.\"}");
		assertThat(response.getStatus()).isEqualTo(409);
	}

	// salman
	@Test
	public void shouldStartFutureOfferDesc() throws IOException {
		ImportResource.getImportSemaphoreForIdentifier().put(
				"FutureOfferDesc.csv", new Semaphore(1));
		WebTarget resource = resources
				.client()
				.target("/admin/importFutureOfferDesc/futureOfferDesc/FutureOfferDesc.csv");
		Response response = resource.request()
				.accept(MediaType.APPLICATION_JSON)
				.post(Entity.entity("", MediaType.APPLICATION_JSON));
		String responseText = response.readEntity(String.class);
		System.out.println(responseText);
		assertThat(responseText)
				.isEqualTo(
						"{\"message\":\"Import future offer description load Job Started.\"}");
		assertThat(response.getStatus()).isEqualTo(200);
	}

	@Test
	public void shouldStartFutureOfferDescImportInvalidRunidentifier()
			throws IOException {
		WebTarget resource = resources.client().target(
				"/admin/importFutureOfferDesc/future/FutureOfferDesc.csv");
		Response response = resource.request()
				.accept(MediaType.APPLICATION_JSON)
				.post(Entity.entity("", MediaType.APPLICATION_JSON));
		String responseText = response.readEntity(String.class);

		assertThat(responseText).isEqualTo(
				"{\"error\":\"Invalid Run Identifier\"}");
		assertThat(response.getStatus()).isEqualTo(400);
	}

	@Test
	public void shouldStartFutureOfferDescImportImportalreadyRunning()
			throws IOException {
		ImportResource.getImportSemaphoreForIdentifier().put(
				"FutureOfferDesc.csv", new Semaphore(0));
		WebTarget resource = resources.client().target(
				"/admin/importFutureOfferDesc/future/FutureOfferDesc.csv");
		Response response = resource.request()
				.accept(MediaType.APPLICATION_JSON)
				.post(Entity.entity("", MediaType.APPLICATION_JSON));
		String responseText = response.readEntity(String.class);

		assertThat(responseText).isEqualTo(
				"{\"message\":\"There is already an import in progress.\"}");
		assertThat(response.getStatus()).isEqualTo(409);
	}

	@Test
	public void shouldStartimportRPMZoneGroupreadyRunning() throws IOException {
		ImportResource.getImportSemaphoreForIdentifier().put(
				"tsl_ps_zonegroup_onetime_20151015.csv", new Semaphore(0));
		WebTarget resource = resources
				.client()
				.target("/admin/importRPMZoneGroup/rpmzonegrouponetime/tsl_ps_zonegroup_onetime_20151015.csv");
		Response response = resource.request()
				.accept(MediaType.APPLICATION_JSON)
				.post(Entity.entity("", MediaType.APPLICATION_JSON));

		String responseText = response.readEntity(String.class);

		assertThat(responseText).isEqualTo(
				"{\"message\":\"There is already an import in progress.\"}");
		assertThat(response.getStatus()).isEqualTo(409);
	}

	@Test
	public void shouldStartimportItemDefaultMappingreadyRunning()
			throws IOException {
		ImportResource.getImportSemaphoreForIdentifier().put(
				"item_dflt_uom_20160413.dat", new Semaphore(0));
		WebTarget resource = resources
				.client()
				.target("/admin/importItemDefaultUom/ItemDefaultUom/item_dflt_uom_20160413.dat");
		Response response = resource.request()
				.accept(MediaType.APPLICATION_JSON)
				.post(Entity.entity("", MediaType.APPLICATION_JSON));
		String responseText = response.readEntity(String.class);

		assertThat(responseText).isEqualTo(
				"{\"message\":\"There is already an import in progress.\"}");
		assertThat(response.getStatus()).isEqualTo(409);
	}

	@Test
	public void shouldStartimportEstablishedPricereadyRunning()
			throws IOException {
		ImportResource.getImportSemaphoreForIdentifier().put(
				"tsl_ps_estd_price_regular_1_20151212.csv", new Semaphore(0));
		WebTarget resource = resources
				.client()
				.target("/admin/importEstablishedPrice/estdprice/tsl_ps_estd_price_regular_1_20151212.csv");
		Response response = resource.request()
				.accept(MediaType.APPLICATION_JSON)
				.post(Entity.entity("", MediaType.APPLICATION_JSON));

		String responseText = response.readEntity(String.class);

		assertThat(responseText).isEqualTo(
				"{\"message\":\"There is already an import in progress.\"}");
		assertThat(response.getStatus()).isEqualTo(409);
	}

	@Test
	public void shouldStartimportRPMZonereadyRunning() throws IOException {
		ImportResource.getImportSemaphoreForIdentifier().put(
				"tsl_ps_zone_onetime_20151212.csv", new Semaphore(0));
		WebTarget resource = resources
				.client()
				.target("/admin/importRPMZone/rpmzoneonetime/tsl_ps_zone_onetime_20151212.csv");
		Response response = resource.request()
				.accept(MediaType.APPLICATION_JSON)
				.post(Entity.entity("", MediaType.APPLICATION_JSON));
		String responseText = response.readEntity(String.class);

		assertThat(responseText).isEqualTo(
				"{\"message\":\"There is already an import in progress.\"}");
		assertThat(response.getStatus()).isEqualTo(409);
	}

	@Test
	public void shouldStartimportRPMClearanceDatareadyRunning()
			throws IOException {
		ImportResource.getImportSemaphoreForIdentifier().put("regranged",
				new Semaphore(0));
		WebTarget resource = resources.client().target(
				"/admin/importRPMClearance/regranged");
		Response response = resource.request()
				.accept(MediaType.APPLICATION_JSON)
				.post(Entity.entity("", MediaType.APPLICATION_JSON));

		String responseText = response.readEntity(String.class);

		assertThat(responseText).isEqualTo(
				"{\"message\":\"There is already an import in progress.\"}");
		assertThat(response.getStatus()).isEqualTo(409);
	}

	@Test
	public void shouldStartimportMMClrDatareadyRunning() throws IOException {
		ImportResource.getImportSemaphoreForIdentifier().put("mmreg",
				new Semaphore(0));
		WebTarget resource = resources.client().target(
				"/admin/importMMClrData/mmreg");
		Response response = resource.request()
				.accept(MediaType.APPLICATION_JSON)
				.post(Entity.entity("", MediaType.APPLICATION_JSON));

		String responseText = response.readEntity(String.class);

		assertThat(responseText).isEqualTo(
				"{\"message\":\"There is already an import in progress.\"}");
		assertThat(response.getStatus()).isEqualTo(409);
	}

	@After
	public void resetMocks() throws Exception {
		Mockito.reset(mockImportJob);
	}

}
