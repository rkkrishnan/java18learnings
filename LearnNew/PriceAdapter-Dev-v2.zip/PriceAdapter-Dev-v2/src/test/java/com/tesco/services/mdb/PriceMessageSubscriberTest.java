package com.tesco.services.mdb;

import static io.dropwizard.testing.FixtureHelpers.fixture;

import javax.jms.JMSException;
import javax.jms.TextMessage;
import javax.jms.TopicSession;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.tesco.services.Configuration;
import com.tesco.services.adapters.rpm.readers.MessageRouter;
import com.tesco.services.exceptions.MessageRouterException;
import com.tesco.services.exceptions.PromoBusinessException;

/**
 * Created by qp65 on 9/8/2015.
 */

@RunWith(MockitoJUnitRunner.class)
public class PriceMessageSubscriberTest {

	private PriceMessageSubscriber priceMessageSubscriber;
	private String xmlData;

	@Mock
	private TextMessage message;

	@Mock
	private Configuration configuration;

	@Mock
	private MessageRouter promotionMessageRouter;

	@Before
	public void setUp() throws Exception {
		xmlData = fixture("com/tesco/services/core/fixtures/price/PriceCreMsgOrig.xml");
		Mockito.when(configuration.getRejectFilePath()).thenReturn("dummypath");

		TopicSession topicSession = Mockito.mock(TopicSession.class);
		priceMessageSubscriber = new PriceMessageSubscriber();
		priceMessageSubscriber.setPriceMessageRouter(promotionMessageRouter);
		priceMessageSubscriber.setConfiguration(configuration);
		priceMessageSubscriber.setTopicSession(topicSession);
		priceMessageSubscriber.setRetryCount(1);
		Mockito.doNothing().when(promotionMessageRouter)
				.route(Mockito.anyString());
		Mockito.doNothing().when(topicSession).commit();
		Mockito.doNothing().when(topicSession).rollback();
	}

	@Test
	public void testOnMessage() throws JMSException, PromoBusinessException {
		Mockito.when(message.getText()).thenReturn(xmlData);
		priceMessageSubscriber.onMessage(message);
	}

	@Test
	public void testOnMessageException() throws JMSException,
			MessageRouterException {
		Mockito.doThrow(new MessageRouterException("Mesage Router Exception"))
				.when(promotionMessageRouter).route(Mockito.anyString());
		priceMessageSubscriber.onMessage(message);
		priceMessageSubscriber.onMessage(message);
		Mockito.doThrow(new JMSException("JMS Exception")).when(message)
				.getText();
		priceMessageSubscriber.onMessage(message);
	}
}
