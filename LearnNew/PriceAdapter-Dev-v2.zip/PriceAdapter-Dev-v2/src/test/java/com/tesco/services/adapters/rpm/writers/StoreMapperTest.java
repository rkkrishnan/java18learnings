package com.tesco.services.adapters.rpm.writers;

import com.tesco.services.adapters.rpm.writers.impl.StoreMapper;
import com.tesco.services.core.Store;
import com.tesco.services.exceptions.DataAccessException;
import com.tesco.services.repositories.RepositoryImpl;
import com.tesco.services.utility.PriceConstants;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Map;

import static org.fest.assertions.api.Assertions.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class StoreMapperTest {


	@Mock
	RepositoryImpl mockRepositoryImpl;

	StoreMapper storeMapper;

	@Before
	public void setUp() throws Exception {
		storeMapper = new StoreMapper(mockRepositoryImpl);
	}

	@After
	public void tearDown() throws Exception {
		Mockito.reset(mockRepositoryImpl);
	}

	@Test
	public void testMap() throws DataAccessException {
		Store testStore = new Store("12345", "GBP","GB");

		@SuppressWarnings("unchecked")
		Map<String, String> storeInfoMap = Mockito.mock(Map.class);

		Mockito.doReturn("12345").when(storeInfoMap)
				.get(CSVHeaders.StoreZone.STORE_ID);

		Mockito.doReturn(testStore).when(mockRepositoryImpl)
				.getGenericObject(PriceConstants.STORE_KEY + "12345",
						Store.class);

		Mockito.doReturn("00001").when(storeInfoMap)
				.get(CSVHeaders.StoreZone.ZONE_ID);

		Mockito.doReturn("00002").when(storeInfoMap)
				.get(CSVHeaders.StoreZone.ZONE_TYPE);

		assertThat(storeMapper.map(storeInfoMap)).isEqualTo(testStore);

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testMapStore() throws DataAccessException {
		Store testStore = new Store("12345", "GBP","GB");

		Map<String, String> storeInfoMap = Mockito.mock(Map.class);

		Mockito.doReturn("12345").when(storeInfoMap)
				.get(CSVHeaders.StoreZone.STORE_ID);

		Mockito.doReturn(testStore)
				.when(mockRepositoryImpl)
				.getGenericObject(org.mockito.Matchers.any(String.class),
						(Class<Store>) org.mockito.Matchers.any());


		Mockito.doReturn("00001").when(storeInfoMap)
				.get(CSVHeaders.StoreZone.ZONE_ID);

		Mockito.doReturn("00002").when(storeInfoMap)
				.get(CSVHeaders.StoreZone.ZONE_TYPE);

		assertThat(storeMapper.mapStore(storeInfoMap)).isEqualTo(testStore);

//		Mockito.doReturn(null).when(mockProductRepository).getStoreIdentified();

		Mockito.doReturn("GBP").when(storeInfoMap)
				.get(CSVHeaders.StoreZone.CURRENCY_CODE);

		Mockito.doReturn("00001").when(storeInfoMap)
				.get(CSVHeaders.StoreZone.ZONE_ID);

		Mockito.doReturn("0002").when(storeInfoMap)
				.get(CSVHeaders.StoreZone.ZONE_TYPE);

		assertThat(storeMapper.mapStore(storeInfoMap)).isEqualTo(testStore);

	}

}
