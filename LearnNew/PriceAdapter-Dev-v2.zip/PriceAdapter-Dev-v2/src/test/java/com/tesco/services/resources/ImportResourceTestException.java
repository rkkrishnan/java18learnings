package com.tesco.services.resources;

import com.tesco.couchbase.AsyncCouchbaseWrapper;
import com.tesco.couchbase.CouchbaseWrapper;
import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.Import;
import com.tesco.services.adapters.core.ImportJob;
import io.dropwizard.configuration.ConfigurationException;
import io.dropwizard.testing.junit.ResourceTestRule;
import org.junit.After;
import org.junit.ClassRule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import static org.fest.assertions.api.Assertions.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class ImportResourceTestException {


	private static Configuration mockConfiguration = Mockito.mock(TestConfiguration.class);

	private static Import importJob = Mockito.mock(ImportJob.class);


	@ClassRule
	public static final ResourceTestRule resources = ResourceTestRule.builder()
			.addResource(
					new ImportResource(mockConfiguration, importJob, null, null,
							null, null, null, null, null, null, null, null))
			.build();

	@Test
	public void shouldImportThrowException() throws Exception {
		WebTarget resource = resources.client().target("/admin/import");
		Mockito.when(mockConfiguration.getRPMStoreDataPath()).thenThrow(Mockito.mock(ConfigurationException.class));
		Response response =  resource.request().accept(MediaType.APPLICATION_JSON).post(Entity.entity("", MediaType.APPLICATION_JSON));
		assertThat(response.getStatus()).isEqualTo(500);
	}

	@After
	public void resetMocks() throws Exception {
		Mockito.reset(mockConfiguration);
	}
}
