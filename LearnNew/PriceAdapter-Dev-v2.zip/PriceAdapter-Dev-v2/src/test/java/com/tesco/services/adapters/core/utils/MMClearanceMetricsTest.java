package com.tesco.services.adapters.core.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.codahale.metrics.Counter;
import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.Timer;

public class MMClearanceMetricsTest {

	static MMClearanceMetrics mmClearanceMetrics = MMClearanceMetrics
			.getInstance();
	static MetricRegistry mmetricRegisty = MMClearanceMetrics
			.getMetricsRegistry();
	Map metricsMap = null;

	// MetricName name = null;

	@Before
	public void setUp() throws Exception {
		mmetricRegisty = MMClearanceMetrics.getMetricsRegistry();
	}

	@After
	public void tearDown() throws Exception {

	}

	@Test
	public void logMessageProcessingStartTime() throws Exception {
		String name = MetricRegistry.name("com.tesco",
				"MMClearanceElapsedTimeAndRate", "time-to-process-message");

		metricsMap = mmetricRegisty.getTimers();

		mmClearanceMetrics.logMessageProcessingStartTime();
		mmClearanceMetrics.logMessageProcessingEndTime();

		assertNotEquals(0, ((Timer) metricsMap.get(name)).getCount());
	}

	@Test
	public void logCreClearanceProcessingStartTime() throws Exception {
		String name = MetricRegistry.name("com.tesco",
				"MMClearanceElapsedTimeAndRate", "time-to-process-cre-message");

		metricsMap = mmetricRegisty.getTimers();

		mmClearanceMetrics.logCreClearanceProcessingStartTime();
		mmClearanceMetrics.logCreClearanceProcessingEndTime();

		assertNotEquals(0, ((Timer) metricsMap.get(name)).getCount());
	}

	@Test
	public void logModClearanceProcessingStartTime() throws Exception {
		String name = MetricRegistry.name("com.tesco",
				"MMClearanceElapsedTimeAndRate", "time-to-process-mod-message");
		metricsMap = mmetricRegisty.getTimers();

		mmClearanceMetrics.logModClearanceProcessingStartTime();
		mmClearanceMetrics.logModClearanceProcessingEndTime();

		assertNotEquals(0, ((Timer) metricsMap.get(name)).getCount());
	}

	@Test
	public void logDelClearanceProcessingStartTime() throws Exception {

		String name = MetricRegistry.name("com.tesco",
				"MMClearanceElapsedTimeAndRate", "time-to-process-del-message");
		metricsMap = mmetricRegisty.getTimers();

		mmClearanceMetrics.logDelClearanceProcessingStartTime();
		mmClearanceMetrics.logDelClearanceProcessingEndTime();

		assertNotEquals(0, ((Timer) metricsMap.get(name)).getCount());
	}

	@Test
	public void incrementErrorCount() throws Exception {
		String name = MetricRegistry.name("com.tesco",
				"MMClearanceMessageProcessingErrors", "total-error-count");
		metricsMap = mmetricRegisty.getCounters();
		mmClearanceMetrics.incrementErrorCount();
		assertEquals(1, ((Counter) metricsMap.get(name)).getCount());
	}

	@Test
	public void resetCounters() throws Exception {
		String name = MetricRegistry.name("com.tesco",
				"MMClearanceMessageProcessingErrors", "total-error-count");
		mmClearanceMetrics.incrementErrorCount();
		metricsMap = mmClearanceMetrics.getMetricsRegistry().getCounters();
		assertEquals(1, ((Counter) metricsMap.get(name)).getCount());
		mmClearanceMetrics.resetCounters();
		metricsMap = mmClearanceMetrics.getMetricsRegistry().getCounters();
		assertEquals(0, ((Counter) metricsMap.get(name)).getCount());
	}

}
