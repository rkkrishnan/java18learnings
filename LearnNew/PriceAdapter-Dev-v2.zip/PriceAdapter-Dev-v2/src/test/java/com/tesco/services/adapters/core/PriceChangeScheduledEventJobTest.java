package com.tesco.services.adapters.core;

import static com.tesco.services.utility.PriceConstants.LOC_REF;
import static com.tesco.services.utility.PriceConstants.PRICE_REF;
import static com.tesco.services.utility.PriceConstants.PRODUCT_REF;
import static com.tesco.services.utility.PriceConstants.PROD_TYPE;
import static com.tesco.services.utility.PriceConstants.TPNC_IDENTIFIER;
import static io.dropwizard.testing.FixtureHelpers.fixture;
import static org.joda.time.DateTimeUtils.setCurrentMillisSystem;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.Response;
import javax.xml.bind.JAXBException;

import org.codehaus.jettison.json.JSONException;
import org.joda.time.DateTimeUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tesco.services.Configuration;
import com.tesco.services.CouchbaseViewConfig;
import com.tesco.services.adapters.core.exceptions.PriceEventException;
import com.tesco.services.adapters.price.PriceEventHandler;
import com.tesco.services.adapters.rpm.writers.impl.PriceWriter;
import com.tesco.services.core.ZoneEntity;
import com.tesco.services.event.core.EventTemplate;
import com.tesco.services.event.exception.EventPublishException;
import com.tesco.services.exceptions.DataAccessException;
import com.tesco.services.repositories.RepositoryImpl;
import com.tesco.services.repositories.views.WebViewTemplate;

@RunWith(MockitoJUnitRunner.class)
public class PriceChangeScheduledEventJobTest {

	@Mock
	private Configuration configuration;
	@Mock
	private RepositoryImpl repositoryImpl;
	@Mock
	private EventTemplate eventTemplate;
	@Mock
	private PriceWriter priceWriter;
	@Mock
	private PriceEventHandler priceEventHandler;
	@Mock
	WebViewTemplate mockWebViewTemplate;

	@Captor
	private ArgumentCaptor<Map<String, String>> argumentCaptor;

	private String priceEntityMultipleRecord = null;
	private ObjectMapper mapper = new ObjectMapper();
	private PriceChangeScheduledEventJob priceChangeScheduledEventJob = null;
	final static private String ZONE_ID_3 = "3";
	final static private String ZONE_ID_5 = "5";
	final static private String ZONE_GROUP_ID = "90";
	final static private String ZONE_ZONENAME = "testZone";
	final static private String COUNTRY_CODE = "IE";

	@Before
	public void setUp() throws IOException, DataAccessException {
		priceEntityMultipleRecord = fixture("com/tesco/services/core/fixtures/price/SCHEDULED_REGPRICE_MULTIPLE_RECORD.json");
		// when(configuration.getPriceChangeViewName()).thenReturn("pricetest2");
		CouchbaseViewConfig mockViewConfig = Mockito
				.mock(CouchbaseViewConfig.class);

		Map<String, String> viewQueryParams = new HashMap<String, String>();
		viewQueryParams.put("stale.state", "false");
		viewQueryParams.put("page.size", "2");
		viewQueryParams.put("timeout.interval", "60000");

		Map<String, String> viewQueryAddlParams = new HashMap<String, String>();
		viewQueryAddlParams.put("offset", "+00:00");
		viewQueryAddlParams.put("effectiveday", "1");

		Mockito.when(mockViewConfig.getViewQueryParams()).thenReturn(
				viewQueryParams);

		Mockito.when(mockViewConfig.getViewAdditionalProperties()).thenReturn(
				viewQueryAddlParams);

		Map<String, CouchbaseViewConfig> priceChangeViewConfig = new HashMap<String, CouchbaseViewConfig>();
		priceChangeViewConfig.put("PriceChange", mockViewConfig);

		Mockito.when(configuration.getCouchbaseViewConfig()).thenReturn(
				priceChangeViewConfig);

		priceChangeScheduledEventJob = new PriceChangeScheduledEventJob(
				configuration, mapper, priceEventHandler, mockWebViewTemplate);

		ZoneEntity zoneUK = new ZoneEntity();
		zoneUK.setZoneId(ZONE_ID_3);
		zoneUK.setZoneGroupId(ZONE_GROUP_ID);
		zoneUK.setZoneName(ZONE_ZONENAME);
		zoneUK.setTslCountryCode(COUNTRY_CODE);
		when(repositoryImpl.getGenericObject("ZONE_3", ZoneEntity.class))
				.thenReturn(zoneUK);
		ZoneEntity zoneGB = new ZoneEntity();
		zoneGB.setZoneId(ZONE_ID_5);
		zoneGB.setZoneGroupId(ZONE_GROUP_ID);
		zoneGB.setZoneName(ZONE_ZONENAME);
		zoneGB.setTslCountryCode("GB");

		when(repositoryImpl.getGenericObject("ZONE_5", ZoneEntity.class))
				.thenReturn(zoneGB);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void shouldTriggerRegularPriceChngCreateEventForEffectiveDateTomorrow()
			throws PriceEventException, IOException, EventPublishException,
			JAXBException, ParseException, JSONException, DataAccessException {

		String priceEntityString = fixture("com/tesco/services/core/fixtures/price/SCHEDULED_REGPRICE_Z.json");

		Response webViewResponse = Mockito.mock(Response.class);

		Mockito.when(webViewResponse.readEntity(String.class))
				.thenReturn(priceEntityString).thenReturn(null);

		mockWebViewTemplate = Mockito.mock(WebViewTemplate.class);
		DateTimeUtils.setCurrentMillisFixed(1464505782847l);

		Mockito.when(
				mockWebViewTemplate.queryView(Matchers.anyMap(),
						Matchers.anyMap())).thenReturn(webViewResponse);

		priceChangeScheduledEventJob = new PriceChangeScheduledEventJob(
				configuration, mapper, priceEventHandler, mockWebViewTemplate);

		priceChangeScheduledEventJob.processScheduledEvents();

		verify(priceEventHandler, times(1)).processScheduledEvent(
				argumentCaptor.capture());
		assertEquals("40686693", (argumentCaptor.getValue()).get(PRICE_REF));
		assertEquals("2", (argumentCaptor.getValue()).get(LOC_REF));
		assertEquals("071075851", (argumentCaptor.getValue()).get(PRODUCT_REF));
		assertEquals("272166306",
				(argumentCaptor.getValue()).get(TPNC_IDENTIFIER));
		assertEquals("tpnb", (argumentCaptor.getValue()).get(PROD_TYPE));

	}

	@Test
	public void shouldTriggerMultipleRegularPriceChngCreateEventForEffectiveDateTomorrow()
			throws PriceEventException, IOException, EventPublishException,
			JAXBException, ParseException, JSONException, DataAccessException {
		DateTimeUtils.setCurrentMillisFixed(1464505782847l);

		Response webViewResponse = Mockito.mock(Response.class);

		Mockito.when(webViewResponse.readEntity(String.class))
				.thenReturn(priceEntityMultipleRecord).thenReturn(null);

		mockWebViewTemplate = Mockito.mock(WebViewTemplate.class);
		DateTimeUtils.setCurrentMillisFixed(1464505782847l);

		Mockito.when(
				mockWebViewTemplate.queryView(Matchers.anyMap(),
						Matchers.anyMap())).thenReturn(webViewResponse);

		priceChangeScheduledEventJob = new PriceChangeScheduledEventJob(
				configuration, mapper, priceEventHandler, mockWebViewTemplate);

		priceChangeScheduledEventJob.processScheduledEvents();

		List<Map<String, String>> captorData = argumentCaptor.getAllValues();
		verify(priceEventHandler, times(2)).processScheduledEvent(
				argumentCaptor.capture());
		assertEquals("40686693", (captorData.get(0)).get(PRICE_REF));
		assertEquals("2", (captorData.get(0)).get(LOC_REF));
		assertEquals("071075851", (captorData.get(0)).get(PRODUCT_REF));
		assertEquals("272166306", (captorData.get(0)).get(TPNC_IDENTIFIER));
		assertEquals("tpnb", (captorData.get(0)).get(PROD_TYPE));

		assertEquals("45678765", (captorData.get(1)).get(PRICE_REF));
		assertEquals("3", (captorData.get(1)).get(LOC_REF));
		assertEquals("050000016", (captorData.get(1)).get(PRODUCT_REF));
		assertEquals("270693174", (captorData.get(1)).get(TPNC_IDENTIFIER));
		assertEquals("tpnb", (captorData.get(1)).get(PROD_TYPE));

	}

	@After
	public void tearDown() {
		setCurrentMillisSystem();
	}

}
