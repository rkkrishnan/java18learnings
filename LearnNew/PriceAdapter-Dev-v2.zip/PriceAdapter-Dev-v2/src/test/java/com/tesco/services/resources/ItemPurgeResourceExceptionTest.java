package com.tesco.services.resources;

import com.couchbase.client.CouchbaseClient;
import com.tesco.services.Configuration;
import com.tesco.services.repositories.RepositoryImpl;
import io.dropwizard.testing.junit.ResourceTestRule;
import org.junit.After;
import org.junit.Before;
import org.junit.ClassRule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.IOException;

import static org.fest.assertions.api.Assertions.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class ItemPurgeResourceExceptionTest {

	private static Configuration mockConfiguration = Mockito.mock(Configuration.class);

	private static CouchbaseClient couchbaseClient = Mockito.mock(CouchbaseClient.class);

	private static RepositoryImpl repositoryImpl = Mockito.mock(RepositoryImpl.class);

	@ClassRule
	public static final ResourceTestRule resources = ResourceTestRule
			.builder().addResource(
					new ItemPurgeResource(mockConfiguration, couchbaseClient,
							repositoryImpl)).build();

	@Before
	public void setUpResources() throws Exception {
		Mockito.doThrow(new Exception()).when(repositoryImpl)
				.purgeUnUpdatedItems(couchbaseClient, mockConfiguration);
	}

	@Test
	public void shouldPurgeThrowException() throws IOException {
		WebTarget resource = resources.client().target("/itempurge/purge");
		Response response = resource.request()
				.accept(MediaType.APPLICATION_JSON)
				.post(Entity.entity("", MediaType.APPLICATION_JSON));
		String responseText = response.readEntity(String.class);
		assertThat(responseText)
				.isEqualTo("{\"error\":\"Item purge failed due to error\"}");
	}
	
	
	@Test
	public void shouldReturnBadRequest() throws IOException {
		WebTarget resource = resources.client().target("/itempurge/");
		Response response = resource.request()
				.accept(MediaType.APPLICATION_JSON)
				.post(Entity.entity("", MediaType.APPLICATION_JSON));
		assertThat(response.getStatus()).isEqualTo(400);
	}

	@After
	public void resetMocks() throws Exception {
		Mockito.reset(mockConfiguration);
		Mockito.reset(couchbaseClient);
		Mockito.reset(repositoryImpl);
	}
}
