package com.tesco.services.adapters.promotion;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tesco.promotion.core.PrmPrcChgDesc;
import com.tesco.services.adapters.core.exceptions.PromotionEventException;
import com.tesco.services.adapters.promotion.impl.PromotionEventHandlerImpl;
import com.tesco.services.core.ZoneEntity;
import com.tesco.services.event.core.EventTemplate;
import com.tesco.services.event.core.impl.MapEvent;
import com.tesco.services.event.exception.EventPublishException;
import com.tesco.services.exceptions.DataAccessException;
import com.tesco.services.repositories.RepositoryImpl;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.ParseMessageUtil;
import com.tesco.services.utility.PriceConstants;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import static com.tesco.services.utility.PriceConstants.*;
import static io.dropwizard.testing.FixtureHelpers.fixture;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class ThresholdPromotionEventCreationTest {

	PrmPrcChgDesc promotions;

	@Mock
	private EventTemplate eventTemplate;

	private PromotionEventHandler promoEventHandler;

	@Mock
	private RepositoryImpl repositoryImpl;

	@Captor
	private ArgumentCaptor<MapEvent> argument;

	@Mock
	private ObjectMapper mapper;

	@Before
	public void setUp() throws Exception {

		promoEventHandler = new PromotionEventHandlerImpl(eventTemplate,
				repositoryImpl);
		// DateTimeUtils.setCurrentMillisFixed(Long.valueOf("1459881000000").longValue());
		String xmlData = fixture("com/tesco/services/core/fixtures/promotion/ThresholdPromoEventCre.xml");
		ParseMessageUtil parseMessageUtil = ParseMessageUtil.getInstance();

		String promoDescData = parseMessageUtil.getNodeData(xmlData,
				PriceConstants.PROMO_MSG_DATA_PATH);
		promotions = (PrmPrcChgDesc) parseMessageUtil
				.getMappedObjectForXmlData(PrmPrcChgDesc.class, promoDescData);

		ZoneEntity ze = new ZoneEntity();
		ze.setZoneId("5");
		ze.setTslCountryCode("GB");
		ze.setZoneGroupId("90");
		ze.setZoneName("testZone");
		Mockito.when(repositoryImpl.getGenericObject("ZONE_5",
				ZoneEntity.class)).thenReturn(ze);
	}

	@Test
	public void testEventCreatedForThresholdPromotion()
			throws PromotionEventException, ParseException,
			EventPublishException {

		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 5);
		String eff_date = dateFormat.format(cal.getTime());
		String effective_date = Dockyard.getISO8601FormatStartDate(eff_date);

		Map<String, String> eventDataMap = prepareEventDataMap(effective_date);
		promoEventHandler.publishPromotionEvent(eventDataMap);
		Mockito.verify(eventTemplate, Mockito.times(1)).publishEvent(
				argument.capture());
		assertEquals(
				PriceConstants.PROMOTION_MSG_TYPE_CRE,
				String.valueOf((argument.getValue()).getHeaderData().get(
						"EventType")));
		assertEquals(
				5,
				Integer.valueOf(
						(argument.getValue()).getHeaderData().get(
								"LeadTimeDays")).intValue());
		assertEquals(
				"GB:Z:5",
				(argument.getValue()).getHeaderData().get(
						PriceConstants.LOCATION_ID));
		assertEquals(
				"1550913",
				(argument.getValue()).getPayloadData().get(
						PriceConstants.OFFER_ID));

	}

	@Test
	public void shouldTriggerPromotionStartScheduledEventForEffectiveDateTomorrow()
			throws PromotionEventException, IOException, EventPublishException,
			JAXBException, ParseException, DataAccessException {

		String promotionStartEntityString = fixture("com/tesco/services/core/fixtures/promotion/SCHEDULED_PROMOTION_SINGLE.json");
		when(mapper.readValue(promotionStartEntityString, Map.class))
				.thenReturn(getMapData(SCHEDULED_PROMOTION_START_EVENT_TYPE));
		ZoneEntity zone = new ZoneEntity();
		zone.setTslCountryCode(TSL_COUNTRY_GB);
		when(repositoryImpl.getGenericObject("ZONE_15", ZoneEntity.class)).thenReturn(zone);
		promoEventHandler
				.publishPromotionEvent(getMapData(SCHEDULED_PROMOTION_START_EVENT_TYPE));
		verify(eventTemplate, times(1)).publishEvent(argument.capture());
		assertEquals("GB:Z:15",
				(argument.getValue()).getHeaderData().get(LOCATION_ID));
		assertEquals(SCHEDULED_PROMOTION_START_EVENT_TYPE,
				(argument.getValue()).getEventType());
		assertEquals(SCHEDULED_EVENT_LEAD_DAY, (argument.getValue())
				.getHeaderData().get(LEAD_TIME_DAYS));
		assertEquals("31918284",
				(argument.getValue()).getPayloadData().get(OFFER_ID));
	}

	@Test
	public void shouldTriggerPromotionEndScheduledEventForEffectiveDateToday()
			throws PromotionEventException, IOException, EventPublishException,
			JAXBException, ParseException, DataAccessException {

		String promotionEndEntityString = fixture("com/tesco/services/core/fixtures/promotion/SCHEDULED_PROMOTION_SINGLE.json");
		when(mapper.readValue(promotionEndEntityString, Map.class)).thenReturn(
				getMapData(SCHEDULED_PROMOTION_END_EVENT_TYPE));
		ZoneEntity zone = new ZoneEntity();
		zone.setTslCountryCode(TSL_COUNTRY_GB);
		when(repositoryImpl.getGenericObject("ZONE_15", ZoneEntity.class)).thenReturn(zone);
		promoEventHandler
				.publishPromotionEvent(getMapData(SCHEDULED_PROMOTION_END_EVENT_TYPE));
		verify(eventTemplate, times(1)).publishEvent(argument.capture());
		assertEquals("GB:Z:15",
				(argument.getValue()).getHeaderData().get(LOCATION_ID));
		assertEquals(SCHEDULED_PROMOTION_END_EVENT_TYPE,
				(argument.getValue()).getEventType());
		assertEquals(SCHEDULED_EVENT_LEAD_DAY, (argument.getValue())
				.getHeaderData().get(LEAD_TIME_DAYS));
		assertEquals("31918284",
				(argument.getValue()).getPayloadData().get(OFFER_ID));
	}

	private Map<String, String> getMapData(String eventType) {
		Map<String, String> mockMapData = new HashMap<String, String>();
		mockMapData.put(LOC_REF, "15");
		mockMapData.put(LOC_TYPE, "Z");
		mockMapData.put(OFFER_ID, "31918284");
		mockMapData.put(EVENT_TYPE, eventType);
		mockMapData.put(LEAD_TIME_DAYS, "1");
		return mockMapData;

	}

	private Map<String, String> prepareEventDataMap(String effectiveDate) {
		Map<String, String> promotionEventDataMap = new HashMap<>();

		promotionEventDataMap.put(LOC_REF, "5");
		promotionEventDataMap.put(LOC_TYPE, "Z");
		promotionEventDataMap.put(OFFER_ID, "1550913");
		promotionEventDataMap.put(EFFECTIVE_DATE, effectiveDate);
		promotionEventDataMap.put(EVENT_TYPE, PROMOTION_MSG_TYPE_CRE);
		return promotionEventDataMap;
	}
}
