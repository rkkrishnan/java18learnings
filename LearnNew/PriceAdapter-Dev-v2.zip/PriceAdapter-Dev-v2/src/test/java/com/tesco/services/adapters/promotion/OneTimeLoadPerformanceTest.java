package com.tesco.services.adapters.promotion;

import static io.dropwizard.testing.FixtureHelpers.fixture;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tesco.services.core.promotion.PromoItemEntity;
import com.tesco.services.core.promotion.PromoItemListEntity;
import com.tesco.services.core.promotion.PromotionEntity;
import com.tesco.services.utility.Dockyard;

/**
 * Created by yp21 on 14/07/2015.
 */
public class OneTimeLoadPerformanceTest {
	private Dockyard dockyard;
	private Random randomGenerator;
	private Set<PromotionEntity> promotionSet;

	List<String> itemLists = Arrays.asList("050000097","050000158","050000304","050000348","050000356","050000379","050000385","050000402","050000425","050000431","050000454","050000460","050000477","050000483","050000517","050000523","050000644","050000650","050000667","050000696","050000771","050000811","050000834","050000863","050000886","050000903","050001050","050001390","050001424","050001430","050001447","050001453","050001476","050001551","050001574","050001580","050001597","050001758","050001758","050001793","050001804","050001810","050001827","050001833","050001856","050001885","050001902","050001919","050001954","050002008","050002037","050002233","050002302","050002383","050002423","050002452","050002803","050002982","050002999","050003094","050003111","050003178","050003284","050003946","050003981","050004029","050004070","050004087","050004185","050004191","050004277","050004415","050004438","050004444","050004450","050004513","050004536","050004542","050004565","050004594","050004611","050004628","050004761","050004778","050004790","050004818","050004868","050004882","050004968","050005034","050005057","050005161","050005178","050005201","050005218","050005224","050005268","050005308","050005316","050005368","050005408","050005443","050005558","050005748","050005798","050005838","050005898","050005909","050005915","050006027","050006091","050006119","050006223","050006246","050006309","050006309","050006338","050006396","050006407","050006436","050006459","050006465","050006471","050006528","050006618","050006690","050006701","050006966","050007003","050007130","050007208","050007245","050007337","050007337","050007343","050007406","050007435","050007441","050007458","050007458","050007458","050007458","050007458","050007752","050007752","050007775","050007809","050007844","050007971","050008221","050008478","050008837","050008958","050009462","050009502","050009502","050009525","050009548","050009548","050009698","050009788","050009940","050010056","050010198","050010338","050010845","050011018","050011216","050011746","050011838","050011844","050011888","050011936","050012152","050012647","050012889","050012970","050013068","050013237","050013266","050013312","050013364","050013427","050013448","050013479","050013531","050013598","050013638","050013750","050013767","050013788","050014098","050014138","050014340","050014490","050014518","050014680","050014766","050014887","050014933","050014956","050015575","050015581","050015598","050015609","050015713","050015736","050015811","050015840");

	HashSet<String> listToSet = new HashSet<String>(itemLists);

	//Creating Arraylist without duplicate values
	List<String> itemList = new ArrayList<String>(listToSet);




	public void	createArrayOfJson() throws IOException{
		ObjectMapper objectMapper = new ObjectMapper();
		randomGenerator = new Random();
		promotionSet = new HashSet<>();
		int offerRef = 5000;
		int detailID = 30000;

		File file = new File("src/test/resources/com/tesco/services/core/fixtures/OneTimeLoadJson/OneTimeJsonForPerformanceTest.json");
		if(file.exists()) {
			file.delete();
		}
		file.createNewFile();
		FileWriter fileWriter = new FileWriter(file.getAbsoluteFile(),true);
		BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
		bufferedWriter.write("");
		bufferedWriter.write("[");

		/* Simple Promotion */
		String simpleJsonString = fixture("com/tesco/services/core/fixtures/OneTimeLoadJson/SimplePromotion.json");
		PromotionEntity simplePromotion = objectMapper.readValue(simpleJsonString, PromotionEntity.class);

		for(int i=1; i<=500 ; i++) {
			simplePromotion.offerRef = String.valueOf(offerRef++);
			PromoItemListEntity promoItemListEntity = simplePromotion.getPromoItemListEntities().get(
					0);
			for(PromoItemEntity promoItemEntity : promoItemListEntity.getPromoItems()){
				promoItemEntity.setItemRef(itemList.get(randomGenerator.nextInt(itemList.size())));
				promoItemEntity.setRpmPromoCompDetailId(String.valueOf(detailID++));
			}
			int locRef   = 5;
			for(int j=0 ; j<4 ; j++) {
				for(PromoItemEntity promoItemEntity : promoItemListEntity.getPromoItems()){
					promoItemEntity.setItemRef(itemList.get(randomGenerator.nextInt(itemList.size())));
					promoItemEntity.setRpmPromoCompDetailId(String.valueOf(detailID++));
				}
				simplePromotion.locRef = String.valueOf(locRef++);
				bufferedWriter.write(objectMapper
						.writeValueAsString(simplePromotion));
				bufferedWriter.newLine();
				bufferedWriter.write(",");
			}
		}


		/* Threshold Future Promotion */
		String thresholdJsonString = fixture("com/tesco/services/core/fixtures/OneTimeLoadJson/ThresholdPromotion.json");
		PromotionEntity thresholdPromotion = objectMapper.readValue(thresholdJsonString, PromotionEntity.class);

		for(int i=1; i<=250 ; i++) {
			thresholdPromotion.offerRef = String.valueOf(offerRef++);
			PromoItemListEntity promoItemListEntity = thresholdPromotion.getPromoItemListEntities().get(
					0);

			int locRef   = 5;
			for(int j=0 ; j<4 ; j++) {
				for(PromoItemEntity promoItemEntity : promoItemListEntity.getPromoItems()){
					promoItemEntity.setItemRef(itemList.get(randomGenerator.nextInt(itemList.size())));
					promoItemEntity.setRpmPromoCompDetailId(String.valueOf(detailID++));
				}
				thresholdPromotion.locRef = String.valueOf(locRef++);
				bufferedWriter.write(objectMapper
						.writeValueAsString(thresholdPromotion));
				bufferedWriter.newLine();
				bufferedWriter.write(",");
			}
		}

		/* Threshold Hierarchy Promotion */
		String thresholdHierJsonString = fixture("com/tesco/services/core/fixtures/OneTimeLoadJson/HierarchyThreshold.json");
		PromotionEntity thresholdHierPromotion = objectMapper.readValue(thresholdHierJsonString, PromotionEntity.class);

		for(int i=1; i<=250 ; i++) {
			thresholdHierPromotion.offerRef = String.valueOf(offerRef++);
			PromoItemListEntity promoItemListEntity = thresholdHierPromotion.getPromoItemListEntities().get(
					0);

			int locRef   = 5;
			for(int j=0 ; j<4 ; j++) {
				for(PromoItemEntity promoItemEntity : promoItemListEntity.getPromoItems()){
					//promoItemEntity.setItemRef(itemList.get(randomGenerator.nextInt(itemList.size())));
					promoItemEntity.setRpmPromoCompDetailId(String.valueOf(detailID++));
				}
				thresholdHierPromotion.locRef = String.valueOf(locRef++);
				bufferedWriter.write(objectMapper
						.writeValueAsString(thresholdHierPromotion));
				bufferedWriter.newLine();
				bufferedWriter.write(",");
			}
		}

		/* Step Threshold Promotion */
		String stepThresholdJsonString = fixture("com/tesco/services/core/fixtures/OneTimeLoadJson/StepThresholdPromotion.json");
		PromotionEntity stepThresholdPromotion = objectMapper.readValue(stepThresholdJsonString, PromotionEntity.class);

		for(int i=1; i<=250 ; i++) {
			stepThresholdPromotion.offerRef = String.valueOf(offerRef++);
			PromoItemListEntity promoItemListEntity = stepThresholdPromotion.getPromoItemListEntities().get(
					0);

			int locRef   = 5;
			for(int j=0 ; j<4 ; j++) {
				for(PromoItemEntity promoItemEntity : promoItemListEntity.getPromoItems()){
					promoItemEntity.setItemRef(itemList.get(randomGenerator.nextInt(itemList.size())));
					promoItemEntity.setRpmPromoCompDetailId(String.valueOf(detailID++));
				}
				stepThresholdPromotion.locRef = String.valueOf(locRef++);
				bufferedWriter.write(objectMapper
						.writeValueAsString(stepThresholdPromotion));
				bufferedWriter.newLine();
				bufferedWriter.write(",");
			}
		}

		/* Multibuy Mead Deal Promotion */
		String mbMDJsonString = fixture("com/tesco/services/core/fixtures/OneTimeLoadJson/MultiBuy_MealDeal.json");
		PromotionEntity mbMDPromotion = objectMapper.readValue(mbMDJsonString, PromotionEntity.class);

		for(int i=1; i<=500 ; i++) {
			mbMDPromotion.offerRef = String.valueOf(offerRef++);
			PromoItemListEntity promoItemListEntity = mbMDPromotion.getPromoItemListEntities().get(0);

			int locRef   = 5;
			for(int j=0 ; j<4 ; j++) {
				for(PromoItemEntity promoItemEntity : promoItemListEntity.getPromoItems()){
					promoItemEntity.setItemRef(itemList.get(randomGenerator.nextInt(itemList.size())));
					promoItemEntity.setRpmPromoCompDetailId(String.valueOf(detailID++));
				}
				mbMDPromotion.locRef = String.valueOf(locRef++);
				bufferedWriter.write(objectMapper.writeValueAsString(mbMDPromotion));
				bufferedWriter.newLine();
				bufferedWriter.write(",");
			}
		}

		/* Multibuy Choice Save Promotion */
		String mbCSJsonString = fixture("com/tesco/services/core/fixtures/OneTimeLoadJson/MultiBuy_ChoiceSave.json");
		PromotionEntity mbCSPromotion = objectMapper.readValue(mbCSJsonString, PromotionEntity.class);

		for(int i=1; i<=500 ; i++) {
			mbCSPromotion.offerRef = String.valueOf(offerRef++);
			PromoItemListEntity promoItemListEntity = mbCSPromotion.getPromoItemListEntities().get(0);

			int locRef   = 5;
			for(int j=0 ; j<4 ; j++) {
				for(PromoItemEntity promoItemEntity : promoItemListEntity.getPromoItems()){
					promoItemEntity.setItemRef(itemList.get(randomGenerator.nextInt(itemList.size())));
					promoItemEntity.setRpmPromoCompDetailId(String.valueOf(detailID++));
				}
				mbCSPromotion.locRef = String.valueOf(locRef++);
				bufferedWriter.write(objectMapper.writeValueAsString(mbCSPromotion));
				bufferedWriter.newLine();
				bufferedWriter.write(",");
			}
		}

		/* Multibuy Link Save Promotion */
		String mbLSJsonString = fixture("com/tesco/services/core/fixtures/OneTimeLoadJson/MultiBuy_LinkSave.json");
		PromotionEntity mbLSPromotion = objectMapper.readValue(mbLSJsonString, PromotionEntity.class);

		for(int i=1; i<=250 ; i++) {
			mbLSPromotion.offerRef = String.valueOf(offerRef++);
			PromoItemListEntity promoItemListEntity = mbLSPromotion.getPromoItemListEntities().get(0);

			int locRef   = 5;
			for(int j=0 ; j<4 ; j++) {
				for(PromoItemEntity promoItemEntity : promoItemListEntity.getPromoItems()){
					promoItemEntity.setItemRef(itemList.get(randomGenerator.nextInt(itemList.size())));
					promoItemEntity.setRpmPromoCompDetailId(String.valueOf(detailID++));
				}
				mbLSPromotion.locRef = String.valueOf(locRef++);
				bufferedWriter.write(objectMapper.writeValueAsString(mbLSPromotion));
				bufferedWriter.newLine();
				bufferedWriter.write(",");
			}
		}
		/* To remove , after last document */
		mbLSPromotion.offerRef = String.valueOf(offerRef++);
		PromoItemListEntity promoItemListEntity = mbLSPromotion.getPromoItemListEntities().get(0);

		int locRef   = 5;
			for(PromoItemEntity promoItemEntity : promoItemListEntity.getPromoItems()){
				promoItemEntity.setItemRef(itemList.get(randomGenerator.nextInt(itemList.size())));
				promoItemEntity.setRpmPromoCompDetailId(String.valueOf(detailID++));
			}
			mbLSPromotion.locRef = String.valueOf(locRef++);
			bufferedWriter.write(objectMapper.writeValueAsString(mbLSPromotion));
			bufferedWriter.newLine();

		/* ------------------- */
		bufferedWriter.write("]");
		bufferedWriter.flush();
		bufferedWriter.close();
	}

	public Dockyard getDockyard() {

		if (dockyard == null) {
			dockyard = new Dockyard();
		}
		return dockyard;
	}

}
