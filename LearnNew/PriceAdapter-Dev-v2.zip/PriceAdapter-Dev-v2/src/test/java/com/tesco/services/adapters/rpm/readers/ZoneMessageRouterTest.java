package com.tesco.services.adapters.rpm.readers;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.tesco.services.adapters.rpm.readers.impl.ZoneMessageRouter;
import com.tesco.services.repositories.RepositoryImpl;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.xml.sax.SAXParseException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Optional;
import com.tesco.couchbase.AsyncCouchbaseWrapper;
import com.tesco.couchbase.CouchbaseWrapper;
import com.tesco.couchbase.testutils.AsyncCouchbaseWrapperStub;
import com.tesco.couchbase.testutils.BucketTool;
import com.tesco.couchbase.testutils.CouchbaseTestManager;
import com.tesco.couchbase.testutils.CouchbaseWrapperStub;
import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.exceptions.ZoneEventException;
import com.tesco.services.adapters.rpm.writers.impl.ZoneWriter;
import com.tesco.services.adapters.zone.ZoneEventHandler;
import com.tesco.services.adapters.zone.ZoneHandler;
import com.tesco.services.adapters.zone.impl.ZoneHandlerImpl;
import com.tesco.services.core.Store;
import com.tesco.services.core.ZoneEntity;
import com.tesco.services.core.zone.ZoneGrpEntity;
import com.tesco.services.exceptions.MessageRouterException;
import com.tesco.services.resources.TestConfiguration;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.ParseMessageUtil;
import com.tesco.services.utility.PriceConstants;
import com.tesco.zone.core.TSLZoneGroupDesc;
import com.tesco.zone.core.TSLZoneGroupRef;

public class ZoneMessageRouterTest {

	@Mock
	private ObjectMapper mapper;
	private static Configuration testConfiguration;

	@Mock
	private ZoneWriter zoneWriter;

	@Mock
	private CouchbaseWrapper couchbaseWrapper;

	@Mock
	private AsyncCouchbaseWrapper asyncCouchbaseWrapper;

	@Mock
	private RepositoryImpl repositoryImpl;

	@Mock
	private ZoneHandler zoneHandler;

	@Mock
	private ZoneEventHandler zoneEventHandler;

	@Mock
	private CouchbaseTestManager couchbaseTestManager;

	private ArgumentCaptor<TSLZoneGroupDesc> argument = ArgumentCaptor
			.forClass(TSLZoneGroupDesc.class);;
	private ArgumentCaptor<String> stringArgument = ArgumentCaptor
			.forClass(String.class);
	private ArgumentCaptor<TSLZoneGroupRef> argumentRef = ArgumentCaptor
			.forClass(TSLZoneGroupRef.class);

	@Before
	public void setUp() throws Exception {

		testConfiguration = TestConfiguration.load();

		if (testConfiguration.isDummyCouchbaseMode()) {
			Map<String, ImmutablePair<Long, String>> fakeBase = new HashMap<>();
			couchbaseTestManager = new CouchbaseTestManager(
					new CouchbaseWrapperStub(fakeBase),
					new AsyncCouchbaseWrapperStub(fakeBase),
					mock(BucketTool.class));
		} else {
			couchbaseTestManager = new CouchbaseTestManager(
					testConfiguration.getCouchbaseBucket(),
					testConfiguration.getCouchbaseUsername(),
					testConfiguration.getCouchbasePassword(),
					testConfiguration.getCouchbaseNodes(),
					testConfiguration.getCouchbaseAdminUsername(),
					testConfiguration.getCouchbaseAdminPassword());
		}

		couchbaseWrapper = couchbaseTestManager.getCouchbaseWrapper();
		asyncCouchbaseWrapper = couchbaseTestManager.getAsyncCouchbaseWrapper();
		mapper = new ObjectMapper();
		repositoryImpl = new RepositoryImpl(this.couchbaseWrapper,
				asyncCouchbaseWrapper, mapper);
		zoneWriter = new ZoneWriter(testConfiguration, repositoryImpl);

		zoneHandler = new ZoneHandlerImpl(zoneWriter, repositoryImpl);
		zoneEventHandler = Mockito.mock(ZoneEventHandler.class);
	}

	@Test
	public void shouldUnmarshallAndProcessZoneGRPCreWhenNoZoneDocNotPresentMsg()
			throws Exception {

		Map zoneDataMap = new HashMap();
		Map zoneGrpDataMap = new HashMap();
		String zone = "30";
		String zoneGrpId = "4000";
		String cb_key = PriceConstants.ZONE_KEY + zone;
		String zoneGrpKey = PriceConstants.ZONE_GRP_KEY + zoneGrpId;
		ZoneMessageRouter zoneMessageRouter = new ZoneMessageRouter(
				zoneHandler, zoneEventHandler);

		String zoneGrpdata = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>ZONEMNT</family>\n"
				+ "<type>ZONEGROUPCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 08:31:35.467|342</ribmessageID>\n"
				+ "<publishTime>2015-10-06 08:31:35.467 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;TSLZoneGroupDesc&gt;&lt;zone_group_id&gt;4000&lt;/zone_group_id&gt;&lt;zone_group_name&gt;PS_ZoneGrp_4000&lt;/zone_group_name&gt;&lt;TSLZoneGroupType&gt;&lt;zone_group_type&gt;2&lt;/zone_group_type&gt;&lt;/TSLZoneGroupType&gt;&lt;TSLZone&gt;&lt;zone_id&gt;30&lt;/zone_id&gt;&lt;zone_name&gt;zone_30&lt;/zone_name&gt;&lt;base_ind&gt;1&lt;/base_ind&gt;&lt;country_code&gt;GB&lt;/country_code&gt;&lt;currency_code&gt;GBP&lt;/currency_code&gt;&lt;/TSLZone&gt;&lt;/TSLZoneGroupDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
				+ "</RibMessages>";

		zoneMessageRouter.route(zoneGrpdata);

		// Set zoneGroupType = new HashSet();
		// zoneGroupType.add("2");
		zoneDataMap.put("zoneGroupId", "4000");
		zoneDataMap.put("zoneGroupName", "PS_ZoneGrp_4000");
		zoneDataMap.put("zoneGroupType", "2");

		List<Map> zoneRefList = new ArrayList<Map>();
		Map zoneInfoMap = new HashMap();
		zoneInfoMap.put("zoneId", "30");
		zoneInfoMap.put("zoneName", "zone_30");
		zoneInfoMap.put("baseInd", "1");
		zoneInfoMap.put("currency", "GBP");
		zoneInfoMap.put("countryId", "GB");
		zoneInfoMap.put("offerPrefix", "A");
		zoneRefList.add(zoneInfoMap);
		zoneDataMap.put("zoneRefs", zoneRefList);

		zoneGrpDataMap.put("zoneGroupId", "4000");
		zoneGrpDataMap.put("zoneGroupName", "PS_ZoneGrp_4000");
		zoneGrpDataMap.put("zoneGroupType", "2");

		List storeIds = new LinkedList<String>();
		List zoneIds = new LinkedList<String>();
		zoneIds.add("30");

		ZoneEntity expectedZoneEntity = createZoneEntity(zoneDataMap, storeIds);

		ZoneGrpEntity expectedZoneGrpEntity = createZoneGroupEntity(
				zoneGrpDataMap, zoneIds);

		ZoneGrpEntity zoneGrpDocCRE = (ZoneGrpEntity) repositoryImpl
				.getGenericObject(zoneGrpKey, ZoneGrpEntity.class);

		ZoneEntity zoneDocCRE = (ZoneEntity) repositoryImpl
				.getGenericObject(cb_key, ZoneEntity.class);

		Assert.assertNotNull(zoneGrpDocCRE);
		Assert.assertNotNull(zoneDocCRE);

		zoneGrpDocCRE.setCreatedById("RPM");
		zoneGrpDocCRE.setCreatedDate("createdDate");
		zoneGrpDocCRE.setLastUpdateDate("lastUpdatedDate");
		zoneGrpDocCRE.setLastUpdatedById("RPM");

		zoneDocCRE.setCreatedDate("createdDate");
		zoneDocCRE.setLastUpdateDate("lastUpdatedDate");

		Assert.assertEquals(expectedZoneGrpEntity.toString(),
				zoneGrpDocCRE.toString());
		Assert.assertEquals(expectedZoneEntity.toString(),
				zoneDocCRE.toString());
	}

	@Test
	public void shouldUnMarshallAndProcessZoneCreWhenZoneNotPresentMsg()
			throws Exception {
		String zone = "4548";
		String cb_key = PriceConstants.ZONE_KEY + zone;
		Map zoneDataMap = new HashMap();
		Map zoneGrpDataMap = new HashMap();
		ZoneMessageRouter zoneMessageRouter = new ZoneMessageRouter(
				zoneHandler, zoneEventHandler);

		String zoneGrpdata = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>ZONEMNT</family>\n"
				+ "<type>ZONEGROUPCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 08:31:35.467|342</ribmessageID>\n"
				+ "<publishTime>2015-10-06 08:31:35.467 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;TSLZoneGroupDesc&gt;&lt;zone_group_id&gt;4496&lt;/zone_group_id&gt;&lt;zone_group_name&gt;PS_ZoneGrp_1&lt;/zone_group_name&gt;&lt;TSLZoneGroupType&gt;&lt;zone_group_type&gt;2&lt;/zone_group_type&gt;&lt;/TSLZoneGroupType&gt;&lt;TSLZone&gt;&lt;zone_id&gt;4500&lt;/zone_id&gt;&lt;zone_name&gt;PS_Zone_01&lt;/zone_name&gt;&lt;base_ind&gt;1&lt;/base_ind&gt;&lt;country_code&gt;GB&lt;/country_code&gt;&lt;currency_code&gt;GBP&lt;/currency_code&gt;&lt;/TSLZone&gt;&lt;/TSLZoneGroupDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
				+ "</RibMessages>";

		zoneMessageRouter.route(zoneGrpdata);

		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>ZONEMNT</family>\n"
				+ "<type>ZONECRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 14:02:25.155|358</ribmessageID>\n"
				+ "<publishTime>2015-10-06 14:02:25.155 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;TSLZoneGroupDesc&gt;&lt;zone_group_id&gt;4496&lt;/zone_group_id&gt;&lt;TSLZone&gt;&lt;zone_id&gt;4548&lt;/zone_id&gt;&lt;zone_name&gt;test&lt;/zone_name&gt;&lt;base_ind&gt;0&lt;/base_ind&gt;&lt;country_code&gt;GB&lt;/country_code&gt;&lt;currency_code&gt;GBP&lt;/currency_code&gt;&lt;/TSLZone&gt;&lt;/TSLZoneGroupDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
				+ "</RibMessages>";

		zoneMessageRouter.route(data);

		zoneDataMap.put("zoneGroupId", "4496");
		zoneDataMap.put("zoneGroupName", "PS_ZoneGrp_1");
		zoneDataMap.put("zoneGroupType", "2");

		List<Map> zoneRefList = new ArrayList<Map>();
		Map zoneInfoMap = new HashMap();
		zoneInfoMap.put("zoneId", "4548");
		zoneInfoMap.put("zoneName", "test");
		zoneInfoMap.put("baseInd", "0");
		zoneInfoMap.put("currency", "GBP");
		zoneInfoMap.put("countryId", "GB");
		zoneInfoMap.put("offerPrefix", "A");
		zoneRefList.add(zoneInfoMap);
		zoneDataMap.put("zoneRefs", zoneRefList);

		List storeIds = new LinkedList<String>();

		ZoneEntity expectedZoneEntity = createZoneEntity(zoneDataMap, storeIds);
		ZoneEntity actualEntity = (ZoneEntity) repositoryImpl
				.getGenericObject(cb_key, ZoneEntity.class);
		Assert.assertNotNull(actualEntity);
		actualEntity.setCreatedDate("createdDate");
		actualEntity.setLastUpdateDate("lastUpdatedDate");
		Assert.assertEquals(expectedZoneEntity.toString(),
				actualEntity.toString());

		zoneGrpDataMap.put("zoneGroupId", "4496");
		zoneGrpDataMap.put("zoneGroupName", "PS_ZoneGrp_1");
		zoneGrpDataMap.put("zoneGroupType", "2");
		List zoneIds = new LinkedList<String>();
		zoneIds.add("4500");
		zoneIds.add("4548");

		ZoneGrpEntity expectedZoneGrpEntity = createZoneGroupEntity(
				zoneGrpDataMap, zoneIds);
		ZoneGrpEntity actualZoneGrpEntity = (ZoneGrpEntity) repositoryImpl
				.getGenericObject(PriceConstants.ZONE_GRP_KEY + "4496",
						ZoneGrpEntity.class);
		Assert.assertNotNull(actualZoneGrpEntity);
		actualZoneGrpEntity.setCreatedDate("createdDate");
		actualZoneGrpEntity.setLastUpdateDate("lastUpdatedDate");
		Assert.assertEquals(expectedZoneGrpEntity.toString(),
				actualZoneGrpEntity.toString());
	}

	@Test
	public void shouldUnMarshallAndProcessLocCreMsgWhenZoneIsAvailableAndNoLocationInZoneDoc()
			throws Exception {

		String zone = "30";
		String storeId = "2000";
		String zoneGrp = "4000";
		String cb_key = PriceConstants.ZONE_KEY + zone;
		String loc_key = PriceConstants.STORE_KEY + storeId;
		String grp_key = PriceConstants.ZONE_GRP_KEY + zoneGrp;

		Map zoneDataMap = new HashMap();
		Map zoneGrpDataMap = new HashMap();

		zoneDataMap.put("zoneGroupId", "4000");
		zoneDataMap.put("zoneGroupName", "PS_ZoneGrp_4000");
		zoneDataMap.put("zoneGroupType", "1");

		List<Map> zoneRefList = new ArrayList<Map>();
		Map zoneInfoMap = new HashMap();
		zoneInfoMap.put("zoneId", "30");
		zoneInfoMap.put("zoneName", "zone_30");
		zoneInfoMap.put("baseInd", "1");
		zoneInfoMap.put("currency", "GBP");
		zoneInfoMap.put("countryId", "GB");
		zoneInfoMap.put("offerPrefix", "A");
		zoneRefList.add(zoneInfoMap);
		zoneDataMap.put("zoneRefs", zoneRefList);

		zoneGrpDataMap.put("zoneGroupId", "4000");
		zoneGrpDataMap.put("zoneGroupName", "PS_ZoneGrp_4000");
		zoneGrpDataMap.put("zoneGroupType", "2");
		List<String> zoneIds = new LinkedList<String>();
		zoneIds.add("30");

		List<String> storeIds = new LinkedList<String>();

		ZoneEntity zoneEntity = createZoneEntity(zoneDataMap, storeIds);
		ZoneGrpEntity zoneGrpEntity = createZoneGroupEntity(zoneGrpDataMap,
				zoneIds);

		ZoneMessageRouter zoneMessageRouter = new ZoneMessageRouter(
				zoneHandler, zoneEventHandler);

		zoneWriter.insertZoneGrpData(grp_key, zoneGrpEntity);
		zoneWriter.insertZoneData(cb_key, zoneEntity);

		String locData = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>ZONEMNT</family>\n"
				+ "<type>ZONELOCCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 14:02:25.155|358</ribmessageID>\n"
				+ "<publishTime>2015-10-06 14:02:25.155 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;TSLZoneGroupDesc&gt;&lt;zone_group_id&gt;4000&lt;/zone_group_id&gt;&lt;TSLZone&gt;&lt;zone_id&gt;30&lt;/zone_id&gt;&lt;TSLZoneLoc&gt;&lt;loc&gt;2000&lt;/loc&gt;&lt;loc_type&gt;0&lt;/loc_type&gt;&lt;/TSLZoneLoc&gt;&lt;/TSLZone&gt;&lt;/TSLZoneGroupDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
				+ "</RibMessages>";

		zoneMessageRouter.route(locData);
		storeIds.add("2000");

		ZoneEntity expectedZoneEntity = createZoneEntity(zoneDataMap, storeIds);

		Map storeMap = new HashMap();
		storeMap.put("storeId", "2000");
		storeMap.put("priceZoneId", -1);
		storeMap.put("promoZoneId", 30);
		storeMap.put("clearanceZoneId", -1);
		storeMap.put("currency", "GBP");
		storeMap.put("countryId", "GB");

		Store expectedStoreEntity = createStoreEntity(storeMap);

		ZoneEntity actualEntity = (ZoneEntity) repositoryImpl
				.getGenericObject(cb_key, ZoneEntity.class);
		Assert.assertNotNull(actualEntity);
		actualEntity.setCreatedDate("createdDate");
		actualEntity.setLastUpdateDate("lastUpdatedDate");
		Assert.assertEquals(expectedZoneEntity.toString(),
				actualEntity.toString());

		Store actualStoreEntity = (Store) repositoryImpl.getGenericObject(
				loc_key, Store.class);

		Assert.assertNotNull(actualStoreEntity);
		Assert.assertEquals(expectedStoreEntity.toString(),
				actualStoreEntity.toString());
	}

	@Test
	public void shouldUnMarshallAndProcessLocCreMsgWhenZoneIsAvailableAndLocationPresentInZoneDoc()
			throws Exception {

		String zone = "30";
		String storeId = "2000";
		String zoneGrp = "4000";
		String cb_key = PriceConstants.ZONE_KEY + zone;
		String loc_key = PriceConstants.STORE_KEY + storeId;
		String grp_key = PriceConstants.ZONE_GRP_KEY + zoneGrp;

		Map zoneDataMap = new HashMap();
		Map zoneGrpDataMap = new HashMap();

		zoneDataMap.put("zoneGroupId", "4000");
		zoneDataMap.put("zoneGroupName", "PS_ZoneGrp_4000");
		zoneDataMap.put("zoneGroupType", "1");

		List<Map> zoneRefList = new ArrayList<Map>();
		Map zoneInfoMap = new HashMap();
		zoneInfoMap.put("zoneId", "30");
		zoneInfoMap.put("zoneName", "zone_30");
		zoneInfoMap.put("baseInd", "1");
		zoneInfoMap.put("currency", "GBP");
		zoneInfoMap.put("countryId", "GB");
		zoneInfoMap.put("offerPrefix", "A");
		zoneRefList.add(zoneInfoMap);
		zoneDataMap.put("zoneRefs", zoneRefList);

		zoneGrpDataMap.put("zoneGroupId", "4000");
		zoneGrpDataMap.put("zoneGroupName", "PS_ZoneGrp_4000");
		zoneGrpDataMap.put("zoneGroupType", "1");
		List<String> zoneIds = new LinkedList<String>();
		zoneIds.add("30");

		List<String> storeIds = new LinkedList<String>();

		// ZoneEntity zoneEntity = createZoneEntity(zoneDataMap,storeIds);
		ZoneGrpEntity zoneGrpEntityBefore = createZoneGroupEntity(
				zoneGrpDataMap, zoneIds);

		ZoneMessageRouter zoneMessageRouter = new ZoneMessageRouter(
				zoneHandler, zoneEventHandler);

		storeIds.add("2000");

		ZoneEntity zoneEntityBefore = createZoneEntity(zoneDataMap, storeIds);

		Map storeMap = new HashMap();
		storeMap.put("storeId", "2000");
		storeMap.put("priceZoneId", -1);
		storeMap.put("promoZoneId", 30);
		storeMap.put("clearanceZoneId", -1);
		storeMap.put("currency", "GBP");
		storeMap.put("countryId", "GB");

		Store storeEntityBefore = createStoreEntity(storeMap);

		zoneWriter.insertZoneGrpData(grp_key, zoneGrpEntityBefore);
		zoneWriter.insertZoneData(cb_key, zoneEntityBefore);
		zoneWriter.insertStoreData(loc_key, storeEntityBefore);

		String locData = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>ZONEMNT</family>\n"
				+ "<type>ZONELOCCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 14:02:25.155|358</ribmessageID>\n"
				+ "<publishTime>2015-10-06 14:02:25.155 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;TSLZoneGroupDesc&gt;&lt;zone_group_id&gt;4000&lt;/zone_group_id&gt;&lt;TSLZone&gt;&lt;zone_id&gt;30&lt;/zone_id&gt;&lt;TSLZoneLoc&gt;&lt;loc&gt;2001&lt;/loc&gt;&lt;loc_type&gt;0&lt;/loc_type&gt;&lt;/TSLZoneLoc&gt;&lt;/TSLZone&gt;&lt;/TSLZoneGroupDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
				+ "</RibMessages>";

		zoneMessageRouter.route(locData);
		storeIds.remove("2000");
		storeIds.add("2001");
		storeIds.add("2000");

		ZoneEntity expectedZoneEntity = createZoneEntity(zoneDataMap, storeIds);

		Map storeMapFor2ndLoc = new HashMap();
		storeMapFor2ndLoc.put("storeId", "2001");
		storeMapFor2ndLoc.put("priceZoneId", -1);
		storeMapFor2ndLoc.put("promoZoneId", 30);
		storeMapFor2ndLoc.put("clearanceZoneId", -1);
		storeMapFor2ndLoc.put("currency", "GBP");
		storeMapFor2ndLoc.put("countryId", "GB");

		Store expectedStoreEntity = createStoreEntity(storeMapFor2ndLoc);

		ZoneEntity actualEntity = (ZoneEntity) repositoryImpl
				.getGenericObject(cb_key, ZoneEntity.class);
		Assert.assertNotNull(actualEntity);
		actualEntity.setCreatedDate("createdDate");
		actualEntity.setLastUpdateDate("lastUpdatedDate");

		Assert.assertEquals(expectedZoneEntity.toString(),
				actualEntity.toString());

		loc_key = PriceConstants.STORE_KEY + "2001";

		Store actualStoreEntity = (Store) repositoryImpl.getGenericObject(
				loc_key, Store.class);

		Assert.assertNotNull(actualStoreEntity);

		Assert.assertEquals(expectedStoreEntity.toString(),
				actualStoreEntity.toString());
	}

	@Test
	public void shouldUnMarshallAndProcessZoneDelMsg() throws Exception {

		String zone = "4548";
		String cb_key = PriceConstants.ZONE_KEY + zone;
		ZoneMessageRouter zoneMessageRouter = new ZoneMessageRouter(
				zoneHandler, zoneEventHandler);

		String zoneGrpdata = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>ZONEMNT</family>\n"
				+ "<type>ZONEGROUPCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 08:31:35.467|342</ribmessageID>\n"
				+ "<publishTime>2015-10-06 08:31:35.467 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;TSLZoneGroupDesc&gt;&lt;zone_group_id&gt;4496&lt;/zone_group_id&gt;&lt;zone_group_name&gt;PS_ZoneGrp_1&lt;/zone_group_name&gt;&lt;TSLZoneGroupType&gt;&lt;zone_group_type&gt;2&lt;/zone_group_type&gt;&lt;/TSLZoneGroupType&gt;&lt;TSLZone&gt;&lt;zone_id&gt;4500&lt;/zone_id&gt;&lt;zone_name&gt;PS_Zone_01&lt;/zone_name&gt;&lt;base_ind&gt;1&lt;/base_ind&gt;&lt;country_code&gt;GB&lt;/country_code&gt;&lt;currency_code&gt;GBP&lt;/currency_code&gt;&lt;/TSLZone&gt;&lt;/TSLZoneGroupDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
				+ "</RibMessages>";

		zoneMessageRouter.route(zoneGrpdata);

		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>ZONEMNT</family>\n"
				+ "<type>ZONECRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 14:02:25.155|358</ribmessageID>\n"
				+ "<publishTime>2015-10-06 14:02:25.155 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;TSLZoneGroupDesc&gt;&lt;zone_group_id&gt;4496&lt;/zone_group_id&gt;&lt;TSLZone&gt;&lt;zone_id&gt;4548&lt;/zone_id&gt;&lt;zone_name&gt;test&lt;/zone_name&gt;&lt;base_ind&gt;0&lt;/base_ind&gt;&lt;country_code&gt;GB&lt;/country_code&gt;&lt;currency_code&gt;GBP&lt;/currency_code&gt;&lt;/TSLZone&gt;&lt;/TSLZoneGroupDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
				+ "</RibMessages>";

		zoneMessageRouter.route(data);
		Assert.assertNotNull(repositoryImpl.getGenericObject(cb_key,
				ZoneEntity.class));

		String dataDel = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>ZONEMNT</family>\n"
				+ "<type>ZONEDEL</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 14:22:59.857|370</ribmessageID>\n"
				+ "<publishTime>2015-10-06 14:22:59.857 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;TSLZoneGroupRef&gt;&lt;zone_group_id&gt;4496&lt;/zone_group_id&gt;&lt;TSLZoneRef&gt;&lt;zone_id&gt;4548&lt;/zone_id&gt;&lt;/TSLZoneRef&gt;&lt;/TSLZoneGroupRef&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
				+ "</RibMessages>";

		zoneMessageRouter.route(dataDel);
		Assert.assertNull(repositoryImpl.getGenericObject(cb_key,
				ZoneEntity.class));

		Map zoneGrpDataMap = new HashMap();
		zoneGrpDataMap.put("zoneGroupId", "4496");
		zoneGrpDataMap.put("zoneGroupName", "PS_ZoneGrp_1");
		zoneGrpDataMap.put("zoneGroupType", "2");
		List<String> zoneIds = new LinkedList<String>();
		zoneIds.add("4500");

		ZoneGrpEntity expectedZoneGrpEntity = createZoneGroupEntity(
				zoneGrpDataMap, zoneIds);

		ZoneGrpEntity actualZoneGrpDoc = (ZoneGrpEntity) repositoryImpl
				.getGenericObject(PriceConstants.ZONE_GRP_KEY + "4496",
						ZoneGrpEntity.class);
		Assert.assertNotNull(actualZoneGrpDoc);
		actualZoneGrpDoc.setCreatedDate("createdDate");
		actualZoneGrpDoc.setLastUpdateDate("lastUpdatedDate");
		Assert.assertEquals(expectedZoneGrpEntity.toString(),
				actualZoneGrpDoc.toString());
	}

	@Ignore
	@Test
	public void shouldUnmarshallAndProcessZoneDelWhenNoDocPresentMsg()
			throws Exception {

		String zone = "4550";
		String cb_key = PriceConstants.ZONE_KEY + zone;
		ZoneMessageRouter zoneMessageRouter = new ZoneMessageRouter(
				zoneHandler, zoneEventHandler);
		Map zoneGrpDataMap = new HashMap();
		zoneGrpDataMap.put("zoneGroupId", "4497");
		zoneGrpDataMap.put("zoneGroupName", "PS_ZoneGrp_4497");
		zoneGrpDataMap.put("zoneGroupType", "2");
		List<String> zoneIds = new LinkedList<String>();
		zoneIds.add("4500");

		ZoneGrpEntity expectedZoneGrpEntity = createZoneGroupEntity(
				zoneGrpDataMap, zoneIds);

		zoneWriter.insertZoneGrpData(PriceConstants.ZONE_GRP_KEY + "4497",
				expectedZoneGrpEntity);

		String dataDel = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>ZONEMNT</family>\n"
				+ "<type>ZONEDEL</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 14:22:59.857|370</ribmessageID>\n"
				+ "<publishTime>2015-10-06 14:22:59.857 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;TSLZoneGroupRef&gt;&lt;zone_group_id&gt;4497&lt;/zone_group_id&gt;&lt;TSLZoneRef&gt;&lt;zone_id&gt;4550&lt;/zone_id&gt;&lt;/TSLZoneRef&gt;&lt;/TSLZoneGroupRef&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
				+ "</RibMessages>";
		try {
			zoneMessageRouter.route(dataDel);
		} catch (Exception e) {
			Assert.assertEquals("Error while deleting the zone details", e
					.getMessage().toString());
		} finally {
			Assert.assertNull(repositoryImpl.getGenericObject(cb_key,
					ZoneEntity.class));
		}

	}

	@Test
	public void testSAXParseException() throws Exception {
		ZoneMessageRouter zoneMessageRouter = new ZoneMessageRouter(
				zoneHandler, zoneEventHandler);
		ParseMessageUtil parseMessageUtilMock = mock(ParseMessageUtil.class);
		when(
				parseMessageUtilMock.getNodeData(Matchers.any(String.class),
						Matchers.any(String.class))).thenThrow(
				SAXParseException.class);
		String data = "";
		try {
			zoneMessageRouter.route(data);
		} catch (MessageRouterException e) {
			Assert.assertTrue(e.getCause() instanceof SAXParseException);

		}
	}

	@Test
	public void shouldUnmarshallAndProcessZoneLocCreWhenThereExistNoStoreDataMsg()
			throws Exception {

		String zone = "4550";
		String cb_key = PriceConstants.ZONE_KEY + zone;

		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>ZONEMNT</family>\n"
				+ "<type>ZONECRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 14:02:25.155|358</ribmessageID>\n"
				+ "<publishTime>2015-10-06 14:02:25.155 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;TSLZoneGroupDesc&gt;&lt;zone_group_id&gt;4496&lt;/zone_group_id&gt;&lt;TSLZone&gt;&lt;zone_id&gt;4550&lt;/zone_id&gt;&lt;zone_name&gt;PS_Zone&lt;/zone_name&gt;&lt;base_ind&gt;0&lt;/base_ind&gt;&lt;country_code&gt;GB&lt;/country_code&gt;&lt;currency_code&gt;GBP&lt;/currency_code&gt;&lt;/TSLZone&gt;&lt;/TSLZoneGroupDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
				+ "</RibMessages>";

		ZoneMessageRouter zoneMessageRouter = new ZoneMessageRouter(
				zoneHandler, zoneEventHandler);
		try {
			zoneMessageRouter.route(data);

			Assert.assertNotNull(repositoryImpl.getGenericObject(cb_key,
					ZoneEntity.class));
			ZoneEntity zoneCreDoc = (ZoneEntity) repositoryImpl
					.getGenericObject(cb_key, ZoneEntity.class);
			Assert.assertEquals(0, zoneCreDoc.getStoreIds().size());

			String locData = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
					+ "<RibMessages>\n"
					+ "<ribMessage>\n"
					+ "<family>ZONEMNT</family>\n"
					+ "<type>ZONELOCCRE</type>\n"
					+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 14:02:25.155|358</ribmessageID>\n"
					+ "<publishTime>2015-10-06 14:02:25.155 BST</publishTime>\n"
					+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
					+ "&lt;TSLZoneGroupDesc&gt;&lt;zone_group_id&gt;4496&lt;/zone_group_id&gt;&lt;TSLZone&gt;&lt;zone_id&gt;4550&lt;/zone_id&gt;&lt;TSLZoneLoc&gt;&lt;loc&gt;2129&lt;/loc&gt;&lt;loc_type&gt;0&lt;/loc_type&gt;&lt;/TSLZoneLoc&gt;&lt;/TSLZone&gt;&lt;/TSLZoneGroupDesc&gt;</messageData>\n"
					+ "<customData></customData>\n"
					+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
					+ "</RibMessages>";

			zoneMessageRouter.route(locData);
			ZoneEntity zoneLocCreDoc = (ZoneEntity) repositoryImpl
					.getGenericObject(cb_key, ZoneEntity.class);
			Assert.assertEquals(1, zoneLocCreDoc.getStoreIds().size());
		} catch (Exception e) {
			Assert.assertEquals(e.getMessage().toString(),
					"Error while constucting the zone Entity");
		}
	}

	@Test
	public void shouldUnmarshallAndProcessZoneLocCreWhenThereExistStoreDataMsg()
			throws Exception {

		String zone = "4551";
		String cb_key = PriceConstants.ZONE_KEY + zone;

		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>ZONEMNT</family>\n"
				+ "<type>ZONECRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 14:02:25.155|358</ribmessageID>\n"
				+ "<publishTime>2015-10-06 14:02:25.155 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;TSLZoneGroupDesc&gt;&lt;zone_group_id&gt;4496&lt;/zone_group_id&gt;&lt;TSLZone&gt;&lt;zone_id&gt;4551&lt;/zone_id&gt;&lt;zone_name&gt;PS_Zone&lt;/zone_name&gt;&lt;base_ind&gt;0&lt;/base_ind&gt;&lt;country_code&gt;GB&lt;/country_code&gt;&lt;currency_code&gt;GBP&lt;/currency_code&gt;&lt;/TSLZone&gt;&lt;/TSLZoneGroupDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
				+ "</RibMessages>";

		ZoneMessageRouter zoneMessageRouter = new ZoneMessageRouter(
				zoneHandler, zoneEventHandler);
		try {
			zoneMessageRouter.route(data);

			Assert.assertNotNull(repositoryImpl.getGenericObject(cb_key,
					ZoneEntity.class));

			String locData = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
					+ "<RibMessages>\n"
					+ "<ribMessage>\n"
					+ "<family>ZONEMNT</family>\n"
					+ "<type>ZONELOCCRE</type>\n"
					+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 14:02:25.155|358</ribmessageID>\n"
					+ "<publishTime>2015-10-06 14:02:25.155 BST</publishTime>\n"
					+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
					+ "&lt;TSLZoneGroupDesc&gt;&lt;zone_group_id&gt;4496&lt;/zone_group_id&gt;&lt;TSLZone&gt;&lt;zone_id&gt;4551&lt;/zone_id&gt;&lt;TSLZoneLoc&gt;&lt;loc&gt;2129&lt;/loc&gt;&lt;loc_type&gt;0&lt;/loc_type&gt;&lt;/TSLZoneLoc&gt;&lt;/TSLZone&gt;&lt;/TSLZoneGroupDesc&gt;</messageData>\n"
					+ "<customData></customData>\n"
					+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
					+ "</RibMessages>";

			zoneMessageRouter.route(locData);
			ZoneEntity zoneLocCreDoc = (ZoneEntity) repositoryImpl
					.getGenericObject(cb_key, ZoneEntity.class);
			Assert.assertEquals(1, zoneLocCreDoc.getStoreIds().size());

			String loc2Data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
					+ "<RibMessages>\n"
					+ "<ribMessage>\n"
					+ "<family>ZONEMNT</family>\n"
					+ "<type>ZONELOCCRE</type>\n"
					+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 14:02:25.155|358</ribmessageID>\n"
					+ "<publishTime>2015-10-06 14:02:25.155 BST</publishTime>\n"
					+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
					+ "&lt;TSLZoneGroupDesc&gt;&lt;zone_group_id&gt;4496&lt;/zone_group_id&gt;&lt;TSLZone&gt;&lt;zone_id&gt;4551&lt;/zone_id&gt;&lt;TSLZoneLoc&gt;&lt;loc&gt;2130&lt;/loc&gt;&lt;loc_type&gt;0&lt;/loc_type&gt;&lt;/TSLZoneLoc&gt;&lt;/TSLZone&gt;&lt;/TSLZoneGroupDesc&gt;</messageData>\n"
					+ "<customData></customData>\n"
					+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
					+ "</RibMessages>";

			zoneMessageRouter.route(loc2Data);
			ZoneEntity zoneLoc2CreDoc = (ZoneEntity) repositoryImpl
					.getGenericObject(cb_key, ZoneEntity.class);
			Assert.assertEquals(2, zoneLoc2CreDoc.getStoreIds().size());
		} catch (Exception e) {
			Assert.assertEquals(e.getMessage().toString(),
					"Error while constucting the zone Entity");
		}
	}

	@Test
	public void shouldUnmarshallAndProcessZoneLocDelMsg() throws Exception {

		String zone = "4551";
		String cb_key = PriceConstants.ZONE_KEY + zone;

		ZoneMessageRouter zoneMessageRouter = new ZoneMessageRouter(
				zoneHandler, zoneEventHandler);

		String zoneGrpdata = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>ZONEMNT</family>\n"
				+ "<type>ZONEGROUPCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 08:31:35.467|342</ribmessageID>\n"
				+ "<publishTime>2015-10-06 08:31:35.467 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;TSLZoneGroupDesc&gt;&lt;zone_group_id&gt;4496&lt;/zone_group_id&gt;&lt;zone_group_name&gt;PS_ZoneGrp_1&lt;/zone_group_name&gt;&lt;TSLZoneGroupType&gt;&lt;zone_group_type&gt;2&lt;/zone_group_type&gt;&lt;/TSLZoneGroupType&gt;&lt;TSLZone&gt;&lt;zone_id&gt;4500&lt;/zone_id&gt;&lt;zone_name&gt;PS_Zone_01&lt;/zone_name&gt;&lt;base_ind&gt;1&lt;/base_ind&gt;&lt;country_code&gt;GB&lt;/country_code&gt;&lt;currency_code&gt;GBP&lt;/currency_code&gt;&lt;/TSLZone&gt;&lt;/TSLZoneGroupDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
				+ "</RibMessages>";

		zoneMessageRouter.route(zoneGrpdata);

		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>ZONEMNT</family>\n"
				+ "<type>ZONECRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 14:02:25.155|358</ribmessageID>\n"
				+ "<publishTime>2015-10-06 14:02:25.155 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;TSLZoneGroupDesc&gt;&lt;zone_group_id&gt;4496&lt;/zone_group_id&gt;&lt;TSLZone&gt;&lt;zone_id&gt;4551&lt;/zone_id&gt;&lt;zone_name&gt;PS_Zone&lt;/zone_name&gt;&lt;base_ind&gt;0&lt;/base_ind&gt;&lt;country_code&gt;GB&lt;/country_code&gt;&lt;currency_code&gt;GBP&lt;/currency_code&gt;&lt;/TSLZone&gt;&lt;/TSLZoneGroupDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
				+ "</RibMessages>";

		zoneMessageRouter.route(data);

		Assert.assertNotNull(repositoryImpl.getGenericObject(cb_key,
				ZoneEntity.class));

		String locData = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>ZONEMNT</family>\n"
				+ "<type>ZONELOCCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 14:02:25.155|358</ribmessageID>\n"
				+ "<publishTime>2015-10-06 14:02:25.155 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;TSLZoneGroupDesc&gt;&lt;zone_group_id&gt;4496&lt;/zone_group_id&gt;&lt;TSLZone&gt;&lt;zone_id&gt;4551&lt;/zone_id&gt;&lt;TSLZoneLoc&gt;&lt;loc&gt;2129&lt;/loc&gt;&lt;loc_type&gt;0&lt;/loc_type&gt;&lt;/TSLZoneLoc&gt;&lt;/TSLZone&gt;&lt;/TSLZoneGroupDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
				+ "</RibMessages>";

		zoneMessageRouter.route(locData);

		String loc2Data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>ZONEMNT</family>\n"
				+ "<type>ZONELOCCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 14:02:25.155|358</ribmessageID>\n"
				+ "<publishTime>2015-10-06 14:02:25.155 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;TSLZoneGroupDesc&gt;&lt;zone_group_id&gt;4496&lt;/zone_group_id&gt;&lt;TSLZone&gt;&lt;zone_id&gt;4551&lt;/zone_id&gt;&lt;TSLZoneLoc&gt;&lt;loc&gt;2130&lt;/loc&gt;&lt;loc_type&gt;0&lt;/loc_type&gt;&lt;/TSLZoneLoc&gt;&lt;/TSLZone&gt;&lt;/TSLZoneGroupDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
				+ "</RibMessages>";

		zoneMessageRouter.route(loc2Data);
		ZoneEntity zoneLoc2CreDoc = (ZoneEntity) repositoryImpl
				.getGenericObject(cb_key, ZoneEntity.class);
		Assert.assertEquals(2, zoneLoc2CreDoc.getStoreIds().size());

		String loc2DelData = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>ZONEMNT</family>\n"
				+ "<type>ZONELOCDEL</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 14:02:25.155|358</ribmessageID>\n"
				+ "<publishTime>2015-10-06 14:02:25.155 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;TSLZoneGroupRef&gt;&lt;zone_group_id&gt;4496&lt;/zone_group_id&gt;&lt;TSLZoneRef&gt;&lt;zone_id&gt;4551&lt;/zone_id&gt;&lt;TSLZoneLocRef&gt;&lt;loc&gt;2130&lt;/loc&gt;&lt;loc_type&gt;0&lt;/loc_type&gt;&lt;/TSLZoneLocRef&gt;&lt;/TSLZoneRef&gt;&lt;/TSLZoneGroupRef&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
				+ "</RibMessages>";

		zoneMessageRouter.route(loc2DelData);
		ZoneEntity zoneLocDeletedDoc = (ZoneEntity) repositoryImpl
				.getGenericObject(cb_key, ZoneEntity.class);
		Assert.assertEquals(1, zoneLocDeletedDoc.getStoreIds().size());

	}

	@Test
	public void shouldUnmarshallAndProcessZoneDelMsgWhenStoreDocIsAlreadyPresent()
			throws Exception {

		String zone = "32";
		String cb_key = PriceConstants.ZONE_KEY + zone;
		ZoneMessageRouter zoneMessageRouter = new ZoneMessageRouter(
				zoneHandler, zoneEventHandler);

		String zoneGrpdata = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>ZONEMNT</family>\n"
				+ "<type>ZONEGROUPCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 08:31:35.467|342</ribmessageID>\n"
				+ "<publishTime>2015-10-06 08:31:35.467 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;TSLZoneGroupDesc&gt;&lt;zone_group_id&gt;4496&lt;/zone_group_id&gt;&lt;zone_group_name&gt;PS_ZoneGrp_1&lt;/zone_group_name&gt;&lt;TSLZoneGroupType&gt;&lt;zone_group_type&gt;2&lt;/zone_group_type&gt;&lt;/TSLZoneGroupType&gt;&lt;TSLZone&gt;&lt;zone_id&gt;4500&lt;/zone_id&gt;&lt;zone_name&gt;PS_Zone_01&lt;/zone_name&gt;&lt;base_ind&gt;1&lt;/base_ind&gt;&lt;country_code&gt;GB&lt;/country_code&gt;&lt;currency_code&gt;GBP&lt;/currency_code&gt;&lt;/TSLZone&gt;&lt;/TSLZoneGroupDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
				+ "</RibMessages>";

		zoneMessageRouter.route(zoneGrpdata);

		String data = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>ZONEMNT</family>\n"
				+ "<type>ZONECRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 14:02:25.155|358</ribmessageID>\n"
				+ "<publishTime>2015-10-06 14:02:25.155 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;TSLZoneGroupDesc&gt;&lt;zone_group_id&gt;4496&lt;/zone_group_id&gt;&lt;TSLZone&gt;&lt;zone_id&gt;32&lt;/zone_id&gt;&lt;zone_name&gt;test&lt;/zone_name&gt;&lt;base_ind&gt;0&lt;/base_ind&gt;&lt;country_code&gt;GB&lt;/country_code&gt;&lt;currency_code&gt;GBP&lt;/currency_code&gt;&lt;/TSLZone&gt;&lt;/TSLZoneGroupDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
				+ "</RibMessages>";

		zoneMessageRouter.route(data);
		Assert.assertNotNull(repositoryImpl.getGenericObject(cb_key,
				ZoneEntity.class));

		String locCreData = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>ZONEMNT</family>\n"
				+ "<type>ZONELOCCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 14:02:25.155|358</ribmessageID>\n"
				+ "<publishTime>2015-10-06 14:02:25.155 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;TSLZoneGroupDesc&gt;&lt;zone_group_id&gt;4496&lt;/zone_group_id&gt;&lt;TSLZone&gt;&lt;zone_id&gt;32&lt;/zone_id&gt;&lt;TSLZoneLoc&gt;&lt;loc&gt;2131&lt;/loc&gt;&lt;loc_type&gt;0&lt;/loc_type&gt;&lt;/TSLZoneLoc&gt;&lt;/TSLZone&gt;&lt;/TSLZoneGroupDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
				+ "</RibMessages>";

		zoneMessageRouter.route(locCreData);

		String dataDel = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>ZONEMNT</family>\n"
				+ "<type>ZONEDEL</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 14:22:59.857|370</ribmessageID>\n"
				+ "<publishTime>2015-10-06 14:22:59.857 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;TSLZoneGroupRef&gt;&lt;zone_group_id&gt;4496&lt;/zone_group_id&gt;&lt;TSLZoneRef&gt;&lt;zone_id&gt;32&lt;/zone_id&gt;&lt;/TSLZoneRef&gt;&lt;/TSLZoneGroupRef&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
				+ "</RibMessages>";

		zoneMessageRouter.route(dataDel);
		Assert.assertNull(repositoryImpl.getGenericObject(cb_key,
				ZoneEntity.class));

		Store storeDoc = (Store) repositoryImpl.getGenericObject(
				"STORE_2131", Store.class);
		Assert.assertEquals(Optional.absent(), storeDoc.getPromoZoneId());
	}

	@Test
	public void shouldUnMarshallAndProcessZoneDelMsgForPriceZoneWhenStoreDocIsAlreadyAndPresent()
			throws Exception {

		String zone = "33";
		String storeId = "2003";
		String zoneGrp = "4001";
		String cb_key = PriceConstants.ZONE_KEY + zone;
		String loc_key = PriceConstants.STORE_KEY + storeId;
		String grp_key = PriceConstants.ZONE_GRP_KEY + zoneGrp;

		Map zoneDataMap = new HashMap();
		Map zoneGrpDataMap = new HashMap();
		ZoneMessageRouter zoneMessageRouter = new ZoneMessageRouter(
				zoneHandler, zoneEventHandler);

		zoneDataMap.put("zoneGroupId", "4001");
		zoneDataMap.put("zoneGroupName", "PS_ZoneGrp_4001");
		zoneDataMap.put("zoneGroupType", "1");

		List<Map> zoneRefList = new ArrayList<Map>();
		Map zoneInfoMap = new HashMap();
		zoneInfoMap.put("zoneId", "33");
		zoneInfoMap.put("zoneName", "zone_33");
		zoneInfoMap.put("baseInd", "1");
		zoneInfoMap.put("currency", "GBP");
		zoneInfoMap.put("countryId", "GB");
		zoneInfoMap.put("offerPrefix", "A");
		zoneRefList.add(zoneInfoMap);
		zoneDataMap.put("zoneRefs", zoneRefList);

		zoneGrpDataMap.put("zoneGroupId", "4001");
		zoneGrpDataMap.put("zoneGroupName", "PS_ZoneGrp_4001");
		zoneGrpDataMap.put("zoneGroupType", "1");

		List<String> storeIds = new LinkedList<String>();
		List<String> zoneIds = new LinkedList<String>();
		zoneIds.add("33");

		ZoneGrpEntity zoneGrpEntityBefore = createZoneGroupEntity(
				zoneGrpDataMap, zoneIds);
		storeIds.add("2003");
		ZoneEntity zoneEntityBefore = createZoneEntity(zoneDataMap, storeIds);

		Map storeMap = new HashMap();
		storeMap.put("storeId", "2003");
		storeMap.put("priceZoneId", 33);
		storeMap.put("promoZoneId", 35);
		storeMap.put("clearanceZoneId", 88);
		storeMap.put("currency", "GBP");
		storeMap.put("countryId", "GB");

		Store storeEntityBefore = createStoreEntity(storeMap);

		zoneWriter.insertZoneGrpData(grp_key, zoneGrpEntityBefore);
		zoneWriter.insertZoneData(cb_key, zoneEntityBefore);
		zoneWriter.insertStoreData(loc_key, storeEntityBefore);

		String dataDel = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>ZONEMNT</family>\n"
				+ "<type>ZONEDEL</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 14:22:59.857|370</ribmessageID>\n"
				+ "<publishTime>2015-10-06 14:22:59.857 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;TSLZoneGroupRef&gt;&lt;zone_group_id&gt;4001&lt;/zone_group_id&gt;&lt;TSLZoneRef&gt;&lt;zone_id&gt;33&lt;/zone_id&gt;&lt;/TSLZoneRef&gt;&lt;/TSLZoneGroupRef&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
				+ "</RibMessages>";

		zoneMessageRouter.route(dataDel);

		Map storeMapFor2ndLoc = new HashMap();
		storeMapFor2ndLoc.put("storeId", "2003");
		storeMapFor2ndLoc.put("priceZoneId", -1);
		storeMapFor2ndLoc.put("promoZoneId", 35);
		storeMapFor2ndLoc.put("clearanceZoneId", 88);
		storeMapFor2ndLoc.put("currency", "GBP");
		storeMapFor2ndLoc.put("countryId", "GB");

		Store expectedStoreEntity = createStoreEntity(storeMapFor2ndLoc);

		ZoneEntity actualZoneEntity = (ZoneEntity) repositoryImpl
				.getGenericObject(cb_key, ZoneEntity.class);
		Assert.assertNull(actualZoneEntity);

		Store actualStoreEntity = (Store) repositoryImpl.getGenericObject(
				loc_key, Store.class);
		Assert.assertNotNull(actualStoreEntity);
		Assert.assertEquals(expectedStoreEntity.toString(),
				actualStoreEntity.toString());
	}

	@Test
	public void shouldUnMarshallAndProcessZoneDelMsgForPromoZoneWhenStoreDocIsAlreadyPresent()
			throws Exception {

		String zone = "36";
		String storeId = "2006";
		String zoneGrp = "4004";
		String cb_key = PriceConstants.ZONE_KEY + zone;
		String loc_key = PriceConstants.STORE_KEY + storeId;
		String grp_key = PriceConstants.ZONE_GRP_KEY + zoneGrp;

		Map zoneDataMap = new HashMap();
		Map zoneGrpDataMap = new HashMap();
		ZoneMessageRouter zoneMessageRouter = new ZoneMessageRouter(
				zoneHandler, zoneEventHandler);

		zoneDataMap.put("zoneGroupId", "4004");
		zoneDataMap.put("zoneGroupName", "PS_ZoneGrp_4004");
		zoneDataMap.put("zoneGroupType", "2");

		List<Map> zoneRefList = new ArrayList<Map>();
		Map zoneInfoMap = new HashMap();
		zoneInfoMap.put("zoneId", "36");
		zoneInfoMap.put("zoneName", "zone_36");
		zoneInfoMap.put("baseInd", "1");
		zoneInfoMap.put("currency", "GBP");
		zoneInfoMap.put("countryId", "GB");
		zoneInfoMap.put("offerPrefix", "A");
		zoneRefList.add(zoneInfoMap);
		zoneDataMap.put("zoneRefs", zoneRefList);

		zoneGrpDataMap.put("zoneGroupId", "4004");
		zoneGrpDataMap.put("zoneGroupName", "PS_ZoneGrp_4004");
		zoneGrpDataMap.put("zoneGroupType", "2");

		List<String> storeIds = new LinkedList<String>();
		List<String> zoneIds = new LinkedList<String>();
		zoneIds.add("36");
		ZoneGrpEntity zoneGrpEntityBefore = createZoneGroupEntity(
				zoneGrpDataMap, zoneIds);
		storeIds.add("2006");
		ZoneEntity zoneEntityBefore = createZoneEntity(zoneDataMap, storeIds);

		Map storeMap = new HashMap();
		storeMap.put("storeId", "2006");
		storeMap.put("priceZoneId", 11);
		storeMap.put("promoZoneId", 36);
		storeMap.put("clearanceZoneId", 87);
		storeMap.put("currency", "GBP");
		storeMap.put("countryId", "GB");

		Store storeEntityBefore = createStoreEntity(storeMap);

		zoneWriter.insertZoneGrpData(grp_key, zoneGrpEntityBefore);
		zoneWriter.insertZoneData(cb_key, zoneEntityBefore);
		zoneWriter.insertStoreData(loc_key, storeEntityBefore);

		String dataDel = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>ZONEMNT</family>\n"
				+ "<type>ZONEDEL</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 14:22:59.857|370</ribmessageID>\n"
				+ "<publishTime>2015-10-06 14:22:59.857 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;TSLZoneGroupRef&gt;&lt;zone_group_id&gt;4004&lt;/zone_group_id&gt;&lt;TSLZoneRef&gt;&lt;zone_id&gt;36&lt;/zone_id&gt;&lt;/TSLZoneRef&gt;&lt;/TSLZoneGroupRef&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
				+ "</RibMessages>";

		zoneMessageRouter.route(dataDel);

		Map storeMapFor2ndLoc = new HashMap();
		storeMapFor2ndLoc.put("storeId", "2006");
		storeMapFor2ndLoc.put("priceZoneId", 11);
		storeMapFor2ndLoc.put("promoZoneId", -1);
		storeMapFor2ndLoc.put("clearanceZoneId", 87);
		storeMapFor2ndLoc.put("currency", "GBP");
		storeMapFor2ndLoc.put("countryId", "GB");

		Store expectedStoreEntity = createStoreEntity(storeMapFor2ndLoc);

		ZoneEntity actualZoneEntity = (ZoneEntity) repositoryImpl
				.getGenericObject(cb_key, ZoneEntity.class);
		Assert.assertNull(actualZoneEntity);

		Store actualStoreEntity = (Store) repositoryImpl.getGenericObject(
				loc_key, Store.class);
		Assert.assertNotNull(actualStoreEntity);
		Assert.assertEquals(expectedStoreEntity.toString(),
				actualStoreEntity.toString());
	}

	@Test
	public void shouldUnMarshallAndProcessZoneDelMsgForClrZoneWhenStoreDocIsAlreadyAndPresent()
			throws Exception {

		String zone = "89";
		String storeId = "2004";
		String zoneGrp = "4002";
		String cb_key = PriceConstants.ZONE_KEY + zone;
		String loc_key = PriceConstants.STORE_KEY + storeId;
		String grp_key = PriceConstants.ZONE_GRP_KEY + zoneGrp;

		Map zoneDataMap = new HashMap();
		Map zoneGrpDataMap = new HashMap();
		ZoneMessageRouter zoneMessageRouter = new ZoneMessageRouter(
				zoneHandler, zoneEventHandler);

		zoneDataMap.put("zoneGroupId", "4002");
		zoneDataMap.put("zoneGroupName", "PS_ZoneGrp_4002");
		zoneDataMap.put("zoneGroupType", "3");

		List<Map> zoneRefList = new ArrayList<Map>();
		Map zoneInfoMap = new HashMap();
		zoneInfoMap.put("zoneId", "89");
		zoneInfoMap.put("zoneName", "zone_89");
		zoneInfoMap.put("baseInd", "1");
		zoneInfoMap.put("currency", "GBP");
		zoneInfoMap.put("countryId", "GB");
		zoneInfoMap.put("offerPrefix", "A");
		zoneRefList.add(zoneInfoMap);
		zoneDataMap.put("zoneRefs", zoneRefList);

		zoneGrpDataMap.put("zoneGroupId", "4002");
		zoneGrpDataMap.put("zoneGroupName", "PS_ZoneGrp_4002");
		zoneGrpDataMap.put("zoneGroupType", "3");

		List<String> storeIds = new LinkedList<String>();
		List<String> zoneIds = new LinkedList<String>();
		zoneIds.add("89");
		ZoneGrpEntity zoneGrpEntityBefore = createZoneGroupEntity(
				zoneGrpDataMap, zoneIds);
		storeIds.add("2004");
		ZoneEntity zoneEntityBefore = createZoneEntity(zoneDataMap, storeIds);

		Map storeMap = new HashMap();
		storeMap.put("storeId", "2004");
		storeMap.put("priceZoneId", 55);
		storeMap.put("promoZoneId", 35);
		storeMap.put("clearanceZoneId", 89);
		storeMap.put("currency", "GBP");
		storeMap.put("countryId", "GB");

		Store storeEntityBefore = createStoreEntity(storeMap);

		zoneWriter.insertZoneGrpData(grp_key, zoneGrpEntityBefore);
		zoneWriter.insertZoneData(cb_key, zoneEntityBefore);
		zoneWriter.insertStoreData(loc_key, storeEntityBefore);

		String dataDel = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>ZONEMNT</family>\n"
				+ "<type>ZONEDEL</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 14:22:59.857|370</ribmessageID>\n"
				+ "<publishTime>2015-10-06 14:22:59.857 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;TSLZoneGroupRef&gt;&lt;zone_group_id&gt;4001&lt;/zone_group_id&gt;&lt;TSLZoneRef&gt;&lt;zone_id&gt;89&lt;/zone_id&gt;&lt;/TSLZoneRef&gt;&lt;/TSLZoneGroupRef&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
				+ "</RibMessages>";

		zoneMessageRouter.route(dataDel);

		Map storeMapFor2ndLoc = new HashMap();
		storeMapFor2ndLoc.put("storeId", "2004");
		storeMapFor2ndLoc.put("priceZoneId", 55);
		storeMapFor2ndLoc.put("promoZoneId", 35);
		storeMapFor2ndLoc.put("clearanceZoneId", -1);
		storeMapFor2ndLoc.put("currency", "GBP");
		storeMapFor2ndLoc.put("countryId", "GB");

		Store expectedStoreEntity = createStoreEntity(storeMapFor2ndLoc);

		ZoneEntity actualZoneEntity = (ZoneEntity) repositoryImpl
				.getGenericObject(cb_key, ZoneEntity.class);
		Assert.assertNull(actualZoneEntity);

		Store actualStoreEntity = (Store) repositoryImpl.getGenericObject(
				loc_key, Store.class);
		Assert.assertNotNull(actualStoreEntity);
		Assert.assertEquals(expectedStoreEntity.toString(),
				actualStoreEntity.toString());
	}

	@Test
	public void shouldUnMarshallAndProcessZoneModMsgIfZoneDocIsAlreadyPresent()
			throws Exception {

		String zone = "38";
		String zoneGrp = "4005";
		String cb_key = PriceConstants.ZONE_KEY + zone;
		String grp_key = PriceConstants.ZONE_GRP_KEY + zoneGrp;

		Map zoneDataMap = new HashMap();
		Map zoneDataMap1 = new HashMap();
		Map zoneGrpDataMap = new HashMap();
		ZoneMessageRouter zoneMessageRouter = new ZoneMessageRouter(
				zoneHandler, zoneEventHandler);

		zoneDataMap.put("zoneGroupId", "4005");
		zoneDataMap.put("zoneGroupName", "PS_ZoneGrp_4005");
		zoneDataMap.put("zoneGroupType", "2");

		List<Map> zoneRefList = new ArrayList<Map>();
		Map zoneInfoMap = new HashMap();
		zoneInfoMap.put("zoneId", "38");
		zoneInfoMap.put("zoneName", "zone_38");
		zoneInfoMap.put("baseInd", "0");
		zoneInfoMap.put("currency", "GBP");
		zoneInfoMap.put("countryId", "GB");
		zoneInfoMap.put("offerPrefix", "A");
		zoneRefList.add(zoneInfoMap);
		zoneDataMap.put("zoneRefs", zoneRefList);

		zoneGrpDataMap.put("zoneGroupId", "4005");
		zoneGrpDataMap.put("zoneGroupName", "PS_ZoneGrp_4005");
		zoneGrpDataMap.put("zoneGroupType", "2");

		List<String> storeIds = new LinkedList<String>();
		List<String> zoneIds = new LinkedList<String>();
		zoneIds.add("38");

		ZoneGrpEntity zoneGrpEntityBefore = createZoneGroupEntity(
				zoneGrpDataMap, zoneIds);
		ZoneEntity zoneEntityBefore = createZoneEntity(zoneDataMap, storeIds);

		zoneWriter.insertZoneGrpData(grp_key, zoneGrpEntityBefore);
		zoneWriter.insertZoneData(cb_key, zoneEntityBefore);

		String modData = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>ZONEMNT</family>\n"
				+ "<type>ZONEMOD</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 14:02:25.155|358</ribmessageID>\n"
				+ "<publishTime>2015-10-06 14:02:25.155 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;TSLZoneGroupDesc&gt;&lt;zone_group_id&gt;4005&lt;/zone_group_id&gt;&lt;TSLZone&gt;&lt;zone_id&gt;38&lt;/zone_id&gt;&lt;zone_name&gt;PS_Zone_38_update&lt;/zone_name&gt;&lt;base_ind&gt;1&lt;/base_ind&gt;&lt;country_code&gt;GB&lt;/country_code&gt;&lt;currency_code&gt;GBP&lt;/currency_code&gt;&lt;/TSLZone&gt;&lt;/TSLZoneGroupDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
				+ "</RibMessages>";

		zoneMessageRouter.route(modData);

		zoneDataMap1.put("zoneGroupId", "4005");
		zoneDataMap1.put("zoneGroupName", "PS_ZoneGrp_4005");
		zoneDataMap1.put("zoneGroupType", "2");

		List<Map> zoneRefList1 = new ArrayList<Map>();
		Map zoneInfoMap1 = new HashMap();
		zoneInfoMap1.put("zoneId", "38");
		zoneInfoMap1.put("zoneName", "PS_Zone_38_update");
		zoneInfoMap1.put("baseInd", "1");
		zoneInfoMap1.put("currency", "GBP");
		zoneInfoMap1.put("countryId", "GB");
		zoneInfoMap1.put("offerPrefix", "A");
		zoneRefList1.add(zoneInfoMap1);
		zoneDataMap1.put("zoneRefs", zoneRefList1);

		ZoneEntity expectedZoneEntity = createZoneEntity(zoneDataMap1, storeIds);
		ZoneEntity actualZoneEntity = (ZoneEntity) repositoryImpl
				.getGenericObject(cb_key, ZoneEntity.class);
		Assert.assertNotNull(actualZoneEntity);
		actualZoneEntity.setLastUpdateDate("lastUpdatedDate");
		Assert.assertEquals(expectedZoneEntity.toString(),
				actualZoneEntity.toString());

	}

	@Test
	public void shouldUnMarshallAndProcessStoreDelForClearanceZoneMsg()
			throws Exception {

		String zone = "89";
		String storeId = "2004";
		String zoneGrp = "4002";
		String cb_key = PriceConstants.ZONE_KEY + zone;
		String loc_key = PriceConstants.STORE_KEY + storeId;
		String grp_key = PriceConstants.ZONE_GRP_KEY + zoneGrp;

		Map zoneDataMap = new HashMap();
		Map zoneGrpDataMap = new HashMap();
		ZoneMessageRouter zoneMessageRouter = new ZoneMessageRouter(
				zoneHandler, zoneEventHandler);

		zoneDataMap.put("zoneGroupId", "4002");
		zoneDataMap.put("zoneGroupName", "PS_ZoneGrp_4002");
		zoneDataMap.put("zoneGroupType", "3");

		List<Map> zoneRefList = new ArrayList<Map>();
		Map zoneInfoMap = new HashMap();
		zoneInfoMap.put("zoneId", "89");
		zoneInfoMap.put("zoneName", "zone_89");
		zoneInfoMap.put("baseInd", "1");
		zoneInfoMap.put("currency", "GBP");
		zoneInfoMap.put("countryId", "GB");
		zoneInfoMap.put("offerPrefix", "A");
		zoneRefList.add(zoneInfoMap);
		zoneDataMap.put("zoneRefs", zoneRefList);

		zoneGrpDataMap.put("zoneGroupId", "4002");
		zoneGrpDataMap.put("zoneGroupName", "PS_ZoneGrp_4002");
		zoneGrpDataMap.put("zoneGroupType", "3");

		List<String> storeIds = new LinkedList<String>();
		List<String> zoneIds = new LinkedList<String>();
		zoneIds.add("89");
		ZoneGrpEntity zoneGrpEntityBefore = createZoneGroupEntity(
				zoneGrpDataMap, zoneIds);
		storeIds.add("2004");
		ZoneEntity zoneEntityBefore = createZoneEntity(zoneDataMap, storeIds);

		Map storeMap = new HashMap();
		storeMap.put("storeId", "2004");
		storeMap.put("priceZoneId", 55);
		storeMap.put("promoZoneId", 35);
		storeMap.put("clearanceZoneId", 89);
		storeMap.put("currency", "GBP");
		storeMap.put("countryId", "GB");

		Store storeEntityBefore = createStoreEntity(storeMap);

		zoneWriter.insertZoneGrpData(grp_key, zoneGrpEntityBefore);
		zoneWriter.insertZoneData(cb_key, zoneEntityBefore);
		zoneWriter.insertStoreData(loc_key, storeEntityBefore);

		String dataDel = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>ZONEMNT</family>\n"
				+ "<type>ZONELOCDEL</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 14:22:59.857|370</ribmessageID>\n"
				+ "<publishTime>2015-10-06 14:22:59.857 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;TSLZoneGroupRef&gt;&lt;zone_group_id&gt;4002&lt;/zone_group_id&gt;&lt;TSLZoneRef&gt;&lt;zone_id&gt;89&lt;/zone_id&gt;&lt;TSLZoneLocRef&gt;&lt;loc&gt;2004&lt;/loc&gt;&lt;loc_type&gt;0&lt;/loc_type&gt;&lt;/TSLZoneLocRef&gt;&lt;/TSLZoneRef&gt;&lt;/TSLZoneGroupRef&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
				+ "</RibMessages>";

		zoneMessageRouter.route(dataDel);

		ZoneEntity actualZoneEntity = (ZoneEntity) repositoryImpl
				.getGenericObject(cb_key, ZoneEntity.class);
		Assert.assertNotNull(actualZoneEntity);

		Store actualStoreEntity = (Store) repositoryImpl.getGenericObject(
				loc_key, Store.class);
		Assert.assertNotNull(actualStoreEntity);
		Assert.assertEquals(Optional.absent(),
				actualStoreEntity.getClearanceZoneId());
	}

	@Test
	public void shouldUnMarshallAndProcessStoreDelForPromoZoneMsg()
			throws Exception {

		String zone = "35";
		String storeId = "2004";
		String zoneGrp = "4002";
		String cb_key = PriceConstants.ZONE_KEY + zone;
		String loc_key = PriceConstants.STORE_KEY + storeId;
		String grp_key = PriceConstants.ZONE_GRP_KEY + zoneGrp;

		Map zoneDataMap = new HashMap();
		Map zoneGrpDataMap = new HashMap();
		ZoneMessageRouter zoneMessageRouter = new ZoneMessageRouter(
				zoneHandler, zoneEventHandler);

		zoneDataMap.put("zoneGroupId", "4002");
		zoneDataMap.put("zoneGroupName", "PS_ZoneGrp_4002");
		zoneDataMap.put("zoneGroupType", "1");

		List<Map> zoneRefList = new ArrayList<Map>();
		Map zoneInfoMap = new HashMap();
		zoneInfoMap.put("zoneId", "35");
		zoneInfoMap.put("zoneName", "zone_35");
		zoneInfoMap.put("baseInd", "1");
		zoneInfoMap.put("currency", "GBP");
		zoneInfoMap.put("countryId", "GB");
		zoneInfoMap.put("offerPrefix", "A");
		zoneRefList.add(zoneInfoMap);
		zoneDataMap.put("zoneRefs", zoneRefList);

		zoneGrpDataMap.put("zoneGroupId", "4002");
		zoneGrpDataMap.put("zoneGroupName", "PS_ZoneGrp_4002");
		zoneGrpDataMap.put("zoneGroupType", "2");

		List<String> storeIds = new LinkedList<String>();
		List<String> zoneIds = new LinkedList<String>();
		zoneIds.add("35");
		ZoneGrpEntity zoneGrpEntityBefore = createZoneGroupEntity(
				zoneGrpDataMap, zoneIds);
		storeIds.add("2004");
		ZoneEntity zoneEntityBefore = createZoneEntity(zoneDataMap, storeIds);

		Map storeMap = new HashMap();
		storeMap.put("storeId", "2004");
		storeMap.put("priceZoneId", 55);
		storeMap.put("promoZoneId", 35);
		storeMap.put("clearanceZoneId", 89);
		storeMap.put("currency", "GBP");
		storeMap.put("countryId", "GB");

		Store storeEntityBefore = createStoreEntity(storeMap);

		zoneWriter.insertZoneGrpData(grp_key, zoneGrpEntityBefore);
		zoneWriter.insertZoneData(cb_key, zoneEntityBefore);
		zoneWriter.insertStoreData(loc_key, storeEntityBefore);

		String dataDel = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>ZONEMNT</family>\n"
				+ "<type>ZONELOCDEL</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 14:22:59.857|370</ribmessageID>\n"
				+ "<publishTime>2015-10-06 14:22:59.857 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;TSLZoneGroupRef&gt;&lt;zone_group_id&gt;4002&lt;/zone_group_id&gt;&lt;TSLZoneRef&gt;&lt;zone_id&gt;35&lt;/zone_id&gt;&lt;TSLZoneLocRef&gt;&lt;loc&gt;2004&lt;/loc&gt;&lt;loc_type&gt;0&lt;/loc_type&gt;&lt;/TSLZoneLocRef&gt;&lt;/TSLZoneRef&gt;&lt;/TSLZoneGroupRef&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
				+ "</RibMessages>";

		zoneMessageRouter.route(dataDel);

		ZoneEntity actualZoneEntity = (ZoneEntity) repositoryImpl
				.getGenericObject(cb_key, ZoneEntity.class);
		Assert.assertNotNull(actualZoneEntity);

		Store actualStoreEntity = (Store) repositoryImpl.getGenericObject(
				loc_key, Store.class);
		Assert.assertNotNull(actualStoreEntity);
		Assert.assertEquals(Optional.absent(),
				actualStoreEntity.getPromoZoneId());
	}

	@Test
	public void shouldUnMarshallAndProcessStoreDelForPriceZoneMsg()
			throws Exception {

		String zone = "55";
		String storeId = "2004";
		String zoneGrp = "4002";
		String cb_key = PriceConstants.ZONE_KEY + zone;
		String loc_key = PriceConstants.STORE_KEY + storeId;
		String grp_key = PriceConstants.ZONE_GRP_KEY + zoneGrp;

		Map zoneDataMap = new HashMap();
		Map zoneGrpDataMap = new HashMap();
		ZoneMessageRouter zoneMessageRouter = new ZoneMessageRouter(
				zoneHandler, zoneEventHandler);

		zoneDataMap.put("zoneGroupId", "4002");
		zoneDataMap.put("zoneGroupName", "PS_ZoneGrp_4002");
		zoneDataMap.put("zoneGroupType", "1");

		List<Map> zoneRefList = new ArrayList<Map>();
		Map zoneInfoMap = new HashMap();
		zoneInfoMap.put("zoneId", "55");
		zoneInfoMap.put("zoneName", "zone_55");
		zoneInfoMap.put("baseInd", "1");
		zoneInfoMap.put("currency", "GBP");
		zoneInfoMap.put("countryId", "GB");
		zoneInfoMap.put("offerPrefix", "A");
		zoneRefList.add(zoneInfoMap);
		zoneDataMap.put("zoneRefs", zoneRefList);

		zoneGrpDataMap.put("zoneGroupId", "4002");
		zoneGrpDataMap.put("zoneGroupName", "PS_ZoneGrp_4002");
		zoneGrpDataMap.put("zoneGroupType", "1");

		List<String> storeIds = new LinkedList<String>();
		List<String> zoneIds = new LinkedList<String>();
		zoneIds.add("55");

		ZoneGrpEntity zoneGrpEntityBefore = createZoneGroupEntity(
				zoneGrpDataMap, zoneIds);
		storeIds.add("2004");
		ZoneEntity zoneEntityBefore = createZoneEntity(zoneDataMap, storeIds);

		Map storeMap = new HashMap();
		storeMap.put("storeId", "2004");
		storeMap.put("priceZoneId", 55);
		storeMap.put("promoZoneId", 35);
		storeMap.put("clearanceZoneId", 89);
		storeMap.put("currency", "GBP");
		storeMap.put("countryId", "GB");

		Store storeEntityBefore = createStoreEntity(storeMap);

		zoneWriter.insertZoneGrpData(grp_key, zoneGrpEntityBefore);
		zoneWriter.insertZoneData(cb_key, zoneEntityBefore);
		zoneWriter.insertStoreData(loc_key, storeEntityBefore);

		String dataDel = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>ZONEMNT</family>\n"
				+ "<type>ZONELOCDEL</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 14:22:59.857|370</ribmessageID>\n"
				+ "<publishTime>2015-10-06 14:22:59.857 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;TSLZoneGroupRef&gt;&lt;zone_group_id&gt;4002&lt;/zone_group_id&gt;&lt;TSLZoneRef&gt;&lt;zone_id&gt;55&lt;/zone_id&gt;&lt;TSLZoneLocRef&gt;&lt;loc&gt;2004&lt;/loc&gt;&lt;loc_type&gt;0&lt;/loc_type&gt;&lt;/TSLZoneLocRef&gt;&lt;/TSLZoneRef&gt;&lt;/TSLZoneGroupRef&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
				+ "</RibMessages>";

		zoneMessageRouter.route(dataDel);

		ZoneEntity actualZoneEntity = (ZoneEntity) repositoryImpl
				.getGenericObject(cb_key, ZoneEntity.class);
		Assert.assertNotNull(actualZoneEntity);

		Store actualStoreEntity = (Store) repositoryImpl.getGenericObject(
				loc_key, Store.class);
		Assert.assertNotNull(actualStoreEntity);
		Assert.assertEquals(Optional.absent(),
				actualStoreEntity.getPriceZoneId());
	}

	@Test
	public void shouldUnMarshallAndProcessZoneGRPModMsg() throws Exception {

		Map zoneDataMap = new HashMap();
		Map zoneGrpDataMap = new HashMap();
		String zone = "39";
		String zoneGrpId = "4007";
		String cb_key = PriceConstants.ZONE_KEY + zone;
		String zoneGrpKey = PriceConstants.ZONE_GRP_KEY + zoneGrpId;
		ZoneMessageRouter zoneMessageRouter = new ZoneMessageRouter(
				zoneHandler, zoneEventHandler);

		zoneDataMap.put("zoneGroupId", "4007");
		zoneDataMap.put("zoneGroupName", "PS_ZoneGrp_4007");
		zoneDataMap.put("zoneGroupType", "2");

		List<Map> zoneRefList = new ArrayList<Map>();
		Map zoneInfoMap = new HashMap();
		zoneInfoMap.put("zoneId", "39");
		zoneInfoMap.put("zoneName", "zone_39");
		zoneInfoMap.put("baseInd", "1");
		zoneInfoMap.put("currency", "GBP");
		zoneInfoMap.put("countryId", "GB");
		zoneInfoMap.put("offerPrefix", "A");
		zoneRefList.add(zoneInfoMap);
		zoneDataMap.put("zoneRefs", zoneRefList);

		zoneGrpDataMap.put("zoneGroupId", "4007");
		zoneGrpDataMap.put("zoneGroupName", "PS_ZoneGrp_4007");
		zoneGrpDataMap.put("zoneGroupType", "2");

		List storeIds = new LinkedList<String>();
		List<String> zoneIds = new LinkedList<String>();
		zoneIds.add("39");

		ZoneEntity beforeProcessingZoneEntity = createZoneEntity(zoneDataMap,
				storeIds);
		ZoneGrpEntity beforeProcessingZoneGrpDocCRE = createZoneGroupEntity(
				zoneGrpDataMap, zoneIds);

		zoneGrpDataMap.put("zoneGroupId", "4007");
		zoneGrpDataMap.put("zoneGroupName", "PS_Zone_grp_4007_update");
		zoneGrpDataMap.put("zoneGroupType", "2");
		ZoneGrpEntity expectedZoneGrpEntity = createZoneGroupEntity(
				zoneGrpDataMap, zoneIds);

		/*
		 * ZoneGrpEntity beforeProcessingzoneGrpDocCRE = (ZoneGrpEntity)
		 * productRepository .getGenericObject(zoneGrpKey, ZoneGrpEntity.class);
		 */

		zoneWriter.insertZoneGrpData("ZONEGROUP_4007",
				beforeProcessingZoneGrpDocCRE);
		zoneWriter.insertZoneData(cb_key, beforeProcessingZoneEntity);

		String zoneGrpModData = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>ZONEMNT</family>\n"
				+ "<type>ZONEGROUPMOD</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 08:31:35.467|342</ribmessageID>\n"
				+ "<publishTime>2015-10-06 08:31:35.467 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;TSLZoneGroupDesc&gt;&lt;zone_group_id&gt;4007&lt;/zone_group_id&gt;&lt;zone_group_name&gt;PS_Zone_grp_4007_update&lt;/zone_group_name&gt;&lt;TSLZone&gt;&lt;zone_id&gt;37&lt;/zone_id&gt;&lt;zone_name&gt;PS_Zone_37_update&lt;/zone_name&gt;&lt;base_ind&gt;1&lt;/base_ind&gt;&lt;country_code&gt;GB&lt;/country_code&gt;&lt;currency_code&gt;GBP&lt;/currency_code&gt;&lt;/TSLZone&gt;&lt;/TSLZoneGroupDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
				+ "</RibMessages>";

		zoneMessageRouter.route(zoneGrpModData);

		ZoneEntity zoneDocMod = (ZoneEntity) repositoryImpl
				.getGenericObject(cb_key, ZoneEntity.class);

		Assert.assertNotNull(zoneDocMod);

		zoneDocMod.setCreatedById("RPM");
		zoneDocMod.setCreatedDate("createdDate");
		zoneDocMod.setLastUpdateDate("lastUpdatedDate");

		ZoneGrpEntity actualZoneGrpDoc = (ZoneGrpEntity) repositoryImpl
				.getGenericObject(PriceConstants.ZONE_GRP_KEY + "4007",
						ZoneGrpEntity.class);
		actualZoneGrpDoc.setLastUpdateDate("lastUpdatedDate");
		actualZoneGrpDoc.setCreatedDate("createdDate");
		Assert.assertEquals(expectedZoneGrpEntity.toString(),
				actualZoneGrpDoc.toString());
	}

	@Test
	public void shouldUnMarshallAndProcessZoneGRPCreForROI() throws Exception {

		Map zoneDataMap = new HashMap();
		Map zoneGrpDataMap = new HashMap();
		String zone = "77";
		String zoneGrpId = "4008";
		String cb_key = PriceConstants.ZONE_KEY + zone;
		String zoneGrpKey = PriceConstants.ZONE_GRP_KEY + zoneGrpId;
		ZoneMessageRouter zoneMessageRouter = new ZoneMessageRouter(
				zoneHandler, zoneEventHandler);

		String zoneGrpdata = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>ZONEMNT</family>\n"
				+ "<type>ZONEGROUPCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 08:31:35.467|342</ribmessageID>\n"
				+ "<publishTime>2015-10-06 08:31:35.467 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;TSLZoneGroupDesc&gt;&lt;zone_group_id&gt;4008&lt;/zone_group_id&gt;&lt;zone_group_name&gt;PS_ZoneGrp_4008&lt;/zone_group_name&gt;&lt;TSLZoneGroupType&gt;&lt;zone_group_type&gt;2&lt;/zone_group_type&gt;&lt;/TSLZoneGroupType&gt;&lt;TSLZone&gt;&lt;zone_id&gt;77&lt;/zone_id&gt;&lt;zone_name&gt;zone_30&lt;/zone_name&gt;&lt;base_ind&gt;1&lt;/base_ind&gt;&lt;country_code&gt;IE&lt;/country_code&gt;&lt;currency_code&gt;EUR&lt;/currency_code&gt;&lt;/TSLZone&gt;&lt;/TSLZoneGroupDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
				+ "</RibMessages>";

		zoneMessageRouter.route(zoneGrpdata);

		zoneDataMap.put("zoneGroupId", "4008");
		zoneDataMap.put("zoneGroupName", "PS_ZoneGrp_4008");
		zoneDataMap.put("zoneGroupType", "2");

		List<Map> zoneRefList = new ArrayList<Map>();
		Map zoneInfoMap = new HashMap();
		zoneInfoMap.put("zoneId", "77");
		zoneInfoMap.put("zoneName", "zone_30");
		zoneInfoMap.put("baseInd", "1");
		zoneInfoMap.put("currency", "EUR");
		zoneInfoMap.put("countryId", "IE");
		zoneInfoMap.put("offerPrefix", "R");
		zoneRefList.add(zoneInfoMap);
		zoneDataMap.put("zoneRefs", zoneRefList);

		zoneGrpDataMap.put("zoneGroupId", "4008");
		zoneGrpDataMap.put("zoneGroupName", "PS_ZoneGrp_4008");
		zoneGrpDataMap.put("zoneGroupType", "2");

		List storeIds = new LinkedList<String>();
		List<String> zoneIds = new LinkedList<String>();
		zoneIds.add("77");

		ZoneEntity expectedZoneEntity = createZoneEntity(zoneDataMap, storeIds);
		ZoneGrpEntity expectedZoneGrpEntity = createZoneGroupEntity(
				zoneGrpDataMap, zoneIds);

		ZoneGrpEntity zoneGrpDocCRE = (ZoneGrpEntity) repositoryImpl
				.getGenericObject(zoneGrpKey, ZoneGrpEntity.class);

		ZoneEntity zoneDocCRE = (ZoneEntity) repositoryImpl
				.getGenericObject(cb_key, ZoneEntity.class);

		Assert.assertNotNull(zoneGrpDocCRE);
		Assert.assertNotNull(zoneDocCRE);

		zoneGrpDocCRE.setCreatedById("RPM");
		zoneGrpDocCRE.setCreatedDate("createdDate");
		zoneGrpDocCRE.setLastUpdateDate("lastUpdatedDate");
		zoneGrpDocCRE.setLastUpdatedById("RPM");

		zoneDocCRE.setCreatedDate("createdDate");
		zoneDocCRE.setLastUpdateDate("lastUpdatedDate");

		Assert.assertEquals(expectedZoneGrpEntity.toString(),
				zoneGrpDocCRE.toString());
		Assert.assertEquals(expectedZoneEntity.toString(),
				zoneDocCRE.toString());
	}

	@Test
	public void shouldUnMarshallAndProcessLocCreMsgWhenZoneIsAvailableAndNoLocationInZoneDocForPricingZone()
			throws Exception {

		String zone = "30";
		String storeId = "2000";
		String zoneGrp = "4000";
		String cb_key = PriceConstants.ZONE_KEY + zone;
		String loc_key = PriceConstants.STORE_KEY + storeId;
		String grp_key = PriceConstants.ZONE_GRP_KEY + zoneGrp;

		Map zoneDataMap = new HashMap();
		Map zoneGrpDataMap = new HashMap();

		zoneDataMap.put("zoneGroupId", "4000");
		zoneDataMap.put("zoneGroupName", "PS_ZoneGrp_4000");
		zoneDataMap.put("zoneGroupType", "2");

		List<Map> zoneRefList = new ArrayList<Map>();
		Map zoneInfoMap = new HashMap();
		zoneInfoMap.put("zoneId", "30");
		zoneInfoMap.put("zoneName", "zone_30");
		zoneInfoMap.put("baseInd", "1");
		zoneInfoMap.put("currency", "GBP");
		zoneInfoMap.put("countryId", "GB");
		zoneInfoMap.put("offerPrefix", "A");
		zoneRefList.add(zoneInfoMap);
		zoneDataMap.put("zoneRefs", zoneRefList);

		zoneGrpDataMap.put("zoneGroupId", "4000");
		zoneGrpDataMap.put("zoneGroupName", "PS_ZoneGrp_4000");
		zoneGrpDataMap.put("zoneGroupType", "2");

		List<String> storeIds = new LinkedList<String>();
		List<String> zoneIds = new LinkedList<String>();
		zoneIds.add("30");
		ZoneEntity zoneEntity = createZoneEntity(zoneDataMap, storeIds);
		ZoneGrpEntity zoneGrpEntity = createZoneGroupEntity(zoneGrpDataMap,
				zoneIds);

		ZoneMessageRouter zoneMessageRouter = new ZoneMessageRouter(
				zoneHandler, zoneEventHandler);

		zoneWriter.insertZoneGrpData(grp_key, zoneGrpEntity);
		zoneWriter.insertZoneData(cb_key, zoneEntity);

		String locData = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>ZONEMNT</family>\n"
				+ "<type>ZONELOCCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 14:02:25.155|358</ribmessageID>\n"
				+ "<publishTime>2015-10-06 14:02:25.155 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;TSLZoneGroupDesc&gt;&lt;zone_group_id&gt;4000&lt;/zone_group_id&gt;&lt;TSLZone&gt;&lt;zone_id&gt;30&lt;/zone_id&gt;&lt;TSLZoneLoc&gt;&lt;loc&gt;2000&lt;/loc&gt;&lt;loc_type&gt;0&lt;/loc_type&gt;&lt;/TSLZoneLoc&gt;&lt;/TSLZone&gt;&lt;/TSLZoneGroupDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
				+ "</RibMessages>";

		zoneMessageRouter.route(locData);
		storeIds.add("2000");

		ZoneEntity expectedZoneEntity = createZoneEntity(zoneDataMap, storeIds);

		Map storeMap = new HashMap();
		storeMap.put("storeId", "2000");
		storeMap.put("priceZoneId", 30);
		storeMap.put("promoZoneId", -1);
		storeMap.put("clearanceZoneId", -1);
		storeMap.put("currency", "GBP");
		storeMap.put("countryId", "GB");

		Store expectedStoreEntity = createStoreEntity(storeMap);

		ZoneEntity actualEntity = (ZoneEntity) repositoryImpl
				.getGenericObject(cb_key, ZoneEntity.class);
		Assert.assertNotNull(actualEntity);
		actualEntity.setCreatedDate("createdDate");
		actualEntity.setLastUpdateDate("lastUpdatedDate");
		Assert.assertEquals(expectedZoneEntity.toString(),
				actualEntity.toString());
		Store actualStoreEntity = (Store) repositoryImpl.getGenericObject(
				loc_key, Store.class);

		Assert.assertNotNull(actualStoreEntity);
		Assert.assertEquals(expectedStoreEntity.toString(),
				actualStoreEntity.toString());
	}

	@Test
	public void shouldUnMarshallAndProcessLocCreMsgWhenZoneIsAvailableAndNoLocationInZoneDocForClearanceZone()
			throws Exception {

		String zone = "30";
		String storeId = "2000";
		String zoneGrp = "4000";
		String cb_key = PriceConstants.ZONE_KEY + zone;
		String loc_key = PriceConstants.STORE_KEY + storeId;
		String grp_key = PriceConstants.ZONE_GRP_KEY + zoneGrp;

		Map zoneDataMap = new HashMap();
		Map zoneGrpDataMap = new HashMap();

		zoneDataMap.put("zoneGroupId", "4000");
		zoneDataMap.put("zoneGroupName", "PS_ZoneGrp_4000");
		zoneDataMap.put("zoneGroupType", "0");

		List<Map> zoneRefList = new ArrayList<Map>();
		Map zoneInfoMap = new HashMap();
		zoneInfoMap.put("zoneId", "30");
		zoneInfoMap.put("zoneName", "zone_30");
		zoneInfoMap.put("baseInd", "1");
		zoneInfoMap.put("currency", "GBP");
		zoneInfoMap.put("countryId", "GB");
		zoneInfoMap.put("offerPrefix", "A");
		zoneRefList.add(zoneInfoMap);
		zoneDataMap.put("zoneRefs", zoneRefList);

		zoneGrpDataMap.put("zoneGroupId", "4000");
		zoneGrpDataMap.put("zoneGroupName", "PS_ZoneGrp_4000");
		zoneGrpDataMap.put("zoneGroupType", "0");

		List<String> storeIds = new LinkedList<String>();
		List<String> zoneIds = new LinkedList<String>();
		zoneIds.add("30");

		ZoneEntity zoneEntity = createZoneEntity(zoneDataMap, storeIds);
		ZoneGrpEntity zoneGrpEntity = createZoneGroupEntity(zoneGrpDataMap,
				zoneIds);

		ZoneMessageRouter zoneMessageRouter = new ZoneMessageRouter(
				zoneHandler, zoneEventHandler);

		zoneWriter.insertZoneGrpData(grp_key, zoneGrpEntity);
		zoneWriter.insertZoneData(cb_key, zoneEntity);

		String locData = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>ZONEMNT</family>\n"
				+ "<type>ZONELOCCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 14:02:25.155|358</ribmessageID>\n"
				+ "<publishTime>2015-10-06 14:02:25.155 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;TSLZoneGroupDesc&gt;&lt;zone_group_id&gt;4000&lt;/zone_group_id&gt;&lt;TSLZone&gt;&lt;zone_id&gt;30&lt;/zone_id&gt;&lt;TSLZoneLoc&gt;&lt;loc&gt;2000&lt;/loc&gt;&lt;loc_type&gt;0&lt;/loc_type&gt;&lt;/TSLZoneLoc&gt;&lt;/TSLZone&gt;&lt;/TSLZoneGroupDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
				+ "</RibMessages>";

		zoneMessageRouter.route(locData);
		storeIds.add("2000");

		ZoneEntity expectedZoneEntity = createZoneEntity(zoneDataMap, storeIds);

		Map storeMap = new HashMap();
		storeMap.put("storeId", "2000");
		storeMap.put("priceZoneId", -1);
		storeMap.put("promoZoneId", -1);
		storeMap.put("clearanceZoneId", 30);
		storeMap.put("currency", "GBP");
		storeMap.put("countryId", "GB");

		Store expectedStoreEntity = createStoreEntity(storeMap);

		ZoneEntity actualEntity = (ZoneEntity) repositoryImpl
				.getGenericObject(cb_key, ZoneEntity.class);
		Assert.assertNotNull(actualEntity);
		actualEntity.setCreatedDate("createdDate");
		actualEntity.setLastUpdateDate("lastUpdatedDate");
		Assert.assertEquals(expectedZoneEntity.toString(),
				actualEntity.toString());

		Store actualStoreEntity = (Store) repositoryImpl.getGenericObject(
				loc_key, Store.class);

		Assert.assertNotNull(actualStoreEntity);
		Assert.assertEquals(expectedStoreEntity.toString(),
				actualStoreEntity.toString());
	}

	@Test
	public void shouldUnMarshallAndProcessZoneGrpModMsgWhenZoneGrpIsAvailable()
			throws Exception {

		String zone = "30";
		String storeId = "2000";
		String zoneGrp = "4000";
		String cb_key = PriceConstants.ZONE_KEY + zone;
		String loc_key = PriceConstants.STORE_KEY + storeId;
		String grp_key = PriceConstants.ZONE_GRP_KEY + zoneGrp;

		Map zoneDataMap = new HashMap();
		Map zoneGrpDataMap = new HashMap();

		zoneDataMap.put("zoneGroupId", "4000");
		zoneDataMap.put("zoneGroupName", "PS_ZoneGrp_4000");
		zoneDataMap.put("zoneGroupType", "1");

		List<Map> zoneRefList = new ArrayList<Map>();
		Map zoneInfoMap = new HashMap();
		zoneInfoMap.put("zoneId", "30");
		zoneInfoMap.put("zoneName", "zone_30");
		zoneInfoMap.put("baseInd", "1");
		zoneInfoMap.put("currency", "GBP");
		zoneInfoMap.put("countryId", "GB");
		zoneInfoMap.put("offerPrefix", "A");
		zoneRefList.add(zoneInfoMap);
		zoneDataMap.put("zoneRefs", zoneRefList);

		zoneGrpDataMap.put("zoneGroupId", "4000");
		zoneGrpDataMap.put("zoneGroupName", "PS_ZoneGrp_4000");
		zoneGrpDataMap.put("zoneGroupType", "1");

		List<String> storeIds = new LinkedList<String>();
		List<String> zoneIds = new LinkedList<String>();
		zoneIds.add("30");

		ZoneEntity zoneEntity = createZoneEntity(zoneDataMap, storeIds);
		ZoneGrpEntity zoneGrpEntity = createZoneGroupEntity(zoneGrpDataMap,
				zoneIds);

		ZoneMessageRouter zoneMessageRouter = new ZoneMessageRouter(
				zoneHandler, zoneEventHandler);

		zoneWriter.insertZoneGrpData(grp_key, zoneGrpEntity);
		zoneWriter.insertZoneData(cb_key, zoneEntity);

		String locData = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>ZONEMNT</family>\n"
				+ "<type>ZONEGROUPMOD</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 14:02:25.155|358</ribmessageID>\n"
				+ "<publishTime>2015-10-06 14:02:25.155 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;TSLZoneGroupDesc&gt;&lt;zone_group_id&gt;4000&lt;/zone_group_id&gt;&lt;zone_group_name&gt;PS_Zone_1_update&lt;/zone_group_name&gt;&lt;TSLZone&gt;&lt;zone_id&gt;30&lt;/zone_id&gt;&lt;zone_name&gt;PS_Zone_01_update&lt;/zone_name&gt;&lt;base_ind&gt;0&lt;/base_ind&gt;&lt;country_code&gt;GB&lt;/country_code&gt;&lt;currency_code&gt;GBP&lt;/currency_code&gt;&lt;/TSLZone&gt;&lt;/TSLZoneGroupDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
				+ "</RibMessages>";

		zoneMessageRouter.route(locData);

		Map zoneDataMap1 = new HashMap();
		zoneDataMap1.put("zoneGroupId", "4000");
		zoneDataMap1.put("zoneGroupName", "PS_Zone_1_update");
		zoneDataMap1.put("zoneGroupType", "1");

		List<Map> zoneRefList1 = new ArrayList<Map>();
		Map zoneInfoMap1 = new HashMap();
		zoneInfoMap1.put("zoneId", "30");
		zoneInfoMap1.put("zoneName", "PS_Zone_01_update");
		zoneInfoMap1.put("baseInd", "0");
		zoneInfoMap1.put("currency", "GBP");
		zoneInfoMap1.put("countryId", "GB");
		zoneInfoMap1.put("offerPrefix", "A");
		zoneRefList1.add(zoneInfoMap1);
		zoneDataMap1.put("zoneRefs", zoneRefList1);

		ZoneEntity expectedZoneEntity = createZoneEntity(zoneDataMap1, storeIds);

		ZoneEntity actualEntity = (ZoneEntity) repositoryImpl
				.getGenericObject(cb_key, ZoneEntity.class);
		Assert.assertNotNull(actualEntity);
		actualEntity.setCreatedDate("createdDate");
		actualEntity.setLastUpdateDate("lastUpdatedDate");
		Assert.assertEquals(expectedZoneEntity.toString(),
				actualEntity.toString());

	}

	@Test
	public void shouldUnMarshallAndProcessZoneLocCREMsgWhenZoneIsNotAvailable()
			throws Exception {

		String zone = "30";
		String storeId = "2000";
		String zoneGrp = "4000";
		String cb_key = PriceConstants.ZONE_KEY + zone;
		String loc_key = PriceConstants.STORE_KEY + storeId;
		String grp_key = PriceConstants.ZONE_GRP_KEY + zoneGrp;

		Map zoneGrpDataMap = new HashMap();

		zoneGrpDataMap.put("zoneGroupId", "4000");
		zoneGrpDataMap.put("zoneGroupName", "PS_ZoneGrp_4000");
		zoneGrpDataMap.put("zoneGroupType", "1");

		List<String> storeIds = new LinkedList<String>();
		List<String> zoneIds = new LinkedList<String>();
		zoneIds.add("30");

		ZoneGrpEntity zoneGrpEntity = createZoneGroupEntity(zoneGrpDataMap,
				zoneIds);

		ZoneMessageRouter zoneMessageRouter = new ZoneMessageRouter(
				zoneHandler, zoneEventHandler);

		zoneWriter.insertZoneGrpData(grp_key, zoneGrpEntity);

		String locData = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>ZONEMNT</family>\n"
				+ "<type>ZONELOCCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 14:02:25.155|358</ribmessageID>\n"
				+ "<publishTime>2015-10-06 14:02:25.155 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;TSLZoneGroupDesc&gt;&lt;zone_group_id&gt;4000&lt;/zone_group_id&gt;&lt;TSLZone&gt;&lt;zone_id&gt;30&lt;/zone_id&gt;&lt;TSLZoneLoc&gt;&lt;loc&gt;2000&lt;/loc&gt;&lt;loc_type&gt;0&lt;/loc_type&gt;&lt;/TSLZoneLoc&gt;&lt;/TSLZone&gt;&lt;/TSLZoneGroupDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
				+ "</RibMessages>";
		try {
			zoneMessageRouter.route(locData);

			ZoneEntity actualEntity = (ZoneEntity) repositoryImpl
					.getGenericObject(cb_key, ZoneEntity.class);
			Assert.assertNull(actualEntity);

			Store actualStoreEntity = (Store) repositoryImpl
					.getGenericObject(loc_key, Store.class);

			Assert.assertNull(actualStoreEntity);
		} catch (Exception e) {
			Assert.assertEquals("Error while constucting the zone Entity", e
					.getMessage().toString());
		}

	}

	@Test
	public void shouldUnMarshallAndProcessZoneLocDelMsgWhenZoneIsNotAvailable()
			throws Exception {

		String zone = "4551";
		String storeId = "2130";
		String zoneGrp = "4496";
		String cb_key = PriceConstants.ZONE_KEY + zone;
		String loc_key = PriceConstants.STORE_KEY + storeId;
		String grp_key = PriceConstants.ZONE_GRP_KEY + zoneGrp;

		Map zoneGrpDataMap = new HashMap();

		zoneGrpDataMap.put("zoneGroupId", "4000");
		zoneGrpDataMap.put("zoneGroupName", "PS_ZoneGrp_4000");
		zoneGrpDataMap.put("zoneGroupType", "1");

		List<String> storeIds = new LinkedList<String>();
		List<String> zoneIds = new LinkedList<String>();
		zoneIds.add("4551");

		ZoneGrpEntity zoneGrpEntity = createZoneGroupEntity(zoneGrpDataMap,
				zoneIds);

		ZoneMessageRouter zoneMessageRouter = new ZoneMessageRouter(
				zoneHandler, zoneEventHandler);

		zoneWriter.insertZoneGrpData(grp_key, zoneGrpEntity);

		String loc2DelData = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>ZONEMNT</family>\n"
				+ "<type>ZONELOCDEL</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 14:02:25.155|358</ribmessageID>\n"
				+ "<publishTime>2015-10-06 14:02:25.155 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;TSLZoneGroupRef&gt;&lt;zone_group_id&gt;4496&lt;/zone_group_id&gt;&lt;TSLZoneRef&gt;&lt;zone_id&gt;4551&lt;/zone_id&gt;&lt;TSLZoneLocRef&gt;&lt;loc&gt;2130&lt;/loc&gt;&lt;loc_type&gt;0&lt;/loc_type&gt;&lt;/TSLZoneLocRef&gt;&lt;/TSLZoneRef&gt;&lt;/TSLZoneGroupRef&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n" + "</ribMessage>\n"
				+ "</RibMessages>";
		try {
			zoneMessageRouter.route(loc2DelData);

			ZoneEntity actualEntity = (ZoneEntity) repositoryImpl
					.getGenericObject(cb_key, ZoneEntity.class);
			Assert.assertNull(actualEntity);

			Store actualStoreEntity = (Store) repositoryImpl
					.getGenericObject(loc_key, Store.class);

			Assert.assertNull(actualStoreEntity);
		} catch (Exception e) {
			Assert.assertEquals("Error while deleting the location details", e
					.getMessage().toString());
		}

	}

	public ZoneEntity createZoneEntity(Map zoneDataMap, List storeIds) {

		ZoneEntity zoneEntity = new ZoneEntity();
		zoneEntity.setZoneGroupId(zoneDataMap.get("zoneGroupId").toString());
		String groupType = zoneDataMap.get("zoneGroupType").toString();

		zoneEntity.setZoneGroupType(groupType);
		zoneEntity
				.setZoneGroupName(zoneDataMap.get("zoneGroupName").toString());

		List zoneInfo = (ArrayList) zoneDataMap.get("zoneRefs");
		Map zoneDtlMap = (Map) zoneInfo.get(0);
		zoneEntity.setZoneId(zoneDtlMap.get("zoneId").toString());
		zoneEntity.setZoneName(zoneDtlMap.get("zoneName").toString());
		zoneEntity.setBaseInd(zoneDtlMap.get("baseInd").toString());
		zoneEntity.setCurrencyCode(zoneDtlMap.get("currency").toString());
		zoneEntity.setTslCountryCode(zoneDtlMap.get("countryId").toString());
		zoneEntity.setOfferPrefix(zoneDtlMap.get("offerPrefix").toString());
		zoneEntity.setCreatedDate("createdDate");
		zoneEntity.setCreatedById("RPM");
		zoneEntity.setLastUpdateDate("lastUpdatedDate");
		if (Dockyard.isSpaceOrNull(storeIds) || storeIds.isEmpty()) {
			List<String> locIds = new LinkedList<>();
			zoneEntity.setStoreIds(locIds);
		} else {
			zoneEntity.setStoreIds(storeIds);
		}

		return zoneEntity;
	}

	public ZoneGrpEntity createZoneGroupEntity(Map zoneGrpDataMap, List zoneIds) {
		ZoneGrpEntity zoneGrpEntity = new ZoneGrpEntity();
		zoneGrpEntity.setZoneGroupId(zoneGrpDataMap.get("zoneGroupId")
				.toString());
		zoneGrpEntity.setZoneGroupName(zoneGrpDataMap.get("zoneGroupName")
				.toString());
		zoneGrpEntity.setZoneGroupType(zoneGrpDataMap.get("zoneGroupType")
				.toString());
		zoneGrpEntity.setCreatedDate("createdDate");
		zoneGrpEntity.setCreatedById("RPM");
		zoneGrpEntity.setLastUpdateDate("lastUpdatedDate");
		zoneGrpEntity.setLastUpdatedById("RPM");
		if (Dockyard.isSpaceOrNull(zoneIds) || zoneIds.isEmpty()) {
			zoneGrpEntity.setZoneIds(zoneIds);
		} else {
			zoneGrpEntity.setZoneIds(zoneIds);
		}

		return zoneGrpEntity;
	}

	// Added (Integer) to this method for PRIS-1133 Java 8 upgrade
	public Store createStoreEntity(Map storeDataMap) {
		Store storeEntity = new Store();
		storeEntity.setStoreId(storeDataMap.get("storeId").toString());
		storeEntity
				.setPriceZoneId((storeDataMap.get("priceZoneId").equals(-1)) ? Optional
						.<Integer> absent() : Optional.of(Integer
						.parseInt(storeDataMap.get("priceZoneId").toString())));
		storeEntity
				.setPromoZoneId((storeDataMap.get("promoZoneId").equals(-1)) ? Optional
						.<Integer> absent() : Optional.of(Integer
						.parseInt(storeDataMap.get("promoZoneId").toString())));
		storeEntity.setClearanceZoneId((storeDataMap.get("clearanceZoneId")
				.equals(-1)) ? Optional.<Integer> absent() : Optional
				.of(Integer.parseInt(storeDataMap.get("clearanceZoneId")
						.toString())));
		storeEntity.setCurrency(storeDataMap.get("currency").toString());
		storeEntity.setCountryId(storeDataMap.get("countryId").toString());

		return storeEntity;
	}

	@Test
	public void testZoneCreationEventGeneration()
			throws MessageRouterException, ZoneEventException {

		ZoneMessageRouter zoneMessageRouter = new ZoneMessageRouter(
				zoneHandler, zoneEventHandler);

		String zoneGrpCreXmldata = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>ZONEMNT</family>\n"
				+ "<type>ZONEGROUPCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 08:31:35.467|342</ribmessageID>\n"
				+ "<publishTime>2015-10-06 08:31:35.467 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;TSLZoneGroupDesc&gt;&lt;zone_group_id&gt;4496&lt;/zone_group_id&gt;&lt;zone_group_name&gt;PS_ZoneGrp_1&lt;/zone_group_name&gt;&lt;TSLZoneGroupType&gt;&lt;zone_group_type&gt;2&lt;/zone_group_type&gt;&lt;/TSLZoneGroupType&gt;&lt;TSLZone&gt;&lt;zone_id&gt;4500&lt;/zone_id&gt;&lt;zone_name&gt;PS_Zone_01&lt;/zone_name&gt;&lt;base_ind&gt;1&lt;/base_ind&gt;&lt;country_code&gt;GB&lt;/country_code&gt;&lt;currency_code&gt;GBP&lt;/currency_code&gt;&lt;/TSLZone&gt;&lt;/TSLZoneGroupDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		zoneMessageRouter.route(zoneGrpCreXmldata);

		String zoneCreXmlData = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>ZONEMNT</family>\n"
				+ "<type>ZONECRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 14:02:25.155|358</ribmessageID>\n"
				+ "<publishTime>2015-10-06 14:02:25.155 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;TSLZoneGroupDesc&gt;&lt;zone_group_id&gt;4496&lt;/zone_group_id&gt;&lt;TSLZone&gt;&lt;zone_id&gt;40&lt;/zone_id&gt;&lt;zone_name&gt;Zone_40&lt;/zone_name&gt;&lt;base_ind&gt;0&lt;/base_ind&gt;&lt;country_code&gt;GB&lt;/country_code&gt;&lt;currency_code&gt;GBP&lt;/currency_code&gt;&lt;/TSLZone&gt;&lt;/TSLZoneGroupDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		zoneMessageRouter.route(zoneCreXmlData);

		Mockito.verify(zoneEventHandler, Mockito.times(2)).publishZoneEvent(
				argument.capture(), stringArgument.capture());
		assertEquals(40, (argument.getValue()).getTSLZone().get(0).getZoneId());

	}

	@Test
	public void testZoneDetailsChangedEventGeneration()
			throws MessageRouterException, ZoneEventException {

		ZoneMessageRouter zoneMessageRouter = new ZoneMessageRouter(
				zoneHandler, zoneEventHandler);

		String zoneGrpCreXmldata = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>ZONEMNT</family>\n"
				+ "<type>ZONEGROUPCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 08:31:35.467|342</ribmessageID>\n"
				+ "<publishTime>2015-10-06 08:31:35.467 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;TSLZoneGroupDesc&gt;&lt;zone_group_id&gt;4496&lt;/zone_group_id&gt;&lt;zone_group_name&gt;PS_ZoneGrp_1&lt;/zone_group_name&gt;&lt;TSLZoneGroupType&gt;&lt;zone_group_type&gt;2&lt;/zone_group_type&gt;&lt;/TSLZoneGroupType&gt;&lt;TSLZone&gt;&lt;zone_id&gt;4500&lt;/zone_id&gt;&lt;zone_name&gt;PS_Zone_01&lt;/zone_name&gt;&lt;base_ind&gt;1&lt;/base_ind&gt;&lt;country_code&gt;GB&lt;/country_code&gt;&lt;currency_code&gt;GBP&lt;/currency_code&gt;&lt;/TSLZone&gt;&lt;/TSLZoneGroupDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		zoneMessageRouter.route(zoneGrpCreXmldata);

		String zoneCreXmlData = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>ZONEMNT</family>\n"
				+ "<type>ZONECRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 14:02:25.155|358</ribmessageID>\n"
				+ "<publishTime>2015-10-06 14:02:25.155 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;TSLZoneGroupDesc&gt;&lt;zone_group_id&gt;4496&lt;/zone_group_id&gt;&lt;TSLZone&gt;&lt;zone_id&gt;40&lt;/zone_id&gt;&lt;zone_name&gt;Zone_40&lt;/zone_name&gt;&lt;base_ind&gt;0&lt;/base_ind&gt;&lt;country_code&gt;GB&lt;/country_code&gt;&lt;currency_code&gt;GBP&lt;/currency_code&gt;&lt;/TSLZone&gt;&lt;/TSLZoneGroupDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		zoneMessageRouter.route(zoneCreXmlData);

		String zoneModXmlData = "<RibMessages><ribMessage><family>ZONEMNT</family><type>ZONEMOD</type>"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 14:02:25.157|359</ribmessageID>"
				+ "<publishTime>2015-10-06 14:02:25.157 BST</publishTime>"
				+ "<messageData>&lt;TSLZoneGroupDesc&gt;&lt;zone_group_id&gt;4496&lt;/zone_group_id&gt;&lt;TSLZone&gt;&lt;zone_id&gt;40&lt;/zone_id&gt;&lt;zone_name&gt;Zone_Test&lt;/zone_name&gt;&lt;base_ind&gt;0&lt;/base_ind&gt;&lt;country_code&gt;GB&lt;/country_code&gt;&lt;currency_code&gt;GBP&lt;/currency_code&gt;&lt;/TSLZone&gt;&lt;/TSLZoneGroupDesc&gt;</messageData>"
				+ "<customData></customData>"
				+ "<customFlag>F</customFlag>"
				+ "</ribMessage>" + "</RibMessages>";

		zoneMessageRouter.route(zoneModXmlData);
		Mockito.verify(zoneEventHandler, Mockito.times(3)).publishZoneEvent(
				argument.capture(), stringArgument.capture());
		assertEquals(40, (argument.getValue()).getTSLZone().get(0).getZoneId());

	}

	@Test(expected = MessageRouterException.class)
	public void shouldThrowMessageRouterExceptionForZoneMod()
			throws ZoneEventException, MessageRouterException {
		ZoneMessageRouter zoneMessageRouter = new ZoneMessageRouter(
				zoneHandler, zoneEventHandler);

		String invalidFormatForZoneModXmlData = "<RibMessages><ribMessage><family>ZONEMNT</family><type>ZONEMOD</type>"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 14:02:25.157|359</ribmessageID>"
				+ "<publishTime>2015-10-06 14:02:25.157 BST</publishTime>"
				+ "<messageData>&lt;TSLZoneGroupDescInvalid&gt;&lt;zone_group_id&gt;4496&lt;/zone_group_id&gt;&lt;TSLZone&gt;&lt;zone_id&gt;40&lt;/zone_id&gt;&lt;zone_name&gt;Zone_Test&lt;/zone_name&gt;&lt;base_ind&gt;0&lt;/base_ind&gt;&lt;country_code&gt;GB&lt;/country_code&gt;&lt;currency_code&gt;GBP&lt;/currency_code&gt;&lt;/TSLZone&gt;&lt;/TSLZoneGroupDesc&gt;</messageData>"
				+ "<customData></customData>"
				+ "<customFlag>F</customFlag>"
				+ "</ribMessage>" + "</RibMessages>";
		zoneMessageRouter.route(invalidFormatForZoneModXmlData);
	}

	public void testZoneDeletionEventGeneration()
			throws MessageRouterException, ZoneEventException {
		ZoneMessageRouter zoneMessageRouter = new ZoneMessageRouter(
				zoneHandler, zoneEventHandler);
		String zoneDelXmlData = "<RibMessages>"
				+ "<ribMessage>"
				+ "<family>ZONEMNT</family>"

				+ "<type>ZONEDEL</type>"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 14:22:59.857|370</ribmessageID>"

				+ "<publishTime>2015-10-06 14:22:59.857 BST</publishTime>"

				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;"

				+ "&lt;TSLZoneGroupRef&gt;&lt;zone_group_id&gt;4496&lt;/zone_group_id&gt;&lt;TSLZoneRef&gt;&lt;zone_id&gt;40&lt;/zone_id&gt;&lt;/TSLZoneRef&gt;&lt;/TSLZoneGroupRef&gt;</messageData>"

				+ "<customData></customData>" + "<customFlag>F</customFlag>"
				+ "</ribMessage>" + "</RibMessages>";

		ArgumentCaptor<TSLZoneGroupRef> tSLZoneGroupArgument = ArgumentCaptor
				.forClass(TSLZoneGroupRef.class);
		ArgumentCaptor<Map> mapArgument = ArgumentCaptor.forClass(Map.class);
		zoneMessageRouter.route(zoneDelXmlData);
		Mockito.verify(zoneEventHandler, Mockito.times(1)).publishZoneDelEvent(
				tSLZoneGroupArgument.capture(), mapArgument.capture());
		assertEquals(40,
				(tSLZoneGroupArgument.getValue()).getTSLZoneRef().get(0)
						.getZoneId());

	}

	@Test(expected = MessageRouterException.class)
	public void testZoneMessageRouterException() throws MessageRouterException {
		ZoneMessageRouter zoneMessageRouter = new ZoneMessageRouter(
				zoneHandler, zoneEventHandler);

		String zoneGrpCreXmldata = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>ZONEMNT</family>\n"
				+ "<type>ZONEGROUPCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 08:31:35.467|342</ribmessageID>\n"
				+ "<publishTime>2015-10-06 08:31:35.467 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;TSLZoneGroupDesc&gt;&lt;zone_group_id&gt;4496&lt;/zone_group_id&gt;&lt;zone_group_name&gt;PS_ZoneGrp_1&lt;/zone_group_name&gt;&lt;TSLZoneGroupType&gt;&lt;zone_group_type&gt;2&lt;/zone_group_type&gt;&lt;/TSLZoneGroupType&gt;&lt;TSLZone&gt;&lt;zone_id&gt;4500&lt;/zone_id&gt;&lt;zone_name&gt;PS_Zone_01&lt;/zone_name&gt;&lt;base_ind&gt;1&lt;/base_ind&gt;&lt;country_code&gt;GB&lt;/country_code&gt;&lt;currency_code&gt;GBP&lt;/currency_code&gt;&lt;/TSLZone&gt;&lt;/TSLZoneGroupDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		zoneMessageRouter.route(zoneGrpCreXmldata);

		String zoneCreXmlData = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>ZONEMNT</family>\n"
				+ "<type>ZONECRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 14:02:25.155|358</ribmessageID>\n"
				+ "<publishTime>2015-10-06 14:02:25.155 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;TSLZoneGroupDesc&gt;&lt;zone_group_id&gt;4496&lt;/zone_group_id&gt;&lt;TSLZone&gt;&lt;zone_id&gt;40&lt;/zone_id&gt;&lt;zone_name&gt;Zone_40&lt;/zone_name&gt;&lt;base_ind&gt;0&lt;/base_ind&gt;&lt;country_code&gt;GB&lt;/country_code&gt;&lt;currency_code&gt;GBP&lt;/currency_code&gt;&lt;/TSLZone&gt;&lt;/TSLZoneGroupDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		zoneMessageRouter.route(zoneCreXmlData);

		String invalidZoneDelXmlMessage = "<RibMessages>"
				+ "<ribMessage>"
				+ "<family>ZONEMNT</family>"
				+ "<type>ZONEDEL</type>"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 14:22:59.857|370</ribmessageID>"
				+ "<publishTime>2015-10-06 14:22:59.857 BST</publishTime>"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;"
				+ "&lt;TSLZoneGroupRefInvalid&gt;&lt;zone_group_id&gt;4496&lt;/zone_group_id&gt;&lt;TSLZoneRef&gt;&lt;zone_id&gt;40&lt;/zone_id&gt;&lt;/TSLZoneRef&gt;&lt;/TSLZoneGroupRef&gt;</messageData>"
				+ "<customData></customData>" + "<customFlag>F</customFlag>"
				+ "</ribMessage>" + "</RibMessages>";
		zoneMessageRouter.route(invalidZoneDelXmlMessage);

	}

	@Test
	public void testStoreZoneCreated() throws MessageRouterException,
			ZoneEventException {

		ZoneMessageRouter zoneMessageRouter = new ZoneMessageRouter(
				zoneHandler, zoneEventHandler);

		String zoneGrpCreXmldata = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>ZONEMNT</family>\n"
				+ "<type>ZONEGROUPCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 08:31:35.467|342</ribmessageID>\n"
				+ "<publishTime>2015-10-06 08:31:35.467 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;TSLZoneGroupDesc&gt;&lt;zone_group_id&gt;4496&lt;/zone_group_id&gt;&lt;zone_group_name&gt;PS_ZoneGrp_1&lt;/zone_group_name&gt;&lt;TSLZoneGroupType&gt;&lt;zone_group_type&gt;2&lt;/zone_group_type&gt;&lt;/TSLZoneGroupType&gt;&lt;TSLZone&gt;&lt;zone_id&gt;4500&lt;/zone_id&gt;&lt;zone_name&gt;PS_Zone_01&lt;/zone_name&gt;&lt;base_ind&gt;1&lt;/base_ind&gt;&lt;country_code&gt;GB&lt;/country_code&gt;&lt;currency_code&gt;GBP&lt;/currency_code&gt;&lt;/TSLZone&gt;&lt;/TSLZoneGroupDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		zoneMessageRouter.route(zoneGrpCreXmldata);

		String zoneCreXmlData = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>ZONEMNT</family>\n"
				+ "<type>ZONECRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 14:02:25.155|358</ribmessageID>\n"
				+ "<publishTime>2015-10-06 14:02:25.155 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;TSLZoneGroupDesc&gt;&lt;zone_group_id&gt;4496&lt;/zone_group_id&gt;&lt;TSLZone&gt;&lt;zone_id&gt;40&lt;/zone_id&gt;&lt;zone_name&gt;Zone_40&lt;/zone_name&gt;&lt;base_ind&gt;0&lt;/base_ind&gt;&lt;country_code&gt;GB&lt;/country_code&gt;&lt;currency_code&gt;GBP&lt;/currency_code&gt;&lt;/TSLZone&gt;&lt;/TSLZoneGroupDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		zoneMessageRouter.route(zoneCreXmlData);

		String storeZoneCreXmlData = "<RibMessages><ribMessage><family>ZONEMNT</family><type>ZONELOCCRE</type>"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.07 10:38:31.356|18</ribmessageID>"
				+ "<publishTime>2015-10-07 10:38:31.356 BST</publishTime>"
				+ "<messageData>"
				+ "&lt;TSLZoneGroupDesc&gt;&lt;zone_group_id&gt;4496&lt;/zone_group_id&gt;&lt;TSLZone&gt;&lt;zone_id&gt;40&lt;/zone_id&gt;&lt;TSLZoneLoc&gt;&lt;loc&gt;2000&lt;/loc&gt;&lt;loc_type&gt;0&lt;/loc_type&gt;&lt;/TSLZoneLoc&gt;&lt;/TSLZone&gt;&lt;/TSLZoneGroupDesc&gt;</messageData>"
				+ "<customData></customData>"
				+ "<customFlag>F</customFlag>"
				+ "</ribMessage></RibMessages>";

		zoneMessageRouter.route(storeZoneCreXmlData);
		ArgumentCaptor<Map> mapArgument = ArgumentCaptor.forClass(Map.class);
		Mockito.verify(zoneEventHandler, Mockito.times(1))
				.publishStoreZoneChangeCreEvent(argument.capture(),
						mapArgument.capture());
		assertEquals(40, (argument.getValue()).getTSLZone().get(0).getZoneId());

	}

	@Test
	public void testStoreZoneDelete() throws MessageRouterException,
			ZoneEventException {

		ZoneMessageRouter zoneMessageRouter = new ZoneMessageRouter(
				zoneHandler, zoneEventHandler);

		String zoneGrpCreXmldata = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>ZONEMNT</family>\n"
				+ "<type>ZONEGROUPCRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 08:31:35.467|342</ribmessageID>\n"
				+ "<publishTime>2015-10-06 08:31:35.467 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;TSLZoneGroupDesc&gt;&lt;zone_group_id&gt;4496&lt;/zone_group_id&gt;&lt;zone_group_name&gt;PS_ZoneGrp_1&lt;/zone_group_name&gt;&lt;TSLZoneGroupType&gt;&lt;zone_group_type&gt;2&lt;/zone_group_type&gt;&lt;/TSLZoneGroupType&gt;&lt;TSLZone&gt;&lt;zone_id&gt;4500&lt;/zone_id&gt;&lt;zone_name&gt;PS_Zone_01&lt;/zone_name&gt;&lt;base_ind&gt;1&lt;/base_ind&gt;&lt;country_code&gt;GB&lt;/country_code&gt;&lt;currency_code&gt;GBP&lt;/currency_code&gt;&lt;/TSLZone&gt;&lt;/TSLZoneGroupDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		zoneMessageRouter.route(zoneGrpCreXmldata);

		String zoneCreXmlData = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RibMessages>\n"
				+ "<ribMessage>\n"
				+ "<family>ZONEMNT</family>\n"
				+ "<type>ZONECRE</type>\n"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.06 14:02:25.155|358</ribmessageID>\n"
				+ "<publishTime>2015-10-06 14:02:25.155 BST</publishTime>\n"
				+ "<messageData>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;\n"
				+ "&lt;TSLZoneGroupDesc&gt;&lt;zone_group_id&gt;4496&lt;/zone_group_id&gt;&lt;TSLZone&gt;&lt;zone_id&gt;40&lt;/zone_id&gt;&lt;zone_name&gt;Zone_40&lt;/zone_name&gt;&lt;base_ind&gt;0&lt;/base_ind&gt;&lt;country_code&gt;GB&lt;/country_code&gt;&lt;currency_code&gt;GBP&lt;/currency_code&gt;&lt;/TSLZone&gt;&lt;/TSLZoneGroupDesc&gt;</messageData>\n"
				+ "<customData></customData>\n"
				+ "<customFlag>F</customFlag>\n"
				+ "</ribMessage>\n"
				+ "</RibMessages>";

		zoneMessageRouter.route(zoneCreXmlData);

		String storeZoneCreXmlData = "<RibMessages><ribMessage><family>ZONEMNT</family><type>ZONELOCCRE</type>"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.07 10:38:31.356|18</ribmessageID>"
				+ "<publishTime>2015-10-07 10:38:31.356 BST</publishTime>"
				+ "<messageData>"
				+ "&lt;TSLZoneGroupDesc&gt;&lt;zone_group_id&gt;4496&lt;/zone_group_id&gt;&lt;TSLZone&gt;&lt;zone_id&gt;40&lt;/zone_id&gt;&lt;TSLZoneLoc&gt;&lt;loc&gt;2000&lt;/loc&gt;&lt;loc_type&gt;0&lt;/loc_type&gt;&lt;/TSLZoneLoc&gt;&lt;/TSLZone&gt;&lt;/TSLZoneGroupDesc&gt;</messageData>"
				+ "<customData></customData>"
				+ "<customFlag>F</customFlag>"
				+ "</ribMessage></RibMessages>";

		zoneMessageRouter.route(storeZoneCreXmlData);

		String storeZoneDelXmlData = "<RibMessages><ribMessage><family>ZONEMNT</family><type>ZONELOCDEL</type>"
				+ "<ribmessageID>12.0|RIBMessagePublisherEjb|ZONEMNT|2015.10.07 10:38:31.342|16</ribmessageID>"
				+ "<publishTime>2015-10-07 10:38:31.342 BST</publishTime>"
				+ "<messageData>"
				+ "&lt;TSLZoneGroupRef&gt;&lt;zone_group_id&gt;4496&lt;/zone_group_id&gt;&lt;TSLZoneRef&gt;&lt;zone_id&gt;40&lt;/zone_id&gt;&lt;TSLZoneLocRef&gt;&lt;loc&gt;2000&lt;/loc&gt;&lt;loc_type&gt;0&lt;/loc_type&gt;&lt;/TSLZoneLocRef&gt;&lt;/TSLZoneRef&gt;&lt;/TSLZoneGroupRef&gt;</messageData>"
				+ "<customData></customData><customFlag>F</customFlag></ribMessage></RibMessages>";

		zoneMessageRouter.route(storeZoneDelXmlData);
		ArgumentCaptor<Map> mapArgument = ArgumentCaptor.forClass(Map.class);
		Mockito.verify(zoneEventHandler, Mockito.times(1))
				.publishStoreZoneChangeRemoveEvent(argumentRef.capture(),
						mapArgument.capture());
		assertEquals(40, (argumentRef.getValue()).getTSLZoneRef().get(0)
				.getZoneId());

	}

}
