package com.tesco.services.adapters.rpm.writers;


import static org.fest.assertions.api.Assertions.assertThat;
import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IllformedLocaleException;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Semaphore;

import com.tesco.services.adapters.rpm.writers.impl.RPMClearanceProductMapper;
import com.tesco.services.adapters.rpm.writers.impl.RPMClearanceWriter;
import com.tesco.services.repositories.RepositoryImpl;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tesco.couchbase.AsyncCouchbaseWrapper;
import com.tesco.couchbase.CouchbaseWrapper;
import com.tesco.couchbase.testutils.AsyncCouchbaseWrapperStub;
import com.tesco.couchbase.testutils.BucketTool;
import com.tesco.couchbase.testutils.CouchbaseTestManager;
import com.tesco.couchbase.testutils.CouchbaseWrapperStub;
import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.exceptions.ColumnNotFoundException;
import com.tesco.services.adapters.core.exceptions.WriterBusinessException;
import com.tesco.services.adapters.rpm.comparators.RPMComparator;
import com.tesco.services.adapters.rpm.events.impl.ClearanceEventData;
import com.tesco.services.adapters.rpm.events.ClearanceEventHandler;
import com.tesco.services.adapters.rpm.readers.PriceServiceCSVReader;
import com.tesco.services.core.ClearanceByDateTime;
import com.tesco.services.core.ClearanceProduct;
import com.tesco.services.core.ClearanceProductVariant;
import com.tesco.services.core.ClearanceStoreSaleInfo;
import com.tesco.services.core.ClearanceZoneSaleInfo;
import com.tesco.services.core.Product;
import com.tesco.services.core.ProductVariant;
import com.tesco.services.resources.ImportResource;
import com.tesco.services.resources.TestConfiguration;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.PriceConstants;

@RunWith(MockitoJUnitRunner.class) public class RpmClearanceWriterTest {

	@Mock public RPMClearanceWriter rpmclearancewriter;
	@Mock public RepositoryImpl repositoryImpl;

	@Mock public AsyncCouchbaseWrapper asyncCouchbaseWrapper;

	@Mock public CouchbaseWrapper couchbaseWrapper;

	@Mock private PriceServiceCSVReader rpmClearanceCreReader;

	@Mock private PriceServiceCSVReader rpmClearanceModReader;

	@Mock private PriceServiceCSVReader rpmClearanceDelReader;

	@Mock private Configuration testConfiguration;

	@Mock private Configuration mockTestConfiguration;

	@Mock private ObjectMapper mapper;

	@Mock private RPMClearanceProductMapper rpmclearanceProductMapper;

	@Mock private BufferedReader bufferedReader;

	@Mock FileReader fileReader;
	@Mock File rpmClrFailedDatafile;

	@Mock FileWriter fileWriter;
	@Mock BufferedWriter bufferedWriter;
	@Mock
	private CouchbaseTestManager couchbaseTestManager;

	@Mock
	ClearanceEventHandler clearanceEventHandler;
	
	String currencyCode = "GBP";
	String sellingUom = "EA";
	String sellingcurr = "GBP";
	String rec_descriptor_cre = "FDETL";
	String line_nor = "1";
	String event_type = "CRE";
	String selling_price = "4";
	String runIdentifier = "acayg";
	String eff_date;
	String end_date;
	String eff_date2;
	String end_date2;
	String eff_date3;
	DateFormat dateFormat ;

	@Before public void setUp()
			throws IOException, URISyntaxException, InterruptedException,
			ColumnNotFoundException {

		testConfiguration = TestConfiguration.load();
		if (testConfiguration.isDummyCouchbaseMode()) {
			Map<String, ImmutablePair<Long, String>> fakeBase = new HashMap<>();
			couchbaseTestManager = new CouchbaseTestManager(
					new CouchbaseWrapperStub(fakeBase),
					new AsyncCouchbaseWrapperStub(fakeBase),
					mock(BucketTool.class));
		} else {
			couchbaseTestManager = new CouchbaseTestManager(
					testConfiguration.getCouchbaseBucket(),
					testConfiguration.getCouchbaseUsername(),
					testConfiguration.getCouchbasePassword(),
					testConfiguration.getCouchbaseNodes(),
					testConfiguration.getCouchbaseAdminUsername(),
					testConfiguration.getCouchbaseAdminPassword());
		}

		couchbaseWrapper = couchbaseTestManager.getCouchbaseWrapper();
		asyncCouchbaseWrapper = couchbaseTestManager.getAsyncCouchbaseWrapper();

		repositoryImpl = new RepositoryImpl(couchbaseWrapper,
				asyncCouchbaseWrapper, new ObjectMapper());
	
		rpmclearancewriter = new RPMClearanceWriter(testConfiguration,
				repositoryImpl, clearanceEventHandler,rpmClearanceCreReader, rpmClearanceDelReader,
				rpmClearanceModReader);

		rpmclearancewriter.setReader(fileReader);
		rpmclearancewriter.setRpmClrFailedFileReader(bufferedReader);

		when(bufferedReader.readLine()).thenReturn(null);
		Mockito.doNothing().when(bufferedReader).close();

		rpmclearancewriter.setFileWriter(fileWriter);
		rpmclearancewriter.setBufferedWriter(bufferedWriter);

		rpmclearancewriter.setRunIdentifier(runIdentifier);

		Mockito.doNothing().when(bufferedWriter).write(Matchers.anyString());
		Mockito.doNothing().when(bufferedWriter).flush();
		Mockito.doNothing().when(bufferedWriter).close();

		ImportResource.importSemaphoreForIdentifier
				.put(runIdentifier, new Semaphore(1));
		rpmclearanceProductMapper = new RPMClearanceProductMapper(
				repositoryImpl);
		/**
		 * Generating the date dynamically..
		 */
		DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");
		Calendar cal = Calendar.getInstance();
		eff_date = dateFormat.format(cal.getTime());
		cal.add(Calendar.DATE, 12);
		end_date = dateFormat.format(cal.getTime());
		eff_date2 = dateFormat.format(cal.getTime());
		cal.add(Calendar.DATE, 12);
		end_date2 = dateFormat.format(cal.getTime());
		cal.add(Calendar.DATE, 10);
		eff_date3 = dateFormat.format(cal.getTime());
		
			
	}

	@Test public void readAndWriteRpmClrForUKNatZoneDataInserts()
			throws Exception {
		String productId = "056376327";
		String tpnc = "252941940";
		String clearance_id = "ACY-1224988440";
		String location = "20";
		String location_type = "Z";

		ConstructProductAndTpncMapping(productId, tpnc);

		Map<String, String> productInfoMap = productInfoMap(productId, tpnc,
				clearance_id, location, location_type, eff_date, end_date,
				selling_price);
		when(rpmClearanceCreReader.getNext()).thenReturn(productInfoMap)
				.thenReturn(null);

		this.rpmclearancewriter.write(null);

		ClearanceByDateTime clearanceByDateTime = createClearanceByDateTime(
				eff_date, end_date, clearance_id, selling_price);
		ClearanceZoneSaleInfo clearanceZoneSaleInfo = createClearanceZoneSaleInfo(
				location, "UK", "GBP", clearanceByDateTime);
		ClearanceProductVariant clearanceProductVariant1 = createClearanceProductVariant(
				tpnc, clearanceZoneSaleInfo, null);

		ClearanceProduct expectedClearanceProduct = createClearanceProduct(
				productId);
		expectedClearanceProduct
				.addClearanceProductVariant(clearanceProductVariant1);
		String key = PriceConstants.CLEARANCE_KEY_PREFIX + productId;
		ClearanceProduct actualClearanceProduct = (ClearanceProduct) repositoryImpl
				.getGenericObject(key,ClearanceProduct.class);
		boolean isEqual = new RPMComparator()
				.compare(actualClearanceProduct, expectedClearanceProduct);
		assertThat(isEqual).isEqualTo(true);
	}

	@Test public void readAndWriteRpmClrForUKNatStoreDataInserts()
			throws Exception {
		String productId = "056376327";
		String tpnc = "252941940";
		String clearance_id = "ACY-1224988440";
		String location = "3276";
		String location_type = "S";
		// String eff_date = "18-DEC-14";
		// String end_date = "12-FEB-15";
		ConstructProductAndTpncMapping(productId, tpnc);

		Map<String, String> productInfoMap = productInfoMap(productId, tpnc,
				clearance_id, location, location_type, eff_date, end_date,
				selling_price);
		when(rpmClearanceCreReader.getNext()).thenReturn(productInfoMap)
				.thenReturn(null);

		this.rpmclearancewriter.write(null);

		ClearanceByDateTime clearanceByDateTime = createClearanceByDateTime(
				eff_date, end_date, clearance_id, selling_price);
		ClearanceStoreSaleInfo clearanceStoreSaleInfo = createClearanceStoreSaleInfo(
				location, "UK", "GBP", clearanceByDateTime);
		ClearanceProductVariant clearanceProductVariant1 = createClearanceProductVariant(
				tpnc, null, clearanceStoreSaleInfo);
		ClearanceProduct expectedClearanceProduct = createClearanceProduct(
				productId);
		expectedClearanceProduct
				.addClearanceProductVariant(clearanceProductVariant1);
		String key = PriceConstants.CLEARANCE_KEY_PREFIX + productId;
		ClearanceProduct actualClearanceProduct = (ClearanceProduct) repositoryImpl
				.getGenericObject(key,ClearanceProduct.class);
		boolean isEqual = new RPMComparator()
				.compare(actualClearanceProduct, expectedClearanceProduct);
		assertThat(isEqual).isEqualTo(true);
	}

	@Test public void readAndWriteRpmClrForUKNatZoneMultiTpncDataInserts()
			throws Exception {
		String productId = "056376327";
		String tpnc1 = "252941940";
		String tpnc2 = "253704978";
		String clearance_id = "ACY-1224988440";
		String location = "20";
		String location_type = "Z";

		ConstructProductAndTpncMapping(productId, tpnc1);
		ConstructProductAndTpncMapping(productId, tpnc2);

		Map<String, String> productInfoMap = productInfoMap(productId, tpnc1,
				clearance_id, location, location_type, eff_date, end_date,
				selling_price);
		Map<String, String> productInfoMap2 = productInfoMap(productId, tpnc2,
				clearance_id, location, location_type, eff_date, end_date,
				selling_price);
		when(rpmClearanceCreReader.getNext()).thenReturn(productInfoMap)
				.thenReturn(productInfoMap2).thenReturn(null);

		this.rpmclearancewriter.write(null);

		ClearanceByDateTime clearanceByDateTime = createClearanceByDateTime(
				eff_date, end_date, clearance_id, selling_price);
		ClearanceZoneSaleInfo clearanceZoneSaleInfo = createClearanceZoneSaleInfo(
				location, "UK", "GBP", clearanceByDateTime);
		ClearanceProductVariant clearanceProductVariant1 = createClearanceProductVariant(
				tpnc1, clearanceZoneSaleInfo, null);
		ClearanceProductVariant clearanceProductVariant2 = createClearanceProductVariant(
				tpnc2, clearanceZoneSaleInfo, null);
		ClearanceProduct expectedClearanceProduct = createClearanceProduct(
				productId);
		expectedClearanceProduct
				.addClearanceProductVariant(clearanceProductVariant1);
		expectedClearanceProduct
				.addClearanceProductVariant(clearanceProductVariant2);

		String key = PriceConstants.CLEARANCE_KEY_PREFIX + productId;
		ClearanceProduct actualClearanceProduct = (ClearanceProduct) repositoryImpl
				.getGenericObject(key,ClearanceProduct.class);
		boolean isEqual = new RPMComparator()
				.compare(actualClearanceProduct, expectedClearanceProduct);

		assertThat(isEqual).isEqualTo(true);
	}

	// CURR
	@Test public void readAndWriteRpmClrForUKNatStoreMultiTpncDataInserts()
			throws Exception {
		String productId = "056376327";
		String tpnc1 = "252941940";
		String tpnc2 = "253704978";
		String clearance_id = "ACY-1224988440";
		String location = "3276";
		String location_type = "S";

		ConstructProductAndTpncMapping(productId, tpnc1);
		ConstructProductAndTpncMapping(productId, tpnc2);

		Map<String, String> productInfoMap = productInfoMap(productId, tpnc1,
				clearance_id, location, location_type, eff_date, end_date,
				selling_price);
		Map<String, String> productInfoMap2 = productInfoMap(productId, tpnc2,
				clearance_id, location, location_type, eff_date, end_date,
				selling_price);
		when(rpmClearanceCreReader.getNext()).thenReturn(productInfoMap)
				.thenReturn(productInfoMap2).thenReturn(null);

		this.rpmclearancewriter.write(null);

		ClearanceByDateTime clearanceByDateTime = createClearanceByDateTime(
				eff_date, end_date, clearance_id, selling_price);
		ClearanceStoreSaleInfo clearanceStoreSaleInfo = createClearanceStoreSaleInfo(
				location, "UK", "GBP", clearanceByDateTime);
		ClearanceProductVariant clearanceProductVariant1 = createClearanceProductVariant(
				tpnc1, null, clearanceStoreSaleInfo);
		ClearanceProductVariant clearanceProductVariant2 = createClearanceProductVariant(
				tpnc2, null, clearanceStoreSaleInfo);
		ClearanceProduct expectedClearanceProduct = createClearanceProduct(
				productId);
		expectedClearanceProduct
				.addClearanceProductVariant(clearanceProductVariant1);
		expectedClearanceProduct
				.addClearanceProductVariant(clearanceProductVariant2);

		String key = PriceConstants.CLEARANCE_KEY_PREFIX + productId;
		ClearanceProduct actualClearanceProduct = (ClearanceProduct) repositoryImpl
				.getGenericObject(key,ClearanceProduct.class);
		boolean isEqual = new RPMComparator()
				.compare(actualClearanceProduct, expectedClearanceProduct);

		assertThat(isEqual).isEqualTo(true);
	}

	@Test public void readAndWriteRpmClrForUKNatStoreMultiProdDataInserts()
			throws Exception {
		String productId = "056376327";
		String productId2 = "056376999";
		String tpnc1 = "252941940";
		String tpnc2 = "253704978";
		String clearance_id = "ACY-1224988440";
		String location = "3276";
		String location_type = "S";

		ConstructProductAndTpncMapping(productId, tpnc1);
		ConstructProductAndTpncMapping(productId2, tpnc2);

		Map<String, String> productInfoMap = productInfoMap(productId, tpnc1,
				clearance_id, location, location_type, eff_date, end_date,
				selling_price);
		Map<String, String> productInfoMap2 = productInfoMap(productId2, tpnc2,
				clearance_id, location, location_type, eff_date, end_date,
				selling_price);
		when(rpmClearanceCreReader.getNext()).thenReturn(productInfoMap)
				.thenReturn(productInfoMap2).thenReturn(null);

		this.rpmclearancewriter.write(null);

		ClearanceByDateTime clearanceByDateTime = createClearanceByDateTime(
				eff_date, end_date, clearance_id, selling_price);
		ClearanceStoreSaleInfo clearanceStoreSaleInfo = createClearanceStoreSaleInfo(
				location, "UK", "GBP", clearanceByDateTime);
		ClearanceProductVariant clearanceProductVariant1 = createClearanceProductVariant(
				tpnc1, null, clearanceStoreSaleInfo);
		ClearanceProductVariant clearanceProductVariant2 = createClearanceProductVariant(
				tpnc2, null, clearanceStoreSaleInfo);
		ClearanceProduct expectedClearanceProduct = createClearanceProduct(
				productId);
		expectedClearanceProduct
				.addClearanceProductVariant(clearanceProductVariant1);

		ClearanceProduct expectedClearanceProduct2 = createClearanceProduct(
				productId2);
		expectedClearanceProduct2
				.addClearanceProductVariant(clearanceProductVariant2);

		String key = PriceConstants.CLEARANCE_KEY_PREFIX + productId;
		ClearanceProduct actualClearanceProduct = (ClearanceProduct) repositoryImpl
				.getGenericObject(key,ClearanceProduct.class);
		boolean isEqual = new RPMComparator()
				.compare(actualClearanceProduct, expectedClearanceProduct);

		assertThat(isEqual).isEqualTo(true);


		key = PriceConstants.CLEARANCE_KEY_PREFIX + productId2;
		actualClearanceProduct = (ClearanceProduct) repositoryImpl.getGenericObject(key,ClearanceProduct.class);

		isEqual = new RPMComparator()
				.compare(actualClearanceProduct, expectedClearanceProduct2);
		assertThat(isEqual).isEqualTo(true);
	}

	@SuppressWarnings("static-access") @Test public void readAndWriteRpmClrForUKNatStoreWithNullEndDate()
			throws Exception {
		String productId = "056376327";
		String productId2 = "056376999";
		String tpnc1 = "252941940";
		String tpnc2 = "253704978";
		String clearance_id = "ACY-1224988440";
		String location = "3276";
		String location_type = "S";

		String end_date = "";
		ConstructProductAndTpncMapping(productId, tpnc1);
		ConstructProductAndTpncMapping(productId2, tpnc2);

		Map<String, String> productInfoMap = productInfoMap(productId, tpnc1,
				clearance_id, location, location_type, eff_date, end_date,
				selling_price);

		when(rpmClearanceCreReader.getNext()).thenReturn(null);
		when(rpmClearanceDelReader.getNext()).thenReturn(null);
		when(rpmClearanceModReader.getNext()).thenReturn(productInfoMap)
				.thenReturn(null);

		this.rpmclearancewriter.write(null);


		String key = PriceConstants.CLEARANCE_KEY_PREFIX + productId;
		ClearanceProduct actualClearanceProduct = (ClearanceProduct) repositoryImpl
				.getGenericObject(key,ClearanceProduct.class);

		assertNull(actualClearanceProduct);
	}

	@Test public void readAndWriteRpmClrForUKNatZoneDataInsertsAndMod()
			throws Exception {
		String productId = "056376327";
		String tpnc1 = "252941940";
		String tpnc2 = "253704978";
		String clearance_id = "ACY-1224988440";
		String location = "20";
		String location_type = "Z";
		String selling_price_mod = "10";
		String productId2 = "056376999";
		String tpnc3 = "253704990";

		ConstructProductAndTpncMapping(productId, tpnc1);
		ConstructProductAndTpncMapping(productId, tpnc2);

		Map<String, String> productInfoMap = productInfoMap(productId, tpnc1,
				clearance_id, location, location_type, eff_date, end_date,
				selling_price);

		Map<String, String> productInfoMap2 = productInfoMap(productId, tpnc1,
				clearance_id, location, location_type, eff_date, end_date,
				selling_price_mod);

		Map<String, String> productInfoMap3 = productInfoMap(productId2, tpnc3,
				clearance_id, location, location_type, eff_date, end_date,
				selling_price_mod);

		when(rpmClearanceCreReader.getNext()).thenReturn(productInfoMap)
				.thenReturn(null);
		when(rpmClearanceModReader.getNext()).thenReturn(productInfoMap2)
				.thenReturn(productInfoMap3).thenReturn(null);

		this.rpmclearancewriter.write(null);

		ClearanceByDateTime clearanceByDateTime = createClearanceByDateTime(
				eff_date, end_date, clearance_id, selling_price_mod);
		ClearanceZoneSaleInfo clearanceZoneSaleInfo = createClearanceZoneSaleInfo(
				location, "UK", "GBP", clearanceByDateTime);
		ClearanceProductVariant clearanceProductVariant1 = createClearanceProductVariant(
				tpnc1, clearanceZoneSaleInfo, null);

		ClearanceProduct expectedClearanceProduct = createClearanceProduct(
				productId);
		expectedClearanceProduct
				.addClearanceProductVariant(clearanceProductVariant1);

		String key = PriceConstants.CLEARANCE_KEY_PREFIX + productId;
		ClearanceProduct actualClearanceProduct = (ClearanceProduct) repositoryImpl
				.getGenericObject(key,ClearanceProduct.class);
		boolean isEqual = new RPMComparator()
				.compare(actualClearanceProduct, expectedClearanceProduct);
		assertThat(isEqual).isEqualTo(true);
	}

	// CURR
	@SuppressWarnings("unused") @Test public void readAndWriteRpmClrForUKStoreNatZoneDataInserts()
			throws Exception {
		String productId = "056376327";
		String tpnc1 = "252941940";
		String clearance_id = "ACY-1224988440";
		String location_z = "20";
		String location_s = "3276";
		String location_type_z = "Z";
		String location_type_s = "S";
		String selling_price_mod = "10";

		ConstructProductAndTpncMapping(productId, tpnc1);

		Map<String, String> productInfoMap = productInfoMap(productId, tpnc1,
				clearance_id, location_z, location_type_z, eff_date, end_date,
				selling_price);
		Map<String, String> productInfoMap2 = productInfoMap(productId, tpnc1,
				clearance_id, location_s, location_type_s, eff_date, end_date,
				selling_price);

		when(rpmClearanceCreReader.getNext()).thenReturn(productInfoMap)
				.thenReturn(productInfoMap2).thenReturn(null);

		rpmclearancewriter.write(null);

		ClearanceByDateTime clearanceByDateTime = createClearanceByDateTime(
				eff_date, end_date, clearance_id, selling_price);
		ClearanceZoneSaleInfo clearanceZoneSaleInfo = createClearanceZoneSaleInfo(
				location_z, "UK", "GBP", clearanceByDateTime);
		ClearanceStoreSaleInfo clearanceStoreSaleInfo = createClearanceStoreSaleInfo(
				location_s, "UK", "GBP", clearanceByDateTime);
		ClearanceProductVariant clearanceProductVariant1 = createClearanceProductVariant(
				tpnc1, clearanceZoneSaleInfo, clearanceStoreSaleInfo);
		ClearanceProduct expectedClearanceProduct = createClearanceProduct(
				productId);
		expectedClearanceProduct
				.addClearanceProductVariant(clearanceProductVariant1);

		String key = PriceConstants.CLEARANCE_KEY_PREFIX + productId;
		ClearanceProduct actualClearanceProduct = (ClearanceProduct) repositoryImpl
				.getGenericObject(key,ClearanceProduct.class);

		boolean isEqual = new RPMComparator()
				.compare(actualClearanceProduct, expectedClearanceProduct);

		assertThat(isEqual).isEqualTo(true);
	}

	@Test public void readAndWriteRpmClrForMultiTpncUKStoreNatZoneDataInserts()
			throws Exception {
		String productId = "056376327";
		String tpnc1 = "252941940";
		String tpnc2 = "253704978";
		String clearance_id = "ACY-1224988440";
		String location_z = "20";
		String location_s = "3276";
		String location_type_z = "Z";
		String location_type_s = "S";
		// String eff_date = "18-DEC-14";
		// String end_date = "12-FEB-15";

		ConstructProductAndTpncMapping(productId, tpnc1);
		Map<String, String> productInfoMap = productInfoMap(productId, tpnc1,
				clearance_id, location_z, location_type_z, eff_date, end_date,
				selling_price);
		Map<String, String> productInfoMap2 = productInfoMap(productId, tpnc2,
				clearance_id, location_z, location_type_z, eff_date, end_date,
				selling_price);
		Map<String, String> productInfoMap3 = productInfoMap(productId, tpnc1,
				clearance_id, location_s, location_type_s, eff_date, end_date,
				selling_price);
		Map<String, String> productInfoMap4 = productInfoMap(productId, tpnc2,
				clearance_id, location_s, location_type_s, eff_date, end_date,
				selling_price);
		when(rpmClearanceCreReader.getNext()).thenReturn(productInfoMap)
				.thenReturn(productInfoMap2).thenReturn(productInfoMap3)
				.thenReturn(productInfoMap4).thenReturn(null);
		this.rpmclearancewriter.write(null);
		ClearanceByDateTime clearanceByDateTime = createClearanceByDateTime(
				eff_date, end_date, clearance_id, selling_price);
		ClearanceZoneSaleInfo clearanceZoneSaleInfo = createClearanceZoneSaleInfo(
				location_z, "UK", "GBP", clearanceByDateTime);
		ClearanceStoreSaleInfo clearanceStoreSaleInfo = createClearanceStoreSaleInfo(
				location_s, "UK", "GBP", clearanceByDateTime);
		ClearanceProductVariant clearanceProductVariant1 = createClearanceProductVariant(
				tpnc1, clearanceZoneSaleInfo, clearanceStoreSaleInfo);
		ClearanceProductVariant clearanceProductVariant2 = createClearanceProductVariant(
				tpnc2, clearanceZoneSaleInfo, clearanceStoreSaleInfo);
		ClearanceProduct expectedClearanceProduct = createClearanceProduct(
				productId);
		expectedClearanceProduct
				.addClearanceProductVariant(clearanceProductVariant1);
		expectedClearanceProduct
				.addClearanceProductVariant(clearanceProductVariant2);
		String key = PriceConstants.CLEARANCE_KEY_PREFIX + productId;
		ClearanceProduct actualClearanceProduct = (ClearanceProduct) repositoryImpl
				.getGenericObject(key,ClearanceProduct.class);
		boolean isEqual = new RPMComparator()
				.compare(actualClearanceProduct, expectedClearanceProduct);
		assertThat(isEqual).isEqualTo(true);
	}

	// markdowns
	@SuppressWarnings("unused") @Test public void readAndWriteRpmClrForUKZoneMarkdownsAcaygDataInserts()
			throws Exception {
		String productId = "056376327";
		String tpnc1 = "252941940";
		String tpnc2 = "253704978";
		String clearance_id = "ACY-1224988440";
		String clearance_id2 = "ACY-1224988441";
		String location_z = "20";
		String location_type_z = "Z";
		// String eff_date = "18-DEC-14";
		// String end_date = "12-FEB-15";
		// String eff_date2 = "18-DEC-14";
		// String end_date2 = "12-FEB-15";

		ConstructProductAndTpncMapping(productId, tpnc1);
		Map<String, String> productInfoMap = productInfoMap(productId, tpnc1,
				clearance_id, location_z, location_type_z, eff_date, end_date,
				selling_price);
		Map<String, String> productInfoMap2 = productInfoMap(productId, tpnc1,
				clearance_id2, location_z, location_type_z, eff_date2,
				end_date2, selling_price);
		when(rpmClearanceCreReader.getNext()).thenReturn(productInfoMap)
				.thenReturn(productInfoMap2).thenReturn(null);
		this.rpmclearancewriter.write(null);
		ClearanceByDateTime clearanceByDateTime = createClearanceByDateTime(
				eff_date, end_date, clearance_id, selling_price);
		ClearanceByDateTime clearanceByDateTime_phase2 = createClearanceByDateTime(
				eff_date2, end_date2, clearance_id2, selling_price);
		ClearanceZoneSaleInfo clearanceZoneSaleInfo = createClearanceZoneSaleInfo(
				location_z, "UK", "GBP", clearanceByDateTime);
		clearanceZoneSaleInfo
				.addZoneClearanceByDateTime(clearanceByDateTime_phase2);
		ClearanceProductVariant clearanceProductVariant1 = createClearanceProductVariant(
				tpnc1, clearanceZoneSaleInfo, null);

		ClearanceProduct expectedClearanceProduct = createClearanceProduct(
				productId);
		expectedClearanceProduct
				.addClearanceProductVariant(clearanceProductVariant1);

		String key = PriceConstants.CLEARANCE_KEY_PREFIX + productId;
		ClearanceProduct actualClearanceProduct = (ClearanceProduct) repositoryImpl
				.getGenericObject(key,ClearanceProduct.class);
		boolean isEqual = new RPMComparator()
				.compare(actualClearanceProduct, expectedClearanceProduct);
		assertThat(isEqual).isEqualTo(true);

	}

	@Test public void readAndWriteRpmClrForUKNatZoneDataInsertsAndDel()
			throws Exception {
		String productId = "056376327";
		String tpnc1 = "252941940";
		String clearance_id = "ACY-1224988440";
		String location = "20";
		String location_type = "Z";

		ConstructProductAndTpncMapping(productId, tpnc1);
		Map<String, String> productInfoMap = productInfoMap(productId, tpnc1,
				clearance_id, location, location_type, eff_date, end_date,
				selling_price);
		Map<String, String> productInfoMapdel = productInfoMap(productId, tpnc1,
				clearance_id, location, location_type);

		when(rpmClearanceCreReader.getNext()).thenReturn(productInfoMap)
				.thenReturn(null);
		when(rpmClearanceModReader.getNext()).thenReturn(null);
		when(rpmClearanceDelReader.getNext()).thenReturn(productInfoMapdel)
				.thenReturn(null);
		this.rpmclearancewriter.write(null);

		String key = PriceConstants.CLEARANCE_KEY_PREFIX + productId;
		ClearanceProduct actualClearanceProduct = (ClearanceProduct) repositoryImpl
				.getGenericObject(key,ClearanceProduct.class);

		assertNull(actualClearanceProduct);
	}

	@Test public void readAndWriteRpmClrForUKNatStoreDataInsertsAndDel()
			throws Exception {
		String productId = "056376327";
		String tpnc1 = "252941940";
		String clearance_id = "ACY-1224988440";
		String location = "2969";
		String location_type = "S";

		ConstructProductAndTpncMapping(productId, tpnc1);
		Map<String, String> productInfoMap = productInfoMap(productId, tpnc1,
				clearance_id, location, location_type, eff_date, end_date,
				selling_price);
		Map<String, String> productInfoMapdel = productInfoMap(productId, tpnc1,
				clearance_id, location, location_type);

		when(rpmClearanceCreReader.getNext()).thenReturn(productInfoMap)
				.thenReturn(null);
		when(rpmClearanceModReader.getNext()).thenReturn(null);
		when(rpmClearanceDelReader.getNext()).thenReturn(productInfoMapdel)
				.thenReturn(null);
		this.rpmclearancewriter.write(null);

		String key = PriceConstants.CLEARANCE_KEY_PREFIX + productId;
		ClearanceProduct actualClearanceProduct = (ClearanceProduct) repositoryImpl
				.getGenericObject(key,ClearanceProduct.class);

		boolean hasValue = false;
		if(actualClearanceProduct != null ){
			hasValue = true;
		}

		assertThat(hasValue).isEqualTo(false);
	}

	@Test public void readAndWriteRpmClrForUKNatStoreMultiClearanceDataInsertsAndDelOneClearance()
			throws Exception {
		String productId = "056376327";
		String tpnc1 = "252941940";
		String clearance_id = "ACY-1224988440";
		String clearance_id2 = "ACY-1224988441";
		String location = "2969";
		String location_type = "S";

		String selling_price_2 = "2";
		ConstructProductAndTpncMapping(productId, tpnc1);
		Map<String, String> productInfoMap = productInfoMap(productId, tpnc1,
				clearance_id, location, location_type, eff_date, end_date,
				selling_price);
		Map<String, String> productInfoMap2 = productInfoMap(productId, tpnc1,
				clearance_id2, location, location_type, eff_date2, end_date2,
				selling_price_2);
		Map<String, String> productInfoMapdel = productInfoMap(productId, tpnc1,
				clearance_id2, location, location_type);

		when(rpmClearanceCreReader.getNext()).thenReturn(productInfoMap)
				.thenReturn(productInfoMap2).thenReturn(null);
		when(rpmClearanceModReader.getNext()).thenReturn(null);
		when(rpmClearanceDelReader.getNext()).thenReturn(productInfoMapdel)
				.thenReturn(null);
		this.rpmclearancewriter.write(null);
		ClearanceProduct expectedClearanceProduct = createClearanceProduct(
				productId);
		ClearanceByDateTime clearanceByDateTime = createClearanceByDateTime(
				eff_date, end_date, clearance_id, selling_price);

		ClearanceStoreSaleInfo clearanceStoreSaleInfo = createClearanceStoreSaleInfo(
				location, "UK", "GBP", null);
		clearanceStoreSaleInfo.addStoreClearanceByDateTime(clearanceByDateTime);
		ClearanceProductVariant clearanceProductVariant1 = createClearanceProductVariant(
				tpnc1, null, clearanceStoreSaleInfo);
		String key = PriceConstants.CLEARANCE_KEY_PREFIX + productId;
		ClearanceProduct actualClearanceProduct = (ClearanceProduct) repositoryImpl
				.getGenericObject(key,ClearanceProduct.class);
		expectedClearanceProduct
				.addClearanceProductVariant(clearanceProductVariant1);
		boolean isEqual = new RPMComparator()
				.compare(actualClearanceProduct, expectedClearanceProduct);
		assertThat(isEqual).isEqualTo(true);
	}

	@SuppressWarnings({ "static-access",
			"unused" }) @Test public void testRestartabilityForAcayg()
			throws Exception {
		String productId = "056376327";
		String productId2 = "056376999";
		String tpnc2 = "252941999";
		String tpnc1 = "252941940";
		String clearance_id = "ACY-1224988440";
		String clearance_id2 = "ACY-1224988441";
		String location = "2969";
		String location_type = "S";
		// String eff_date = "18-DEC-14";
		// String end_date = "12-FEB-15";
		// String eff_date2 = "14-FEB-15";
		// String end_date2 = "19-FEB-15";
		String selling_price_2 = "2";
		ConstructProductAndTpncMapping(productId, tpnc1);
		ConstructProductAndTpncMapping(productId2, tpnc2);

		Map<String, String> productInfoMap = productInfoMap(productId, tpnc1,
				clearance_id, location, location_type, eff_date, end_date,
				selling_price);
		Map<String, String> productInfoMap2 = productInfoMap(productId2, tpnc2,
				clearance_id2, location, location_type, eff_date2, end_date2,
				selling_price_2);
		runIdentifier = "acayg";
		// rpmclearancewriter = new RPMClearanceWriter(productRepository,
		// rpmClearanceCreReader, rpmClearanceModReader,
		// rpmClearanceDelReader,runIdentifier);
		rpmclearancewriter = new RPMClearanceWriter(testConfiguration,
				repositoryImpl,clearanceEventHandler,rpmClearanceCreReader,rpmClearanceDelReader,rpmClearanceModReader);
		rpmclearancewriter.setRunIdentifier(runIdentifier);
		rpmclearancewriter.setRpmClrFailedFileReader(bufferedReader);
		rpmclearancewriter.setRpmClrFailedDatafile(rpmClrFailedDatafile);
		rpmclearancewriter.setReader(fileReader);
		when(bufferedReader.readLine()).thenReturn(productId2 + "_cre")
				.thenReturn(null);
		// constructFailedProduct(productId2 + "_cre");

		when(rpmClearanceCreReader.getNext()).thenReturn(productInfoMap)
				.thenReturn(productInfoMap2).thenReturn(null);
		// when(rpmclearancewriter.getfailedProductInProviousRunIfExist()).thenReturn(productId2
		// + "_cre");

		rpmclearancewriter.setReader(fileReader);
		rpmclearancewriter.setFileWriter(fileWriter);
		rpmclearancewriter.setBufferedWriter(bufferedWriter);

		Mockito.doNothing().when(bufferedWriter).write(Matchers.anyString());
		Mockito.doNothing().when(bufferedWriter).flush();
		Mockito.doNothing().when(bufferedWriter).close();

		this.rpmclearancewriter.write(null);
		ClearanceProduct expectedClearanceProduct = createClearanceProduct(
				productId2);

		ClearanceByDateTime clearanceByDateTime2 = createClearanceByDateTime(
				eff_date2, end_date2, clearance_id2, selling_price_2);

		ClearanceStoreSaleInfo clearanceStoreSaleInfo = createClearanceStoreSaleInfo(
				location, "UK", "GBP", null);
		clearanceStoreSaleInfo
				.addStoreClearanceByDateTime(clearanceByDateTime2);

		ClearanceProductVariant clearanceProductVariant1 = createClearanceProductVariant(
				tpnc2, null, clearanceStoreSaleInfo);
		/*
		 * Optional<ClearanceProduct> actualClearanceProduct =
		 * productRepository.getClearanceProductByTPNB(productId2);
		 * expectedClearanceProduct
		 * .addClearanceProductVariant(clearanceProductVariant1); boolean
		 * isEqual = new RPMComparator().compare(actualClearanceProduct.get(),
		 * expectedClearanceProduct);
		 */
		String key = PriceConstants.CLEARANCE_KEY_PREFIX + productId;
		ClearanceProduct actualClearanceProduct = (ClearanceProduct) repositoryImpl
				.getGenericObject(key,ClearanceProduct.class);

		assertNull(actualClearanceProduct);

	}

	@SuppressWarnings("static-access") @Test public void testRestartabilityForEmerNonRanged()
			throws Exception {
		String productId = "056376327";
		String productId2 = "056376999";
		String tpnc2 = "252941999";
		String tpnc1 = "252941940";
		String clearance_id = "EM-1224988440";
		String clearance_id2 = "EM-1224988441";
		String location = "2969";
		String location_type = "S";

		String selling_price_2 = "2";
		ConstructProductAndTpncMapping(productId, tpnc1);
		ConstructProductAndTpncMapping(productId2, tpnc2);

		Map<String, String> productInfoMap = productInfoMap(productId, tpnc1,
				clearance_id, location, location_type, eff_date, end_date,
				selling_price);
		Map<String, String> productInfoMap2 = productInfoMap(productId2, tpnc2,
				clearance_id2, location, location_type, eff_date2, end_date2,
				selling_price_2);

		runIdentifier = "emernonranged";
		ImportResource.importSemaphoreForIdentifier
				.put(runIdentifier, new Semaphore(1));

		rpmclearancewriter.setRunIdentifier(runIdentifier);
		when(bufferedReader.readLine()).thenReturn(productId2 + "_cre")
				.thenReturn(null);
		ClearanceEventData clearanceEventMap = new ClearanceEventData();
		writeFailedProductDetailsMapToFile(clearanceEventMap);
				
		when(rpmClearanceCreReader.getNext()).thenReturn(productInfoMap)
				.thenReturn(productInfoMap2).thenReturn(null);
		when(rpmClearanceModReader.getNext()).thenReturn(null);
		when(rpmClearanceDelReader.getNext()).thenReturn(null);

		this.rpmclearancewriter.write(null);
		ClearanceProduct expectedClearanceProduct = createClearanceProduct(
				productId2);

		ClearanceByDateTime clearanceByDateTime2 = createClearanceByDateTime(
				eff_date2, end_date2, clearance_id2, selling_price_2);

		ClearanceStoreSaleInfo clearanceStoreSaleInfo = createClearanceStoreSaleInfo(
				location, "UK", "GBP", null);
		clearanceStoreSaleInfo
				.addStoreClearanceByDateTime(clearanceByDateTime2);

		ClearanceProductVariant clearanceProductVariant1 = createClearanceProductVariant(
				tpnc2, null, clearanceStoreSaleInfo);
		String key = PriceConstants.CLEARANCE_KEY_PREFIX + productId2;
		ClearanceProduct actualClearanceProduct = (ClearanceProduct) repositoryImpl
				.getGenericObject(key,ClearanceProduct.class);
		expectedClearanceProduct
				.addClearanceProductVariant(clearanceProductVariant1);
		boolean isEqual = new RPMComparator()
				.compare(actualClearanceProduct, expectedClearanceProduct);

		assertNull(repositoryImpl.getGenericObject(PriceConstants.CLEARANCE_KEY_PREFIX+productId,ClearanceProduct.class));
		// assertThat(actualClearanceProduct).isEqualTo(expectedClearanceProduct);

		assertThat(isEqual).isEqualTo(true);
		
	}

	@SuppressWarnings("static-access") @Test public void testRestartabilityForEmerRanged()
			throws Exception {
		String productId = "056376327";
		String productId2 = "056376999";
		String tpnc2 = "252941999";
		String tpnc1 = "252941940";
		String clearance_id = "EM-1224988440";
		String clearance_id2 = "EM-1224988441";
		String location = "2969";
		String location_type = "S";
		String selling_price_2 = "2";

		ConstructProductAndTpncMapping(productId, tpnc1);
		ConstructProductAndTpncMapping(productId2, tpnc2);

		Map<String, String> productInfoMap = productInfoMap(productId, tpnc1,
				clearance_id, location, location_type, eff_date, end_date,
				selling_price);
		Map<String, String> productInfoMap2 = productInfoMap(productId2, tpnc2,
				clearance_id2, location, location_type, eff_date2, end_date2,
				selling_price_2);
		runIdentifier = "emerranged";
		ImportResource.importSemaphoreForIdentifier
				.put(runIdentifier, new Semaphore(1));

		rpmclearancewriter.setRunIdentifier(runIdentifier);

		when(bufferedReader.readLine()).thenReturn(productId2 + "_del")
				.thenReturn(null);

		when(rpmClearanceCreReader.getNext()).thenReturn(null);
		when(rpmClearanceModReader.getNext()).thenReturn(null);
		when(rpmClearanceDelReader.getNext()).thenReturn(productInfoMap)
				.thenReturn(productInfoMap2).thenReturn(null);

		rpmclearancewriter.write(null);

		assertNull(repositoryImpl.getGenericObject(PriceConstants.CLEARANCE_KEY_PREFIX+productId2,ClearanceProduct.class));

		assertNull(repositoryImpl.getGenericObject(PriceConstants.CLEARANCE_KEY_PREFIX+productId,ClearanceProduct.class));
	}

	@SuppressWarnings("static-access") @Test public void testRestartabilityForRegNonRanged()
			throws Exception {
		String productId = "056376327";
		String productId2 = "056376999";
		String tpnc2 = "252941999";
		String tpnc1 = "252941940";
		String clearance_id = "RG-1224988440";
		String clearance_id2 = "RG-1224988441";
		String location = "2969";
		String location_type = "S";

		String selling_price_2 = "2";
		ConstructProductAndTpncMapping(productId, tpnc1);
		ConstructProductAndTpncMapping(productId2, tpnc2);

		Map<String, String> productInfoMap = productInfoMap(productId, tpnc1,
				clearance_id, location, location_type, eff_date, end_date,
				selling_price);
		Map<String, String> productInfoMap2 = productInfoMap(productId2, tpnc2,
				clearance_id2, location, location_type, eff_date2, end_date2,
				selling_price_2);
		runIdentifier = "regnonranged";
		ImportResource.importSemaphoreForIdentifier
				.put(runIdentifier, new Semaphore(1));

		when(bufferedReader.readLine()).thenReturn(productId2 + "_cre")
				.thenReturn(null);

		when(rpmClearanceCreReader.getNext()).thenReturn(productInfoMap)
				.thenReturn(productInfoMap2).thenReturn(null);
		when(rpmClearanceModReader.getNext()).thenReturn(null);
		when(rpmClearanceDelReader.getNext()).thenReturn(null);

		this.rpmclearancewriter.write(null);
		ClearanceProduct expectedClearanceProduct = createClearanceProduct(
				productId2);
		ClearanceByDateTime clearanceByDateTime2 = createClearanceByDateTime(
				eff_date2, end_date2, clearance_id2, selling_price_2);

		ClearanceStoreSaleInfo clearanceStoreSaleInfo = createClearanceStoreSaleInfo(
				location, "UK", "GBP", null);
		clearanceStoreSaleInfo
				.addStoreClearanceByDateTime(clearanceByDateTime2);

		ClearanceProductVariant clearanceProductVariant1 = createClearanceProductVariant(
				tpnc2, null, clearanceStoreSaleInfo);
		String key = PriceConstants.CLEARANCE_KEY_PREFIX + productId2;
		ClearanceProduct actualClearanceProduct = (ClearanceProduct) repositoryImpl
				.getGenericObject(key,ClearanceProduct.class);
		expectedClearanceProduct
				.addClearanceProductVariant(clearanceProductVariant1);
		boolean isEqual = new RPMComparator()
				.compare(actualClearanceProduct, expectedClearanceProduct);
		assertNull(repositoryImpl.getGenericObject(PriceConstants.CLEARANCE_KEY_PREFIX+productId,ClearanceProduct.class));

		assertThat(isEqual).isEqualTo(true);
	}

	@SuppressWarnings("static-access") @Test public void testRestartabilityForRegRanged()
			throws Exception {
		String productId = "056376327";
		String productId2 = "056376999";
		String tpnc2 = "252941999";
		String tpnc1 = "252941940";
		String clearance_id = "RG-1224988440";
		String clearance_id2 = "RG-1224988441";
		String location = "2969";
		String location_type = "S";
		String selling_price_2 = "2";
		
		// PRIS-1639
		runIdentifier = "regranged";
		ClearanceEventData ClearanceFailedDataEventMap = new ClearanceEventData();
		writeFailedProductDetailsMapToFile(ClearanceFailedDataEventMap);

		ConstructProductAndTpncMapping(productId, tpnc1);
		ConstructProductAndTpncMapping(productId2, tpnc2);

		Map<String, String> productInfoMap = productInfoMap(productId, tpnc1,
				clearance_id, location, location_type, eff_date, end_date,
				selling_price);
		Map<String, String> productInfoMap2 = productInfoMap(productId2, tpnc2,
				clearance_id2, location, location_type, eff_date2, end_date2,
				selling_price_2);
		runIdentifier = "regranged";
		ImportResource.importSemaphoreForIdentifier
				.put(runIdentifier, new Semaphore(1));
		rpmclearancewriter.setRunIdentifier(runIdentifier);

		when(bufferedReader.readLine()).thenReturn(productId2 + "_mod")
				.thenReturn(null);

		when(rpmClearanceCreReader.getNext()).thenReturn(null);
		when(rpmClearanceDelReader.getNext()).thenReturn(null);
		when(rpmClearanceModReader.getNext()).thenReturn(productInfoMap)
				.thenReturn(productInfoMap2).thenReturn(null);

		this.rpmclearancewriter.write(null);
		ClearanceProduct expectedClearanceProduct = createClearanceProduct(
				productId2);
		ClearanceByDateTime clearanceByDateTime2 = createClearanceByDateTime(
				eff_date2, end_date2, clearance_id2, selling_price_2);

		ClearanceStoreSaleInfo clearanceStoreSaleInfo = createClearanceStoreSaleInfo(
				location, "UK", "GBP", null);
		clearanceStoreSaleInfo
				.addStoreClearanceByDateTime(clearanceByDateTime2);

		ClearanceProductVariant clearanceProductVariant1 = createClearanceProductVariant(
				tpnc2, null, clearanceStoreSaleInfo);

		String key = PriceConstants.CLEARANCE_KEY_PREFIX + productId2;
		ClearanceProduct actualClearanceProduct = (ClearanceProduct) repositoryImpl
				.getGenericObject(key,ClearanceProduct.class);
		expectedClearanceProduct
				.addClearanceProductVariant(clearanceProductVariant1);
		boolean isEqual = new RPMComparator()
				.compare(actualClearanceProduct, expectedClearanceProduct);

		assertNull(repositoryImpl.getGenericObject(PriceConstants.CLEARANCE_KEY_PREFIX+productId,ClearanceProduct.class));

		assertThat(isEqual).isEqualTo(true);
	}

	@SuppressWarnings("static-access") @Test public void shouldDeleteFailedProductDocumentAfterRestartabilityForRegRanged()
			throws Exception {
		String productId = "056376327";
		String productId2 = "056376999";
		String tpnc2 = "252941999";
		String tpnc1 = "252941940";
		String clearance_id = "RG-1224988440";
		String clearance_id2 = "RG-1224988441";
		String location = "2969";
		String location_type = "S";

		String selling_price_2 = "2";
		ConstructProductAndTpncMapping(productId, tpnc1);
		ConstructProductAndTpncMapping(productId2, tpnc2);

		Map<String, String> productInfoMap = productInfoMap(productId, tpnc1,
				clearance_id, location, location_type, eff_date, end_date,
				selling_price);
		Map<String, String> productInfoMap2 = productInfoMap(productId2, tpnc2,
				clearance_id2, location, location_type, eff_date2, end_date2,
				selling_price_2);
		runIdentifier = "regranged";
		ImportResource.importSemaphoreForIdentifier
				.put(runIdentifier, new Semaphore(1));

		rpmclearancewriter.setRunIdentifier(runIdentifier);
		when(bufferedReader.readLine()).thenReturn(productId2 + "_cre")
				.thenReturn(null);
		// constructFailedProduct(productId2 + "_cre");
		// Mocking TRUE if checked if the file exists or not
		when(rpmClrFailedDatafile.exists()).thenReturn(true);
		when(rpmClearanceCreReader.getNext()).thenReturn(productInfoMap)
				.thenReturn(productInfoMap2).thenReturn(null);
		when(rpmClearanceModReader.getNext()).thenReturn(null);
		when(rpmClearanceDelReader.getNext()).thenReturn(null);
		this.rpmclearancewriter.write(null);

		String key = PriceConstants.CLEARANCE_KEY_PREFIX + productId;
		ClearanceProduct actualClearanceProduct = (ClearanceProduct) repositoryImpl
				.getGenericObject(key,ClearanceProduct.class);

		assertNull(actualClearanceProduct);

	}

	@SuppressWarnings({ "static-access",
			"unused" }) @Test public void shouldInsertClrProductDetailsWhenPriceProductNotFound()
			throws Exception {
		String productId = "056376327";
		String tpnc = "252941940";
		String clearance_id = "ACY-1224988440";
		String location = "3276";
		String location_type = "S";
		// String eff_date = "18-DEC-14";
		// String end_date = "12-FEB-15";
		String productIdWithReasonCode = "056376327|PRODUCT NOT FOUND";
		Map<String, String> productInfoMap = productInfoMap(productId, tpnc,
				clearance_id, location, location_type, eff_date, end_date,
				selling_price);

		when(rpmClearanceCreReader.getNext()).thenReturn(productInfoMap)
				.thenReturn(null);
		this.rpmclearancewriter.write(null);
		String key = PriceConstants.CLEARANCE_KEY_PREFIX + productId;
		ClearanceProduct actualClearanceProduct = (ClearanceProduct) repositoryImpl
				.getGenericObject(key,ClearanceProduct.class);

		assertNotNull(actualClearanceProduct);
	}

	@SuppressWarnings({ "static-access",
			"unused" }) @Test public void shouldWriteProductDetailsToRejectFileWhenEndDateIsNull()
			throws Exception {
		// In this test mode and hence reject file will not be created. Hence we
		// dont assert by opening the reject file.
		String productId = "056376327";
		String tpnc = "252941940";
		String clearance_id = "ACY-1224988440";
		String location = "3276";
		String location_type = "S";
		String end_date = "";
		String productIdWithReasonCode = "056376327|NULL END DATE";

		Map<String, String> productInfoMap = productInfoMap(productId, tpnc,
				clearance_id, location, location_type, eff_date, end_date,
				selling_price);

		when(rpmClearanceCreReader.getNext()).thenReturn(productInfoMap)
				.thenReturn(null);
		when(rpmClearanceModReader.getNext()).thenReturn(null);
		when(rpmClearanceDelReader.getNext()).thenReturn(null);

		this.rpmclearancewriter.write(null);

		String key = PriceConstants.CLEARANCE_KEY_PREFIX + productId;
		ClearanceProduct actualClearanceProduct = (ClearanceProduct) repositoryImpl
				.getGenericObject(key,ClearanceProduct.class);

		assertNull(actualClearanceProduct);

	}

	@SuppressWarnings({ "static-access",
			"unused" }) @Test public void shouldWriteProductDetailsToRejectFileWhenDataIssue()
			throws Exception {
		String productId = "056376327";
		String tpnc = "252941940";
		String clearance_id = "ACY-1224988440";
		String location = "3276";
		String location_type = "S";
		// String eff_date = "18-DEC-14";
		String end_date = "";
		String productIdWithReasonCode = "056376327|NULL END DATE";
		Map<String, String> productInfoMap = productInfoMap(productId, tpnc,
				clearance_id, location, location_type, eff_date, end_date,
				selling_price);
		rpmclearancewriter = new RPMClearanceWriter(testConfiguration,
				repositoryImpl,clearanceEventHandler,rpmClearanceCreReader,rpmClearanceDelReader,rpmClearanceModReader);
		rpmclearancewriter.setRunIdentifier(runIdentifier);
		rpmclearancewriter.setFileWriter(fileWriter);
		rpmclearancewriter.setRpmClrFailedFileReader(bufferedReader);
		rpmclearancewriter.setRpmClrFailedDatafile(rpmClrFailedDatafile);
		rpmclearancewriter.setReader(fileReader);
		
		Mockito.doThrow(new ArrayIndexOutOfBoundsException())
				.when(bufferedReader).readLine();
		when(rpmClearanceCreReader.getNext()).thenReturn(productInfoMap)
				.thenReturn(null);
		this.rpmclearancewriter.write(null);
		Mockito.doThrow(new IOException()).when(bufferedReader).readLine();
		this.rpmclearancewriter.write(null);
		// to mock a generic exception
		Mockito.doThrow(new IllformedLocaleException()).when(bufferedReader)
				.readLine();
		this.rpmclearancewriter.write(null);
		String key = PriceConstants.CLEARANCE_KEY_PREFIX + productId;
		ClearanceProduct actualClearanceProduct = (ClearanceProduct) repositoryImpl
				.getGenericObject(key,ClearanceProduct.class);

		assertNull(actualClearanceProduct);
	}

	@Test public void deleteExpiredClearanceProductForStore() throws Exception {
		String productId = "056376327";
		String productId2 = "056376999";
		String tpnc2 = "252941999";
		String tpnc1 = "252941940";
		String clearance_id = "RG-1224988440";
		String clearance_id2 = "RG-1224988441";
		String location = "3020";
		String location_type = "S";
		String eff_date = "18-DEC-14";
		String end_date = "25-DEC-14";
		String selling_price_2 = "2";
		ConstructProductAndTpncMapping(productId, tpnc1);
		ConstructProductAndTpncMapping(productId2, tpnc2);

		ClearanceProduct expiredClearanceProduct = createClearanceProduct(
				productId);
		ClearanceByDateTime clearanceByDateTime = createClearanceByDateTime(
				eff_date, end_date, clearance_id, selling_price_2);
		ClearanceStoreSaleInfo clearanceStoreSaleInfo = createClearanceStoreSaleInfo(
				location, "UK", "GBP", null);
		clearanceStoreSaleInfo.addStoreClearanceByDateTime(clearanceByDateTime);
		ClearanceProductVariant clearanceProductVariant = createClearanceProductVariant(
				tpnc1, null, clearanceStoreSaleInfo);
		expiredClearanceProduct
				.addClearanceProductVariant(clearanceProductVariant);
		insertClearanceProduct(expiredClearanceProduct);

		Map<String, String> productInfoMap2 = productInfoMap(productId, tpnc1,
				clearance_id2, location, location_type, eff_date2, end_date2,
				selling_price_2);
		runIdentifier = "acayg";

		rpmclearancewriter.setRunIdentifier(runIdentifier);

		when(rpmClearanceCreReader.getNext()).thenReturn(productInfoMap2)
				.thenReturn(null);
		when(rpmClearanceModReader.getNext()).thenReturn(null);
		when(rpmClearanceDelReader.getNext()).thenReturn(null);
		this.rpmclearancewriter.write(null);

		/**
		 * Buliding expected clearance
		 */
		ClearanceProduct expectedClearanceProduct = createClearanceProduct(
				productId);
		ClearanceByDateTime clearanceByDateTime2 = createClearanceByDateTime(
				eff_date2, end_date2, clearance_id2, selling_price_2);
		ClearanceStoreSaleInfo clearanceStoreSaleInfo2 = createClearanceStoreSaleInfo(
				location, "UK", "GBP", null);
		clearanceStoreSaleInfo2
				.addStoreClearanceByDateTime(clearanceByDateTime2);
		ClearanceProductVariant clearanceProductVariant2 = createClearanceProductVariant(
				tpnc1, null, clearanceStoreSaleInfo2);
		expectedClearanceProduct
				.addClearanceProductVariant(clearanceProductVariant2);

		String key = PriceConstants.CLEARANCE_KEY_PREFIX + productId;
		ClearanceProduct actualClearanceProduct = (ClearanceProduct) repositoryImpl
				.getGenericObject(key,ClearanceProduct.class);

		boolean isEqual = new RPMComparator()
				.compare(actualClearanceProduct, expectedClearanceProduct);
		assertThat(isEqual).isEqualTo(true);
	}

	@Test public void deleteExpiredClearanceProductForZone() throws Exception {
		String productId = "056376327";
		String productId2 = "056376999";
		String tpnc2 = "252941999";
		String tpnc1 = "252941940";
		String clearance_id = "RG-1224988440";
		String clearance_id2 = "RG-1224988441";
		String location = "20";
		String location_type = "Z";
		String eff_date = "18-DEC-14";
		String end_date = "25-DEC-14";
		String selling_price_2 = "2";
		ConstructProductAndTpncMapping(productId, tpnc1);
		ConstructProductAndTpncMapping(productId2, tpnc2);

		ClearanceProduct expiredClearanceProduct = createClearanceProduct(
				productId);
		ClearanceByDateTime clearanceByDateTime = createClearanceByDateTime(
				eff_date, end_date, clearance_id, selling_price_2);
		ClearanceZoneSaleInfo clearanceZoneSaleInfo = createClearanceZoneSaleInfo(
				location, "UK", "GBP", null);
		clearanceZoneSaleInfo.addZoneClearanceByDateTime(clearanceByDateTime);
		ClearanceProductVariant clearanceProductVariant = createClearanceProductVariant(
				tpnc1, clearanceZoneSaleInfo, null);
		expiredClearanceProduct
				.addClearanceProductVariant(clearanceProductVariant);
		insertClearanceProduct(expiredClearanceProduct);

		Map<String, String> productInfoMap2 = productInfoMap(productId, tpnc1,
				clearance_id2, location, location_type, eff_date2, end_date2,
				selling_price_2);
		runIdentifier = "acayg";

		rpmclearancewriter.setRunIdentifier(runIdentifier);

		when(rpmClearanceCreReader.getNext()).thenReturn(productInfoMap2)
				.thenReturn(null);
		when(rpmClearanceModReader.getNext()).thenReturn(null);
		when(rpmClearanceDelReader.getNext()).thenReturn(null);

		this.rpmclearancewriter.write(null);

		/**
		 * Buliding expected clearance
		 */
		ClearanceProduct expectedClearanceProduct = createClearanceProduct(
				productId);
		ClearanceByDateTime clearanceByDateTime2 = createClearanceByDateTime(
				eff_date2, end_date2, clearance_id2, selling_price_2);
		ClearanceZoneSaleInfo clearanceZoneSaleInfo2 = createClearanceZoneSaleInfo(
				location, "UK", "GBP", null);
		clearanceZoneSaleInfo2.addZoneClearanceByDateTime(clearanceByDateTime2);
		ClearanceProductVariant clearanceProductVariant2 = createClearanceProductVariant(
				tpnc1, clearanceZoneSaleInfo2, null);
		expectedClearanceProduct
				.addClearanceProductVariant(clearanceProductVariant2);

		String key = PriceConstants.CLEARANCE_KEY_PREFIX + productId;
		ClearanceProduct actualClearanceProduct = (ClearanceProduct) repositoryImpl
				.getGenericObject(key,ClearanceProduct.class);
		boolean isEqual = new RPMComparator()
				.compare(actualClearanceProduct, expectedClearanceProduct);
		assertThat(isEqual).isEqualTo(true);
	}

	@Test public void removeExpiredClearanceProductForStore() throws Exception {
		String productId = "056376327";
		String productId2 = "056376999";
		String tpnc2 = "252941999";
		String tpnc1 = "252941940";
		String clearance_id = "RG-1224988440";
		String clearance_id2 = "RG-1224988441";
		String location = "3020";
		String location_type = "S";
		String eff_date = "18-DEC-14";
		String end_date = "25-DEC-14";
		String eff_date2 = "14-NOV-14";
		String end_date2 = "29-NOV-14";
		String selling_price_2 = "2";
		ConstructProductAndTpncMapping(productId, tpnc1);
		ConstructProductAndTpncMapping(productId2, tpnc2);

		ClearanceProduct expiredClearanceProduct = createClearanceProduct(
				productId);
		ClearanceByDateTime clearanceByDateTime = createClearanceByDateTime(
				eff_date, end_date, clearance_id, selling_price_2);
		ClearanceStoreSaleInfo clearanceStoreSaleInfo = createClearanceStoreSaleInfo(
				location, "UK", "GBP", null);
		clearanceStoreSaleInfo.addStoreClearanceByDateTime(clearanceByDateTime);
		ClearanceProductVariant clearanceProductVariant = createClearanceProductVariant(
				tpnc1, null, clearanceStoreSaleInfo);
		expiredClearanceProduct
				.addClearanceProductVariant(clearanceProductVariant);
		insertClearanceProduct(expiredClearanceProduct);

		Map<String, String> productInfoMap2 = productInfoMap(productId, tpnc1,
				clearance_id2, location, location_type, eff_date2, end_date2,
				selling_price_2);
		runIdentifier = "acayg";
		rpmclearancewriter.setRunIdentifier(runIdentifier);

		when(rpmClearanceCreReader.getNext()).thenReturn(null);
		when(rpmClearanceModReader.getNext()).thenReturn(null);
		when(rpmClearanceDelReader.getNext()).thenReturn(productInfoMap2)
				.thenReturn(null);
		this.rpmclearancewriter.write(null);

		/**
		 * In this case expected clearance should be null
		 */
		assertNull(repositoryImpl.getGenericObject(PriceConstants.CLEARANCE_KEY_PREFIX+productId,ClearanceProduct.class));
	}

	@Test public void removeExpiredClearanceProductForZone() throws Exception {
		String productId = "056376327";
		String productId2 = "056376999";
		String tpnc2 = "252941999";
		String tpnc1 = "252941940";
		String clearance_id = "RG-1224988440";
		String clearance_id2 = "RG-1224988441";
		String location = "20";
		String location_type = "Z";
		String eff_date = "18-DEC-14";
		String end_date = "25-DEC-14";
		String eff_date2 = "14-NOV-14";
		String end_date2 = "29-NOV-14";
		String selling_price_2 = "2";
		ConstructProductAndTpncMapping(productId, tpnc1);
		ConstructProductAndTpncMapping(productId2, tpnc2);

		ClearanceProduct expiredClearanceProduct = createClearanceProduct(
				productId);
		ClearanceByDateTime clearanceByDateTime = createClearanceByDateTime(
				eff_date, end_date, clearance_id, selling_price_2);
		ClearanceZoneSaleInfo clearanceZoneSaleInfo = createClearanceZoneSaleInfo(
				location, "UK", "GBP", null);
		clearanceZoneSaleInfo.addZoneClearanceByDateTime(clearanceByDateTime);
		ClearanceProductVariant clearanceProductVariant = createClearanceProductVariant(
				tpnc1, clearanceZoneSaleInfo, null);
		expiredClearanceProduct
				.addClearanceProductVariant(clearanceProductVariant);
		insertClearanceProduct(expiredClearanceProduct);

		Map<String, String> productInfoMap2 = productInfoMap(productId, tpnc1,
				clearance_id, location, location_type, eff_date2, end_date2,
				selling_price_2);

		Map<String, String> productInfoMap1 = productInfoMap(productId2, tpnc2,
				clearance_id2, location, location_type, eff_date2, end_date2,
				selling_price_2);

		runIdentifier = "acayg";

		rpmclearancewriter.setRunIdentifier(runIdentifier);

		when(rpmClearanceCreReader.getNext()).thenReturn(null);
		when(rpmClearanceModReader.getNext()).thenReturn(null);
		when(rpmClearanceDelReader.getNext()).thenReturn(productInfoMap2)
				.thenReturn(productInfoMap1).thenReturn(null);
		this.rpmclearancewriter.write(null);

		/**
		 * In this case expected clearance should be null
		 */
		String key = PriceConstants.CLEARANCE_KEY_PREFIX + productId;
		ClearanceProduct actualClearanceProduct = (ClearanceProduct) repositoryImpl
				.getGenericObject(key,ClearanceProduct.class);

		assertNull(actualClearanceProduct);
	}

	@Test public void shouldIReplaceTheWholeProductForOneTimeImportForCre()
			throws Exception {
		String productId = "056376327";
		String productId2 = "056376999";
		String tpnc2 = "252941999";
		String tpnc1 = "252941940";
		String clearance_id = "EC-1224988440";
		String clearance_id2 = "EC-1224988441";
		String location = "20";
		String location_type = "Z";
		String selling_price_2 = "2";
		String modSellingPrice = "1";
		ConstructProductAndTpncMapping(productId, tpnc1);
		ConstructProductAndTpncMapping(productId2, tpnc2);

		// Insert corrupted RPM clearance data
		ClearanceProduct corruptedClearanceProduct = createClearanceProduct(
				productId);
		ClearanceByDateTime clearanceByDateTime = createClearanceByDateTime(
				eff_date, end_date, clearance_id + "##$$^%^%", selling_price_2);
		ClearanceZoneSaleInfo clearanceZoneSaleInfo = createClearanceZoneSaleInfo(
				location, "UK", "GBP", null);
		clearanceZoneSaleInfo.addZoneClearanceByDateTime(clearanceByDateTime);
		ClearanceProductVariant clearanceProductVariant = createClearanceProductVariant(
				tpnc1, clearanceZoneSaleInfo, null);
		corruptedClearanceProduct
				.addClearanceProductVariant(clearanceProductVariant);
		insertClearanceProduct(corruptedClearanceProduct);
		// Construct Maps for two CRE and one MOD for the first CRE (Price
		// change)
		Map<String, String> productInfoMap1 = productInfoMap(productId, tpnc1,
				clearance_id, location, location_type, eff_date, end_date,
				selling_price_2);
		Map<String, String> productInfoMap2 = productInfoMap(productId, tpnc1,
				clearance_id2, location, location_type, eff_date2, end_date2,
				selling_price_2);
		Map<String, String> productInfoMap3 = productInfoMap(productId, tpnc1,
				clearance_id, location, location_type, eff_date, end_date,
				modSellingPrice);
		runIdentifier = "onetime";
		ImportResource.importSemaphoreForIdentifier
				.put(runIdentifier, new Semaphore(1));

		rpmclearancewriter.setRunIdentifier(runIdentifier);

		when(rpmClearanceCreReader.getNext()).thenReturn(productInfoMap1)
				.thenReturn(productInfoMap2).thenReturn(productInfoMap3)
				.thenReturn(null);
		this.rpmclearancewriter.write(null);

		// Build the Expected product which contains the a clr with effdate2 and
		// effdate1(with mod price)
		ClearanceProduct replacedClearanceProduct = createClearanceProduct(
				productId);
		ClearanceByDateTime replacedClearanceByDateTime1 = createClearanceByDateTime(
				eff_date, end_date, clearance_id, modSellingPrice);

		ClearanceByDateTime replacedClearanceByDateTime = createClearanceByDateTime(
				eff_date2, end_date2, clearance_id2, selling_price_2);
		ClearanceZoneSaleInfo replacedClearanceZoneSaleInfo = createClearanceZoneSaleInfo(
				location, "UK", "GBP", null);

		replacedClearanceZoneSaleInfo
				.addZoneClearanceByDateTime(replacedClearanceByDateTime1);
		replacedClearanceZoneSaleInfo
				.addZoneClearanceByDateTime(replacedClearanceByDateTime);

		ClearanceProductVariant replacedClearanceProductVariant = createClearanceProductVariant(
				tpnc1, replacedClearanceZoneSaleInfo, null);
		replacedClearanceProduct
				.addClearanceProductVariant(replacedClearanceProductVariant);

		String key = PriceConstants.CLEARANCE_KEY_PREFIX + productId;
		ClearanceProduct actualClearanceProduct = (ClearanceProduct) repositoryImpl
				.getGenericObject(key,ClearanceProduct.class);

		boolean isEqual = new RPMComparator()
				.compare(actualClearanceProduct, replacedClearanceProduct);
		assertThat(isEqual).isEqualTo(true);
	}

	@SuppressWarnings("unused") private String getfailedProductInProviousRunIfExist(
			String file) throws IOException {
		File mmClrFailedDatafile = new File(file);
		FileReader reader;
		String line;
		BufferedReader rpmClrFailedFileReader;
		String failedProduct = "";
		try {
			reader = new FileReader(mmClrFailedDatafile);
			rpmClrFailedFileReader = new BufferedReader(reader);
			while ((line = rpmClrFailedFileReader.readLine()) != null) {
				failedProduct = line;
			}
			rpmClrFailedFileReader.close();
		} catch (FileNotFoundException e) {
			return null;
		} catch (IOException e) {
			return null;
		}
		return failedProduct;
	}

	private Map<String, String> productInfoMap(String productId, String tpnc,
			String clearance_id, String location, String location_type) {
		Map<String, String> productInfoMap = new HashMap<>();
		productInfoMap.put(CSVHeaders.RpmClearance_Del.REC_DESCRIPTOR,
				rec_descriptor_cre);
		productInfoMap.put(CSVHeaders.RpmClearance_Del.LINE_NOR, line_nor);
		productInfoMap
				.put(CSVHeaders.RpmClearance_Del.CLEARANCE_ID, clearance_id);
		productInfoMap.put(CSVHeaders.RpmClearance_Del.TPNB, productId);
		productInfoMap.put(CSVHeaders.RpmClearance_Del.TPNC, tpnc);
		productInfoMap.put(CSVHeaders.RpmClearance_Del.LOCATION, location);
		productInfoMap
				.put(CSVHeaders.RpmClearance_Del.LOCATION_TYPE, location_type);

		return productInfoMap;
	}

	private Map<String, String> productInfoMap(String productId, String tpnc,
			String clearance_id, String location, String location_type,
			String eff_date, String end_date, String selling_price) {
		Map<String, String> productInfoMap = new HashMap<>();
		productInfoMap.put(CSVHeaders.RpmClearance_Cre_Mod.REC_DESCRIPTOR,
				rec_descriptor_cre);
		productInfoMap.put(CSVHeaders.RpmClearance_Cre_Mod.LINE_NOR, line_nor);
		productInfoMap
				.put(CSVHeaders.RpmClearance_Cre_Mod.EVENT_TYPE, event_type);
		productInfoMap.put(CSVHeaders.RpmClearance_Cre_Mod.CLEARANCE_ID,
				clearance_id);
		productInfoMap.put(CSVHeaders.RpmClearance_Cre_Mod.TPNB, productId);
		productInfoMap.put(CSVHeaders.RpmClearance_Cre_Mod.TPNC, tpnc);
		productInfoMap.put(CSVHeaders.RpmClearance_Cre_Mod.LOCATION, location);
		productInfoMap.put(CSVHeaders.RpmClearance_Cre_Mod.LOCATION_TYPE,
				location_type);
		productInfoMap
				.put(CSVHeaders.RpmClearance_Cre_Mod.EFFECTIVE_DATE, eff_date);
		productInfoMap.put(CSVHeaders.RpmClearance_Cre_Mod.END_DATE, end_date);
		productInfoMap.put(CSVHeaders.RpmClearance_Cre_Mod.SELLING_PRICE,
				selling_price);
		productInfoMap
				.put(CSVHeaders.RpmClearance_Cre_Mod.SELLING_UOM, sellingUom);
		productInfoMap.put(CSVHeaders.RpmClearance_Cre_Mod.SELLING_CURRENCY,
				sellingcurr);

		return productInfoMap;
	}
	
	//This method used to prepare input data map in case of MOD operations
		private Map<String, String> productInfoMap(Map<String, String> dataMap,String event_type) {
			
			
			dataMap.put(CSVHeaders.RpmClearance_Cre_Mod.EVENT_TYPE,
					event_type);
			return dataMap;
		}

	public void ConstructProductAndTpncMapping(String tpnb, String tpnc)
			throws Exception {
		Product product = new Product(tpnb);
		ProductVariant productVariant = new ProductVariant(tpnc);
		productVariant.setSellingUOM(sellingUom);
		product.addProductVariant(productVariant);
		repositoryImpl.insertObject(PriceConstants.PRODUCT_KEY_PREFIX+product.getTPNB(),product);
		repositoryImpl.mapLookUps(tpnc, tpnb);

	}

	@SuppressWarnings("unused") private void constructFailedProduct(
			String value) throws IOException {
		ImportResource.importSemaphoreForIdentifier
				.put(runIdentifier, new Semaphore(1));
		File f = new File(
				testConfiguration.getRpmClrImportFailedFile() + "/RR_RPM_"
						+ runIdentifier + ".txt");
		FileWriter fileWriter = new FileWriter(f);
		BufferedWriter bw = new BufferedWriter(fileWriter);
		bw.write(value);
		bw.flush();
		bw.close();
	}

	public ClearanceProduct createClearanceProduct(String productId) {
		ClearanceProduct clearanceProduct = new ClearanceProduct(productId);
		String docType = "datedPrice";
		String dateTimeFormat = "ISO8601";
		String countryFormat = "ISO3166";
		String currencyFormat = "ISO4217";
		String version = "1.0";
		String prodType = "tpnb";
		clearanceProduct.setVersionNo(version);
		clearanceProduct.setDocType(docType);
		clearanceProduct.setCountryFormat(countryFormat);
		clearanceProduct.setCurrencyFormat(currencyFormat);
		clearanceProduct.setDateTimeFormat(dateTimeFormat);
		clearanceProduct.setProdType(prodType);
		clearanceProduct.setSellingUom(sellingUom);
		

		return clearanceProduct;
	}

	public ClearanceByDateTime createClearanceByDateTime(String effcDate,
			String endDate, String clrRef, String clrPrice)
			throws ParseException {
		ClearanceByDateTime clearanceByDateTime = new ClearanceByDateTime();
		clearanceByDateTime.setEffvDateTime(
				Dockyard.getISO8601FormatStartDateForRpmClr(effcDate));
		clearanceByDateTime.setEndDateTime(
				Dockyard.getISO8601FormatEndDateForRPMClr(endDate));
		clearanceByDateTime.setClearanceRef(clrRef);
		clearanceByDateTime.setClearancePrice(
				Dockyard.priceScaleRoundHalfUp(currencyCode, clrPrice));
		return clearanceByDateTime;
	}

	public ClearanceZoneSaleInfo createClearanceZoneSaleInfo(String zone,
			String country, String currency,
			ClearanceByDateTime clearanceByDateTime) throws ParseException {
		ClearanceZoneSaleInfo clearanceZoneSaleInfo = new ClearanceZoneSaleInfo();
		clearanceZoneSaleInfo.setClearanceZoneId(zone);
		clearanceZoneSaleInfo.setCountryCode(country);
		clearanceZoneSaleInfo.setCurrency(currency);
		if (clearanceByDateTime != null) {
			clearanceZoneSaleInfo
					.addZoneClearanceByDateTime(clearanceByDateTime);
		}
		return clearanceZoneSaleInfo;
	}

	public ClearanceStoreSaleInfo createClearanceStoreSaleInfo(String store,
			String country, String currency,
			ClearanceByDateTime clearanceByDateTime) throws ParseException {
		ClearanceStoreSaleInfo clearanceStoreSaleInfo = new ClearanceStoreSaleInfo();
		clearanceStoreSaleInfo.setClearanceStoreId(store.trim());
		clearanceStoreSaleInfo.setCountryCode(country);
		clearanceStoreSaleInfo.setCurrency(currency);
		if (clearanceByDateTime != null) {
			clearanceStoreSaleInfo
					.addStoreClearanceByDateTime(clearanceByDateTime);
		}
		return clearanceStoreSaleInfo;
	}

	public ClearanceProductVariant createClearanceProductVariant(String tpnc,
			ClearanceZoneSaleInfo clearanceZoneSaleInfo,
			ClearanceStoreSaleInfo clearanceStoreSaleInfo) {
		ClearanceProductVariant clearanceProductVariant = new ClearanceProductVariant(
				tpnc);
		if (clearanceZoneSaleInfo != null) {
			clearanceProductVariant
					.addClearanceZoneSaleInfo(clearanceZoneSaleInfo);
		}
		if (clearanceStoreSaleInfo != null) {
			clearanceProductVariant
					.addClearanceStoreSaleInfo(clearanceStoreSaleInfo);
		}
		return clearanceProductVariant;
	}

	private void insertClearanceProduct(
			ClearanceProduct clearanceProductTobeInserted) throws Exception {
		String key = PriceConstants.CLEARANCE_KEY_PREFIX + clearanceProductTobeInserted.getProductId();
		repositoryImpl.insertObject(key,clearanceProductTobeInserted);
	}

	@SuppressWarnings("unused") @Test public void failedProductstest() {
		String failedProduct = "055555_cre";
		String product = failedProduct.split("_")[0];
		String module = failedProduct.split("_")[1];
	}

	@Test public void testCreateRpmClearanceReader() {

		try {
			rpmclearancewriter
					.createRpmClearanceReader(PriceConstants.CRE_CSV_READER);
		} catch (WriterBusinessException e) {
			assertThat(e).hasNoCause();
		}

		try {
			rpmclearancewriter
					.createRpmClearanceReader(PriceConstants.MOD_CSV_READER);
		} catch (WriterBusinessException e) {
			assertThat(e).hasNoCause();
		}

		try {
			rpmclearancewriter
					.createRpmClearanceReader(PriceConstants.DEL_CSV_READER);
		} catch (WriterBusinessException e) {
			assertThat(e).hasNoCause();
		}

	}

	@Test public void testGetfailedProductInProviousRunIfExistFNFExcepiton()
			throws IOException, ColumnNotFoundException {

		Configuration mockconfig = mock(Configuration.class);
		Mockito.doReturn("").when(mockconfig).getRpmClrImportFailedFile();

		RPMClearanceWriter localRpmclearancewriter = new RPMClearanceWriter(
				mockconfig, repositoryImpl,clearanceEventHandler);

		localRpmclearancewriter.setReader(null);

		String fnf = localRpmclearancewriter
				.getfailedProductInProviousRunIfExist();

		assertThat(fnf).isEqualTo(null);
	}
	
	
	/*
	 * PRIS-1662-Test Cases Below testcase checking the event publishing part,
	 * integrate to the RPMClearanceWriter and confirm that proper data event is
	 * sent to publish.
	 */
	@Test
	public void shouldInvokePublishEventsForRPMClearancesForCre() throws Exception {

		// first line of data of the clearance file
		String productId1 = "072820636";
		String tpnc1 = "275684805";
		String clearance_id1 = "AC-1224988454";
		String location1 = "2425";
		String location_type1 = "S";
		String selling_price1 = "74";
		ConstructProductAndTpncMapping(productId1, tpnc1);

		ClearanceEventData clearanceDataEventMap = new ClearanceEventData();
		Map<String, String> productInfoMap = productInfoMap(productId1, tpnc1, clearance_id1, location1, location_type1,
				eff_date, end_date, selling_price1);

		when(rpmClearanceCreReader.getNext()).thenReturn(productInfoMap).thenReturn(null);

		this.rpmclearancewriter.write(null);

		ArgumentCaptor<ClearanceEventData> argumentMap = ArgumentCaptor.forClass(ClearanceEventData.class);
		
		Set<String> testSet = new HashSet<>();
		testSet.add("S_2425_AC-1224988454");
		String effectiveDate = Dockyard.getISO8601FormatStartDateForRpmClr(eff_date);
		clearanceDataEventMap.put("tpnc:275684805_S_" + effectiveDate + "_GBP_I", testSet);

		Mockito.verify(clearanceEventHandler, Mockito.times(1)).publishEventsForClearances(argumentMap.capture());
		assertEquals(clearanceDataEventMap, argumentMap.getValue());
	}

	/*
	 * This is Negative Testcase. This is checking the condition that if endDate
	 * is expired ,then will not try to publish event.
	 */
	@Test
	public void shouldNotInvokePublishEventsForRPMClearancesForCre() throws Exception {
		// first line of data of the clearance file
		String productId = "072820636";
		String tpnc = "275684805";
		String clearance_id = "AC-1224988454";
		String location = "2425";
		String location_type = "S";
		String eff_date = "20-NOV-14";
		String end_date = "28-SEP-15";
		String selling_price = "74";
		ConstructProductAndTpncMapping(productId, tpnc);
		Map<String, String> productInfoMap = productInfoMap(productId, tpnc, clearance_id, location, location_type,
				eff_date, end_date, selling_price);

		when(rpmClearanceCreReader.getNext()).thenReturn(productInfoMap).thenReturn(null);

		this.rpmclearancewriter.write(null);

		ArgumentCaptor<ClearanceEventData> argumentMap = ArgumentCaptor.forClass(ClearanceEventData.class);

		Mockito.verify(clearanceEventHandler, Mockito.times(0)).publishEventsForClearances(argumentMap.capture());

	}

	/*
	 * This testcase verify the grouping logic of the data.In this cae, 2 lines
	 * of data passing (which has same productId and same startDate. So it
	 * provide only one event.
	 */
	@Test
	public void shouldInvokePublishEventsForRPMClearancesForCreWithGrouping() throws Exception {
		// first line of data of the clearance file
		String productIdFirstClearance = "072820636";
		String tpncFirstClearance = "275684805";
		String clearance_idFirstClearance = "AC-1224988454";
		String locationFirstClearance = "2425";
		String location_typeFirstClearance = "S";
		String selling_priceFirstClearance = "74";

		// second line of data of the clearance file
		String productIdSecondClearance = "072820636";
		String tpncSecondClearance = "275684805";
		String clearance_idSecondClearance = "AC-1224988455";
		String locationSecondClearance = "5171";
		String location_typeSecondClearance = "S";
		String selling_priceSecondClearance = "75";

		ConstructProductAndTpncMapping(productIdFirstClearance, tpncFirstClearance);
		ConstructProductAndTpncMapping(productIdSecondClearance, tpncSecondClearance);

		ClearanceEventData clearanceDataEventMap = new ClearanceEventData();

		Map<String, String> productInfoMap1 = productInfoMap(productIdFirstClearance, tpncFirstClearance,
				clearance_idFirstClearance, locationFirstClearance, location_typeFirstClearance, eff_date, end_date,
				selling_priceFirstClearance);

		Map<String, String> productInfoMap2 = productInfoMap(productIdSecondClearance, tpncSecondClearance,
				clearance_idSecondClearance, locationSecondClearance, location_typeSecondClearance, eff_date, end_date2,
				selling_priceSecondClearance);

		when(rpmClearanceCreReader.getNext()).thenReturn(productInfoMap1).thenReturn(productInfoMap2).thenReturn(null);
		this.rpmclearancewriter.write(null);
		ArgumentCaptor<ClearanceEventData> argumentMap = ArgumentCaptor.forClass(ClearanceEventData.class);
		// Expected event data
		Set<String> testSet = new HashSet<>();
		testSet.add("S_5171_AC-1224988455");
		testSet.add("S_2425_AC-1224988454");
		String effectiveDate = Dockyard.getISO8601FormatStartDateForRpmClr(eff_date);
		clearanceDataEventMap.put("tpnc:275684805_S_" + effectiveDate + "_GBP_I", testSet);

		Mockito.verify(clearanceEventHandler, Mockito.times(1)).publishEventsForClearances(argumentMap.capture());
		assertEquals(clearanceDataEventMap, argumentMap.getValue());

	}
	/*
	 * This testcase verify the grouping logic. This case grouping will not work
	 * , because productId(tpnc) be different for the two lines.So 2 sets of
	 * data inserted to the event map.
	 */

	@Test
	public void shouldInvokePublishEventsForRPMClearancesForCreWithoutGrouping() throws Exception {
		// first line of data of the clearance file
		String productIdFirstClearance = "072820636";
		String tpncFirstClearance = "275684805";
		String clearance_idFirstClearance = "AC-1224988454";
		String locationFirstClearance = "2425";
		String location_typeFirstClearance = "S";
		String selling_priceFirstClearance = "74";

		// second line of data of the clearance file
		String productIdSecondClearance = "072820636";
		String tpncSecondClearance = "275684806";
		String clearance_idSecondClearance = "AC-1224988455";
		String locationSecondClearance = "5171";
		String location_typeSecondClearance = "S";
		String selling_priceSecondClearance = "75";

		ConstructProductAndTpncMapping(productIdFirstClearance, tpncFirstClearance);
		ConstructProductAndTpncMapping(productIdSecondClearance, tpncSecondClearance);

		ClearanceEventData clearanceDataEventMap = new ClearanceEventData();

		Map<String, String> productInfoMap1 = productInfoMap(productIdFirstClearance, tpncFirstClearance,
				clearance_idFirstClearance, locationFirstClearance, location_typeFirstClearance, eff_date, end_date,
				selling_priceFirstClearance);

		Map<String, String> productInfoMap2 = productInfoMap(productIdSecondClearance, tpncSecondClearance,
				clearance_idSecondClearance, locationSecondClearance, location_typeSecondClearance, eff_date, end_date2,
				selling_priceSecondClearance);

		when(rpmClearanceCreReader.getNext()).thenReturn(productInfoMap1).thenReturn(productInfoMap2).thenReturn(null);
		this.rpmclearancewriter.write(null);
		ArgumentCaptor<ClearanceEventData> argumentMap = ArgumentCaptor.forClass(ClearanceEventData.class);
		// Expected event data
		Set<String> testSet = new HashSet<>();
		Set<String> testSet2 = new HashSet<>();
		testSet.add("S_2425_AC-1224988454");
		testSet2.add("S_5171_AC-1224988455");

		String effectiveDate = Dockyard.getISO8601FormatStartDateForRpmClr(eff_date);
		clearanceDataEventMap.put("tpnc:275684805_S_" + effectiveDate + "_GBP_I", testSet);
		clearanceDataEventMap.put("tpnc:275684806_S_" + effectiveDate + "_GBP_I", testSet2);

		Mockito.verify(clearanceEventHandler, Mockito.times(1)).publishEventsForClearances(argumentMap.capture());
		assertEquals(clearanceDataEventMap, argumentMap.getValue());

	}

	/*
	 * This testcase verify the grouping logic. This case grouping will not work
	 * because startDate(eff_Date) be different for the two lines.So 2 sets of
	 * data inserted to the event map.
	 */

	@Test
	public void shouldInvokePublishEventsForRPMClearancesForCreWithDifferentStartDate() throws Exception {
		// first line of data of the clearance file
		String productIdFirstClearance = "072820636";
		String tpncFirstClearance = "275684805";
		String clearance_idFirstClearance = "AC-1224988454";
		String locationFirstClearance = "2425";
		String location_typeFirstClearance = "S";
		String selling_priceFirstClearance = "74";

		// second line of data of the clearance file
		String productIdSecondClearance = "072820636";
		String tpncSecondClearance = "275684805";
		String clearance_idSecondClearance = "AC-1224988455";
		String locationSecondClearance = "5171";
		String location_typeSecondClearance = "S";
		String selling_priceSecondClearance = "75";

		ConstructProductAndTpncMapping(productIdFirstClearance, tpncFirstClearance);
		ConstructProductAndTpncMapping(productIdSecondClearance, tpncSecondClearance);

		ClearanceEventData clearanceDataEventMap = new ClearanceEventData();

		Map<String, String> productInfoMap1 = productInfoMap(productIdFirstClearance, tpncFirstClearance,
				clearance_idFirstClearance, locationFirstClearance, location_typeFirstClearance, eff_date, end_date,
				selling_priceFirstClearance);

		Map<String, String> productInfoMap2 = productInfoMap(productIdSecondClearance, tpncSecondClearance,
				clearance_idSecondClearance, locationSecondClearance, location_typeSecondClearance, eff_date3,
				end_date2, selling_priceSecondClearance);

		when(rpmClearanceCreReader.getNext()).thenReturn(productInfoMap1).thenReturn(productInfoMap2).thenReturn(null);
		this.rpmclearancewriter.write(null);
		ArgumentCaptor<ClearanceEventData> argumentMap = ArgumentCaptor.forClass(ClearanceEventData.class);
		// Expected event data
		Set<String> testSet = new HashSet<>();
		Set<String> testSet2 = new HashSet<>();
		testSet.add("S_2425_AC-1224988454");
		testSet2.add("S_5171_AC-1224988455");

		String effectiveDate1 = Dockyard.getISO8601FormatStartDateForRpmClr(eff_date);
		String effectiveDate2 = Dockyard.getISO8601FormatStartDateForRpmClr(eff_date3);
		clearanceDataEventMap.put("tpnc:275684805_S_" + effectiveDate1 + "_GBP_I", testSet);
		clearanceDataEventMap.put("tpnc:275684805_S_" + effectiveDate2 + "_GBP_I", testSet2);

		Mockito.verify(clearanceEventHandler, Mockito.times(1)).publishEventsForClearances(argumentMap.capture());
		assertEquals(clearanceDataEventMap, argumentMap.getValue());

	}

	/*
	 * This testcase verifying the EventMap write to a file in the failure
	 * location in case of failure. EventMap holding the grouped event data read
	 * from file.Also it verify the correct data write to the file.
	 */
	@Test
	public void shouldWriteClearanceEventMaptoFileInCaseOfFailure() throws Exception {

		// first line of data of the clearance file
		String productIdFirstClearance = "072820636";
		String tpncFirstClearance = "275684805";
		String clearance_idFirstClearance = "AC-1224988454";
		String locationFirstClearance = "2425";
		String location_typeFirstClearance = "S";
		String selling_priceFirstClearance = "74";

		// second line of data of the clearance file
		String productIdSecondClearance = "072820637";
		String tpncSecondClearance = "275684807";
		String clearance_idSecondClearance = "AC-1224988455";
		String locationSecondClearance = null;
		String location_typeSecondClearance = null;
		String selling_priceSecondClearance = null;

		ConstructProductAndTpncMapping(productIdFirstClearance, tpncFirstClearance);
		ConstructProductAndTpncMapping(productIdSecondClearance, tpncSecondClearance);

		Map<String, String> productInfoMap1 = productInfoMap(productIdFirstClearance, tpncFirstClearance,
				clearance_idFirstClearance, locationFirstClearance, location_typeFirstClearance, eff_date, end_date,
				selling_priceFirstClearance);

		Map<String, String> productInfoMap2 = productInfoMap(productIdSecondClearance, tpncSecondClearance,
				clearance_idSecondClearance, locationSecondClearance, location_typeSecondClearance, eff_date3,
				end_date2, selling_priceSecondClearance);

		when(rpmClearanceCreReader.getNext()).thenReturn(productInfoMap1).thenReturn(productInfoMap2).thenReturn(null);
		this.rpmclearancewriter.write(null);

		// Expected failedEventMap Data
		ClearanceEventData expectedClearanceFailedDataEventMap = new ClearanceEventData();
		Set<String> testSet = new HashSet<>();
		testSet.add("S_2425_AC-1224988454");
		String effectiveDate1 = Dockyard.getISO8601FormatStartDateForRpmClr(eff_date);
		expectedClearanceFailedDataEventMap.put("tpnc:275684805_S_" + effectiveDate1 + "_GBP_I", testSet);

		// Actual EventMap Data reding from file.
		rpmClrFailedDatafile = new File(
				testConfiguration.getRpmClrImportFailedFile() + "/RR_RPM_EVENTMAP_" + runIdentifier + ".txt");
		ObjectMapper mapper = new ObjectMapper();
		ClearanceEventData clearanceFailedDataEventMap = mapper.readValue(rpmClrFailedDatafile,
				new TypeReference<ClearanceEventData>() {
				});

		assertTrue(rpmClrFailedDatafile.exists());
		assertEquals(expectedClearanceFailedDataEventMap, clearanceFailedDataEventMap);
		// failedEventMap-file removing from the location
		Files.deleteIfExists(rpmClrFailedDatafile.toPath());

	}

	/*
	 * This testcase verifying the restart of the test after the failure.While
	 * restart the test , Event Map populated with the data from the failure
	 * file(RR_RPM_EVENTMAP_runIdentifier.txt)
	 */
	@Test
	public void shouldRestartTestFromFailureEventMapFile() throws Exception {

		// Writing the first line data to the RR_RPM_EVENTMAP_runIdentifier.txt

		ClearanceEventData ClearanceFailedDataEventMap = new ClearanceEventData();
		Set<String> testSetFailed = new HashSet<>();
		testSetFailed.add("S_2425_AC-1224988454");
		String effectiveDate = Dockyard.getISO8601FormatStartDateForRpmClr(eff_date);
		ClearanceFailedDataEventMap.put("tpnc:275684805_S_" + effectiveDate + "_GBP_I", testSetFailed);
		writeFailedProductDetailsMapToFile(ClearanceFailedDataEventMap);

		// second line of data of the clearance file
		String productIdSecondClearance = "072820637";
		String tpncSecondClearance = "275684807";
		String clearance_idSecondClearance = "AC-1224988455";
		String locationSecondClearance = "5171";
		String location_typeSecondClearance = "S";
		String selling_priceSecondClearance = "75";

		ConstructProductAndTpncMapping(productIdSecondClearance, tpncSecondClearance);
		Map<String, String> productInfoMap2 = productInfoMap(productIdSecondClearance, tpncSecondClearance,
				clearance_idSecondClearance, locationSecondClearance, location_typeSecondClearance, eff_date2,
				end_date2, selling_priceSecondClearance);

		runIdentifier = "acayg";
		rpmclearancewriter.setRunIdentifier(runIdentifier);
		when(bufferedReader.readLine()).thenReturn("072820637_cre").thenReturn(null);
		when(rpmClearanceCreReader.getNext()).thenReturn(productInfoMap2).thenReturn(null);
		this.rpmclearancewriter.write(null);
		ArgumentCaptor<ClearanceEventData> argumentMap = ArgumentCaptor.forClass(ClearanceEventData.class);
		// Expected event data
		Set<String> testSet = new HashSet<>();
		Set<String> testSet2 = new HashSet<>();
		testSet.add("S_2425_AC-1224988454");
		testSet2.add("S_5171_AC-1224988455");
		String effectiveDate2 = Dockyard.getISO8601FormatStartDateForRpmClr(eff_date2);
		ClearanceEventData clearanceDataEventMap = new ClearanceEventData();
		clearanceDataEventMap.put("tpnc:275684805_S_" + effectiveDate + "_GBP_I", testSet);
		clearanceDataEventMap.put("tpnc:275684807_S_" + effectiveDate2 + "_GBP_I", testSet2);

		Mockito.verify(clearanceEventHandler, Mockito.times(1)).publishEventsForClearances(argumentMap.capture());
		assertEquals(clearanceDataEventMap, argumentMap.getValue());

	}
	
	/*
	 * PRIS-1663-Test Cases. This test case creating a product with store
	 * clearance , and generate the event for deleting the clearance.
	 */

	@Test
	public void shouldInvokePublishEventsForRPMStoreClearanceDel() throws Exception {

		// first line of data of the clearance file which is used to create the
		// product
		String productId = "072820636";
		String tpnc = "275684805";
		String clearance_id = "AC-1224988454";
		String location = "2425";
		String location_type = "S";
		String selling_price = "74";

		ClearanceEventData clearanceDataEventMap = new ClearanceEventData();
		// creating the clearance data before delete operations start
		ClearanceProduct clearanceProduct = createClearanceProduct(productId);
		ClearanceByDateTime clearanceBydt = createClearanceByDateTime(eff_date, end_date, clearance_id, selling_price);
		ClearanceStoreSaleInfo clearanceStore = createClearanceStoreSaleInfo(location, "GB", "GBP", clearanceBydt);
		ClearanceProductVariant clearanceProductVariant = createClearanceProductVariant(tpnc, null, clearanceStore);
		clearanceProduct.addClearanceProductVariant(clearanceProductVariant);
		insertClearanceProduct(clearanceProduct);
		Map<String, String> productInfoMapDel = productInfoMap(productId, tpnc, clearance_id, location, location_type);

		when(rpmClearanceCreReader.getNext()).thenReturn(null);
		when(rpmClearanceModReader.getNext()).thenReturn(null);
		// data reading for deleting the product from map productInfoMapDel
		when(rpmClearanceDelReader.getNext()).thenReturn(productInfoMapDel).thenReturn(null);

		this.rpmclearancewriter.write(null);

		ArgumentCaptor<ClearanceEventData> argumentMap = ArgumentCaptor.forClass(ClearanceEventData.class);

		// preparing expected data
		Set<String> testSet = new HashSet<>();
		testSet.add("S_2425_AC-1224988454");
		// Reading system date and passing it it to the key
		DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");
		Calendar cal = Calendar.getInstance();
		String keyDate = dateFormat.format(cal.getTime());
		String keyDateformat = Dockyard.getISO8601FormatStartDateForRpmClr(keyDate);
		clearanceDataEventMap.put("tpnc:275684805_S_" + keyDateformat + "_GBP_D", testSet);

		// verify the expected data with actual data
		Mockito.verify(clearanceEventHandler, Mockito.times(1)).publishEventsForClearances(argumentMap.capture());
		assertEquals(clearanceDataEventMap, argumentMap.getValue());
	}

	/*
	 * Negative testcase checking the condition (TPNB = null) and make sure that
	 * will not try to publish event.
	 */
	@Test
	public void shouldNotInvokePublishEventsForRPMStoreClearanceDel() throws Exception {
		// first line of data of the clearance file
		String productId = "072820636";
		String tpnc = "275684805";
		String clearance_id = "AC-1224988454";
		String location = "2425";
		String location_type = "S";
		String selling_price = "74";

		// creating the clearance before statr the delete operations
		ClearanceProduct clearanceProduct = createClearanceProduct(productId);
		ClearanceByDateTime clearanceBydt = createClearanceByDateTime(eff_date, end_date, clearance_id, selling_price);
		ClearanceStoreSaleInfo clearanceStore = createClearanceStoreSaleInfo(location, "GB", "GBP", clearanceBydt);
		ClearanceProductVariant clearanceProductVariant = createClearanceProductVariant(tpnc, null, clearanceStore);
		clearanceProduct.addClearanceProductVariant(clearanceProductVariant);
		insertClearanceProduct(clearanceProduct);

		Map<String, String> productInfoMap = productInfoMap(null, tpnc, clearance_id, location, location_type);

		when(rpmClearanceCreReader.getNext()).thenReturn(null);
		when(rpmClearanceModReader.getNext()).thenReturn(null);
		when(rpmClearanceDelReader.getNext()).thenReturn(productInfoMap).thenReturn(null);

		this.rpmclearancewriter.write(null);
		// Verify the test reult
		ArgumentCaptor<ClearanceEventData> argumentMap = ArgumentCaptor.forClass(ClearanceEventData.class);

		Mockito.verify(clearanceEventHandler, Mockito.times(0)).publishEventsForClearances(argumentMap.capture());

	}

	/*
	 * This testcase verify the grouping logic of the data.In this case, 2 lines
	 * of data passing which has same productId.This testcase will creating 2
	 * store clearance , and generate the event for deleting the clearance.Due
	 * to grouping logic,1 set of data inserted to the event map which provides
	 * 1 delete event .
	 */
	@Test
	public void shouldInvokePublishEventsForRPMClearancesForDelWithGrouping() throws Exception {

		// first line of data of the clearance file
		String productIdFirstClearance = "072820636";
		String tpncFirstClearance = "275684805";
		String clearance_idFirstClearance = "AC-1224988454";
		String locationFirstClearance = "2425";
		String location_typeFirstClearance = "S";
		String selling_priceFirstClearance = "74";

		// second line of data of the clearance file
		String productIdSecondClearance = "072820637";
		String tpncSecondClearance = "275684805";
		String clearance_idSecondClearance = "AC-1224988455";
		String locationSecondClearance = "5171";
		String location_typeSecondClearance = "S";

		ClearanceEventData clearanceDataEventMap = new ClearanceEventData();
        
		ConstructProductAndTpncMapping(productIdFirstClearance,tpncFirstClearance);
		ConstructProductAndTpncMapping(productIdSecondClearance,tpncSecondClearance);
		
		// creating the clearance data before delete
		ClearanceProduct clearanceProduct1 = createClearanceProduct(productIdFirstClearance);
		ClearanceByDateTime clearanceBydt1 = createClearanceByDateTime(eff_date, end_date, clearance_idFirstClearance,
				selling_priceFirstClearance);
		ClearanceStoreSaleInfo clearanceStore1 = createClearanceStoreSaleInfo(locationFirstClearance, "GB", "GBP",
				clearanceBydt1);
		ClearanceProductVariant clearanceProductVariant1 = createClearanceProductVariant(tpncSecondClearance, null,
				clearanceStore1);
		clearanceProduct1.addClearanceProductVariant(clearanceProductVariant1);
		insertClearanceProduct(clearanceProduct1);
		
		// creating the clearance data before delete
		ClearanceProduct clearanceProduct2 = createClearanceProduct(productIdSecondClearance);
		ClearanceByDateTime clearanceBydt2 = createClearanceByDateTime(eff_date2, end_date2, clearance_idSecondClearance,
				selling_priceFirstClearance);
		ClearanceStoreSaleInfo clearanceStore2 = createClearanceStoreSaleInfo(locationSecondClearance, "GB", "GBP",
				clearanceBydt2);
		ClearanceProductVariant clearanceProductVariant2 = createClearanceProductVariant(tpncSecondClearance, null,
				clearanceStore2);
		clearanceProduct2.addClearanceProductVariant(clearanceProductVariant2);
		insertClearanceProduct(clearanceProduct2);
		
		Map<String, String> productInfoMapDel1 = productInfoMap(productIdFirstClearance, tpncFirstClearance,
				clearance_idFirstClearance, locationFirstClearance, location_typeFirstClearance);
		Map<String, String> productInfoMapDel2 = productInfoMap(productIdSecondClearance, tpncSecondClearance,
				clearance_idSecondClearance, locationSecondClearance, location_typeSecondClearance);
		

		when(rpmClearanceCreReader.getNext()).thenReturn(null);
		when(rpmClearanceModReader.getNext()).thenReturn(null);
		// data reading from map productInfoMapDel1 and productInfoMapDel2 and
		// deleting the product
		when(rpmClearanceDelReader.getNext()).thenReturn(productInfoMapDel1).thenReturn(productInfoMapDel2).thenReturn(null);
		
		this.rpmclearancewriter.write(null);

		ArgumentCaptor<ClearanceEventData> argumentMap = ArgumentCaptor.forClass(ClearanceEventData.class);
		// Expected event data
		Set<String> testSet = new HashSet<>();
		testSet.add("S_2425_AC-1224988454");
		testSet.add("S_5171_AC-1224988455");

		// Reading system date and passing it it to the key
		DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");
		Calendar cal = Calendar.getInstance();
		String keyDateformat = dateFormat.format(cal.getTime());
		String keyDate = Dockyard.getISO8601FormatStartDateForRpmClr(keyDateformat);

		clearanceDataEventMap.put("tpnc:275684805_S_" + keyDate + "_GBP_D", testSet);

		Mockito.verify(clearanceEventHandler, Mockito.times(1)).publishEventsForClearances(argumentMap.capture());
		assertEquals(clearanceDataEventMap, argumentMap.getValue());

	}

	/*
	 * This testcase verify the grouping logic of the data.In this case, 2 lines
	 * of data passing which has different productId(tpnc)(Grouping logic will
	 * not work here).This testcase will creating 2 store clearance , and
	 * generate the event for deleting the clearance.So 2 sets of data inserted
	 * to the event map which provides 2 delete events
	 */

	@Test
	public void shouldInvokePublishEventsForRPMClearancesForDelWithoutGrouping() throws Exception {
		// first line of data of the clearance file
		String productIdFirstClearance = "072820636";
		String tpncFirstClearance = "275684805";
		String clearance_idFirstClearance = "AC-1224988454";
		String locationFirstClearance = "2425";
		String location_typeFirstClearance = "S";
		String selling_priceFirstClearance = "74";

		// second line of data of the clearance file
		String productIdSecondClearance = "072820637";
		String tpncSecondClearance = "275684806";
		String clearance_idSecondClearance = "AC-1224988455";
		String locationSecondClearance = "5171";
		String location_typeSecondClearance = "S";
		String selling_priceSecondClearance = "75";

		ConstructProductAndTpncMapping(productIdFirstClearance, tpncFirstClearance);
		ConstructProductAndTpncMapping(productIdSecondClearance, tpncSecondClearance);

		ClearanceEventData clearanceDataEventMap = new ClearanceEventData();

		// creating the clearance data before delete
		ClearanceProduct clearanceProduct1 = createClearanceProduct(productIdFirstClearance);
		ClearanceByDateTime clearanceBydt1 = createClearanceByDateTime(eff_date, end_date, clearance_idFirstClearance,
				selling_priceFirstClearance);
		ClearanceStoreSaleInfo clearanceStore1 = createClearanceStoreSaleInfo(locationFirstClearance, "GB", "GBP",
				clearanceBydt1);
		ClearanceProductVariant clearanceProductVariant1 = createClearanceProductVariant(tpncFirstClearance, null,
				clearanceStore1);
		clearanceProduct1.addClearanceProductVariant(clearanceProductVariant1);
		insertClearanceProduct(clearanceProduct1);

		// Creating the second clearance record
		ClearanceProduct clearanceProduct2 = createClearanceProduct(productIdSecondClearance);
		ClearanceByDateTime clearanceBydt2 = createClearanceByDateTime(eff_date, end_date, clearance_idSecondClearance,
				selling_priceSecondClearance);
		ClearanceStoreSaleInfo clearanceStore2 = createClearanceStoreSaleInfo(locationSecondClearance, "GB", "GBP",
				clearanceBydt2);
		ClearanceProductVariant clearanceProductVariant2 = createClearanceProductVariant(tpncSecondClearance, null,
				clearanceStore2);
		clearanceProduct2.addClearanceProductVariant(clearanceProductVariant2);

		insertClearanceProduct(clearanceProduct2);

		Map<String, String> productInfoMapDel1 = productInfoMap(productIdFirstClearance, tpncFirstClearance,
				clearance_idFirstClearance, locationFirstClearance, location_typeFirstClearance);
		Map<String, String> productInfoMapDel2 = productInfoMap(productIdSecondClearance, tpncSecondClearance,
				clearance_idSecondClearance, locationSecondClearance, location_typeSecondClearance);

		when(rpmClearanceCreReader.getNext()).thenReturn(null);
		when(rpmClearanceModReader.getNext()).thenReturn(null);
		// data reading from map productInfoMapDel1 and productInfoMapDel2 and
		// deleting the product

		when(rpmClearanceDelReader.getNext()).thenReturn(productInfoMapDel1).thenReturn(productInfoMapDel2)
				.thenReturn(null);
		this.rpmclearancewriter.write(null);

		ArgumentCaptor<ClearanceEventData> argumentMap = ArgumentCaptor.forClass(ClearanceEventData.class);
		// Expected event data
		Set<String> testSet = new HashSet<>();
		Set<String> testSet2 = new HashSet<>();
		testSet.add("S_2425_AC-1224988454");
		testSet2.add("S_5171_AC-1224988455");

		// Reading system date and passing it it to the key
		DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");
		Calendar cal = Calendar.getInstance();
		String keyDateformat = dateFormat.format(cal.getTime());
		String keyDate = Dockyard.getISO8601FormatStartDateForRpmClr(keyDateformat);

		clearanceDataEventMap.put("tpnc:275684805_S_" + keyDate + "_GBP_D", testSet);
		clearanceDataEventMap.put("tpnc:275684806_S_" + keyDate + "_GBP_D", testSet2);

		Mockito.verify(clearanceEventHandler, Mockito.times(1)).publishEventsForClearances(argumentMap.capture());
		assertEquals(clearanceDataEventMap, argumentMap.getValue());

	}
	/*
	 * This testcase verifying the EventMap write to a file in the failure
	 * location in case of failure. EventMap holding the grouped event data read
	 * from file.Also it verify the correct data write to the file.
	 */

	@Test
	public void shouldWriteClearanceEventMaptoFileInCaseOfFailureWithRPMClearancesDel() throws Exception {

		// first line of data of the clearance file
		String productIdFirstClearance = "072820636";
		String tpncFirstClearance = "275684805";
		String clearance_idFirstClearance = "AC-1224988454";
		String locationFirstClearance = "2425";
		String location_typeFirstClearance = "S";
		String selling_priceFirstClearance = "74";

		// second line of data of the clearance file
		String productIdSecondClearance = "072820637";
		String tpncSecondClearance = "275684807";
		String clearance_idSecondClearance = "AC-1224988455";
		String locationSecondClearance = "5171";
		String selling_priceSecondClearance = "75";

		
		// creating the clearance data before delete
		// Creating the first clearance record
		ClearanceProduct clearanceProduct1 = createClearanceProduct(productIdFirstClearance);
		ClearanceByDateTime clearanceBydt1 = createClearanceByDateTime(eff_date, end_date, clearance_idFirstClearance,
				selling_priceFirstClearance);
		ClearanceStoreSaleInfo clearanceStore1 = createClearanceStoreSaleInfo(locationFirstClearance, "GB", "GBP",
				clearanceBydt1);
		ClearanceProductVariant clearanceProductVariant1 = createClearanceProductVariant(tpncFirstClearance, null,
				clearanceStore1);
		clearanceProduct1.addClearanceProductVariant(clearanceProductVariant1);
		insertClearanceProduct(clearanceProduct1);

		// Creating the second clearance record
		ClearanceProduct clearanceProduct2 = createClearanceProduct(productIdSecondClearance);
		ClearanceByDateTime clearanceBydt2 = createClearanceByDateTime(eff_date, end_date, clearance_idSecondClearance,
				selling_priceSecondClearance);
		ClearanceStoreSaleInfo clearanceStore2 = createClearanceStoreSaleInfo(locationSecondClearance, "GB", "GBP",
				clearanceBydt2);
		ClearanceProductVariant clearanceProductVariant2 = createClearanceProductVariant(tpncSecondClearance, null,
				clearanceStore2);
		clearanceProduct2.addClearanceProductVariant(clearanceProductVariant2);
		insertClearanceProduct(clearanceProduct2);

		Map<String, String> productInfoMapDel1 = productInfoMap(productIdFirstClearance, tpncFirstClearance,
				clearance_idFirstClearance, locationFirstClearance, location_typeFirstClearance);
		Map<String, String> productInfoMapDel2 = productInfoMap(productIdSecondClearance, tpncSecondClearance,
				clearance_idSecondClearance, null, null);

		// data reading from map productInfoMapCre1 and productInfoMapCre2 and
		// for creating the product
		when(rpmClearanceCreReader.getNext()).thenReturn(null);
		when(rpmClearanceModReader.getNext()).thenReturn(null);
		// data reading from map productInfoMapDel1 and productInfoMapDel2 and
		// deleting the product
		when(rpmClearanceDelReader.getNext()).thenReturn(productInfoMapDel1).thenReturn(productInfoMapDel2)
				.thenReturn(null);
		this.rpmclearancewriter.write(null);

		// Expected failedEventMap Data
		ClearanceEventData expectedClearanceFailedDataEventMap = new ClearanceEventData();
		Set<String> testSet = new HashSet<>();
		testSet.add("S_2425_AC-1224988454");
		String effectiveDate1 = Dockyard.getISO8601FormatStartDateForRpmClr(eff_date);
		expectedClearanceFailedDataEventMap.put("tpnc:275684805_S_" + effectiveDate1 + "_GBP_D", testSet);

		// Actual EventMap Data reding from file.
		rpmClrFailedDatafile = new File(
				testConfiguration.getRpmClrImportFailedFile() + "/RR_RPM_EVENTMAP_" + runIdentifier + ".txt");
		ObjectMapper mapper = new ObjectMapper();
		ClearanceEventData clearanceFailedDataEventMap = mapper.readValue(rpmClrFailedDatafile,
				new TypeReference<ClearanceEventData>() {
				});

		assertTrue(rpmClrFailedDatafile.exists());
		assertEquals(expectedClearanceFailedDataEventMap, clearanceFailedDataEventMap);
		// failedEventMap-file removing from the location
		Files.deleteIfExists(rpmClrFailedDatafile.toPath());
	}

	/*
	 * This testcase verifying the restart of the test after the failure.While
	 * restart the test , Event Map populated with the data from the failure
	 * file(RR_RPM_EVENTMAP_runIdentifier.txt)
	 */

	@Test
	public void shouldRestartTestFromFailureEventMapFileWithRPMClearancesDel() throws Exception {

		// Writing the first line data to the RR_RPM_EVENTMAP_runIdentifier.txt

		ClearanceEventData ClearanceFailedDataEventMap = new ClearanceEventData();
		Set<String> testSetFailed = new HashSet<>();
		testSetFailed.add("S_2425_AC-1224988454");
		String effectiveDate = Dockyard.getISO8601FormatStartDateForRpmClr(eff_date);
		ClearanceFailedDataEventMap.put("tpnc:275684805_S_" + effectiveDate + "_GBP_D", testSetFailed);
		writeFailedProductDetailsMapToFile(ClearanceFailedDataEventMap);

		// second line of data of the clearance file
		String productIdSecondClearance = "072820637";
		String tpncSecondClearance = "275684807";
		String clearance_idSecondClearance = "AC-1224988455";
		String locationSecondClearance = "5171";
		String location_typeSecondClearance = "S";
		String selling_priceSecondClearance = "75";

		// creating the clearance data before delete
		ClearanceProduct clearanceProduct = createClearanceProduct("072820637");
		ClearanceByDateTime clearanceBydt = createClearanceByDateTime(eff_date, end_date, clearance_idSecondClearance,
				selling_priceSecondClearance);
		ClearanceStoreSaleInfo clearanceStore = createClearanceStoreSaleInfo(locationSecondClearance, "GB", "GBP",
				clearanceBydt);
		ClearanceProductVariant clearanceProductVariant = createClearanceProductVariant(tpncSecondClearance, null,
				clearanceStore);
		clearanceProduct.addClearanceProductVariant(clearanceProductVariant);
		insertClearanceProduct(clearanceProduct);

		Map<String, String> productInfoMapDel2 = productInfoMap(productIdSecondClearance, tpncSecondClearance,
				clearance_idSecondClearance, locationSecondClearance, location_typeSecondClearance);

		runIdentifier = "acayg";
		rpmclearancewriter.setRunIdentifier(runIdentifier);

		when(rpmClearanceCreReader.getNext()).thenReturn(null);
		when(rpmClearanceModReader.getNext()).thenReturn(null);

		when(bufferedReader.readLine()).thenReturn("072820637_del").thenReturn(null);
		when(rpmClearanceDelReader.getNext()).thenReturn(productInfoMapDel2).thenReturn(null);
		this.rpmclearancewriter.write(null);

		ArgumentCaptor<ClearanceEventData> argumentMap = ArgumentCaptor.forClass(ClearanceEventData.class);
		// Expected event data
		Set<String> testSet = new HashSet<>();
		Set<String> testSet2 = new HashSet<>();
		testSet.add("S_2425_AC-1224988454");
		testSet2.add("S_5171_AC-1224988455");

		ClearanceEventData clearanceDataEventMap = new ClearanceEventData();
		clearanceDataEventMap.put("tpnc:275684805_S_" + effectiveDate + "_GBP_D", testSet);
		clearanceDataEventMap.put("tpnc:275684807_S_" + effectiveDate + "_GBP_D", testSet2);

		Mockito.verify(clearanceEventHandler, Mockito.times(1)).publishEventsForClearances(argumentMap.capture());
		assertEquals(clearanceDataEventMap, argumentMap.getValue());

	}

	// This method using to generate FAILURE event map file for some
	// unit test cases.
	public void writeFailedProductDetailsMapToFile(ClearanceEventData clearanceEventMap) throws IOException {
				rpmClrFailedDatafile = new File(
				testConfiguration.getRpmClrImportFailedFile() + "/RR_RPM_EVENTMAP_" + runIdentifier + ".txt");
		ObjectMapper mapper = new ObjectMapper();
		mapper.writeValue(rpmClrFailedDatafile, clearanceEventMap);

	}
	
	/*
	 * PRIS-1639 Test Cases Below testcase checking the event publishing part,
	 * integrate to the RPMClearanceWriter and confirm that proper data event is
	 * sent to publish.
	 */

	@Test
	public void shouldInvokePublishEventsForRPMClearancesForModEndDate() throws Exception {

		// first line of data of the clearance file
		String productIdFirstClearance = "072820636";
		String tpncFirstClearance = "275684805";
		String clearance_idFirstClearance = "AC-1224988454";
		String locationFirstClearance = "2425";
		String location_typeFirstClearance = "S";
		String selling_priceFirstClearance = "74";
		String event_type = "MOD";

		// creating the clearance data before Mod operations start
		ClearanceProduct clearanceProduct = createClearanceProduct(productIdFirstClearance);
		ClearanceByDateTime clearanceBydt = createClearanceByDateTime(eff_date, end_date, clearance_idFirstClearance,
				selling_priceFirstClearance);
		ClearanceStoreSaleInfo clearanceStore = createClearanceStoreSaleInfo(locationFirstClearance, "GB", "GBP",
				clearanceBydt);
		ClearanceProductVariant clearanceProductVariant = createClearanceProductVariant(tpncFirstClearance, null,
				clearanceStore);
		clearanceProduct.addClearanceProductVariant(clearanceProductVariant);
		insertClearanceProduct(clearanceProduct);

		ClearanceEventData clearanceDataEventMap = new ClearanceEventData();

		Map<String, String> dataMap = productInfoMap(productIdFirstClearance, tpncFirstClearance,
				clearance_idFirstClearance, locationFirstClearance, location_typeFirstClearance, eff_date, end_date2,
				selling_priceFirstClearance);
		Map<String, String> productInfoMap = productInfoMap(dataMap, event_type);

		when(rpmClearanceCreReader.getNext()).thenReturn(null);
		when(rpmClearanceModReader.getNext()).thenReturn(productInfoMap).thenReturn(null);
		this.rpmclearancewriter.write(null);

		ArgumentCaptor<ClearanceEventData> argumentMap = ArgumentCaptor.forClass(ClearanceEventData.class);
		Set<String> testSet = new HashSet<>();
		testSet.add("S_2425_AC-1224988454");
		String oldClearanceEndDate = Dockyard.getISO8601FormatEndDateForRPMClr(end_date);
		clearanceDataEventMap.put("tpnc:275684805_S_" + oldClearanceEndDate + "_GBP_U-CLR-END-DATE", testSet);

		Mockito.verify(clearanceEventHandler, Mockito.times(1)).publishEventsForClearances(argumentMap.capture());
		assertEquals(clearanceDataEventMap, argumentMap.getValue());
	}

	/*
	 * This is Negative Testcase. This is checking the condition that if endDate
	 * is expired ,then will not try to publish event.
	 */
	@Test
	public void shouldNotInvokePublishEventsForRPMClearancesForMod() throws Exception {
		// first line of data of the clearance file
		String productIdFirstClearance = "072820636";
		String tpncFirstClearance = "275684805";
		String clearance_idFirstClearance = "AC-1224988454";
		String locationFirstClearance = "2425";
		String location_typeFirstClearance = "S";
		String selling_priceFirstClearance = "74";
		String eff_date = "20-NOV-14";
		String end_date = "28-SEP-15";
		String event_type = "MOD";

		// creating the first clearance data before Mod operations start
		ClearanceProduct clearanceProduct = createClearanceProduct(productIdFirstClearance);
		ClearanceByDateTime clearanceBydt = createClearanceByDateTime(eff_date, end_date, clearance_idFirstClearance,
				selling_priceFirstClearance);
		ClearanceStoreSaleInfo clearanceStore = createClearanceStoreSaleInfo(locationFirstClearance, "GB", "GBP",
				clearanceBydt);
		ClearanceProductVariant clearanceProductVariant = createClearanceProductVariant(tpncFirstClearance, null,
				clearanceStore);
		clearanceProduct.addClearanceProductVariant(clearanceProductVariant);
		insertClearanceProduct(clearanceProduct);

		Map<String, String> dataMap = productInfoMap(productIdFirstClearance, tpncFirstClearance,
				clearance_idFirstClearance, locationFirstClearance, location_typeFirstClearance, eff_date, end_date,
				selling_price);
		Map<String, String> productInfoMap = productInfoMap(dataMap, event_type);

		when(rpmClearanceCreReader.getNext()).thenReturn(null);
		when(rpmClearanceModReader.getNext()).thenReturn(productInfoMap).thenReturn(null);

		this.rpmclearancewriter.write(null);

		ArgumentCaptor<ClearanceEventData> argumentMap = ArgumentCaptor.forClass(ClearanceEventData.class);

		Mockito.verify(clearanceEventHandler, Mockito.times(0)).publishEventsForClearances(argumentMap.capture());

	}

	/*
	 * This testcase verify the grouping logic of the data.In this case, 2 lines
	 * of data passing (which has same productId and same oldClearanceEndDate.
	 * So it provide only one event.
	 */
	@Test
	public void shouldInvokePublishEventsForRPMClearancesForModWithGrouping() throws Exception {
		// first line of data of the clearance file
		String productIdFirstClearance = "072820636";
		String tpncFirstClearance = "275684805";
		String clearance_idFirstClearance = "AC-1224988454";
		String locationFirstClearance = "2425";
		String location_typeFirstClearance = "S";
		String selling_priceFirstClearance = "74";

		// second line of data of the clearance file
		String productIdSecondClearance = "072820637";
		String tpncSecondClearance = "275684805";
		String clearance_idSecondClearance = "AC-1224988455";
		String locationSecondClearance = "5171";
		String location_typeSecondClearance = "S";
		String selling_priceSecondClearance = "75";

		String event_type = "MOD";

		Map<String, Set<String>> clearanceDataEventMap = new HashMap<String, Set<String>>();

		// creating the first clearance data before Mod operations start

		ClearanceProduct clearanceProduct = createClearanceProduct(productIdFirstClearance);
		ClearanceByDateTime clearanceBydt = createClearanceByDateTime(eff_date, end_date, clearance_idFirstClearance,
				selling_priceFirstClearance);
		ClearanceStoreSaleInfo clearanceStore = createClearanceStoreSaleInfo(locationFirstClearance, "GB", "GBP",
				clearanceBydt);
		ClearanceProductVariant clearanceProductVariant = createClearanceProductVariant(tpncFirstClearance, null,
				clearanceStore);
		clearanceProduct.addClearanceProductVariant(clearanceProductVariant);
		insertClearanceProduct(clearanceProduct);

		// creating the second clearance data before Mod operations start

		ClearanceProduct clearanceProduct2 = createClearanceProduct(productIdSecondClearance);
		ClearanceByDateTime clearanceBydt2 = createClearanceByDateTime(eff_date, end_date, clearance_idSecondClearance,
				selling_priceSecondClearance);
		ClearanceStoreSaleInfo clearanceStore2 = createClearanceStoreSaleInfo(locationSecondClearance, "GB", "GBP",
				clearanceBydt2);
		ClearanceProductVariant clearanceProductVariant2 = createClearanceProductVariant(tpncSecondClearance, null,
				clearanceStore2);
		clearanceProduct2.addClearanceProductVariant(clearanceProductVariant2);
		insertClearanceProduct(clearanceProduct2);

		Map<String, String> dataMap1 = productInfoMap(productIdFirstClearance, tpncFirstClearance,
				clearance_idFirstClearance, locationFirstClearance, location_typeFirstClearance, eff_date, end_date2,
				selling_priceFirstClearance);
		Map<String, String> productInfoMap1 = productInfoMap(dataMap1, event_type);

		Map<String, String> dataMap2 = productInfoMap(productIdSecondClearance, tpncSecondClearance,
				clearance_idSecondClearance, locationSecondClearance, location_typeSecondClearance, eff_date, end_date2,
				selling_priceSecondClearance);
		Map<String, String> productInfoMap2 = productInfoMap(dataMap2, event_type);

		when(rpmClearanceCreReader.getNext()).thenReturn(null);
		when(rpmClearanceModReader.getNext()).thenReturn(productInfoMap1).thenReturn(productInfoMap2).thenReturn(null);

		this.rpmclearancewriter.write(null);

		ArgumentCaptor<ClearanceEventData> argumentMap = ArgumentCaptor.forClass(ClearanceEventData.class);
		// Expected event data
		Set<String> testSet = new HashSet<>();
		testSet.add("S_5171_AC-1224988455");
		testSet.add("S_2425_AC-1224988454");
		String oldClearanceEndDate = Dockyard.getISO8601FormatEndDateForRPMClr(end_date);
		clearanceDataEventMap.put("tpnc:275684805_S_" + oldClearanceEndDate + "_GBP_U-CLR-END-DATE", testSet);

		Mockito.verify(clearanceEventHandler, Mockito.times(1)).publishEventsForClearances(argumentMap.capture());
		assertEquals(clearanceDataEventMap, argumentMap.getValue());

	}

	/*
	 * This testcase verify the grouping logic. This case grouping will not work
	 * , because productId(tpnc) be different for the two lines.So 2 sets of
	 * data inserted to the event map.
	 */

	@Test
	public void shouldInvokePublishEventsForRPMClearancesForModWithoutGrouping() throws Exception {
		// first line of data of the clearance file
		String productIdFirstClearance = "072820636";
		String tpncFirstClearance = "275684805";
		String clearance_idFirstClearance = "AC-1224988454";
		String locationFirstClearance = "2425";
		String location_typeFirstClearance = "S";
		String selling_priceFirstClearance = "74";

		// second line of data of the clearance file
		String productIdSecondClearance = "072820637";
		String tpncSecondClearance = "275684806";
		String clearance_idSecondClearance = "AC-1224988455";
		String locationSecondClearance = "5171";
		String location_typeSecondClearance = "S";
		String selling_priceSecondClearance = "75";

		String event_type = "MOD";

		ClearanceEventData clearanceDataEventMap = new ClearanceEventData();

		// creating the first clearance data before Mod operations start

		ClearanceProduct clearanceProduct = createClearanceProduct(productIdFirstClearance);
		ClearanceByDateTime clearanceBydt = createClearanceByDateTime(eff_date, end_date, clearance_idFirstClearance,
				selling_priceFirstClearance);
		ClearanceStoreSaleInfo clearanceStore = createClearanceStoreSaleInfo(locationFirstClearance, "GB", "GBP",
				clearanceBydt);
		ClearanceProductVariant clearanceProductVariant = createClearanceProductVariant(tpncFirstClearance, null,
				clearanceStore);
		clearanceProduct.addClearanceProductVariant(clearanceProductVariant);
		insertClearanceProduct(clearanceProduct);

		// creating the second clearance data before Mod operations start

		ClearanceProduct clearanceProduct2 = createClearanceProduct(productIdSecondClearance);
		ClearanceByDateTime clearanceBydt2 = createClearanceByDateTime(eff_date, end_date, clearance_idSecondClearance,
				selling_priceSecondClearance);
		ClearanceStoreSaleInfo clearanceStore2 = createClearanceStoreSaleInfo(locationSecondClearance, "GB", "GBP",
				clearanceBydt2);
		ClearanceProductVariant clearanceProductVariant2 = createClearanceProductVariant(tpncSecondClearance, null,
				clearanceStore2);
		clearanceProduct2.addClearanceProductVariant(clearanceProductVariant2);
		insertClearanceProduct(clearanceProduct2);

		Map<String, String> dataMap1 = productInfoMap(productIdFirstClearance, tpncFirstClearance,
				clearance_idFirstClearance, locationFirstClearance, location_typeFirstClearance, eff_date, end_date2,
				selling_priceFirstClearance);
		Map<String, String> productInfoMap1 = productInfoMap(dataMap1, event_type);

		Map<String, String> dataMap2 = productInfoMap(productIdSecondClearance, tpncSecondClearance,
				clearance_idSecondClearance, locationSecondClearance, location_typeSecondClearance, eff_date, end_date2,
				selling_priceSecondClearance);
		Map<String, String> productInfoMap2 = productInfoMap(dataMap2, event_type);

		when(rpmClearanceCreReader.getNext()).thenReturn(null);
		when(rpmClearanceModReader.getNext()).thenReturn(productInfoMap1).thenReturn(productInfoMap2).thenReturn(null);
		this.rpmclearancewriter.write(null);
		ArgumentCaptor<ClearanceEventData> argumentMap = ArgumentCaptor.forClass(ClearanceEventData.class);
		// Expected event data
		Set<String> testSet = new HashSet<>();
		Set<String> testSet2 = new HashSet<>();
		testSet.add("S_2425_AC-1224988454");
		testSet2.add("S_5171_AC-1224988455");

		String oldClearanceEndDate = Dockyard.getISO8601FormatEndDateForRPMClr(end_date);
		clearanceDataEventMap.put("tpnc:275684805_S_" + oldClearanceEndDate + "_GBP_U-CLR-END-DATE", testSet);
		clearanceDataEventMap.put("tpnc:275684806_S_" + oldClearanceEndDate + "_GBP_U-CLR-END-DATE", testSet2);

		Mockito.verify(clearanceEventHandler, Mockito.times(1)).publishEventsForClearances(argumentMap.capture());
		assertEquals(clearanceDataEventMap, argumentMap.getValue());

	}

	/*
	 * This testcase verifying the EventMap write to a file in the failure
	 * location in case of failure. EventMap holding the grouped event data read
	 * from file.Also it verify the correct data write to the file.
	 */
	@Test
	public void shouldWriteClearanceEventMaptoFileInCaseOfFailureRpmClrMod() throws Exception {

		// first line of data of the clearance file
		String productIdFirstClearance = "072820636";
		String tpncFirstClearance = "275684805";
		String clearance_idFirstClearance = "AC-1224988454";
		String locationFirstClearance = "2425";
		String location_typeFirstClearance = "S";
		String selling_priceFirstClearance = "74";

		// second line of data of the clearance file
		String productIdSecondClearance = "072820637";
		String tpncSecondClearance = "275684807";
		String clearance_idSecondClearance = "AC-1224988455";
		String locationSecondClearance = "5171";
		String selling_priceSecondClearance = "75";

		String event_type = "MOD";

		// Creating the first clearance record
		ClearanceProduct clearanceProduct1 = createClearanceProduct(productIdFirstClearance);
		ClearanceByDateTime clearanceBydt1 = createClearanceByDateTime(eff_date, end_date, clearance_idFirstClearance,
				selling_priceFirstClearance);
		ClearanceStoreSaleInfo clearanceStore1 = createClearanceStoreSaleInfo(locationFirstClearance, "GB", "GBP",
				clearanceBydt1);
		ClearanceProductVariant clearanceProductVariant1 = createClearanceProductVariant(tpncFirstClearance, null,
				clearanceStore1);
		clearanceProduct1.addClearanceProductVariant(clearanceProductVariant1);
		insertClearanceProduct(clearanceProduct1);

		// Creating the second clearance record
		ClearanceProduct clearanceProduct2 = createClearanceProduct(productIdSecondClearance);
		ClearanceByDateTime clearanceBydt2 = createClearanceByDateTime(eff_date, end_date, clearance_idSecondClearance,
				selling_priceSecondClearance);
		ClearanceStoreSaleInfo clearanceStore2 = createClearanceStoreSaleInfo(locationSecondClearance, "GB", "GBP",
				clearanceBydt2);
		ClearanceProductVariant clearanceProductVariant2 = createClearanceProductVariant(tpncSecondClearance, null,
				clearanceStore2);
		clearanceProduct2.addClearanceProductVariant(clearanceProductVariant2);
		insertClearanceProduct(clearanceProduct2);

		Map<String, String> dataMap1 = productInfoMap(productIdFirstClearance, tpncFirstClearance,
				clearance_idFirstClearance, locationFirstClearance, location_typeFirstClearance, eff_date, end_date2,
				selling_priceFirstClearance);
		Map<String, String> productInfoMap1 = productInfoMap(dataMap1, event_type);

		Map<String, String> dataMap2 = productInfoMap(productIdSecondClearance, tpncSecondClearance,
				clearance_idSecondClearance, null, null, eff_date3, end_date2, selling_priceSecondClearance);
		Map<String, String> productInfoMap2 = productInfoMap(dataMap2, event_type);

		when(rpmClearanceCreReader.getNext()).thenReturn(null);
		when(rpmClearanceModReader.getNext()).thenReturn(productInfoMap1).thenReturn(productInfoMap2).thenReturn(null);

		this.rpmclearancewriter.write(null);

		// Expected failedEventMap Data
		ClearanceEventData expectedClearanceFailedDataEventMap = new ClearanceEventData();
		Set<String> testSet = new HashSet<>();
		testSet.add("S_2425_AC-1224988454");
		String oldClearanceEndDate = Dockyard.getISO8601FormatEndDateForRPMClr(end_date);
		expectedClearanceFailedDataEventMap.put("tpnc:275684805_S_" + oldClearanceEndDate + "_GBP_U-CLR-END-DATE", testSet);

		// Actual EventMap Data reding from file.
		rpmClrFailedDatafile = new File(
				testConfiguration.getRpmClrImportFailedFile() + "/RR_RPM_EVENTMAP_" + runIdentifier + ".txt");
		ObjectMapper mapper = new ObjectMapper();
		ClearanceEventData clearanceFailedDataEventMap = mapper.readValue(rpmClrFailedDatafile,
				new TypeReference<ClearanceEventData>() {
				});

		assertTrue(rpmClrFailedDatafile.exists());
		assertEquals(expectedClearanceFailedDataEventMap, clearanceFailedDataEventMap);
		// failedEventMap-file removing from the location
		Files.deleteIfExists(rpmClrFailedDatafile.toPath());

	}

	/*
	 * This testcase verifying the restart of the test after the failure.While
	 * restart the test , Event Map populated with the data from the failure
	 * file(RR_RPM_EVENTMAP_runIdentifier.txt)
	 */
	@Test
	public void shouldRestartTestFromFailureEventMapFileinCaseofRPMClrMod() throws Exception {

		// Writing the first line data to the RR_RPM_EVENTMAP_runIdentifier.txt

		ClearanceEventData ClearanceFailedDataEventMap = new ClearanceEventData();
		Set<String> testSetFailed = new HashSet<>();
		testSetFailed.add("S_2425_AC-1224988454");
		String oldClearanceEndDate1 = Dockyard.getISO8601FormatEndDateForRPMClr(end_date);
		ClearanceFailedDataEventMap.put("tpnc:275684805_S_" + oldClearanceEndDate1 + "_GBP_U-CLR-END-DATE", testSetFailed);
		writeFailedProductDetailsMapToFile(ClearanceFailedDataEventMap);

		// second line of data of the clearance file
		String productIdSecondClearance = "072820637";
		String tpncSecondClearance = "275684807";
		String clearance_idSecondClearance = "AC-1224988455";
		String locationSecondClearance = "5171";
		String location_typeSecondClearance = "S";
		String selling_priceSecondClearance = "75";

		String event_type = "MOD";

		// creating the clearance data before Mod Operation
		ClearanceProduct clearanceProduct = createClearanceProduct("072820637");
		ClearanceByDateTime clearanceBydt = createClearanceByDateTime(eff_date, end_date, clearance_idSecondClearance,
				selling_priceSecondClearance);
		ClearanceStoreSaleInfo clearanceStore = createClearanceStoreSaleInfo(locationSecondClearance, "GB", "GBP",
				clearanceBydt);
		ClearanceProductVariant clearanceProductVariant = createClearanceProductVariant(tpncSecondClearance, null,
				clearanceStore);
		clearanceProduct.addClearanceProductVariant(clearanceProductVariant);
		insertClearanceProduct(clearanceProduct);

		Map<String, String> dataMap2 = productInfoMap(productIdSecondClearance, tpncSecondClearance,
				clearance_idSecondClearance, locationSecondClearance, location_typeSecondClearance, eff_date, end_date2,
				selling_priceSecondClearance);
		Map<String, String> productInfoMap2 = productInfoMap(dataMap2, event_type);

		runIdentifier = "acayg";
		rpmclearancewriter.setRunIdentifier(runIdentifier);

		when(rpmClearanceCreReader.getNext()).thenReturn(null);
		when(bufferedReader.readLine()).thenReturn("072820637_mod").thenReturn(null);
		when(rpmClearanceModReader.getNext()).thenReturn(productInfoMap2).thenReturn(null);

		this.rpmclearancewriter.write(null);
		ArgumentCaptor<ClearanceEventData> argumentMap = ArgumentCaptor.forClass(ClearanceEventData.class);
		// Expected event data
		Set<String> testSet = new HashSet<>();
		Set<String> testSet2 = new HashSet<>();
		testSet.add("S_2425_AC-1224988454");
		testSet2.add("S_5171_AC-1224988455");
		String oldClearanceEndDate2 = Dockyard.getISO8601FormatEndDateForRPMClr(end_date);
		ClearanceEventData clearanceDataEventMap = new ClearanceEventData();
		clearanceDataEventMap.put("tpnc:275684805_S_" + oldClearanceEndDate1 + "_GBP_U-CLR-END-DATE", testSet);
		clearanceDataEventMap.put("tpnc:275684807_S_" + oldClearanceEndDate2 + "_GBP_U-CLR-END-DATE", testSet2);

		Mockito.verify(clearanceEventHandler, Mockito.times(1)).publishEventsForClearances(argumentMap.capture());
		assertEquals(clearanceDataEventMap, argumentMap.getValue());

	}
	
}
