package com.tesco.services.adapters.rpm.writers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tesco.couchbase.AsyncCouchbaseWrapper;
import com.tesco.couchbase.CouchbaseWrapper;
import com.tesco.couchbase.testutils.AsyncCouchbaseWrapperStub;
import com.tesco.couchbase.testutils.BucketTool;
import com.tesco.couchbase.testutils.CouchbaseTestManager;
import com.tesco.couchbase.testutils.CouchbaseWrapperStub;
import com.tesco.services.Configuration;
import com.tesco.services.adapters.rpm.writers.impl.ProductAvgWeightWriter;
import com.tesco.services.core.ProductAvgWeightInfoEntity;
import com.tesco.services.exceptions.PromoBusinessException;
import com.tesco.services.repositories.RepositoryImpl;
import com.tesco.services.resources.ImportResource;
import com.tesco.services.resources.TestConfiguration;
import com.tesco.services.utility.PriceConstants;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.reflect.Whitebox;

import java.io.*;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Semaphore;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

@RunWith(MockitoJUnitRunner.class)
public class ProductAvgWeightWriterTest {

	@Mock
	public ProductAvgWeightWriter productAvgWeightWriter;

	@Mock
	public RepositoryImpl repositoryImpl;
	@Mock
	public AsyncCouchbaseWrapper asyncCouchbaseWrapper;
	@Mock
	public CouchbaseWrapper couchbaseWrapper;
	@Mock
	private Configuration testConfiguration;
	@Mock
	private ObjectMapper mapper;
	@Mock
	private CouchbaseTestManager couchbaseTestManager;

	@Mock
	FileWriter fileWriter;
	@Mock
	BufferedWriter bufferedWriter;

	String runIdentifier = "sonettouk";

	String testFilename = "Products_20151027.xml";


	File productAvgWeightFileForUK;
	File productAvgWeightFileForROI;

	@Before
	public void setUp() throws FileNotFoundException {
		testConfiguration = TestConfiguration.load();

		if (testConfiguration.isDummyCouchbaseMode()) {
			Map<String, ImmutablePair<Long, String>> fakeBase = new HashMap<>();
			couchbaseTestManager = new CouchbaseTestManager(
					new CouchbaseWrapperStub(fakeBase),
					new AsyncCouchbaseWrapperStub(fakeBase),
					mock(BucketTool.class));
		} else {
			couchbaseTestManager = new CouchbaseTestManager(
					testConfiguration.getCouchbaseBucket(),
					testConfiguration.getCouchbaseUsername(),
					testConfiguration.getCouchbasePassword(),
					testConfiguration.getCouchbaseNodes(),
					testConfiguration.getCouchbaseAdminUsername(),
					testConfiguration.getCouchbaseAdminPassword());
		}

		couchbaseWrapper = couchbaseTestManager.getCouchbaseWrapper();
		asyncCouchbaseWrapper = couchbaseTestManager.getAsyncCouchbaseWrapper();

		repositoryImpl = new RepositoryImpl(couchbaseWrapper,
				asyncCouchbaseWrapper, new ObjectMapper());
		productAvgWeightFileForUK = new File(
				"src/test/resources/com/tesco/services/core/fixtures/Products_20151027.xml");
		productAvgWeightFileForROI = new File(
				"src/test/resources/com/tesco/services/core/fixtures/Products_20151027.xml");
		productAvgWeightWriter = new ProductAvgWeightWriter(testConfiguration,
				repositoryImpl);
		productAvgWeightWriter.setRunIdentifier(runIdentifier);

		ImportResource.getImportSemaphoreForIdentifier().put(testFilename,
				new Semaphore(1));
	}

	@Test
	public void testWritePriceToCBForUK() throws Exception {
		productAvgWeightWriter
				.setProductAvgWeightFile(productAvgWeightFileForUK);
		productAvgWeightWriter.write(testFilename);

		ProductAvgWeightInfoEntity expectedAvgWeightEntity = (ProductAvgWeightInfoEntity) repositoryImpl
				.getGenericObject(
						PriceConstants.SONETTO_UK_DOC_KEY_PREFIX,
						ProductAvgWeightInfoEntity.class);
		assertThat(expectedAvgWeightEntity).isNotNull();

	}

	@Test
	public void testWritePriceToCBForROI() throws Exception {
		runIdentifier = "sonettoroi";
		productAvgWeightWriter.setRunIdentifier(runIdentifier);
		productAvgWeightWriter
				.setProductAvgWeightFile(productAvgWeightFileForROI);
		productAvgWeightWriter.write(testFilename);

		ProductAvgWeightInfoEntity expectedAvgWeightEntity = (ProductAvgWeightInfoEntity) repositoryImpl
				.getGenericObject(PriceConstants.SONETTO_ROI_DOC_KEY_PREFIX,
						ProductAvgWeightInfoEntity.class);
		assertThat(expectedAvgWeightEntity).isNotNull();

	}

	@Test
	public void testCbExceptionforROI() throws Exception {

		repositoryImpl = Mockito.mock(RepositoryImpl.class);

		Mockito.doThrow(new Exception("Exception")).when(repositoryImpl).insertObject(
				Matchers.anyString() , Matchers.anyObject());
		productAvgWeightWriter
				.setProductAvgWeightFile(productAvgWeightFileForROI);
		try {
			Whitebox.<String>invokeMethod(productAvgWeightWriter,
					"writeProductAvgWeight");
			String doc = (String) couchbaseWrapper
					.get(PriceConstants.SONETTO_ROI_DOC_KEY_PREFIX);
			assertThat(doc).isNull();

		} catch (Exception e) {

			assertThat(e.getCause() instanceof PromoBusinessException);
		}
	}

		@Test
		public void testCbExceptionforUK() throws Exception {
			repositoryImpl = Mockito.mock(RepositoryImpl.class);
			Mockito.doThrow(new Exception("Exception")).when(repositoryImpl)
					.insertObject(Matchers.anyString(), Matchers.anyObject());
			productAvgWeightWriter
					.setProductAvgWeightFile(productAvgWeightFileForUK);
			try {
				Whitebox.<String>invokeMethod(productAvgWeightWriter,
						"writeProductAvgWeight");
				String doc = (String) couchbaseWrapper
						.get(PriceConstants.SONETTO_UK_DOC_KEY_PREFIX);
				assertThat(doc).isNull();
			} catch (Exception e) {

				assertThat(e.getCause() instanceof PromoBusinessException);
			}

	}

}
