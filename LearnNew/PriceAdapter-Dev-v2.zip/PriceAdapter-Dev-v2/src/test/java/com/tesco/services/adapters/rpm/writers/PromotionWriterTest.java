package com.tesco.services.adapters.rpm.writers;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.MappingJsonFactory;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tesco.couchbase.AsyncCouchbaseWrapper;
import com.tesco.couchbase.CouchbaseWrapper;
import com.tesco.couchbase.testutils.AsyncCouchbaseWrapperStub;
import com.tesco.couchbase.testutils.BucketTool;
import com.tesco.couchbase.testutils.CouchbaseTestManager;
import com.tesco.couchbase.testutils.CouchbaseWrapperStub;
import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.exceptions.ColumnNotFoundException;
import com.tesco.services.adapters.rpm.writers.impl.PromotionWriter;
import com.tesco.services.core.promotion.PromotionEntity;
import com.tesco.services.core.promotion.PromotionHierarchyEntity;
import com.tesco.services.core.promotion.PromotionMasterEntity;
import com.tesco.services.exceptions.PromoBusinessException;
import com.tesco.services.repositories.RepositoryImpl;
import com.tesco.services.resources.PromotionResource;
import com.tesco.services.resources.TestConfiguration;
import com.tesco.services.utility.PriceConstants;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.reflect.Whitebox;

import java.io.*;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Semaphore;

import static io.dropwizard.testing.FixtureHelpers.fixture;
import static org.fest.assertions.api.Assertions.assertThat;
import static org.fest.assertions.api.Assertions.fail;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;

@RunWith(MockitoJUnitRunner.class)
public class PromotionWriterTest {

	@Mock
	public PromotionWriter promotionWriter;
	@Mock
	private static RepositoryImpl repositoryImpl;

	@Mock
	public AsyncCouchbaseWrapper asyncCouchbaseWrapper;

	@Mock
	public CouchbaseWrapper couchbaseWrapper;
	@Mock
	private Configuration testConfiguration;

	@Mock
	private Configuration mockTestConfiguration;

	private ObjectMapper mapper;

	@Mock
	private CouchbaseTestManager couchbaseTestManager;

	@Mock
	FileWriter fileWriter;
	@Mock
	BufferedWriter bufferedWriter;
	@Mock
	private BufferedReader bufferedReader;

	String runIdentifier = "onetimepromotion";

	String testFilename = "promotion_onetime.dat";

	@Before
	public void setUp() throws IOException, URISyntaxException,
			InterruptedException, ColumnNotFoundException {

		testConfiguration = TestConfiguration.load();

		if (testConfiguration.isDummyCouchbaseMode()) {
			Map<String, ImmutablePair<Long, String>> fakeBase = new HashMap<>();
			couchbaseTestManager = new CouchbaseTestManager(
					new CouchbaseWrapperStub(fakeBase),
					new AsyncCouchbaseWrapperStub(fakeBase),
					mock(BucketTool.class));
		} else {
			couchbaseTestManager = new CouchbaseTestManager(
					testConfiguration.getCouchbaseBucket(),
					testConfiguration.getCouchbaseUsername(),
					testConfiguration.getCouchbasePassword(),
					testConfiguration.getCouchbaseNodes(),
					testConfiguration.getCouchbaseAdminUsername(),
					testConfiguration.getCouchbaseAdminPassword());
		}

		couchbaseWrapper = couchbaseTestManager.getCouchbaseWrapper();
		asyncCouchbaseWrapper = couchbaseTestManager.getAsyncCouchbaseWrapper();

		repositoryImpl = new RepositoryImpl(couchbaseWrapper,
				asyncCouchbaseWrapper, new ObjectMapper());
		bufferedReader = new BufferedReader(
				new FileReader(
						new File(
								"src/test/resources/com/tesco/services/core/fixtures/promotion_onetime.json")));
		mapper = new ObjectMapper();

		promotionWriter = new PromotionWriter(testConfiguration,
				repositoryImpl, mapper);
		promotionWriter.setPromotionFileReader(bufferedReader);
		promotionWriter.setRunIdentifier(runIdentifier);

		PromotionResource.getImportSemaphoreForIdentifier().put(testFilename,
				new Semaphore(1));

	}

	@Test
	public void testWritePromotionToCB() throws Exception {
		promotionWriter.write(testFilename);
		String doc = (String) couchbaseWrapper
				.get(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ "A22222222_PROMOZONE1");
		assertThat(doc).isNotNull();

	}

	@Test
	public void testWritePromotionToCBErrorInJsonString() throws Exception {
		bufferedReader = new BufferedReader(
				new FileReader(
						new File(
								"src/test/resources/com/tesco/services/core/fixtures/promotion_onetime_error.json")));
		promotionWriter = new PromotionWriter(testConfiguration,
				repositoryImpl, mapper);
		promotionWriter.setRunIdentifier(runIdentifier);
		promotionWriter.setPromotionFileReader(bufferedReader);
		promotionWriter.write(testFilename);
		String doc = (String) couchbaseWrapper
				.get(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ "A22222222_PROMOZONE1");
		assertThat(doc).isNull();

	}

	@Test
	public void testWritePromotioynToCBForChangeTypeAsP() throws Exception {
		bufferedReader = new BufferedReader(
				new FileReader(
						new File(
								"src/test/resources/com/tesco/services/core/fixtures/promotion_onetime_per.json")));
		promotionWriter = new PromotionWriter(testConfiguration,
				repositoryImpl, mapper);
		promotionWriter.setRunIdentifier(runIdentifier);
		promotionWriter.setPromotionFileReader(bufferedReader);
		promotionWriter.write(testFilename);
		String doc = (String) couchbaseWrapper
				.get(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ "A22222222_PROMOZONE1");
		assertThat(doc).isNotNull();

	}

	@Test
	public void testValidatePromotionDoc() throws Exception {
		bufferedReader = new BufferedReader(
				new FileReader(
						new File(
								"src/test/resources/com/tesco/services/core/fixtures/promotion_onetime_validation_error.json")));
		promotionWriter = new PromotionWriter(testConfiguration,
				repositoryImpl, mapper);
		promotionWriter.setRunIdentifier(runIdentifier);
		promotionWriter.setPromotionFileReader(bufferedReader);
		String doc = (String) couchbaseWrapper
				.get(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ "A22222222_PROMOZONE1");
		assertThat(doc).isNull();

	}

	@Test
	public void testWritePromotionMasterToCB() throws Exception {

		promotionWriter.write(testFilename);
		String doc = (String) couchbaseWrapper
				.get(PriceConstants.PROMOTION_DOC_KEY_PREFIX + "A22222222");
		assertThat(doc).isNotNull();
	}

	@Test
	public void ValidatePromotionMasterToCB() throws Exception {
		ObjectMapper objectMapper = new ObjectMapper();

		promotionWriter.write(testFilename);
		String doc = (String) couchbaseWrapper
				.get(PriceConstants.PROMOTION_DOC_KEY_PREFIX + "A22222222");
		PromotionMasterEntity jsonMaster = objectMapper.readValue(doc,
				PromotionMasterEntity.class);
		assertThat(jsonMaster.getOfferType().equals("SIMPLE"));
		assertThat(jsonMaster.getEffectiveDate().equals(""));
		assertThat(jsonMaster.getEndDate().equals(""));
		assertThat(jsonMaster.getOfferLocRef().equals(
				"PROMOTION_A22222222_PROMOZONE1"));
		assertThat(jsonMaster.getCreatedDate().equals("createdDate"));
		assertThat(jsonMaster.getCreatedById().equals("ONETIMERPM"));
		assertThat(jsonMaster.getLastUpdateDate().equals("approvedDate"));
		assertThat(jsonMaster.getLastUpdatedById().equals("approvedById"));
	}

	@Test
	public void UpdatePromotionMaster() throws Exception {
		ObjectMapper objectMapper = new ObjectMapper();

		promotionWriter.write(testFilename);
		bufferedReader = new BufferedReader(
				new FileReader(
						new File(
								"src/test/resources/com/tesco/services/core/fixtures/promotion_onetime_update.json")));
		mapper = new ObjectMapper();

		promotionWriter = new PromotionWriter(testConfiguration,
				repositoryImpl, mapper);
		promotionWriter.setRunIdentifier(runIdentifier);
		promotionWriter.setPromotionFileReader(bufferedReader);
		Mockito.doNothing().when(bufferedWriter).write(Matchers.anyString());
		Mockito.doNothing().when(bufferedWriter).flush();
		Mockito.doNothing().when(bufferedWriter).close();

		PromotionResource.getImportSemaphoreForIdentifier().put(testFilename,
				new Semaphore(1));

		String doc = (String) couchbaseWrapper
				.get(PriceConstants.PROMOTION_DOC_KEY_PREFIX + "A22222222");
		PromotionMasterEntity jsonMaster = objectMapper.readValue(doc,
				PromotionMasterEntity.class);
		assertThat(jsonMaster.getOfferType().equals("SIMPLE"));
		assertThat(jsonMaster.getEffectiveDate().equals(""));
		assertThat(jsonMaster.getEndDate().equals(""));
		assertThat(jsonMaster.getOfferLocRef().size() == 2);
		assertThat(jsonMaster.getCreatedDate().equals("createdDate"));
		assertThat(jsonMaster.getCreatedById().equals("ONETIMERPM"));
		assertThat(jsonMaster.getLastUpdateDate().equals("approvedDate"));
		assertThat(jsonMaster.getLastUpdatedById().equals("approvedById"));
	}

	@Test
	public void testWritePromotionToCBErrorNullDoc() throws Exception {
		bufferedReader = new BufferedReader(
				new FileReader(
						new File(
								"src/test/resources/com/tesco/services/core/fixtures/promotion_onetime.json")));
		bufferedReader = null;
		promotionWriter = new PromotionWriter(testConfiguration,
				repositoryImpl, mapper);
		promotionWriter.setRunIdentifier(runIdentifier);
		promotionWriter.write(testFilename);
		bufferedReader = new BufferedReader(
				new FileReader(
						new File(
								"src/test/resources/com/tesco/services/core/fixtures/promotion_onetime.json")));
		promotionWriter = new PromotionWriter(testConfiguration,
				repositoryImpl, mapper);
		promotionWriter.setRunIdentifier(runIdentifier);
		promotionWriter.setPromotionFileReader(bufferedReader);
		try {
			promotionWriter.write(testFilename);
		} catch (Exception e) {
			Assert.assertTrue(e.getCause() instanceof Exception);
		}
	}

	@Test
	public void testWritePromotionFromMsgToCBErrorNullDoc() throws Exception {

		bufferedReader = new BufferedReader(
				new FileReader(
						new File(
								"src/test/resources/com/tesco/services/core/fixtures/promotion_onetime.json")));
		bufferedReader = null;
		promotionWriter = new PromotionWriter(testConfiguration,
				repositoryImpl, mapper);
		promotionWriter.setRunIdentifier(runIdentifier);
		promotionWriter.write(testFilename);
		bufferedReader = new BufferedReader(
				new FileReader(
						new File(
								"src/test/resources/com/tesco/services/core/fixtures/promotion_onetime.json")));
		promotionWriter = new PromotionWriter(testConfiguration,
				repositoryImpl, mapper);
		promotionWriter.setRunIdentifier(runIdentifier);
		promotionWriter.setPromotionFileReader(bufferedReader);
		try {
			promotionWriter.write(testFilename);
		} catch (Exception e) {
			Assert.assertTrue(e.getCause() instanceof Exception);
		}
	}

	@Test
	public void testProcessHierarchyPromotions() throws IOException,
			PromoBusinessException {

		BufferedReader hpBufferedReader = new BufferedReader(
				new FileReader(
						new File(
								"src/test/resources/com/tesco/services/core/fixtures/promotion/HierarchyPromotion_OneTime.json")));
		String source = PriceConstants.ONE_TIME_RPM;
		JsonFactory jsonFactory = new MappingJsonFactory();
		JsonParser jsonParser = jsonFactory.createJsonParser(hpBufferedReader);
		JsonToken startArrayToken = jsonParser.nextToken();

		while (jsonParser.nextToken() != JsonToken.END_ARRAY) {
			JsonNode rootNode = jsonParser.readValueAsTree();
			PromotionEntity promotionEntity = mapper.readValue(
					rootNode.toString(), PromotionEntity.class);
			Map<String, PromotionHierarchyEntity> hierarchyPromos = new HashMap<String, PromotionHierarchyEntity>();

			promotionWriter.processHierarchyPromotions(promotionEntity,
					hierarchyPromos, source);

			promotionWriter.saveHierarchyPromotions(hierarchyPromos);
		}

		String doc = (String) couchbaseWrapper
				.get(PriceConstants.HIERARCHY_PROMO_PREFIX + "A00JE");
		assertThat(doc).isNotNull();

		doc = (String) couchbaseWrapper
				.get(PriceConstants.HIERARCHY_PROMO_PREFIX + "A00J");
		assertThat(doc).isNotNull();

		hpBufferedReader.close();

	}

	@Test
	public void testSaveHierarchyPromotionsError() {

		RepositoryImpl mockRepositoryImpl = Mockito
				.mock(RepositoryImpl.class);

		Map<String, PromotionHierarchyEntity> hierarchyPromos = new HashMap<String, PromotionHierarchyEntity>();

		try {
			Mockito.doThrow(new Exception("Failed insertion"))
					.when(mockRepositoryImpl)
					.insertObject(Matchers.anyString(), Matchers.anyObject());

			PromotionHierarchyEntity proHEntity = mapper
					.readValue(
							"{\"hierarchyId\":\"A00JE\",\"createdDate\":\"2015-06-26T15:14:00+05:30\",\"createdById\":\"ONETIMERPM\",\"lastUpdateDate\":\"2015-06-26T15:14:00+05:30\",\"lastUpdatedById\":\"ONETIMERPM\",\"offers\":{\"OFFER_31742663\":{\"effectiveDate\":\"2015-06-02T00:00:00+05:30\",\"endDate\":\"2015-06-02T23:59:59+05:30\",\"offerLocRef\":[\"Z2\"],\"offerRef\":\"31742663\"}}}",
							PromotionHierarchyEntity.class);
			hierarchyPromos.put("A00JE", proHEntity);
			promotionWriter.saveHierarchyPromotions(hierarchyPromos);

		} catch (Exception e) {
			Assert.assertTrue(true);
		}

	}

	@Test
	public void testWritePromotionToCBHierarchyError() throws Exception {

		BufferedReader hpBufferedReader = new BufferedReader(
				new FileReader(
						new File(
								"src/test/resources/com/tesco/services/core/fixtures/promotion/HierarchyPromotion_OneTime.json")));

		RepositoryImpl mockRepositoryImpl = Mockito
				.mock(RepositoryImpl.class);

		Mockito.doThrow(new Exception("Failed insertion"))
				.when(mockRepositoryImpl)
				.insertObject(Matchers.anyString(), Matchers.anyObject());

		promotionWriter = new PromotionWriter(testConfiguration,
				mockRepositoryImpl, mapper);
		promotionWriter.setRunIdentifier(runIdentifier);
		promotionWriter.setPromotionFileReader(hpBufferedReader);

		Whitebox.<String> invokeMethod(promotionWriter, "writePromotion",
				true);

		hpBufferedReader.close();

	}

	@Test
	public void testWritePromotionToCBConversionCheck() throws Exception {

		BufferedReader hpBufferedReader = new BufferedReader(
				new FileReader(
						new File(
								"src/test/resources/com/tesco/services/core/fixtures/promotion/HierarchyPromotion_OneTime.json")));

		promotionWriter = new PromotionWriter(testConfiguration,
				repositoryImpl, mapper);
		promotionWriter.setRunIdentifier(runIdentifier);
		promotionWriter.setPromotionFileReader(hpBufferedReader);

		Whitebox.<String> invokeMethod(promotionWriter, "writePromotion",
				true);

		String doc = (String) couchbaseWrapper.get("PROMOTION_33222223_Z5");

		JsonFactory jsonFactory = new MappingJsonFactory();
		JsonParser jsonParser = jsonFactory.createJsonParser(new StringReader(
				doc));
		JsonNode rootNode = jsonParser.readValueAsTree();

		JsonNode promoItem = rootNode.path("promoItemLists").get(0)
				.path("promoItems").get(0);

		assertThat(promoItem.path("itemRef").textValue()).isEqualTo("A00J");

		hpBufferedReader.close();

	}

	@Test
	public void testProcessOfferLookupOneTime() throws Exception {
		BufferedReader hpBufferedReader = new BufferedReader(
				new FileReader(
						new File(
								"src/test/resources/com/tesco/services/core/fixtures/promotion/HierarchyPromotion_OneTimeInvalid.json")));

		JsonFactory jsonFactory = new MappingJsonFactory();
		JsonParser jsonParser = jsonFactory.createJsonParser(hpBufferedReader);
		jsonParser.nextToken();

		while (jsonParser.nextToken() != JsonToken.END_ARRAY) {
			JsonNode rootNode = jsonParser.readValueAsTree();
			PromotionEntity promotionEntity = mapper.readValue(
					rootNode.toString(), PromotionEntity.class);

			Whitebox.<String> invokeMethod(promotionWriter,
					"processOfferLookupOneTime", promotionEntity);
		}

		String offerId = (String) repositoryImpl.getGenericObject(
				PriceConstants.PROMO_DETAIL_ID_KEY + "10101", String.class);

		assertThat("31742663").isEqualTo(offerId);

		hpBufferedReader.close();
	}

	@Test
	public void testProcessOfferLookupOneTimeException() throws Exception {

		BufferedReader hpBufferedReader = new BufferedReader(
				new FileReader(
						new File(
								"src/test/resources/com/tesco/services/core/fixtures/promotion/HierarchyPromotion_OneTime.json")));

		RepositoryImpl repositoryImpl = Mockito
				.mock(RepositoryImpl.class);

		Mockito.doThrow(new Exception("Failed insertion"))
				.when(repositoryImpl)
				.insertObject(Matchers.anyString(), Matchers.anyString());
		promotionWriter = new PromotionWriter(testConfiguration,
				repositoryImpl, mapper);
		promotionWriter.setRunIdentifier(runIdentifier);
		promotionWriter.setPromotionFileReader(bufferedReader);
		promotionWriter.write(testFilename);
		JsonFactory jsonFactory = new MappingJsonFactory();
		JsonParser jsonParser = jsonFactory.createJsonParser(hpBufferedReader);
		jsonParser.nextToken();

		while (jsonParser.nextToken() != JsonToken.END_ARRAY) {
			JsonNode rootNode = jsonParser.readValueAsTree();
			PromotionEntity promotionEntity = mapper.readValue(
					rootNode.toString(), PromotionEntity.class);

			boolean status = Whitebox.<Boolean> invokeMethod(promotionWriter,
					"processOfferLookupOneTime", promotionEntity);

			Assert.assertFalse(status);

			break;
		}

		hpBufferedReader.close();

	}

	@Test
	public void testUpdateonetimePromotionDocExceptionInInsertion()
			throws Exception {
		bufferedReader = new BufferedReader(
				new FileReader(
						new File(
								"src/test/resources/com/tesco/services/core/fixtures/promotion_onetime_error.json")));

		RepositoryImpl repositoryImpl = Mockito
				.mock(RepositoryImpl.class);
		doThrow(new Exception("Exception")).when(repositoryImpl)
				.insertObject(anyString(), anyObject());
		promotionWriter = new PromotionWriter(testConfiguration,
				repositoryImpl, mapper);
		promotionWriter.setPromotionFileReader(bufferedReader);
		promotionWriter.setRunIdentifier(runIdentifier);
		promotionWriter.write(testFilename);

		String doc = (String) couchbaseWrapper
				.get(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ "A22222222_PROMOZONE1");
		String masterDoc = (String) couchbaseWrapper
				.get(PriceConstants.PROMOTION_DOC_KEY_PREFIX + "A22222222");
		String lookUpDoc = (String) couchbaseWrapper
				.get(PriceConstants.PROMO_DETAIL_ID_KEY + "1");
		assertThat(doc).isNull();
		assertThat(masterDoc).isNull();
		assertThat(lookUpDoc).isNull();

	}

	@Test
	public void testUpdateJmsPromotionDocExceptionInInsertion()
			throws Exception {

		String entity = fixture("com/tesco/services/core/fixtures/promotion/PROMOTION_31742663_Z13.json");
		PromotionEntity promotionEntity = mapper.readValue(entity,
				PromotionEntity.class);
		RepositoryImpl repositoryImpl = Mockito
				.mock(RepositoryImpl.class);
		doThrow(new Exception("Exception")).when(repositoryImpl)
				.insertObject(anyString(), anyObject());
		promotionWriter = new PromotionWriter(testConfiguration,
				repositoryImpl, mapper);
		try {
			promotionWriter.writePromoEntityFromMessage(promotionEntity);
			fail("suppose to throw exception");
		} catch (Exception e) {

			assertThat(e.getCause() instanceof PromoBusinessException);
		}

	}

	@Test
	public void testUpdateJmsProdOfferDocExceptionInInsertion()
			throws Exception {

		String entity = fixture("com/tesco/services/core/fixtures/promotion/PROMOTION_31067925_Z5.json");
		PromotionEntity promotionEntity = mapper.readValue(entity,
				PromotionEntity.class);
		RepositoryImpl repositoryImpl = Mockito
				.mock(RepositoryImpl.class);
		doThrow(new Exception("Exception")).when(repositoryImpl)
				.insertObject(anyString(), anyObject());
		promotionWriter = new PromotionWriter(testConfiguration,
				repositoryImpl, mapper);
		int[] thresholdRefs = { 0 };
		try {
			Whitebox.<String> invokeMethod(promotionWriter,
					"createAndInsertProdOfferDoc", promotionEntity,
					promotionEntity.getPromoItemListEntities().get(0)
							.getPromoItems().get(0), thresholdRefs);
			fail("suppose to throw exception");
		} catch (Exception e) {

			assertThat(e.getCause() instanceof PromoBusinessException);
		}

	}

	@Test
	public void testWritePromotionToCBWhenChangeUomIsZero() throws Exception {
		bufferedReader = new BufferedReader(
				new FileReader(
						new File(
								"src/test/resources/com/tesco/services/core/fixtures/promotion_onetime_uom.json")));
		promotionWriter = new PromotionWriter(testConfiguration,
				repositoryImpl, mapper);
		promotionWriter.setRunIdentifier(runIdentifier);
		promotionWriter.setPromotionFileReader(bufferedReader);
		promotionWriter.write(testFilename);
		String doc = (String) couchbaseWrapper
				.get(PriceConstants.PROMOTION_DOC_KEY_PREFIX
						+ "A33333333_PROMOZONE1");
		assertThat(doc).isNotNull();

	}

}