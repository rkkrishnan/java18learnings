package com.tesco.services.adapters.rpm.writers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Optional;
import com.tesco.couchbase.AsyncCouchbaseWrapper;
import com.tesco.couchbase.CouchbaseWrapper;
import com.tesco.couchbase.testutils.AsyncCouchbaseWrapperStub;
import com.tesco.couchbase.testutils.BucketTool;
import com.tesco.couchbase.testutils.CouchbaseTestManager;
import com.tesco.couchbase.testutils.CouchbaseWrapperStub;
import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.ImportEanJob;
import com.tesco.services.adapters.core.PriceComparatorJob;
import com.tesco.services.adapters.rpm.writers.impl.TeauthFileProcessor;
import com.tesco.services.core.*;
import com.tesco.services.repositories.RepositoryImpl;
import com.tesco.services.resources.HTTPResponses;
import com.tesco.services.resources.TeauthPriceChecksResource;
import com.tesco.services.resources.TestConfiguration;
import com.tesco.services.utility.*;
import io.dropwizard.servlets.assets.ResourceNotFoundException;
import junit.framework.Assert;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import javax.servlet.ServletException;
import javax.ws.rs.core.Response;
import java.io.BufferedReader;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.net.URISyntaxException;
import java.util.*;
import java.util.concurrent.Semaphore;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class TeauthFileProcessorTest {
    @Mock
    public TeauthFileProcessor teauthFileProcessor;
    @Mock
    public RepositoryImpl repositoryImpl;

    @Mock
    public AsyncCouchbaseWrapper asyncCouchbaseWrapper;

    @Mock
    public CouchbaseWrapper couchbaseWrapper;

    @Mock
    protected Configuration testConfiguration;

    @Mock
    private ObjectMapper mapper;

    @Mock
    private CouchbaseTestManager couchbaseTestManager;

    @Mock
    private WebServiceCallBuilder webServiceCallBuilder;

    @Mock
    protected BufferedReader teauthReader;

	@Mock
	private Response response;


    String fileName =  "KLL KLAUTH B3121";
    private String storeId;
    private List<Object> expectedDataList;
    private List<Object> expectedErrorList;


    @Mock
    private Set<String> tpncKeys;

    private  Map<String,Map<String,String>> eanToTpncMap;
    Set<String> expectedPriceCheckFileDetails = new LinkedHashSet<>();
    boolean onExceptionCheck = false;
    Exception exception;
    @Before
    public void setUp() throws IOException, URISyntaxException, InterruptedException {

        testConfiguration = TestConfiguration.load();
        if (testConfiguration.isDummyCouchbaseMode()){
            Map<String, ImmutablePair<Long, String>> fakeBase = new HashMap<>();
            couchbaseTestManager = new CouchbaseTestManager(new CouchbaseWrapperStub(fakeBase),
                    new AsyncCouchbaseWrapperStub(fakeBase),
                    mock(BucketTool.class));
        } else {
            couchbaseTestManager = new CouchbaseTestManager(testConfiguration.getCouchbaseBucket(),
                    testConfiguration.getCouchbaseUsername(),
                    testConfiguration.getCouchbasePassword(),
                    testConfiguration.getCouchbaseNodes(),
                    testConfiguration.getCouchbaseAdminUsername(),
                    testConfiguration.getCouchbaseAdminPassword());
        }

        couchbaseWrapper = couchbaseTestManager.getCouchbaseWrapper();
        asyncCouchbaseWrapper = couchbaseTestManager.getAsyncCouchbaseWrapper();

        mapper = new ObjectMapper();
        repositoryImpl = new RepositoryImpl(couchbaseWrapper,asyncCouchbaseWrapper, mapper);
        teauthFileProcessor = new TeauthFileProcessor(testConfiguration,couchbaseWrapper,asyncCouchbaseWrapper,webServiceCallBuilder,teauthReader);
        teauthFileProcessor.setFileName(fileName);
        when(teauthReader.readLine()).thenReturn(null);

    }

    private void buildEanMappingAndProducts(Map<String,String>eans,String dynamicTpnc,String dynamicTpnb,boolean errorListExist,boolean isBadResponse,boolean persistEanMapping) throws Exception {

        int dynamicCount = 1;
        if(persistEanMapping) {
            expectedPriceCheckFileDetails.add("TEAUTH validation started - store " + storeId);
        }
        ResponseBuilderForTests responseBuilder = new ResponseBuilderForTests(
				repositoryImpl);
        expectedDataList = new ArrayList<>();
		expectedErrorList = new ArrayList<>();
        tpncKeys = new LinkedHashSet<>();
        eanToTpncMap = new LinkedHashMap<>();
        for(String ean:eans.keySet()) {
            dynamicTpnc = getDynamicItem(dynamicTpnc, dynamicCount);
            tpncKeys.add(dynamicTpnc);
            if(persistEanMapping) {
                Ean eanDoc = new Ean(dynamicTpnc);
                eanDoc.setLastUpdatedDate(Dockyard.getSysDate("yyyyMMdd"));
                repositoryImpl.insertObject(
						PriceConstants.EAN_KEY_PREFIX + ean.split("_")[1],
						eanDoc);
            }
            if (!errorListExist) {
                dynamicTpnb = getDynamicItem(dynamicTpnb, dynamicCount);
                List<String> tpncList = new LinkedList<>();
                tpncList.add(dynamicTpnc);
                Map<Integer, String> priceZone = new LinkedHashMap<>();
                priceZone.put(3, "2.2");
                Map<Integer, String> promoZone = new LinkedHashMap<>();
                promoZone.put(8, "1.2");
                Map<Integer, String> clearanceZone = new LinkedHashMap<>();
                clearanceZone.put(20, "1.2");
                Store store = new Store(storeId, Optional.of(3), Optional.of(8),Optional.of(20), "GBP","GB");

                repositoryImpl.insertObject(
						PriceConstants.STORE_KEY + store.getStoreId(),
						store);
                Map<String, ProductVariant> variants = responseBuilder.createProductVariants(tpncList, "EA", priceZone, promoZone);
                Product product = responseBuilder.createProductWithVaraintsAndPromotions(dynamicTpnb, variants, null);
                ClearanceProduct clearanceProduct = responseBuilder.createRpmClearanceWithVaraints(dynamicTpnb, tpncList, "1.1", "0.9", "GBP", store);
                ClearanceMMProduct clearanceMMProduct = responseBuilder.createMMClearance(dynamicTpnb, "1.0", "0.8", "GBP", store);
                Map<String, Object> expectedProductPriceMap = responseBuilder.getExpectedProductPriceMap(product, clearanceProduct, clearanceMMProduct, store);
                expectedDataList.add(expectedProductPriceMap);
                if(!isBadResponse) {
                    expectedPriceCheckFileDetails.add("TEAUTH Price error - store : " + storeId + " || item ean : " + ean.split("_")[1] + " || tpnc : " + dynamicTpnc + " || TEAUTH price : " + eans.get(ean).trim() + " || Price service price : " + "0.80");
                }
            } else {
                if(onExceptionCheck){
                    expectedPriceCheckFileDetails.add("TEAUTH File Check failed for Ean  " + ean.split("_")[1] + " || Error Message : " + exception.toString());
                }else{
                    String errorMsg = "Product not found";
                    expectedErrorList.add(responseBuilder.getExpectedErrorMap(dynamicTpnc, 404, errorMsg));
					expectedPriceCheckFileDetails.add("TEAUTH Item not in price service - store : " + storeId + " || item ean : " + ean.split("_")[1] + " || Message from PS : " + errorMsg);
                }


            }
        }
        if(isBadResponse){
            String errorMsg = String.format("{\"error\":\"%s\"}", HTTPResponses.INTERNAL_SERVER_ERROR);

			expectedPriceCheckFileDetails.add("Get Price for List Failed - store : "+storeId+" || Tpncs : "+tpncKeys+" || Message from PS : "+errorMsg);

        }


		expectedPriceCheckFileDetails.add("TEAUTH validation ended - store "+storeId);

    }
    private void processMissedEansInPriceServices(Map<String,String> eansNotFoundMap){
        Set<String> eanKeys = eansNotFoundMap.keySet();
		expectedPriceCheckFileDetails.add("TEAUTH validation started - store "+storeId);
        for(String ean:eanKeys){
			expectedPriceCheckFileDetails.add("EAN : " + ean.split("_")[1] + " mapping not found");
        }
		expectedPriceCheckFileDetails.add("TEAUTH validation ended - store "+storeId);

    }
    private String getDynamicItem(String item,int count){
        int newItem = (Integer.parseInt(item) + count);
        item = Integer.toString(newItem);

        return item;
    }

    @Test
    public void getStoreIdFromFileName(){
        String fileName = "KLL KLAUTH B3121";
        String storeId = fileName.substring(fileName.length()-4);
        assertThat("3121").isEqualTo(storeId);
    }

    @Test
    public void writePriceDifferenceToACollection() throws Exception{
        fileName = "KLL KLAUTH B3121";
        storeId = fileName.substring(fileName.length() - 4);
        String line = "205034934293011    0.75    0.75   0.7505034934293028    0.75    0.75   0.750";
        String footer = "90001";
        String tpnc="234567891";
        String tpnb="056789988";
        Map<String,String> eanMap = new LinkedHashMap<>();
        eanMap.put(PriceConstants.EAN_KEY_PREFIX + "5034934293011", "0.75");
        eanMap.put(PriceConstants.EAN_KEY_PREFIX + "5034934293028", "0.75");
        buildEanMappingAndProducts(eanMap,tpnc,tpnb,false,false,true);
        TeauthPriceChecksResource.SEMAPHORE_MAP.put(fileName, new Semaphore(1));
        teauthFileProcessor = new TeauthFileProcessor(testConfiguration,couchbaseWrapper,asyncCouchbaseWrapper,webServiceCallBuilder,teauthReader);
        teauthFileProcessor.setFileName(fileName);
        teauthFileProcessor.setWebServiceCallBuilder(webServiceCallBuilder);
        when(teauthReader.readLine()).thenReturn(line).thenReturn(footer).thenReturn(null);

        Map<String,Object> responseMap = new LinkedHashMap<>();
        responseMap.put(PriceConstants.GET_PRICE_LIST_DATA,expectedDataList);
        responseMap.put(PriceConstants.GET_PRICE_LIST_ERRORS,expectedErrorList);

        Response clientResponseMock = mock(Response.class);

        when(webServiceCallBuilder.getResponseFromRemoteServerForProductsListWithStore(Matchers.any(Set.class),
                Matchers.any(String.class))).thenReturn(clientResponseMock);
        when(clientResponseMock.getStatus()).thenReturn(200);
        when(clientResponseMock.readEntity(Map.class)).thenReturn(responseMap);

        this.teauthFileProcessor.readAndProcessFile();
        assertThat(teauthFileProcessor.getPriceCheckFileDetails()).isEqualTo(expectedPriceCheckFileDetails);

    }

    @Test
    public void writePriceErroredDetailsFromRemoteServerToACollection() throws Exception{
        fileName = "KLL KLAUTH B3121";
        storeId = fileName.substring(fileName.length() - 4);
        String line = "205034934293011    0.75    0.75   0.7505034934293028    0.75    0.75   0.750";

        String footer = "90001";
        String tpnc="234567891";
        String tpnb="056789988";
        Map<String,String> eanMap = new LinkedHashMap<>();
        eanMap.put(PriceConstants.EAN_KEY_PREFIX + "5034934293011", "0.75");
        eanMap.put(PriceConstants.EAN_KEY_PREFIX + "5034934293028","0.75");
        buildEanMappingAndProducts(eanMap,tpnc,tpnb,true,false,true);
        TeauthPriceChecksResource.SEMAPHORE_MAP.put(fileName, new Semaphore(1));
        teauthFileProcessor = new TeauthFileProcessor(testConfiguration,couchbaseWrapper,asyncCouchbaseWrapper,webServiceCallBuilder,teauthReader);
        teauthFileProcessor.setFileName(fileName);
        teauthFileProcessor.setWebServiceCallBuilder(webServiceCallBuilder);
        when(teauthReader.readLine()).thenReturn(line).thenReturn(footer).thenReturn(null);

        Map<String,Object> responseMap = new LinkedHashMap<>();
        responseMap.put(PriceConstants.GET_PRICE_LIST_DATA,expectedDataList);
        responseMap.put(PriceConstants.GET_PRICE_LIST_ERRORS,expectedErrorList);

        Response clientResponseMock = mock(Response.class);

        when(webServiceCallBuilder.getResponseFromRemoteServerForProductsListWithStore(Matchers.any(Set.class),
                Matchers.any(String.class))).thenReturn(clientResponseMock);
        when(clientResponseMock.getStatus()).thenReturn(200);
        when(clientResponseMock.readEntity(Map.class)).thenReturn(responseMap);

        this.teauthFileProcessor.readAndProcessFile();
        assertThat(teauthFileProcessor.getPriceCheckFileDetails()).isEqualTo(expectedPriceCheckFileDetails);

    }

    @Test
    public void shouldWriteTheErrorResponse500ToCollection() throws Exception{
        fileName = "KLL KLAUTH B3121";
        storeId = fileName.substring(fileName.length() - 4);
        String line = "205034934293011    0.75    0.75   0.7505034934293028    0.75    0.75   0.750";
        String footer = "90001";
        String tpnc="234567891";
        String tpnb="056789988";
        Map<String,String> eanMap = new LinkedHashMap<>();
        eanMap.put(PriceConstants.EAN_KEY_PREFIX + "5034934293011", "0.75");
        eanMap.put(PriceConstants.EAN_KEY_PREFIX + "5034934293028", "0.75");
        buildEanMappingAndProducts(eanMap,tpnc,tpnb,false,true,true);
        TeauthPriceChecksResource.SEMAPHORE_MAP.put(fileName, new Semaphore(1));
        teauthFileProcessor = new TeauthFileProcessor(testConfiguration,couchbaseWrapper,asyncCouchbaseWrapper,webServiceCallBuilder,teauthReader);
        teauthFileProcessor.setFileName(fileName);
        teauthFileProcessor.setWebServiceCallBuilder(webServiceCallBuilder);
        when(teauthReader.readLine()).thenReturn(line).thenReturn(footer).thenReturn(null);

        Response response = HTTPResponses.serverError();
        Response clientResponseMock = mock(Response.class);

        when(webServiceCallBuilder.getResponseFromRemoteServerForProductsListWithStore(Matchers.any(Set.class),
                Matchers.any(String.class))).thenReturn(clientResponseMock);
        when(clientResponseMock.getStatus()).thenReturn(response.getStatus());
        String errorMsg = String.format("{\"error\":\"%s\"}", HTTPResponses.INTERNAL_SERVER_ERROR);
        when( clientResponseMock.readEntity(String.class)).thenReturn(errorMsg);


        this.teauthFileProcessor.readAndProcessFile();
        assertThat(teauthFileProcessor.getPriceCheckFileDetails()).isEqualTo(expectedPriceCheckFileDetails);


    }
    @Test
    public void docyardObjTest(){
        teauthFileProcessor = new TeauthFileProcessor(testConfiguration,couchbaseWrapper,asyncCouchbaseWrapper,webServiceCallBuilder,teauthReader);
        teauthFileProcessor.setFileName(fileName);
        Assert.assertNotNull(teauthFileProcessor.getDockyard());

    }
    @Test
    public void clearProductsSetTest(){
        teauthFileProcessor = new TeauthFileProcessor(testConfiguration,couchbaseWrapper,asyncCouchbaseWrapper,webServiceCallBuilder,teauthReader);
        teauthFileProcessor.setFileName(fileName);
        Set<String> productDetails = teauthFileProcessor.getPriceCheckFileDetails();
        productDetails.add("xyz");
        productDetails.add("abc");
        teauthFileProcessor.setPriceCheckFileDetails(productDetails);
        assertThat(teauthFileProcessor.getPriceCheckFileDetails()).isEqualTo(productDetails);
        teauthFileProcessor.clearpriceCheckFileDetails();
        assertThat(teauthFileProcessor.getPriceCheckFileDetails()).isEqualTo(new LinkedHashSet<String>());
    }

    @Test
    public void testFailedProductBlock() throws Exception{
        fileName = "KLL KLAUTH B3121";
        storeId = fileName.substring(fileName.length() - 4);
        String line = "205034934293011    0.75    0.75   0.7505034934293028    0.75    0.75   0.750";
        String footer = "90001";
        String failedEan = "5034934293022";
        TeauthPriceChecksResource.SEMAPHORE_MAP.put(fileName, new Semaphore(1));
        teauthFileProcessor = new TeauthFileProcessor(testConfiguration,couchbaseWrapper,asyncCouchbaseWrapper,webServiceCallBuilder,teauthReader);
        teauthFileProcessor.setFileName(fileName);
        teauthFileProcessor.setWebServiceCallBuilder(webServiceCallBuilder);
        when(teauthReader.readLine()).thenReturn(line).thenReturn(footer).thenReturn(null);

        FileOperations fileOperationsMock = mock(FileOperations.class);
        teauthFileProcessor.setFileOperations(fileOperationsMock);
        when(fileOperationsMock.getfailedProductInProviousRunIfExist(Matchers.any(Configuration.class), Matchers.any(String.class))).thenReturn(failedEan);

        Response response = HTTPResponses.serverError();
        Response clientResponseMock = mock(Response.class);

        when(webServiceCallBuilder.getResponseFromRemoteServerForProductsListWithStore(Matchers.any(Set.class),
                Matchers.any(String.class))).thenReturn(clientResponseMock);
        when(clientResponseMock.getStatus()).thenReturn(response.getStatus());
        this.teauthFileProcessor.readAndProcessFile();

		expectedPriceCheckFileDetails.add("TEAUTH validation started - store "+storeId);
		expectedPriceCheckFileDetails.add("TEAUTH validation ended - store "+storeId);
        assertThat(teauthFileProcessor.getPriceCheckFileDetails()).isEqualTo(expectedPriceCheckFileDetails);


    }

    @Test
    public void shouldWriteTheEanDetailsToToCollectionOnException() throws Exception{
        fileName = "KLL KLAUTH B3121";
        storeId = fileName.substring(fileName.length() - 4);
        String line = "205034934293011    0.75    0.75   0.7505034934293028    0.75    0.75   0.750";
        String footer = "90001";
        String tpnc="234567891";
        String tpnb="056789988";
        Map<String,String> eanMap = new LinkedHashMap<>();
        eanMap.put(PriceConstants.EAN_KEY_PREFIX + "5034934293011", "0.75");
        eanMap.put(PriceConstants.EAN_KEY_PREFIX + "5034934293028", "0.75");
        onExceptionCheck = true;
        exception = new ArrayIndexOutOfBoundsException();
        buildEanMappingAndProducts(eanMap,tpnc,tpnb,true,false,true);
        TeauthPriceChecksResource.SEMAPHORE_MAP.put(fileName, new Semaphore(1));
        teauthFileProcessor = new TeauthFileProcessor(testConfiguration,couchbaseWrapper,asyncCouchbaseWrapper,webServiceCallBuilder,teauthReader);
        teauthFileProcessor.setFileName(fileName);
        teauthFileProcessor.setWebServiceCallBuilder(webServiceCallBuilder);
        when(teauthReader.readLine()).thenReturn(line).thenReturn(footer).thenReturn(null);

        when(webServiceCallBuilder.getResponseFromRemoteServerForProductsListWithStore(Matchers.any(Set.class),
                Matchers.any(String.class))).thenThrow(new ArrayIndexOutOfBoundsException());

        this.teauthFileProcessor.readAndProcessFile();
        assertThat(teauthFileProcessor.getPriceCheckFileDetails()).isEqualTo(expectedPriceCheckFileDetails);


    }
    @Test
    public void testCatchBlockInreadTeauthFileAndComparePricesMethodOnException() throws Exception{
        fileName = "KLL KLAUTH B3121";
        storeId = fileName.substring(fileName.length() - 4);
        String failedEan = "5034934293022";
        TeauthPriceChecksResource.SEMAPHORE_MAP.put(fileName, new Semaphore(1));
        teauthFileProcessor = new TeauthFileProcessor(testConfiguration,couchbaseWrapper,asyncCouchbaseWrapper,webServiceCallBuilder,teauthReader);
        teauthFileProcessor.setFileName(fileName);
        teauthFileProcessor.setWebServiceCallBuilder(webServiceCallBuilder);
        when(teauthReader.readLine()).thenThrow(new StringIndexOutOfBoundsException());

        FileOperations fileOperationsMock = mock(FileOperations.class);
        teauthFileProcessor.setFileOperations(fileOperationsMock);
        when(fileOperationsMock.getfailedProductInProviousRunIfExist(Matchers.any(Configuration.class), Matchers.any(String.class))).thenReturn(failedEan);

        this.teauthFileProcessor.readAndProcessFile();
        expectedPriceCheckFileDetails.add("TEAUTH validation started - store "+storeId);
		expectedPriceCheckFileDetails.add("TEAUTH validation ended - store "+storeId);
        assertThat(teauthFileProcessor.getPriceCheckFileDetails()).isEqualTo(expectedPriceCheckFileDetails);

    }

    @Test
    public void testPriceComparatorJob() throws Exception {
        fileName = "fileName";
        PriceComparatorJob priceComparatorJob = new PriceComparatorJob(mock(TeauthFileProcessor.class));
        priceComparatorJob.setFileName(fileName);
		ImportEanJob importEanJob = new ImportEanJob(testConfiguration,mock(Writer.class));
        TeauthPriceChecksResource teauthPriceChecksResource = new TeauthPriceChecksResource(testConfiguration,importEanJob,priceComparatorJob);
        teauthPriceChecksResource.SEMAPHORE_MAP.put(fileName, new Semaphore(0));
        priceComparatorJob.run();
        assertThat(TeauthPriceChecksResource.getErrorString(fileName)).isEqualTo(null);

    }
    @Test
    public void shouldReturnStoreIdFromFileName(){

        String fileName = "KLL.KLTEAUTH.B2598_20150402124412.txt";
        String storeId = fileName.split("_")[0];
        storeId = storeId.substring(storeId.length() - 4);
        assertThat("2598").isEqualTo(storeId);

    }
    @Test
    public void shouildReturnStoreIdFromCompleteFilePath(){
        String filePath = "src/main/resources/com/tesco/services/adapters/teauth/uk/KLL.KLTEAUTH.B2598_20150402124412.txt";
        String fileName = filePath.substring(filePath.lastIndexOf('/') + 1);
        String storeId = fileName.split("_")[0];
        storeId =   storeId.substring(storeId.length() - 4);
        assertThat("2598").isEqualTo(storeId);

    }

    @Test
    public void test404ErrorBlocksAfterProdServiceCalls(){
        Response clientResponseMock = mock(Response.class);
        when(webServiceCallBuilder.getResponseFromProdServices(Matchers.any(String.class))).thenReturn(clientResponseMock);
        when(clientResponseMock.getStatus()).thenReturn(404);
        when(clientResponseMock.readEntity(String.class)).thenReturn("error: server not found");

        Map<String,String> eanMapFromPriceServices = new LinkedHashMap<>();
        List<String> eanList = new ArrayList<>();
        String url1="";
        String url2="";
        for(int i=1;i<23;i++){
            eanMapFromPriceServices.put("EAN_" + i,"test");
            eanList.add(""+i);
            if(eanList.size()==PriceConstants.PRODUCT_SERVICE_CALL_LIMIT){
                url1= teauthFileProcessor.createProductServiceUrl(eanList);
                eanList.clear();
            }
        }if(!eanList.isEmpty()){
            url2= teauthFileProcessor.createProductServiceUrl(eanList);
        }
        ResourceNotFoundException resourceNotFoundException1= new ResourceNotFoundException(new Exception("The URL trying to reach could not be found on the server. URL : "+url1));
        ResourceNotFoundException resourceNotFoundException2= new ResourceNotFoundException(new Exception("The URL trying to reach could not be found on the server. URL : "+url2));

        List<String> dummyEanList = new ArrayList<>();
        dummyEanList.add("1234");
        teauthFileProcessor.setWebServiceCallBuilder(webServiceCallBuilder);
        this.teauthFileProcessor.processMissedEansInPriceServices(eanMapFromPriceServices);
		expectedPriceCheckFileDetails.add("TEAUTH EAN Seeding Failed :: Error Msg : "+resourceNotFoundException1.toString());
		expectedPriceCheckFileDetails.add("TEAUTH EAN Seeding Failed :: Error Msg : "+resourceNotFoundException2.toString());

        assertThat(teauthFileProcessor.getPriceCheckFileDetails()).isEqualTo(expectedPriceCheckFileDetails);

    }

    @Test
    public void test500ErrorBlocksAfterProdServiceCalls(){
        Response clientResponseMock = mock(Response.class);
        when(webServiceCallBuilder.getResponseFromProdServices(Matchers.any(String.class))).thenReturn(clientResponseMock);
        when(clientResponseMock.getStatus()).thenReturn(500);
        when(clientResponseMock.readEntity(String.class)).thenReturn("error: server not found");

        Map<String,String> eanMapFromPriceServices = new LinkedHashMap<>();
        List<String> eanList = new ArrayList<>();
        String url1="";
        String url2="";
        for(int i=1;i<23;i++){
            eanMapFromPriceServices.put("EAN_" + i,"test");
            eanList.add(""+i);
            if(eanList.size()==PriceConstants.PRODUCT_SERVICE_CALL_LIMIT){
                url1= teauthFileProcessor.createProductServiceUrl(eanList);
                eanList.clear();
            }
        }if(!eanList.isEmpty()){
            url2= teauthFileProcessor.createProductServiceUrl(eanList);
        }
        ServletException servletException1= new ServletException("HTTP 500 - Internal Server Error. URL : "+url1);
        ServletException servletException2= new ServletException("HTTP 500 - Internal Server Error. URL : "+url2);

        List<String> dummyEanList = new ArrayList<>();
        dummyEanList.add("1234");
        teauthFileProcessor.setWebServiceCallBuilder(webServiceCallBuilder);
        this.teauthFileProcessor.processMissedEansInPriceServices(eanMapFromPriceServices);
		expectedPriceCheckFileDetails.add("TEAUTH EAN Seeding Failed :: Error Msg : "+servletException1.toString());
		expectedPriceCheckFileDetails.add("TEAUTH EAN Seeding Failed :: Error Msg : "+servletException2.toString());

        assertThat(teauthFileProcessor.getPriceCheckFileDetails()).isEqualTo(expectedPriceCheckFileDetails);

    }
    @Test
    public void test200StatusAfterProdServiceCalls(){
        Response clientResponseMock = mock(Response.class);
        when(webServiceCallBuilder.getResponseFromProdServices(Matchers.any(String.class))).thenReturn(clientResponseMock);
        when(clientResponseMock.getStatus()).thenReturn(200);
        Map<String,String> productsMap = new LinkedHashMap<>();
        productsMap.put("TPNC","23456782");
        productsMap.put("GTIN14","04894304307752");
        List<Map<String,String>> productsList = new LinkedList<>();
        productsList.add(productsMap);

        List<String> missingSet = new ArrayList<>();
        missingSet.add("00000000000002");

        Map expectedResponseMap = new LinkedHashMap();
        expectedResponseMap.put("products",productsList);
        expectedResponseMap.put("missingSet",missingSet);
        when(clientResponseMock.readEntity(Map.class)).thenReturn(expectedResponseMap);
        List<String> eanList = new ArrayList<>();
        eanList.add("04894304307752");
        eanList.add("00000000000002");
        teauthFileProcessor.setWebServiceCallBuilder(webServiceCallBuilder);
        this.teauthFileProcessor.callProductService(eanList);
		expectedPriceCheckFileDetails.add("TEAUTH Invalid EAN, not available in product service - store " + storeId + " item ean 00000000000002");
        assertThat(teauthFileProcessor.getPriceCheckFileDetails()).isEqualTo(expectedPriceCheckFileDetails);
        Map<String,String> expectedTpncToEanMapFromProdServices = new LinkedHashMap<>();
        expectedTpncToEanMapFromProdServices.put("23456782",PriceConstants.EAN_KEY_PREFIX + "4894304307752");
        assertThat(teauthFileProcessor.getTpncToEanMapFromProdServices()).isEqualTo(expectedTpncToEanMapFromProdServices);

    }

    @Test
    public void shouldGetTpncDetailsFromProdSrvceForMissedEansInPrcsrvceAndComparePrices() throws Exception{
        fileName = "KLL KLAUTH B3121";
        storeId = fileName.substring(fileName.length() - 4);
        String line = "205034934293011    0.75    0.75   0.7505034934293028    0.75    0.75   0.750";
        String footer = "90001";
        String tpnc="234567891";
        String tpnb="056789988";
        Map<String,String> eanMap = new LinkedHashMap<>();
        eanMap.put(PriceConstants.EAN_KEY_PREFIX + "5034934293011", "0.75");

		expectedPriceCheckFileDetails.add("TEAUTH validation started - store " + storeId);
		expectedPriceCheckFileDetails.add("TEAUTH Invalid EAN, not available in product service - store "+storeId+" item ean 05034934293028");

        buildEanMappingAndProducts(eanMap, tpnc, tpnb, false, false, false);
        TeauthPriceChecksResource.SEMAPHORE_MAP.put(fileName, new Semaphore(1));


        teauthFileProcessor = new TeauthFileProcessor(testConfiguration,couchbaseWrapper,asyncCouchbaseWrapper,webServiceCallBuilder,teauthReader);
        teauthFileProcessor.setFileName(fileName);
        teauthFileProcessor.setWebServiceCallBuilder(webServiceCallBuilder);
        when(teauthReader.readLine()).thenReturn(line).thenReturn(footer).thenReturn(null);

        Map<String,Object> responseMap = new LinkedHashMap<>();
        responseMap.put(PriceConstants.GET_PRICE_LIST_DATA,expectedDataList);
        responseMap.put(PriceConstants.GET_PRICE_LIST_ERRORS,expectedErrorList);

        Response clientResponseMockForPriceGet = mock(Response.class);

        when(webServiceCallBuilder.getResponseFromRemoteServerForProductsListWithStore(Matchers.any(Set.class),
                Matchers.any(String.class))).thenReturn(clientResponseMockForPriceGet);
        when(clientResponseMockForPriceGet.getStatus()).thenReturn(200);
        when(clientResponseMockForPriceGet.readEntity(Map.class)).thenReturn(responseMap);

        Response clientResponseMock = mock(Response.class);

        when(webServiceCallBuilder.getResponseFromProdServices(Matchers.any(String.class))).thenReturn(clientResponseMock);
        when(clientResponseMock.getStatus()).thenReturn(200);
        Map<String,String> productsMap = new LinkedHashMap<>();
        productsMap.put("TPNC",getDynamicItem(tpnc, 1));
        productsMap.put("GTIN14","05034934293011");
        List<Map<String,String>> productsList = new LinkedList<>();
        productsList.add(productsMap);

        List<String> missingSet = new ArrayList<>();
        missingSet.add("05034934293028");

        Map expectedResponseMap = new LinkedHashMap();
        expectedResponseMap.put("products",productsList);
        expectedResponseMap.put("missingSet",missingSet);
        when(clientResponseMock.readEntity(Map.class)).thenReturn(expectedResponseMap);

        this.teauthFileProcessor.readAndProcessFile();
        assertThat(teauthFileProcessor.getPriceCheckFileDetails()).isEqualTo(expectedPriceCheckFileDetails);

    }

    @Test
    public void shouldGetTpncDetailsFromProdSrvceForMissedEansInPrcsrvceAndLogErroredResponse() throws Exception{
        fileName = "KLL KLAUTH B3121";
        storeId = fileName.substring(fileName.length() - 4);
        String line = "205034934293011    0.75    0.75   0.7505034934293028    0.75    0.75   0.750";
        String footer = "90001";
        String tpnc="234567891";
        String tpnb="056789988";
        Map<String,String> eanMap = new LinkedHashMap<>();
        eanMap.put(PriceConstants.EAN_KEY_PREFIX + "5034934293011", "0.75");

		expectedPriceCheckFileDetails.add("TEAUTH validation started - store " + storeId);
		expectedPriceCheckFileDetails.add("TEAUTH Invalid EAN, not available in product service - store "+storeId+" item ean 05034934293028");

        buildEanMappingAndProducts(eanMap, tpnc, tpnb, false, true, false);
        TeauthPriceChecksResource.SEMAPHORE_MAP.put(fileName, new Semaphore(1));


        teauthFileProcessor = new TeauthFileProcessor(testConfiguration,couchbaseWrapper,asyncCouchbaseWrapper,webServiceCallBuilder,teauthReader);
        teauthFileProcessor.setFileName(fileName);
        teauthFileProcessor.setWebServiceCallBuilder(webServiceCallBuilder);
        when(teauthReader.readLine()).thenReturn(line).thenReturn(footer).thenReturn(null);

        Map<String,Object> responseMap = new LinkedHashMap<>();
        responseMap.put(PriceConstants.GET_PRICE_LIST_DATA,expectedDataList);
        responseMap.put(PriceConstants.GET_PRICE_LIST_ERRORS,expectedErrorList);

        Response clientResponseMockForPriceGet = mock(Response.class);

        when(webServiceCallBuilder.getResponseFromRemoteServerForProductsListWithStore(Matchers.any(Set.class),
                Matchers.any(String.class))).thenReturn(clientResponseMockForPriceGet);
        when(clientResponseMockForPriceGet.getStatus()).thenReturn(500);
        when(clientResponseMockForPriceGet.readEntity(Map.class)).thenReturn(responseMap);
        when(clientResponseMockForPriceGet.readEntity(String.class)).thenReturn(String.format("{\"error\":\"%s\"}", HTTPResponses.INTERNAL_SERVER_ERROR));

        Response clientResponseMock = mock(Response.class);

        when(webServiceCallBuilder.getResponseFromProdServices(Matchers.any(String.class))).thenReturn(clientResponseMock);
        when(clientResponseMock.getStatus()).thenReturn(200);
        Map<String,String> productsMap = new LinkedHashMap<>();
        productsMap.put("TPNC",getDynamicItem(tpnc, 1));
        productsMap.put("GTIN14","05034934293011");
        List<Map<String,String>> productsList = new LinkedList<>();
        productsList.add(productsMap);

        List<String> missingSet = new ArrayList<>();
        missingSet.add("05034934293028");

        Map expectedResponseMap = new LinkedHashMap();
        expectedResponseMap.put("products",productsList);
        expectedResponseMap.put("missingSet",missingSet);
        when(clientResponseMock.readEntity(Map.class)).thenReturn(expectedResponseMap);

        this.teauthFileProcessor.readAndProcessFile();
        assertThat(teauthFileProcessor.getPriceCheckFileDetails()).isEqualTo(expectedPriceCheckFileDetails);

    }
    @Test
    public void shouldWriteToCollectionWhenGtinIsNullAfterProdServiceCalls(){
        String tpnc = "234567891";
        Response clientResponseMock = mock(Response.class);
        when(webServiceCallBuilder.getResponseFromProdServices(Matchers.any(String.class))).thenReturn(clientResponseMock);
        when(clientResponseMock.getStatus()).thenReturn(200);
        Map<String,String> productsMap = new LinkedHashMap<>();
        productsMap.put("TPNC",tpnc);
        productsMap.put("GTIN14",null);
        List<Map<String,String>> productsList = new LinkedList<>();
        productsList.add(productsMap);

        List<String> missingSet = new ArrayList<>();
        missingSet.add("00000000000002");

        Map expectedResponseMap = new LinkedHashMap();
        expectedResponseMap.put("products",productsList);
        expectedResponseMap.put("missingSet",missingSet);
        when(clientResponseMock.readEntity(Map.class)).thenReturn(expectedResponseMap);
        List<String> eanList = new ArrayList<>();
        eanList.add("04894304307752");
        eanList.add("00000000000002");
        teauthFileProcessor.setWebServiceCallBuilder(webServiceCallBuilder);
        this.teauthFileProcessor.callProductService(eanList);

		expectedPriceCheckFileDetails.add("EAN mapping not found for TPNC : "+tpnc+" - store : "+storeId);
		expectedPriceCheckFileDetails.add("TEAUTH Invalid EAN, not available in product service - store " + storeId + " item ean 00000000000002");

        assertThat(teauthFileProcessor.getPriceCheckFileDetails()).isEqualTo(expectedPriceCheckFileDetails);
        Map<String,String> expectedTpncToEanMapFromProdServices = new LinkedHashMap<>();
        expectedTpncToEanMapFromProdServices.put("23456782",PriceConstants.EAN_KEY_PREFIX + "4894304307752");
        assertThat(teauthFileProcessor.getPriceCheckFileDetails()).isEqualTo(expectedPriceCheckFileDetails);

    }
    @Test
    public void shouldWriteToCollectionWhenTpncIsNullAfterProdServiceCalls(){
        String gtin = "04894304307752";
        Response clientResponseMock = mock(Response.class);
        when(webServiceCallBuilder.getResponseFromProdServices(Matchers.any(String.class))).thenReturn(clientResponseMock);
        when(clientResponseMock.getStatus()).thenReturn(200);
        Map<String,String> productsMap = new LinkedHashMap<>();
        productsMap.put("TPNC",null);
        productsMap.put("GTIN14",gtin);
        List<Map<String,String>> productsList = new LinkedList<>();
        productsList.add(productsMap);

        List<String> missingSet = new ArrayList<>();
        missingSet.add("00000000000002");

        Map expectedResponseMap = new LinkedHashMap();
        expectedResponseMap.put("products",productsList);
        expectedResponseMap.put("missingSet",missingSet);
        when(clientResponseMock.readEntity(Map.class)).thenReturn(expectedResponseMap);
        List<String> eanList = new ArrayList<>();
        eanList.add("04894304307752");
        eanList.add("00000000000002");
        teauthFileProcessor.setWebServiceCallBuilder(webServiceCallBuilder);
        this.teauthFileProcessor.callProductService(eanList);

		expectedPriceCheckFileDetails.add("TPNC mapping not available in product service - store :" + storeId + ":: item EAN :"+gtin);
		expectedPriceCheckFileDetails.add("TEAUTH Invalid EAN, not available in product service - store " + storeId + " item ean 00000000000002");

        assertThat(teauthFileProcessor.getPriceCheckFileDetails()).isEqualTo(expectedPriceCheckFileDetails);
        Map<String,String> expectedTpncToEanMapFromProdServices = new LinkedHashMap<>();
        expectedTpncToEanMapFromProdServices.put("23456782",PriceConstants.EAN_KEY_PREFIX + "4894304307752");
        assertThat(teauthFileProcessor.getPriceCheckFileDetails()).isEqualTo(expectedPriceCheckFileDetails);

    }

	@Test
	public void callProductServiceTest() throws Exception {

		Map actualProductPriceInfo = new HashMap();
		String line = "20     10009666    1.31    1.31  10.480     10009680    3.00    3.00   8.580";
		List<Map<String, String>> products = new ArrayList<>();
		Map prod1 = new HashMap();
		prod1.put(PriceConstants.PRODUCT_SERVICE_RESPONSE_TPNC, "254842259");
		prod1.put(PriceConstants.PRODUCT_SERVICE_RESPONSE_GTIN14,
				"00000010009666");
		List l = new ArrayList();
		l.add("10009666");
		l.add("10009680");
		String url = teauthFileProcessor.createProductServiceUrl(l);
		products.add(prod1);
		actualProductPriceInfo.put(
				PriceConstants.PRODUCT_SERVICE_RESPONSE_PRODUCTS, products);
		actualProductPriceInfo.put(
				PriceConstants.PRODUCT_SERVICE_RESPONSE_TOTAL, 1);
		actualProductPriceInfo.put(
				PriceConstants.PRODUCT_SERVICE_RESPONSE_MISSING_SET,
				new ArrayList<>());
		setFinalStatic(
				PriceConstants.class.getField("PRODUCT_SERVICE_CALL_LIMIT"), 2);
		BufferedReader mockBufferedReader = Mockito.mock(BufferedReader.class);
		teauthFileProcessor.setRepository(repositoryImpl);
		teauthFileProcessor.setWebServiceCallBuilder(webServiceCallBuilder);
		Mockito.when(webServiceCallBuilder.getResponseFromProdServices(url))
				.thenReturn(response);
		Mockito.when(response.getStatus()).thenReturn(200);
		Mockito.when(response.readEntity(Map.class)).thenReturn(
				actualProductPriceInfo);
		Mockito.when(mockBufferedReader.readLine()).thenReturn(line)
				.thenReturn(null);
		Set eans = new HashSet();
		eans.add("0000010009666");
		assertThat(teauthFileProcessor.getTpncMapListForEans(eans) != null);

	}

    public void createProdServiceResponseMap(){

        Map<String,String> productsMap = new LinkedHashMap<>();
        productsMap.put("TPNC","23456782");
        productsMap.put("GTIN14","04894304307752");
        List<Map<String,String>> productsList = new LinkedList<>();
        productsList.add(productsMap);

        List<String> missingSet = new ArrayList<>();
        missingSet.add("00000000000002");

        Map expectedResponseMap = new LinkedHashMap();
        expectedResponseMap.put("products",productsList);
        expectedResponseMap.put("missingSet",missingSet);
    }

	static void setFinalStatic(Field field, Object newValue) throws Exception {
		field.setAccessible(true);

		// remove final modifier from field
		Field modifiersField = Field.class.getDeclaredField("modifiers");
		modifiersField.setAccessible(true);
		modifiersField.setInt(field, field.getModifiers() & ~Modifier.FINAL);

		field.set(null, newValue);
	}
}