package com.tesco.services.utility;

import static com.tesco.services.utility.PriceUtility.prepareClearanceKey;
import static org.junit.Assert.assertEquals;

import java.util.HashMap;
import java.util.Map;

import org.joda.time.DateTimeUtils;
import org.junit.After;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.tesco.services.Configuration;
import com.tesco.services.CouchbaseViewConfig;
import com.tesco.services.exceptions.ProductEncodeException;

/**
 * Created by hv41 on 01/07/2015.
 */
@RunWith(MockitoJUnitRunner.class)
public class PriceUtilityTest {

	@Mock
	private Configuration configuration;

	@Test
	public void testConvertRMStoTesco() throws ProductEncodeException {
		// CheckAllEquals
		String retVal = PriceUtility.convertRMStoTesco("0200", "03", "04");
		Assert.assertEquals("B00CD", retVal);
		// checkSubClassNull
		retVal = PriceUtility.convertRMStoTesco("0200", "03", null);
		Assert.assertEquals("B00C", retVal);
		// checkClassSubclassNull
		retVal = PriceUtility.convertRMStoTesco("0200", null, null);
		Assert.assertEquals("B00", retVal);

	}

	@Test
	public void checkZeroValueForClassError() throws ProductEncodeException {
		try {
			String retVal = PriceUtility.convertRMStoTesco("0200", "03", "0");
		} catch (ProductEncodeException e) {
			Assert.assertTrue(true);
		}
	}

	@Test
	public void checkZeroValueForClassSubClassError()
			throws ProductEncodeException {
		try {
			String retVal = PriceUtility.convertRMStoTesco("0200", "0", "0");
		} catch (ProductEncodeException e) {
			Assert.assertTrue(true);
		}
	}

	@Test
	public void checkAllValueZeroError() throws ProductEncodeException {
		try {
			String retVal = PriceUtility.convertRMStoTesco("0", "0", "0");
		} catch (ProductEncodeException e) {
			Assert.assertTrue(true);
		}
	}

	@Test
	public void checkGreaterThanTwentySixException()
			throws ProductEncodeException {
		try {
			String retVal = PriceUtility.convertRMStoTesco("0200", "03", "27");
		} catch (ProductEncodeException e) {
			Assert.assertTrue(true);
		}

	}

	@Test
	public void checkDeptAndClassNullException() throws ProductEncodeException {
		try {
			String retVal = PriceUtility.convertRMStoTesco(null, null, "27");
		} catch (ProductEncodeException e) {
			Assert.assertTrue(true);
		}

	}

	@Test
	public void checkDeptSpaceException() throws ProductEncodeException {
		try {
			String retVal = PriceUtility.convertRMStoTesco(" ", "03", "27");
		} catch (ProductEncodeException e) {
			Assert.assertTrue(true);
		}

	}

	@Test
	public void checkAllAlphaException() throws ProductEncodeException {
		try {
			String retVal = PriceUtility.convertRMStoTesco("A20", "B", "2C");
		} catch (NumberFormatException e) {
			Assert.assertTrue(true);
		}

	}

	@Test
	public void checkDeptGreaterThanTwentySixException()
			throws ProductEncodeException {
		try {
			String retVal = PriceUtility.convertRMStoTesco("2822", "03", "24");
		} catch (ProductEncodeException e) {
			Assert.assertTrue(true);
		}

	}

	@Test
	public void checkDeptMoreThanFourException() throws ProductEncodeException {
		try {
			String retVal = PriceUtility.convertRMStoTesco("12345", "03", "27");
		} catch (ProductEncodeException e) {
			Assert.assertTrue(true);
		}

	}

	@Test
	public void checkClassSpaceException() throws ProductEncodeException {
		try {
			String retVal = PriceUtility.convertRMStoTesco("1234", " ", "23");
		} catch (ProductEncodeException e) {
			Assert.assertTrue(true);
		}

	}

	@Test
	public void checkClassMoreThanTwoException() throws ProductEncodeException {
		try {
			String retVal = PriceUtility
					.convertRMStoTesco("1234", "123 ", "23");
		} catch (ProductEncodeException e) {
			Assert.assertTrue(true);
		}
	}

	@Test
	public void verifyClearanceKeyCreated() {
		DateTimeUtils.setCurrentMillisFixed(1463981780195l);
		CouchbaseViewConfig viewConfig = Mockito
				.mock(CouchbaseViewConfig.class);
		Map<String, String> viewAdditionalProps = new HashMap<String, String>();
		viewAdditionalProps.put("offset", "+00:00");
		viewAdditionalProps.put("country", "UK");
		viewAdditionalProps.put("effectiveday", "1");

		Mockito.when(viewConfig.getViewAdditionalProperties()).thenReturn(
				viewAdditionalProps);

		String key = prepareClearanceKey(viewConfig);
		assertEquals("2016-05-24_UK", key);
	}

	@After
	public void tearDown() {
		DateTimeUtils.setCurrentMillisSystem();
	}
}