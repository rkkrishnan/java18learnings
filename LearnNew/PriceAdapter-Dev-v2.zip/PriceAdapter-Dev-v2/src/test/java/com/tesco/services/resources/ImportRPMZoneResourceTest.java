package com.tesco.services.resources;

import com.tesco.couchbase.AsyncCouchbaseWrapper;
import com.tesco.couchbase.CouchbaseWrapper;
import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.ImportRPMZoneJob;
import io.dropwizard.testing.junit.ResourceTestRule;
import org.junit.After;
import org.junit.Before;
import org.junit.ClassRule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.IOException;

import static org.fest.assertions.api.Assertions.assertThat;

/**
 * Created by qp65 on 5/21/2015.
 */

@RunWith(MockitoJUnitRunner.class)
public class ImportRPMZoneResourceTest  {

    @Mock
    private static Configuration testConfiguration;

    static ImportRPMZoneJob importRPMZoneJob = Mockito.mock(ImportRPMZoneJob.class);

    @ClassRule
    public static final ResourceTestRule resources = ResourceTestRule.builder()
            .addResource(new ImportResource(testConfiguration, null, null, null,
            importRPMZoneJob, null, null, null, null, null, null, null))
            .build();

    @Before
    public void setUpResources() throws Exception {
        Mockito.doNothing().when(importRPMZoneJob).run();
        String runType = "rpmzoneonetime";
        Mockito.doReturn(runType).when(testConfiguration).getRpmZoneDataDump();
        if(ImportResource.getImportSemaphoreForIdentifier("fileName")!=null){
			ImportResource.getImportSemaphoreForIdentifier("fileName").release();
		}
    }

    @Test
    public void shouldStartRPMZoneImportScript() throws IOException {
        WebTarget resource = resources.client()
                .target("/admin/importRPMZone/rpmzoneonetime/fileName");
        Response response = resource.request()
                .accept(MediaType.APPLICATION_JSON)
                .post(Entity.entity("", MediaType.APPLICATION_JSON));
        String responseText = response.readEntity(String.class);
        assertThat(responseText).isEqualTo(
                "{\"message\":\"Import RPM Onetime Zone load Job Started.\"}");
        assertThat(response.getStatus()).isEqualTo(200);
    }

    @Test
    public void shouldRPMZoneImportScriptThrowException() throws IOException {
        WebTarget resource = resources.client()
                .target("/admin/importRPMZone/invalidRunType/filename");
        Response response = resource.request()
                .accept(MediaType.APPLICATION_JSON)
                .post(Entity.entity("", MediaType.APPLICATION_JSON));

        assertThat(response.getStatus()).isEqualTo(400);
    }

    @After
    public void resetMocks() throws Exception {
        Mockito.reset(importRPMZoneJob);
        Mockito.reset(testConfiguration);
    }
}
