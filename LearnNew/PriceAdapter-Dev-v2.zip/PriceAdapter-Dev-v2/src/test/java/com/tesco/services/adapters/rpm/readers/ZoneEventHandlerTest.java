package com.tesco.services.adapters.rpm.readers;

import com.tesco.services.adapters.core.exceptions.ZoneEventException;
import com.tesco.services.adapters.zone.ZoneEventHandler;
import com.tesco.services.adapters.zone.impl.ZoneEventHandlerImpl;
import com.tesco.services.core.ZoneEntity;
import com.tesco.services.event.core.EventTemplate;
import com.tesco.services.event.core.impl.MapEvent;
import com.tesco.services.event.exception.EventPublishException;
import com.tesco.services.exceptions.DataAccessException;
import com.tesco.services.exceptions.ZoneBusinessException;
import com.tesco.services.repositories.RepositoryImpl;
import com.tesco.services.utility.ParseMessageUtil;
import com.tesco.services.utility.PriceConstants;
import com.tesco.zone.core.TSLZone;
import com.tesco.zone.core.TSLZoneGroupDesc;
import com.tesco.zone.core.TSLZoneGroupRef;
import com.tesco.zone.core.TSLZoneRef;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.io.IOException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static io.dropwizard.testing.FixtureHelpers.fixture;
import static org.junit.Assert.assertEquals;

@RunWith(MockitoJUnitRunner.class)
public class ZoneEventHandlerTest {

	TSLZoneGroupDesc zoneGrpDesc;
	TSLZoneGroupDesc zoneGrpDescMod;
	TSLZoneGroupRef tslZoneGroupRef;
    TSLZoneGroupDesc zoneGrpDescStoreCre;
    TSLZoneGroupRef zoneGrpRefStoreDel;


	String zoneMsgType = null;
	String zoneMsgTypeForDel = null;

	@Mock
	private EventTemplate eventTemplate;
	@Mock
	private RepositoryImpl repositoryImpl;
	private ZoneEventHandler zoneEventHandler;
	String zoneMsgTypeMod = null;
	String zoneMsgTypeStoreCre = null;
	String zoneMsgTypeStoreDel = null;
	private String zoneIdGB = "ZONE_4548";
	private String zoneIdIE = "ZONE_4545";
	private String zoneID="ZONE_60";
	private ZoneEntity zeGB = new ZoneEntity();
	private ZoneEntity zeIE = new ZoneEntity();

	@Captor 
	private ArgumentCaptor<MapEvent> argument;

	@Before
	public void setUp() throws Exception {
		
		String xmlData = fixture("com/tesco/services/core/fixtures/zone/ZoneCre.xml");
		String zoneModXml = fixture("com/tesco/services/core/fixtures/zone/ZoneModEvent.xml");	
		String xmlDataDel = fixture("com/tesco/services/core/fixtures/zone/ZoneDelete.xml");
		String xmlDataZoneStoreCreation = fixture("com/tesco/services/core/fixtures/zone/StoreZoneSetup.xml");
		String xmlDataZoneStoreRemove = fixture("com/tesco/services/core/fixtures/zone/StoreZoneRemove.xml");
		zoneEventHandler = new ZoneEventHandlerImpl(eventTemplate,
				repositoryImpl);
		zeGB.setBaseInd("0");
		zeGB.setZoneName("TestZone");
		zeGB.setCurrencyCode("USD");
		zeGB.setTslCountryCode("GB");
		
		zeIE.setBaseInd("1");
		zeIE.setZoneName("TestZone");
		zeIE.setCurrencyCode("USD");
		zeIE.setTslCountryCode("IE");
		
		ParseMessageUtil parseMessageUtil = ParseMessageUtil.getInstance();

		String zoneGrpDescData = parseMessageUtil.getNodeData(xmlData,
				PriceConstants.PROMO_MSG_DATA_PATH);
		zoneMsgType = parseMessageUtil.getNodeData(xmlData,
				PriceConstants.PROMO_MSG_TYPE_PATH);
		zoneGrpDesc = (TSLZoneGroupDesc) parseMessageUtil
				.getMappedObjectForXmlData(TSLZoneGroupDesc.class,
						zoneGrpDescData);

		String zoneGrpDescDataMod = parseMessageUtil.getNodeData(zoneModXml,
				PriceConstants.PROMO_MSG_DATA_PATH);
		zoneMsgTypeMod = parseMessageUtil.getNodeData(zoneModXml,
				PriceConstants.PROMO_MSG_TYPE_PATH);
		zoneGrpDescMod = (TSLZoneGroupDesc) parseMessageUtil
				.getMappedObjectForXmlData(TSLZoneGroupDesc.class,
						zoneGrpDescDataMod);
		String zoneGrpDescDataForStoreSetup = parseMessageUtil.getNodeData(xmlDataZoneStoreCreation,
				PriceConstants.PROMO_MSG_DATA_PATH);
		zoneMsgTypeStoreCre = parseMessageUtil.getNodeData(xmlDataZoneStoreCreation,
				PriceConstants.PROMO_MSG_TYPE_PATH);
		zoneGrpDescStoreCre = (TSLZoneGroupDesc) parseMessageUtil
				.getMappedObjectForXmlData(TSLZoneGroupDesc.class,
						zoneGrpDescDataForStoreSetup);
		
		String zoneGrpRefDataForStoreRemove = parseMessageUtil.getNodeData(xmlDataZoneStoreRemove,
				PriceConstants.PROMO_MSG_DATA_PATH);
		zoneMsgTypeStoreDel = parseMessageUtil.getNodeData(xmlDataZoneStoreRemove,
				PriceConstants.PROMO_MSG_TYPE_PATH);
		zoneGrpRefStoreDel = (TSLZoneGroupRef) parseMessageUtil
				.getMappedObjectForXmlData(TSLZoneGroupRef.class,
						zoneGrpRefDataForStoreRemove);
		
		zoneEventHandler = new ZoneEventHandlerImpl(eventTemplate,
				repositoryImpl);

		String zoneGroupRefData = parseMessageUtil.getNodeData(xmlDataDel, PriceConstants.PROMO_MSG_DATA_PATH);
		zoneMsgTypeForDel = parseMessageUtil.getNodeData(xmlDataDel, PriceConstants.PROMO_MSG_TYPE_PATH);
		tslZoneGroupRef = (TSLZoneGroupRef) parseMessageUtil.getMappedObjectForXmlData(TSLZoneGroupRef.class,zoneGroupRefData);
		
        zoneEventHandler = new ZoneEventHandlerImpl(eventTemplate,
				repositoryImpl);

	}


	@Test
	public void testEventCreatedForZoneCreation() throws ZoneEventException,
			ParseException, EventPublishException {
			zoneEventHandler.publishZoneEvent(zoneGrpDesc,PriceConstants.ZONE_MSG_TYPE_CREATED);	
			Mockito.verify(eventTemplate,Mockito.times(1)).publishEvent(argument.capture());
			assertEquals(PriceConstants.ZONE_MSG_TYPE_CREATED, (argument.getValue()).getEventType());
			assertEquals("ZoneCreated", (argument.getValue()).getHeaderData().get(PriceConstants.EVENT_TYPE));
			assertEquals("GB:Z:4548", (argument.getValue()).getHeaderData().get(PriceConstants.LOCATION_ID));
			assertEquals("1", (argument.getValue()).getHeaderData().get(PriceConstants.LEAD_TIME_DAYS));
			Map<?,?> locationMap = (Map<?,?>)(argument.getValue()).getPayloadData().get(PriceConstants.PRICING_LOC);
			assertEquals("4548", locationMap.get(PriceConstants.LOC_REF));
			assertEquals("Z", locationMap.get(PriceConstants.LOC_TYPE));
	}
	
	@Test
	public void testEventCreatedForZoneCreationZoneGroupID() throws ZoneEventException,
			ParseException, EventPublishException {
			zoneEventHandler.publishZoneEvent(zoneGrpDesc,PriceConstants.ZONE_MSG_TYPE_CREATED);	
			Mockito.verify(eventTemplate,Mockito.times(1)).publishEvent(argument.capture());
			assertEquals(PriceConstants.ZONE_MSG_TYPE_CREATED, (argument.getValue()).getEventType());
			assertEquals("ZoneCreated", (argument.getValue()).getHeaderData().get(PriceConstants.EVENT_TYPE));
			assertEquals("GB:Z:4548", (argument.getValue()).getHeaderData().get(PriceConstants.LOCATION_ID));
			assertEquals("1", (argument.getValue()).getHeaderData().get(PriceConstants.LEAD_TIME_DAYS));
			Map<?,?> locationMap = (Map<?,?>)(argument.getValue()).getPayloadData().get(PriceConstants.PRICING_LOC);
			assertEquals("4548", locationMap.get(PriceConstants.LOC_REF));
			assertEquals("Z", locationMap.get(PriceConstants.LOC_TYPE));
			
	}
	@Test
	public void testEventCreationForZoneDetailsChanged() throws ZoneEventException,ParseException, ZoneBusinessException, EventPublishException{		
		zoneEventHandler.publishZoneEvent(zoneGrpDescMod,PriceConstants.ZONE_MSG_TYPE_DTLS_CHANGED);
		Mockito.verify(eventTemplate,Mockito.times(1)).publishEvent(argument.capture());
		assertEquals(PriceConstants.ZONE_MSG_TYPE_DTLS_CHANGED, (argument.getValue()).getEventType());
		assertEquals("ZoneDetailsChanged", (argument.getValue()).getHeaderData().get(PriceConstants.EVENT_TYPE));
		assertEquals("GB:Z:4548", (argument.getValue()).getHeaderData().get(PriceConstants.LOCATION_ID));
		assertEquals("1", (argument.getValue()).getHeaderData().get(PriceConstants.LEAD_TIME_DAYS));
		Map<?,?> locationMap = (Map<?,?>)(argument.getValue()).getPayloadData().get(PriceConstants.PRICING_LOC);
		assertEquals("4548", locationMap.get(PriceConstants.LOC_REF));
		assertEquals("Z", locationMap.get(PriceConstants.LOC_TYPE));
	}
	@Test(expected = ZoneEventException.class)
	public void shouldThrowEventPublicationExceptionForZoneDetailsChange() throws ZoneEventException, EventPublishException{		
		MapEvent data = new MapEvent();
		data.setEventType(PriceConstants.ZONE_MSG_TYPE_DTLS_CHANGED);
		Map<String, String> headerMap = new HashMap<String, String>();
		Map<String, Object> payloadMap = new HashMap<String, Object>();		
		headerMap.put(PriceConstants.LOCATION_ID, "GB"+":"+PriceConstants.ZONE_PREFIX+":"+4548);
		headerMap.put(PriceConstants.LEAD_TIME_DAYS, PriceConstants.ZONE_CRE_EVNT_LTD); // LeadTime Days is always 1 for zone deletion
		headerMap.put(PriceConstants.EVENT_TYPE, PriceConstants.ZONE_MSG_TYPE_DTLS_CHANGED);
		headerMap.put(PriceConstants.EVENT_CORR_ID, PriceConstants.EVENT_PREFIX +4548);
		Map<String,String> jsonComplex = new HashMap<>();
		jsonComplex.put(PriceConstants.LOC_TYPE, "Z");
		jsonComplex.put(PriceConstants.LOC_REF, "4548");
		payloadMap.put(PriceConstants.PRICING_LOC,jsonComplex);
		data.setHeaderData(headerMap);
		data.setPayloadData(payloadMap);		
		ZoneEntity ze = new ZoneEntity();
		ze.setBaseInd("0");
		ze.setZoneName("TestZone");
		ze.setCurrencyCode("USD");
		ze.setTslCountryCode("GB");		
		Mockito.when(eventTemplate.publishEvent(data)).thenThrow(new EventPublishException(new Exception("Error"), "Error"));		
		zoneEventHandler.publishZoneEvent(zoneGrpDescMod,PriceConstants.ZONE_MSG_TYPE_DTLS_CHANGED);
	}	
	
	@Test
	public void testEventCreatedForZoneDeletionOnSingleZoneAndCountry() throws ZoneEventException, ParseException, EventPublishException,DataAccessException{
		
		Mockito.when(repositoryImpl.getGenericObject(zoneIdGB,ZoneEntity.class)).thenReturn(zeGB);
		Mockito.when(repositoryImpl.getGenericObject(zoneIdIE,ZoneEntity.class)).thenReturn(zeIE);
		
		zoneEventHandler.publishZoneDelEvent(tslZoneGroupRef,getZoneIdCountryCodeMap(tslZoneGroupRef));		 
		Mockito.verify(eventTemplate,Mockito.times(2)).publishEvent(argument.capture());
		List<MapEvent> listData=argument.getAllValues();
		assertEquals(PriceConstants.ZONE_MSG_TYPE_DELETED, (argument.getValue()).getEventType());
		assertEquals("GB:Z:4548", (listData.get(0)).getHeaderData().get(PriceConstants.LOCATION_ID));
		assertEquals("ZoneDeleted", (listData.get(0)).getHeaderData().get(PriceConstants.EVENT_TYPE));
		assertEquals("1", (listData.get(0)).getHeaderData().get(PriceConstants.LEAD_TIME_DAYS));
		Map<?,?> locationMap = (Map<?,?>)(listData.get(0)).getPayloadData().get(PriceConstants.PRICING_LOC);
		assertEquals("4548", locationMap.get(PriceConstants.LOC_REF));
		locationMap = (Map<?,?>)(listData.get(1)).getPayloadData().get(PriceConstants.PRICING_LOC);
		assertEquals("4545", locationMap.get(PriceConstants.LOC_REF));
		assertEquals("Z", locationMap.get(PriceConstants.LOC_TYPE));
	}
	
	@Test
	public void testEventCreatedForZoneDeletionOnMultipleZoneAndCountry() throws ZoneEventException, ParseException, EventPublishException,DataAccessException{

		Mockito.when(repositoryImpl.getGenericObject(zoneIdGB,ZoneEntity.class)).thenReturn(zeGB);
		Mockito.when(repositoryImpl.getGenericObject(zoneIdIE,ZoneEntity.class)).thenReturn(zeIE);

		zoneEventHandler.publishZoneDelEvent(tslZoneGroupRef,getZoneIdCountryCodeMap(tslZoneGroupRef));		 
		Mockito.verify(eventTemplate,Mockito.times(2)).publishEvent(argument.capture());
		List<MapEvent> captorData=argument.getAllValues();
		assertEquals(PriceConstants.ZONE_MSG_TYPE_DELETED, (argument.getValue()).getEventType());		
		assertEquals("GB:Z:4548", (captorData.get(0)).getHeaderData().get(PriceConstants.LOCATION_ID));
		assertEquals("ZoneDeleted", (captorData.get(0)).getHeaderData().get(PriceConstants.EVENT_TYPE));
		assertEquals("1", (captorData.get(0)).getHeaderData().get(PriceConstants.LEAD_TIME_DAYS));
		Map<?,?> locationMap = (Map<?,?>)(captorData.get(0)).getPayloadData().get(PriceConstants.PRICING_LOC);
		assertEquals("4548", locationMap.get(PriceConstants.LOC_REF));
		assertEquals("Z", locationMap.get(PriceConstants.LOC_TYPE));

		assertEquals("IE:Z:4545", (captorData.get(1)).getHeaderData().get(PriceConstants.LOCATION_ID));
		assertEquals("ZoneDeleted", (captorData.get(1)).getHeaderData().get(PriceConstants.EVENT_TYPE));
		assertEquals("1", (captorData.get(1)).getHeaderData().get(PriceConstants.LEAD_TIME_DAYS));
		locationMap = (Map<?,?>)(captorData.get(1)).getPayloadData().get(PriceConstants.PRICING_LOC);
		assertEquals("4545", locationMap.get(PriceConstants.LOC_REF));
		assertEquals("Z", locationMap.get(PriceConstants.LOC_TYPE));

	}

	
	@Test(expected = ZoneEventException.class)
	public void shouldThrowExceptionOnEventDataForZoneDeletion()
			throws IOException, ZoneEventException, EventPublishException,
			DataAccessException {
		MapEvent data = new MapEvent();
		data.setEventType(PriceConstants.ZONE_MSG_TYPE_DELETED);
		Map<String, String> headerMap = new HashMap<String, String>();
		Map<String, Object> payloadMap = new HashMap<String, Object>();		
		headerMap.put(PriceConstants.LOCATION_ID, "GB"+":"+PriceConstants.ZONE_PREFIX+":"+4548);
		headerMap.put(PriceConstants.LEAD_TIME_DAYS, PriceConstants.ZONE_CRE_EVNT_LTD); // LeadTime Days is always 1 for zone deletion
		headerMap.put(PriceConstants.EVENT_TYPE, PriceConstants.ZONE_MSG_TYPE_DELETED);
		headerMap.put(PriceConstants.EVENT_CORR_ID, PriceConstants.EVENT_PREFIX +4548);
		Map<String,String> jsonComplex = new HashMap<>();
		jsonComplex.put(PriceConstants.LOC_TYPE, "Z");
		jsonComplex.put(PriceConstants.LOC_REF, "4548");
		payloadMap.put(PriceConstants.PRICING_LOC,jsonComplex);
		data.setHeaderData(headerMap);
		data.setPayloadData(payloadMap);
		Mockito.when(eventTemplate.publishEvent(data)).thenThrow(new EventPublishException(new Exception("Error"), "Error"));
		Mockito.when(repositoryImpl.getGenericObject(zoneIdGB,ZoneEntity.class)).thenReturn(
				zeGB);
		Mockito.when(repositoryImpl.getGenericObject(zoneIdIE,
				ZoneEntity.class)).thenReturn(zeIE);
		zoneEventHandler.publishZoneDelEvent(tslZoneGroupRef,getZoneIdCountryCodeMap(tslZoneGroupRef));
	}
	
	@Test
	public void testEventCreatedForStoreZoneChangeNewStore() throws ZoneEventException, EventPublishException ,DataAccessException{
		Mockito.when(repositoryImpl.getGenericObject(zoneID,ZoneEntity.class)).thenReturn(zeGB);
		zoneEventHandler.publishStoreZoneChangeCreEvent(zoneGrpDescStoreCre,getZoneIdCountryCodeForTSLZoneGroup(zoneGrpDescStoreCre));			 
		Mockito.verify(eventTemplate,Mockito.times(1)).publishEvent(argument.capture());		
		assertEquals(PriceConstants.STORE_ZONE_CHANGE, (argument.getValue()).getEventType());		
		assertEquals(PriceConstants.STORE_ZONE_CHANGE, (argument.getValue()).getHeaderData().get(PriceConstants.EVENT_TYPE));		
		assertEquals("1", (argument.getValue()).getHeaderData().get(PriceConstants.LEAD_TIME_DAYS));
		assertEquals("GB:S:2000", (argument.getValue()).getHeaderData().get(PriceConstants.LOCATION_ID));
		Map<?,?> locationMap = (Map<?,?>)(argument.getValue()).getPayloadData().get(PriceConstants.PRICING_LOC);
		assertEquals("2000", locationMap.get(PriceConstants.LOC_REF));
		assertEquals("S", locationMap.get(PriceConstants.LOC_TYPE));
		
	}
	
	@Test
	public void testEventCreatedForStoreZoneChangeRemoveStore() throws ZoneEventException, EventPublishException,DataAccessException{
		
		Mockito.when(repositoryImpl.getGenericObject(zoneID,ZoneEntity.class)).thenReturn(zeGB);
		zoneEventHandler.publishStoreZoneChangeRemoveEvent(zoneGrpRefStoreDel,getZoneIdCountryCodeMap(zoneGrpRefStoreDel));			 
		Mockito.verify(eventTemplate,Mockito.times(1)).publishEvent(argument.capture());		
		assertEquals(PriceConstants.STORE_ZONE_CHANGE, (argument.getValue()).getEventType());		
		assertEquals(PriceConstants.STORE_ZONE_CHANGE, (argument.getValue()).getHeaderData().get(PriceConstants.EVENT_TYPE));		
		assertEquals("1", (argument.getValue()).getHeaderData().get(PriceConstants.LEAD_TIME_DAYS));
		assertEquals("GB:S:1998", (argument.getValue()).getHeaderData().get(PriceConstants.LOCATION_ID));
		Map<?,?> locationMap = (Map<?,?>)(argument.getValue()).getPayloadData().get(PriceConstants.PRICING_LOC);
		assertEquals("1998", locationMap.get(PriceConstants.LOC_REF));
		assertEquals("S", locationMap.get(PriceConstants.LOC_TYPE));
	}

	private Map<String, ZoneEntity> getZoneIdCountryCodeMap(TSLZoneGroupRef tslZoneGroupRef)
			throws DataAccessException {
		List<TSLZoneRef> tslZoneRefList = tslZoneGroupRef.getTSLZoneRef();
		Map<String, ZoneEntity> zoneCountryCodeMap = new HashMap<String, ZoneEntity>();
		for(TSLZoneRef tslZoneRef : tslZoneRefList){			
			ZoneEntity zoneEntity = (ZoneEntity) repositoryImpl.getGenericObject(
					PriceConstants.ZONE_KEY + String
							.valueOf(tslZoneRef.getZoneId()), ZoneEntity.class);
			zoneCountryCodeMap.put(String.valueOf(tslZoneRef.getZoneId()),zoneEntity);						
		}		 
		return zoneCountryCodeMap;		
	}
	
	private Map<String, ZoneEntity> getZoneIdCountryCodeForTSLZoneGroup(TSLZoneGroupDesc tslZoneGroupDec)
			throws DataAccessException {
		List<TSLZone> tslZoneList = tslZoneGroupDec.getTSLZone();	
		Map<String, ZoneEntity> zoneCountryCodeMap = new HashMap<String, ZoneEntity>();
		 for(TSLZone tslZone : tslZoneList){
				ZoneEntity zoneEntity = (ZoneEntity) repositoryImpl.getGenericObject(
						PriceConstants.ZONE_KEY + String
								.valueOf(tslZone.getZoneId()), ZoneEntity.class);
				if(zoneEntity != null){
					zoneCountryCodeMap.put(String.valueOf(tslZone.getZoneId()),zoneEntity);
				}	
	         }	 
		 return zoneCountryCodeMap;
   }


}