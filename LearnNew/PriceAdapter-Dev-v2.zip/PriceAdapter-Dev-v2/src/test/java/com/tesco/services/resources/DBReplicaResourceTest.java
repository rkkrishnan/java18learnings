package com.tesco.services.resources;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Optional;
import com.tesco.couchbase.AsyncCouchbaseWrapper;
import com.tesco.couchbase.CouchbaseWrapper;
import com.tesco.couchbase.testutils.AsyncCouchbaseWrapperStub;
import com.tesco.couchbase.testutils.BucketTool;
import com.tesco.couchbase.testutils.CouchbaseTestManager;
import com.tesco.couchbase.testutils.CouchbaseWrapperStub;
import com.tesco.services.adapters.rpm.readers.PriceServiceCSVReader;
import com.tesco.services.core.*;
import com.tesco.services.repositories.RepositoryImpl;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.PriceConstants;
import io.dropwizard.testing.junit.ResourceTestRule;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.junit.Before;
import org.junit.ClassRule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;
import java.util.HashMap;
import java.util.Map;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

/**
 * Created by QZ88 on 19/11/2014.
 */
@RunWith(MockitoJUnitRunner.class) public class DBReplicaResourceTest {
	private static Map<String, ImmutablePair<Long, String>> fakeBase = new HashMap<>();

	private static ObjectMapper mapper = new ObjectMapper();

	private static CouchbaseWrapper couchbaseWrapper = new CouchbaseTestManager(
			new CouchbaseWrapperStub(fakeBase),
			new AsyncCouchbaseWrapperStub(fakeBase), mock(BucketTool.class))
			.getCouchbaseWrapper();

	private static AsyncCouchbaseWrapper asyncCouchbaseWrapper = new CouchbaseTestManager(
			new CouchbaseWrapperStub(fakeBase),
			new AsyncCouchbaseWrapperStub(fakeBase), mock(BucketTool.class))
			.getAsyncCouchbaseWrapper();

	@ClassRule public static final ResourceTestRule resources = ResourceTestRule
			.builder().addResource(new DBReplicaResource(couchbaseWrapper,
					asyncCouchbaseWrapper, mapper)).build();

	private RepositoryImpl repositoryImpl;
	private Promotion promotionForProduct = null;
	private String sellingUOM = "KG";

	@Mock private PriceServiceCSVReader rpmPromotionReader;
	@Mock private PriceServiceCSVReader rpmPromotionDescReader;

	@Before public void setUpResources() throws Exception {
		repositoryImpl = new RepositoryImpl(couchbaseWrapper,
				asyncCouchbaseWrapper, mapper);
	}

	@Test public void shouldFetchProductForTheRequestedKey() throws Exception {

		final String tpnc = "284347092";
		int priceZoneId = 1;
		String price = null;
		String tpnb = "070461113";
		ProductVariant productVariant = createProductVariant(tpnc, priceZoneId,
				price, null);
		Product product = createProduct(tpnb, productVariant);
		repositoryImpl.insertObject(
				PriceConstants.PRODUCT_KEY_PREFIX + product.getTPNB(), product);
		WebTarget resource = resources.client()
				.target("/dbreplica/PRODUCT_" + tpnb);
		Response response = resource.request().get();
		assertThat(response.getStatus()).isEqualTo(200);
		assertThat(response.readEntity(Product.class)).isEqualTo(product);

	}

	@Test public void ShouldReturn404WhenProductDataIsNotAvailableInDB()
			throws Exception {

		final String tpnc = "284347092";
		int priceZoneId = 1;
		String price = null;
		String tpnb = "070461113";
		String key = "gdhgfdg";
		ProductVariant productVariant = createProductVariant(tpnc, priceZoneId,
				price, null);
		Product product = createProduct(tpnb, productVariant);
		repositoryImpl.insertObject(
				PriceConstants.PRODUCT_KEY_PREFIX + product.getTPNB(), product);
		WebTarget resource = resources.client()
				.target("/dbreplica/PRODUCT_" + key);
		Response response = resource.request().get();
		assertThat(response.getStatus()).isEqualTo(404);
		assertThat(response.readEntity(String.class))
				.contains("Data unavailable in Database");

	}

	@Test public void shouldFetchStoreDataForTheRequestedKey()
			throws Exception {

		String storeId = "2002";
		int NATIONAL_PRICE_ZONE_ID = 1;
		String NATIONAL_ZONE_CURRENCY = "GBP";
		int NATIONAL_PROMO_ZONE_ID = 5;
		int NATIONAL_CLEARANCE_ZONE_ID = 20;
		Store store = new Store(storeId, Optional.of(NATIONAL_PRICE_ZONE_ID),
				Optional.of(NATIONAL_PROMO_ZONE_ID),
				Optional.of(NATIONAL_CLEARANCE_ZONE_ID), NATIONAL_ZONE_CURRENCY,
				"GB");
		repositoryImpl.insertObject(
				PriceConstants.STORE_KEY + store.getStoreId(),
				store);
		WebTarget resource = resources.client()
				.target("/dbreplica/STORE_" + storeId);
		Response response = resource.request().get();
		assertThat(response.getStatus()).isEqualTo(200);
		assertThat(response.readEntity(Store.class)).isEqualTo(store);

	}

	@Test public void shouldReturn404WhenStoreRequestedNotFound()
			throws Exception {

		String storeId = "2002";
		int NATIONAL_PRICE_ZONE_ID = 1;
		String NATIONAL_ZONE_CURRENCY = "GBP";
		int NATIONAL_PROMO_ZONE_ID = 5;
		String keyStore = "200002";
		int NATIONAL_CLEARANCE_ZONEID = 20;
		Store store = new Store(storeId, Optional.of(NATIONAL_PRICE_ZONE_ID),
				Optional.of(NATIONAL_PROMO_ZONE_ID),
				Optional.of(NATIONAL_CLEARANCE_ZONEID), NATIONAL_ZONE_CURRENCY,
				"GB");
		repositoryImpl.insertObject(
				PriceConstants.STORE_KEY + store.getStoreId(),
				store);
		WebTarget resource = resources.client()
				.target("/dbreplica/STORE_" + keyStore);
		Response response = resource.request().get();
		assertThat(response.getStatus()).isEqualTo(404);
		assertThat(response.readEntity(String.class))
				.contains("Data unavailable in Database");

	}

	private ProductVariant createProductVariant(String tpnc, int zoneId,
			String price, Promotion promotion) {
		ProductVariant productVariant = new ProductVariant(tpnc);
		SaleInfo saleInfo = new SaleInfo(zoneId, price);
		if (promotion != null) {
			promotionForProduct = promotion;
		}
		productVariant.addSaleInfo(saleInfo);
		productVariant.setSellingUOM(sellingUOM);

		return productVariant;
	}

	private Product createProduct(String tpnb, ProductVariant productVariant) {
		Product product = new Product(tpnb);
		if (promotionForProduct != null) {
			product.addPromotion(promotionForProduct);
		}
		product.addProductVariant(productVariant);
		product.setLast_updated_date(Dockyard.getSysDate("yyyyMMdd"));
		return product;
	}

}
