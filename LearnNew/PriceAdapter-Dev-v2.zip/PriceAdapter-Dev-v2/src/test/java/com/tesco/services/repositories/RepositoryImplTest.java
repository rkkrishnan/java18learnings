package com.tesco.services.repositories;

import com.couchbase.client.CouchbaseClient;
import com.couchbase.client.protocol.views.DesignDocument;
import com.couchbase.client.protocol.views.InvalidViewException;
import com.couchbase.client.protocol.views.View;
import com.couchbase.client.protocol.views.ViewDesign;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Optional;
import com.tesco.couchbase.AsyncCouchbaseWrapper;
import com.tesco.couchbase.CouchbaseWrapper;
import com.tesco.couchbase.testutils.AsyncCouchbaseWrapperStub;
import com.tesco.couchbase.testutils.BucketTool;
import com.tesco.couchbase.testutils.CouchbaseTestManager;
import com.tesco.couchbase.testutils.CouchbaseWrapperStub;
import com.tesco.services.Configuration;
import com.tesco.services.adapters.rpm.writers.impl.ProductMapper;
import com.tesco.services.core.*;
import com.tesco.services.exceptions.DataAccessException;
import com.tesco.services.exceptions.ItemNotFoundException;
import com.tesco.services.resources.TestConfiguration;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.PriceConstants;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;
import net.spy.memcached.internal.OperationFuture;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.fest.assertions.api.Fail;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.InOrder;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.slf4j.Logger;

import java.io.IOException;
import java.net.URISyntaxException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.mock;

public class RepositoryImplTest /* extends IntegrationTest */{
	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(RepositoryImplTest.class);

	private String tpnb = "123455";
	private Product product;
	private RepositoryImpl repositoryImpl;

	private CouchbaseTestManager couchbaseTestManager;
	@Mock
	private CouchbaseWrapper couchbaseWrapper;
	@Mock
	private OperationFuture<?> operationFuture;
	private Optional<Integer> absent;
	@Mock
	private AsyncCouchbaseWrapper asyncCouchbaseWrapper;
	private ObjectMapper mapper;

	private Configuration testConfiguration;
	private CouchbaseClient couchbaseClient;

	@Before
	public void setUp() throws IOException, URISyntaxException,
			InterruptedException {
		product = new Product(tpnb);

		testConfiguration = TestConfiguration.load();

		if (testConfiguration.isDummyCouchbaseMode()) {
			Map<String, ImmutablePair<Long, String>> fakeBase = new HashMap<>();
			couchbaseTestManager = new CouchbaseTestManager(
					new CouchbaseWrapperStub(fakeBase),
					new AsyncCouchbaseWrapperStub(fakeBase),
					mock(BucketTool.class));
		} else {
			couchbaseTestManager = new CouchbaseTestManager(
					testConfiguration.getCouchbaseBucket(),
					testConfiguration.getCouchbaseUsername(),
					testConfiguration.getCouchbasePassword(),
					testConfiguration.getCouchbaseNodes(),
					testConfiguration.getCouchbaseAdminUsername(),
					testConfiguration.getCouchbaseAdminPassword());
		}

		couchbaseWrapper = couchbaseTestManager.getCouchbaseWrapper();
		asyncCouchbaseWrapper = couchbaseTestManager.getAsyncCouchbaseWrapper();

		mapper = new ObjectMapper();
		repositoryImpl = new RepositoryImpl(this.couchbaseWrapper,
				asyncCouchbaseWrapper, mapper);

		absent = Optional.absent();

	}

	@Test
	public void shouldCacheProductByTPNB() throws Exception {
		product.setLast_updated_date("20140806");
		repositoryImpl.insertObject(
				PriceConstants.PRODUCT_KEY_PREFIX + product.getTPNB(), product);
		String key = PriceConstants.PRODUCT_KEY_PREFIX+tpnb;
		assertThat(repositoryImpl.getGenericObject(key,Product.class,true).get()).isEqualTo(product);
	}

	@Test
	public void shouldReturnNullObjectWhenProductIsNotFound()
			throws ItemNotFoundException, DataAccessException {
		String key = PriceConstants.PRODUCT_KEY_PREFIX+"12345";
		assertThat(repositoryImpl.getGenericObject(key,Product.class,true).isPresent()).isFalse();
	}

	@Test
	public void shouldNamespacePrefixKey() throws Exception {
		final CouchbaseWrapper couchbaseClientMock = mock(CouchbaseWrapper.class);
		repositoryImpl = new RepositoryImpl(couchbaseClientMock,
				asyncCouchbaseWrapper, mapper);
		final InOrder inOrder = inOrder(couchbaseClientMock);

		repositoryImpl.insertObject(
				PriceConstants.PRODUCT_KEY_PREFIX + product.getTPNB(), product);

		repositoryImpl.getGenericObject(
				PriceConstants.PRODUCT_KEY_PREFIX + tpnb, Product.class, true);

		String productJson = mapper.writeValueAsString(product);
		inOrder.verify(couchbaseClientMock).set("PRODUCT_" + tpnb, productJson);
		inOrder.verify(couchbaseClientMock).get("PRODUCT_" + tpnb);

	}

	@Test
	public void mapTPNCtoTPNBwithAsycCode() {
		String tpnc = "271871871";
		String tpnB = "056428171";
		repositoryImpl.mapLookUps(tpnc, tpnB);
		String mappedTPNCtoTPNB = (String) couchbaseWrapper.get(tpnc);
		mappedTPNCtoTPNB = Dockyard.replaceOldValCharWithNewVal(
				mappedTPNCtoTPNB, "\"", "");
		String mappedTPNBtoTPNC = (String) couchbaseWrapper.get(tpnB);
		mappedTPNBtoTPNC = Dockyard.replaceOldValCharWithNewVal(
				mappedTPNBtoTPNC, "\"", "");

		assertEquals(mappedTPNCtoTPNB, tpnB);
		assertEquals(mappedTPNBtoTPNC, tpnc);

	}

	/*
	 * Added by Surya for PS-114. This Junit will Delete the elements from CB -
	 * Start
	 */

	@Ignore
	@Test
	public void deleteTPNBToTPNCToVaraintDependencies() throws Exception {

		String tpnc = "271871871";
		String tpnb = "056428171";
		String variant = "056428171-001";
		String tpncForVar = "271871872";

		String variant2 = "056428171-002";
		String tpncForVar2 = "271871873";

		Product product1 = new Product(tpnb);
		ProductVariant productVariant1 = createProductVariant(tpnc, 1, "1.15",
				null);
		ProductVariant productVariant2 = createProductVariant(tpncForVar, 1,
				"1.18", null);
		ProductVariant productVariant3 = createProductVariant(tpncForVar2, 1,
				"1.19", null);

		product1.addProductVariant(productVariant1);
		product1.addProductVariant(productVariant2);
		product1.addProductVariant(productVariant3);

		/* Added for PS-368 -- Start */
		ClearanceProduct clearanceProduct;
		clearanceProduct = createClearanceProduct(tpnb);
		ClearanceMMProduct clearanceMMProduct;
		clearanceMMProduct = createClearanceMMProduct(tpnb);

		repositoryImpl = new RepositoryImpl();
		/* Added for PS-368 -- End */

		String lastUpdateDateKey = "";
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -(testConfiguration.getLastUpdatedPurgeDays()));
		lastUpdateDateKey = dateFormat.format(cal.getTime());
		product1.setLast_updated_date(lastUpdateDateKey);

		String productJson = mapper.writeValueAsString(product1);
		couchbaseClient.set(getProductKey(tpnb), productJson);

		couchbaseClient.set(tpnc, mapper.writeValueAsString(tpnb));
		couchbaseClient.set(tpnb, mapper.writeValueAsString(tpnc));

		couchbaseClient.set(tpncForVar, mapper.writeValueAsString(variant));
		couchbaseClient.set(variant, mapper.writeValueAsString(tpncForVar));

		couchbaseClient.set(tpncForVar2, mapper.writeValueAsString(variant2));
		couchbaseClient.set(variant2, mapper.writeValueAsString(tpncForVar2));

		/* Added for PS-368 -- Start */
		String productJsonForClr = mapper.writeValueAsString(clearanceProduct);
		couchbaseClient.set(getClearanceProductKey(tpnb), productJsonForClr);

		String productJsonForMM = mapper.writeValueAsString(clearanceMMProduct);
		couchbaseClient.set(getClearanceMMProductKey(tpnb), productJsonForMM);
		/* Added for PS-368 -- End */

		checkforView(couchbaseClient, testConfiguration);

		repositoryImpl.purgeUnUpdatedItems(couchbaseClient,
				testConfiguration);

		/*
		 * assertNull function checks if the object is null; In this case if the
		 * object is null then the document is deleted and the test passes
		 */

		assertNull(repositoryImpl.getMappedTPNCorTPNBWithCouchBaseClient(
				tpnc, couchbaseClient));
		assertNull(repositoryImpl.getMappedTPNCorTPNBWithCouchBaseClient(
				tpnb, couchbaseClient));
		assertNull(repositoryImpl.getMappedTPNCorTPNBWithCouchBaseClient(
				tpncForVar, couchbaseClient));
		assertNull(repositoryImpl.getMappedTPNCorTPNBWithCouchBaseClient(
				variant, couchbaseClient));
		assertNull(repositoryImpl.getMappedTPNCorTPNBWithCouchBaseClient(
				tpncForVar2, couchbaseClient));
		assertNull(repositoryImpl.getMappedTPNCorTPNBWithCouchBaseClient(
				variant2, couchbaseClient));

	}

	private ProductVariant createProductVariant(String tpnc, int zoneId,
			String price, Promotion promotion) {
		ProductVariant productVariant = new ProductVariant(tpnc);
		SaleInfo saleInfo = new SaleInfo(zoneId, price);
		productVariant.addSaleInfo(saleInfo);
		return productVariant;
	}

	private String getProductKey(String tpnb) {
		return String.format("PRODUCT_%s", tpnb);
	}

	/*
	 * Added by Surya for PS-114. This Junit will Delete the elements from CB -
	 * End
	 */
	/* Added by Surya for View check to avoid Junit Failures - Start */
	private void createView(Configuration configuration,
			CouchbaseClient couchbaseClient) throws Exception {
		final DesignDocument designDoc = new DesignDocument(
				configuration.getCouchBaseDesignDocName());
		designDoc
				.setView(new ViewDesign(
						configuration.getCouchBaseViewName(),
						"function (doc, meta) {\n"
								+ "  if (doc.last_updated_date && meta.type == \"json\" ) {\n"
								+ "    emit(doc.last_updated_date, {KEY: meta.id});\n"
								+ "  }\n" + "}"));

		couchbaseClient.createDesignDoc(designDoc);
	}

	public void checkforView(CouchbaseClient couchbaseClient,
			Configuration configuration) throws Exception {
		try {
			View view = couchbaseClient.getView(
					configuration.getCouchBaseDesignDocName(),
					configuration.getCouchBaseViewName());
		} catch (InvalidViewException e) {
			createView(configuration, couchbaseClient);
			Thread.sleep(50);
		}
	}

	/* Added by Surya for View check to avoid Junit Failures - End */

	/* Added for PS-368 -- Start */
	private ClearanceProduct createClearanceProduct(String productId) {
		ClearanceProduct clearanceProduct = new ClearanceProduct(productId);
		String docType = "datedPrice";
		String dateTimeFormat = "ISO8601";
		String countryFormat = "ISO3166";
		String currencyFormat = "ISO4217";
		String version = "1.0";
		String prodType = "tpnb";
		String sellingUom = "EA";
		clearanceProduct.setVersionNo(version);
		clearanceProduct.setDocType(docType);
		clearanceProduct.setCountryFormat(countryFormat);
		clearanceProduct.setCurrencyFormat(currencyFormat);
		clearanceProduct.setDateTimeFormat(dateTimeFormat);
		clearanceProduct.setProdType(prodType);
		clearanceProduct.setSellingUom(sellingUom);

		return clearanceProduct;
	}

	private String getClearanceProductKey(String tpnb) {
		return String.format("CLRPROD_%s", tpnb);
	}

	private String getClearanceMMProductKey(String tpnb) {
		return String.format("CLRMMPROD_%s", tpnb);
	}

	private ClearanceMMProduct createClearanceMMProduct(String productId) {
		ClearanceMMProduct clearanceMMProduct = new ClearanceMMProduct(
				productId);
		String docType = "datedPrice";
		String dateTimeFormat = "ISO8601";
		String countryFormat = "ISO3166";
		String currencyFormat = "ISO4217";
		String version = "1.0";
		String prodType = "tpnb";
		String sellingUom = "EA";
		clearanceMMProduct.setVersionNo(version);
		clearanceMMProduct.setDocType(docType);
		clearanceMMProduct.setCountryFormat(countryFormat);
		clearanceMMProduct.setCurrencyFormat(currencyFormat);
		clearanceMMProduct.setDateTimeFormat(dateTimeFormat);
		clearanceMMProduct.setProdType(prodType);
		clearanceMMProduct.setSellingUom(sellingUom);

		return clearanceMMProduct;
	}

	/* Added for PS-368 -- End */
	@Test
	public void testGetProductTPNC() {

		String tpnc = "234567899";
		String tpnb = "051234567";
		repositoryImpl.mapLookUps(tpnc, tpnb);
		assertEquals(repositoryImpl.getMappedData(tpnb), tpnc);
	}

	@Test
	public void testGetObjectException() throws IOException {
		String tpnb = "050000018";
		couchbaseWrapper.set(PriceConstants.PRODUCT_TPNB_KEY + ":" + tpnb,
				"junk data");
		try {
			ItemDefaultUomSubEntity itemDefaultUomSubEntity = (ItemDefaultUomSubEntity) repositoryImpl
					.getGenericObject(
							PriceConstants.PRODUCT_TPNB_KEY + ":" + tpnb,
							ItemDefaultUomSubEntity.class);
			Fail.fail("Should throw error");
		} catch (Exception e) {
			assertThat(true);
		}
	}

	@Ignore
	public void testgetByTPNBWithCouchBaseClientException() throws IOException {
		ObjectMapper mockMapper = mock(ObjectMapper.class);
		CouchbaseWrapper mockCouchbaseWrapper = mock(CouchbaseWrapper.class);
		RepositoryImpl productRep = new RepositoryImpl(
				mockCouchbaseWrapper, asyncCouchbaseWrapper, mockMapper);

		Product mockProduct = mock(Product.class);
		Mockito.doReturn(" ").when(mockProduct).toString();

		Mockito.doReturn(mockProduct.toString()).when(mockCouchbaseWrapper)
				.get(Matchers.anyString());

		try {

			Mockito.doThrow(IOException.class)
					.when(mockMapper)
					.readValue(Matchers.anyString(),
							(Class<Product>) Matchers.any());
			productRep.getByTPNBWithCouchBaseClient("050000016",
					couchbaseClient);

		} catch (IOException e) {
			assertThat(e.getMessage().equals("java.io.IOException"));
		}
	}


	@Test
	public void testPutProductException() throws Exception {
		Product mockProduct = mock(Product.class);
		ObjectMapper mockMapper = mock(ObjectMapper.class);

		Mockito.doReturn(new String(" ")).when(mockProduct).getTPNB();

		RepositoryImpl productRep = new RepositoryImpl(couchbaseWrapper,
				asyncCouchbaseWrapper, mockMapper);

		try {

			Mockito.doThrow(JsonProcessingException.class).when(mockMapper)
					.writeValueAsString(mockProduct);
			productRep.insertObject(PriceConstants.PRODUCT_KEY_PREFIX + mockProduct.getTPNB(),mockProduct);

		} catch (JsonProcessingException e) {
			assertThat(e.getMessage().equals("java.io.IOException"));
		}
	}

	@Test
	public void testgetByTPNBException() throws IOException,
			DataAccessException {
		ObjectMapper mockMapper = mock(ObjectMapper.class);
		CouchbaseWrapper mockCouchbaseWrapper = mock(CouchbaseWrapper.class);
		RepositoryImpl productRep = new RepositoryImpl(
				mockCouchbaseWrapper, asyncCouchbaseWrapper, mockMapper);

		Product mockProduct = mock(Product.class);
		Mockito.doReturn(" ").when(mockProduct).toString();

		Mockito.doReturn(mockProduct.toString()).when(mockCouchbaseWrapper)
				.get(Matchers.anyString());

		try {
			Mockito.doThrow(new IOException("java.io.IOException"))
					.when(mockMapper)
					.readValue(Matchers.anyString(),
							(Class<Product>) Matchers.any());
			productRep.getGenericObject(
					PriceConstants.PRODUCT_KEY_PREFIX + "050000016",
					Product.class,true);
			fail("suppose to fail");
		} catch (DataAccessException e) {
			assertThat(e.getMessage().equals("java.io.IOException"));
		}

	}

}
