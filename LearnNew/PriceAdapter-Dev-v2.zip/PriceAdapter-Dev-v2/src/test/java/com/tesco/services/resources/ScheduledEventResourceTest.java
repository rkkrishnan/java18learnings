package com.tesco.services.resources;

import static com.tesco.services.utility.PriceConstants.CLEARANCE_END_EVENT_TYPE;
import static com.tesco.services.utility.PriceConstants.SUCCESS_MESSAGE;
import static com.tesco.services.utility.PriceConstants.SUCCESS_MESSAGE_CLEARANCE_END;
import static com.tesco.services.utility.PriceConstants.SUCCESS_MESSAGE_CLEARANCE_START;
import static com.tesco.services.utility.PriceConstants.SUCCESS_MESSAGE_PROMOTION_END;
import static com.tesco.services.utility.PriceConstants.SUCCESS_MESSAGE_PROMOTION_START;
import static com.tesco.services.utility.sl4j.LoggerFactoryWrapper.getLogger;
import static org.fest.assertions.api.Assertions.assertThat;
import io.dropwizard.testing.junit.ResourceTestRule;

import java.util.concurrent.Semaphore;

import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

import org.junit.After;
import org.junit.ClassRule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.slf4j.Logger;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.ClearanceScheduledEventJob;
import com.tesco.services.adapters.core.PriceChangeScheduledEventJob;
import com.tesco.services.adapters.core.PromotionScheduledEventJob;
import com.tesco.services.adapters.price.PriceEventHandler;
import com.tesco.services.adapters.promotion.PromotionEventHandler;
import com.tesco.services.event.core.EventTemplate;
import com.tesco.services.utility.PriceConstants;

@RunWith(MockitoJUnitRunner.class)
public class ScheduledEventResourceTest {

	private static Configuration testConfiguration = TestConfiguration.load();;
	@Mock
	private static ObjectMapper jsonMapper;
	@Mock
	private static PriceEventHandler priceEventHandler;
	@Mock
	private static PromotionEventHandler promotionEventHandler;
	@Mock
	private PromotionScheduledEventJob promotionScheduledEventJob;
	@Mock
	private PriceChangeScheduledEventJob priceChangeEventJob;
	@Mock
	private ClearanceScheduledEventJob clearanceScheduledEventJob;
	@Mock
	private static EventTemplate eventTemplate;

	@ClassRule
	public static final ResourceTestRule resources = ResourceTestRule
			.builder()
			.addResource(
					new ScheduledEventResource(testConfiguration, jsonMapper,
							priceEventHandler, promotionEventHandler,
							eventTemplate)).build();

	static private Logger LOGGER = getLogger(ScheduledEventResourceTest.class);

	@Test
	public void shouldGetTheStatusOfScheduledJobForClearanceEnd() {
		WebTarget resource = resources.client().target(
				"/scheduledEventAdmin/publishClearanceEndEvent");
		Response response = resource.request().get();
		String responseText = response.readEntity(String.class);
		LOGGER.info("Response text :{}", responseText);
		assertThat(responseText).isEqualTo(SUCCESS_MESSAGE_CLEARANCE_END);
		assertThat(response.getStatus()).isEqualTo(200);
	}

	@Test
	public void shouldGetTheInProgressStatusOfScheduledJobForClearanceEnd() {
		Semaphore semaphore = Mockito.mock(Semaphore.class);
		Mockito.when(semaphore.availablePermits()).thenReturn(0);
		ScheduledEventResource.addScheduledEventSemaphore(
				PriceConstants.CLEARANCE_END_EVENT_TYPE, semaphore);
		WebTarget resource = resources.client().target(
				"/scheduledEventAdmin/scheduledEventJobStatus/ClearanceEnd");
		Response response = resource.request().get();
		String responseText = response.readEntity(String.class);
		LOGGER.info("Response text :{}", responseText);
		assertThat(responseText).isEqualTo(
				PriceConstants.INPROGRES_MESSAGE_SCHEDULED_JOB);
		assertThat(response.getStatus()).isEqualTo(200);
		ScheduledEventResource
				.removeScheduledEventSemaphore(CLEARANCE_END_EVENT_TYPE);
	}

	@Test
	public void shouldGetTheErrorStatusOfScheduledJobForClearanceEnd() {
		Semaphore semaphore = Mockito.mock(Semaphore.class);
		Mockito.when(semaphore.availablePermits()).thenReturn(1);
		ScheduledEventResource.addScheduledEventSemaphore(
				CLEARANCE_END_EVENT_TYPE, semaphore);
		ScheduledEventResource
				.setErrorString(CLEARANCE_END_EVENT_TYPE,
						"Error while processing scheduled events of type[ClearanceEnd]...");
		WebTarget resource = resources.client().target(
				"/scheduledEventAdmin/scheduledEventJobStatus/ClearanceEnd");
		Response response = resource.request().get();
		String responseText = response.readEntity(String.class);
		LOGGER.info("Response text :{}", responseText);
		assertThat(responseText).isEqualTo(
				PriceConstants.ERROR_MESSAGE_CLEARANCE_END_SCHEDULED_JOB);
		assertThat(response.getStatus()).isEqualTo(200);
		ScheduledEventResource
				.removeScheduledEventSemaphore(CLEARANCE_END_EVENT_TYPE);
	}

	@Test
	public void shouldGetTheNoProcessStatusOfScheduledJobForClearanceEnd() {
		ScheduledEventResource
				.removeScheduledEventSemaphore(CLEARANCE_END_EVENT_TYPE);
		WebTarget resource = resources.client().target(
				"/scheduledEventAdmin/scheduledEventJobStatus/ClearanceEnd");
		Response response = resource.request().get();
		String responseText = response.readEntity(String.class);
		LOGGER.info("Response text :{}", responseText);
		assertThat(responseText).isEqualTo(
				PriceConstants.NO_PROCESS_MESSAGE_SCHEDULED_JOB);
		assertThat(response.getStatus()).isEqualTo(200);

	}

	@Test
	public void shouldGetTheStatusOfScheduledJobForPriceChange() {
		WebTarget resource = resources.client().target(
				"/scheduledEventAdmin/publishPriceChangeEvent");
		Response response = resource.request().get();
		String responseText = response.readEntity(String.class);
		LOGGER.info("Response text :{}", responseText);
		assertThat(responseText).isEqualTo(SUCCESS_MESSAGE);
		assertThat(response.getStatus()).isEqualTo(200);
	}

	@Test
	public void shouldGetTheStatusOfScheduledJobForPromotionStart() {
		WebTarget resource = resources.client().target(
				"/scheduledEventAdmin/publishZoneLevelPromotionStart");
		Response response = resource.request().get();
		String responseText = response.readEntity(String.class);
		LOGGER.info("Response text :{}", responseText);
		assertThat(responseText).isEqualTo(SUCCESS_MESSAGE_PROMOTION_START);
		assertThat(response.getStatus()).isEqualTo(200);
	}

	@Test
	public void shouldGetTheStatusOfScheduledJobForPromotionEnd() {
		WebTarget resource = resources.client().target(
				"/scheduledEventAdmin/publishZoneLevelPromotionEnd");
		Response response = resource.request().get();
		String responseText = response.readEntity(String.class);
		LOGGER.info("Response text :{}", responseText);
		assertThat(responseText).isEqualTo(SUCCESS_MESSAGE_PROMOTION_END);
		assertThat(response.getStatus()).isEqualTo(200);
	}

	@Test
	public void shouldGetTheStatusOfScheduledJobForPromotionStartProduct() {
		WebTarget resource = resources.client().target(
				"/scheduledEventAdmin/publishPromotionStartProduct");
		Response response = resource.request().get();
		String responseText = response.readEntity(String.class);
		LOGGER.info("Response text :{}", responseText);
		assertThat(responseText).isEqualTo(SUCCESS_MESSAGE);
		assertThat(response.getStatus()).isEqualTo(200);
	}

	@Test
	public void shouldGetTheStatusOfScheduledJobForClearanceStart() {
		WebTarget resource = resources.client().target(
				"/scheduledEventAdmin/publishClearanceStartEvent");
		Response response = resource.request().get();
		String responseText = response.readEntity(String.class);
		LOGGER.info("Response text :{}", responseText);
		assertThat(responseText).isEqualTo(SUCCESS_MESSAGE_CLEARANCE_START);
		assertThat(response.getStatus()).isEqualTo(200);
	}

	@After
	public void resetMocks() throws Exception {
		Mockito.reset(priceChangeEventJob);
		Mockito.reset(promotionScheduledEventJob);
		Mockito.reset(jsonMapper);
	}

}
