package com.tesco.services.adapters.rpm.writers;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Semaphore;

import com.tesco.services.adapters.rpm.writers.impl.ItemDefaultUomWriter;
import com.tesco.services.repositories.RepositoryImpl;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.fest.assertions.api.Fail;
import org.glassfish.hk2.api.ServiceLocator;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tesco.couchbase.AsyncCouchbaseWrapper;
import com.tesco.couchbase.CouchbaseWrapper;
import com.tesco.couchbase.testutils.AsyncCouchbaseWrapperStub;
import com.tesco.couchbase.testutils.BucketTool;
import com.tesco.couchbase.testutils.CouchbaseTestManager;
import com.tesco.couchbase.testutils.CouchbaseWrapperStub;
import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.exceptions.ColumnNotFoundException;
import com.tesco.services.adapters.rpm.readers.PriceServiceCSVReader;
import com.tesco.services.core.ItemDefaultUomSubEntity;
import com.tesco.services.resources.ImportResource;
import com.tesco.services.resources.TestConfiguration;
import com.tesco.services.utility.PriceConstants;

@RunWith(MockitoJUnitRunner.class)
public class ItemDefaultUomWriterTest {

	public RepositoryImpl repositoryImpl;

	public AsyncCouchbaseWrapper asyncCouchbaseWrapper;

	public CouchbaseWrapper couchbaseWrapper;
	private Configuration testConfiguration = TestConfiguration.load();

	private CouchbaseTestManager couchbaseTestManager;

	public ObjectMapper mapper;

	@Mock
	private PriceServiceCSVReader itemDfltReader;

	ItemDefaultUomWriter itemDefaultUomWriter;

	String runIdentifier = PriceConstants.ITEM_DEFAULT_UOM_RUNIDENTIFIER;
	String fileName = PriceConstants.ITEM_DFLT_UOM_FILENAME;
	String tpnb = "050000650";
	String sellByType = "I";
	String defaultUOM = "EACH";
	@Mock
	public ServiceLocator serviceLocator;

	@Before
	public void setUp() throws IOException, URISyntaxException,
			InterruptedException, ColumnNotFoundException {

		testConfiguration = TestConfiguration.load();
		mapper = new ObjectMapper();
		if (testConfiguration.isDummyCouchbaseMode()) {
			Map<String, ImmutablePair<Long, String>> fakeBase = new HashMap<>();
			couchbaseTestManager = new CouchbaseTestManager(
					new CouchbaseWrapperStub(fakeBase),
					new AsyncCouchbaseWrapperStub(fakeBase),
					mock(BucketTool.class));
		} else {
			couchbaseTestManager = new CouchbaseTestManager(
					testConfiguration.getCouchbaseBucket(),
					testConfiguration.getCouchbaseUsername(),
					testConfiguration.getCouchbasePassword(),
					testConfiguration.getCouchbaseNodes(),
					testConfiguration.getCouchbaseAdminUsername(),
					testConfiguration.getCouchbaseAdminPassword());
		}
		couchbaseWrapper = couchbaseTestManager.getCouchbaseWrapper();
		asyncCouchbaseWrapper = couchbaseTestManager.getAsyncCouchbaseWrapper();

		Mockito.when(
				serviceLocator.getService(AsyncCouchbaseWrapper.class,
						"asyncCouchbaseWrapper")).thenReturn(
				asyncCouchbaseWrapper);
		Mockito.when(
				serviceLocator.getService(CouchbaseWrapper.class,
						"couchbaseWrapper")).thenReturn(couchbaseWrapper);
		Mockito.when(
				serviceLocator.getService(ObjectMapper.class, "jsonmapper"))
				.thenReturn(mapper);

		repositoryImpl = new RepositoryImpl(couchbaseWrapper,
				asyncCouchbaseWrapper, new ObjectMapper());
		itemDefaultUomWriter = new ItemDefaultUomWriter(testConfiguration,
				repositoryImpl,itemDfltReader);
		itemDefaultUomWriter.setRunIdentifier(runIdentifier);

	}

	@Test
	public void readAndWriteItemDefaultData() throws Exception {

		Map<String, String> itemDefaultMapping = returnRpmUomWriterMap(tpnb,
				sellByType,
				defaultUOM);

		when(itemDfltReader.getNext()).thenReturn(itemDefaultMapping)
				.thenReturn(null);
		ImportResource.importSemaphoreForIdentifier
				.put(fileName, new Semaphore(1));

		this.itemDefaultUomWriter.write(fileName);

		ItemDefaultUomSubEntity expectedEntity = (ItemDefaultUomSubEntity) repositoryImpl
				.getGenericObject(PriceConstants.PRODUCT_TPNB_KEY + ":" + tpnb,
						ItemDefaultUomSubEntity.class);

		assertThat(expectedEntity.getProdRef())
				.isEqualTo(PriceConstants.TPNB_IDENTIFIER + ":" + tpnb);
		assertThat(expectedEntity.getSellByType())
				.isEqualToIgnoringCase(sellByType);
		assertThat(expectedEntity.getDefaultUOM())
				.isEqualToIgnoringCase(defaultUOM);
		assertThat(expectedEntity.getLastUpdatedById())
				.isEqualTo(PriceConstants.ITEM_DFLT_UPDATED_BY);

	}

	@Test
	public void readAndWriteSubGroupDefaultDataForNullTpnbUOM()
			throws Exception {
		tpnb = "";
		Map<String, String> itemWritergMap = returnRpmUomWriterMap(tpnb,
				sellByType,
				defaultUOM);

		when(itemDfltReader.getNext()).thenReturn(itemWritergMap)
				.thenReturn(null);
		ImportResource.importSemaphoreForIdentifier
				.put(fileName, new Semaphore(1));

		this.itemDefaultUomWriter.write(fileName);

		ItemDefaultUomSubEntity expectedEntity = (ItemDefaultUomSubEntity) repositoryImpl
				.getGenericObject(PriceConstants.PRODUCT_TPNB_KEY + ":" + tpnb,
						ItemDefaultUomSubEntity.class);

		assertThat(expectedEntity).isNull();
	}

	@Test
	public void readAndWriteSubGroupDefaultDataForNullSellByType()
			throws Exception {
		sellByType = "";
		Map<String, String> itemWritergMap = returnRpmUomWriterMap(tpnb,
				sellByType,
				defaultUOM);

		when(itemDfltReader.getNext()).thenReturn(itemWritergMap)
				.thenReturn(null);
		ImportResource.importSemaphoreForIdentifier
				.put(fileName, new Semaphore(1));

		this.itemDefaultUomWriter.write(fileName);

		ItemDefaultUomSubEntity expectedEntity = (ItemDefaultUomSubEntity) repositoryImpl
				.getGenericObject(PriceConstants.PRODUCT_TPNB_KEY + ":" + tpnb,
						ItemDefaultUomSubEntity.class);

		assertThat(expectedEntity).isNull();
	}

	@Test
	public void readAndWriteSubGroupDefaultDataForInvalidSellByType()
			throws Exception {
		sellByType = "W";
		Map<String, String> itemWritergMap = returnRpmUomWriterMap(tpnb,
				sellByType,
				defaultUOM);

		when(itemDfltReader.getNext()).thenReturn(itemWritergMap)
				.thenReturn(null);
		ImportResource.importSemaphoreForIdentifier
				.put(fileName, new Semaphore(1));

		this.itemDefaultUomWriter.write(fileName);

		ItemDefaultUomSubEntity expectedEntity = (ItemDefaultUomSubEntity) repositoryImpl
				.getGenericObject(PriceConstants.PRODUCT_TPNB_KEY + ":" + tpnb,
						ItemDefaultUomSubEntity.class);

		assertThat(expectedEntity).isNull();
	}

	@Test
	public void readAndWriteSubGroupDefaultDataForNullDefaultUom()
			throws Exception {
		defaultUOM = "";
		Map<String, String> itemWritergMap = returnRpmUomWriterMap(tpnb,
				sellByType,
				defaultUOM);

		when(itemDfltReader.getNext()).thenReturn(itemWritergMap)
				.thenReturn(null);
		ImportResource.importSemaphoreForIdentifier
				.put(fileName, new Semaphore(1));

		this.itemDefaultUomWriter.write(fileName);

		ItemDefaultUomSubEntity expectedEntity = (ItemDefaultUomSubEntity) repositoryImpl
				.getGenericObject(PriceConstants.PRODUCT_TPNB_KEY + ":" + tpnb,
						ItemDefaultUomSubEntity.class);

		assertThat(expectedEntity.getProdRef())
				.isEqualTo(PriceConstants.TPNB_IDENTIFIER + ":" + tpnb);
		assertThat(expectedEntity.getSellByType())
				.isEqualToIgnoringCase(sellByType);
		assertThat(expectedEntity.getDefaultUOM()).isNull();
		assertThat(expectedEntity.getLastUpdatedById())
				.isEqualTo(PriceConstants.ITEM_DFLT_UPDATED_BY);
	}

	private Map<String, String> returnRpmUomWriterMap(String tpnb,
			String sellByType,
			String defaultUOM
	) {
		Map<String, String> itemDfltUomWriterMap = new HashMap<>();
		itemDfltUomWriterMap
				.put(CSVHeaders.ItemDefaultUOMHeaders.TPNB, tpnb);
		itemDfltUomWriterMap.put(CSVHeaders.ItemDefaultUOMHeaders.SELL_BY_TYPE,
				sellByType);
		itemDfltUomWriterMap.put(CSVHeaders.ItemDefaultUOMHeaders.DEFAULT_UOM,
				defaultUOM);
		return itemDfltUomWriterMap;
	}


	@Test public void readAndWriteItemDefaultDataIOException()
			throws Exception {

		Map<String, String> itemDefaultMapping = returnRpmUomWriterMap(tpnb,
				sellByType, defaultUOM);
		ImportResource.importSemaphoreForIdentifier
				.put(fileName, new Semaphore(1));

		when(itemDfltReader.getNext())
				.thenThrow(new IOException("Exception", new Exception()))
				.thenReturn(null);

		try {
			this.itemDefaultUomWriter.write(fileName);

			Fail.fail("suppose to fail");
		} catch (Exception e) {
			assertThat(e.getMessage()).contains("Exception");
		}

	}

	@Test
	public void readAndWriteItemDefaultDataExceptionInSyncInsertion() throws Exception {

		Map<String, String> itemDefaultMapping = returnRpmUomWriterMap(tpnb,
				sellByType,
				defaultUOM);
		ImportResource.importSemaphoreForIdentifier
				.put(fileName, new Semaphore(1));

		when(itemDfltReader.getNext()).thenReturn(itemDefaultMapping)
				.thenReturn(null);

		RepositoryImpl repositoryImpl = Mockito
				.mock(RepositoryImpl.class);
		doThrow(new Exception("Exception")).when(repositoryImpl)
				.insertObject(anyString(), anyObject());
		itemDefaultUomWriter.setRepository(repositoryImpl);
		this.itemDefaultUomWriter.write(fileName);

		ItemDefaultUomSubEntity expectedEntity = (ItemDefaultUomSubEntity) repositoryImpl
				.getGenericObject(PriceConstants.PRODUCT_TPNB_KEY + ":" + tpnb,
						ItemDefaultUomSubEntity.class);

		assertThat(expectedEntity).isNull();

	}
}
