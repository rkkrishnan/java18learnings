package com.tesco.services.resources;

import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.ImportEanJob;
import com.tesco.services.adapters.core.PriceComparatorJob;
import io.dropwizard.testing.junit.ResourceTestRule;
import org.junit.ClassRule;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;

import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import static org.fest.assertions.api.Assertions.assertThat;

public class TeauthPriceChecksResourseExpectionTest {

    private static Configuration testConfiguration = TestConfiguration.load();

	private static ImportEanJob mockImportEanJob = Mockito.mock(ImportEanJob.class);
    private static PriceComparatorJob mockPriceComparatorJob = Mockito.mock(PriceComparatorJob.class);

    String runType = "uk";
    String fileName = "fileName";

    @ClassRule
    public static final ResourceTestRule resources = ResourceTestRule.builder()
            .addResource(new TeauthPriceChecksResource(testConfiguration,
					mockImportEanJob, mockPriceComparatorJob)).build();


    @Test
    public void shouldReturnFileNotFoundException() throws Exception {


        WebTarget resourceTarget = resources.client().target(
                "/teauth/comparePrice/"+runType+"/"+fileName);

        Response response = resourceTarget.request()
                .accept(MediaType.APPLICATION_JSON)
                .post(Entity.entity("", MediaType.APPLICATION_JSON));

        String responseText = response.readEntity(String.class);
        assertThat(responseText).isEqualTo("{\"message\":\"Price Comparison Job Started.\"}");
        assertThat(response.getStatus()).isEqualTo(200);
//        Thread.sleep(4000);
//        assertThat(TeauthPriceChecksResource.getErrorString(fileName)).isEqualTo("File Not found : " +fileName);

    }

}
