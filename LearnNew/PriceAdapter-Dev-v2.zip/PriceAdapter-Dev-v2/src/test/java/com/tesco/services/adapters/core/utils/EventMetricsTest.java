package com.tesco.services.adapters.core.utils;

import static org.junit.Assert.assertNotEquals;

import java.util.Map;

import org.junit.After;
import org.junit.BeforeClass;
import org.junit.Test;

import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.Timer;
import com.tesco.services.utility.PriceConstants;

public class EventMetricsTest {

	static EventMetrics eventMetrics = null;
	static MetricRegistry mmetricRegisty = null;
	Map metricsMap = null;

	@BeforeClass
	public static void setUp() throws Exception {
		eventMetrics = EventMetrics.getInstance();
		mmetricRegisty = EventMetrics.getMetricsRegistry();

	}

	@After
	public void tearDown() throws Exception {

	}

	@Test
	public void logMessageProcessingStartTime() throws Exception {
		String eventType = PriceConstants.FUTURE_PRICE_MSG_TYPE_CRE;
		metricsMap = mmetricRegisty.getTimers();

		String name = MetricRegistry.name("com.tesco",
				"EventsElapsedTimeAndRate",
				"time-to-process-priceChanged-event");

		System.out.println(((Timer) metricsMap.get(name)).getCount());
		eventMetrics.logEventStartTime(eventType);
		eventMetrics.logEventEndTime(eventType);
		System.out.println(((Timer) metricsMap.get(name)).getCount());
		assertNotEquals(0, ((Timer) metricsMap.get(name)).getCount());

	}
}
