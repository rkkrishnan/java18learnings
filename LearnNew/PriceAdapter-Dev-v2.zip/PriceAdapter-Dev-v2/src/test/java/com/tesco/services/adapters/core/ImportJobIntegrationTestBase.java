package com.tesco.services.adapters.core;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tesco.couchbase.AsyncCouchbaseWrapper;
import com.tesco.couchbase.CouchbaseWrapper;
import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.exceptions.WriterBusinessException;
import com.tesco.services.adapters.rpm.writers.impl.*;
import com.tesco.services.repositories.RepositoryImpl;
import com.tesco.services.resources.ImportResource;
import com.tesco.services.resources.PromotionResource;
import com.tesco.services.utility.WebServiceCallBuilder;
import org.junit.After;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.io.IOException;
import java.util.HashMap;
import java.util.concurrent.Semaphore;

import static org.fest.assertions.api.Assertions.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class ImportJobIntegrationTestBase /* extends IntegrationTest */{

	@Mock
	private Configuration mockConfiguration;
	@Mock
	private CouchbaseWrapper couchbaseWrapper;
	@Mock
	private AsyncCouchbaseWrapper asyncCouchbaseWrapper;
	@Mock
	RPMWriter mockRPMWriter;
	@Mock
	MMWriter mmWriter;
	@Mock
	RPMClearanceWriter rpmClearanceWriter;
	@Mock
	RPMZoneGroupWriter rpmZoneGroupWriter;
	@Mock
	PromotionWriter promotionWriter;

	@Mock
	PriceWriter priceWriter;
	@Mock
	RPMSubGroupDfltUomMapper rpmSubGroupDfltUomMapper;
	@Mock
	WebServiceCallBuilder webServiceCallBuilder;

	@Mock
	RepositoryImpl repositoryImpl;

	@Mock
	RPMZoneWriter rpmZoneWriter;

	ObjectMapper objectMapper;

	@Mock
	EstablishedPriceWritter establishedPriceWritter;

	@Mock
	FutureOfferDescWritter futureOfferDescWritter;

	@Test
	public void testImportJobRun() throws WriterBusinessException {

		Mockito.doNothing().when(mockRPMWriter).write(null);

		ImportJob importJob = new ImportJob(mockRPMWriter);
		importJob.run();
		assertThat(true).isEqualTo(true);
		objectMapper = new ObjectMapper();
	}

	@Test
	public void testImportJobAIOBException() throws WriterBusinessException {

		Mockito.doThrow(new ArrayIndexOutOfBoundsException())
				.when(mockRPMWriter).write(null);

		ImportJob importJob = new ImportJob(mockRPMWriter);
		importJob.run();
		assertThat("Array index out of bound Exception").isEqualTo(
				ImportJob.getErrorString());
	}

	@Test
	public void testImportJobException() throws WriterBusinessException {

		Mockito.doThrow(new WriterBusinessException()).when(mockRPMWriter)
				.write(null);

		ImportJob importJob = new ImportJob(mockRPMWriter);
		importJob.run();
		assertThat("Import exception occured").isEqualTo(
				ImportJob.getErrorString());
	}

	@Test
	public void testImportMMJobRun() throws WriterBusinessException {

		String runIdentifier = "mmreg";
		Mockito.doNothing().when(mmWriter).write(null);
		Mockito.doReturn("src/main/resources/com/tesco/services/adapters/mm")
				.when(mockConfiguration).getMmClrFilePath();
		Mockito.doReturn("MM_CLR_DATA.dat").when(mockConfiguration)
				.getMmClrFileName();
		ImportResource.importSemaphoreForIdentifier = new HashMap();
		ImportResource.importSemaphoreForIdentifier.put(runIdentifier,
				new Semaphore(1));
		ImportMMJob importMMJob = new ImportMMJob(mmWriter);
		importMMJob.setRunIdentifier(runIdentifier);
		importMMJob.run();
		assertThat(true).isEqualTo(true);
	}

	@Test
	public void testImportMMJobException() throws WriterBusinessException {

		String runIdentifier = "mmreg";

		Mockito.doThrow(new WriterBusinessException()).when(mmWriter)
				.write(null);
		ImportResource.importSemaphoreForIdentifier = new HashMap();
		ImportResource.importSemaphoreForIdentifier.put(runIdentifier,
				new Semaphore(1));
		ImportMMJob importMMJob = new ImportMMJob(mmWriter);
		importMMJob.setRunIdentifier(runIdentifier);
		importMMJob.run();
		assertThat("error importing MM data").isEqualTo(
				ImportResource.getErrorString(runIdentifier));
	}

	@Test
	public void testImportRPMClearanceJobRun() throws WriterBusinessException {
		String runIdentifier = "acayg";
		Mockito.doNothing().when(rpmClearanceWriter).write(null);
		Mockito.doReturn(
				"src/main/resources/com/tesco/services/adapters/rpmclearance")
				.when(mockConfiguration).getRpmClrDataDumpPath();
		ImportResource.importSemaphoreForIdentifier = new HashMap();
		ImportResource.importSemaphoreForIdentifier.put(runIdentifier,
				new Semaphore(1));
		ImportRPMClearanceJob importRPMClearanceJob = new ImportRPMClearanceJob(
				rpmClearanceWriter);
		importRPMClearanceJob.setRunIdentifier(runIdentifier);
		// System.out.println("not null");
		importRPMClearanceJob.run();
		assertThat(true).isEqualTo(true);
	}

	@Test
	public void testImportRPMClearanceJobException()
			throws WriterBusinessException {

		String runIdentifier = "acayg";
		Mockito.doThrow(new WriterBusinessException()).when(rpmClearanceWriter)
				.write(null);
		ImportResource.importSemaphoreForIdentifier = new HashMap();
		ImportResource.importSemaphoreForIdentifier.put(runIdentifier,
				new Semaphore(1));
		ImportRPMClearanceJob importRPMClearanceJob = new ImportRPMClearanceJob(
				rpmClearanceWriter);
		importRPMClearanceJob.setRunIdentifier(runIdentifier);
		importRPMClearanceJob.run();
		assertThat("Error importing RPM Clearance data").isEqualTo(
				ImportResource.getErrorString(runIdentifier));
	}

	@Test
	public void testImportRPMZoneJobRun() throws Exception {

		String fileName = "tsl_rpm_zone_onetime.csv";
		Mockito.doNothing().when(rpmZoneWriter).write(fileName);
		Mockito.doReturn(
				"src/main/resources/com/tesco/services/adapters/rpmzone")
				.when(mockConfiguration).getRpmZoneDataDump();

		Mockito.doReturn(fileName).when(mockConfiguration).getRpmZoneDataDump();

		ImportResource.importSemaphoreForIdentifier.put(fileName,
				new Semaphore(1));

		ImportRPMZoneJob importRPMZoneJob = new ImportRPMZoneJob(rpmZoneWriter);
		importRPMZoneJob.setFileName(fileName);
		importRPMZoneJob.run();
		assertThat(true).isEqualTo(true);
	}

	@Test
	public void testImportRPMZoneJobException() throws Exception {

		String fileName = "tsl_rpm_zone_onetime.csv";
		Mockito.doThrow(new WriterBusinessException()).when(rpmZoneWriter)
				.write(fileName);
		ImportResource.importSemaphoreForIdentifier.put(fileName,
				new Semaphore(1));
		ImportRPMZoneJob importRPMZoneJob = new ImportRPMZoneJob(rpmZoneWriter);
		importRPMZoneJob.setFileName(fileName);
		importRPMZoneJob.run();
		assertThat("Error importing Onetime RPM Zone data..").isEqualTo(
				ImportResource.getErrorString(fileName));
	}

	@Test
	public void testImportPromotionJobRun() throws Exception {

		String fileName = "promotion_onetime.dat";
		Mockito.doNothing().when(promotionWriter).write(fileName);
		Mockito.doReturn(
				"src/main/resources/com/tesco/services/adapters/promotion")
				.when(mockConfiguration).getPromotionFilePath();
		Mockito.doReturn("promotion_onetime.json").when(mockConfiguration)
				.getPromotionOneTImeFileName();

		PromotionResource.getImportSemaphoreForIdentifier().put(
				"promotion_onetime.dat", new Semaphore(1));

		ImportPromotionJob importPromotionJob = new ImportPromotionJob(
				mockConfiguration, promotionWriter);
		importPromotionJob.setFileName(fileName);
		importPromotionJob.run();
		assertThat(true).isEqualTo(true);
	}

	@Test
	public void testImportPromotionJobException() throws Exception {

		Mockito.doReturn(
				"src/main/resources/com/tesco/services/adapters/promotion")
				.when(mockConfiguration).getPromotionFilePath();
		Mockito.doReturn("promotion_onetime.json").when(mockConfiguration)
				.getPromotionOneTImeFileName();
		String fileName = "promotion_onetime.dat";
		Mockito.doThrow(new WriterBusinessException()).when(promotionWriter)
				.write(fileName);
		PromotionResource.getImportSemaphoreForIdentifier().put(
				"promotion_onetime.dat", new Semaphore(1));
		ImportPromotionJob importPromotionJob = new ImportPromotionJob(
				mockConfiguration, promotionWriter);
		importPromotionJob.setFileName(fileName);
		importPromotionJob.run();
		assertThat("Error importing onetime Promotion data").isEqualTo(
				PromotionResource.getErrorString("promotion_onetime.dat"));

		Mockito.doThrow(
				new WriterBusinessException(
						"Error importing Promotion Data : File Not Found"))
				.when(promotionWriter).write(fileName);
		PromotionResource.getImportSemaphoreForIdentifier().put(
				"onetimepromotion", new Semaphore(1));
		importPromotionJob = new ImportPromotionJob(mockConfiguration,
				promotionWriter);
		importPromotionJob.setFileName(fileName);
		importPromotionJob.run();
		assertThat("Error importing onetime Promotion data").isEqualTo(
				PromotionResource.getErrorString("promotion_onetime.dat"));
	}

	@Test
	public void testImportPriceJob() throws IOException,
			WriterBusinessException {
		String fileName = "priceOnetime.dat";
		Mockito.doNothing().when(priceWriter).write(fileName);
		Mockito.doReturn("src/main/resources/com/tesco/services/adapters/price")
				.when(mockConfiguration).getPriceFilePath();
		ImportResource.getImportSemaphoreForIdentifier().put(fileName,
				new Semaphore(1));

		ImportPriceJob importPriceJob = new ImportPriceJob(priceWriter);
		importPriceJob.setFileName(fileName);
		importPriceJob.run();

	}

	@Test
	public void testImportPriceJobException() throws Exception {
		String fileName = "priceOnetime.dat";
		Mockito.doReturn("src/main/resources/com/tesco/services/adapters/price")
				.when(mockConfiguration).getPriceFilePath();

		Mockito.doThrow(new WriterBusinessException()).when(priceWriter)
				.write(fileName);
		ImportResource.getImportSemaphoreForIdentifier().put(fileName,
				new Semaphore(1));
		ImportPriceJob importPriceJob = new ImportPriceJob(priceWriter);
		importPriceJob.setFileName(fileName);
		importPriceJob.run();
		assertThat("Error importing Price onetime data").isEqualTo(
				ImportResource.getErrorString(fileName));

	}

	@Test
	public void testImportSubGroupDfltJob() throws Exception {
		String fileName = "subgroup_dflt_uom_20160412.dat";
		Mockito.doNothing().when(rpmSubGroupDfltUomMapper).write(fileName);
		Mockito.doReturn("src/main/resources/com/tesco/services/adapters/")
				.when(mockConfiguration).getRpmSubgroupDataDumpPath();
		ImportResource.getImportSemaphoreForIdentifier().put(fileName,
				new Semaphore(1));

		ImportSubGroupDfltUomJob importSubGroupDfltUomJob = new ImportSubGroupDfltUomJob(
				mockConfiguration, webServiceCallBuilder,
				rpmSubGroupDfltUomMapper);
		importSubGroupDfltUomJob.setFileName(fileName);
		importSubGroupDfltUomJob.run();

	}

	@Test
	public void testImportSubGroupDfltException() throws Exception {
		String fileName = "subgroup_dflt_uom_20160412.dat";
		String runIdentifier = "subgroup_dflt_uom";

		Mockito.doThrow(new WriterBusinessException())
				.when(rpmSubGroupDfltUomMapper).write(fileName);
		ImportResource.importSemaphoreForIdentifier.put(fileName,
				new Semaphore(1));
		ImportSubGroupDfltUomJob importSubGroupDfltUomJob = new ImportSubGroupDfltUomJob(
				mockConfiguration, webServiceCallBuilder,
				rpmSubGroupDfltUomMapper);
		importSubGroupDfltUomJob.setFileName(fileName);
		importSubGroupDfltUomJob.setRunIdentifier(runIdentifier);
		importSubGroupDfltUomJob.run();
		assertThat("Error importing Onetime SubGroup Default Mapping..")
				.isEqualTo(ImportResource.getErrorString(runIdentifier));
	}

	@Test
	public void testImportRPMZoneGroupJobRun() throws Exception {

		String fileName = "tsl_rpm_zone_group_onetime.csv";
		Mockito.doNothing().when(rpmZoneGroupWriter).write(fileName);
		Mockito.doReturn(
				"src/main/resources/com/tesco/services/adapters/rpmzone")
				.when(mockConfiguration).getRpmZoneDataDump();

		Mockito.doReturn(fileName).when(mockConfiguration).getRpmZoneDataDump();

		ImportResource.importSemaphoreForIdentifier.put(fileName,
				new Semaphore(1));

		ImportRPMZoneGroupJob importRPMZoneGroupJob = new ImportRPMZoneGroupJob(
				mockConfiguration, rpmZoneGroupWriter);
		importRPMZoneGroupJob.setFileName(fileName);
		importRPMZoneGroupJob.run();
		assertThat(true).isEqualTo(true);
	}

	@Test
	public void testImportRPMZoneGroupJobException() throws Exception {

		String fileName = "tsl_rpm_zone_group_onetime.csv";
		Mockito.doThrow(new WriterBusinessException()).when(rpmZoneGroupWriter)
				.write(fileName);
		ImportResource.importSemaphoreForIdentifier.put(fileName,
				new Semaphore(1));
		ImportRPMZoneGroupJob importRPMZoneGroupJob = new ImportRPMZoneGroupJob(
				mockConfiguration, rpmZoneGroupWriter);
		importRPMZoneGroupJob.setFileName(fileName);
		importRPMZoneGroupJob.run();
		assertThat("Error importing Onetime RPM Zone Group data..").isEqualTo(
				ImportResource.getErrorString(fileName));
	}

	@Test
	public void testImportEstbPriceJobRun() throws Exception {

		String fileName = "tsl_ps_estd_price_regular_1_20151212.csv";

		Mockito.doNothing().when(establishedPriceWritter).write(fileName);
		Mockito.doReturn(
				"src/main/resources/com/tesco/services/adapters/rpmclearance")
				.when(mockConfiguration).getRpmClrDataDumpPath();

		Mockito.doReturn(fileName).when(mockConfiguration).getRpmZoneDataDump();

		ImportResource.importSemaphoreForIdentifier.put(fileName,
				new Semaphore(1));

		ImportEstablishedPriceJob importEstablishedPriceJob = new ImportEstablishedPriceJob(
				mockConfiguration, establishedPriceWritter);
		importEstablishedPriceJob.setFileName(fileName);
		importEstablishedPriceJob.run();
		assertThat(true).isEqualTo(true);
	}

	@Test
	public void testImportEstbPriceJobException() throws Exception {
		String fileName = "tsl_ps_estd_price_regular_1_20151212.csv";
		Mockito.doThrow(new WriterBusinessException())
				.when(establishedPriceWritter).write(fileName);
		ImportEstablishedPriceJob importEstablishedPriceJob = new ImportEstablishedPriceJob(
				mockConfiguration, establishedPriceWritter);
		importEstablishedPriceJob.setFileName(fileName);
		ImportResource.importSemaphoreForIdentifier.put(fileName,
				new Semaphore(1));
		importEstablishedPriceJob.run();
		assertThat("Error importing Onetime Established Price data..")
				.isEqualTo(
						ImportResource
								.getErrorString("tsl_ps_estd_price_regular_1_20151212.csv"));
	}

	@Test
	public void testImportFutureOfferDescJobRun() throws Exception {
		String fileName = "FutureOfferDesc.csv";

		Mockito.doNothing().when(futureOfferDescWritter).write(fileName);
		Mockito.doReturn(
				"src/main/resources/com/tesco/services/adapters/promotion/")
				.when(mockConfiguration).getPromotionFilePath();
		ImportResource.importSemaphoreForIdentifier.put(fileName,
				new Semaphore(1));

		ImportFutureOfferDescJob importFutureOfferDescJob = new ImportFutureOfferDescJob(
				mockConfiguration, futureOfferDescWritter);
		importFutureOfferDescJob.setFileName(fileName);
		importFutureOfferDescJob.run();
		assertThat(true).isEqualTo(true);
	}

	@Test
	public void testImportFutureOfferDescJobException() throws Exception {

		String fileName = "FutureOfferDesc.csv";
		Mockito.doThrow(new WriterBusinessException())
				.when(futureOfferDescWritter).write(fileName);
		ImportResource.importSemaphoreForIdentifier.put(fileName,
				new Semaphore(1));
		ImportFutureOfferDescJob importFutureOfferDescJob = new ImportFutureOfferDescJob(
				mockConfiguration, futureOfferDescWritter);
		importFutureOfferDescJob.setFileName(fileName);
		importFutureOfferDescJob.run();
		assertThat("Error importing Future offer descriptions..").isEqualTo(
				ImportResource.getErrorString(fileName));
	}

	@After
	public void resetMocks() throws Exception {
		Mockito.reset(mockRPMWriter);
		Mockito.reset(mmWriter);
		Mockito.reset(rpmClearanceWriter);
		Mockito.reset(mockConfiguration);
		Mockito.reset(couchbaseWrapper);
		Mockito.reset(asyncCouchbaseWrapper);
		Mockito.reset(rpmZoneWriter);
		Mockito.reset(promotionWriter);
		Mockito.reset(priceWriter);
		Mockito.reset(rpmSubGroupDfltUomMapper);
	}
}
