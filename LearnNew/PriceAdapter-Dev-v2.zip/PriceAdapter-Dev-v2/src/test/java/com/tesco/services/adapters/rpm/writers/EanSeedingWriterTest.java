package com.tesco.services.adapters.rpm.writers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tesco.couchbase.AsyncCouchbaseWrapper;
import com.tesco.couchbase.CouchbaseWrapper;
import com.tesco.couchbase.testutils.AsyncCouchbaseWrapperStub;
import com.tesco.couchbase.testutils.BucketTool;
import com.tesco.couchbase.testutils.CouchbaseTestManager;
import com.tesco.couchbase.testutils.CouchbaseWrapperStub;
import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.exceptions.WriterBusinessException;
import com.tesco.services.adapters.rpm.writers.impl.EanSeedingWriter;
import com.tesco.services.repositories.RepositoryImpl;
import com.tesco.services.resources.TeauthPriceChecksResource;
import com.tesco.services.resources.TestConfiguration;
import com.tesco.services.utility.PriceConstants;
import com.tesco.services.utility.WebServiceCallBuilder;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import javax.servlet.ServletException;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;
import java.io.BufferedReader;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.net.URISyntaxException;
import java.util.*;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by PO47 on 06/04/2015.
 */

@RunWith(MockitoJUnitRunner.class)
public class EanSeedingWriterTest {

	@Mock
	public RepositoryImpl repositoryImpl;

	@Mock
	public AsyncCouchbaseWrapper asyncCouchbaseWrapper;

	@Mock
	public CouchbaseWrapper couchbaseWrapper;

	@Mock
	protected Configuration testConfiguration;

	@Mock
	private ObjectMapper mapper;

	@Mock
	private CouchbaseTestManager couchbaseTestManager;

	@Mock
	private WebServiceCallBuilder webServiceCallBuilder;

	@Mock
	protected BufferedReader eanSeedWriterReader;

	@Mock
	private Set<String> tpncKeys;

	@Mock
	private WebTarget resource;

	@Mock
	private Response response;

	public EanSeedingWriter eanSeedingWriter;

	String filePath = "uk";

	private Map actualProductPriceInfo = new HashMap();
	Exception exception;

	@Before
	public void setUp() throws IOException, URISyntaxException,
			InterruptedException {

		testConfiguration = TestConfiguration.load();
		filePath = "/appl/prcsrvce/data/rej/PRICE_CHECK_FILE_KLL.KLTEAUTH.B*";

		if (testConfiguration.isDummyCouchbaseMode()) {
			Map<String, ImmutablePair<Long, String>> fakeBase = new HashMap<>();
			couchbaseTestManager = new CouchbaseTestManager(
					new CouchbaseWrapperStub(fakeBase),
					new AsyncCouchbaseWrapperStub(fakeBase),
					mock(BucketTool.class));
		} else {
			couchbaseTestManager = new CouchbaseTestManager(
					testConfiguration.getCouchbaseBucket(),
					testConfiguration.getCouchbaseUsername(),
					testConfiguration.getCouchbasePassword(),
					testConfiguration.getCouchbaseNodes(),
					testConfiguration.getCouchbaseAdminUsername(),
					testConfiguration.getCouchbaseAdminPassword());
		}

		couchbaseWrapper = couchbaseTestManager.getCouchbaseWrapper();
		asyncCouchbaseWrapper = couchbaseTestManager.getAsyncCouchbaseWrapper();

		mapper = new ObjectMapper();
		repositoryImpl = new RepositoryImpl(couchbaseWrapper,
				asyncCouchbaseWrapper, mapper);

		eanSeedingWriter = new EanSeedingWriter(testConfiguration,
				webServiceCallBuilder, repositoryImpl);
		Mockito.doNothing().when(eanSeedWriterReader).close();

	}

	@After
	public void tearDown() throws Exception {
		setFinalStatic(
				PriceConstants.class.getField("PRODUCT_SERVICE_CALL_LIMIT"),
				PriceConstants.PRODUCT_SERVICE_CALL_LIMIT);

	}

	@Test
	public void writeThrowSIOBException() throws ServletException {
		BufferedReader mockBufferedReader = Mockito.mock(BufferedReader.class);
		try {
			Mockito.when(mockBufferedReader.readLine()).thenThrow(
					new StringIndexOutOfBoundsException());
			eanSeedingWriter.setBufferedReader(mockBufferedReader);
			eanSeedingWriter.write(filePath);
		} catch (WriterBusinessException | IOException e) {
			e.printStackTrace();
		} catch (StringIndexOutOfBoundsException e) {
			assertThat(e);
		}

	}

	@Test
	public void writeThrowException() throws ServletException {
		BufferedReader mockBufferedReader = Mockito.mock(BufferedReader.class);
		try {
			Mockito.when(mockBufferedReader.readLine()).thenThrow(
					new IOException());
			eanSeedingWriter.setBufferedReader(mockBufferedReader);
			eanSeedingWriter.write(filePath);
		} catch (Exception e) {
			assertThat(e);
		}
	}

	@Test
	public void writeEanTpncMapingTest() throws ServletException {
		BufferedReader mockBufferedReader = Mockito.mock(BufferedReader.class);
		try {
			Mockito.when(mockBufferedReader.readLine())
					.thenReturn(new String("10"))
					.thenReturn(
							new String(
									"20            8  15900  15900 159000           17    032    032   0320"))
					.thenReturn(new String("90")).thenReturn(null);
			eanSeedingWriter.setBufferedReader(mockBufferedReader);
			eanSeedingWriter.write(filePath);
		} catch (Exception e) {
			assertThat(e);
		}

	}

	@Test
	public void callProductServiceExceptionTest() throws Exception {
		Mockito.when(response.getStatus()).thenReturn(404);
		BufferedReader mockBufferedReader = Mockito.mock(BufferedReader.class);
		WebServiceCallBuilder webServiceCallBuilderMock = mock(WebServiceCallBuilder.class);
		eanSeedingWriter.setWebServiceCallBuilder(webServiceCallBuilderMock);
		when(
				webServiceCallBuilderMock.getResponseFromProdServices(Matchers
						.any(String.class))).thenReturn(response);

		Mockito.when(mockBufferedReader.readLine())
				.thenReturn(
						new String(
								"20            8  15900  15900 159000           17    032    032   0320"))
				.thenReturn(null);
		eanSeedingWriter.setBufferedReader(mockBufferedReader);
		eanSeedingWriter.setResponse(response);
		// eanSeedingWriter.setResource(resource);
		eanSeedingWriter.write(filePath);

		assertThat(TeauthPriceChecksResource
				.getErrorString(
						"/appl/prcsrvce/data/rej/PRICE_CHECK_FILE_KLL.KLTEAUTH.B*")
				.equals("The URL trying to reach could not be found on the server."));

		Mockito.when(response.getStatus()).thenReturn(500);
		Mockito.when(mockBufferedReader.readLine())
				.thenReturn(
						new String(
								"20            8  15900  15900 159000           17    032    032   0320"))
				.thenReturn(null);
		eanSeedingWriter.write(filePath);
		assertThat(TeauthPriceChecksResource.getErrorString(
				"/appl/prcsrvce/data/rej/PRICE_CHECK_FILE_KLL.KLTEAUTH.B*")
				.equals("HTTP 500 - Internal Server Error"));

		Mockito.when(response.getStatus()).thenReturn(501);
		Mockito.when(mockBufferedReader.readLine())
				.thenReturn(
						new String(
								"20            8  15900  15900 159000           17    032    032   0320"))
				.thenReturn(null);
		eanSeedingWriter.write(filePath);
		assertThat(TeauthPriceChecksResource.getErrorString(
				"/appl/prcsrvce/data/rej/PRICE_CHECK_FILE_KLL.KLTEAUTH.B*")
				.equals("The status code from Product Service is 501"));
	}

	@Test
	public void checkProductRepository() {
		eanSeedingWriter.setRepository(repositoryImpl);
		assertThat(repositoryImpl).isEqualTo(
				(RepositoryImpl) eanSeedingWriter.getRepository());

	}

	@Test
	public void testloggingconditions() throws Exception {
		// If TPNC is nullitem
		String line = "20     10009666    1.31    1.31  10.480     10009680    3.00    3.00   8.580";
		List<Map<String, String>> products = new ArrayList<>();
		Map prod1 = new HashMap();
		// prod1.put(PriceConstants.PRODUCT_SERVICE_RESPONSE_TPNC, "254842259");
		prod1.put(PriceConstants.PRODUCT_SERVICE_RESPONSE_GTIN14,
				"00000010009666");
		products.add(prod1);
		actualProductPriceInfo.put(
				PriceConstants.PRODUCT_SERVICE_RESPONSE_PRODUCTS, products);
		actualProductPriceInfo.put(
				PriceConstants.PRODUCT_SERVICE_RESPONSE_TOTAL, 1);
		actualProductPriceInfo.put(
				PriceConstants.PRODUCT_SERVICE_RESPONSE_MISSING_SET,
				new ArrayList<>());
		List l = new ArrayList();
		l.add("10009666");
		l.add("10009680");
		String url = eanSeedingWriter.createProductServiceUrl(l);
		BufferedReader mockBufferedReader = Mockito.mock(BufferedReader.class);
		eanSeedingWriter.setRepository(repositoryImpl);
		eanSeedingWriter.setWebServiceCallBuilder(webServiceCallBuilder);
		Mockito.when(webServiceCallBuilder.getResponseFromProdServices(url))
				.thenReturn(response);
		Mockito.when(response.getStatus()).thenReturn(200);
		Mockito.when(response.readEntity(Map.class)).thenReturn(
				actualProductPriceInfo);
		eanSeedingWriter.setBufferedReader(mockBufferedReader);
		Mockito.when(mockBufferedReader.readLine()).thenReturn(line)
				.thenReturn(null);
		eanSeedingWriter.write(filePath);

		// If GTIN is null
		String line1 = "20     10009666    1.31    1.31  10.480     10009680    3.00    3.00   8.580";
		List<Map<String, String>> products1 = new ArrayList<>();
		Map prod2 = new HashMap();
		prod2.put(PriceConstants.PRODUCT_SERVICE_RESPONSE_TPNC, "254842259");

		products1.add(prod2);
		actualProductPriceInfo = new HashMap();
		actualProductPriceInfo.put(
				PriceConstants.PRODUCT_SERVICE_RESPONSE_PRODUCTS, products1);
		actualProductPriceInfo.put(
				PriceConstants.PRODUCT_SERVICE_RESPONSE_TOTAL, 1);
		actualProductPriceInfo.put(
				PriceConstants.PRODUCT_SERVICE_RESPONSE_MISSING_SET,
				new ArrayList<>());
		List l1 = new ArrayList();
		l1.add("10009666");
		l1.add("10009680");
		String url1 = eanSeedingWriter.createProductServiceUrl(l1);

		eanSeedingWriter.setRepository(repositoryImpl);
		eanSeedingWriter.setWebServiceCallBuilder(webServiceCallBuilder);
		Mockito.when(webServiceCallBuilder.getResponseFromProdServices(url1))
				.thenReturn(response);
		Mockito.when(response.getStatus()).thenReturn(200);
		Mockito.when(response.readEntity(Map.class)).thenReturn(
				actualProductPriceInfo);
		eanSeedingWriter.setBufferedReader(mockBufferedReader);
		Mockito.when(mockBufferedReader.readLine()).thenReturn(line1)
				.thenReturn(null);
		eanSeedingWriter.write(filePath);

	}

	static void setFinalStatic(Field field, Object newValue) throws Exception {
		field.setAccessible(true);

		// remove final modifier from field
		Field modifiersField = Field.class.getDeclaredField("modifiers");
		modifiersField.setAccessible(true);
		modifiersField.setInt(field, field.getModifiers() & ~Modifier.FINAL);

		field.set(null, newValue);
	}
}
