package com.tesco.services.mappers;

import javax.ws.rs.NotFoundException;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;

import com.tesco.services.resources.HTTPResponses;

/*Invalid URLMapper class*/
public class InvalidUrlMapper implements ExceptionMapper<NotFoundException> {
    @Override
    public Response toResponse(NotFoundException e) {
        return HTTPResponses.badRequest();
    }
}
