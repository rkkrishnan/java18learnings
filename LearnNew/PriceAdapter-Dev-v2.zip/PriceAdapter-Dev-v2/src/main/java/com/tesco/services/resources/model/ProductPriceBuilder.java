package com.tesco.services.resources.model;

import com.google.common.base.Optional;
import com.tesco.services.core.*;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.PriceConstants;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;
import org.slf4j.Logger;

import java.text.ParseException;
import java.util.*;

public class ProductPriceBuilder implements ProductPriceVisitor {
    public static final String VARIANTS = "variants";
    public static final String TPNB = "tpnb";
    public static final String TPNC = "tpnc";
    public static final String PRICE = "price";
    /**Modified By Nibedita - PS-118- Positive Scenario
     * Given the  price IDL ,When the price rest calls are requested, then the response JSON should be as per format mentioned in IDL  */
    public static final String PROMO_PRICE = "promoprice";
    /**Modified By Nibedita - PS-173
     * Given the  price IDL ,When the price rest calls are requested and selling UOM filed is available in price_zone.csv,
     * then the response JSON should display selling UOM for the tpnc's in line with IDL  */
    public static final String SELLING_UOM = "sellingUOM";
    public static final String CLEARANCE_PRICE = "clrprice";
    public static final String AUTH_PRICE = "authprice";


    public static final String PROMOTION_INFO = "promotions";
    public static final String CURRENCY = "currency";
    public static final String OFFER_ID = "offerID";
    public static final String OFFER_NAME = "offerName";
    public static final String EFFECTIVE_DATE = "effectiveDate";
    public static final String END_DATE = "endDate";
    public static final String CUSTOMER_FRIENDLY_DESCRIPTION_1 = "customerFriendlyDescription1";
    private static final String CUSTOMER_FRIENDLY_DESCRIPTION_2 = "customerFriendlyDescription2";
    private static final Logger LOGGER = (Logger)LoggerFactoryWrapper.getLogger(ProductPriceBuilder.class);

    private Map<String, Object> priceInfo = new LinkedHashMap<>();
    private Collection<Promotion> promotionsInProduct = null;
    private Optional<Integer> priceZoneId;
    private Optional<Integer> promoZoneId;

    private Optional<Integer> clearZoneId;
    private String currency;
    Map<String,Object> bulkProducts;

    public ProductPriceBuilder(Optional<Integer> priceZoneId, Optional<Integer> promoZoneId, String currency, Optional<Integer> clearZoneId, Map<String, Object> bulkProducts) {
        this.priceZoneId = priceZoneId;
        this.promoZoneId = promoZoneId;
        this.currency = currency;
        this.clearZoneId=clearZoneId;
        this.bulkProducts=bulkProducts;
    }
    public ProductPriceBuilder(Optional<Integer> priceZoneId, Optional<Integer> promoZoneId, String currency) {
        this.priceZoneId = priceZoneId;
        this.promoZoneId = promoZoneId;
        this.currency = currency;


    }

    @Override
    public void visit(Product product) {
        priceInfo.put(TPNB, product.getTPNB());
        priceInfo.put(VARIANTS, new ArrayList<Map<String, Object>>());
        /**Modified By Nibedita - PS-118- Positive Scenario
         * Given the  price IDL ,When the price rest calls are requested, then the response JSON should be as per format mentioned in IDL  */
        priceInfo.put(PROMOTION_INFO, new ArrayList<Map<String, String>>());
        promotionsInProduct = product.getPromotions();

    }


/**
 * Visit function will calculate clearance price and auth price for a particular variant passed to it
 * Will also take into consideration only the active clearance,National Clearance Zone
 * If clearance is present in MM as well as RPM then lowest of both clearance price
 * Auth price is lowest all the prices*/

    @Override
    public void visit(ProductVariant productVariant,String tpnb) {
        List<Map<String, Object>> variants = (List<Map<String, Object>>) priceInfo.get(VARIANTS);
        List<Map<String, String>> promotions = (List<Map<String, String>>) priceInfo.get(PROMOTION_INFO);
        String clearPrice=null ;

        SaleInfo priceZoneSaleInfo = priceZoneId.isPresent() ? productVariant.getSaleInfo(priceZoneId.get()) : null;
        SaleInfo promoZoneSaleInfo = promoZoneId.isPresent() ? productVariant.getSaleInfo(promoZoneId.get()) : null;
        ClearanceMMProduct mmClearProduct;
        ClearanceZoneSaleInfo mmclearZoneSaleInfo = null;
        ClearanceProductVariant rpmClearVariant=null;
        ClearanceZoneSaleInfo rpmclearZoneSaleInfo = null;

        if(bulkProducts.get(PriceConstants.CLEARANCE_KEY_PREFIX+tpnb)!=null &&
                (rpmClearVariant=((ClearanceProduct)bulkProducts.get(PriceConstants.CLEARANCE_KEY_PREFIX+tpnb))
                    .getClearanceProductVariantByTPNC(productVariant.getTPNC()))!=null)
        {
          rpmclearZoneSaleInfo=rpmClearVariant.getClearanceZoneSaleInfo(clearZoneId.get());
        }
        if((mmClearProduct=(ClearanceMMProduct)bulkProducts.get(PriceConstants.CLEARANCE_MM_PRODUCT_KEY_PREFIX+tpnb))!=null){
             mmclearZoneSaleInfo=mmClearProduct.getClearanceZoneSaleInfo(clearZoneId.get());
        }
        if (priceZoneSaleInfo == null && promoZoneSaleInfo == null) {
            return;
        }

        Map<String, Object> variantInfo = new LinkedHashMap<>();
        variantInfo.put(TPNC, productVariant.getTPNC());
        variantInfo.put(CURRENCY, currency);
        /**Modified By Nibedita - PS-173
         * Given the  price IDL ,When the price rest calls are requested and selling UOM filed is available in price_zone.csv,
         * then the response JSON should display selling UOM for the tpnc's in line with IDL  */
        variantInfo.put(SELLING_UOM, productVariant.getSellingUOM());
        variants.add(variantInfo);
        /*Modified by Sushil PS-178 to configure decimal places for price - Start*/
        if (priceZoneSaleInfo != null ) {
            variantInfo.put(PRICE, Dockyard.priceScaleRoundHalfUp(currency, priceZoneSaleInfo.getPrice()));
        }
        /**Modified By Nibedita - PS-118- Positive Scenario
         * Given the  price IDL ,When the price rest calls are requested, then the response JSON should be as per format mentioned in IDL  */
        if (promoZoneSaleInfo != null) {
            variantInfo.put(PROMO_PRICE, Dockyard.priceScaleRoundHalfUp(currency, promoZoneSaleInfo.getPrice()));
        }
        /*Modified by Sushil PS-178 to configure decimal places for price - End*/
        /**Modified By Nibedita - PS-118- Positive Scenario
         * Given the  price IDL ,When the price rest calls are requested, then the response JSON should be as per format mentioned in IDL  */
        if (promoZoneSaleInfo == null) {
            variantInfo.put(PROMO_PRICE, null);
        }
        if (promotions.isEmpty()) {
            addPromotionInfo(promotions);
        }

        try {
            if(!Dockyard.isSpaceOrNull(rpmclearZoneSaleInfo)) {
                for (ClearanceByDateTime clearanceByDateTime : rpmclearZoneSaleInfo.getZoneClearancePriceByDateTime().values()) {

                    if (Dockyard.checkActiveaClear(clearanceByDateTime.getEffvDateTime(), clearanceByDateTime.getEndDateTime())) {
                        clearPrice = clearanceByDateTime.getClearancePrice();
                        break;

                    }
                }
            }
            if(!Dockyard.isSpaceOrNull(mmclearZoneSaleInfo)) {
                for (ClearanceByDateTime clearanceByDateTime : mmclearZoneSaleInfo.getZoneClearancePriceByDateTime().values()) {
                    if (Dockyard.checkActiveaClear(clearanceByDateTime.getEffvDateTime(), clearanceByDateTime.getEndDateTime())) {

                        clearPrice = String.valueOf(Dockyard.lowestOfTwoNum(clearPrice, clearanceByDateTime.getClearancePrice()));
                        break;

                    }
                }
            }
            variantInfo.put(CLEARANCE_PRICE,clearPrice);
            String authPrice= Dockyard.lowestOfTwoNum(Dockyard.lowestOfTwoNum((String) variantInfo.get(PROMO_PRICE), (String) variantInfo.get(CLEARANCE_PRICE)), (String) variantInfo.get(PRICE));
            variantInfo.put(AUTH_PRICE,authPrice);
        }catch (ParseException e) {
            LOGGER.info("Parse Exception in ProductPricebuilder.java while checking for active clearance");
            }
    }
    @Override
    public void visit(ProductVariant productVariant) {
        List<Map<String, Object>> variants = (List<Map<String, Object>>) priceInfo.get(VARIANTS);
        List<Map<String, String>> promotions = (List<Map<String, String>>) priceInfo.get(PROMOTION_INFO);

        SaleInfo priceZoneSaleInfo = priceZoneId.isPresent() ? productVariant.getSaleInfo(priceZoneId.get()) : null;
        SaleInfo promoZoneSaleInfo = promoZoneId.isPresent() ? productVariant.getSaleInfo(promoZoneId.get()) : null;

        if (priceZoneSaleInfo == null && promoZoneSaleInfo == null) {
            return;
        }

        Map<String, Object> variantInfo = new LinkedHashMap<>();
        variantInfo.put(TPNC, productVariant.getTPNC());
        variantInfo.put(CURRENCY, currency);
        /**Modified By Nibedita - PS-173
         * Given the  price IDL ,When the price rest calls are requested and selling UOM filed is available in price_zone.csv,
         * then the response JSON should display selling UOM for the tpnc's in line with IDL  */
        variantInfo.put(SELLING_UOM, productVariant.getSellingUOM());
        variants.add(variantInfo);
        /*Modified by Sushil PS-178 to configure decimal places for price - Start*/
        if (priceZoneSaleInfo != null ) {
            variantInfo.put(PRICE, Dockyard.priceScaleRoundHalfUp(currency, priceZoneSaleInfo.getPrice()));
        }
        /**Modified By Nibedita - PS-118- Positive Scenario
         * Given the  price IDL ,When the price rest calls are requested, then the response JSON should be as per format mentioned in IDL  */
        if (promoZoneSaleInfo != null) {
            variantInfo.put(PROMO_PRICE, Dockyard.priceScaleRoundHalfUp(currency, promoZoneSaleInfo.getPrice()));
        }
        /*Modified by Sushil PS-178 to configure decimal places for price - End*/
        /**Modified By Nibedita - PS-118- Positive Scenario
         * Given the  price IDL ,When the price rest calls are requested, then the response JSON should be as per format mentioned in IDL  */
        if (promoZoneSaleInfo == null) {
            variantInfo.put(PROMO_PRICE, null);
        }
        if (promotions.isEmpty()) {
            addPromotionInfo(promotions);
        }
    }


    /**Modified By Nibedita - PS-118- Positive Scenario
     * Given the  price IDL ,When the price rest calls are requested, then the response JSON should be as per format mentioned in IDL  */
    private void addPromotionInfo(List<Map<String, String>> promotionInfo) {
        Collection<Promotion> promotions = promotionsInProduct;

        if (promotions.isEmpty()) {
            return;
        }

        for (Promotion promotion : promotions) {
            if(this.promoZoneId.equals(Optional.of(promotion.getZoneId())) ){
                Map<String, String> promotionInfoMap = new LinkedHashMap<>();
                promotionInfoMap.put(OFFER_ID, promotion.getOfferId());
                promotionInfoMap.put(OFFER_NAME, promotion.getOfferName());
                promotionInfoMap.put(EFFECTIVE_DATE, promotion.getEffectiveDate());
                promotionInfoMap.put(END_DATE, promotion.getEndDate());
                promotionInfoMap.put(CUSTOMER_FRIENDLY_DESCRIPTION_1, promotion.getCFDescription1());
                promotionInfoMap.put(CUSTOMER_FRIENDLY_DESCRIPTION_2, promotion.getCFDescription2());
                promotionInfo.add(promotionInfoMap);
            }
        }

    }

    public Map<String, Object> getPriceInfo() {
        return priceInfo;
    }
}
