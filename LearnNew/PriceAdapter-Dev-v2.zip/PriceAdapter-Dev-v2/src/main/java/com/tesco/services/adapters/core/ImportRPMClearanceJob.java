package com.tesco.services.adapters.core;

import java.io.IOException;
import java.text.ParseException;

import javax.inject.Inject;
import javax.inject.Named;
import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;

import org.slf4j.Logger;
import org.xml.sax.SAXException;

import com.tesco.services.adapters.core.exceptions.ColumnNotFoundException;
import com.tesco.services.adapters.core.exceptions.WriterBusinessException;
import com.tesco.services.adapters.rpm.writers.impl.RPMClearanceWriter;
import com.tesco.services.adapters.rpm.writers.Writer;
import com.tesco.services.resources.ImportResource;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;

public class ImportRPMClearanceJob implements Import {

	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(ImportRPMClearanceJob.class);

	public String runIdentifier;
	private Writer rpmClearanceWriter;

	@Inject
	public ImportRPMClearanceJob(@Named("rpmClearanceWriter") Writer rpmClearanceWriter) {
		this.rpmClearanceWriter = rpmClearanceWriter;
	}

	public String getRunIdentifier() {
		return runIdentifier;
	}

	public void setRunIdentifier(String runIdentifier) {
		this.runIdentifier = runIdentifier;
	}

	@Override
	public void run() {
		LOGGER.info("Firing up imports for RPM Clearance for {}",
				runIdentifier);
		startImportProcess();
	}

	/**
	 * @throws IOException
	 * @throws ColumnNotFoundException
	 * @throws ParserConfigurationException
	 * @throws JAXBException
	 * @throws SAXException
	 * @throws ParseException
	 */
	public void startImportProcess() {
		try {
			((RPMClearanceWriter)rpmClearanceWriter).setRunIdentifier(getRunIdentifier());
			rpmClearanceWriter.write(null);
		} catch (WriterBusinessException exception) {
			LOGGER.error("Error importing data", exception);
			ImportResource.setErrorString(runIdentifier,
					"Error importing RPM Clearance data");
		} finally {
			ImportResource.getImportSemaphoreForIdentifier(runIdentifier)
					.release();
		}

	}

}
