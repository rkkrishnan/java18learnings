package com.tesco.services.adapters.core.utils;

import java.net.URI;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;

/**
 * Created by PO47 on 26/11/2015.
 */
public class ServiceClient {

	public URI getResourceURIToRefreshService(String refreshServiceUrl) {
		return UriBuilder.fromUri(String.format(refreshServiceUrl)).build();

	}

	public Response callRemoteServerToPostData(URI uriPath) {
		Client client = ClientBuilder.newClient();
		WebTarget target = client.target(uriPath);
		return target.request().accept(MediaType.APPLICATION_JSON)
				.post(Entity.entity("{}", MediaType.APPLICATION_JSON));
	}

	public Response callRemoteServer(URI uriPath) throws Exception {
		try {
			Client client = ClientBuilder.newClient();
			WebTarget target = client.target(uriPath);
			return target.request().accept(MediaType.APPLICATION_JSON).get();
		} catch (Exception e) {
			throw new Exception("Service is not running . " + e.getMessage());
		}
	}
}
