package com.tesco.services.adapters.rpm.writers;

import com.tesco.services.core.Store;
import com.tesco.services.core.ZoneEntity;
import com.tesco.services.core.zone.ZoneGrpEntity;
import com.tesco.services.exceptions.ZoneBusinessException;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Created by wa68 on 05/07/2016.
 */
public interface ZoneMessageWriter {

	public void writeZoneGrpMessage(ZoneGrpEntity zoneGrpEntity,
			Map<String, ZoneEntity> mapOfZoneEntities, String zoneMsgType)
			throws ZoneBusinessException;

	public void modifyZoneGroupData(List<String> zoneIds, String msgType)
			throws ZoneBusinessException;

	public void writeZoneMessage(Map<String, ZoneEntity> mapOfZoneEntities,
			String zoneMsgType) throws ZoneBusinessException;

	public void writeStoreDataFromMessage(Map<String, Store> mapOfStoreEntities)
			throws ZoneBusinessException;

	public void writeRejects(Set rejectedProducts);

	public void deleteZoneGrpData(String zoneGrpId)
			throws ZoneBusinessException;

	public void deleteZoneData(List<String> zoneKeys)
			throws ZoneBusinessException;

	public void deleteLocFromZoneDoc(String zoneKey, List<String> storeIds)
			throws ZoneBusinessException;
}
