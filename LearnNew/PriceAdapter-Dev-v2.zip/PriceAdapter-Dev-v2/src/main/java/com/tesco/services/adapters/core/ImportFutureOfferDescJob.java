package com.tesco.services.adapters.core;

import javax.inject.Inject;
import javax.inject.Named;

import org.slf4j.Logger;

import com.tesco.services.Configuration;
import com.tesco.services.adapters.rpm.writers.impl.FutureOfferDescWritter;
import com.tesco.services.adapters.rpm.writers.Writer;
import com.tesco.services.resources.ImportResource;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;

public class ImportFutureOfferDescJob implements Import {

	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(ImportFutureOfferDescJob.class);

	private Configuration configuration;
	private String runIdentifier;
	private String fileName;
	private Writer futureOfferDescWritter;

	@Inject
	public ImportFutureOfferDescJob(
			@Named("configuration") Configuration configuration,
			@Named("futureOfferDescWritter") Writer futureOfferDescWritter) {
		this.configuration = configuration;
		this.futureOfferDescWritter = futureOfferDescWritter;
	}

	public String getRunIdentifier() {
		return runIdentifier;
	}

	public void setRunIdentifier(String runIdentifier) {
		this.runIdentifier = runIdentifier;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	@Override
	public void run() {
		LOGGER.info("Firing up imports for Future offer descriptions {}",
				runIdentifier);
		startImportProcess();
	}

	public void startImportProcess() {
		try {
			LOGGER.info("Importing data for future offer descriptions {} ",
					configuration.getRpmClrDataDumpPath());
			((FutureOfferDescWritter) futureOfferDescWritter)
					.setRunIdentifier(getRunIdentifier());
			futureOfferDescWritter.write(getFileName());
			LOGGER.info("Successfully completed imports for Future offer descriptions");

		} catch (Exception exception) {
			LOGGER.error("Error importing Future offer descriptions..",
					exception);
			ImportResource.setErrorString(fileName,
					"Error importing Future offer descriptions..");
		} finally {
			ImportResource.getImportSemaphoreForIdentifier(fileName).release();
		}
	}
}
