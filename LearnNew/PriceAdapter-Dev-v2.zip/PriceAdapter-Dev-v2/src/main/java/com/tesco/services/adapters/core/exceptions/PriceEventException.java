package com.tesco.services.adapters.core.exceptions;

public class PriceEventException extends Exception {

	public PriceEventException(String message) {
		super(message);
	}

	public PriceEventException(Exception exception) {
		super(exception);
	}
	
	public PriceEventException(String message,Exception exception) {
		super(message,exception);
	}

}
