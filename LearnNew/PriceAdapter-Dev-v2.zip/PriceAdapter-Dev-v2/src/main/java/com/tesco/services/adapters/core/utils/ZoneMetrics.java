package com.tesco.services.adapters.core.utils;

import com.codahale.metrics.Counter;
import com.codahale.metrics.JmxReporter;
import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.Timer;
import com.codahale.metrics.Timer.Context;

/**
 * Created by wr38 on 27/05/2016.
 */
public class ZoneMetrics {

	static ZoneMetrics zoneMetrics;

	private static MetricRegistry metricRegisty;

	private static Timer zoneMessagesCre;

	Context zoneMessagesCreTC;
	private static Timer zoneMessagesMod;

	Context zoneMessagesModTC;
	private static Timer zoneMessagesDel;

	Context zoneMessagesDelTC;
	private static Timer zoneGroupMessagesCre;

	Context zoneGroupMessagesCreTC;
	private static Timer zoneGroupMessagesMod;

	Context zoneGroupMessagesModTC;
	private static Timer zoneGroupMessagesDel;

	Context zoneGroupMessagesDelTC;
	private static Timer zoneLocMessagesCre;

	Context zoneLocMessagesCreTC;
	private static Timer zoneLocMessagesDel;

	Context zoneLocMessagesDelTC;
	private static Timer messageListenerTimer;

	Context messageTimerContext;
	private static Counter errorCounter;

	private ZoneMetrics(MetricRegistry myMetricRegisty) {
		metricRegisty = myMetricRegisty;
	}
	public static synchronized ZoneMetrics getInstance() {
		if (zoneMetrics == null) {
			metricRegisty = new MetricRegistry();
			zoneMetrics = new ZoneMetrics(metricRegisty);
			JmxReporter.forRegistry(metricRegisty).build();
			initMetrics();
		}
		return zoneMetrics;
	}

	public static MetricRegistry getMetricRegisty() {
		return metricRegisty;
	}

	public void incrementErrorCount() {
		errorCounter.inc();
	}

	private static void initMetrics() {
		zoneMessagesCre = metricRegisty.timer(MetricRegistry.name("com.tesco",
				"ZoneElapsedTimeAndRate", "time-to-process-cre-message"));

		zoneMessagesDel = metricRegisty.timer(MetricRegistry.name("com.tesco",
				"ZoneElapsedTimeAndRate", "time-to-process-del-message"));

		zoneMessagesMod = metricRegisty.timer(MetricRegistry.name("com.tesco",
				"ZoneElapsedTimeAndRate", "time-to-process-mod-message"));

		zoneGroupMessagesCre = metricRegisty.timer(MetricRegistry.name(
				"com.tesco", "ZoneElapsedTimeAndRate",
				"time-to-process-cre-group-message"));

		zoneGroupMessagesDel = metricRegisty.timer(MetricRegistry.name(
				"com.tesco", "ZoneElapsedTimeAndRate",
				"time-to-process-del-group-message"));

		zoneGroupMessagesMod = metricRegisty.timer(MetricRegistry.name(
				"com.tesco", "ZoneElapsedTimeAndRate",
				"time-to-process-mod-group-message"));

		zoneLocMessagesCre = metricRegisty.timer(MetricRegistry.name(
				"com.tesco", "ZoneElapsedTimeAndRate",
				"time-to-process-cre-loc-message"));

		zoneLocMessagesDel = metricRegisty.timer(MetricRegistry.name(
				"com.tesco", "ZoneElapsedTimeAndRate",
				"time-to-process-del-loc-message"));

		messageListenerTimer = metricRegisty.timer(MetricRegistry.name(
				"com.tesco", "OverallZoneElapsedTimeAndRate",
				"time-to-process-message"));

		errorCounter = metricRegisty.counter(MetricRegistry.name("com.tesco",
				"ZoneMessageProcessingErrors", "total-error-count"));
	}

	public void logCreZoneGroupProcessingEndTime() {
		zoneGroupMessagesCreTC.stop();
	}

	public void logCreZoneGroupProcessingStartTime() {
		zoneGroupMessagesCreTC = zoneGroupMessagesCre.time();
	}

	public void logCreZoneLocProcessingEndTime() {
		zoneLocMessagesCreTC.stop();
	}

	public void logCreZoneLocProcessingStartTime() {
		zoneLocMessagesCreTC = zoneLocMessagesCre.time();
	}

	public void logCreZoneProcessingEndTime() {
		zoneMessagesCreTC.stop();
	}

	public void logCreZoneProcessingStartTime() {
		zoneMessagesCreTC = zoneMessagesCre.time();
	}

	public void logDelZoneGroupProcessingEndTime() {
		zoneGroupMessagesDelTC.stop();
	}

	public void logDelZoneGroupProcessingStartTime() {
		zoneGroupMessagesDelTC = zoneGroupMessagesDel.time();
	}

	public void logDelZoneLocProcessingEndTime() {
		zoneLocMessagesDelTC.stop();
	}

	public void logDelZoneLocProcessingStartTime() {
		zoneLocMessagesDelTC = zoneLocMessagesDel.time();
	}

	public void logDelZoneProcessingEndTime() {
		zoneMessagesDelTC.stop();
	}

	public void logDelZoneProcessingStartTime() {
		zoneMessagesDelTC = zoneMessagesDel.time();
	}

	public void logMessageProcessingEndTime() {
		messageTimerContext.stop();
	}

	public void logMessageProcessingStartTime() {
		messageTimerContext = messageListenerTimer.time();
	}

	public void logModZoneGroupProcessingEndTime() {
		zoneGroupMessagesModTC.stop();
	}

	public void logModZoneGroupProcessingStartTime() {
		zoneGroupMessagesModTC = zoneGroupMessagesMod.time();
	}

	public void logModZoneProcessingEndTime() {
		zoneMessagesModTC.stop();
	}

	public void logModZoneProcessingStartTime() {
		zoneMessagesModTC = zoneMessagesMod.time();
	}

	public void resetMetrics() {
		metricRegisty = new MetricRegistry();
		initMetrics();
	}
}
