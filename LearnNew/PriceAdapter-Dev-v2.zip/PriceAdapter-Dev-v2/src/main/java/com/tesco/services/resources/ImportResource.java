package com.tesco.services.resources;

import static com.tesco.services.resources.HTTPResponses.notAValidRequest;
import static com.tesco.services.resources.HTTPResponses.ok;
import static com.tesco.services.resources.HTTPResponses.serverError;

import com.tesco.services.adapters.core.*;
import io.dropwizard.configuration.ConfigurationException;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Semaphore;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;

import com.tesco.services.Configuration;
import com.tesco.services.exceptions.ImportInProgressException;
import com.tesco.services.exceptions.InvalidClrRunIdentifierException;
import com.tesco.services.utility.PriceConstants;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;

@Path("/admin")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class ImportResource {
	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(ImportResource.class);

	public static Semaphore importSemaphore = new Semaphore(1);
	public static Map<String, String> errorString = new HashMap<>();

	public static String getErrorString(String runIdentifier) {
		return errorString.get(runIdentifier);
	}

	public static void setErrorString(String runIdentifier, String error) {
		errorString.put(runIdentifier, error);
	}

	public static Semaphore getImportSemaphoreForIdentifier(String runIdentifier) {
		return importSemaphoreForIdentifier.get(runIdentifier);
	}

	public static Map<String, Semaphore> getImportSemaphoreForIdentifier() {
		return importSemaphoreForIdentifier;
	}

	public static Map<String, Semaphore> importSemaphoreForIdentifier = new HashMap<>();

	private Configuration configuration;

	// changes for dropwizard upgrade
	private Import importJob;
	private Import importMMJob;
	private Import importRPMClearanceJob;
	private Import importRPMZoneJob;
	private Import importSubGroupJob;
	private Import importPriceJob;
	private Import importProductAvgWeightJob;
	private Import importRPMZoneGroupJob;
	private Import importEstablishedPriceJob;
	private Import importFutureOfferDescJob;
	private Import importItemDefaultUomJob;

	@Inject
	public ImportResource(
			@Named("configuration") Configuration configuration,
			@Named("importJob") Import importJob,
			@Named("importMMJob") Import importMMJob,
			@Named("importRPMClearanceJob") Import importRPMClearanceJob,
			@Named("importRPMZoneJob") Import importRPMZoneJob,
			@Named("importSubGroupJob") Import importSubGroupJob,
			@Named("importPriceJob") Import importPriceJob,
			@Named("importProductAvgWeightJob") Import importProductAvgWeightJob,
			@Named("importRPMZoneGroupJob") Import importRPMZoneGroupJob,
			@Named("importEstablishedPriceJob") Import importEstablishedPriceJob,
			@Named("importFutureOfferDescJob") Import importFutureOfferDescJob,
			@Named("importItemDefaultUomJob") Import importItemDefaultUomJob) {
		this.configuration = configuration;
		this.importJob = importJob;
		this.importMMJob = importMMJob;
		this.importRPMClearanceJob = importRPMClearanceJob;
		this.importRPMZoneJob = importRPMZoneJob;
		this.importSubGroupJob = importSubGroupJob;
		this.importPriceJob = importPriceJob;
		this.importProductAvgWeightJob = importProductAvgWeightJob;
		this.importRPMZoneGroupJob = importRPMZoneGroupJob;
		this.importEstablishedPriceJob = importEstablishedPriceJob;
		this.importFutureOfferDescJob = importFutureOfferDescJob;
		this.importItemDefaultUomJob = importItemDefaultUomJob;
	}

	public static Semaphore getImportSemaphore() {
		return importSemaphore;
	}

	@POST
	@Path("/import")
	public Response importData() {
		/**
		 * Added by Salman - PS-242 added new condition to prevent importing
		 * data when one import is already in progress
		 **/
		if (!importSemaphore.tryAcquire()) {
			LOGGER.info("Import already running");

			throw new ImportInProgressException();
		}
		try {
			LOGGER.info(
					"RPM Import Job Started : Processing extracts from ",
					configuration.getRPMStoreDataPath() != null ? configuration
							.getRPMStoreDataPath().substring(
									0,
									configuration.getRPMStoreDataPath()
											.lastIndexOf("/"))
							: "unknown location");

			Thread importThread = new Thread(this.importJob);
			importThread.start();

		} catch (ConfigurationException e) {
			LOGGER.error("error : Import Failed {} {} ", serverError()
					.getStatusInfo().getStatusCode(), serverError()
					.getStatusInfo().getReasonPhrase());

			return serverError();
		}
		/* Added by Sushil - PS-83 added logger to log exceptions -End */
		return ok("{\"message\":\"Import Started.\"}");
	}

	/**
	 * Added by Salman - PS-242 added new GET call to check if import is
	 * completed or errored out
	 */
	@GET
	@Path("/importInProgress")
	/**
	 * Response isImportInProgress
	 */
	public Response isImportInProgress() {

		if (importSemaphore.availablePermits() < 1) {
			return ok("{\"import\":\"progress\"}");
		} else if (ImportJob.getErrorString() != null) {

			return ok(String.format(
					"{\"import\":\"aborted\",\n \"error\":\"%s\"}",
					ImportJob.getErrorString()));
		} else {
			return ok("{\"import\":\"completed\"}");
		}
	}

	@GET
	@Path("/importInProgress/{runIdentifier}")
	public Response isImportInProgressForrunIdentifier(
			@PathParam("runIdentifier") String runIdentifier) {

		if (importSemaphoreForIdentifier.get(runIdentifier).availablePermits() < 1) {
			return ok("{\"import\":\"progress\"}");
		} else if (getErrorString(runIdentifier) != null) {
			return ok(String.format(
					"{\"import\":\"aborted\",\n \"error\":\"%s\"}",
					getErrorString(runIdentifier)));
		} else {
			return ok("{\"import\":\"completed\"}");
		}
	}

	@POST
	@Path("/importMMClrData/{runIdentifier}")
	/**
	 * Response importMMData
	 */
	public Response importMMData(
			@PathParam("runIdentifier") String runIdentifier) {
		// boolean isValidRun = false;
		if (importSemaphoreForIdentifier.get(runIdentifier) == null) {
			importSemaphoreForIdentifier.put(runIdentifier, new Semaphore(1));
		}
		if (!importSemaphoreForIdentifier.get(runIdentifier).tryAcquire()) {
			LOGGER.info("Import already running");
			throw new ImportInProgressException();
		}

		try {

			Thread thread = new Thread(getImporMMJob(runIdentifier));
			thread.start();

		} catch (InvalidClrRunIdentifierException e) {
			getImportSemaphoreForIdentifier(runIdentifier).release();
			LOGGER.error(
					"error : Import MM Clearance Job not Started due to invalid Run Identifier- {} {}",
					notAValidRequest().getStatusInfo().getStatusCode(),
					notAValidRequest().getStatusInfo().getReasonPhrase());
			return notAValidRequest();
		}
		return ok("{\"message\":\"Import MM Clearance Job Started.\"}");
	}

	/**
	 * @param runIdentifier
	 * @return
	 * @throws InvalidClrRunIdentifierException
	 */
	public Import getImporMMJob(String runIdentifier)
			throws InvalidClrRunIdentifierException {

		boolean isValidRun = false;
		setErrorString(runIdentifier, null);
		String[] runTypes = configuration.getMmClrTypes();
		for (String runType : runTypes) {
			if (runType.equalsIgnoreCase(runIdentifier)) {
				isValidRun = true;
			}
		}
		if (!isValidRun) {
			throw new InvalidClrRunIdentifierException(
					"Not a Valid Run Identifier");

		}
		((ImportMMJob) importMMJob).setRunIdentifier(runIdentifier);
		return this.importMMJob;
	}

	/* Added for PS-386 -- Start */
	@POST
	@Path("/importRPMClearance/{runIdentifier}")
	public Response importRPMClearanceData(
			@PathParam("runIdentifier") String runIdentifier) {

		if (importSemaphoreForIdentifier.get(runIdentifier) == null) {
			importSemaphoreForIdentifier.put(runIdentifier, new Semaphore(1));
		}
		if (!importSemaphoreForIdentifier.get(runIdentifier).tryAcquire()) {
			LOGGER.info("Import already running");
			throw new ImportInProgressException();
		}
		try {

			Thread thread = new Thread(getImporRPMClearanceJob(runIdentifier));
			thread.start();

		} catch (InvalidClrRunIdentifierException e) {
			getImportSemaphoreForIdentifier(runIdentifier).release();
			LOGGER.error(
					"error : Import RPM Clearance Job not Started due to invalid Run Identifier- {} {}",
					notAValidRequest().getStatusInfo().getStatusCode(),
					notAValidRequest().getStatusInfo().getReasonPhrase());
			return notAValidRequest();
		}
		return ok("{\"message\":\"Import RPM Clearance Job Started.\"}");
	}

	/* Added for PS-386 -- End */

	/**
	 * @param runIdentifier
	 * @return
	 * @throws InvalidClrRunIdentifierException
	 */
	public Import getImporRPMClearanceJob(String runIdentifier)
			throws InvalidClrRunIdentifierException {

		boolean isValidRun = false;
		setErrorString(runIdentifier, null);

		String[] runTypes = configuration.getRpmClrTypes();
		for (String runType : runTypes) {
			if (runType.equalsIgnoreCase(runIdentifier)) {
				isValidRun = true;
			}
		}
		if (!isValidRun) {
			throw new InvalidClrRunIdentifierException(
					"Not a Valid Run Identifier");

		}
		((ImportRPMClearanceJob)importRPMClearanceJob).setRunIdentifier(runIdentifier);
		return importRPMClearanceJob;
	}

	/**
	 * Response importOnetimeRPMZone
	 */
	@POST
	@Path("/importRPMZone/{runIdentifier}/{fileName}")
	public Response importRPMZone(
			@PathParam("runIdentifier") String runIdentifier,
			@PathParam("fileName") String fileName) {

		if (importSemaphoreForIdentifier.get(fileName) == null) {
			importSemaphoreForIdentifier.put(fileName, new Semaphore(1));
		}

		if (!importSemaphoreForIdentifier.get(fileName).tryAcquire()) {
			LOGGER.info("Import already running");
			throw new ImportInProgressException();
		}

		try {
			Thread thread = new Thread(
					getImportRPMZone(runIdentifier, fileName));
			thread.start();

		} catch (InvalidClrRunIdentifierException e) {
			getImportSemaphoreForIdentifier(fileName).release();
			LOGGER.error(
					"error : Import RPM Onetime Zone load Job not Started due to invalid Run Identifier- {} {}",
					notAValidRequest().getStatusInfo().getStatusCode(),
					notAValidRequest().getStatusInfo().getReasonPhrase());
			return notAValidRequest();
		}
		return ok("{\"message\":\"Import RPM Onetime Zone load Job Started.\"}");
	}

	/**
	 * @param runIdentifier
	 * @return
	 * @throws InvalidClrRunIdentifierException
	 */
	public Import getImportRPMZone(String runIdentifier, String fileName)
			throws InvalidClrRunIdentifierException {

		boolean isValidRun = false;
		setErrorString(runIdentifier, null);

		String runTypes = PriceConstants.ONETIME_RPM_ZONE;
		if (runTypes.equalsIgnoreCase(runIdentifier)) {
			isValidRun = true;
		}

		if (!isValidRun) {
			throw new InvalidClrRunIdentifierException(
					"Not a Valid Run Identifier");
		}
		((ImportRPMZoneJob)importRPMZoneJob).setRunIdentifier(runIdentifier);
		((ImportRPMZoneJob)importRPMZoneJob).setFileName(fileName);
		return importRPMZoneJob;
	}

	/**
	 * @param runIdentifier
	 * @return
	 * @throws InvalidClrRunIdentifierException
	 */
	public Import getImportSubGroupDefaultMapping(String runIdentifier,
			String fileName) throws InvalidClrRunIdentifierException {

		boolean isValidRun = false;
		setErrorString(runIdentifier, null);

		String runTypes = PriceConstants.SUBGRP_DFLT_RUN_IDENTIFIER;
		if (runTypes.equalsIgnoreCase(runIdentifier)) {
			isValidRun = true;
		}

		if (!isValidRun) {
			throw new InvalidClrRunIdentifierException(
					"Not a Valid Run Identifier");
		}
		((ImportSubGroupDfltUomJob)importSubGroupJob).setFileName(fileName);
		((ImportSubGroupDfltUomJob)importSubGroupJob).setRunIdentifier(runIdentifier);
		return importSubGroupJob;
	}

	/**
	 * Endpoint to trigger onetime price import
	 */

	@POST
	@Path("/importPrice/{runIdentifier}/{fileName}")
	public Response importPrice(
			@PathParam("runIdentifier") String runIdentifier,
			@PathParam("fileName") String fileName) {

		if (importSemaphoreForIdentifier.get(fileName) == null) {
			importSemaphoreForIdentifier.put(fileName, new Semaphore(1));
		}

		if (!importSemaphoreForIdentifier.get(fileName).tryAcquire()) {
			LOGGER.info("Price Import already running");
			throw new ImportInProgressException();
		}

		try {
			if (!PriceConstants.ONETIME_PRICE.equalsIgnoreCase(runIdentifier)) {
				throw new InvalidClrRunIdentifierException(
						"invalid runidentifier for onetime price Import");
			}
			Thread thread = new Thread(getImportPriceJob(runIdentifier,
					fileName));
			thread.start();

		} catch (InvalidClrRunIdentifierException e) {
			getImportSemaphoreForIdentifier(fileName).release();
			LOGGER.error(
					"error : Import Price OneTime Job not Started due to invalid Run Identifier- {} {}",
					notAValidRequest().getStatusInfo().getStatusCode(),
					notAValidRequest().getStatusInfo().getReasonPhrase());
			return notAValidRequest();
		}
		return ok("{\"message\":\"Import Price Onetime load Job Started.\"}");

	}

	public Import getImportPriceJob(String runIdentifier, String fileName)
			throws InvalidClrRunIdentifierException {
		if (!PriceConstants.ONETIME_PRICE.equalsIgnoreCase(runIdentifier)) {
			throw new InvalidClrRunIdentifierException(
					"invalid runidentifier for onetime price Import");
		}
		((ImportPriceJob) importPriceJob).setRunIdentifier(runIdentifier);
		((ImportPriceJob) importPriceJob).setFileName(fileName);
		return importPriceJob;
	}

	/**
	 * Response importSubGroupDefault
	 */
	@POST
	@Path("/importSubGroupDefault/{runIdentifier}/{fileName}")
	public Response importMapping(
			@PathParam("runIdentifier") String runIdentifier,
			@PathParam("fileName") String fileName) {

		if (importSemaphoreForIdentifier.get(fileName) == null) {
			importSemaphoreForIdentifier.put(fileName, new Semaphore(1));
		}

		if (!importSemaphoreForIdentifier.get(fileName).tryAcquire()) {
			LOGGER.info("Import already running");
			throw new ImportInProgressException();
		}

		try {
			Thread thread = new Thread(getImportSubGroupDefaultMapping(
					runIdentifier, fileName));
			thread.start();

		} catch (InvalidClrRunIdentifierException e) {
			LOGGER.error(
					"error : Import RPM Onetime SubGroup Default UOM JOb not Started due to invalid Run Identifier- {} {}",
					notAValidRequest().getStatusInfo().getStatusCode(),
					notAValidRequest().getStatusInfo().getReasonPhrase());
			return notAValidRequest();
		} finally {
			getImportSemaphoreForIdentifier(fileName).release();
		}
		return ok("{\"message\":\"Import RPM Onetime SubGroup Default UOM Job Started.\"}");
	}

	/**
	 * Endpoint to trigger onetime price import
	 */

	@POST
	@Path("/importavgweight/{runIdentifier}/{fileName}")
	public Response importProductAvgWieight(
			@PathParam("runIdentifier") String runIdentifier,
			@PathParam("fileName") String fileName) {

		if (importSemaphoreForIdentifier.get(fileName) == null) {
			importSemaphoreForIdentifier.put(fileName, new Semaphore(1));
		}

		if (!importSemaphoreForIdentifier.get(fileName).tryAcquire()) {
			LOGGER.info("Product Avg Weight Import already running");
			throw new ImportInProgressException();
		}

		try {
			if (!((PriceConstants.SONETTO_UK.equalsIgnoreCase(runIdentifier)) || PriceConstants.SONETTO_ROI
					.equalsIgnoreCase(runIdentifier))) {
				throw new InvalidClrRunIdentifierException(
						"invalid runidentifier for product avg weight Import");
			}

			Thread thread = new Thread(getImportProductAvgWeightJob(fileName,
					runIdentifier));
			thread.start();

		} catch (InvalidClrRunIdentifierException e) {
			getImportSemaphoreForIdentifier(fileName).release();
			LOGGER.error(
					"error : Import Product Avg Weight Job not Started due to invalid Run Identifier- {} {}",
					notAValidRequest().getStatusInfo().getStatusCode(),
					notAValidRequest().getStatusInfo().getReasonPhrase());
			return notAValidRequest();
		}
		return ok("{\"message\":\"Import Product Avg Weight Job Started.\"}");

	}

	public Import getImportProductAvgWeightJob(String fileName,
			String runIdentifier) throws InvalidClrRunIdentifierException {

		if (!((PriceConstants.SONETTO_UK.equalsIgnoreCase(runIdentifier)) || PriceConstants.SONETTO_ROI
				.equalsIgnoreCase(runIdentifier))) {
			throw new InvalidClrRunIdentifierException(
					"invalid runidentifier for product avg weight Import");
		}

		((ImportProductAvgWeightJob) importProductAvgWeightJob)
				.setFileName(fileName);
		((ImportProductAvgWeightJob) importProductAvgWeightJob)
				.setRunIdentifier(runIdentifier);
		return importProductAvgWeightJob;

	}

	@GET
	@Path("/importInProgress/{runIdentifier}/{fileName}")
	public Response isImportInProgressFoRunIdentifierAndFileName(
			@PathParam("runIdentifier") String runIdentifier,
			@PathParam("fileName") String fileName) {

		if (importSemaphoreForIdentifier.get(fileName).availablePermits() < 1) {
			return ok("{\"import\":\"progress\"}");
		} else if (getErrorString(fileName) != null) {
			return ok(String.format(
					"{\"import\":\"aborted\",\n \"error\":\"%s\"}",
					getErrorString(fileName)));
		} else {
			return ok("{\"import\":\"completed\"}");
		}
	}

	/**
	 * Response importOnetimeRPMZone
	 */
	@POST
	@Path("/importRPMZoneGroup/{runIdentifier}/{fileName}")
	public Response importRPMZoneGroup(
			@PathParam("runIdentifier") String runIdentifier,
			@PathParam("fileName") String fileName) {

		if (importSemaphoreForIdentifier.get(fileName) == null) {
			importSemaphoreForIdentifier.put(fileName, new Semaphore(1));
		}

		if (!importSemaphoreForIdentifier.get(fileName).tryAcquire()) {
			LOGGER.info("Import already running");
			throw new ImportInProgressException();
		}

		try {
			Thread thread = new Thread(getImportRPMZoneGroup(runIdentifier,
					fileName));
			thread.start();

		} catch (InvalidClrRunIdentifierException e) {
			getImportSemaphoreForIdentifier(fileName).release();
			LOGGER.error(
					"error : Import RPM Onetime Zone Group load Job not Started due to invalid Run Identifier- {} {}",
					notAValidRequest().getStatusInfo().getStatusCode(),
					notAValidRequest().getStatusInfo().getReasonPhrase());
			return notAValidRequest();
		}
		return ok("{\"message\":\"Import RPM Onetime Zone Group load Job Started.\"}");
	}

	/**
	 * @param runIdentifier
	 * @return
	 * @throws InvalidClrRunIdentifierException
	 */
	public Import getImportRPMZoneGroup(String runIdentifier, String fileName)
			throws InvalidClrRunIdentifierException {

		boolean isValidRun = false;
		setErrorString(fileName, null);

		String runTypes = PriceConstants.ONETIME_RPM_ZONE_GROUP;
		if (runTypes.equalsIgnoreCase(runIdentifier)) {
			isValidRun = true;
		}

		if (!isValidRun) {
			throw new InvalidClrRunIdentifierException(
					"Not a Valid Run Identifier");
		}
		((ImportRPMZoneGroupJob)importRPMZoneGroupJob).setRunIdentifier(runIdentifier);
		((ImportRPMZoneGroupJob)importRPMZoneGroupJob).setFileName(fileName);
		return this.importRPMZoneGroupJob;
	}

	/**
	 * Response importEstablishedPrice
	 */

	@POST
	@Path("/importEstablishedPrice/{runIdentifier}/{fileName}")
	public Response importEstablishedPrice(
			@PathParam("runIdentifier") String runIdentifier,
			@PathParam("fileName") String fileName) {

		if (importSemaphoreForIdentifier.get(fileName) == null) {
			importSemaphoreForIdentifier.put(fileName, new Semaphore(1));
		}

		if (!importSemaphoreForIdentifier.get(fileName).tryAcquire()) {
			LOGGER.info("Import already running");
			throw new ImportInProgressException();
		}

		try {
			Thread thread = new Thread(getImportEstablishedPrice(runIdentifier,
					fileName));
			thread.start();

		} catch (InvalidClrRunIdentifierException e) {
			getImportSemaphoreForIdentifier(fileName).release();
			LOGGER.error(
					"error : Import Established Price load Job not Started due to invalid Run Identifier- {} {}",
					notAValidRequest().getStatusInfo().getStatusCode(),
					notAValidRequest().getStatusInfo().getReasonPhrase());
			return notAValidRequest();
		}
		return ok("{\"message\":\"Import Established Price load Job Started.\"}");
	}

	@POST
	@Path("/importFutureOfferDesc/{runIdentifier}/{fileName}")
	public Response importFutureOfferDesc(
			@PathParam("runIdentifier") String runIdentifier,
			@PathParam("fileName") String fileName) {

		if (importSemaphoreForIdentifier.get(fileName) == null) {
			importSemaphoreForIdentifier.put(fileName, new Semaphore(1));
		}

		if (!importSemaphoreForIdentifier.get(fileName).tryAcquire()) {
			LOGGER.info("Import already running");
			throw new ImportInProgressException();
		}

		try {
			Thread thread = new Thread(getImportFutureOfferDesc(runIdentifier,
					fileName));
			thread.start();

		} catch (InvalidClrRunIdentifierException e) {
			getImportSemaphoreForIdentifier(fileName).release();
			LOGGER.error(
					"error : Import Future offer description load Job not Started due to invalid Run Identifier- {} {}",
					notAValidRequest().getStatusInfo().getStatusCode(),
					notAValidRequest().getStatusInfo().getReasonPhrase());
			return notAValidRequest();
		}
		return ok("{\"message\":\"Import future offer description load Job Started.\"}");
	}

	/**
	 * @param runIdentifier
	 * @return
	 * @throws InvalidClrRunIdentifierException
	 */
	public Import getImportEstablishedPrice(String runIdentifier,
			String fileName) throws InvalidClrRunIdentifierException {

		boolean isValidRun = false;
		setErrorString(fileName, null);

		String runTypes = PriceConstants.ESTABLISHED_PRICE;
		if (runTypes.equalsIgnoreCase(runIdentifier)) {
			isValidRun = true;
		}

		if (!isValidRun) {
			throw new InvalidClrRunIdentifierException(
					"Not a Valid Run Identifier");
		}
		((ImportEstablishedPriceJob)importEstablishedPriceJob).setFileName(fileName);
		((ImportEstablishedPriceJob)importEstablishedPriceJob).setRunIdentifier(runIdentifier);
		return this.importEstablishedPriceJob;
	}

	/**
	 * @param runIdentifier
	 * @return
	 * @throws InvalidClrRunIdentifierException
	 */
	public Import getImportFutureOfferDesc(String runIdentifier, String fileName)
			throws InvalidClrRunIdentifierException {

		boolean isValidRun = false;
		setErrorString(fileName, null);

		if (PriceConstants.FUTURE_OFFER_DESC.equalsIgnoreCase(runIdentifier)
				|| PriceConstants.FUTURE_OFFER_DESC_ONETIME
						.equalsIgnoreCase(runIdentifier)) {
			isValidRun = true;
		}

		if (!isValidRun) {
			throw new InvalidClrRunIdentifierException(
					"Not a Valid Run Identifier");
		}
		((ImportFutureOfferDescJob)importFutureOfferDescJob).setFileName(fileName);
		((ImportFutureOfferDescJob)importFutureOfferDescJob).setRunIdentifier(runIdentifier);
		return this.importFutureOfferDescJob;
	}

	/**
	 * @param runIdentifier
	 * @return
	 * @throws InvalidClrRunIdentifierException
	 */
	public Import getImportItemDefaultMapping(String runIdentifier,
			String fileName) throws InvalidClrRunIdentifierException {

		setErrorString(runIdentifier, null);

		String runTypes = PriceConstants.ITEM_DEFAULT_UOM_RUNIDENTIFIER;
		if (!runTypes.equalsIgnoreCase(runIdentifier)) {
			throw new InvalidClrRunIdentifierException(
					"Not a Valid Run Identifier " + runIdentifier);
		}
		((ImportItemDefaultUomJob)importItemDefaultUomJob).setFileName(fileName);
		((ImportItemDefaultUomJob)importItemDefaultUomJob).setRunIdentifier(runIdentifier);
		return this.importItemDefaultUomJob;
	}

	/**
	 * Response importItemDefaultUom
	 */
	@POST
	@Path("/importItemDefaultUom/{runIdentifier}/{fileName}")
	public Response importItemDefaultMapping(
			@PathParam("runIdentifier") String runIdentifier,
			@PathParam("fileName") String fileName) {

		if (importSemaphoreForIdentifier.get(fileName) == null) {
			importSemaphoreForIdentifier.put(fileName, new Semaphore(1));
		}

		if (!importSemaphoreForIdentifier.get(fileName).tryAcquire()) {
			LOGGER.info("Import already running");
			throw new ImportInProgressException();
		}

		try {
			Thread thread = new Thread(getImportItemDefaultMapping(
					runIdentifier, fileName));
			thread.start();

		} catch (InvalidClrRunIdentifierException e) {
			LOGGER.error(
					"error : Import Item Default UOM JOb not Started due to invalid Run Identifier- {} {}",
					notAValidRequest().getStatusInfo().getStatusCode(),
					notAValidRequest().getStatusInfo().getReasonPhrase());
			return notAValidRequest();
		} finally {
			getImportSemaphoreForIdentifier(fileName).release();
		}
		return ok("{\"message\":\"Import Item Default UOM Job Started.\"}");
	}

}