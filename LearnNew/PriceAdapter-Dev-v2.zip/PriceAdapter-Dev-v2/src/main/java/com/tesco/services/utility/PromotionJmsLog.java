package com.tesco.services.utility;

/**
 * Created by yp21 on 14/06/2016.
 */
public interface PromotionJmsLog {

	public void updateCounterForCreMsg(String docType);

	public void updateCounterForModMsg(String docType);

	public String printMetricsSnasphot();
	
	public void resetMetricsSnapshot();
}
