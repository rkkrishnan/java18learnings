package com.tesco.services.adapters.core.exceptions;

public class PromotionEventException extends Exception {

	public PromotionEventException(String message) {
		super(message);
	}

	public PromotionEventException(Exception exception) {
		super(exception);
	}
	
	public PromotionEventException(String message,Exception exception) {
		super(message,exception);
	}

}
