package com.tesco.services.core;
//Interface PriceVisitable
public interface PriceVisitable {
    public void accept(ProductPriceVisitor visitor);
    public void accept(ProductPriceVisitor visitor,String tpnb);
}
