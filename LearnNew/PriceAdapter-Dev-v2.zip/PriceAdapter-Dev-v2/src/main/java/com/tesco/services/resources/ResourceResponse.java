package com.tesco.services.resources;

import javax.ws.rs.core.MediaType;

/*ResourceResponse class*/
public class ResourceResponse {
    public static final String RESPONSE_TYPE = MediaType.APPLICATION_JSON + "; charset=utf-8";

}
