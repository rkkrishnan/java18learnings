package com.tesco.services.adapters.core.utils;

import com.codahale.metrics.Counter;
import com.codahale.metrics.JmxReporter;
import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.Timer;
import com.codahale.metrics.Timer.Context;

public class RPMClearanceMetrics {
	private static RPMClearanceMetrics rpmClearanceMetrics;
	private static MetricRegistry metricsRegistry;

	static Timer rpmClearanceMessagesCre;
	Context rpmClearanceMessagesCreTC;

	static Timer rpmClearanceMessagesMod;
	Context rpmClearanceMessagesModTC;

	static Timer rpmClearanceMessagesDel;
	Context rpmClearanceMessagesDelTC;

	static Timer messageListenerTimer;
	Context messageTimerContext;

	static Counter creErrorCounter;
	static Counter modErrorCounter;
	static Counter delErrorCounter;

	private RPMClearanceMetrics() {
		rpmClearanceMetrics = null;
	}

	public static MetricRegistry getMetricsRegistry() {
		return metricsRegistry;
	}

	public static synchronized RPMClearanceMetrics getInstance() {
		if (rpmClearanceMetrics == null) {
			rpmClearanceMetrics = new RPMClearanceMetrics();
			metricsRegistry = new MetricRegistry();
			JmxReporter.forRegistry(metricsRegistry).build();
			initMetrics(metricsRegistry);
		}
		return rpmClearanceMetrics;
	}

	private static void initMetrics(MetricRegistry metricRegisty) {

		rpmClearanceMessagesCre = metricRegisty.timer(MetricRegistry.name(
				"com.tesco", "RPMClearanceElapsedTimeAndRate",
				"time-to-process-cre-message"));

		rpmClearanceMessagesMod = metricRegisty.timer(MetricRegistry.name(
				"com.tesco", "RPMClearanceElapsedTimeAndRate",
				"time-to-process-mod-message"));

		rpmClearanceMessagesDel = metricRegisty.timer(MetricRegistry.name(
				"com.tesco", "RPMClearanceElapsedTimeAndRate",
				"time-to-process-del-message"));

		messageListenerTimer = metricRegisty.timer(MetricRegistry.name(
				"com.tesco", "RPMClearanceElapsedTimeAndRate",
				"time-to-process-message"));

		creErrorCounter = metricRegisty.counter(MetricRegistry.name(
				"com.tesco", "RPMClearanceMessageProcessingErrors",
				"total-cre-error-message-count"));

		modErrorCounter = metricRegisty.counter(MetricRegistry.name(
				"com.tesco", "RPMClearanceMessageProcessingErrors",
				"total-mod-error-message-count"));

		delErrorCounter = metricRegisty.counter(MetricRegistry.name(
				"com.tesco", "RPMClearanceMessageProcessingErrors",
				"total-del-error-message-count"));
	}

	public void logCreClearanceProcessingStartTime() {
		rpmClearanceMessagesCreTC = rpmClearanceMessagesCre.time();
	}

	public void logCreClearanceProcessingEndTime() {
		rpmClearanceMessagesCreTC.stop();
	}

	public void logModClearanceProcessingStartTime() {
		rpmClearanceMessagesModTC = rpmClearanceMessagesMod.time();
	}

	public void logModClearanceProcessingEndTime() {
		rpmClearanceMessagesModTC.stop();
	}

	public void logDelClearanceProcessingStartTime() {
		rpmClearanceMessagesDelTC = rpmClearanceMessagesDel.time();
	}

	public void logDelClearanceProcessingEndTime() {
		rpmClearanceMessagesDelTC.stop();
	}

	public void logMessageProcessingStartTime() {
		messageTimerContext = messageListenerTimer.time();
	}

	public void logMessageProcessingEndTime() {
		messageTimerContext.stop();
	}

	public void incrementCreErrorCount() {
		creErrorCounter.inc();
	}

	public void incrementModErrorCount() {
		modErrorCounter.inc();
	}

	public void incrementDelErrorCount() {
		delErrorCounter.inc();
	}

	public void resetCounters() {
		new RPMClearanceMetrics();
		getInstance();
	}
}
