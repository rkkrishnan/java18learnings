package com.tesco.services.adapters.zone.impl;

import com.google.common.base.Optional;
import com.tesco.services.adapters.rpm.writers.ZoneMessageWriter;
import com.tesco.services.adapters.zone.ZoneHandler;
import com.tesco.services.core.Store;
import com.tesco.services.core.ZoneEntity;
import com.tesco.services.core.zone.ZoneGrpEntity;
import com.tesco.services.exceptions.DataAccessException;
import com.tesco.services.exceptions.ZoneBusinessException;
import com.tesco.services.repositories.Repository;
import com.tesco.services.repositories.RepositoryImpl;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.PriceConstants;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;
import com.tesco.zone.core.TSLZone;
import com.tesco.zone.core.TSLZoneGroupDesc;
import com.tesco.zone.core.TSLZoneGroupRef;
import com.tesco.zone.core.TSLZoneLocRef;
import com.tesco.zone.core.TSLZoneRef;

import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;

import java.util.*;

public class ZoneHandlerImpl implements ZoneHandler {

	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(ZoneHandlerImpl.class);

	private ZoneMessageWriter zoneWriter;
	private Repository repository;

	@Inject
	public ZoneHandlerImpl(@Named("zoneJMSWriter") ZoneMessageWriter zoneWriter,
			@Named("repository") Repository repository) {
		this.zoneWriter = zoneWriter;
		this.repository = repository;
	}

	@Override
	public void processZoneGroupCre(TSLZoneGroupDesc tslZoneGroupDesc,
			String zoneMsgType) throws ZoneBusinessException {
		List<String> zoneIds = new ArrayList<String>();
		try {
			ZoneGrpEntity zoneGrpEntity = constructZoneGroupEntityFromMsg(
					tslZoneGroupDesc, zoneMsgType);

			Map<String, ZoneEntity> zoneEntities = constructZoneEntityFromMsg(
					tslZoneGroupDesc, zoneGrpEntity, zoneMsgType);

			zoneWriter.writeZoneGrpMessage(zoneGrpEntity, zoneEntities,
					zoneMsgType);
			for (Map.Entry<String, ZoneEntity> entry : zoneEntities.entrySet()) {
				zoneIds.add(entry.getValue().getZoneId());
			}
			zoneWriter.modifyZoneGroupData(zoneIds,
					PriceConstants.ZONE_MSG_TYPE_CRE);
		} catch (ZoneBusinessException jpe) {
			LOGGER.error("Error occurred in processZoneGroupCre method.", jpe);
			throw jpe;
		}

	}

	@Override
	public void processZoneCre(TSLZoneGroupDesc tslZoneGroupDesc,
			String zoneMsgType) throws ZoneBusinessException {
		ZoneGrpEntity zoneGrpEntity = null;
		Map<String, ZoneEntity> zoneEntities;
		List<String> zoneIds = new ArrayList<String>();
		try {
			zoneEntities = constructZoneEntityFromMsg(tslZoneGroupDesc,
					zoneGrpEntity, zoneMsgType);

			if (Dockyard.isSpaceOrNull(zoneEntities)) {
				throw new ZoneBusinessException(
						"Error while processing Zone Cre message");
			}
			zoneWriter.writeZoneMessage(zoneEntities, zoneMsgType);

			for (Map.Entry<String, ZoneEntity> entry : zoneEntities.entrySet()) {
				zoneIds.add(entry.getValue().getZoneId());
			}
			zoneWriter.modifyZoneGroupData(zoneIds,
					PriceConstants.ZONE_MSG_TYPE_CRE);

		} catch (ZoneBusinessException jpe) {
			LOGGER.error("Error occurred in processZoneCre method.", jpe);
			throw jpe;
		}
	}

	@Override
	public void processZoneLocationCre(TSLZoneGroupDesc tslZoneGroupDesc,
			String zoneMsgType) throws ZoneBusinessException {
		ZoneGrpEntity zoneGrpEntity = null;
		Map<String, ZoneEntity> zoneEntities = new HashMap<String, ZoneEntity>();
		try {
			zoneEntities = constructZoneEntityFromMsg(tslZoneGroupDesc,
					zoneGrpEntity, zoneMsgType);

			if (!Dockyard.isSpaceOrNull(zoneEntities)) {
				zoneWriter.writeZoneMessage(zoneEntities, zoneMsgType);
			} else {
				throw new ZoneBusinessException(
						"Error occured while Processing Zone Location Cre message");
			}
		} catch (ZoneBusinessException jpe) {
			LOGGER.error("Error occurred in processZoneLocationCre method.",
					jpe);
			throw jpe;
		}

		for (Map.Entry<String, ZoneEntity> entry : zoneEntities.entrySet()) {
			List storeIds = entry.getValue().getStoreIds();
			Map<String, Store> storeEntities = constructStoreEntity(storeIds,
					entry.getValue(), zoneMsgType);

			zoneWriter.writeStoreDataFromMessage(storeEntities);
		}

	}

	@Override
	public void processZoneGroupMod(TSLZoneGroupDesc tslZoneGroupDesc,
			String zoneMsgType) throws ZoneBusinessException {
		try {
			ZoneGrpEntity zoneGrpEntity = constructZoneGroupEntityFromMsg(
					tslZoneGroupDesc, zoneMsgType);

			if (!Dockyard.isSpaceOrNull(zoneGrpEntity)) {

				Map zoneEntities = constructZoneEntityFromMsg(tslZoneGroupDesc,
						zoneGrpEntity, zoneMsgType);

				zoneWriter.writeZoneGrpMessage(zoneGrpEntity, zoneEntities,
						zoneMsgType);
			} else {
				throw new ZoneBusinessException(
						"Error while processing zone group Mod message");
			}
		} catch (ZoneBusinessException jpe) {
			LOGGER.error("Error occurred in processZoneGroupMod method.", jpe);
			throw jpe;
		}

	}

	@Override
	public void processZoneMod(TSLZoneGroupDesc tslZoneGroupDesc,
			String zoneMsgType) throws ZoneBusinessException {
		ZoneGrpEntity zoneGrpEntity = null;
		try {
			Map zoneEntities = constructZoneEntityFromMsg(tslZoneGroupDesc,
					zoneGrpEntity, zoneMsgType);

			zoneWriter.writeZoneMessage(zoneEntities, zoneMsgType);
		} catch (ZoneBusinessException jpe) {
			LOGGER.error("Error occurred in processZoneMod method.", jpe);
			throw jpe;
		}
	}

	public ZoneGrpEntity constructZoneGroupEntityFromMsg(
			TSLZoneGroupDesc tslZoneGroupDesc, String zoneMsgType)
			throws ZoneBusinessException {
		Set<String> rejectedProducts = new HashSet<>();
		ZoneGrpEntity zoneGrpEntity = new ZoneGrpEntity();

		if (PriceConstants.ZONE_GRP_MSG_TYPE_CRE.equals(zoneMsgType)) {
			zoneGrpEntity.setZoneGroupId(tslZoneGroupDesc.getZoneGroupId()
					.toString());
			zoneGrpEntity.setZoneGroupName(tslZoneGroupDesc.getZoneGroupName()
					.toString());
			zoneGrpEntity
					.setZoneGroupType(tslZoneGroupDesc.getTSLZoneGroupType()
							.get(0).getZoneGroupType().toString());
			zoneGrpEntity.setCreatedDate(Dockyard
					.getSysDate(PriceConstants.ISO_8601_FORMAT));
			zoneGrpEntity.setCreatedById("RPM");
			zoneGrpEntity.setLastUpdateDate(Dockyard
					.getSysDate(PriceConstants.ISO_8601_FORMAT));
			zoneGrpEntity.setLastUpdatedById("RPM");
		} else if (PriceConstants.ZONE_GRP_MSG_TYPE_MOD.equals(zoneMsgType)) {

			String zoneGrpKey = PriceConstants.ZONE_GRP_KEY
					+ tslZoneGroupDesc.getZoneGroupId();
			try {
				ZoneGrpEntity zoneGrpDoc = (ZoneGrpEntity) repository
						.getGenericObject(zoneGrpKey, ZoneGrpEntity.class);
				if (Dockyard.isSpaceOrNull(zoneGrpDoc)) {
					LOGGER.info("Zone group document is not available to modify for zone group - "
							+ tslZoneGroupDesc.getZoneGroupId());
					LOGGER.error("Zone group document is not available to modify for zone group - "
							+ tslZoneGroupDesc.getZoneGroupId());
					rejectedProducts
							.add("Zone group document is not available to modify for zone group - "
									.concat(String.valueOf(tslZoneGroupDesc
											.getZoneGroupId())));
				}
				if (!Dockyard.isSpaceOrNull(zoneGrpDoc)) {
					zoneGrpEntity.setCreatedById(zoneGrpDoc.getCreatedById());
					zoneGrpEntity.setCreatedDate(zoneGrpDoc.getCreatedDate());
					if (Dockyard
							.isSpaceOrNull(zoneGrpEntity.getZoneGroupType())
							|| zoneGrpEntity.getZoneGroupType().isEmpty()) {
						zoneGrpEntity.setZoneGroupType(zoneGrpDoc
								.getZoneGroupType());
					}
					zoneGrpEntity.setZoneIds(zoneGrpDoc.getZoneIds());
				} else {
					zoneGrpEntity.setCreatedDate(Dockyard
							.getSysDate(PriceConstants.ISO_8601_FORMAT));
					zoneGrpEntity.setCreatedById("RPM");
				}
				zoneGrpEntity.setLastUpdateDate(Dockyard
						.getSysDate(PriceConstants.ISO_8601_FORMAT));
				zoneGrpEntity.setLastUpdatedById("RPM");
				zoneGrpEntity.setZoneGroupId(tslZoneGroupDesc.getZoneGroupId()
						.toString());
				zoneGrpEntity.setZoneGroupName(tslZoneGroupDesc
						.getZoneGroupName().toString());
			} catch (DataAccessException e) {
				throw new ZoneBusinessException(e);
			}
		}

		if (!rejectedProducts.isEmpty()) {
			zoneWriter.writeRejects(rejectedProducts);
			rejectedProducts.clear();
			throw new ZoneBusinessException(
					"Error while Modifying the zone group document");
		}

		return zoneGrpEntity;
	}

	public Map<String, ZoneEntity> constructZoneEntityFromMsg(
			TSLZoneGroupDesc tslZoneGroupDesc, ZoneGrpEntity zoneGrpEntity,
			String zoneMsgType) throws ZoneBusinessException {
		Set<String> rejectedProducts = new HashSet<>();
		Map<String, ZoneEntity> zoneEntities = new HashMap<String, ZoneEntity>();
		String zoneGrpName = null;
		String zoneGrpType = null;
		String zoneGrpId = String.valueOf(tslZoneGroupDesc.getZoneGroupId());
		String zoneGrpDocKey = PriceConstants.ZONE_GRP_KEY + zoneGrpId;
		try {
			ZoneGrpEntity zoneGrpEntityDoc = (ZoneGrpEntity) repository
					.getGenericObject(zoneGrpDocKey, ZoneGrpEntity.class);

			if (PriceConstants.ZONE_MSG_TYPE_CRE.equals(zoneMsgType)
					|| PriceConstants.ZONE_LOC_MSG_TYPE_CRE.equals(zoneMsgType)
					|| PriceConstants.ZONE_MSG_TYPE_MOD.equals(zoneMsgType)) {

				if (Dockyard.isSpaceOrNull(zoneGrpEntityDoc)) {
					LOGGER.error(
							"The Zone Group Document is unavailable for the zone group id -  ",
							zoneGrpId);
					rejectedProducts
							.add("The Zone Group Document is unavailable for the zone group id -"
									.concat(zoneGrpId));

				} else {
					zoneGrpName = zoneGrpEntityDoc.getZoneGroupName();
					zoneGrpType = zoneGrpEntityDoc.getZoneGroupType();
				}

			} else if (PriceConstants.ZONE_GRP_MSG_TYPE_MOD.equals(zoneMsgType)) {

				zoneGrpName = zoneGrpEntity.getZoneGroupName();
				zoneGrpType = zoneGrpEntity.getZoneGroupType();

			}
		} catch (DataAccessException e) {
			throw new ZoneBusinessException(e);
		}
		for (int i = 0; i < tslZoneGroupDesc.getTSLZone().size(); i++) {
			String zoneId = String.valueOf(tslZoneGroupDesc.getTSLZone().get(i)
					.getZoneId());
			String zoneKey = PriceConstants.ZONE_KEY + zoneId;
			ZoneEntity zoneDoc = null;
			try {
				zoneDoc = (ZoneEntity) repository
						.getGenericObject(zoneKey,ZoneEntity.class);
			} catch (DataAccessException e) {
				throw new ZoneBusinessException(e);
			}
			if (PriceConstants.ZONE_LOC_MSG_TYPE_CRE.equals(zoneMsgType)
					&& Dockyard.isSpaceOrNull(zoneDoc)) {
				LOGGER.error(
						"While processing the Loc CRE , the Zone Document is unavailable for the zone id -  ",
						zoneId);
				rejectedProducts
						.add("While processing the Loc CRE , the Zone Document is unavailable for the zone id -"
								.concat(zoneId));

			}
			if (PriceConstants.ZONE_MSG_TYPE_MOD.equals(zoneMsgType)
					&& Dockyard.isSpaceOrNull(zoneDoc)) {
				LOGGER.info("Zone document found unavailable while processing Mod msg for zone - "
						+ zoneId);

			}
			ZoneEntity zoneEntity = new ZoneEntity();
			List<String> storeIds = new ArrayList<String>();

			if ((!Dockyard
					.isSpaceOrNull(tslZoneGroupDesc.getTSLZoneGroupType()) && !tslZoneGroupDesc
					.getTSLZoneGroupType().isEmpty())) {
				zoneGrpType = tslZoneGroupDesc.getTSLZoneGroupType().get(0)
						.getZoneGroupType().toString();
			}
			zoneEntity.setZoneGroupId(tslZoneGroupDesc.getZoneGroupId()
					.toString());
			zoneEntity.setZoneGroupName(Dockyard.isSpaceOrNull(tslZoneGroupDesc
					.getZoneGroupName()) ? zoneGrpName : tslZoneGroupDesc
					.getZoneGroupName());
			zoneEntity.setZoneGroupType(zoneGrpType);

			zoneEntity.setZoneId(String.valueOf(tslZoneGroupDesc.getTSLZone()
					.get(i).getZoneId()));
			zoneEntity.setZoneName(tslZoneGroupDesc.getTSLZone().get(i)
					.getZoneName());
			zoneEntity.setBaseInd(String.valueOf(tslZoneGroupDesc.getTSLZone()
					.get(i).getBaseInd()));
			zoneEntity.setCurrencyCode(tslZoneGroupDesc.getTSLZone().get(i)
					.getCurrencyCode());
			zoneEntity.setTslCountryCode(tslZoneGroupDesc.getTSLZone().get(i)
					.getCountryCode());

			if (!Dockyard.isSpaceOrNull(tslZoneGroupDesc.getTSLZone().get(i)
					.getCountryCode())
					&& PriceConstants.TSL_COUNTRY_GB.equals(tslZoneGroupDesc
							.getTSLZone().get(i).getCountryCode())) {
				zoneEntity.setOfferPrefix(PriceConstants.OFFER_PREFIX_UK);
			}
			if (!Dockyard.isSpaceOrNull(tslZoneGroupDesc.getTSLZone().get(i)
					.getCountryCode())
					&& PriceConstants.TSL_COUNTRY_IE.equals(tslZoneGroupDesc
							.getTSLZone().get(i).getCountryCode())) {
				zoneEntity.setOfferPrefix(PriceConstants.OFFER_PREFIX_ROI);
			}
			zoneEntity.setCreatedDate(Dockyard
					.getSysDate(PriceConstants.ISO_8601_FORMAT));
			zoneEntity.setCreatedById(PriceConstants.JMS_RPM);
			zoneEntity.setLastUpdateDate(Dockyard
					.getSysDate(PriceConstants.ISO_8601_FORMAT));
			if (!tslZoneGroupDesc.getTSLZone().get(i).getTSLZoneLoc().isEmpty()) {
				for (int locIndex = 0; locIndex < tslZoneGroupDesc.getTSLZone()
						.get(i).getTSLZoneLoc().size(); locIndex++) {
					storeIds.add(String.valueOf(tslZoneGroupDesc.getTSLZone()
							.get(i).getTSLZoneLoc().get(locIndex).getLoc()));
				}
			}
			zoneEntity.setStoreIds(storeIds);

			zoneEntities.put(zoneKey, zoneEntity);
		}
		if (!rejectedProducts.isEmpty()) {
			zoneWriter.writeRejects(rejectedProducts);
			rejectedProducts.clear();
			throw new ZoneBusinessException(
					"Error while constucting the zone Entity");
		}
		return zoneEntities;
	}

	public Map<String, Store> constructStoreEntity(List<String> storeIds,
			ZoneEntity zoneEntity, String zoneGrpType)
			throws ZoneBusinessException {
		Map<String, Store> storeEntities = new HashMap<String, Store>();
		String zoneGroupType = null;
		zoneGroupType = zoneEntity.getZoneGroupType();

		if (!Dockyard.isSpaceOrNull(storeIds)) {
			for (String storeId : storeIds) {
				Store storeEntity = new Store();
				String storeKey = PriceConstants.STORE_KEY + storeId;
				try {
					Store storeDoc = (Store) repository
							.getGenericObject(storeKey, Store.class);
					storeEntity.setStoreId(storeId);
					storeEntity.setPriceZoneId(Optional.<Integer> absent());
					storeEntity.setPromoZoneId(Optional.<Integer> absent());
					storeEntity.setClearanceZoneId(Optional.<Integer> absent());
					if (PriceConstants.PRICE_ZONE_TYPE.equals(zoneGroupType)) {
						storeEntity.setPriceZoneId(Optional.of(Integer
								.parseInt(zoneEntity.getZoneId())));
						if (!Dockyard.isSpaceOrNull(storeDoc)) {
							storeEntity.setPromoZoneId(storeDoc
									.getPromoZoneId());
							storeEntity.setClearanceZoneId(storeDoc
									.getClearanceZoneId());
						}
					}
					if (PriceConstants.PROMO_ZONE_TYPE.equals(zoneGroupType)) {
						storeEntity.setPromoZoneId(Optional.of(Integer
								.parseInt(zoneEntity.getZoneId())));
						if (!Dockyard.isSpaceOrNull(storeDoc)) {
							storeEntity.setPriceZoneId(storeDoc
									.getPriceZoneId());
							storeEntity.setClearanceZoneId(storeDoc
									.getClearanceZoneId());
						}
					}
					if (PriceConstants.CLEARANCE_ZONE_TYPE
							.equals(zoneGroupType)) {
						storeEntity.setClearanceZoneId(Optional.of(Integer
								.parseInt(zoneEntity.getZoneId())));
						if (!Dockyard.isSpaceOrNull(storeDoc)) {
							storeEntity.setPriceZoneId(storeDoc
									.getPriceZoneId());
							storeEntity.setPromoZoneId(storeDoc
									.getPromoZoneId());
						}
					}
					storeEntity.setCurrency(zoneEntity.getCurrencyCode());
					storeEntity.setCountryId(zoneEntity.getTslCountryCode());

					storeEntities.put(storeKey, storeEntity);
				} catch (DataAccessException e) {
					throw new ZoneBusinessException(e);
				}
			}
		}
		return storeEntities;
	}

	public void processZoneGroupDel(TSLZoneGroupRef tslZoneGroupDesc,
			String zoneMsgType) throws ZoneBusinessException {
		List<String> zoneKeys = new ArrayList<String>();
		try {
			String zoneGrpId = String
					.valueOf(tslZoneGroupDesc.getZoneGroupId());
			zoneWriter.deleteZoneGrpData(zoneGrpId);
		} catch (Exception e) {
			throw new ZoneBusinessException(e.getMessage(), e);
		}
	}

	public void processZoneDel(TSLZoneGroupRef tslZoneGroupRef)
			throws ZoneBusinessException {
		try {
			List<String> zoneKeys = new ArrayList<String>();
			List<String> zoneIds = new ArrayList<String>();
			for (TSLZoneRef zoneRef : tslZoneGroupRef.getTSLZoneRef()) {
				String zoneId = String.valueOf(zoneRef.getZoneId());
				String zoneKey = PriceConstants.ZONE_KEY + zoneId;
				zoneKeys.add(zoneKey);
				zoneIds.add(zoneId);
			}
			zoneWriter.modifyZoneGroupData(zoneIds,
					PriceConstants.ZONE_MSG_TYPE_DEL);
			zoneWriter.deleteZoneData(zoneKeys);
		} catch (Exception e) {
			throw new ZoneBusinessException(e.getMessage(), e);
		}
	}

	public void processLocDel(TSLZoneGroupRef tslZoneGroupRef)
			throws ZoneBusinessException {
		String zoneId;
		String locId;
		List<String> storeIds = new ArrayList<String>();
		for (TSLZoneRef zoneRefs : tslZoneGroupRef.getTSLZoneRef()) {
			zoneId = String.valueOf(zoneRefs.getZoneId());
			String zoneDocKey = PriceConstants.ZONE_KEY + zoneId;
			for (TSLZoneLocRef zoneLocRef : zoneRefs.getTSLZoneLocRef()) {
				locId = String.valueOf(zoneLocRef.getLoc());
				storeIds.add(locId);
			}
			zoneWriter.deleteLocFromZoneDoc(zoneDocKey, storeIds);
		}
	}

	@Override
	public Map<String, ZoneEntity> getZoneIdCountryCodeMap(
			TSLZoneGroupRef tslZoneGroupRef) throws ZoneBusinessException {
		List<TSLZoneRef> tslZoneRefList = tslZoneGroupRef.getTSLZoneRef();
		Map<String, ZoneEntity> zoneCountryCodeMap = new HashMap<String, ZoneEntity>();
		for (TSLZoneRef tslZoneRef : tslZoneRefList) {
			ZoneEntity zoneEntity = null;
			try {
				zoneEntity = (ZoneEntity) repository
						.getGenericObject(PriceConstants.ZONE_KEY
								+ String.valueOf(tslZoneRef.getZoneId()),
								ZoneEntity.class);
			} catch (DataAccessException e) {
				throw new ZoneBusinessException(e);
			}
			if (zoneEntity != null) {
				zoneCountryCodeMap.put(String.valueOf(tslZoneRef.getZoneId()),
						zoneEntity);
			}
		}
		return zoneCountryCodeMap;
	}

	@Override
	public Map<String, ZoneEntity> getZoneIdCountryCodeForTSLZoneGroup(
			TSLZoneGroupDesc tslZoneGroupDec) throws ZoneBusinessException {
		List<TSLZone> tslZoneList = tslZoneGroupDec.getTSLZone();
		Map<String, ZoneEntity> zoneCountryCodeMap = new HashMap<String, ZoneEntity>();
		for (TSLZone tslZone : tslZoneList) {
			ZoneEntity zoneEntity = null;
			try {
				zoneEntity = (ZoneEntity) repository
						.getGenericObject(PriceConstants.ZONE_KEY
										+ String.valueOf(tslZone.getZoneId()),
								ZoneEntity.class);
			} catch (DataAccessException e) {
				throw new ZoneBusinessException(e);
			}
			if (zoneEntity != null) {
				zoneCountryCodeMap.put(String.valueOf(tslZone.getZoneId()),
						zoneEntity);
			}
		}
		return zoneCountryCodeMap;
	}
}
