package com.tesco.services.adapters.core.utils;

import java.util.HashMap;
import java.util.Map;

import com.codahale.metrics.Counter;
import com.codahale.metrics.JmxReporter;
import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.Timer;
import com.tesco.services.utility.PriceConstants;

/**
 * Created by GC78 on 16/06/2016.
 */
public class EventMetrics {

	static EventMetrics eventMetrics;

	private static Map<String, Timer> eventTimers;
	private static Map<String, Timer.Context> eventTimersCtx;
	private static MetricRegistry metricsRegistry;
	private static Map<String, Counter> eventErrorCounters;

	Counter errorCounter;

	private EventMetrics() {
		eventMetrics = null;
	}

	public static MetricRegistry getMetricsRegistry() {
		return metricsRegistry;
	}

	public static synchronized EventMetrics getInstance() {
		if (eventMetrics == null) {
			eventMetrics = new EventMetrics();
			metricsRegistry = new MetricRegistry();
			JmxReporter.forRegistry(metricsRegistry).build();
			eventTimers = new HashMap<String, Timer>();
			eventTimersCtx = new HashMap<String, Timer.Context>();
			eventErrorCounters = new HashMap<String, Counter>();
			initMetrics(metricsRegistry);
		}
		return eventMetrics;
	}

	private static void initMetrics(MetricRegistry metricRegisty) {

		eventTimers.put(PriceConstants.FUTURE_PRICE_MSG_TYPE_CRE, metricRegisty
				.timer(MetricRegistry.name("com.tesco",
						"EventsElapsedTimeAndRate",
						"time-to-process-priceChanged-event")));

		eventTimers.put(PriceConstants.FUTURE_PRICE_MSG_TYPE_DEL, metricRegisty
				.timer(MetricRegistry.name("com.tesco",
						"EventsElapsedTimeAndRate",
						"time-to-process-priceDeleted-event")));

		eventTimers.put(PriceConstants.PROMOTION_MSG_TYPE_CRE, metricRegisty
				.timer(MetricRegistry.name("com.tesco",
						"EventsElapsedTimeAndRate",
						"time-to-process-promotionCreated-event")));

		eventTimers.put(PriceConstants.ZONE_MSG_TYPE_CREATED, metricRegisty
				.timer(MetricRegistry.name("com.tesco",
						"EventsElapsedTimeAndRate",
						"time-to-process-zoneCreated-event")));

		eventTimers.put(PriceConstants.ZONE_MSG_TYPE_DTLS_CHANGED,
				metricRegisty.timer(MetricRegistry.name("com.tesco",
						"EventsElapsedTimeAndRate",
						"time-to-process-zoneDetailsChanged-event")));

		eventTimers.put(PriceConstants.ZONE_MSG_TYPE_DELETED, metricRegisty
				.timer(MetricRegistry.name("com.tesco",
						"EventsElapsedTimeAndRate",
						"time-to-process-zoneDeleted-event")));

		eventTimers.put(PriceConstants.STORE_ZONE_CHANGE, metricRegisty
				.timer(MetricRegistry.name("com.tesco",
						"EventsElapsedTimeAndRate",
						"time-to-process-storeZoneChanged-event")));

		eventTimers.put(PriceConstants.CLEARANCE_CREATED_EVENT_TYPE,
				metricRegisty.timer(MetricRegistry.name("com.tesco",
						"EventsElapsedTimeAndRate",
						"time-to-process-clearanceCreated-event")));

		eventTimers.put(PriceConstants.CLEARANCE_DELETED_EVENT_TYPE,
				metricRegisty.timer(MetricRegistry.name("com.tesco",
						"EventsElapsedTimeAndRate",
						"time-to-process-clearanceDeleted-event")));

		eventTimers.put(PriceConstants.SCHEDULED_FUTURE_PRICE_MSG_TYPE_CRE,
				metricRegisty.timer(MetricRegistry.name("com.tesco",
						"EventsElapsedTimeAndRate",
						"time-to-process-priceChange-event")));

		eventTimers.put(PriceConstants.SCHEDULED_PROMOTION_START_EVENT_TYPE,
				metricRegisty.timer(MetricRegistry.name("com.tesco",
						"EventsElapsedTimeAndRate",
						"time-to-process-promotionStart-event")));

		eventTimers.put(PriceConstants.SCHEDULED_PROMOTION_END_EVENT_TYPE,
				metricRegisty.timer(MetricRegistry.name("com.tesco",
						"EventsElapsedTimeAndRate",
						"time-to-process-promotionEnd-event")));

		eventTimers.put(
				PriceConstants.SCHEDULED_PROMOTION_START_PRODUCT_EVENT_TYPE,
				metricRegisty.timer(MetricRegistry.name("com.tesco",
						"EventsElapsedTimeAndRate",
						"time-to-process-PromotionStartProduct-event")));

		eventTimers.put(PriceConstants.CLEARANCE_END_DATE_CHANGED_EVENT_TYPE,
				metricRegisty.timer(MetricRegistry.name("com.tesco",
						"EventsElapsedTimeAndRate",
						"time-to-process-clearanceEndDateChanged-event")));

		eventTimers.put(PriceConstants.CLEARANCE_PREV_PRICE_CHANGE_EVENT_TYPE,
				metricRegisty.timer(MetricRegistry.name("com.tesco",
						"EventsElapsedTimeAndRate",
						"time-to-process-clearancePrevPriceChanged-event")));

		eventTimers.put(PriceConstants.CLEARANCE_START_EVENT_TYPE,
				metricRegisty.timer(MetricRegistry.name("com.tesco",
						"EventsElapsedTimeAndRate",
						"time-to-process-clearanceStart-event")));

		eventTimers.put(PriceConstants.CLEARANCE_END_EVENT_TYPE, metricRegisty
				.timer(MetricRegistry.name("com.tesco",
						"EventsElapsedTimeAndRate",
						"time-to-process-clearanceEnd-event")));

		eventTimers.put(PriceConstants.PROMOTION_DETAILS_CHANGED_EVENT_TYPE,
				metricRegisty.timer(MetricRegistry.name("com.tesco",
						"EventsElapsedTimeAndRate",
						"time-to-process-PromotionDetailsChanged-event")));

		eventTimers.put(PriceConstants.PROMOTION_DELETED_EVENT_TYPE,
				metricRegisty.timer(MetricRegistry.name("com.tesco",
						"EventsElapsedTimeAndRate",
						"time-to-process-PromotionDeleted-event")));

		eventTimers.put(PriceConstants.PROMOTION_LOCATION_REMOVED_EVENT_TYPE,
				metricRegisty.timer(MetricRegistry.name("com.tesco",
						"EventsElapsedTimeAndRate",
						"time-to-process-PromotionLocationRemoved-event")));

		eventTimers.put(PriceConstants.PROMOTION_PRODUCT_REMOVED_EVENT_TYPE,
				metricRegisty.timer(MetricRegistry.name("com.tesco",
						"EventsElapsedTimeAndRate",
						"time-to-process-PromotionProductRemoved-event")));

		eventTimers.put(PriceConstants.PROMO_PRODUCT_ADDED, metricRegisty
				.timer(MetricRegistry.name("com.tesco",
						"EventsElapsedTimeAndRate",
						"time-to-process-PromotionProductAdded-event")));

		eventTimers.put(PriceConstants.PROMOTION_ENDDATE_CHANGED, metricRegisty
				.timer(MetricRegistry.name("com.tesco",
						"EventsElapsedTimeAndRate",
						"time-to-process-PromotionEndDateChanged-event")));

		eventTimers.put(PriceConstants.PROMO_LOC_ADDED, metricRegisty
				.timer(MetricRegistry.name("com.tesco",
						"EventsElapsedTimeAndRate",
						"time-to-process-PromotionLocationAdded-event")));

		eventErrorCounters.put(PriceConstants.FUTURE_PRICE_MSG_TYPE_CRE,
				metricRegisty.counter(MetricRegistry.name("com.tesco",
						"EventsMessageProcessingErrors",
						"total-priceChanged-error-count")));

		eventErrorCounters.put(PriceConstants.FUTURE_PRICE_MSG_TYPE_DEL,
				metricRegisty.counter(MetricRegistry.name("com.tesco",
						"EventsMessageProcessingErrors",
						"total-priceDeleted-error-count")));

		eventErrorCounters.put(PriceConstants.PROMOTION_MSG_TYPE_CRE,
				metricRegisty.counter(MetricRegistry.name("com.tesco",
						"EventsMessageProcessingErrors",
						"total-promotionCreated-error-count")));

		eventErrorCounters.put(PriceConstants.ZONE_MSG_TYPE_CREATED,
				metricRegisty.counter(MetricRegistry.name("com.tesco",
						"EventsMessageProcessingErrors",
						"total-zoneCreated-error-count")));

		eventErrorCounters.put(PriceConstants.ZONE_MSG_TYPE_DTLS_CHANGED,
				metricRegisty.counter(MetricRegistry.name("com.tesco",
						"EventsMessageProcessingErrors",
						"total-zoneDetailsChanged-error-count")));

		eventErrorCounters.put(PriceConstants.ZONE_MSG_TYPE_DELETED,
				metricRegisty.counter(MetricRegistry.name("com.tesco",
						"EventsMessageProcessingErrors",
						"total-zoneDeleted-error-count")));

		eventErrorCounters.put(PriceConstants.STORE_ZONE_CHANGE, metricRegisty
				.counter(MetricRegistry.name("com.tesco",
						"EventsMessageProcessingErrors",
						"total-storeZoneChanged-error-count")));

		eventErrorCounters.put(PriceConstants.CLEARANCE_CREATED_EVENT_TYPE,
				metricRegisty.counter(MetricRegistry.name("com.tesco",
						"EventsMessageProcessingErrors",
						"total-clearanceCreated-error-count")));

		eventErrorCounters.put(PriceConstants.CLEARANCE_DELETED_EVENT_TYPE,
				metricRegisty.counter(MetricRegistry.name("com.tesco",
						"EventsMessageProcessingErrors",
						"total-clearanceDeleted-error-count")));

		eventErrorCounters.put(
				PriceConstants.SCHEDULED_FUTURE_PRICE_MSG_TYPE_CRE,
				metricRegisty.counter(MetricRegistry.name("com.tesco",
						"EventsMessageProcessingErrors",
						"total-priceChange-error-count")));

		eventErrorCounters.put(
				PriceConstants.SCHEDULED_PROMOTION_START_EVENT_TYPE,
				metricRegisty.counter(MetricRegistry.name("com.tesco",
						"EventsMessageProcessingErrors",
						"total-promotionStart-error-count")));

		eventErrorCounters.put(
				PriceConstants.SCHEDULED_PROMOTION_END_EVENT_TYPE,
				metricRegisty.counter(MetricRegistry.name("com.tesco",
						"EventsMessageProcessingErrors",
						"total-promotionEnd-error-count")));

		eventErrorCounters.put(
				PriceConstants.SCHEDULED_PROMOTION_START_PRODUCT_EVENT_TYPE,
				metricRegisty.counter(MetricRegistry.name("com.tesco",
						"EventsMessageProcessingErrors",
						"total-PromotionStartProduct-error-count")));

		eventErrorCounters.put(
				PriceConstants.CLEARANCE_END_DATE_CHANGED_EVENT_TYPE,
				metricRegisty.counter(MetricRegistry.name("com.tesco",
						"EventsMessageProcessingErrors",
						"total-clearanceEndDateChanged-error-count")));

		eventErrorCounters.put(
				PriceConstants.CLEARANCE_PREV_PRICE_CHANGE_EVENT_TYPE,
				metricRegisty.counter(MetricRegistry.name("com.tesco",
						"EventsMessageProcessingErrors",
						"total-clearancePrevPriceChanged-error-count")));

		eventErrorCounters.put(PriceConstants.CLEARANCE_START_EVENT_TYPE,
				metricRegisty.counter(MetricRegistry.name("com.tesco",
						"EventsMessageProcessingErrors",
						"total-clearanceStart-error-count")));

		eventErrorCounters.put(PriceConstants.CLEARANCE_END_EVENT_TYPE,
				metricRegisty.counter(MetricRegistry.name("com.tesco",
						"EventsMessageProcessingErrors",
						"total-clearanceEnd-error-count")));

		eventErrorCounters.put(
				PriceConstants.PROMOTION_DETAILS_CHANGED_EVENT_TYPE,
				metricRegisty.counter(MetricRegistry.name("com.tesco",
						"EventsMessageProcessingErrors",
						"total-PromotionDetailsChanged-error-count")));

		eventErrorCounters.put(PriceConstants.PROMOTION_DELETED_EVENT_TYPE,
				metricRegisty.counter(MetricRegistry.name("com.tesco",
						"EventsMessageProcessingErrors",
						"total-PromotionDeleted-error-count")));

		eventErrorCounters.put(
				PriceConstants.PROMOTION_LOCATION_REMOVED_EVENT_TYPE,
				metricRegisty.counter(MetricRegistry.name("com.tesco",
						"EventsMessageProcessingErrors",
						"total-PromotionLocationRemoved-error-count")));

		eventErrorCounters.put(
				PriceConstants.PROMOTION_PRODUCT_REMOVED_EVENT_TYPE,
				metricRegisty.counter(MetricRegistry.name("com.tesco",
						"EventsMessageProcessingErrors",
						"total-PromotionProductRemoved-error-count")));

		eventErrorCounters.put(PriceConstants.PROMO_PRODUCT_ADDED,
				metricRegisty.counter(MetricRegistry.name("com.tesco",
						"EventsMessageProcessingErrors",
						"total-PromotionProductAdded-error-count")));

		eventErrorCounters.put(PriceConstants.PROMOTION_ENDDATE_CHANGED,
				metricRegisty.counter(MetricRegistry.name("com.tesco",
						"EventsMessageProcessingErrors",
						"total-PromotionEndDateChanged-error-count")));

		eventErrorCounters.put(PriceConstants.PROMO_LOC_ADDED, metricRegisty
				.counter(MetricRegistry.name("com.tesco",
						"EventsMessageProcessingErrors",
						"total-PromotionLocationAdded-error-count")));

	}

	public void logEventStartTime(String eventType) {
		eventTimersCtx.put(eventType, eventTimers.get(eventType).time());
	}

	public void logEventEndTime(String eventType) {
		eventTimersCtx.get(eventType).stop();
	}

	public void incrementErrorCounter(String eventType) {
		eventErrorCounters.get(eventType).inc();
	}

	public void resetCounters() {
		new EventMetrics();
		getInstance();
	}
}
