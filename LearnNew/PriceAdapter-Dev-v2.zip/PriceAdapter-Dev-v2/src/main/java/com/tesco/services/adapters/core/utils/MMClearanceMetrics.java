package com.tesco.services.adapters.core.utils;

import com.codahale.metrics.Counter;
import com.codahale.metrics.JmxReporter;
import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.Timer;
import com.codahale.metrics.Timer.Context;

public class MMClearanceMetrics {
	private static MMClearanceMetrics mmClearanceMetrics;
	private static MetricRegistry metricsRegistry;

	static Timer mmClearanceMessagesCre;
	Context mmClearanceMessagesCreTC;

	static Timer mmClearanceMessagesMod;
	Context mmClearanceMessagesModTC;

	static Timer mmClearanceMessagesDel;
	Context mmClearanceMessagesDelTC;

	static Timer messageListenerTimer;
	Context messageTimerContext;

	static Counter errorCounter;

	private MMClearanceMetrics() {
		mmClearanceMetrics = null;
	}

	public static MetricRegistry getMetricsRegistry() {
		return metricsRegistry;
	}

	public static synchronized MMClearanceMetrics getInstance() {
		if (mmClearanceMetrics == null) {
			mmClearanceMetrics = new MMClearanceMetrics();
			metricsRegistry = new MetricRegistry();
			JmxReporter.forRegistry(metricsRegistry).build();
			initMetrics(metricsRegistry);
		}
		return mmClearanceMetrics;
	}

	private static void initMetrics(MetricRegistry metricRegisty) {

		mmClearanceMessagesCre = metricRegisty.timer(MetricRegistry.name(
				"com.tesco", "MMClearanceElapsedTimeAndRate",
				"time-to-process-cre-message"));

		mmClearanceMessagesMod = metricRegisty.timer(MetricRegistry.name(
				"com.tesco", "MMClearanceElapsedTimeAndRate",
				"time-to-process-mod-message"));

		mmClearanceMessagesDel = metricRegisty.timer(MetricRegistry.name(
				"com.tesco", "MMClearanceElapsedTimeAndRate",
				"time-to-process-del-message"));

		messageListenerTimer = metricRegisty.timer(MetricRegistry.name(
				"com.tesco", "MMClearanceElapsedTimeAndRate",
				"time-to-process-message"));

		errorCounter = metricRegisty.counter(MetricRegistry.name("com.tesco",
				"MMClearanceMessageProcessingErrors", "total-error-count"));

	}

	public void logCreClearanceProcessingStartTime() {
		mmClearanceMessagesCreTC = mmClearanceMessagesCre.time();
	}

	public void logCreClearanceProcessingEndTime() {
		mmClearanceMessagesCreTC.stop();
	}

	public void logModClearanceProcessingStartTime() {
		mmClearanceMessagesModTC = mmClearanceMessagesMod.time();
	}

	public void logModClearanceProcessingEndTime() {
		mmClearanceMessagesModTC.stop();
	}

	public void logDelClearanceProcessingStartTime() {
		mmClearanceMessagesDelTC = mmClearanceMessagesDel.time();
	}

	public void logDelClearanceProcessingEndTime() {
		mmClearanceMessagesDelTC.stop();
	}

	public void logMessageProcessingStartTime() {
		messageTimerContext = messageListenerTimer.time();
	}

	public void logMessageProcessingEndTime() {
		messageTimerContext.stop();
	}

	public void incrementErrorCount() {
		errorCounter.inc();
	}

	public void resetCounters() {
		new MMClearanceMetrics();
		getInstance();
	}
}
