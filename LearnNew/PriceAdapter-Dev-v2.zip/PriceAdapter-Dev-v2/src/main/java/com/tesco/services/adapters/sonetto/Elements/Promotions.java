package com.tesco.services.adapters.sonetto.Elements;


import com.googlecode.totallylazy.Predicate;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

import static ch.lambdaj.Lambda.*;
import static com.googlecode.totallylazy.Sequences.sequence;
import static org.hamcrest.CoreMatchers.is;

@XmlRootElement (name="Promotions")
//Class Promotions
public class Promotions {

    @XmlElement(name = "Promotion")
    private List<Promotion> promotionList;

    public List<Promotion> getPromotions(){
        return promotionList;
    }

    public List<Promotion> getInternetPromotions() {

        return filter(having(on(Promotion.class).isInternetExclusive(), is(true)), promotionList);
    }

    /**
     * Method getStorePromotions
     * @return
     */
    public List<Promotion> getStorePromotions() {
        return sequence(promotionList).filter(new Predicate<Promotion>() {
            @Override
            public boolean matches(Promotion promotion) {
                return !promotion.isInternetExclusive();
            }
        }).toList();
    }
}
