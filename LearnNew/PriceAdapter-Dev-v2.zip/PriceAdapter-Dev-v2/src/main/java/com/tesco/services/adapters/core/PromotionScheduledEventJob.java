package com.tesco.services.adapters.core;

import static com.tesco.services.resources.ScheduledEventResource.getScheduledEventSemaphoreMap;
import static com.tesco.services.utility.PriceConstants.EVENT_TYPE;
import static com.tesco.services.utility.PriceConstants.LEAD_TIME_DAYS;
import static com.tesco.services.utility.PriceUtility.getCouchbaseViewKeyForEffectiveDate;
import static com.tesco.services.utility.sl4j.LoggerFactoryWrapper.getLogger;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.core.Response;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.slf4j.Logger;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tesco.logging.LogWriter;
import com.tesco.logging.LoggerRepository;
import com.tesco.services.Configuration;
import com.tesco.services.CouchbaseViewConfig;
import com.tesco.services.adapters.core.exceptions.PromotionEventException;
import com.tesco.services.adapters.promotion.PromotionEventHandler;
import com.tesco.services.repositories.views.CouchbaseViewRestImpl;
import com.tesco.services.repositories.views.WebViewTemplate;
import com.tesco.services.resources.ScheduledEventResource;
import com.tesco.services.utility.PriceConstants;

public class PromotionScheduledEventJob extends CouchbaseViewRestImpl implements
		ScheduledEventJob {

	private static final String PAGE_SIZE = "page.size";

	private static final Logger LOGGER = getLogger(PromotionScheduledEventJob.class);
	final static private LogWriter REJECTLOGGER = LoggerRepository
			.getLogger("ScheduledEventRejectLogger");
	final static private String ROWS = "rows";
	final static private String VALUE = "value";
	private Configuration configuration;
	private ObjectMapper mapper;
	private PromotionEventHandler promotionEventHandler;
	private String eventType;
	private WebViewTemplate webViewTemplate;

	@Inject
	public PromotionScheduledEventJob(
			@Named("configuration") Configuration configuration,
			@Named("jsonmapper") ObjectMapper mapper,
			@Named("promoEvtHandler") PromotionEventHandler promotionEventhandler,
			String eventType) {
		super(configuration);
		this.configuration = configuration;
		this.mapper = mapper;
		this.promotionEventHandler = promotionEventhandler;
		this.eventType = eventType;
	}

	public PromotionScheduledEventJob(Configuration configuration,
			ObjectMapper mapper, PromotionEventHandler promotionEventhandler,
			WebViewTemplate webViewTemplate, String eventType) {
		super(configuration);
		this.configuration = configuration;
		this.mapper = mapper;
		this.promotionEventHandler = promotionEventhandler;
		this.webViewTemplate = webViewTemplate;
		this.eventType = eventType;
	}

	@Override
	public void run() {
		try {
			processScheduledEvents();
		} catch (Exception exception) {
			ScheduledEventResource.setErrorString(eventType,
					"Error while processing scheduled events of type["
							+ eventType + "]...");
		} finally {
			getScheduledEventSemaphoreMap(eventType).release();
		}
	}

	@Override
	public void processScheduledEvents() {
		String resultJsonData = null;
		int pageStartIndex = 0;
		int numberOfRecordsProcessed = 0;

		CouchbaseViewConfig promotionViewConfig = configuration
				.getCouchbaseViewConfig().get(eventType);

		int pageSize = Integer.parseInt(promotionViewConfig
				.getViewQueryParams().get(PAGE_SIZE));

		String documentKey = getCouchbaseViewKeyForEffectiveDate(promotionViewConfig);

		Map<String, String> viewQueryDynamicParams = new HashMap<String, String>();
		viewQueryDynamicParams.put(PriceConstants.VIEW_QUERY_KEY, documentKey);

		if (webViewTemplate == null) {
			webViewTemplate = createViewTemplate(promotionViewConfig);
		}
		do {
			viewQueryDynamicParams
					.put(PriceConstants.SKIP, "" + pageStartIndex);

			Response viewQueryResponse = webViewTemplate.queryView(
					promotionViewConfig.getViewQueryParams(),
					viewQueryDynamicParams);

			resultJsonData = viewQueryResponse.readEntity(String.class);

			LOGGER.info(
					"Data fetched from couchBase view for schedule zone-level promotion {} :{}",
					eventType, resultJsonData);
			numberOfRecordsProcessed = processPageRecordForPromotionEvent(
					resultJsonData, eventType);
			pageStartIndex = pageStartIndex + pageSize;

		} while (numberOfRecordsProcessed > 0);
	}

	@SuppressWarnings("unchecked")
	private int processPageRecordForPromotionEvent(String resultJsonData,
			String eventType) {
		JSONArray promotionRowData = null;
		JSONObject promotionDocData = null;
		int promotionRowDataLength = 0;
		try {
			if (resultJsonData != null) {
				promotionDocData = new JSONObject(resultJsonData);
				promotionRowData = new JSONArray(promotionDocData.getJSONArray(
						ROWS).toString());
			}
			LOGGER.info(promotionDocData != null ? promotionDocData.toString()
					: "promo doc data null");

			LOGGER.info(promotionRowData != null ? promotionRowData.toString()
					: "promo row data null");

			Map<String, String> promotionEventMapData = null;
			if (promotionRowData == null) {
				return 0;
			}
			promotionRowDataLength = promotionRowData.length();
			for (int rowIndex = 0; rowIndex < promotionRowDataLength; rowIndex++) {
				try {
					JSONObject pageRowData = promotionRowData
							.getJSONObject(rowIndex);
					JSONObject eventDataEntityJson = (JSONObject) pageRowData
							.get(VALUE);
					promotionEventMapData = mapper.readValue(
							eventDataEntityJson.toString(), Map.class);
					promotionEventMapData.put(EVENT_TYPE, eventType);
					promotionEventMapData.put(LEAD_TIME_DAYS, "1");
					String messageId = promotionEventHandler
							.publishPromotionEvent(promotionEventMapData);
					LOGGER.debug(
							"Event publishing success with event type {} and message ID {}",
							eventType, messageId);
				} catch (PromotionEventException exception) {
					REJECTLOGGER.info(promotionEventMapData);
				}
			}
		} catch (JSONException | IOException exception) {
			LOGGER.error(
					"Error occured while publishing of promotion event {}",
					exception);
		} catch (Exception exception) {
			LOGGER.error("Error occured while processing event {}", exception);
		}
		return promotionRowDataLength;
	}
}
