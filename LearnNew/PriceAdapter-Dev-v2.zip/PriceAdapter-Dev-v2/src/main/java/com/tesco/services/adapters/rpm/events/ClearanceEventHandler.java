package com.tesco.services.adapters.rpm.events;

import java.text.ParseException;

import com.tesco.services.adapters.rpm.events.impl.ClearanceEventData;
import com.tesco.services.event.exception.EventPublishException;

/**
 * This class handles the clearance events
 */

public interface ClearanceEventHandler {

	/**
	 * @param clearanceEventMap
	 * @throws ParseException
	 * @throws EventPublishException
	 */
	public void publishEventsForClearances(ClearanceEventData clearanceEventMap)
			throws ParseException, EventPublishException;

	/**
	 * @param clearanceEventMap
	 * @throws ParseException
	 * @throws EventPublishException
	 */
	public void publishEventsForPreviousPriceChangeClearances(ClearanceEventData clearanceEventMap)
			throws ParseException, EventPublishException;
	
}
