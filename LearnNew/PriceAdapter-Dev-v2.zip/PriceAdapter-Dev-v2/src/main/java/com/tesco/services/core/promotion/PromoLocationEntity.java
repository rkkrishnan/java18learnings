package com.tesco.services.core.promotion;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by iv16 on 5/5/2015.
 */
public class PromoLocationEntity {
    @JsonProperty("@type")
    public String type;

    @JsonProperty("locType")
    public String locType;

    @JsonProperty("locRef")
    public String locRef;

    @JsonProperty("effectiveDate")
    public String effectiveDate;

    @JsonProperty("endDate")
    public String endDate;

    @JsonProperty("rewardRefs")
    public int[] rewardRefs;

    public String getLocType() {
        return locType;
    }
    public String getEndDate() {
        return endDate;
    }

    public String getLocRef() {
        return locRef;
    }

    public String getEffectiveDate() {
        return effectiveDate;
    }


}
