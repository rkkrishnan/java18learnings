package com.tesco.services.repositories;

import java.util.UUID;

public class UUIDGenerator {

    //Method getUUID
    public String getUUID() {
        return UUID.randomUUID().toString();
    }
}
