package com.tesco.services.resources;

import static com.tesco.services.resources.HTTPResponses.badRequest;
import static com.tesco.services.resources.HTTPResponses.notFound;
import static com.tesco.services.resources.HTTPResponses.ok;
import io.swagger.annotations.ApiParam;

import java.io.IOException;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import org.slf4j.Logger;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tesco.couchbase.AsyncCouchbaseWrapper;
import com.tesco.couchbase.CouchbaseWrapper;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;

/**
 * Created by QZ88 on 13/11/2014.
 */
@Path("/dbreplica")
@Produces(MediaType.APPLICATION_JSON)
/* TO get the exact copy of document stored in couch base */
public class DBReplicaResource {

	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(DBReplicaResource.class);

	@SuppressWarnings("unused")
	private String uriPath = "";

	private CouchbaseWrapper couchbaseWrapper;
	@SuppressWarnings("unused")
	private ObjectMapper mapper;
	@SuppressWarnings("unused")
	private AsyncCouchbaseWrapper asyncCouchbaseWrapper;

	@Inject
	public DBReplicaResource(
			@Named("couchbaseWrapper") CouchbaseWrapper couchbaseWrapper,
			@Named("asyncCouchbaseWrapper") AsyncCouchbaseWrapper asyncCouchbaseWrapper,
			@Named("jsonmapper") ObjectMapper mapper) {
		this.couchbaseWrapper = couchbaseWrapper;
		this.asyncCouchbaseWrapper = asyncCouchbaseWrapper;
		this.mapper = mapper;
	}

	@GET
	@Path("/")
	public Response getRoot(@Context UriInfo uriInfo) {

		LOGGER.info("message :{} {} {}", uriInfo.getRequestUri().toString(),
				HttpServletResponse.SC_BAD_REQUEST,
				HTTPResponses.INVALID_REQUEST);

		return badRequest();
	}

	/* Key equals to th document key of couch base */
	@GET
	@Path("/{key}")
	public Response get(
			@ApiParam(value = "Product", required = true) @PathParam("key") String key,
			@Context UriInfo uriInfo) throws IOException {
		uriPath = uriInfo.getRequestUri().toString();
		String prod = (String) couchbaseWrapper.get(key);
		if (Dockyard.isSpaceOrNull(prod))
			return notFound("Data unavailable in Database");
		return ok(prod);

	}

}
