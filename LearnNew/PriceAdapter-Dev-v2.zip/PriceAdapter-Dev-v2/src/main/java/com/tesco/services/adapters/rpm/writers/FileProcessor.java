package com.tesco.services.adapters.rpm.writers;

import com.tesco.services.adapters.core.exceptions.WriterBusinessException;

/**
 * Created by wa68 on 08/07/2016.
 */
public interface FileProcessor {

	public void readAndProcessFile() throws WriterBusinessException;
}
