package com.tesco.services.exceptions;

/**
 * Created by qz88 on 06/10/2015
 */
public class ZoneBusinessException extends Exception {
	public ZoneBusinessException() {
		// TODO Auto-generated constructor stub
	}

	public ZoneBusinessException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ZoneBusinessException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public ZoneBusinessException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ZoneBusinessException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
