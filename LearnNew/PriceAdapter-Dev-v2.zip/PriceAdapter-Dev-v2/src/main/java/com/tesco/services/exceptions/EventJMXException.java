package com.tesco.services.exceptions;

/**
 * Created by GC78 on 17/6/2016.
 */
public class EventJMXException extends Exception {
	public EventJMXException() {
		// TODO Auto-generated constructor stub
	}

	public EventJMXException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public EventJMXException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public EventJMXException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public EventJMXException(String message, Throwable cause,
	boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}
}
