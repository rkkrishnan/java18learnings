package com.tesco.services.adapters.rpm.writers.impl;

import com.google.common.base.Optional;
import com.tesco.services.Configuration;
import com.tesco.services.adapters.rpm.writers.ZoneMessageWriter;
import com.tesco.services.core.Store;
import com.tesco.services.core.ZoneEntity;
import com.tesco.services.core.zone.ZoneGrpEntity;
import com.tesco.services.exceptions.DataAccessException;
import com.tesco.services.exceptions.ZoneBusinessException;
import com.tesco.services.repositories.Repository;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.PriceConstants;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.*;

/**
 * Created by qz88 on 07/10/2015.
 */
public class ZoneWriter implements ZoneMessageWriter {

	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(ZoneWriter.class);
	private Repository repository;
	private Configuration configuration;
	private Dockyard dockyard;

	@Inject
	public ZoneWriter(
			@Named("configuration") Configuration configuration,
			@Named("repository") Repository repository) {
		this.configuration = configuration;
		this.repository = repository;
	}

	public Dockyard getDockyard() {

		if (dockyard == null) {
			dockyard = new Dockyard();
		}
		return dockyard;
	}

	public void writeZoneMessage(Map<String, ZoneEntity> mapOfZoneEntities,
			String zoneMsgType)
			throws ZoneBusinessException {

		Set rejectedProducts = new HashSet<>();
		try {
			for (Map.Entry<String, ZoneEntity> entry : mapOfZoneEntities
					.entrySet()) {
				ZoneEntity zoneDoc = (ZoneEntity) repository
						.getGenericObject(entry.getKey(), ZoneEntity.class);
				ZoneEntity zoneEntity = constructZoneEntity(entry.getValue(),
						zoneDoc,
						zoneMsgType);
				if (Dockyard.isSpaceOrNull(zoneEntity)) {
					throw new ZoneBusinessException(
							"Error while creating the zone entity");
				}
                try {
					insertZoneData(entry.getKey(), zoneEntity);			// Added for PRIS-2203
				}catch(Exception ex){
					LOGGER.error(
							"Zone document couldn't be inserted due to DB error for zone -"
									+ zoneEntity.getZoneId());
					rejectedProducts
							.add("Zone document couldn't be inserted due to DB error for zone -"
									.concat(zoneEntity.getZoneId()));
				}
			}
			if (!rejectedProducts.isEmpty()) {
				writeRejects(rejectedProducts);
				rejectedProducts.clear();
			}
		} catch (ZoneBusinessException | DataAccessException e) {
			new ZoneBusinessException(e.getMessage());
		}

	}

	public void writeZoneGrpMessage(ZoneGrpEntity zoneGrpEntity,
			Map<String, ZoneEntity> mapOfZoneEntities, String zoneMsgType)
			throws ZoneBusinessException {
		String zoneGrpKey =
				PriceConstants.ZONE_GRP_KEY + zoneGrpEntity.getZoneGroupId();
		Set rejectedProducts = new HashSet<>();
		try {
			insertZoneGrpData(zoneGrpKey, zoneGrpEntity); // Added for PRIS-2203
		}catch(Exception ex){
			LOGGER.error(
					"Zone Group document couldn't be inserted due to DB error for zone group key-"
							+ zoneGrpKey);
			rejectedProducts
					.add("Zone Group document couldn't be inserted due to DB error for zone group-"
							.concat(zoneGrpKey));
		}
		writeZoneMessage(mapOfZoneEntities, zoneMsgType);

		if (!rejectedProducts.isEmpty()) {
			writeRejects(rejectedProducts);
			rejectedProducts.clear();
		}

	}

	public void writeStoreDataFromMessage(Map<String, Store> mapOfStoreEntities)
			throws ZoneBusinessException {

		Set rejectedProducts = new HashSet<>();

		for (Map.Entry<String, Store> entry : mapOfStoreEntities
				.entrySet()) {

			try{
			insertStoreData(entry.getKey(), entry.getValue()); // Added for PRIS-2203
			}catch(Exception ex){
				LOGGER.error(
						"Store document couldn't be inserted due to DB error for store -"
								+ entry.getKey());
				rejectedProducts
						.add("Zone document couldn't be inserted due to DB error for zone -"
								.concat(entry.getKey()));
			}

		}

	}

	public ZoneEntity constructZoneEntity(ZoneEntity zoneEntity,
			ZoneEntity zoneDoc, String zoneMsgType) {
		Set rejectedProducts = new HashSet<>();

		List<String> prevStores = new ArrayList<String>();
		if (PriceConstants.ZONE_LOC_MSG_TYPE_CRE.equals(zoneMsgType) && Dockyard
				.isSpaceOrNull(zoneDoc)) {
			LOGGER.error(
					"Zone document unavailable to store location details for zone "
							+ zoneEntity.getZoneId());
			rejectedProducts
					.add("Zone document unavailable to store location details for zone -"
							.concat(zoneEntity.getZoneId()));
		} else {
			if (Dockyard.isSpaceOrNull(zoneDoc)) {
				return zoneEntity;
			} else {
				if (!Dockyard.isSpaceOrNull(zoneDoc.getZoneGroupType())
						&& Dockyard
						.isSpaceOrNull(zoneEntity.getZoneGroupType())) {
					zoneEntity.setZoneGroupType(zoneDoc.getZoneGroupType());
				}
				if (PriceConstants.ZONE_LOC_MSG_TYPE_CRE.equals(zoneMsgType)) {
					zoneEntity.setZoneGroupId(zoneDoc.getZoneGroupId());
					zoneEntity.setZoneGroupName(zoneDoc.getZoneGroupName());
					zoneEntity.setZoneGroupType(zoneDoc.getZoneGroupType());
					zoneEntity.setZoneName(zoneDoc.getZoneName());
					zoneEntity.setBaseInd(zoneDoc.getBaseInd());
					zoneEntity.setCurrencyCode(zoneDoc.getCurrencyCode());
					zoneEntity.setTslCountryCode(zoneDoc.getTslCountryCode());
					zoneEntity.setOfferPrefix(zoneDoc.getOfferPrefix());
				}
				zoneEntity.setCreatedDate(zoneDoc.getCreatedDate());
				zoneEntity.setCreatedById(zoneDoc.getCreatedById());
				List<String> storeList = zoneEntity.getStoreIds();
				prevStores = zoneDoc.getStoreIds();
				if (!Dockyard.isSpaceOrNull(prevStores)) {
					Iterator itPrevLoc = prevStores.iterator();
					while (itPrevLoc.hasNext()) {
						storeList.add(itPrevLoc.next().toString());
					}
				}
				zoneEntity.setStoreIds(storeList);
			}
		}
		if (!rejectedProducts.isEmpty()) {
			writeRejects(rejectedProducts);
			rejectedProducts.clear();
			zoneEntity = null;
		}
		return zoneEntity;
	}

	public void insertZoneData(String zoneKey,
			ZoneEntity zoneEntity)
			throws Exception {
			repository.insertObject(zoneKey, zoneEntity); // Added for PRIS-2203

	}

	public void insertStoreData(String storeKey,
			Store storeEntity)
			throws Exception {
			repository.insertObject(storeKey, storeEntity); // Added for PRIS-2203
	}

	public void insertZoneGrpData(String zoneGrpKey,
			ZoneGrpEntity zoneGrpEntity)
			throws Exception{
			repository.insertObject(zoneGrpKey, zoneGrpEntity); // Added for PRIS-2203

	}

	public void deleteZoneData(List<String> zoneKeys)
			throws ZoneBusinessException {
		Set rejectedProducts = new HashSet<>();
		try {
			for (String zoneKey : zoneKeys) {
				ZoneEntity zoneDocToDelete = (ZoneEntity) repository
						.getGenericObject(zoneKey, ZoneEntity.class);
				int zoneId = Integer.parseInt(zoneKey.substring(5));
				if (!Dockyard.isSpaceOrNull(zoneDocToDelete)) {
					repository.deleteProduct(zoneKey);
					List<String> storeIds = zoneDocToDelete.getStoreIds();
					if (!storeIds.isEmpty()) {
						for (String storeId : storeIds) {
							Store storeDoc = (Store) repository
									.getGenericObject(
											PriceConstants.STORE_KEY + storeId,
											Store.class);
							if (!Dockyard.isSpaceOrNull(storeDoc)) {
								if (Optional.of(zoneId)
										.equals(storeDoc.getPriceZoneId())) {
									storeDoc.setPriceZoneId(
											Optional.<Integer>absent());
								} else if (Optional.of(zoneId)
										.equals(storeDoc.getPromoZoneId())) {
									storeDoc.setPromoZoneId(
											Optional.<Integer>absent());
								} else if (Optional.of(zoneId).equals(storeDoc
										.getClearanceZoneId())) {
									storeDoc.setClearanceZoneId(
											Optional.<Integer>absent());
								} else {
									LOGGER.info(
											"Information not avilable in document of store "
													+ storeId + " for zone - "
													+ zoneDocToDelete
													.getZoneId());
								}
								insertStoreData(
										PriceConstants.STORE_KEY + storeId,
										storeDoc);
							} else {
								LOGGER.info(
										"Store document not available "
												+ storeId + " for zone - "
												+ zoneDocToDelete
												.getZoneId());
							}
						}
					}

				} else {
					LOGGER.info(
							"No Zone Document available for delete for zone" +
									zoneKey.substring(5));
					LOGGER.error(
							"No Zone Document available for delete for zone  "
									+ zoneKey.substring(5));
					rejectedProducts
							.add("No Zone Document available for delete for zone -"
									.concat(zoneKey.substring(5)));
				}
			}
			if (!rejectedProducts.isEmpty()) {
				writeRejects(rejectedProducts);
				rejectedProducts.clear();
				throw new ZoneBusinessException(
						"Error while deleting the zone details");

			}
		} catch (Exception e) {
			throw new ZoneBusinessException(e.getMessage(), e);
		}
	}

	public void deleteLocFromZoneDoc(String zoneKey, List<String> storeIds)
			throws ZoneBusinessException {
		Set rejectedProducts = new HashSet<>();

		try {
			ZoneEntity zoneDocToBeModified = (ZoneEntity) repository
					.getGenericObject(zoneKey, ZoneEntity.class);
			if (!Dockyard.isSpaceOrNull(zoneDocToBeModified)) {
				List storeIdsToModify = zoneDocToBeModified.getStoreIds();
				for (String storeId : storeIds) {
					if (storeIdsToModify.contains(storeId)) {
						storeIdsToModify.remove(storeId);
					}
					zoneDocToBeModified.setLastUpdateDate(Dockyard.getSysDate(
							PriceConstants.ISO_8601_FORMAT));
					zoneDocToBeModified.setStoreIds(storeIdsToModify);
				}
				insertZoneData(zoneKey, zoneDocToBeModified);
			} else {
				LOGGER.error(
						"To delete location zone document is unavailable for zone Id  "
								+ zoneKey.substring(5));
				rejectedProducts
						.add("To delete location zone document is unavailable -"
								.concat(zoneKey.substring(5)));
			}
			if (!rejectedProducts.isEmpty()) {
				writeRejects(rejectedProducts);
				rejectedProducts.clear();
				throw new ZoneBusinessException(
						"Error while deleting the location details");
			}
			deleteStoreData(storeIds,zoneKey);
		} catch (Exception e) {
			throw new ZoneBusinessException(e.getMessage(), e);
		}

	}

	public void deleteStoreData(List<String> storeIds,String zoneKey)
			throws ZoneBusinessException {
		try {
			int zoneId = Integer.parseInt(zoneKey.substring(5));
			if (!Dockyard.isSpaceOrNull(storeIds)) {
				for (String storeId : storeIds) {
					Store storeDocToDelete = (Store) repository
							.getGenericObject(
									PriceConstants.STORE_KEY + storeId,
									Store.class);
					if (!Dockyard.isSpaceOrNull(storeDocToDelete)) {

						if(Optional.of(zoneId).equals(storeDocToDelete.getPriceZoneId())){
							storeDocToDelete.setPriceZoneId(
									Optional.<Integer>absent());

						}if(Optional.of(zoneId).equals(storeDocToDelete.getPromoZoneId())){
							storeDocToDelete.setPromoZoneId(
									Optional.<Integer>absent());

						}if(Optional.of(zoneId).equals(storeDocToDelete.getClearanceZoneId())){
							storeDocToDelete.setClearanceZoneId(
									Optional.<Integer>absent());
						}
						insertStoreData(PriceConstants.STORE_KEY+storeId,storeDocToDelete);
					} else {
						LOGGER.info(
								"Document not available to delete for store - "
										+ storeId);
					}
				}
			}
		} catch (Exception e) {
			throw new ZoneBusinessException(e.getMessage(), e);
		}
	}

	public void writeRejects(Set rejectedProducts) {
		String loggedDate = Dockyard.getSysDate("yyyyMMdd");
		String rejectFilePath = configuration.getRejectFilePath();
		new Dockyard().writeProductDetailsToFile(
				rejectFilePath + "/REJECT_FILE_ZONE_"
						+ loggedDate + ".log", rejectedProducts);
		return;
	}

	public void deleteZoneGrpData(String zoneGrpId)throws ZoneBusinessException{
		try{
			Set rejectedProducts = new HashSet<>();
			String zoneGrpKey = PriceConstants.ZONE_GRP_KEY+zoneGrpId;
			ZoneGrpEntity zoneGrpDoc = (ZoneGrpEntity) repository.getGenericObject(zoneGrpKey,ZoneGrpEntity.class);
			List zoneIds = zoneGrpDoc.getZoneIds();
			if(Dockyard.isSpaceOrNull(zoneIds) || zoneIds.isEmpty()){
				repository.deleteProduct(zoneGrpKey);

			}else{
				LOGGER.error(
						"Can not delete zone group document as it has reference for zone in document with Id"
								+ zoneGrpKey);
				rejectedProducts
						.add("Can not delete zone group document as it has reference for zone in document with Id -"
								.concat(zoneGrpKey));
			}
			if (!rejectedProducts.isEmpty()) {
				writeRejects(rejectedProducts);
				rejectedProducts.clear();
				throw new ZoneBusinessException(
						"Error while deleting the zone group document");
			}
		}catch(Exception e){
			throw new ZoneBusinessException(e.getMessage(),e);
		}
	}

	public void modifyZoneGroupData(List<String> zoneIds, String msgType)throws ZoneBusinessException{
		Set rejectedProducts = new HashSet<>();
		List<String> zoneIdsInZoneGrpDoc = new ArrayList<String>();
		try {
			for (String zoneId : zoneIds) {
				ZoneEntity zoneDoc = (ZoneEntity) repository.getGenericObject(PriceConstants.ZONE_KEY+zoneId,ZoneEntity.class);
				String zoneGrpId = zoneDoc.getZoneGroupId();
				ZoneGrpEntity zoneGrpDoc = (ZoneGrpEntity) repository
						.getGenericObject(
								PriceConstants.ZONE_GRP_KEY + zoneGrpId,
								ZoneGrpEntity.class);
				if(PriceConstants.ZONE_MSG_TYPE_DEL.equals(msgType) || PriceConstants.ZONE_MSG_TYPE_CRE.equals(msgType)){
					if(Dockyard.isSpaceOrNull(zoneGrpDoc)){
						LOGGER.error(
								"Reference is not available in zone group document for zone Id - "
										+ zoneId);
						rejectedProducts
								.add("Reference is not available in zone group document for zone Id - "
										.concat(zoneId));
					}
				}
				zoneIdsInZoneGrpDoc = zoneGrpDoc.getZoneIds();
				if(PriceConstants.ZONE_MSG_TYPE_DEL.equals(msgType)) {
					if (!Dockyard.isSpaceOrNull(zoneIdsInZoneGrpDoc)
							&& zoneIdsInZoneGrpDoc.contains(zoneId)) {
						zoneIdsInZoneGrpDoc.remove(zoneId);
						zoneGrpDoc.setZoneIds(zoneIdsInZoneGrpDoc);
						repository.insertObject(
								PriceConstants.ZONE_GRP_KEY + zoneGrpId,
								zoneGrpDoc);

					} else {
						LOGGER.error(
								"Reference is not available in zone group document for zone Id - "
										+ zoneId);
						rejectedProducts
								.add("Reference is not available in zone group document for zone Id - "
										.concat(zoneId));
					}
				}else if(PriceConstants.ZONE_MSG_TYPE_CRE.equals(msgType)){
					if (Dockyard.isSpaceOrNull(zoneIdsInZoneGrpDoc)) {
						zoneIdsInZoneGrpDoc = new ArrayList<String>();
					}
						zoneIdsInZoneGrpDoc.add(zoneId);
						zoneGrpDoc.setZoneIds(zoneIdsInZoneGrpDoc);
						repository.insertObject(
								PriceConstants.ZONE_GRP_KEY + zoneGrpId,
								zoneGrpDoc);

				}
			}

			if (!rejectedProducts.isEmpty()) {
				writeRejects(rejectedProducts);
				rejectedProducts.clear();
				throw new ZoneBusinessException(
						"Error while deleting the zone document");
			}
		}catch(Exception e){
			throw new ZoneBusinessException(e.getMessage(),e);
		}

	}

}
