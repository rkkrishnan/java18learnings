package com.tesco.services.exceptions;

/**
 * Created by QP65 on 10/8/2015.
 */
public class PriceJMXException extends Exception {
	public PriceJMXException() {
		// TODO Auto-generated constructor stub
	}

	public PriceJMXException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public PriceJMXException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public PriceJMXException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public PriceJMXException(String message, Throwable cause,
	boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}
}
