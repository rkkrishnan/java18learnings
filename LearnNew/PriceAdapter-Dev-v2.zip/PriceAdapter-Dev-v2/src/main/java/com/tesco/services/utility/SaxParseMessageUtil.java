package com.tesco.services.utility;

import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import java.io.File;
import java.io.IOException;

/**
 * Created by PO47 on 25/11/2015.
 */
public class SaxParseMessageUtil {

	private static SaxParseMessageUtil messageParseUtil = null;

	public static SaxParseMessageUtil getInstance() {
		if (messageParseUtil == null) {
			messageParseUtil = new SaxParseMessageUtil();
		}
		return messageParseUtil;
	}

	private SaxParseMessageUtil() {
	}

	public void saxParserForXmlData(DefaultHandler handler,
			File filePath) throws IOException {
		try {
			SAXParserFactory factory = SAXParserFactory.newInstance();
			SAXParser saxParser = factory.newSAXParser();
			saxParser.parse(filePath, handler);
		} catch (SAXException | ParserConfigurationException e) {
			throw new IOException(e);
		}
	}
}
