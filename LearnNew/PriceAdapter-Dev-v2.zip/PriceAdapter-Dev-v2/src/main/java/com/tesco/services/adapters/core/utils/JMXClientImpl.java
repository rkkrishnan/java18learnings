package com.tesco.services.adapters.core.utils;

import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.management.AttributeNotFoundException;
import javax.management.InstanceNotFoundException;
import javax.management.MBeanException;
import javax.management.MBeanServerConnection;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import javax.management.ReflectionException;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;

import org.glassfish.hk2.api.ServiceLocator;
import org.slf4j.Logger;

import com.tesco.services.Configuration;
import com.tesco.services.exceptions.ClearanceJMXException;
import com.tesco.services.exceptions.EventJMXException;
import com.tesco.services.exceptions.PriceJMXException;
import com.tesco.services.exceptions.PromoJMXException;
import com.tesco.services.exceptions.ZoneJMXException;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;

public class JMXClientImpl implements JMXClient {
	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(JMXClientImpl.class);

	Configuration configuration;

	ServiceLocator serviceLocator;

	JMXConnector connector;

	public JMXClientImpl(Configuration injectedConfiguration,
			ServiceLocator serviceLocator) {
		this.configuration = injectedConfiguration;
		this.serviceLocator = serviceLocator;
	}

	private JMXConnector initializeJMXConnector() {
		Map<String, String[]> env = new HashMap<String, String[]>();
		env.put(JMXConnector.CREDENTIALS,
				new String[] { configuration.getJmxConnectorUid(),
						configuration.getJmxConnectorPwd() });

		try {
			JMXServiceURL address = new JMXServiceURL(
					configuration.getJmxServiceUrl());
			connector = JMXConnectorFactory.connect(address, env);
		} catch (IOException e) {
			LOGGER.error("Unable to connect to JMX Service {}", e);
		}
		return connector;
	}

	public void setConnector(JMXConnector connector) {
		this.connector = connector;
	}

	private MBeanServerConnection initializeMBeanConnection()
			throws PromoJMXException {
		MBeanServerConnection mbeanServerConn = null;
		try {
			if (connector == null) {
				mbeanServerConn = initializeJMXConnector()
						.getMBeanServerConnection();
			} else {
				mbeanServerConn = connector.getMBeanServerConnection();
			}
		} catch (IOException e) {
			LOGGER.error("Unable to get to Mbean connection {}", e);
			throw new PromoJMXException(e);
		}
		return mbeanServerConn;
	}

	@Override
	public Map<String, TimerMetrics> getPromotionLoadMetrics()
			throws PromoJMXException {

		LOGGER.info("Enter getPromotionLoadMetrics()");

		MBeanServerConnection mbeanServerConn = null;

		try {
			mbeanServerConn = initializeMBeanConnection();
		} catch (PromoJMXException e) {
			LOGGER.error("MBean initialization error {}", e);
		}

		Map<String, TimerMetrics> promoTimerMetricsList = new LinkedHashMap<String, TimerMetrics>();
		if (mbeanServerConn != null) {
			try {

				for (ObjectName promoMetricObjName : getPromotionTimerMetricNameList()) {

					TimerMetrics promoTimerMetric = new TimerMetrics();
					promoTimerMetric.setLatency(new LatencyMetrics());
					promoTimerMetric.setThroughput(new RateMetrics());

					promoTimerMetric.setCount(mbeanServerConn.getAttribute(
							promoMetricObjName, MetricsConstants.COUNT)
							.toString());

					promoTimerMetric.getLatency().setMinResponseTime(
							mbeanServerConn.getAttribute(promoMetricObjName,
									MetricsConstants.MIN_RESPONSE_TIME)
									.toString());

					promoTimerMetric.getLatency().setMaxResponseTime(
							mbeanServerConn.getAttribute(promoMetricObjName,
									MetricsConstants.MAX_RESPONSE_TIME)
									.toString());

					promoTimerMetric.getLatency().setMeanResponseTime(
							mbeanServerConn.getAttribute(promoMetricObjName,
									MetricsConstants.MEAN_RESPONSE_TIME)
									.toString());

					promoTimerMetric.getLatency().setLatencyUnit(
							mbeanServerConn.getAttribute(promoMetricObjName,
									MetricsConstants.RESPONSE_TIME_UNIT)
									.toString());

					promoTimerMetric.getThroughput().setOneMinuteRate(
							mbeanServerConn.getAttribute(promoMetricObjName,
									MetricsConstants.RESPONSE_RATE_IN_A_MINUTE)
									.toString());

					promoTimerMetric
							.getThroughput()
							.setFiveMinuteRate(
									mbeanServerConn
											.getAttribute(
													promoMetricObjName,
													MetricsConstants.RESPONSE_RATE_IN_FIVE_MINUTES)
											.toString());

					promoTimerMetric
							.getThroughput()
							.setFifteenMinuteRate(
									mbeanServerConn
											.getAttribute(
													promoMetricObjName,
													MetricsConstants.RESPONSE_RATE_IN_FIFTEEN_MINUTES)
											.toString());

					promoTimerMetric.getThroughput().setMeanRate(
							mbeanServerConn.getAttribute(promoMetricObjName,
									MetricsConstants.MEAN_RESPONSE_RATE)
									.toString());

					promoTimerMetric.getThroughput().setRateUnit(
							mbeanServerConn.getAttribute(promoMetricObjName,
									MetricsConstants.RESPONSE_RATE_UNIT)
									.toString());

					promoTimerMetricsList.put(promoMetricObjName
							.getKeyProperty("type").replace("\"", "")
							+ " - "
							+ promoMetricObjName.getKeyProperty("name")
									.replace("\"", ""), promoTimerMetric);
				}

				for (ObjectName promoMetricObjName : getPromotionCounterMetricNameList()) {
					TimerMetrics promoTimerMetric = new TimerMetrics();
					promoTimerMetric.setCount(mbeanServerConn.getAttribute(
							promoMetricObjName, MetricsConstants.COUNT)
							.toString());
					promoTimerMetricsList.put(promoMetricObjName
							.getKeyProperty("type").replace("\"", "")
							+ " - "
							+ promoMetricObjName.getKeyProperty("name")
									.replace("\"", ""), promoTimerMetric);
				}

			} catch (IOException | InstanceNotFoundException
					| ReflectionException | MalformedObjectNameException
					| AttributeNotFoundException | MBeanException e) {
				LOGGER.error("Unable to load promo metrics : {}", e);
				throw new PromoJMXException(e);
			}
		} else {
			throw new PromoJMXException("JMX service not available");
		}
		LOGGER.info("Exit getPromotionLoadMetrics()");
		return promoTimerMetricsList;
	}

	@Override
	public void resetPromotionMetrics() throws PromoJMXException {
		LOGGER.info("Enter resetPromotionMetrics()");
		PromotionMetrics promoMetrics = serviceLocator.getService(
				PromotionMetrics.class, "promotionMetricsListener");
		promoMetrics.resetMetrics();
		LOGGER.info("Exit resetPromotionMetrics()");
	}

	private List<ObjectName> getPromotionTimerMetricNameList()
			throws MalformedObjectNameException {

		List<ObjectName> metricNameList = new LinkedList<ObjectName>();
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-message\",type=\"OverallPromotionElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-cre-mod-message\",type=\"SimplePromotionElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-del-message\",type=\"SimplePromotionElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-cre-mod-message\",type=\"ThresholdPromotionElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-del-message\",type=\"ThresholdPromotionElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-cre-mod-message\",type=\"MultibuyPromotionElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-del-message\",type=\"MultibuyPromotionElapsedTimeAndRate\""));

		return metricNameList;
	}

	private List<ObjectName> getPromotionCounterMetricNameList()
			throws MalformedObjectNameException {

		List<ObjectName> metricNameList = new LinkedList<ObjectName>();

		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"total-error-count\",type=\"PromotionMessageProcessingErrors\""));

		return metricNameList;
	}

	/**
	 * Price XML message performance stats..
	 * 
	 * @return
	 * @throws PriceJMXException
	 */
	@Override
	public Map<String, TimerMetrics> getPriceLoadMetrics()
			throws PriceJMXException {

		LOGGER.info("Enter getPriceLoadMetrics()");

		MBeanServerConnection mbeanServerConn = null;

		try {
			mbeanServerConn = initializeMBeanConnection();
		} catch (PromoJMXException e) {
			LOGGER.error("MBean initialization error {}", e);
		}

		Map<String, TimerMetrics> priceTimerMetricsList = new LinkedHashMap<String, TimerMetrics>();

		if (mbeanServerConn != null) {

			try {
				for (ObjectName priceMetricObjName : getPriceTimerMetricNameList()) {

					TimerMetrics priceTimerMetric = new TimerMetrics();
					priceTimerMetric.setLatency(new LatencyMetrics());
					priceTimerMetric.setThroughput(new RateMetrics());

					priceTimerMetric.setCount(mbeanServerConn.getAttribute(
							priceMetricObjName, MetricsConstants.COUNT)
							.toString());

					priceTimerMetric.getLatency().setMinResponseTime(
							mbeanServerConn.getAttribute(priceMetricObjName,
									MetricsConstants.MIN_RESPONSE_TIME)
									.toString());

					priceTimerMetric.getLatency().setMaxResponseTime(
							mbeanServerConn.getAttribute(priceMetricObjName,
									MetricsConstants.MAX_RESPONSE_TIME)
									.toString());

					priceTimerMetric.getLatency().setMeanResponseTime(
							mbeanServerConn.getAttribute(priceMetricObjName,
									MetricsConstants.MEAN_RESPONSE_TIME)
									.toString());

					priceTimerMetric.getLatency().setLatencyUnit(
							mbeanServerConn.getAttribute(priceMetricObjName,
									MetricsConstants.RESPONSE_TIME_UNIT)
									.toString());

					priceTimerMetric.getThroughput().setOneMinuteRate(
							mbeanServerConn.getAttribute(priceMetricObjName,
									MetricsConstants.RESPONSE_RATE_IN_A_MINUTE)
									.toString());

					priceTimerMetric
							.getThroughput()
							.setFiveMinuteRate(
									mbeanServerConn
											.getAttribute(
													priceMetricObjName,
													MetricsConstants.RESPONSE_RATE_IN_FIVE_MINUTES)
											.toString());

					priceTimerMetric
							.getThroughput()
							.setFifteenMinuteRate(
									mbeanServerConn
											.getAttribute(
													priceMetricObjName,
													MetricsConstants.RESPONSE_RATE_IN_FIFTEEN_MINUTES)
											.toString());

					priceTimerMetric.getThroughput().setMeanRate(
							mbeanServerConn.getAttribute(priceMetricObjName,
									MetricsConstants.MEAN_RESPONSE_RATE)
									.toString());

					priceTimerMetric.getThroughput().setRateUnit(
							mbeanServerConn.getAttribute(priceMetricObjName,
									MetricsConstants.RESPONSE_RATE_UNIT)
									.toString());

					priceTimerMetricsList.put(priceMetricObjName
							.getKeyProperty("type").replace("\"", "")
							+ " - "
							+ priceMetricObjName.getKeyProperty("name")
									.replace("\"", ""), priceTimerMetric);
				}

				for (ObjectName priceMetricObjName : getPriceCounterMetricNameList()) {
					TimerMetrics promoTimerMetric = new TimerMetrics();
					promoTimerMetric.setCount(mbeanServerConn.getAttribute(
							priceMetricObjName, MetricsConstants.COUNT)
							.toString());
					priceTimerMetricsList.put(priceMetricObjName
							.getKeyProperty("type").replace("\"", "")
							+ " - "
							+ priceMetricObjName.getKeyProperty("name")
									.replace("\"", ""), promoTimerMetric);
				}

			} catch (IOException | InstanceNotFoundException
					| ReflectionException | MalformedObjectNameException
					| AttributeNotFoundException | MBeanException e) {
				LOGGER.error("Unable to load price metrics : {}", e);
				throw new PriceJMXException(e);
			}
		} else {
			throw new PriceJMXException("JMX service not available");
		}
		LOGGER.info("Exit getPriceLoadMetrics()");
		return priceTimerMetricsList;
	}

	@Override
	public void resetPriceMetrics() throws PriceJMXException {
		LOGGER.info("Enter resetPriceMetrics()");
		PriceMetrics priceMetrics = serviceLocator.getService(
				PriceMetrics.class, "priceMetricsListener");
		priceMetrics.resetMetrics();
		LOGGER.info("Exit resetPriceMetrics()");
	}

	private List<ObjectName> getPriceTimerMetricNameList()
			throws MalformedObjectNameException {

		List<ObjectName> metricNameList = new LinkedList<ObjectName>();
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-message\",type=\"OverallPriceElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-cre-message\",type=\"PriceElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-del-message\",type=\"PriceElapsedTimeAndRate\""));
		return metricNameList;
	}

	private List<ObjectName> getPriceCounterMetricNameList()
			throws MalformedObjectNameException {
		List<ObjectName> metricNameList = new LinkedList<ObjectName>();
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"total-error-count\",type=\"PriceMessageProcessingErrors\""));
		return metricNameList;
	}

	@Override
	public void resetZoneMetrics() throws ZoneJMXException {
		LOGGER.info("Enter resetZoneMetrics()");
		ZoneMetrics zoneMetrics = serviceLocator.getService(ZoneMetrics.class,
				"zoneMetricsListener");
		zoneMetrics.resetMetrics();
		LOGGER.info("Exit resetZoneMetrics()");
	}

	/**
	 * Price XML message performance stats..
	 *
	 * @return
	 * @throws ZoneJMXException
	 */
	@Override
	public Map<String, TimerMetrics> getZoneLoadMetrics()
			throws ZoneJMXException {

		LOGGER.info("Enter getZoneLoadMetrics()");

		MBeanServerConnection mbeanServerConn = null;

		try {
			mbeanServerConn = initializeMBeanConnection();
		} catch (PromoJMXException e) {
			LOGGER.error("MBean initialization error {}", e);
		}

		Map<String, TimerMetrics> zoneTimerMetricsList = new LinkedHashMap<String, TimerMetrics>();

		if (mbeanServerConn != null) {

			try {
				for (ObjectName zoneMetricObjName : getZoneTimerMetricsList()) {

					TimerMetrics zoneTimerMetric = new TimerMetrics();
					zoneTimerMetric.setLatency(new LatencyMetrics());
					zoneTimerMetric.setThroughput(new RateMetrics());

					zoneTimerMetric.setCount(mbeanServerConn.getAttribute(
							zoneMetricObjName, MetricsConstants.COUNT)
							.toString());

					zoneTimerMetric.getLatency().setMinResponseTime(
							mbeanServerConn.getAttribute(zoneMetricObjName,
									MetricsConstants.MIN_RESPONSE_TIME)
									.toString());

					zoneTimerMetric.getLatency().setMaxResponseTime(
							mbeanServerConn.getAttribute(zoneMetricObjName,
									MetricsConstants.MAX_RESPONSE_TIME)
									.toString());

					zoneTimerMetric.getLatency().setMeanResponseTime(
							mbeanServerConn.getAttribute(zoneMetricObjName,
									MetricsConstants.MEAN_RESPONSE_TIME)
									.toString());

					zoneTimerMetric.getLatency().setLatencyUnit(
							mbeanServerConn.getAttribute(zoneMetricObjName,
									MetricsConstants.RESPONSE_TIME_UNIT)
									.toString());

					zoneTimerMetric.getThroughput().setOneMinuteRate(
							mbeanServerConn.getAttribute(zoneMetricObjName,
									MetricsConstants.RESPONSE_RATE_IN_A_MINUTE)
									.toString());

					zoneTimerMetric
							.getThroughput()
							.setFiveMinuteRate(
									mbeanServerConn
											.getAttribute(
													zoneMetricObjName,
													MetricsConstants.RESPONSE_RATE_IN_FIVE_MINUTES)
											.toString());

					zoneTimerMetric
							.getThroughput()
							.setFifteenMinuteRate(
									mbeanServerConn
											.getAttribute(
													zoneMetricObjName,
													MetricsConstants.RESPONSE_RATE_IN_FIFTEEN_MINUTES)
											.toString());

					zoneTimerMetric.getThroughput().setMeanRate(
							mbeanServerConn.getAttribute(zoneMetricObjName,
									MetricsConstants.MEAN_RESPONSE_RATE)
									.toString());

					zoneTimerMetric.getThroughput().setRateUnit(
							mbeanServerConn.getAttribute(zoneMetricObjName,
									MetricsConstants.RESPONSE_RATE_UNIT)
									.toString());

					zoneTimerMetricsList
							.put(zoneMetricObjName.getKeyProperty("type")
									.replace("\"", "")
									+ " - "
									+ zoneMetricObjName.getKeyProperty("name")
											.replace("\"", ""), zoneTimerMetric);
				}

				for (ObjectName zoneMetricObjName : getZoneCounterMetricList()) {
					TimerMetrics promoTimerMetric = new TimerMetrics();
					promoTimerMetric.setCount(mbeanServerConn.getAttribute(
							zoneMetricObjName, MetricsConstants.COUNT)
							.toString());
					zoneTimerMetricsList.put(
							zoneMetricObjName.getKeyProperty("type").replace(
									"\"", "")
									+ " - "
									+ zoneMetricObjName.getKeyProperty("name")
											.replace("\"", ""),
							promoTimerMetric);
				}

			} catch (IOException | InstanceNotFoundException
					| ReflectionException | MalformedObjectNameException
					| AttributeNotFoundException | MBeanException e) {
				LOGGER.error("Unable to load price metrics : {}", e);
				throw new ZoneJMXException(e);
			}
		} else {
			throw new ZoneJMXException("JMX service not available");
		}
		LOGGER.info("Exit getZoneLoadMetrics()");
		return zoneTimerMetricsList;
	}

	private List<ObjectName> getZoneTimerMetricsList()
			throws MalformedObjectNameException {

		List<ObjectName> metricNameList = new LinkedList<ObjectName>();

		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-message\",type=\"OverallZoneElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-cre-message\",type=\"ZoneElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-mod-message\",type=\"ZoneElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-del-message\",type=\"ZoneElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-cre-group-message\",type=\"ZoneElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-mod-group-message\",type=\"ZoneElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-del-group-message\",type=\"ZoneElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-cre-loc-message\",type=\"ZoneElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-del-loc-message\",type=\"ZoneElapsedTimeAndRate\""));
		return metricNameList;
	}

	private List<ObjectName> getZoneCounterMetricList()
			throws MalformedObjectNameException {

		List<ObjectName> metricNameList = new LinkedList<ObjectName>();

		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"total-error-count\",type=\"ZoneMessageProcessingErrors\""));

		return metricNameList;
	}

	/**
	 * Clearance MM message performance stats..
	 *
	 * @return
	 * @throws ClearanceJMXException
	 */
	@Override
	public Map<String, TimerMetrics> getMMClearanceLoadMetrics()
			throws ClearanceJMXException {

		LOGGER.info("Enter getMMClearanceLoadMetrics()");

		MBeanServerConnection mbeanServerConn = null;

		try {
			mbeanServerConn = initializeMBeanConnection();
		} catch (PromoJMXException e) {
			LOGGER.error("MBean initialization error {}", e);
		}

		Map<String, TimerMetrics> mmClearanceTimerMetricsList = new LinkedHashMap<String, TimerMetrics>();

		if (mbeanServerConn != null) {

			try {
				for (ObjectName mmClearanceMetricObjName : getMMClearanceTimerMetricNameList()) {

					TimerMetrics mmClearanceTimerMetric = new TimerMetrics();
					mmClearanceTimerMetric.setLatency(new LatencyMetrics());
					mmClearanceTimerMetric.setThroughput(new RateMetrics());

					mmClearanceTimerMetric.setCount(mbeanServerConn
							.getAttribute(mmClearanceMetricObjName,
									MetricsConstants.COUNT).toString());

					mmClearanceTimerMetric.getLatency().setMinResponseTime(
							mbeanServerConn.getAttribute(
									mmClearanceMetricObjName,
									MetricsConstants.MIN_RESPONSE_TIME)
									.toString());

					mmClearanceTimerMetric.getLatency().setMaxResponseTime(
							mbeanServerConn.getAttribute(
									mmClearanceMetricObjName,
									MetricsConstants.MAX_RESPONSE_TIME)
									.toString());

					mmClearanceTimerMetric.getLatency().setMeanResponseTime(
							mbeanServerConn.getAttribute(
									mmClearanceMetricObjName,
									MetricsConstants.MEAN_RESPONSE_TIME)
									.toString());

					mmClearanceTimerMetric.getLatency().setLatencyUnit(
							mbeanServerConn.getAttribute(
									mmClearanceMetricObjName,
									MetricsConstants.RESPONSE_TIME_UNIT)
									.toString());

					mmClearanceTimerMetric.getThroughput().setOneMinuteRate(
							mbeanServerConn.getAttribute(
									mmClearanceMetricObjName,
									MetricsConstants.RESPONSE_RATE_IN_A_MINUTE)
									.toString());

					mmClearanceTimerMetric
							.getThroughput()
							.setFiveMinuteRate(
									mbeanServerConn
											.getAttribute(
													mmClearanceMetricObjName,
													MetricsConstants.RESPONSE_RATE_IN_FIVE_MINUTES)
											.toString());

					mmClearanceTimerMetric
							.getThroughput()
							.setFifteenMinuteRate(
									mbeanServerConn
											.getAttribute(
													mmClearanceMetricObjName,
													MetricsConstants.RESPONSE_RATE_IN_FIFTEEN_MINUTES)
											.toString());

					mmClearanceTimerMetric.getThroughput().setMeanRate(
							mbeanServerConn.getAttribute(
									mmClearanceMetricObjName,
									MetricsConstants.MEAN_RESPONSE_RATE)
									.toString());

					mmClearanceTimerMetric.getThroughput().setRateUnit(
							mbeanServerConn.getAttribute(
									mmClearanceMetricObjName,
									MetricsConstants.RESPONSE_RATE_UNIT)
									.toString());

					mmClearanceTimerMetricsList.put(mmClearanceMetricObjName
							.getKeyProperty("type").replace("\"", "")
							+ " - "
							+ mmClearanceMetricObjName.getKeyProperty("name")
									.replace("\"", ""), mmClearanceTimerMetric);
				}

				for (ObjectName mmClearanceMetricObjName : getMMClearanceCounterMetricNameList()) {
					TimerMetrics mmClearanceTimerMetric = new TimerMetrics();
					mmClearanceTimerMetric.setCount(mbeanServerConn
							.getAttribute(mmClearanceMetricObjName,
									MetricsConstants.COUNT).toString());
					mmClearanceTimerMetricsList.put(mmClearanceMetricObjName
							.getKeyProperty("type").replace("\"", "")
							+ " - "
							+ mmClearanceMetricObjName.getKeyProperty("name")
									.replace("\"", ""), mmClearanceTimerMetric);
				}

			} catch (IOException | InstanceNotFoundException
					| ReflectionException | MalformedObjectNameException
					| AttributeNotFoundException | MBeanException e) {
				LOGGER.error("Unable to load clearance metrics : {}", e);
				throw new ClearanceJMXException(e);
			}
		} else {
			throw new ClearanceJMXException("JMX service not available");
		}
		LOGGER.info("Exit getMMClearanceLoadMetrics()");
		return mmClearanceTimerMetricsList;
	}

	@Override
	public void resetMMClearanceMetrics() throws ClearanceJMXException {
		LOGGER.info("Enter resetMMClearanceMetrics()");

		MMClearanceMetrics clearanceMetrics = MMClearanceMetrics.getInstance();
		clearanceMetrics.resetCounters();

		LOGGER.info("Exit resetMMClearanceMetrics()");
	}

	private List<ObjectName> getMMClearanceTimerMetricNameList()
			throws MalformedObjectNameException {

		List<ObjectName> metricNameList = new LinkedList<ObjectName>();
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-message\",type=\"MMClearanceElapsedTimeAndRate\""));
		return metricNameList;
	}

	private List<ObjectName> getMMClearanceCounterMetricNameList()
			throws MalformedObjectNameException {

		List<ObjectName> metricNameList = new LinkedList<ObjectName>();

		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"total-error-count\",type=\"MMClearanceMessageProcessingErrors\""));

		return metricNameList;
	}

	/**
	 * Clearance RPM message performance stats..
	 *
	 * @return
	 * @throws ClearanceJMXException
	 */
	@Override
	public Map<String, TimerMetrics> getRPMClearanceLoadMetrics()
			throws ClearanceJMXException {

		LOGGER.info("Enter getRPMClearanceLoadMetrics()");

		MBeanServerConnection mbeanServerConn = null;

		try {
			mbeanServerConn = initializeMBeanConnection();
		} catch (PromoJMXException e) {
			LOGGER.error("MBean initialization error {}", e);
		}

		Map<String, TimerMetrics> rpmClearanceTimerMetricsList = new LinkedHashMap<String, TimerMetrics>();

		if (mbeanServerConn != null) {

			try {
				for (ObjectName rpmClearanceMetricObjName : getRPMClearanceTimerMetricNameList()) {

					TimerMetrics rpmClearanceTimerMetric = new TimerMetrics();
					rpmClearanceTimerMetric.setLatency(new LatencyMetrics());
					rpmClearanceTimerMetric.setThroughput(new RateMetrics());

					rpmClearanceTimerMetric.setCount(mbeanServerConn
							.getAttribute(rpmClearanceMetricObjName,
									MetricsConstants.COUNT).toString());

					rpmClearanceTimerMetric.getLatency().setMinResponseTime(
							mbeanServerConn.getAttribute(
									rpmClearanceMetricObjName,
									MetricsConstants.MIN_RESPONSE_TIME)
									.toString());

					rpmClearanceTimerMetric.getLatency().setMaxResponseTime(
							mbeanServerConn.getAttribute(
									rpmClearanceMetricObjName,
									MetricsConstants.MAX_RESPONSE_TIME)
									.toString());

					rpmClearanceTimerMetric.getLatency().setMeanResponseTime(
							mbeanServerConn.getAttribute(
									rpmClearanceMetricObjName,
									MetricsConstants.MEAN_RESPONSE_TIME)
									.toString());

					rpmClearanceTimerMetric.getLatency().setLatencyUnit(
							mbeanServerConn.getAttribute(
									rpmClearanceMetricObjName,
									MetricsConstants.RESPONSE_TIME_UNIT)
									.toString());

					rpmClearanceTimerMetric.getThroughput().setOneMinuteRate(
							mbeanServerConn.getAttribute(
									rpmClearanceMetricObjName,
									MetricsConstants.RESPONSE_RATE_IN_A_MINUTE)
									.toString());

					rpmClearanceTimerMetric
							.getThroughput()
							.setFiveMinuteRate(
									mbeanServerConn
											.getAttribute(
													rpmClearanceMetricObjName,
													MetricsConstants.RESPONSE_RATE_IN_FIVE_MINUTES)
											.toString());

					rpmClearanceTimerMetric
							.getThroughput()
							.setFifteenMinuteRate(
									mbeanServerConn
											.getAttribute(
													rpmClearanceMetricObjName,
													MetricsConstants.RESPONSE_RATE_IN_FIFTEEN_MINUTES)
											.toString());

					rpmClearanceTimerMetric.getThroughput().setMeanRate(
							mbeanServerConn.getAttribute(
									rpmClearanceMetricObjName,
									MetricsConstants.MEAN_RESPONSE_RATE)
									.toString());

					rpmClearanceTimerMetric.getThroughput().setRateUnit(
							mbeanServerConn.getAttribute(
									rpmClearanceMetricObjName,
									MetricsConstants.RESPONSE_RATE_UNIT)
									.toString());

					rpmClearanceTimerMetricsList
							.put(rpmClearanceMetricObjName.getKeyProperty(
									"type").replace("\"", "")
									+ " - "
									+ rpmClearanceMetricObjName.getKeyProperty(
											"name").replace("\"", ""),
									rpmClearanceTimerMetric);
				}

				for (ObjectName rpmClearanceMetricObjName : getRPMClearanceCounterMetricNameList()) {
					TimerMetrics rpmClearanceTimerMetric = new TimerMetrics();
					rpmClearanceTimerMetric.setCount(mbeanServerConn
							.getAttribute(rpmClearanceMetricObjName,
									MetricsConstants.COUNT).toString());
					rpmClearanceTimerMetricsList
							.put(rpmClearanceMetricObjName.getKeyProperty(
									"type").replace("\"", "")
									+ " - "
									+ rpmClearanceMetricObjName.getKeyProperty(
											"name").replace("\"", ""),
									rpmClearanceTimerMetric);
				}

			} catch (IOException | InstanceNotFoundException
					| ReflectionException | MalformedObjectNameException
					| AttributeNotFoundException | MBeanException e) {
				LOGGER.error("Unable to load clearance metrics : {}", e);
				throw new ClearanceJMXException(e);
			}
		} else {
			throw new ClearanceJMXException("JMX service not available");
		}
		LOGGER.info("Exit getRPMClearanceLoadMetrics()");
		return rpmClearanceTimerMetricsList;
	}

	@Override
	public void resetRPMClearanceMetrics() throws ClearanceJMXException {
		LOGGER.info("Enter resetRPMClearanceMetrics()");

		RPMClearanceMetrics clearanceMetrics = RPMClearanceMetrics
				.getInstance();
		clearanceMetrics.resetCounters();

		LOGGER.info("Exit resetRPMClearanceMetrics()");
	}

	private List<ObjectName> getRPMClearanceTimerMetricNameList()
			throws MalformedObjectNameException {

		List<ObjectName> metricNameList = new LinkedList<ObjectName>();
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-message\",type=\"RPMClearanceElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-cre-message\",type=\"RPMClearanceElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-mod-message\",type=\"RPMClearanceElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-del-message\",type=\"RPMClearanceElapsedTimeAndRate\""));

		return metricNameList;
	}

	private List<ObjectName> getRPMClearanceCounterMetricNameList()
			throws MalformedObjectNameException {

		List<ObjectName> metricNameList = new LinkedList<ObjectName>();

		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"total-cre-error-message-count\",type=\"RPMClearanceMessageProcessingErrors\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"total-mod-error-message-count\",type=\"RPMClearanceMessageProcessingErrors\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"total-del-error-message-count\",type=\"RPMClearanceMessageProcessingErrors\""));
		return metricNameList;
	}

	/**
	 * Event message performance stats..
	 *
	 * @return
	 * @throws EventJMXException
	 */
	@Override
	public Map<String, TimerMetrics> getEventLoadMetrics()
			throws EventJMXException {

		LOGGER.info("Enter getEventLoadMetrics()");

		MBeanServerConnection mbeanServerConn = null;

		try {
			mbeanServerConn = initializeMBeanConnection();
		} catch (PromoJMXException e) {
			LOGGER.error("MBean initialization error {}", e);
		}

		Map<String, TimerMetrics> eventTimerMetricsList = new LinkedHashMap<String, TimerMetrics>();

		if (mbeanServerConn != null) {

			try {
				for (ObjectName eventMetricObjName : getEventTimerMetricNameList()) {

					TimerMetrics eventTimerMetric = new TimerMetrics();
					eventTimerMetric.setLatency(new LatencyMetrics());
					eventTimerMetric.setThroughput(new RateMetrics());

					eventTimerMetric.setCount(mbeanServerConn.getAttribute(
							eventMetricObjName, MetricsConstants.COUNT)
							.toString());

					eventTimerMetric.getLatency().setMinResponseTime(
							mbeanServerConn.getAttribute(eventMetricObjName,
									MetricsConstants.MIN_RESPONSE_TIME)
									.toString());

					eventTimerMetric.getLatency().setMaxResponseTime(
							mbeanServerConn.getAttribute(eventMetricObjName,
									MetricsConstants.MAX_RESPONSE_TIME)
									.toString());

					eventTimerMetric.getLatency().setMeanResponseTime(
							mbeanServerConn.getAttribute(eventMetricObjName,
									MetricsConstants.MEAN_RESPONSE_TIME)
									.toString());

					eventTimerMetric.getLatency().setLatencyUnit(
							mbeanServerConn.getAttribute(eventMetricObjName,
									MetricsConstants.RESPONSE_TIME_UNIT)
									.toString());

					eventTimerMetric.getThroughput().setOneMinuteRate(
							mbeanServerConn.getAttribute(eventMetricObjName,
									MetricsConstants.RESPONSE_RATE_IN_A_MINUTE)
									.toString());

					eventTimerMetric
							.getThroughput()
							.setFiveMinuteRate(
									mbeanServerConn
											.getAttribute(
													eventMetricObjName,
													MetricsConstants.RESPONSE_RATE_IN_FIVE_MINUTES)
											.toString());

					eventTimerMetric
							.getThroughput()
							.setFifteenMinuteRate(
									mbeanServerConn
											.getAttribute(
													eventMetricObjName,
													MetricsConstants.RESPONSE_RATE_IN_FIFTEEN_MINUTES)
											.toString());

					eventTimerMetric.getThroughput().setMeanRate(
							mbeanServerConn.getAttribute(eventMetricObjName,
									MetricsConstants.MEAN_RESPONSE_RATE)
									.toString());

					eventTimerMetric.getThroughput().setRateUnit(
							mbeanServerConn.getAttribute(eventMetricObjName,
									MetricsConstants.RESPONSE_RATE_UNIT)
									.toString());

					eventTimerMetricsList.put(eventMetricObjName
							.getKeyProperty("type").replace("\"", "")
							+ " - "
							+ eventMetricObjName.getKeyProperty("name")
									.replace("\"", ""), eventTimerMetric);
				}

				for (ObjectName eventMetricObjName : getEventsCounterMetricNameList()) {
					TimerMetrics eventTimerMetric = new TimerMetrics();
					eventTimerMetric.setCount(mbeanServerConn.getAttribute(
							eventMetricObjName, MetricsConstants.COUNT)
							.toString());
					eventTimerMetricsList.put(eventMetricObjName
							.getKeyProperty("type").replace("\"", "")
							+ " - "
							+ eventMetricObjName.getKeyProperty("name")
									.replace("\"", ""), eventTimerMetric);
				}

			} catch (IOException | InstanceNotFoundException
					| ReflectionException | MalformedObjectNameException
					| AttributeNotFoundException | MBeanException e) {
				LOGGER.error("Unable to load event metrics : {}", e);
				throw new EventJMXException(e);
			}
		} else {
			throw new EventJMXException("JMX service not available");
		}
		LOGGER.info("Exit getEventLoadMetrics()");
		return eventTimerMetricsList;
	}

	@Override
	public void resetEventMetrics() throws EventJMXException {
		LOGGER.info("Enter resetEventMetrics()");

		EventMetrics eventMetrics = EventMetrics.getInstance();
		eventMetrics.resetCounters();

		LOGGER.info("Exit resetEventMetrics()");
	}

	private List<ObjectName> getEventTimerMetricNameList()
			throws MalformedObjectNameException {

		List<ObjectName> metricNameList = new LinkedList<ObjectName>();
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-priceChanged-event\",type=\"EventsElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-priceDeleted-event\",type=\"EventsElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-promotionCreated-event\",type=\"EventsElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-zoneCreated-event\",type=\"EventsElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-zoneDetailsChanged-event\",type=\"EventsElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-zoneDeleted-event\",type=\"EventsElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-storeZoneChanged-event\",type=\"EventsElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-clearanceCreated-event\",type=\"EventsElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-clearanceDeleted-event\",type=\"EventsElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-priceChange-event\",type=\"EventsElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-promotionStart-event\",type=\"EventsElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-promotionEnd-event\",type=\"EventsElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-clearanceEndDateChanged-event\",type=\"EventsElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-clearancePrevPriceChanged-event\",type=\"EventsElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-clearanceStart-event\",type=\"EventsElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-clearanceEnd-event\",type=\"EventsElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-PromotionDetailsChanged-event\",type=\"EventsElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-PromotionDeleted-event\",type=\"EventsElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-PromotionLocationRemoved-event\",type=\"EventsElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-PromotionProductRemoved-event\",type=\"EventsElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-PromotionProductAdded-event\",type=\"EventsElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-PromotionEndDateChanged-event\",type=\"EventsElapsedTimeAndRate\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-PromotionLocationAdded-event\",type=\"EventsElapsedTimeAndRate\""));

		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"time-to-process-PromotionStartProduct-event\",type=\"EventsElapsedTimeAndRate\""));

		return metricNameList;
	}

	private List<ObjectName> getEventsCounterMetricNameList()
			throws MalformedObjectNameException {

		List<ObjectName> metricNameList = new LinkedList<ObjectName>();

		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"total-priceChanged-error-count\",type=\"EventsMessageProcessingErrors\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"total-priceDeleted-error-count\",type=\"EventsMessageProcessingErrors\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"total-promotionCreated-error-count\",type=\"EventsMessageProcessingErrors\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"total-zoneCreated-error-count\",type=\"EventsMessageProcessingErrors\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"total-zoneDetailsChanged-error-count\",type=\"EventsMessageProcessingErrors\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"total-zoneDeleted-error-count\",type=\"EventsMessageProcessingErrors\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"total-storeZoneChanged-error-count\",type=\"EventsMessageProcessingErrors\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"total-clearanceCreated-error-count\",type=\"EventsMessageProcessingErrors\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"total-clearanceDeleted-error-count\",type=\"EventsMessageProcessingErrors\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"total-priceChange-error-count\",type=\"EventsMessageProcessingErrors\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"total-promotionStart-error-count\",type=\"EventsMessageProcessingErrors\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"total-promotionEnd-error-count\",type=\"EventsMessageProcessingErrors\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"total-PromotionStartProduct-error-count\",type=\"EventsMessageProcessingErrors\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"total-clearanceEndDateChanged-error-count\",type=\"EventsMessageProcessingErrors\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"total-clearancePrevPriceChanged-error-count\",type=\"EventsMessageProcessingErrors\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"total-clearanceStart-error-count\",type=\"EventsMessageProcessingErrors\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"total-clearanceEnd-error-count\",type=\"EventsMessageProcessingErrors\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"total-PromotionDetailsChanged-error-count\",type=\"EventsMessageProcessingErrors\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"total-PromotionDeleted-error-count\",type=\"EventsMessageProcessingErrors\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"total-PromotionLocationRemoved-error-count\",type=\"EventsMessageProcessingErrors\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"total-PromotionProductRemoved-error-count\",type=\"EventsMessageProcessingErrors\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"total-PromotionProductAdded-error-count\",type=\"EventsMessageProcessingErrors\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"total-PromotionEndDateChanged-error-count\",type=\"EventsMessageProcessingErrors\""));
		metricNameList
				.add(new ObjectName(
						"\"com.tesco\":name=\"total-PromotionLocationAdded-error-count\",type=\"EventsMessageProcessingErrors\""));

		return metricNameList;
	}
}
