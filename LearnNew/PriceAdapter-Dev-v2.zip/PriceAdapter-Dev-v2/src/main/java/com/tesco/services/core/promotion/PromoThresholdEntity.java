package com.tesco.services.core.promotion;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PromoThresholdEntity implements Serializable {
    @JsonProperty("@type")
    public String type;
    @JsonProperty("thresholdType")
    public String thresholdType;
    @JsonProperty("thresholdAmount")
    public double thresholdAmount;
    @JsonProperty("thresholdCurrency")
    public String thresholdCurrency;
    @JsonProperty("thresholdQty")
    public int thresholdQty;

    @Override
    public String toString() {
        return "PromoThresholdEntity{" +
                "type='" + type + '\'' +
                ", thresholdType='" + thresholdType + '\'' +
                ", thresholdAmount=" + thresholdAmount +
                ", thresholdCurrency='" + thresholdCurrency + '\'' +
                ", thresholdQty=" + thresholdQty +
                '}';
    }

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(thresholdAmount);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((thresholdCurrency == null) ? 0 : thresholdCurrency.hashCode());
		result = prime * result + thresholdQty;
		result = prime * result + ((thresholdType == null) ? 0 : thresholdType.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PromoThresholdEntity other = (PromoThresholdEntity) obj;
		if (Double.doubleToLongBits(thresholdAmount) != Double.doubleToLongBits(other.thresholdAmount))
			return false;
		if (thresholdCurrency == null) {
			if (other.thresholdCurrency != null)
				return false;
		} else if (!thresholdCurrency.equals(other.thresholdCurrency))
			return false;
		if (thresholdQty != other.thresholdQty)
			return false;
		if (thresholdType == null) {
			if (other.thresholdType != null)
				return false;
		} else if (!thresholdType.equals(other.thresholdType))
			return false;
		if (type == null) {
			if (other.type != null)
				return false;
		} else if (!type.equals(other.type))
			return false;
		return true;
	}
}
