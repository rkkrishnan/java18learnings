package com.tesco.services.adapters.core;

import com.tesco.services.Configuration;
import com.tesco.services.adapters.rpm.writers.impl.ItemDefaultUomWriter;
import com.tesco.services.adapters.rpm.writers.Writer;
import com.tesco.services.resources.ImportResource;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;

public class ImportItemDefaultUomJob implements Import {
	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(ImportItemDefaultUomJob.class);

	private Configuration configuration;
	private String runIdentifier;
	private String fileName;
	private Writer itemDefaultUomWriter;

	/**
	 * @param configuration
	 * @param itemDefaultUomWriter
	 */
	@Inject
	public ImportItemDefaultUomJob(
			@Named("configuration") Configuration configuration,
			@Named("itemDefaultUomWriter") Writer itemDefaultUomWriter) {
		this.configuration = configuration;
		this.itemDefaultUomWriter = itemDefaultUomWriter;
	}

	public String getRunIdentifier() {
		return runIdentifier;
	}

	public void setRunIdentifier(String runIdentifier) {
		this.runIdentifier = runIdentifier;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	@Override
	public void run() {
		LOGGER.info("Firing up imports for Item Default Uom Mapping...{}",
				runIdentifier);
		startImportProcess();
	}

	public void startImportProcess() {
		try {
			LOGGER.info("Importing data for Item Default Uom from {} ",
					configuration.getRpmItemDefaultUomDump());

			((ItemDefaultUomWriter) itemDefaultUomWriter)
					.setRunIdentifier(getRunIdentifier());
			itemDefaultUomWriter.write(getFileName());
			LOGGER.info("Successfully completed imports for Item Default Uom");
		} catch (Exception exception) {
			LOGGER.error("Error importing ..", exception);
			ImportResource.setErrorString(runIdentifier,
					"Error importing Item Default Uom Mapping..");
		} finally {
			ImportResource.getImportSemaphoreForIdentifier(fileName).release();
		}
	}
}
