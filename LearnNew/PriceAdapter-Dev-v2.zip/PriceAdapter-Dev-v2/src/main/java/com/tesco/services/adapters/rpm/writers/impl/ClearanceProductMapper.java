package com.tesco.services.adapters.rpm.writers.impl;

import com.google.common.base.Optional;
import com.tesco.services.core.*;
import com.tesco.services.repositories.Repository;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.PriceConstants;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;
import org.slf4j.Logger;

import java.io.IOException;
import java.text.ParseException;
import java.util.HashSet;

/**
 * This class will map the line items from MM clearance file and constructs MM Clearance Product.
 * Method :mapLineDataToClearanceMMProduct() - Maps every field in the Line Item to MM clearance Product
 **/
public class ClearanceProductMapper {
    private static final Logger LOGGER = (Logger) LoggerFactoryWrapper.getLogger(ClearanceProductMapper.class);

    private Repository repository;
    private ClearanceMMProduct clearanceMMProduct;
    boolean isEligibleForDelete;
    boolean isEligibleForInsert;
    String tpnc;
    HashSet<String> productsWithoutPrice = new HashSet<>();
    String oldClearanceEndDate;

    public String getOldClearanceEndDate() {
		return oldClearanceEndDate;
	}

	public void setOldClearanceEndDate(String oldClearanceEndDate) {
		this.oldClearanceEndDate = oldClearanceEndDate;
	}

    public HashSet<String> getProductsWithoutPrice() {
        return productsWithoutPrice;
    }

    /**
     * Method setClearanceMMProduct
     */
    public void setClearanceMMProduct(){
        productsWithoutPrice.clear();
    }

    /**
     * Constructor ClearanceProductMapper
     * @param repository
     */
    public ClearanceProductMapper(Repository repository) {
        this.repository = repository;
    }

    /**
     * Method mapLineDataToClearanceMMProduct
     * @param line
     * @param isNewProduct
     * @return
     * @throws IOException
     * @throws ParseException
     */
    public ClearanceMMProduct mapLineDataToClearanceMMProduct(String line, boolean isNewProduct,String runIdentifier) throws IOException,ParseException {
        Optional<ClearanceMMProduct> clearanceMMProductByTPNB;
        ClearanceData clearanceData = new ClearanceData();
        clearanceData = clearanceData.getClearanceDataWithStore(line);
        String docType = clearanceData.getDocType();
        String dateTimeFormat = clearanceData.getDateTimeFormat();
        String countryFormat = clearanceData.getCountryFormat();
        String currencyFormat = clearanceData.getCurrenrcyFormat();
        String version = clearanceData.getVersion();
        String prodType = clearanceData.getProdType();
        String productId = clearanceData.getProductId();
        String storeId = clearanceData.getStoreId();
        String effevDate = clearanceData.getEffevDate();
        String chargeType = clearanceData.getChargeType();
        String action = clearanceData.getAction();
        String currencyCode = clearanceData.getCurrencyCode();
        String clearancePrice = clearanceData.getClearancePrice();
        String sourcesystem = clearanceData.getSourceSystem();
        String endDate = clearanceData.getEndDate();
       try{
        //Check if it is NewProduct
        if(isNewProduct){
            isEligibleForDelete = true;
            isEligibleForInsert = true;

            if(!(PriceConstants.RUN_IDENT_MMONDEMAND).equals(runIdentifier)) {

				ClearanceMMProduct product = (ClearanceMMProduct) repository
						.getGenericObject(PriceConstants.CLEARANCE_MM_PRODUCT_KEY_PREFIX+productId,ClearanceMMProduct.class);
				clearanceMMProductByTPNB = (product != null) ? Optional.of(product) : Optional
						.<ClearanceMMProduct> absent();
            }else
            {
                clearanceMMProductByTPNB=Optional.<ClearanceMMProduct>absent();
            }

            if(clearanceMMProductByTPNB.isPresent()){
                clearanceMMProduct = clearanceMMProductByTPNB.get();
            }else{
                if(("U").equalsIgnoreCase(action)||("I").equalsIgnoreCase(action)) {
                    //Optional<Product> product = productRepository.getByTPNB(productId);

					Product product = (Product) repository.getGenericObject(PriceConstants.PRODUCT_KEY_PREFIX+productId,Product.class);

                    if (product!=null) {
                        clearanceMMProduct = new ClearanceMMProduct(productId);
                        tpnc = repository.getMappedData(productId);
                        ProductVariant productVariant = product.getProductVariantByTPNC(tpnc);
                        clearanceMMProduct.setVersionNo(version);
                        clearanceMMProduct.setDocType(docType);
                        clearanceMMProduct.setCountryFormat(countryFormat);
                        clearanceMMProduct.setCurrencyFormat(currencyFormat);
                        clearanceMMProduct.setDateTimeFormat(dateTimeFormat);
                        clearanceMMProduct.setProdType(prodType);
                        clearanceMMProduct.setSellingUom(!Dockyard.isSpaceOrNull(productVariant.getSellingUOM()) ? productVariant.getSellingUOM():"");
                    } else {
                        isEligibleForInsert = false;

                            LOGGER.warn("Product {} doesn't have Price Info in PS ",productId);
                            productsWithoutPrice.add(productId+"|PRODUCT NOT FOUND");

                    }
                }else{
                    isEligibleForDelete = false;
                }
            }
        }}
            //Catch Block
            catch(Exception e){
                LOGGER.error("Product {} Failed to Upload due to {} ",productId,e);
        }
        if(("U").equalsIgnoreCase(action)||("I").equalsIgnoreCase(action)) {
            //Check isEligibleForInsert
            if (isEligibleForInsert) {

            ClearanceByDateTime clearanceByDateTime = new ClearanceByDateTime();
            clearanceByDateTime.setClearancePrice(clearancePrice);
            clearanceByDateTime.setClearanceRef(sourcesystem);
            clearanceByDateTime.setEffvDateTime(effevDate);
            clearanceByDateTime.setEndDateTime(endDate);

            if (("S").equals(chargeType)) {
                ClearanceStoreSaleInfo clearanceStoreSaleInfo = clearanceMMProduct.getClearanceStoreSaleInfo(storeId);
                if (clearanceStoreSaleInfo == null) {
                    clearanceStoreSaleInfo = new ClearanceStoreSaleInfo();
                    clearanceStoreSaleInfo.setClearanceStoreId(storeId);
                    clearanceStoreSaleInfo.setCurrency(currencyCode);
                    if (("GBP").equalsIgnoreCase(currencyCode)) {
                        clearanceStoreSaleInfo.setCountryCode("UK");
                        clearanceStoreSaleInfo.setCurrency(currencyCode);
                    } else {
                        clearanceStoreSaleInfo.setCountryCode("IE");
                        clearanceStoreSaleInfo.setCurrency("EUR");
                    }
                }
				processMMClearanceStoreEndDateUpdate(effevDate, action, clearanceStoreSaleInfo);
                clearanceStoreSaleInfo.addStoreClearanceByDateTime(clearanceByDateTime);
                clearanceMMProduct.addClearanceStoreSaleInfo(clearanceStoreSaleInfo);
            } else {
                ClearanceZoneSaleInfo clearanceZoneSaleInfo;
                if (("GBP").equalsIgnoreCase(currencyCode)) {
                    clearanceZoneSaleInfo = clearanceMMProduct.getClearanceZoneSaleInfo("20");
                    if (clearanceZoneSaleInfo == null) {
                        clearanceZoneSaleInfo = new ClearanceZoneSaleInfo();
                        clearanceZoneSaleInfo.setClearanceZoneId("20");
                        clearanceZoneSaleInfo.setCountryCode("UK");
                        clearanceZoneSaleInfo.setCurrency(currencyCode);
                    }
                } else {
                    clearanceZoneSaleInfo = clearanceMMProduct.getClearanceZoneSaleInfo("21");
                    if (clearanceZoneSaleInfo == null) {
                        clearanceZoneSaleInfo = new ClearanceZoneSaleInfo();
                        clearanceZoneSaleInfo.setClearanceZoneId("21");
                        clearanceZoneSaleInfo.setCountryCode("IE");
                        clearanceZoneSaleInfo.setCurrency("EUR");
                    }
                }
                processMMClearanceNationalEndDateUpdate(effevDate, action, clearanceZoneSaleInfo);
                clearanceZoneSaleInfo.addZoneClearanceByDateTime(clearanceByDateTime);
                clearanceMMProduct.addClearanceZoneSaleInfo(clearanceZoneSaleInfo);
            }

        }
        }else {
            //Check if isEligibleForDelete
            if (isEligibleForDelete) {
                if (("S").equals(chargeType)) {
                    ClearanceStoreSaleInfo clearanceStoreSaleInfo = clearanceMMProduct.getClearanceStoreSaleInfo(storeId);
                    ClearanceByDateTime clearanceByDateTime = clearanceStoreSaleInfo.getStoreClearancePriceByDateTime(effevDate);
                    clearanceStoreSaleInfo.deleteStoreClearanceByDateTime(clearanceByDateTime);
                    clearanceMMProduct.addClearanceStoreSaleInfo(clearanceStoreSaleInfo);
                } else {
                    ClearanceZoneSaleInfo clearanceZoneSaleInfo;
                    ClearanceByDateTime clearanceByDateTime;
                    if (("GBP").equalsIgnoreCase(currencyCode)) {
                        clearanceZoneSaleInfo = clearanceMMProduct.getClearanceZoneSaleInfo("20");
                        clearanceByDateTime = clearanceZoneSaleInfo.getZoneClearancePriceByDateTime(effevDate);
                        clearanceZoneSaleInfo.deleteZoneClearanceByDateTime(clearanceByDateTime);
                    } else {
                        clearanceZoneSaleInfo = clearanceMMProduct.getClearanceZoneSaleInfo("21");
                        clearanceByDateTime = clearanceZoneSaleInfo.getZoneClearancePriceByDateTime(effevDate);
                        clearanceZoneSaleInfo.deleteZoneClearanceByDateTime(clearanceByDateTime);
                    }
                    clearanceMMProduct.addClearanceZoneSaleInfo(clearanceZoneSaleInfo);
                }
            }
        }
        //Return the clearanceMMProduct
        return clearanceMMProduct;
    }

	private void processMMClearanceStoreEndDateUpdate(String effevDate, String action,
			ClearanceStoreSaleInfo clearanceStoreSaleInfo) throws ParseException {
		if ((PriceConstants.UPDATE_ACTION_FILE_CODE).equalsIgnoreCase(action)) {
			ClearanceByDateTime existingClearanceByDateTime = clearanceStoreSaleInfo
					.getStoreClearancePriceByDateTime(effevDate);
			if (existingClearanceByDateTime != null) {
				setOldClearanceEndDate(existingClearanceByDateTime.getEndDateTime());
			} else {
				setOldClearanceEndDate(null);
			}
		}
	}  
	
	/**
	 * @param effevDate
	 * @param action
	 * @param clearanceZoneSaleInfo
	 * @throws ParseException
	 */
	private void processMMClearanceNationalEndDateUpdate(String effevDate, String action,
			ClearanceZoneSaleInfo clearanceZoneSaleInfo) throws ParseException {
		if((PriceConstants.UPDATE_ACTION_FILE_CODE).equalsIgnoreCase(action) && clearanceZoneSaleInfo != null){
			 ClearanceByDateTime existingClearanceByDateTime = clearanceZoneSaleInfo.getZoneClearancePriceByDateTime(effevDate);
		     if(existingClearanceByDateTime != null){
		     	 setOldClearanceEndDate(existingClearanceByDateTime.getEndDateTime());
		     }else{
		    	 setOldClearanceEndDate(null); 
		     }
		}
	}

}
