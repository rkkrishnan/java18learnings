package com.tesco.services.adapters.price;

import com.tesco.price.core.RegPrcChgDesc;
import com.tesco.price.core.RegPrcChgRef;
import com.tesco.services.exceptions.PriceBusinessException;

public interface PriceHandler {
	public void processCre(RegPrcChgDesc regPrcChgDesc)
			throws PriceBusinessException;

	public void processDel(RegPrcChgRef regPrcChgRef)
			throws PriceBusinessException;
}
