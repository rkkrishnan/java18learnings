package com.tesco.services.core;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import static com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility.ANY;
import static com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility.NONE;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonAutoDetect(fieldVisibility = ANY, getterVisibility = NONE,
		setterVisibility = NONE)
public class SubGroupContentEntity implements Serializable {

	@JsonProperty
	private Map<String, String> subgroup = new HashMap<>();

	@JsonProperty
	private String lastUpdatedById;

	@JsonProperty
	private String lastUpdateDate;

	@JsonIgnore
	private Set<String> rejectedProducts;

	@Override
	public String toString() {
		return "SubGroupContentEntity{" +
				"subgroup='" + subgroup + '\'' +
				", lastUpdatedById='" + lastUpdatedById + '\'' +
				", lastUpdateDate='" + lastUpdateDate + '\'' +
				'}';
	}

	public Map<String, String> getSubgroup() {
		return subgroup;
	}

	public void setSubgroup(Map<String, String> subgroup) {
		this.subgroup = subgroup;
	}

	public void setLastUpdatedById(String lastUpdatedById) {
		this.lastUpdatedById = lastUpdatedById;
	}

	public void setLastUpdateDate(String lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	public Set<String> getRejectedProducts() {
		return rejectedProducts;
	}

	public void setRejectedProducts(Set<String> rejectedProducts) {
		this.rejectedProducts = rejectedProducts;
	}
}
