package com.tesco.services.adapters.price.impl;

import com.tesco.price.core.RegPrcChgDesc;
import com.tesco.price.core.RegPrcChgDtl;
import com.tesco.price.core.RegPrcChgDtlRef;
import com.tesco.price.core.RegPrcChgRef;
import com.tesco.services.adapters.price.PriceHandler;
import com.tesco.services.adapters.rpm.writers.PriceMessageWriter;
import com.tesco.services.core.price.PriceByDateTime;
import com.tesco.services.core.price.PriceEntity;
import com.tesco.services.core.price.ProductVariant;
import com.tesco.services.exceptions.PriceBusinessException;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.PriceConstants;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;

import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by iv16 on 9/1/2015.
 */

public class PriceHandlerImpl implements PriceHandler {
	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(PriceHandlerImpl.class);

	private PriceMessageWriter priceWriter;

	@Inject
	public PriceHandlerImpl(@Named("priceWriter") PriceMessageWriter priceWriter) {
		this.priceWriter = priceWriter;
	}

	@Override
	public void processCre(RegPrcChgDesc regPrcChgDesc)
			throws PriceBusinessException {

		String locType = regPrcChgDesc.getLocType();
		String loc = String.valueOf(regPrcChgDesc.getLocation());
		List<String> docKeys = new ArrayList<>();
		List<RegPrcChgDtl> listOfPriceDetails = regPrcChgDesc.getRegPrcChgDtl();
		try {
			for (RegPrcChgDtl priceDetail : listOfPriceDetails) {
				String item = priceDetail.getItem();
				docKeys.add(PriceConstants.PRICE_DOC_KEY_PREFIX
						.concat(item.split("-")[0]).concat("_").concat(locType)
						.concat(loc));
			}

			/**
			 * Contains all the docs required for this particular message and
			 * also used to insert the updated objects.Basically this map is
			 * reused
			 */

			Map<String, PriceEntity> mapOfPriceEntities = priceWriter
					.getBulkDeserialized(docKeys, PriceEntity.class);

			for (RegPrcChgDtl priceDetail : listOfPriceDetails) {
				String tpnc = priceDetail.getTslConsumerUnit();
				String key = PriceConstants.PRICE_DOC_KEY_PREFIX
						.concat(priceDetail.getItem().split("-")[0])
						.concat("_").concat(locType).concat(loc);
				PriceEntity priceEntity = null;
				if (mapOfPriceEntities == null) {
					mapOfPriceEntities = new HashMap<>();
				} else {
					priceEntity = mapOfPriceEntities.get(key);

				}

				if (priceEntity == null) {
					priceEntity = new PriceEntity();
					priceEntity.setProdType(PriceConstants.TPNB_IDENTIFIER);
					priceEntity.setProdRef(priceDetail.getItem().split("-")[0]);
					priceEntity.setLocRef(loc);
					priceEntity.setLocType(locType);
					priceEntity.setLastUpdateDate(Dockyard
							.getSysDate(PriceConstants.ISO_8601_FORMAT));
				}
				ProductVariant productVariant = priceEntity
						.getTpncToProductVariant().get(tpnc);

				/**
				 * If the variant is not found create a new one and set
				 * appropriate values
				 */
				if (productVariant == null) {
					productVariant = new ProductVariant();
					productVariant.setTpnc(tpnc);
					productVariant.setSellingCurrency(priceDetail
							.getSellingCurrency());
					productVariant.setSellingUOM(priceDetail.getSellingUom());
				}
				/** Build the object based on the date */
				PriceByDateTime priceByDateTime = new PriceByDateTime();
				priceByDateTime.setPriceRef(String.valueOf(priceDetail
						.getPriceChangeId()));
				String effectiveDate = getDate(priceDetail.getEffectiveDate()
						.getYear().toString(), priceDetail.getEffectiveDate()
						.getMonth().toString(), priceDetail.getEffectiveDate()
						.getDay().toString(), priceDetail.getEffectiveDate()
						.getHour().toString(), priceDetail.getEffectiveDate()
						.getMinute().toString(), priceDetail.getEffectiveDate()
						.getSecond().toString());
				priceByDateTime.setEffvDateTime(effectiveDate);
				priceByDateTime
						.setChangeType(PriceConstants.PROMO_CHG_TYPES.FXD
								.value());
				priceByDateTime.setChangeAmount(priceDetail
						.getSellingUnitRetail().doubleValue());
				priceByDateTime.setRegPrice(priceDetail.getSellingUnitRetail()
						.doubleValue());

				priceByDateTime.setState(PriceConstants.PRICE_CHANGE_STATE);

				priceByDateTime
						.setCreatedById(PriceConstants.PROMO_CREATED_ID_RPM);
				priceByDateTime.setCreatedDate(Dockyard
						.getSysDate(PriceConstants.ISO_8601_FORMAT));
				priceByDateTime.setLastUpdateDate(Dockyard
						.getSysDate(PriceConstants.ISO_8601_FORMAT));

				productVariant.getEffectiveDate().put(
						getkeyInDateFormat(effectiveDate), priceByDateTime);

				/** Setting variant back to the map */

				priceEntity.getTpncToProductVariant().put(tpnc, productVariant);

				/**
				 * Setting the built PriceEntity to the map so that it can be
				 * Written to CB later or also fetch the updated doc for a
				 * variant
				 */
				mapOfPriceEntities.put(key, priceEntity);

			}
			/** Write the updated documents back to CB */
			priceWriter.writePrice(mapOfPriceEntities);

		} catch (Exception e) {
			throw new PriceBusinessException(e.getMessage(), e);

		}
	}

	@Override
	public void processDel(RegPrcChgRef regPrcChgRef)
			throws PriceBusinessException {
		Set<String> rejectedProducts = new HashSet<>();

		List<RegPrcChgDtlRef> listOfPriceDetails = regPrcChgRef
				.getRegPrcChgDtlRef();
		String locType = regPrcChgRef.getLocType().toString();
		String loc = String.valueOf(regPrcChgRef.getLocation());
		List<String> docKeys = new ArrayList<>();
		try {

			for (RegPrcChgDtlRef priceDetail : listOfPriceDetails) {
				String item = priceDetail.getItem().split("-")[0];
				docKeys.add(PriceConstants.PRICE_DOC_KEY_PREFIX.concat(item)
						.concat("_").concat(locType).concat(loc));
			}

			/**
			 * Contains all the docs required for this particular message and
			 * also used to insert the updated objects.Basically this map is
			 * reused
			 */
			Map<String, PriceEntity> mapOfPriceEntities = priceWriter
					.getBulkDeserialized(docKeys, PriceEntity.class);

			/** Loop through all the details to be deleted. */
			for (RegPrcChgDtlRef regPrcChgDtlRef : regPrcChgRef
					.getRegPrcChgDtlRef()) {
				String priceChangeId = String.valueOf(regPrcChgDtlRef
						.getPriceChangeId());
				String item = regPrcChgDtlRef.getItem().split("-")[0];
				String tpnc = regPrcChgDtlRef.getTslConsumerUnit();
				List<String> effDateTobeRemoved = new ArrayList<>();

				PriceEntity priceEntity = mapOfPriceEntities
						.get(PriceConstants.PRICE_DOC_KEY_PREFIX.concat(item)
								.concat("_").concat(locType).concat(loc));
				if (priceEntity == null) {
					LOGGER.error(
							"No REGPRICE document found item {}, hence price change id {} cannot be deleted  ",
							item, priceChangeId);
					rejectedProducts.add(Dockyard
							.getSysDate(PriceConstants.ISO_8601_FORMAT)
							.concat("~<REGULAR PRICE DEL>~")
							.concat("No REGPRICE document found for item "
									+ item
									+ " when deleting price change id "
											.concat(priceChangeId)));
					continue;

				}
				ProductVariant tpncToProductVariant = priceEntity
						.getTpncToProductVariant().get(tpnc);

				/**
				 * Check if the tpnc from the delete message is present in the
				 * Doc If not then reject into file and continue with further
				 * delete details
				 */
				if (tpncToProductVariant == null) {
					LOGGER.info(
							"TPNC: {} is not found for item: {} during delete process",
							tpnc, item);
					rejectedProducts.add(Dockyard
							.getSysDate(PriceConstants.ISO_8601_FORMAT)
							.concat("~<REGULAR PRICE DEL>~")
							.concat("TPNC: ")
							.concat(tpnc)
							.concat(" is not found for item: ".concat(item)
									.concat(" during delete process")));
					continue;
				}
				boolean detailToDelFound = false;
				for (Map.Entry<String, PriceByDateTime> entry : tpncToProductVariant
						.getEffectiveDate().entrySet()) {
					if (entry.getValue().getPriceRef().equals(priceChangeId)) {
						priceEntity.setLastUpdateDate(Dockyard
								.getSysDate(PriceConstants.ISO_8601_FORMAT));
						effDateTobeRemoved.add(entry.getKey());
						detailToDelFound = true;
						break;

					}

				}
				if (!detailToDelFound) {
					LOGGER.info(
							"price change id {} is not found for item {} during delete process",
							priceChangeId, item);
					rejectedProducts.add(Dockyard
							.getSysDate(PriceConstants.ISO_8601_FORMAT)
							.concat("~<REGULAR PRICE DEL>~")
							.concat("Price change id: ".concat(priceChangeId)
									.concat(" is not found for item:".concat(
											item).concat(
											" during delete process"))));
				}
				/** Remove the identified price changes */
				for (String id : effDateTobeRemoved) {
					tpncToProductVariant.getEffectiveDate().remove(id);
				}

				mapOfPriceEntities.put(PriceConstants.PRICE_DOC_KEY_PREFIX
						.concat(item).concat("_").concat(locType).concat(loc),
						priceEntity);

			}

			for (String regPriceRef : mapOfPriceEntities.keySet()) {
				PriceEntity pE = mapOfPriceEntities.get(regPriceRef);
				List<String> listOfProductVarToBeDeleted = new ArrayList<>();

				for (String variantKey : pE.getTpncToProductVariant().keySet()) {
					if (pE.getTpncToProductVariant().get(variantKey)
							.getEffectiveDate().isEmpty()) {
						listOfProductVarToBeDeleted.add(variantKey);
					}

				}
				/** Remove the product variant if empty */
				for (String key : listOfProductVarToBeDeleted) {
					pE.getTpncToProductVariant().remove(key);

				}

				if (pE.getTpncToProductVariant().isEmpty()) {
					this.priceWriter.deletePriceEntity(pE);
				} else {
					this.priceWriter.writeUpdatePriceEntityDoc(pE);
				}

			}
			/** Write the rejected data if present */
			if (!rejectedProducts.isEmpty()) {
				priceWriter.writeRejects(rejectedProducts);
				rejectedProducts.clear();

			}
		} catch (Exception e) {
			throw new PriceBusinessException(e.getMessage(), e);
		}

	}

	public String getDate(String year, String month, String day, String hrs,
			String mins, String secs) {
		String parsedDay = day.length() == 1 ? "0" + day : day;
		String parsedMonth = month.length() == 1 ? "0" + month : month;
		String parsedHrs = hrs.length() == 1 ? "0" + hrs : hrs;
		String parsedMins = mins.length() == 1 ? "0" + mins : mins;
		String parsedSecs = secs.length() == 1 ? "0" + secs : secs;

		String date = year + parsedMonth + parsedDay + parsedHrs + parsedMins
				+ parsedSecs;
		try {
			date = Dockyard.getFormattedDate(date,
					PriceConstants.PROMO_MSG_DATE_FORMAT,
					PriceConstants.ISO_8601_FORMAT);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date;
	}

	public static String getkeyInDateFormat(String date) throws ParseException {

		SimpleDateFormat dateFormatFromFiles = new SimpleDateFormat(
				"yyyy-MM-dd'T'HH:mm:ss");
		SimpleDateFormat isodateformat = new SimpleDateFormat("yyyyMMddHHmmss");
		Date date1 = dateFormatFromFiles.parse(date);

		return isodateformat.format(date1);
	}
}
