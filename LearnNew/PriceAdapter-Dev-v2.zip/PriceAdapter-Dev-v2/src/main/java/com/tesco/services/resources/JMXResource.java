package com.tesco.services.resources;

import static com.tesco.services.resources.ResourceResponse.RESPONSE_TYPE;
import io.swagger.annotations.Api;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import org.slf4j.Logger;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.tesco.services.adapters.core.utils.JMXClient;
import com.tesco.services.adapters.core.utils.TimerMetrics;
import com.tesco.services.exceptions.ClearanceJMXException;
import com.tesco.services.exceptions.EventJMXException;
import com.tesco.services.exceptions.PriceJMXException;
import com.tesco.services.exceptions.PromoJMXException;
import com.tesco.services.exceptions.ZoneJMXException;
import com.tesco.services.utility.PromotionJmsLog;
import com.tesco.services.utility.PromotionJmsLogImpl;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;

/**
 * @author a185
 */
@Path("/admin/jmx")
@Api(value = "JMX MBean Viewer")
@Produces(RESPONSE_TYPE)
public class JMXResource {
	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(JMXResource.class);
	private static PromotionJmsLog PROMOMSGCOUNTER = PromotionJmsLogImpl
			.getInstance();

	JMXClient jmxClient;
	ObjectMapper objectMapper;

	@Inject
	public JMXResource(@Named("jmxClient") JMXClient injectedJMXClient,
			@Named("jsonmapper") ObjectMapper injectedObjectMapper) {
		jmxClient = injectedJMXClient;
		objectMapper = injectedObjectMapper;
		objectMapper.configure(SerializationFeature.INDENT_OUTPUT, true);
	}

	/**
	 * @param command
	 *            *
	 * @param uriInfo
	 * @return
	 */
	@GET
	@Path("/promo/{command}")
	public Response get(@PathParam("command") String command,
			@Context UriInfo uriInfo) {
		String commandStatus = "Invalid Command";
		Map<String, TimerMetrics> metricsData = null;
		final ByteArrayOutputStream promoMetricsPrettyPrint = new ByteArrayOutputStream();

		if ("refresh".equals(command)) {
			try {
				metricsData = jmxClient.getPromotionLoadMetrics();
				objectMapper.writeValue(promoMetricsPrettyPrint, metricsData);
			} catch (PromoJMXException | IOException e) {
				commandStatus = "Error: Unable to process command : " + e;
				LOGGER.error(
						"Unable to retrieve promotions metrics from JMX server {}",
						e);
			}

		} else if ("reset".equals(command)) {
			try {
				jmxClient.resetPromotionMetrics();
				metricsData = jmxClient.getPromotionLoadMetrics();
				objectMapper.writeValue(promoMetricsPrettyPrint, metricsData);
			} catch (PromoJMXException | IOException e) {
				commandStatus = "Error: Unable to process command : " + e;
				LOGGER.error(
						"Unable to retrieve promotions metrics from JMX server {}",
						e);
			}

		} else {
			commandStatus = "Invalid Command";
		}

		if (metricsData != null && !metricsData.isEmpty()) {
			return Response.ok().entity(promoMetricsPrettyPrint.toByteArray())
					.build();
		}

		return Response.ok(commandStatus).build();
	}

	/**
	 * @param command
	 * @param uriInfo
	 * @return
	 */
	@GET
	@Path("/price/{command}")
	public Response getPriceStat(@PathParam("command") String command,
			@Context UriInfo uriInfo) {
		String commandStatus = "Invalid Command";
		Map<String, TimerMetrics> metricsData = null;
		final ByteArrayOutputStream priceMetricsPrettyPrint = new ByteArrayOutputStream();

		if ("refresh".equals(command)) {
			try {
				metricsData = jmxClient.getPriceLoadMetrics();
				objectMapper.writeValue(priceMetricsPrettyPrint, metricsData);
			} catch (PriceJMXException | IOException e) {
				commandStatus = "Error: Unable to process command : " + e;
				LOGGER.error(
						"Unable to retrieve price metrics from JMX server {}",
						e);
			}

		} else if ("reset".equals(command)) {
			try {
				jmxClient.resetPriceMetrics();
				metricsData = jmxClient.getPriceLoadMetrics();
				objectMapper.writeValue(priceMetricsPrettyPrint, metricsData);
			} catch (PriceJMXException | IOException e) {
				commandStatus = "Error: Unable to process command : " + e;
				LOGGER.error(
						"Unable to retrieve price metrics from JMX server {}",
						e);
			}

		} else {
			commandStatus = "Invalid Command";
		}

		if (metricsData != null && !metricsData.isEmpty()) {
			return Response.ok().entity(priceMetricsPrettyPrint.toByteArray())
					.build();
		}

		return Response.ok(commandStatus).build();
	}

	/**
	 * @param command
	 *            *
	 * @param uriInfo
	 * @return
	 */
	@GET
	@Path("/zone/{command}")
	public Response getZoneStat(@PathParam("command") String command,
			@Context UriInfo uriInfo) {
		String commandStatus = "Invalid Command";
		Map<String, TimerMetrics> metricsData = null;
		final ByteArrayOutputStream zoneMetricsPrettyPrint = new ByteArrayOutputStream();

		if ("refresh".equals(command)) {
			try {
				metricsData = jmxClient.getZoneLoadMetrics();
				objectMapper.writeValue(zoneMetricsPrettyPrint, metricsData);
			} catch (ZoneJMXException | IOException e) {
				commandStatus = "Error: Unable to process command : " + e;
				LOGGER.error(
						"Unable to retrieve zone metrics from JMX server {}", e);
			}

		} else if ("reset".equals(command)) {
			try {
				jmxClient.resetZoneMetrics();
				metricsData = jmxClient.getZoneLoadMetrics();
				objectMapper.writeValue(zoneMetricsPrettyPrint, metricsData);
			} catch (ZoneJMXException | IOException e) {
				commandStatus = "Error: Unable to process command : " + e;
				LOGGER.error(
						"Unable to retrieve zone metrics from JMX server {}", e);
			}

		} else {
			commandStatus = "Invalid Command";
		}

		if (metricsData != null && !metricsData.isEmpty()) {
			return Response.ok().entity(zoneMetricsPrettyPrint.toByteArray())
					.build();
		}

		return Response.ok(commandStatus).build();
	}

	/**
	 * @param command
	 *            *
	 * @param uriInfo
	 * @return
	 */
	@GET
	@Path("/promodoc/count/{command}")
	public Response getPromotionDocumentCount(
			@PathParam("command") String command, @Context UriInfo uriInfo) {
		String commandStatus = "Invalid Command";
		boolean isError = false;
		final ByteArrayOutputStream promoDocPrettyPrint = new ByteArrayOutputStream();

		if ("refresh".equals(command)) {
			try {
				objectMapper.writeValue(promoDocPrettyPrint,
						PROMOMSGCOUNTER.printMetricsSnasphot());
			} catch (IOException e) {
				commandStatus = "Error: Unable to process command : " + e;
				isError = true;
				LOGGER.error(commandStatus);
			}
		} else if ("reset".equals(command)) {
			try {
				PROMOMSGCOUNTER.resetMetricsSnapshot();
				objectMapper.writeValue(promoDocPrettyPrint,
						PROMOMSGCOUNTER.printMetricsSnasphot());
			} catch (IOException e) {
				commandStatus = "Error: Unable to process command : " + e;
				isError = true;
				LOGGER.error(commandStatus);
			}

		} else {
			commandStatus = "Invalid Command";
		}
		if (isError) {
			return Response.ok(commandStatus).build();
		}
		return Response.ok().entity(promoDocPrettyPrint.toByteArray()).build();
	}

	/**
	 * @param command
	 *            *
	 * @param uriInfo
	 * @return
	 */
	@GET
	@Path("/clearance/mm/{command}")
	public Response getMMClearanceStat(@PathParam("command") String command,
			@Context UriInfo uriInfo) {
		String commandStatus = "Invalid Command";
		Map<String, TimerMetrics> metricsData = null;
		final ByteArrayOutputStream mmClearanceMetricsPrettyPrint = new ByteArrayOutputStream();

		if ("refresh".equals(command)) {
			try {
				metricsData = jmxClient.getMMClearanceLoadMetrics();
				objectMapper.writeValue(mmClearanceMetricsPrettyPrint,
						metricsData);
			} catch (ClearanceJMXException | IOException e) {
				commandStatus = "Error: Unable to process command : " + e;
				LOGGER.error(
						"Unable to retrieve MM Clearance metrics from JMX server {}",
						e);
			}

		} else if ("reset".equals(command)) {
			try {
				jmxClient.resetMMClearanceMetrics();
				metricsData = jmxClient.getMMClearanceLoadMetrics();
				objectMapper.writeValue(mmClearanceMetricsPrettyPrint,
						metricsData);
			} catch (ClearanceJMXException | IOException e) {
				commandStatus = "Error: Unable to process command : " + e;
				LOGGER.error(
						"Unable to retrieve MM Clearance metrics from JMX server {}",
						e);
			}

		} else {
			commandStatus = "Invalid Command";
		}

		if (metricsData != null && !metricsData.isEmpty()) {
			return Response.ok()
					.entity(mmClearanceMetricsPrettyPrint.toByteArray())
					.build();
		}

		return Response.ok(commandStatus).build();
	}

	/**
	 * @param command
	 *            *
	 * @param uriInfo
	 * @return
	 */
	@GET
	@Path("/clearance/rpm/{command}")
	public Response getRPMClearanceStat(@PathParam("command") String command,
			@Context UriInfo uriInfo) {
		String commandStatus = "Invalid Command";
		Map<String, TimerMetrics> metricsData = null;
		final ByteArrayOutputStream rpmClearanceMetricsPrettyPrint = new ByteArrayOutputStream();

		if ("refresh".equals(command)) {
			try {
				metricsData = jmxClient.getRPMClearanceLoadMetrics();
				objectMapper.writeValue(rpmClearanceMetricsPrettyPrint,
						metricsData);
			} catch (ClearanceJMXException | IOException e) {
				commandStatus = "Error: Unable to process command : " + e;
				LOGGER.error(
						"Unable to retrieve RPM Clearance metrics from JMX server {}",
						e);
			}

		} else if ("reset".equals(command)) {
			try {
				jmxClient.resetRPMClearanceMetrics();
				metricsData = jmxClient.getRPMClearanceLoadMetrics();
				objectMapper.writeValue(rpmClearanceMetricsPrettyPrint,
						metricsData);
			} catch (ClearanceJMXException | IOException e) {
				commandStatus = "Error: Unable to process command : " + e;
				LOGGER.error(
						"Unable to retrieve RPM Clearance metrics from JMX server {}",
						e);
			}

		} else {
			commandStatus = "Invalid Command";
		}

		if (metricsData != null && !metricsData.isEmpty()) {
			return Response.ok()
					.entity(rpmClearanceMetricsPrettyPrint.toByteArray())
					.build();
		}

		return Response.ok(commandStatus).build();
	}

	/**
	 * @param command
	 *            *
	 * @param uriInfo
	 * @return
	 */
	@GET
	@Path("/event/{command}")
	public Response getEventStat(@PathParam("command") String command,
			@Context UriInfo uriInfo) {
		String commandStatus = "Invalid Command";
		Map<String, TimerMetrics> metricsData = null;
		final ByteArrayOutputStream eventMetricsPrettyPrint = new ByteArrayOutputStream();

		if ("refresh".equals(command)) {
			try {
				metricsData = jmxClient.getEventLoadMetrics();
				objectMapper.writeValue(eventMetricsPrettyPrint, metricsData);
			} catch (EventJMXException | IOException e) {
				commandStatus = "Error: Unable to process command : " + e;
				LOGGER.error(
						"Unable to retrieve event metrics from JMX server {}",
						e);
			}

		} else if ("reset".equals(command)) {
			try {
				jmxClient.resetEventMetrics();
				metricsData = jmxClient.getEventLoadMetrics();
				objectMapper.writeValue(eventMetricsPrettyPrint, metricsData);
			} catch (EventJMXException | IOException e) {
				commandStatus = "Error: Unable to process command : " + e;
				LOGGER.error(
						"Unable to retrieve event metrics from JMX server {}",
						e);
			}

		} else {
			commandStatus = "Invalid Command";
		}

		if (metricsData != null && !metricsData.isEmpty()) {
			return Response.ok().entity(eventMetricsPrettyPrint.toByteArray())
					.build();
		}

		return Response.ok(commandStatus).build();
	}

}
