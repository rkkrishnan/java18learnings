package com.tesco.services.adapters.rpm.writers.impl;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.MappingJsonFactory;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.exceptions.WriterBusinessException;
import com.tesco.services.adapters.rpm.writers.PriceMessageWriter;
import com.tesco.services.core.price.PriceEntity;
import com.tesco.services.exceptions.PriceBusinessException;
import com.tesco.services.repositories.Repository;
import com.tesco.services.resources.PromotionResource;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.PriceConstants;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import java.io.File;
import java.io.IOException;
import java.util.*;

import static org.apache.commons.lang.StringUtils.isBlank;

/**
 * Created by iv16 on 8/9/2015.
 */
public class PriceWriter implements PriceMessageWriter {

	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(PriceWriter.class);
	private Configuration configuration;
	private ObjectMapper objectMapper;
	private String runIdentifier;
	private Repository repository;
	private File onetimePromoFile;
	private Set<String> rejectedProducts;
	private Dockyard dockyard;

	public File getOnetimePromoFile(String fileName) {
		if (onetimePromoFile == null) {
			onetimePromoFile = new File(configuration.getPriceFilePath() + "/"
					+ runIdentifier + "/" + fileName);
		}
		return onetimePromoFile;
	}

	public void setOnetimePromoFile(File onetimePromoFile) {
		this.onetimePromoFile = onetimePromoFile;
	}

	public Dockyard getDockyard() {

		if (dockyard == null) {
			dockyard = new Dockyard();
		}
		return dockyard;
	}

	@Inject
	public PriceWriter(@Named("configuration") Configuration configuration,
			@Named("jsonmapper") ObjectMapper objectMapper,
			@Named("repository") Repository repository) {
		this.configuration = configuration;
		this.objectMapper = objectMapper;
		this.repository = repository;
	}

	public String getRunIdentifier() {
		return runIdentifier;
	}

	public void setRunIdentifier(String runIdentifier) {
		this.runIdentifier = runIdentifier;
	}

	public void write(String fileName) throws WriterBusinessException {
		JsonParser jsonParser = null;
		rejectedProducts = new HashSet<>();
		String date = Dockyard.getSysDate("yyyyMMdd");
		String rejectfilepath = configuration.getRejectFilePath();
		int counter = 0;
		int recordsInserted = 0;
		int recordsRejected = 0;

		onetimePromoFile = getOnetimePromoFile(fileName);
		JsonFactory jsonFactory = new MappingJsonFactory();
		try {
			jsonParser = jsonFactory.createJsonParser(onetimePromoFile);

			JsonToken token = jsonParser.nextToken();
			if (token != JsonToken.START_ARRAY) {
				LOGGER.error("Root should be an array token ']': quiting.");
				PromotionResource.setErrorString(runIdentifier,
						"File doesnot start with array token ']' ");
				return;
			}
			while (jsonParser.nextToken() != JsonToken.END_ARRAY) {
				JsonNode rootNode = jsonParser.readValueAsTree();
				counter += 1;
				String promotionEntityString = rootNode.toString();
				PriceEntity priceEntity = objectMapper.readValue(
						promotionEntityString, PriceEntity.class);
				String tpnb = priceEntity.getProdRef();
				String locType = priceEntity.getLocType();
				String zoneId = priceEntity.getLocRef();
				if (priceEntity.getProdRef() == null
						|| isBlank(priceEntity.getProdRef())) {
					recordsRejected++;
					rejectedProducts.add("Price Object " + counter
							+ " is without productref");

				} else if (!validateObject(priceEntity)) {
					recordsRejected++;
					rejectedProducts.add("Price Object with productref: "
							+ priceEntity.getProdRef() + "is incomplete");

				} else {

					try {
						repository.insertObject(
								PriceConstants.PRICE_DOC_KEY_PREFIX + tpnb
										+ "_" + locType + zoneId, priceEntity);
						recordsInserted++;
					} catch (Exception e) {
						recordsRejected++;
						rejectedProducts
								.add("Price Object with productref: "
										+ priceEntity.getProdRef()
										+ "is got rejected.");
						LOGGER.error(
								"Error occurred when inserting document into couchbase for tpnb: "
										+ tpnb, e);
					}

				}

			}
			/** Close the json parser after processing */
			jsonParser.close();
		} catch (IOException e) {
			LOGGER.error("Error occured in importing onetimeprice fille", e);
			throw new WriterBusinessException(e.getMessage(), e.getCause());
		}

		// Added for PRIS-2203
		LOGGER.info("FileName: " + fileName + " Price documents inserted : "
				+ recordsInserted);
		LOGGER.info("FileName: " + fileName + " Price documents rejected : "
				+ recordsRejected);
		LOGGER.info("FileName: " + fileName + " Total price documents read : "
				+ counter);

		if (!rejectedProducts.isEmpty()) {
			getDockyard().writeProductDetailsToFile(
					rejectfilepath + "/REJECT_FILE_" + runIdentifier + "_"
							+ date + ".log", rejectedProducts);
			rejectedProducts.clear();
		}
	}

	public void writePrice(Map<String, PriceEntity> mapOfPriceEntities) {
		rejectedProducts = new HashSet<>();
		String date = Dockyard.getSysDate("yyyyMMdd");
		String rejectfilepath = configuration.getRejectFilePath();
		int recordsInserted = 0;
		int recordsRejected = 0;
		int counter = 0;
		for (Map.Entry<String, PriceEntity> entry : mapOfPriceEntities
				.entrySet()) {
			counter++;
			try {
				PriceEntity priceEntity = entry.getValue();
				priceEntity.setLastUpdateDate(Dockyard
						.getSysDate(PriceConstants.ISO_8601_FORMAT));
				repository
						.insertObject(entry.getKey(), entry.getValue());
				recordsInserted++;
			} catch (Exception e) {
				recordsRejected++;
				rejectedProducts.add("Price Object with productref: "
						+ entry.getValue().getProdRef() + "is got rejected.");
				LOGGER.error(
						"Error occurred when inserting document into couchbase for tpnb: "
								+ entry.getKey(), e);
			}
		}

		// Added for PRIS-2203
		LOGGER.info("Price documents inserted : " + recordsInserted);
		LOGGER.info("Price documents rejected : " + recordsRejected);
		LOGGER.info("Total price documents : " + counter);

		if (!rejectedProducts.isEmpty()) {
			getDockyard().writeProductDetailsToFile(
					rejectfilepath + "/REJECT_FILE_" + runIdentifier + "_"
							+ date + ".log", rejectedProducts);
			rejectedProducts.clear();
		}

	}

	public boolean validateObject(PriceEntity priceEntity) {
		boolean valid = true;
		if (priceEntity.getLocRef() == null
				|| priceEntity.getProdType() == null
				|| priceEntity.getLocType() == null
				|| priceEntity.getTpncToProductVariant() == null) {
			valid = false;

		}
		if (isBlank(priceEntity.getLocRef())
				|| isBlank(priceEntity.getProdType())
				|| isBlank(priceEntity.getLocType())) {
			valid = false;

		}

		return valid;
	}

	public void deletePriceEntity(PriceEntity priceEntityMessage)
			throws PriceBusinessException {

		try {
			String item = priceEntityMessage.getProdRef();
			String locType = priceEntityMessage.getLocType();
			String locRef = priceEntityMessage.getLocRef();
			repository.deleteProduct(PriceConstants.PRICE_DOC_KEY_PREFIX
					.concat(item).concat("_").concat(locType).concat(locRef));
		} catch (Exception e) {
			throw new PriceBusinessException(e.getMessage(), e);
		}
	}

	public void writeUpdatePriceEntityDoc(PriceEntity priceEntityMsg) {
		rejectedProducts = new HashSet<>();
		String date = Dockyard.getSysDate("yyyyMMdd");
		String rejectfilepath = configuration.getRejectFilePath();
		String item = priceEntityMsg.getProdRef();
		String locType = priceEntityMsg.getLocType();
		String locRef = priceEntityMsg.getLocRef();
		try {
			repository.insertObject(PriceConstants.PRICE_DOC_KEY_PREFIX
							.concat(item).concat("_").concat(locType)
							.concat(locRef),
					priceEntityMsg);
		} catch (Exception e) {
			rejectedProducts.add("Price Object with productref: " + item
					+ "is got rejected.");
			LOGGER.error(
					"Error occurred when updating document into couchbase for tpnb: "
							+ item, e);
		}

		if (!rejectedProducts.isEmpty()) {
			getDockyard().writeProductDetailsToFile(
					rejectfilepath + "/REJECT_FILE_" + runIdentifier + "_"
							+ date + ".log", rejectedProducts);
			rejectedProducts.clear();
		}
	}

	public <M> Map getBulkDeserialized(List<String> keys, Class<M> clazz)
			throws WriterBusinessException {
		Map<String, Object> mapOfPriceEntitiesFromCB = repository
				.getBulk(keys);
		Map<String, M> mapOfPriceEntities = new HashMap<>();
		for (Map.Entry entry : mapOfPriceEntitiesFromCB.entrySet()) {
			try {
				mapOfPriceEntities.put(entry.getKey().toString(), objectMapper
						.readValue(entry.getValue().toString(), clazz));
			} catch (IOException e) {
				LOGGER.error("Error occurred in getBulkDeserialized.", e);
				throw new WriterBusinessException(e.getMessage(), e.getCause());
			}
		}
		return mapOfPriceEntities;

	}

	public void writeRejects(Set rejectedProducts) {
		String date = Dockyard.getSysDate("yyyyMMdd");
		String rejectfilepath = configuration.getRejectFilePath();
		new Dockyard().writeProductDetailsToFile(rejectfilepath
				+ "/REJECT_FILE_PRICE_" + date + ".log", rejectedProducts);

	}
}
