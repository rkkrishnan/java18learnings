package com.tesco.services.adapters.rpm.writers.impl;

import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.exceptions.ColumnNotFoundException;
import com.tesco.services.adapters.core.exceptions.WriterBusinessException;
import com.tesco.services.adapters.rpm.readers.PriceServiceCSVReader;
import com.tesco.services.adapters.rpm.readers.impl.PriceServiceCSVReaderImpl;
import com.tesco.services.adapters.rpm.writers.CSVHeaders;
import com.tesco.services.adapters.rpm.writers.Writer;
import com.tesco.services.core.zone.ZoneGrpEntity;
import com.tesco.services.repositories.Repository;
import com.tesco.services.repositories.RepositoryImpl;
import com.tesco.services.resources.ImportResource;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.PriceConstants;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by qp65 on 11/5/2015.
 */
public class RPMZoneGroupWriter implements Writer {

	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger("RPM Zone Group Import");

	private Configuration configuration;
	private String runIdentifier;
	private Repository repository;

	private ZoneGrpEntity zoneGrpEntity = new ZoneGrpEntity();

	private PriceServiceCSVReader rpmZoneReader;

	@Inject
	public RPMZoneGroupWriter(
			@Named("configuration") Configuration configuration,
			@Named("repository") Repository repository) {
		this.configuration = configuration;
		this.repository = repository;
	}

	public RPMZoneGroupWriter(Configuration configuration,
			RepositoryImpl repository,
			PriceServiceCSVReader rpmZoneReader) {
		this(configuration, repository);
		this.rpmZoneReader = rpmZoneReader;
	}

	public String getRunIdentifier() {
		return runIdentifier;
	}

	public void setRunIdentifier(String runIdentifier) {
		this.runIdentifier = runIdentifier;
	}

	public PriceServiceCSVReader createRPMZoneGroupReader(String fileName)
			throws WriterBusinessException {

		PriceServiceCSVReader csvreader;
		try {
			csvreader = new PriceServiceCSVReaderImpl(
					configuration.getRpmZoneDataDump() + "/" + runIdentifier
							+ "/" + fileName,
					CSVHeaders.RPMZoneGroupHeaders.HEADERS);
		} catch (IOException | ColumnNotFoundException e) {
			LOGGER.error(
					"Error occured while initializing PriceServiceCSVReader for RPMZoneGroupWriter",
					e);
			throw new WriterBusinessException(e.getMessage(), e.getCause());
		}
		return csvreader;
	}

	public void write(String fileName) throws WriterBusinessException {
		LOGGER.info("Importing price zone prices into Couchbase");
		if (rpmZoneReader == null) {
			rpmZoneReader = createRPMZoneGroupReader(fileName);
		}

		try {
			writeRPMZoneGroupToCB();

		} catch (ArrayIndexOutOfBoundsException exception) {
			ImportResource.setErrorString(fileName,
					"Array index out of bound Exception");
			LOGGER.error("Error importing data", exception.getMessage());
		} catch (Exception e) {
			ImportResource.setErrorString(fileName, e.toString());
			LOGGER.error("Error importing data", e);
			throw new WriterBusinessException(e.getMessage(), e.getCause());
		} finally {
			ImportResource.getImportSemaphoreForIdentifier(fileName).release();
		}
	}

	private void writeRPMZoneGroupToCB() throws IOException {

		Map<String, String> rpmZoneGroupInfoMap;
		int recordsInsertedCount = 0;
		int recordsRejectedCount = 0;
		int recordsTotalRead = 0;

		while ((rpmZoneGroupInfoMap = rpmZoneReader.getNext()) != null) {
			recordsTotalRead++;
			String key = setZoneGroupEntity(rpmZoneGroupInfoMap);
			try {
				repository.insertObject(key, zoneGrpEntity);
				// Changed for PRIS-2203
				recordsInsertedCount++;
			} catch (Exception e) {
				recordsRejectedCount++;
				LOGGER.error(
						"Error occurred when inserting document into couchbase for zone: "
								+ key, e);
			}
			zoneGrpEntity = new ZoneGrpEntity();
		}

		// Added for PRIS-2203
		LOGGER.info("ZoneGroup documents processed : " + recordsInsertedCount);
		LOGGER.info("ZoneGroup documents rejected : " + recordsRejectedCount);
		LOGGER.info("Total ZoneGroup documents read : " + recordsTotalRead);
	}

	public String setZoneGroupEntity(Map<String, String> rpmZoneGroupInfoMap) {

		List<String> zoneIds = new ArrayList<String>();
		String date = Dockyard.getSysDate(PriceConstants.ISO_8601_FORMAT);
		String zoneGroupId = PriceConstants.ZONE_GRP_KEY
				+ rpmZoneGroupInfoMap
						.get(CSVHeaders.RPMZoneGroupHeaders.ZONE_GROUP_ID);

		zoneGrpEntity.setZoneGroupId(rpmZoneGroupInfoMap
				.get(CSVHeaders.RPMZoneGroupHeaders.ZONE_GROUP_ID));
		zoneGrpEntity.setZoneGroupName(rpmZoneGroupInfoMap
				.get(CSVHeaders.RPMZoneGroupHeaders.ZONE_GROUP_NAME));
		zoneGrpEntity.setZoneGroupType(rpmZoneGroupInfoMap
				.get(CSVHeaders.RPMZoneGroupHeaders.ZONE_GROUP_TYPE));
		zoneGrpEntity.setCreatedDate(date);
		zoneGrpEntity.setCreatedById(PriceConstants.ONETIME_ZONE_CREATED_BY);
		zoneGrpEntity.setLastUpdateDate(date);
		zoneGrpEntity
				.setLastUpdatedById(PriceConstants.ONETIME_ZONE_CREATED_BY);
		zoneGrpEntity.setZoneIds(zoneIds);
		return zoneGroupId;
	}

	public void setZoneGrpEntity(ZoneGrpEntity zoneGrpEntity) {
		this.zoneGrpEntity = zoneGrpEntity;
	}
}
