package com.tesco.services.adapters.core;

import javax.inject.Inject;
import javax.inject.Named;

import org.slf4j.Logger;

import com.tesco.services.adapters.rpm.writers.impl.MMWriter;
import com.tesco.services.adapters.rpm.writers.Writer;
import com.tesco.services.resources.ImportResource;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;

/**
 * This class validates the run identifier and fetches the file path . <<<<<<<
 * HEAD
 **/
public class ImportMMJob implements Import {

	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(ImportMMJob.class);

	private String runIdentifier;
	private Writer mmWriter;

	@Inject
	public ImportMMJob(@Named("mmWriter") Writer mmWriter) {
		this.mmWriter = mmWriter;
	}

	public String getRunIdentifier() {
		return runIdentifier;
	}

	public void setRunIdentifier(String runIdentifier) {
		this.runIdentifier = runIdentifier;
	}

	@Override
	public void run() {
		LOGGER.info("Firing up MM imports...");
		startImportProcess();
	}

	@Override
	public void startImportProcess() {
		try {
			LOGGER.info("Importing data from MM....");
			((MMWriter) mmWriter).setRunIdentifier(getRunIdentifier());
			// ((MMWriter)mmWriter).setMmClrFileReader(((MMWriter)mmWriter).getMmClrFileReader());
			mmWriter.write(null);
		} catch (Exception exception) {
			LOGGER.error("Error importing MM data", exception);
			ImportResource.setErrorString(runIdentifier,
					"error importing MM data");
		} finally {
			ImportResource.getImportSemaphoreForIdentifier(runIdentifier)
					.release();
		}
	}
}
