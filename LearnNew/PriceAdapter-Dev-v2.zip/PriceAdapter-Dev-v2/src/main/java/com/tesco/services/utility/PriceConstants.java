package com.tesco.services.utility;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * This Interface should contain all the constants required of the project.
 * Instead of hard coding constants in the code ,declare it in this Interface
 * and use in the code.
 */
public interface PriceConstants {
	String RUN_IDENT_MMONDEMAND = "mmondemand";
	String RUN_IDENT_RPMONETIME = "onetime";
	String CRE_CSV_READER = "crecsvreader";
	String MOD_CSV_READER = "modcsvreader";
	String DEL_CSV_READER = "delcsvreader";
	String PROMO_ZONE_REJ_FILE = "promozone";
	String PROMO_EXTRACT_REJ_FILE = "promoextract";
	String PROMOTION_STATE = "APPROVED";
	String PRICE_CHANGE_STATE = "APPROVED";

	int THREAD_LIMIT = 10;
	int TEAUTH_RECORD_COUNT_LIMIT = 500;

	String POS_LABEL_ONE = "1";
	String POS_LABEL_Y = "Y";
	String POS_LABEL_N = "N";
	String TPNB_IDENTIFIER = "tpnb";
	String TPNC_IDENTIFIER = "tpnc";
	String STORE_IDENTIFIER = "store";
	String GET_CALL_ROOT = "price";
	String VARIANTS = "variants";
	String GET_PRICE_LIST_DATA = "data";
	String GET_PRICE_LIST_ERRORS = "errors";
	String ERROR_PROD_ID = "id";
	String ERROR_STATUS_CODE = "statusCode";
	String ERROR_MESSAGE = "message";
	String PRICE = "regPrice";
	String PRICING_DATE = "pricingDate";
	String PRICING_LOC = "pricingLocation";
	String LOC_TYPE = "locType";
	String LOC_REF = "locRef";
	String PROD_REF = "prodRef";
	String PROMO_PRICE = "promoPrice";
	String SELLING_UOM = "sellingUOM";
	String CLEARANCE_PRICE = "clrPrice";
	String AUTH_PRICE = "authPrice";
	String PROMOTION_INFO = "promotions";
	String CURRENCY = "currency";
	String OFFER_ID = "offerId";
	String OFFER_NAME = "offerName";
	String EFFECTIVE_DATE = "effectiveDate";
	String END_DATE = "endDate";
	String CUSTOMER_FRIENDLY_DESCRIPTION_1 = "customerFriendlyDescription1";
	String CUSTOMER_FRIENDLY_DESCRIPTION_2 = "customerFriendlyDescription2";
	String STORE = "store";
	String NATIONAL = "national";
	String LOC_REF_COUNTRY = "UK";

	String PROMOTION_DOC_KEY_PREFIX = "PROMOTION_";
	String PROD_OFFERS = "PRODOFFERS_";

	String PRICE_DOC_KEY_PREFIX = "REGPRICE_";
	String SONETTO_UK_DOC_KEY_PREFIX = "UKAVWT";
	String SONETTO_ROI_DOC_KEY_PREFIX = "ROIAVWT";

	String ONETIME_RPM_ZONE = "rpmzoneonetime";
	String ONETIME_PRICE = "onetimeprice";
	String SONETTO_UK = "sonettouk";
	String SONETTO_ROI = "sonettoroi";
	String SONETTO_DISPLAY_TYPE_ONE = "1";
	String SONETTO_DISPLAY_TYPE_TWO = "2";
	String SONETTO_DISPLAY_TYPE_THREE = "3";
	String SONETTO_UOM_VALUE = "KG";
	String ONETIME_RPM_ZONE_FILENAME = "tsl_rpm_zone_onetime.csv";
	String ONETIME_SUBGRP_DFLT_UOM_FILENAME = "subgroup_dflt_uom_20160412.dat";
	String ISO_8601_FORMAT = "yyyy-MM-dd'T'HH:mm:ssXXX";
	String DATE_FORMAT = "MMM dd yyyy hh:mma";
	String DATE_FORMAT_FOR_PROMOTION_END_DATE = "yyyy-MM-dd";
	String APPEND_HOURS_MIN_SEC_TO_END_DATE = "T23:59:59Z";

	String ZONE_KEY = "ZONE_";
	int MULTIBUY_ARRAY_SIZE = 1;

	int PRODUCT_SERVICE_CALL_LIMIT = 20;
	String PRODUCT_SERVICE_RESPONSE_PRODUCTS = "products";
	String PRODUCT_SERVICE_RESPONSE_TPNC = "TPNC";
	String PRODUCT_SERVICE_RESPONSE_GTIN14 = "GTIN14";
	String PRODUCT_SERVICE_RESPONSE_TOTAL = "total";
	String PRODUCT_SERVICE_RESPONSE_MISSING_SET = "missingSet";
	String PROMO_DETAIL_ID_KEY = "PROMO_COMP_DETAIL_ID_";
	String ONE_TIME_RPM = "ONETIMERPM";
	String JMS_RPM = "RPM";
	String SONETTO_PRODUCTS = "Products";

	public enum PROMOTION_IMPORT_TYPES {
		ONETIME("onetimepromotion"), CRE("cre"), MOD("mod"), DEL("del");

		private String value;

		PROMOTION_IMPORT_TYPES(String val) {
			this.value = val;
		}

		public String value() {
			return value;
		}

		public static List<?> getPromotionTypes() {
			return Arrays.asList(PROMOTION_IMPORT_TYPES.ONETIME.value());
		}
	}

	;

	String PROMO_MSG_TYPE_PATH = "//RibMessages/ribMessage/type";
	String PROMO_MSG_PUBLISH_DATE_PATH = "//RibMessages/ribMessage/publishTime";
	String PROMO_MSG_DATA_PATH = "//messageData";
	String PROMO_SIMPLE_OFFER_TYPE = "SIMPLE";
	String PROMO_THRESHOLD_OFFER_TYPE = "THRESHOLD";
	String PROMO_MB_OFFER_TYPE = "MULTIBUY";
	String PROMO_MSG_RAW_NEW_STATE = "pcd.new";
	String PROMO_MSG_RAW_REAPPROVED_STATE = "pcd.reapproved";
	String PROMO_MSG_RAW_CANCELLED_STATE = "pcd.cancelled";
	String PROMO_MSG_RAW_DELETED_STATE = "pcd.deleted";
	String PROMO_MSG_APPROVED_STATE = "APPROVED";
	String PROMO_MSG_CANCELLED_STATE = "CANCELLED";
	String PROMO_MSG_DELETED_STATE = "DELETED";
	String PROMO_MSG_TYPE_CRE = "PRMPRCCHGCRE";
	String PROMO_MSG_TYPE_MOD = "PRMPRCCHGMOD";
	String PROMO_MSG_TYPE_DEL = "PRMPRCCHGDEL";
	String SIMPLE_PROMO_THR_TYPE = "Q";
	int SIMPLE_PROMO_THR_AMT = 0;
	int SIMPLE_PROMO_THR_QTY = 1;
	String PROMO_CHANGE_UOM = "0";
	int PROMO_CHANGE_PERCENT_FOR_FIXED_AMOUNT = 0;
	int PROMO_CHANGE_AMT_FOR_PRCNTGE_TYPE = 0;
	int PROMO_CHANGE_AMT_FOR_QTY_THR = 0;
	int PROMO_CHANGE_QTY_FOR_AMT_THR = 0;
	int DEFAULT_PROMO_CHANGE_QTY = 1;
	int SIMPLE_PROMO_THR_CHG_PRCNT = 0;
	String PROMO_ITEM_TYPE = "TPNB";
	String PROMO_ITEM_LIST_BUY_TYPE = "BUY";
	String PROMO_ITEM_LIST_GET_TYPE = "GET";
	String PROMO_ITEM_BUY_TYPE = "B";
	String PROMO_ITEM_GET_TYPE = "G";

	String ZONE_ENTITY_KEY = "ZONE_";
	String PROMO_CREATED_ID_RPM = "RPM";

	String PROMO_MSG_DATE_FORMAT = "yyyyMMddHHmmss";

	String PRODUCT_AVG_WEIGHT_PATH = "BaseProduct";
	String PRODUCT_AVG_WEIGHT_TPNB_PATH = "tpnb";
	String PRODUCT_AVG_WEIGHT_DISPLAYTYPE_PATH = "DisplayType";
	String PRODUCT_AVG_WEIGHTSELECTION_PATH = "AverageWeight";
	String PRODUCT_MAX_WEIGHTSELECTION_PATH = "MaximumWeight";
	String PRODUCT_MIN_WEIGHTSELECTION_PATH = "MinimumWeight";
	String PRODUCT_INCREMENT_WEIGHTSELECTION_PATH = "Increment";

	public enum PROMO_THR_TYPES {
		QTY("Q"), AMT("A");

		private String value;

		PROMO_THR_TYPES(String val) {
			this.value = val;
		}

		public String value() {
			return value;
		}
	}

	;

	public enum PROMO_CHG_TYPES {
		PCT("P"), AMT("A"), FXD("F"), NO_CHG("N"), CLB_CRD("C"), VOC("V");

		private String value;

		PROMO_CHG_TYPES(String val) {
			this.value = val;
		}

		public String value() {
			return value;
		}
	}

	;

	public enum MULTI_BUY_PROMO_TYPE {
		LINK_SAVE("L"), CHOICE_SAVE("C"), MEAL_DEAL("M");
		private String value;

		MULTI_BUY_PROMO_TYPE(String val) {
			this.value = val;
		}

		public String value() {
			return value;
		}
	}

	;

	public enum FUTURE_OFFER_DESC_RANGE {
		RANGE_BEGIN(1), RANGE_END(2);
		private int value;

		FUTURE_OFFER_DESC_RANGE(int val) {
			this.value = val;
		}

		public int value() {
			return value;
		}

	}

	public int SECTION = 1;
	public int CLASS = 2;
	public int SUBCLASS = 3;

	public String SECTION_STR = "SECTION";
	public String CLASS_STR = "CLASS";
	public String SUBCLASS_STR = "SUBCLASS";

	public List<String> HIERARCHY_LIST = new ArrayList<String>(Arrays.asList(SECTION_STR, CLASS_STR, SUBCLASS_STR));

	public String OFFER_PREFIX = "OFFER_";
	public String ZONE_PREFIX = "Z";
	public String HIERARCHY_PROMO_PREFIX = "PROMOHIER_";

	public String PRICE_REJ_FILE = "REJECT_PRICE_FILE_FailedMsgs";
	public String PRICE_MSG_TYPE_CRE = "REGPRCCHGCRE";
	public String PRICE_MSG_TYPE_DEL = "REGPRCCHGDEL";

	public String TSL_COUNTRY_GB = "GB";
	public String TSL_COUNTRY_IE = "IE";
	public String ONETIME_ZONE_CREATED_BY = "ONETIMERPM";
	public String OFFER_PREFIX_UK = "A";
	public String OFFER_PREFIX_ROI = "R";

	public String SUBGRP_DFLT_UOM_KEY = "SUBGRP_DFLT_UOM";
	public String ONETIME_SUBGRP_DFLT_UPDATED_BY = "ODS";
	public String SUBGRP_DFLT_RUN_IDENTIFIER = "subgroup_dflt_uom";
	public String PRODUCT_AVG_WEIGHT_UK_RUNIDENTIFIER = "sonettouk";
	public String PRODUCT_AVG_WEIGHT_ROI_RUNIDENTIFIER = "sonettoroi";

	public String ZONE_REJ_FILE = "REJECT_ZONE_FILE_FailedMsgs";
	public String ZONE_MSG_TYPE_CRE = "ZONECRE";
	public String ZONE_MSG_TYPE_MOD = "ZONEMOD";
	public String ZONE_MSG_TYPE_DEL = "ZONEDEL";
	public String ZONE_GRP_MSG_TYPE_CRE = "ZONEGROUPCRE";
	public String ZONE_GRP_MSG_TYPE_MOD = "ZONEGROUPMOD";
	public String ZONE_GRP_MSG_TYPE_DEL = "ZONEGROUPDEL";
	public String ZONE_LOC_MSG_TYPE_CRE = "ZONELOCCRE";
	public String ZONE_LOC_MSG_TYPE_DEL = "ZONELOCDEL";
	public String ZONE_GRP_KEY = "ZONEGROUP_";
	public String STORE_KEY = "STORE_";
	public String PRICE_ZONE_TYPE = "2";
	public String PROMO_ZONE_TYPE = "1";
	public String CLEARANCE_ZONE_TYPE = "0";

	public String ONETIME_RPM_ZONE_GROUP = "rpmzonegrouponetime";

	public String REFRESH_URL_SUBGROUP = "/v3/price/refreshSubGroupDefaultMapping";
	public String REFRESH_URL_PRODUCT_AVG_WEIGHT = "/v3/price/refreshAvgWeightMapping";

	public String ESTABLISHED_PRICE = "estdprice";
	String FUTURE_OFFER_DESC = "futureOfferDesc";
	String FUTURE_OFFER_DESC_ONETIME = "oneTimeFutureOfferDesc";
	public String RPM_CLR_PRODUCT = "CLRPROD_";
	public String DATE_FORMAT_YYYYMMDDHHMMSS = "yyyy-MM-dd'T'HH:mm:ss";

	public enum ITEM_TYPE {
		TPNB("TPNB"), TPNC("TPNC");

		private String value;

		ITEM_TYPE(String val) {
			this.value = val;
		}

		public String value() {
			return value;
		}

		public String lowerCaseValue() {
			return value.toLowerCase();
		}
	}

	public String FUTURE_PRICE_MSG_TYPE_CRE = "PriceChanged";
	public String FUTURE_PRICE_MSG_TYPE_DEL = "PriceDeleted";
	public String PRICE_REF = "priceRef";
	public String PROMOTION_MSG_TYPE_CRE = "PromotionCreated";
	public String ZONE_MSG_TYPE_CREATED = "ZoneCreated";
	public String ZONE_MSG_TYPE_DTLS_CHANGED = "ZoneDetailsChanged";
	public String ZONE_MSG_TYPE_DELETED = "ZoneDeleted";
	public String STORE_ZONE_CHANGE = "StoreZoneChanged";
	public String ZONE_CRE_EVNT_LTD = "1";
	public String EVENT_PREFIX = "EVENT_";
	public String STORE_PREFIX = "S";

	public String EVENT_EFFECTIVE_DATE = "effectiveDate";

	public String LOCATION_ID = "LocationID";
	public String LEAD_TIME_DAYS = "LeadTimeDays";
	public String EVENT_TYPE = "EventType";

	public String EVENT_CORR_ID = "EventCorrelationID";
	public String PRODUCT_REF = "prodRef";
	public String PROD_TYPE = "prodType";

	public String COUNTRY = "country";
	public String LOCATIONS = "locations";
	public String CLEARANCE_ID = "clearanceId";
	public String CLEARANCE_CREATED_EVENT_TYPE = "ClearanceCreated";
	public String CLEARANCE_DELETED_EVENT_TYPE = "ClearanceDeleted";
	public String CLEARANCE_DEL = "DEL";
	public String STORE_RPM_BACKUP_MAP = "CLR_RPM_STORE_MAP";
	public String INSERT_ACTION_FILE_CODE = "I";
	public String CURRENCY_CODE_GBP = "GBP";
	public String LOC_REF_COUNTRYCODE_UK = "GB";
	public String LOC_REF_COUNTRYCODE_ROI = "IE";
	public String EVENT_CORR_ID_PREFIX = "EVENT_";
	public String REALTIME_TEMPLATE_ID = "REALTIME";
	public String NATIONAL_IN_FILE_CODE = "N";
	public String DELETE_ACTION_FILE_CODE = "D";
	public String UPDATE_ACTION_FILE_CODE = "U";
	public String STORE_IN_FILE_CODE = "S";
	public String AUTHORIZATION = "Authorization";
	String APPLICATION_JSON = "application/json";
	int SCHEDULED_LEAD_DAYS = 1;
	String COUCHBASE_VIEW_QUERY = "couchbaseViewQuery";
	String COUCHBASE_VIEW_URL = "couchbaseViewUrl";
	String SCHEDULED_FUTURE_PRICE_MSG_TYPE_CRE = "PriceChange";
	String SCHEDULED_PROMOTION_START_EVENT_TYPE = "PromotionStart";
	String SCHEDULED_PROMOTION_END_EVENT_TYPE= "PromotionEnd";
	String SCHEDULED_PROMOTION_START_PRODUCT_EVENT_TYPE= "PromotionStartProduct";
	String STALE_STATE = "stale";
	String VIEW_QUERY_KEY = "key";
	String CONNECTION_TIMEOUT = "connection_timeout";
	String LIMIT = "limit";
	String SKIP = "skip";
	String SUCCESS_MESSAGE = "{\"message\":\"Publishing of price change event has Started\"}";
	String SUCCESS_MESSAGE_PROMOTION_START = "{\"message\":\"Publishing of promotion start event has Started\"}";
	String SUCCESS_MESSAGE_PROMOTION_END = "{\"message\":\"Publishing of promotion end event has Started\"}";
	String COMPLETED_MESSAGE_SCHEDULED_JOB = "{\"import\":\"completed\"}";
	String INPROGRES_MESSAGE_SCHEDULED_JOB = "{\"import\":\"progress\"}";
	String ERROR_MESSAGE_CLEARANCE_END_SCHEDULED_JOB = "{\"import\":\"aborted\",\n \"error\":\"Error while processing scheduled events of type[ClearanceEnd]...\"}";
	String NO_PROCESS_MESSAGE_SCHEDULED_JOB = "{\"import\":\"No Process\"}";
	String EVENT_ERROR_MESSAGE = "{\"message\":\"There is already a scheduled event publication in progress.\"}";
	String SCHEDULED_EVENT_ADMIN = "/scheduledEventAdmin";
	String SCHEDULED_EVENT_LEAD_DAY = "1";
	String COLON_SEPARATOR = ":";
	String UNDERSCORE_SEPARATOR = "_";
	String COLON_ENCODE = "%3A";
	String PLUS_ENCODE = "%2B";
	String PLUS_SEPARATOR = "+";
	String PRICE_SCHEDULED_THREAD = "Price scheduled thread";
	String PROMOTION_START_SCHEDULED_THREAD = "Promotion Start scheduled thread";
	String PROMOTION_SCHEDULED_THREAD = "Promotion scheduled thread";
	String PROMOTION_END_SCHEDULED_THREAD = "Promotion End scheduled thread";
	String CLEARANCE_START_SCHEDULED_THREAD = "Clearance Start scheduled thread";
	String CLEARANCE_END_SCHEDULED_THREAD = "Clearance End scheduled thread";
	String PROMOTION_START_PRODUCT_SCHEDULED_THREAD = "Promotion start product scheduled event thread";
	public String CLEARANCES = "clearances";
	public String CLEARANCE_OFFER_ID = "clearanceOfferId";
	public String UPDATE_CLR_END_DATE_ACTION_FILE_CODE = "U-CLR-END-DATE";
	public String RPM_CLR_CRE = "CRE";
	public String RPM_CLR_MOD = "MOD";

	public String CLEARANCE_END_DATE_CHANGED_EVENT_TYPE = "ClearanceEndDateChanged";
	public String CLEARANCE_PREV_PRICE_CHANGE_EVENT_TYPE = "ClearancePrevPriceChanged";
	public String CLEARANCE_START_EVENT_TYPE = "ClearanceStart";
	public String CLEARANCE_END_EVENT_TYPE = "ClearanceEnd";
	String SUCCESS_MESSAGE_CLEARANCE_START = "{\"message\":\"Publishing of clearance start event has Started\"}";
	String SUCCESS_MESSAGE_CLEARANCE_END = "{\"message\":\"Publishing of clearance end event has Started\"}";

	public String SELL_BY_TYPE_INDIVIDUAL = "I";
	public String SELL_BY_TYPE_SINGLE = "S";
	public String ITEM_DEFAULT_UOM_RUNIDENTIFIER = "item_dflt_uom";
	public String ITEM_DFLT_UOM_KEY = "ITEM_DFLT_UOM";
	public String REFRESH_URL_ITEM_DEFAULT_UOM = "/v3/price/refreshItemDefaultMapping";
	public String ITEM_DFLT_UOM_FILENAME = "item_dflt_uom_20160413.dat";
	public String ITEM_DFLT_UPDATED_BY = "ODS";
	public String PRODUCT_TPNB_KEY = "PRODUCT_TPNB";

	public String HIERARCHY_PROMOTION_INSERTED_COUNT = "HIERARCHY_PROMOTION_INSERTED_COUTED";
	public String HIERARCHY_PROMOTION_REJECTED_COUNT = "HIERARCHY_PROMOTION_REJECTED_COUTED";

	public String PROMOTION_DOCUMENT = "PROMOTION_OFFER_LOCATION";
	public String PROMOTION_MASTER_DOCUMENT = "PROMOTION_OFFER";
	public String PROMOTION_LOOKUP_DOCUMENT = "PROMOTION_LOOKUP";
	public String PROMOTION_PRODOFFERS_DOCUMENT = "PROMOTION_PRODOFFERS";
	public String PROMOTION_HIERARCHY_DOCUMENT = "PROMOTION_HIERARCHY";
	public String PROMOTION_ONETIME = "ONETIME";
	public String DELETE_PRODOFFERS_DOCUMENT = "PRODOFFERS_DOC_DELETED";
	public String DELETE_PROMOTION_DOCUMENT = "PROMOTION_DOC_DELETED";
	public String DELETE_PROMOTION_MASTER_DOCUMENT = "PROMOTION_MASTER_DOC_DELETED";
	public String DELETE_PROMOTION_LOOKUP_DOCUMENT = "PROMOTION_LOOKUP_DOC_DELETED";
	public String DELETE_PROMOTION_HIERARCHY_DOCUMENT = "PROMOTION_HIERARCHY_DOC_DELETED";
	
	public String PROMOTION_DETAILS_CHANGED_EVENT_TYPE = "PromotionDetailsChanged";
	public String PROMOTION_DETAILS_CHANGED_OFFER_LEVEL_KEY = "promotionDetailsChangedOfferLevel";
	public String PROMOTION_DETAILS_CHANGED_PRODUCT_LEVEL_KEY = "promotionDetailsChangedProductLevel";

	public String PROMO_LOC_ADDED = "PromotionLocationAdded";
	public String PROMO_PRODUCT_ADDED = "PromotionProductAdded";
	public String PROMO_PRODUCT_ITEM_LIST = "PromotionProductItemList";
	public String PROMOTION_CREATED_LOCATION_ADDED_PRODUCT_ADDED_KEY = "PromotionCreOrLocAddedOrProductAddedDataMap";
    String PROMOTION_ENDDATE_CHANGED = "PromotionEndDateChanged";
    String PROMOTION_ENDDATE_CHANGED_PER_ITEM = "PromotionEndDateChangedPerItem";
	
	public String PROMOTION_DELETED_EVENT_TYPE = "PromotionDeleted";
	public String PROMOTION_LOCATION_REMOVED_EVENT_TYPE = "PromotionLocationRemoved";
	public String PROMOTION_PRODUCT_REMOVED_EVENT_TYPE = "PromotionProductRemoved";
	String PRODUCT_KEY_PREFIX = "PRODUCT_";
	String CLEARANCE_KEY_PREFIX = "CLRPROD_";
	String CLEARANCE_MM_PRODUCT_KEY_PREFIX = "CLRMMPROD_";
	String EAN_KEY_PREFIX = "EAN_";
}
