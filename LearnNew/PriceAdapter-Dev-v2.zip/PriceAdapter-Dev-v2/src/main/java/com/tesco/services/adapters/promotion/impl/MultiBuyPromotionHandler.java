package com.tesco.services.adapters.promotion.impl;

import com.tesco.promotion.core.*;
import com.tesco.services.Configuration;
import com.tesco.services.adapters.promotion.PromotionHandler;
import com.tesco.services.adapters.rpm.writers.PromotionMessageWriter;
import com.tesco.services.core.ZoneEntity;
import com.tesco.services.core.promotion.*;
import com.tesco.services.exceptions.DataAccessException;
import com.tesco.services.exceptions.PromoBusinessException;
import com.tesco.services.repositories.Repository;
import com.tesco.services.repositories.RepositoryImpl;
import com.tesco.services.utility.*;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;
import org.apache.commons.lang.time.DateUtils;
import org.joda.time.DateTime;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.tesco.services.utility.CommonEventPublishingUtility.getEndDateChangedMapDataPerItem;
import static com.tesco.services.utility.PriceConstants.*;

/**
 * Created by qu17 on 5/26/2015.
 */

public class MultiBuyPromotionHandler implements PromotionHandler {

	private Repository repository;
	private PromotionMessageWriter promotionWriter;
	private Configuration configuration;

	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(MultiBuyPromotionHandler.class);

	private static PromotionJmsLog PROMOMSGCOUNTER = PromotionJmsLogImpl
			.getInstance();

	@Inject
	public MultiBuyPromotionHandler(
			@Named("repository") Repository repository,
			@Named("promotionWriter") PromotionMessageWriter promotionWriter,
			@Named("configuration") Configuration configuration) {
		this.promotionWriter = promotionWriter;
		this.repository = repository;
		this.configuration = configuration;
	}

	@Override
	public Map<String, Object> processCreMessage(
			PromotionEntity inputPromotionEntity,
			List<PrmPrcChgDtl> prmPrcChgDtls, String promoMsgForZoneId,
			String msgState, String msgOfferType, String promoMsgLocType)
			throws PromoBusinessException {
		Map<String, Object> allEventsDataMap = new HashMap<>();
		Map<String, Object> promotionDetailsChangedOfferLevelEventMap = new HashMap<>();
		Map<String, Object> promotionCreatedMap = new HashMap<>();
		Map<String, Object> promotionDetailsChangedProductLevelEventMap = new HashMap<>();
		Map<String, Object> promotionEndDateEventMapData = new HashMap<>();
		PromotionEntity existingPromotionEntity = null;
		try {
			if (inputPromotionEntity != null) {
				existingPromotionEntity = inputPromotionEntity.deepCopy();
			}
		} catch (Exception e) {
			throw new PromoBusinessException(e.getMessage(), e);
		}
		Map<String, DateTime> leastEffectiveDateMap = new HashMap<>();
		Map<String, PromotionEntity> promotionEntityMap = new HashMap<>();
		PromotionEntity promotionEntity;
		List<PromoItemListEntity> promoItemListEntities;
		PromoItemListEntity promoItemListEntity;
		String zoneCurrency = null;
		try {
			 zoneCurrency = getCurrencyForLoc(promoMsgForZoneId);
		}
		catch(DataAccessException e){
			throw new PromoBusinessException(e.getMessage(), e);
		}
		String effectiveDate = null;
		String endDate = null;
		String multiBuyPromoType;
		String changeTypeForMB;
		SimpleDateFormat dateFormat = new SimpleDateFormat(
				PriceConstants.DATE_FORMAT_FOR_PROMOTION_END_DATE);
		Calendar cal = Calendar.getInstance();
		Date sysDate = cal.getTime();
		Date incrementDateByTwo = DateUtils.addDays(sysDate,
				configuration.getDaysToEndMultibuyPromo());
		String formatDate = dateFormat.format(incrementDateByTwo);
		String endDateMultibuy = formatDate
				.concat(PriceConstants.APPEND_HOURS_MIN_SEC_TO_END_DATE);

		for (PrmPrcChgDtl prmPrcChgDtl : prmPrcChgDtls) {

			TSLPrmPrcChgMultiBuy tslPrmPrcChgMultiBuy = prmPrcChgDtl
					.getTSLPrmPrcChgMultiBuy();
			multiBuyPromoType = tslPrmPrcChgMultiBuy.getMultiBuyPromoType();
			String state = prmPrcChgDtl.getTslState();

			effectiveDate = getDate(prmPrcChgDtl.getStartDate().getYear()
					.toString(), prmPrcChgDtl.getStartDate().getMonth()
					.toString(), prmPrcChgDtl.getStartDate().getDay()
					.toString(), prmPrcChgDtl.getStartDate().getHour()
					.toString(), prmPrcChgDtl.getStartDate().getMinute()
					.toString(), prmPrcChgDtl.getStartDate().getSecond()
					.toString());
			if (inputPromotionEntity != null) {
				String offerId = inputPromotionEntity.getOfferRef();
				CommonEventPublishingUtility.addOnlyLeastEffectiveDate(
						leastEffectiveDateMap, effectiveDate, offerId);
			}
			endDate = getDate(prmPrcChgDtl.getEndDate().getYear().toString(),
					prmPrcChgDtl.getEndDate().getMonth().toString(),
					prmPrcChgDtl.getEndDate().getDay().toString(), prmPrcChgDtl
							.getEndDate().getHour().toString(), prmPrcChgDtl
							.getEndDate().getMinute().toString(), prmPrcChgDtl
							.getEndDate().getSecond().toString());

			promotionEntity = new PromotionEntity();
			promotionEntity.offerRef = prmPrcChgDtl.getTslPromoCompDisplayId();
			promotionEntity.offerType = msgOfferType;
			promotionEntity.multiBuyPromoType = multiBuyPromoType;
			promotionEntity.state = msgState;
			promotionEntity.name = prmPrcChgDtl.getPromoCompDesc();
			promotionEntity.externalPromoId = prmPrcChgDtl.getTslExtPromoId() != null ? prmPrcChgDtl
					.getTslExtPromoId().toString() : null;
			promotionEntity.tillRollDescription = prmPrcChgDtl
					.getTslCompLevelTillDesc();
			promotionEntity.couponTriggeredInd = false;
			promotionEntity.locType = promoMsgLocType;
			promotionEntity.locRef = promoMsgForZoneId;
			promotionEntity.createdById = PriceConstants.PROMO_CREATED_ID_RPM;
			promotionEntity.createdDate = Dockyard
					.getSysDate(PriceConstants.ISO_8601_FORMAT);
			promotionEntity.lastUpdatedById = PriceConstants.PROMO_CREATED_ID_RPM;
			promotionEntity.lastUpdateDate = Dockyard
					.getSysDate(PriceConstants.ISO_8601_FORMAT);

			promoItemListEntities = new ArrayList<>();
			PromoThresholdEntity promoThresholdEntity;
			PromoRewardEntity promoRewardEntity = new PromoRewardEntity();

			/**
			 * Loop the Multi-Buy List for setting Promo Threshold refs and Item
			 * List
			 */
			List<TSLPrmPrcChgBuyList> tslPrmPrcChgBuyLists = tslPrmPrcChgMultiBuy
					.getTSLPrmPrcChgBuyList();
			for (int i = 0; i < tslPrmPrcChgBuyLists.size(); i++) {

				/**
				 * Creating new Threshold Entity for each Buy list in the
				 * Promotion
				 */
				promoThresholdEntity = new PromoThresholdEntity();
				/**
				 * Creating new ItemList for each Buy list in the Promotion
				 */
				promoItemListEntity = new PromoItemListEntity();
				TSLPrmPrcChgBuyList tslPrmPrcChgBuyList = tslPrmPrcChgBuyLists
						.get(i);

				promoThresholdEntity.thresholdType = PriceConstants.SIMPLE_PROMO_THR_TYPE;
				promoThresholdEntity.thresholdCurrency = zoneCurrency;
				promoThresholdEntity.thresholdQty = tslPrmPrcChgBuyList
						.getBuyItemValue().intValue();

				promoItemListEntity.listType = PriceConstants.PROMO_ITEM_LIST_BUY_TYPE;
				promoItemListEntity.setThresholdRefs(setThrRewardRefs(i));

				/**
				 * Looping Buy Item List from Buylist.
				 */
				for (TSLPrmPrcChgBuyListItem tslPrmPrcChgBuyListItem : tslPrmPrcChgBuyList
						.getTSLPrmPrcChgBuyListItem()) {

					PromoItemEntity promoItemEntity = new PromoItemEntity();

					if (!("0").equals(tslPrmPrcChgBuyListItem.getMerchType()
							.toString())) {
						throw new PromoBusinessException(
								"Invalid Message - with non zero merch type - Multi buy");
					}
					promoItemEntity.itemType = PriceConstants.PROMO_ITEM_TYPE;
					promoItemEntity.itemRef = tslPrmPrcChgBuyListItem.getItem();

					if (state
							.equalsIgnoreCase(PriceConstants.PROMO_MSG_RAW_CANCELLED_STATE)) {
						promoItemEntity.setEffectiveDate(effectiveDate);
						promoItemEntity.setEndDate(endDateMultibuy);

					} else {
						promoItemEntity.setEffectiveDate(effectiveDate);
						promoItemEntity.setEndDate(endDate);
					}

					if (tslPrmPrcChgMultiBuy.getTslPosLabelReqInd() != null) {
						if (PriceConstants.POS_LABEL_ONE
								.equals(tslPrmPrcChgMultiBuy
										.getTslPosLabelReqInd().toString())) {
							promoItemEntity
									.setPosLabelReqInd(PriceConstants.POS_LABEL_Y);
						} else {
							promoItemEntity
									.setPosLabelReqInd(PriceConstants.POS_LABEL_N);

						}
					} else {
						promoItemEntity
								.setPosLabelReqInd(PriceConstants.POS_LABEL_N);
					}

					if (prmPrcChgDtl.getPromoCompDetailId() != null) {
						promoItemEntity.setRpmPromoCompDetailId(prmPrcChgDtl
								.getPromoCompDetailId().toString());

					}

					promoItemListEntity.addPromoItem(promoItemEntity);
				}
				promoItemListEntities.add(promoItemListEntity);
				promotionEntity.addPromoThresholdEntity(promoThresholdEntity);
			}

			/**
			 * Extract Get-List item for LS and Change Reward for MD & CS and
			 * set the reward refs and Item Lists
			 */
			TSLPrmPrcChgGetList tslPrmPrcChgGetLists = tslPrmPrcChgMultiBuy
					.getTSLPrmPrcChgGetList();
			TSLPrmPrcChgReward tslPrmPrcChgReward = tslPrmPrcChgMultiBuy
					.getTSLPrmPrcChgReward();

			if (PriceConstants.MULTI_BUY_PROMO_TYPE.LINK_SAVE.value().equals(
					multiBuyPromoType)) {
				/**
				 * Creating new ItemList for Single GET list (LINK SAVE MB)
				 */
				promoItemListEntity = new PromoItemListEntity();

				promoRewardEntity.changeType = getChangeType(tslPrmPrcChgGetLists
						.getChangeType().intValue());
				changeTypeForMB = promoRewardEntity.changeType;
				promoRewardEntity.changeQty = PriceConstants.DEFAULT_PROMO_CHANGE_QTY;

				if (PriceConstants.PROMO_CHG_TYPES.AMT.value().equals(
						changeTypeForMB)
						|| PriceConstants.PROMO_CHG_TYPES.FXD.value().equals(
								changeTypeForMB)) {
					promoRewardEntity.changeAmount = tslPrmPrcChgGetLists
							.getChangeAmount();
				}
				promoRewardEntity.changeCurrency = zoneCurrency;
				if (PriceConstants.PROMO_CHG_TYPES.PCT.value().equals(
						changeTypeForMB)) {
					promoRewardEntity.changePercent = tslPrmPrcChgGetLists
							.getChangePercent() * 100;
				}
				promoRewardEntity.changeUom = null;
				promoItemListEntity.listType = PriceConstants.PROMO_ITEM_LIST_GET_TYPE;
				promoItemListEntity.setRewardRefs(setThrRewardRefs(0));

				/**
				 * Looping Get Item List from getlist.
				 */
				for (TSLPrmPrcChgGetListItem tslPrmPrcChgGetListItem : tslPrmPrcChgGetLists
						.getTSLPrmPrcChgGetListItem()) {
					PromoItemEntity promoItemEntity = new PromoItemEntity();

					if (!("0").equals(tslPrmPrcChgGetListItem.getMerchType()
							.toString())) {
						throw new PromoBusinessException(
								"Invalid Message - with non zero merch type - Multi buy");
					}
					promoItemEntity.itemType = PriceConstants.PROMO_ITEM_TYPE;
					promoItemEntity.itemRef = tslPrmPrcChgGetListItem.getItem();

					/**
					 * Effective date and End date are not required for
					 * GetItemList
					 */
					if (tslPrmPrcChgMultiBuy.getTslPosLabelReqInd() != null) {
						if (PriceConstants.POS_LABEL_ONE
								.equals(tslPrmPrcChgMultiBuy
										.getTslPosLabelReqInd().toString())) {
							promoItemEntity
									.setPosLabelReqInd(PriceConstants.POS_LABEL_Y);
						} else {
							promoItemEntity
									.setPosLabelReqInd(PriceConstants.POS_LABEL_N);
						}
					} else {
						promoItemEntity
								.setPosLabelReqInd(PriceConstants.POS_LABEL_N);
					}

					if (prmPrcChgDtl.getPromoCompDetailId() != null) {
						promoItemEntity.setRpmPromoCompDetailId(prmPrcChgDtl
								.getPromoCompDetailId().toString());
					}

					promoItemListEntity.addPromoItem(promoItemEntity);

				}
				promoItemListEntities.add(promoItemListEntity);
				promotionEntity.addPromoRewardEntities(promoRewardEntity);

			} else if (PriceConstants.MULTI_BUY_PROMO_TYPE.MEAL_DEAL.value()
					.equals(multiBuyPromoType)) {

				/**
				 * Creating new ItemList for Single GET list (MEAL DEAL MB)
				 */
				promoItemListEntity = new PromoItemListEntity();

				promoRewardEntity.changeType = getChangeType(tslPrmPrcChgReward
						.getChangeType().intValue());
				changeTypeForMB = promoRewardEntity.changeType;
				promoRewardEntity.changeQty = PriceConstants.DEFAULT_PROMO_CHANGE_QTY;

				if (PriceConstants.PROMO_CHG_TYPES.FXD.value().equals(
						changeTypeForMB)) {
					promoRewardEntity.changeAmount = tslPrmPrcChgReward
							.getChangeAmount();
				}

				promoRewardEntity.changeCurrency = zoneCurrency;
				promoRewardEntity.changeUom = null;
				promoItemListEntity.listType = PriceConstants.PROMO_ITEM_LIST_GET_TYPE;
				promoItemListEntity.setRewardRefs(setThrRewardRefs(0));

				promoItemListEntities.add(promoItemListEntity);
				promotionEntity.addPromoRewardEntities(promoRewardEntity);

			} else if (PriceConstants.MULTI_BUY_PROMO_TYPE.CHOICE_SAVE.value()
					.equals(multiBuyPromoType)) {

				/**
				 * Creating new ItemList for Single GET list (CHOICE SAVE MB)
				 */
				promoItemListEntity = new PromoItemListEntity();

				promoRewardEntity.changeType = getChangeType(tslPrmPrcChgReward
						.getChangeType().intValue());
				changeTypeForMB = promoRewardEntity.changeType;
				promoRewardEntity.changeQty = PriceConstants.DEFAULT_PROMO_CHANGE_QTY;

				if (PriceConstants.PROMO_CHG_TYPES.PCT.value().equals(
						changeTypeForMB)) {
					promoRewardEntity.changePercent = tslPrmPrcChgReward
							.getChangePercent() * 100;
				}

				promoRewardEntity.changeCurrency = zoneCurrency;
				promoRewardEntity.changeUom = null;
				promoItemListEntity.listType = PriceConstants.PROMO_ITEM_LIST_GET_TYPE;
				promoItemListEntity.setRewardRefs(setThrRewardRefs(0));

				promoItemListEntities.add(promoItemListEntity);
				promotionEntity.addPromoRewardEntities(promoRewardEntity);
			}

			promotionEntity.setPromoItemListEntities(promoItemListEntities);
			if (inputPromotionEntity != null) {
				promotionEntity.createdDate = inputPromotionEntity.createdDate;
			}
			promotionEntityMap.put(promotionEntity.getOfferRef(),
					promotionEntity);
			mapPromoCompDisplayIdToPromoCompDtlId(
					prmPrcChgDtl.getTslPromoCompDisplayId(), prmPrcChgDtl
							.getPromoCompDetailId().toString());
		}

		/**
		 * Write the Promo Doc to CB
		 */
		try {

			for (String offerId : promotionEntityMap.keySet()) {
				PromotionEntity pE = promotionEntityMap.get(offerId);
				if (!Dockyard.isSpaceOrNull(pE)) {
					/* Get Buy and Get List For Existing MultiBuyPromotion */
					List<String> previousBuyGetList = getBuyGetListForMultiBuyPromotion(inputPromotionEntity);

					/*
					 * PRIS-2010 Get cfDescription1 , cfDescription2 from
					 * existing promotion
					 */
					if (inputPromotionEntity != null) {
						pE.setCfDescription1(inputPromotionEntity
								.getCfDescription1());
						pE.setCfDescription2(inputPromotionEntity
								.getCfDescription2());
					}
					String eventType = verifyPromotionOrLocationExist(pE);
					promotionWriter.writePromoEntityFromMessage(pE);
					if (existingPromotionEntity != null) {
						Map<String, Object> argumentData = CommonEventPublishingUtility
								.preparePromoDetailsChangedOffLevelArgumentData(
										existingPromotionEntity,
										leastEffectiveDateMap, offerId, pE);
						argumentData.put("msgOfferType", msgOfferType);
						promotionDetailsChangedOfferLevelEventMap.put(offerId,
								argumentData);
					}
					/**
					 * Creating new ProdOffer Doc to support the Future dated
					 * promotions in PriceService
					 */
					Map<String, String> newProductData = promotionWriter
							.writeProdOfferDoc(pE);
					promotionCreatedMap = CommonEventPublishingUtility
							.preparePromotionCreatedEventDataMap(pE, eventType,
									newProductData);
					/* Get Buy and Get List For Modified MultiBuyPromotion */
					if (!previousBuyGetList.isEmpty()) {
						List<String> deletedItems = new ArrayList<String>();
						List<String> modifiedBuyGetList = getBuyGetListForMultiBuyPromotion(pE);
						deletedItems = getDeletedItems(previousBuyGetList,
								modifiedBuyGetList);
						List<String> allDeletedItemList = new ArrayList<String>();
						for (String item : deletedItems) {
							String zoneId = pE.getLocType() + pE.getLocRef();
							promotionWriter.deleteProdOfferDoc(item, zoneId,
									pE.getOfferRef());
							allDeletedItemList.add(item);
						}
						promotionEndDateEventMapData = getEndDateChangedMapDataPerItem(
								allDeletedItemList, inputPromotionEntity);
					}
					if (existingPromotionEntity != null) {
						Map<Object, Object> argumentDataPrdLevel = CommonEventPublishingUtility
								.preparePromoDetailsChangedProductLevelArgumentData(
										existingPromotionEntity, offerId, pE);
						argumentDataPrdLevel.put("msgOfferType", msgOfferType);
						promotionDetailsChangedProductLevelEventMap.put(
								offerId, argumentDataPrdLevel);
					}

				}
			}
		} catch (Exception e) {
			throw new PromoBusinessException(e.getMessage(), e);
		}
		allEventsDataMap.put(PROMOTION_DETAILS_CHANGED_PRODUCT_LEVEL_KEY,
				promotionDetailsChangedProductLevelEventMap);
		allEventsDataMap.put(
				PROMOTION_CREATED_LOCATION_ADDED_PRODUCT_ADDED_KEY,
				promotionCreatedMap);
		allEventsDataMap.put(PROMOTION_DETAILS_CHANGED_OFFER_LEVEL_KEY,
				promotionDetailsChangedOfferLevelEventMap);
		if (!promotionEndDateEventMapData.isEmpty()) {

			allEventsDataMap.put(
					PriceConstants.PROMOTION_ENDDATE_CHANGED_PER_ITEM,
					promotionEndDateEventMapData);
		}
		return allEventsDataMap;
	}

	@Override
	public Map<String, Object> processDelMessage(
			List<PrmPrcChgDtlRef> prmPrcChgDtlRefs, String promoMsgForZoneId)
			throws PromoBusinessException {

		String effectiveDate = "";
		Map<String, PromotionEntity> promotionEntityMap = new HashMap<>();
		Map<String, Object> promotionEventDataMap = null;
		Map<String, String> promotionEffectiveDateMap = new HashMap<String, String>();
		try {
			for (PrmPrcChgDtlRef prmPrcChgDtlRef : prmPrcChgDtlRefs) {
				String promoCompDetailId = Integer.toString(prmPrcChgDtlRef
						.getPromoCompDetailId().intValue());
				String promoCompDisplayId = (String) repository
						.getGenericObject(PriceConstants.PROMO_DETAIL_ID_KEY
								+ promoCompDetailId, String.class);
				if (promoCompDisplayId == null) {
					LOGGER.error(
							"Mapping document for promo_comp_detail_id :{} from Del Msg not present in ",
							promoCompDetailId);
					return null;
				}

				/**
				 * Deleting ProdOffer Doc which are processed in DEL message
				 */
				PromotionEntity prodOfferItemsToBeDeleted;
				prodOfferItemsToBeDeleted = promotionEntityMap
						.get(promoCompDisplayId);
				if (Dockyard.isSpaceOrNull(prodOfferItemsToBeDeleted)) {
					prodOfferItemsToBeDeleted = (PromotionEntity) repository
							.getGenericObject(
									PriceConstants.PROMOTION_DOC_KEY_PREFIX
											+ promoCompDisplayId
											+ "_"
											+ promoMsgForZoneId,
									PromotionEntity.class);
				}
				if (!Dockyard.isSpaceOrNull(prodOfferItemsToBeDeleted)) {
					List<PromoItemListEntity> existingPromoItemList = prodOfferItemsToBeDeleted
							.getPromoItemListEntities();
					for (PromoItemListEntity existingPromoItem : existingPromoItemList) {
						if (PriceConstants.PROMO_ITEM_LIST_BUY_TYPE
								.equals(existingPromoItem.getListType())
								|| (PriceConstants.PROMO_ITEM_LIST_GET_TYPE
										.equals(existingPromoItem.getListType()) && (existingPromoItem
										.getPromoItems() != null))) {
							for (int i = 0; i < existingPromoItem
									.getPromoItems().size(); i++) {
								String itemToDelete = existingPromoItem
										.getPromoItems().get(i).getItemRef();
								effectiveDate = promotionWriter
										.deleteProdOfferDoc(itemToDelete,
												promoMsgForZoneId,
												promoCompDisplayId);
								promotionEffectiveDateMap.put(
										promoCompDisplayId, effectiveDate);
							}
						}
					}

				}

				/**
				 * Delete the promotion document eg:PROMOTION_123_z5
				 */
				repository
						.deleteProduct(PriceConstants.PROMOTION_DOC_KEY_PREFIX
								+ promoCompDisplayId + "_" + promoMsgForZoneId);
				PROMOMSGCOUNTER
						.updateCounterForModMsg(DELETE_PROMOTION_DOCUMENT);

				/**
				 * Delete the details from master document eg: PROMOTION_123
				 */
				promotionEventDataMap = promotionWriter
						.deleteZoneInMasterDocument(promoCompDisplayId,
								promoMsgForZoneId.substring(0, 1),
								promoMsgForZoneId.substring(1), repository);

				for (String eventType : promotionEventDataMap.keySet()) {
					if (eventType.equals(PROMOTION_DELETED_EVENT_TYPE)
							|| eventType
									.equals(PROMOTION_LOCATION_REMOVED_EVENT_TYPE)) {
						Map<String, String> promotionEventData = (Map<String, String>) promotionEventDataMap
								.get(eventType);
						promotionEventData.put(promoCompDisplayId,
								promotionEffectiveDateMap
										.get(promoCompDisplayId));
					}
				}

				LOGGER.info(
						"Promotion document deleted successfully for offer Display Id {} and Zone {}",
						promoCompDisplayId, promoMsgForZoneId);

				/**
				 * Delete the mapping lookup document between comp_display_id
				 * and comp_detail_id document eg:PROMO_COMP_DETAIL_ID_456
				 */

				promotionWriter.deleteMultiBuyLookup(promoCompDisplayId,
						promoCompDetailId, repository);
			}
		} catch (DataAccessException e) {
			throw new PromoBusinessException(e);
		}
		return promotionEventDataMap;
	}

	@Override
	public Map<String, Object> processModMessage(
			PromotionEntity promotionEntity, List<PrmPrcChgDtl> prmPrcChgDtl,
			String promoMsgForZoneId, String msgState, String msgOfferType,
			String promoMsgLocType) throws PromoBusinessException {
		LOGGER.info("In MultiBuy All MOD cases is handled as CRE because always its a full refersh.");
		return null;
	}

	private String getCurrencyForLoc(String zoneId) throws DataAccessException {
		String currency = null;
		ZoneEntity zoneEntity = (ZoneEntity) repository
				.getGenericObject(PriceConstants.ZONE_ENTITY_KEY + zoneId,
						ZoneEntity.class);
		if (zoneEntity != null) {
			currency = zoneEntity.getCurrencyCode();
		}
		return currency;
	}

	private String getDate(String year, String month, String day, String hrs,
			String mins, String secs) {
		String parsedDay = day.length() == 1 ? "0" + day : day;
		String parsedMonth = month.length() == 1 ? "0" + month : month;
		String parsedHrs = hrs.length() == 1 ? "0" + hrs : hrs;
		String parsedMins = mins.length() == 1 ? "0" + mins : mins;
		String parsedSecs = secs.length() == 1 ? "0" + secs : secs;

		String date = year + parsedMonth + parsedDay + parsedHrs + parsedMins
				+ parsedSecs;
		try {
			date = Dockyard.getFormattedDate(date,
					PriceConstants.PROMO_MSG_DATE_FORMAT,
					PriceConstants.ISO_8601_FORMAT);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date;
	}

	private String getChangeType(int changeType) {

		switch (changeType) {
		case 0:
			return "P";
		case 8:
			return "P";
		case 1:
			return "A";
		case 2:
			return "F";
		case 5:
			return "C";
		case 6:
			return "V";
		default:
			return null;
		}
	}

	private void mapPromoCompDisplayIdToPromoCompDtlId(
			String promoCompDisplayId, String promoCompDtlId)
			throws PromoBusinessException {
		try {
			repository.insertObject(PriceConstants.PROMO_DETAIL_ID_KEY
					+ promoCompDtlId, promoCompDisplayId);
			PROMOMSGCOUNTER.updateCounterForCreMsg(PROMOTION_LOOKUP_DOCUMENT);
		} catch (Exception e) {
			LOGGER.error("Look up document couldn't be inserted for multibuy promotion due to DB error for detailId: "
					+ promoCompDtlId);
			throw new PromoBusinessException(e.getMessage(), e);
		}

	}

	private int[] setThrRewardRefs(int size) {
		int[] refs = new int[PriceConstants.MULTIBUY_ARRAY_SIZE];
		refs[0] = size;
		return refs;
	}

	private List<String> getBuyGetListForMultiBuyPromotion(
			PromotionEntity promotionEntity) {
		/* Get The BUY anf GET List For Existing Offer For MOD Cases */
		List<String> itemsList = new ArrayList<String>();
		if (promotionEntity != null) {
			List<PromoItemListEntity> existingPromoItemList = promotionEntity
					.getPromoItemListEntities();
			for (PromoItemListEntity existingPromoItem : existingPromoItemList) {
				if (PriceConstants.PROMO_ITEM_LIST_BUY_TYPE
						.equals(existingPromoItem.getListType())
						|| (PriceConstants.PROMO_ITEM_LIST_GET_TYPE
								.equals(existingPromoItem.getListType()) && (existingPromoItem
								.getPromoItems() != null))) {
					for (int i = 0; i < existingPromoItem.getPromoItems()
							.size(); i++) {
						itemsList.add(existingPromoItem.getPromoItems().get(i)
								.getItemRef());
					}
				}
			}
		}
		return itemsList;
	}

	private List<String> getDeletedItems(List<String> previousBuyGetList,
			List<String> modifiedBuyGetList) {
		List<String> deletedItems = new ArrayList<String>();
		for (String existingPromoItem : previousBuyGetList) {
			if (!modifiedBuyGetList.contains(existingPromoItem)) {
				deletedItems.add(existingPromoItem);
			}
		}
		return deletedItems;
	}

	private String verifyPromotionOrLocationExist(
			PromotionEntity promotionEntity) throws PromoBusinessException {

		String offerId = promotionEntity.getOfferRef();
		String locRef = promotionEntity.getLocRef();
		String locType = promotionEntity.getLocType();
		PromotionMasterEntity masterDoc = null;
		PromotionEntity existingPromotionEntity = null;
		String eventType = null;
		try {
			masterDoc = (PromotionMasterEntity) repository
					.getGenericObject(PROMOTION_DOC_KEY_PREFIX + offerId,
							PromotionMasterEntity.class);

			existingPromotionEntity = (PromotionEntity) repository
					.getGenericObject(PROMOTION_DOC_KEY_PREFIX + offerId + "_"
							+ locType + locRef, PromotionEntity.class);

		} catch (DataAccessException e) {
			throw new PromoBusinessException(e);
		}

		if (masterDoc == null) {
			eventType = PROMOTION_MSG_TYPE_CRE;

		} else if (existingPromotionEntity == null) {
			eventType = PROMO_LOC_ADDED;
		}
		return eventType;

	}

}
