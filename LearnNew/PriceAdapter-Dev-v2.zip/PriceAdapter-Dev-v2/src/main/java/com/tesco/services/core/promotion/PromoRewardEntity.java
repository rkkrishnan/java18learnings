package com.tesco.services.core.promotion;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by iv16 on 5/5/2015.
 */
public class PromoRewardEntity implements Serializable {
    @JsonProperty("@type")
    public String type;

    @JsonProperty("changeType")
    public String changeType;

    @JsonProperty("changeQty")
    public int changeQty;

    @JsonProperty("changeAmount")
    public double changeAmount;

    @JsonProperty("changeCurrency")
    public String changeCurrency;

    @JsonProperty("changePercent")
    public double changePercent;

    @JsonProperty("changeUom")
    public String changeUom;

    @JsonProperty("voucherNumber")
    public String voucherNumber;

    @JsonProperty("voucherDescription")
    public String voucherDescription;

    public String getChangeType() {
        return changeType;
    }

@Override
    public String toString() {
        return "PromoRewardEntity{" +
                "type='" + type + '\'' +
                ", changeType='" + changeType + '\'' +
                ", changeQty='" + changeQty + '\'' +
                ", changeAmount=" + changeAmount +
                ", changeCurrency='" + changeCurrency + '\'' +
                ", changePercent=" + changePercent +
                ", changeUom='" + changeUom + '\'' +
                ", voucherNumber='" + voucherNumber + '\'' +
                ", voucherDescription='" + voucherDescription + '\'' +
                '}';
    }

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(changeAmount);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((changeCurrency == null) ? 0 : changeCurrency.hashCode());
		temp = Double.doubleToLongBits(changePercent);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + changeQty;
		result = prime * result + ((changeType == null) ? 0 : changeType.hashCode());
		result = prime * result + ((changeUom == null) ? 0 : changeUom.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		result = prime * result + ((voucherDescription == null) ? 0 : voucherDescription.hashCode());
		result = prime * result + ((voucherNumber == null) ? 0 : voucherNumber.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PromoRewardEntity other = (PromoRewardEntity) obj;
		if (Double.doubleToLongBits(changeAmount) != Double.doubleToLongBits(other.changeAmount))
			return false;
		if (changeCurrency == null) {
			if (other.changeCurrency != null)
				return false;
		} else if (!changeCurrency.equals(other.changeCurrency))
			return false;
		if (Double.doubleToLongBits(changePercent) != Double.doubleToLongBits(other.changePercent))
			return false;
		if (changeQty != other.changeQty)
			return false;
		if (changeType == null) {
			if (other.changeType != null)
				return false;
		} else if (!changeType.equals(other.changeType))
			return false;
		if (changeUom == null) {
			if (other.changeUom != null)
				return false;
		} else if (!changeUom.equals(other.changeUom))
			return false;
		if (type == null) {
			if (other.type != null)
				return false;
		} else if (!type.equals(other.type))
			return false;
		if (voucherDescription == null) {
			if (other.voucherDescription != null)
				return false;
		} else if (!voucherDescription.equals(other.voucherDescription))
			return false;
		if (voucherNumber == null) {
			if (other.voucherNumber != null)
				return false;
		} else if (!voucherNumber.equals(other.voucherNumber))
			return false;
		return true;
	}

}
