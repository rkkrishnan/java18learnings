package com.tesco.services.core.price;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PriceByDateTime {

	@JsonProperty("priceRef")
	private String priceRef;

	@JsonProperty("effvDateTime")
	private String effvDateTime;

	@JsonProperty("changeType")
	private String changeType;

	@JsonProperty("changeAmount")
	private double changeAmount;

	@JsonProperty("regPrice")
	private double regPrice;

	@JsonProperty("state")
	private String state;

	@JsonProperty("createdDate")
	private String createdDate;

	@JsonProperty("createdById")
	private String createdById;

	@JsonProperty("lastUpdateDate")
	private String lastUpdateDate;

	@JsonProperty("priceRef")
	public String getPriceRef() {
		return priceRef;
	}

	@JsonProperty("priceRef")
	public void setPriceRef(String priceRef) {
		this.priceRef = priceRef;
	}

	@JsonProperty("effvDateTime")
	public String getEffvDateTime() {
		return effvDateTime;
	}

	@JsonProperty("effvDateTime")
	public void setEffvDateTime(String effvDateTime) {
		this.effvDateTime = effvDateTime;
	}

	@JsonProperty("changeType")
	public String getChangeType() {
		return changeType;
	}

	@JsonProperty("changeType")
	public void setChangeType(String changeType) {
		this.changeType = changeType;
	}

	@JsonProperty("changeAmount")
	public double getChangeAmount() {
		return changeAmount;
	}

	@JsonProperty("changeAmount")
	public void setChangeAmount(double changeAmount) {
		this.changeAmount = changeAmount;
	}

	@JsonProperty("regPrice")
	public double getRegPrice() {
		return regPrice;
	}

	@JsonProperty("regPrice")
	public void setRegPrice(double regPrice) {
		this.regPrice = regPrice;
	}

	@JsonProperty("state")
	public String getState() {
		return state;
	}

	@JsonProperty("state")
	public void setState(String state) {
		this.state = state;
	}

	@JsonProperty("createdDate")
	public String getCreatedDate() {
		return createdDate;
	}

	@JsonProperty("createdDate")
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	@JsonProperty("createdById")
	public String getCreatedById() {
		return createdById;
	}

	@JsonProperty("createdById")
	public void setCreatedById(String createdById) {
		this.createdById = createdById;
	}

	@JsonProperty("lastUpdateDate")
	public String getLastUpdateDate() {
		return lastUpdateDate;
	}

	@JsonProperty("lastUpdateDate")
	public void setLastUpdateDate(String lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	@Override public String toString() {
		return "PriceByDateTime{" +
				"priceRef='" + priceRef + '\'' +
				", effvDateTime='" + effvDateTime + '\'' +
				", changeType='" + changeType + '\'' +
				", changeAmount=" + changeAmount +
				", regPrice=" + regPrice +
				", state='" + state + '\'' +
				", createdDate='" + createdDate + '\'' +
				", createdById='" + createdById + '\'' +
				", lastUpdateDate='" + lastUpdateDate + '\'' +
				'}';
	}
}
