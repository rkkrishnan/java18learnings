package com.tesco.services.adapters.core.utils;

import com.codahale.metrics.Counter;
import com.codahale.metrics.JmxReporter;
import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.Timer;
import com.codahale.metrics.Timer.Context;

import java.util.HashMap;

/**
 * Created by QP65 on 10/9/2015.
 */
public class PriceMetrics {

	static PriceMetrics priceMetrics;

	private static MetricRegistry metricRegisty;

	private static Timer priceMessagesCre;

	Context priceMessagesCreTC;
	private static Timer priceMessagesDel;

	Context priceMessagesDelTC;
	private static Timer messageListenerTimer;

	Context messageTimerContext;
	private static Counter errorCounter;

	private PriceMetrics(MetricRegistry myMetricRegisty) {
		this.metricRegisty = myMetricRegisty;
	}

	public static synchronized PriceMetrics getInstance() {
		if (priceMetrics == null) {
			metricRegisty = new MetricRegistry();
			priceMetrics = new PriceMetrics(metricRegisty);
			JmxReporter.forRegistry(metricRegisty).build();
			initMetrics();
		}
		return priceMetrics;
	}

	public static MetricRegistry getMetricRegisty() {
		return metricRegisty;
	}

	public void incrementErrorCount() {
		errorCounter.inc();
	}

	private static void initMetrics() {
		priceMessagesCre = metricRegisty.timer(MetricRegistry.name("com.tesco",
				"PriceElapsedTimeAndRate", "time-to-process-cre-message"));

		priceMessagesDel = metricRegisty.timer(MetricRegistry.name("com.tesco",
				"PriceElapsedTimeAndRate", "time-to-process-del-message"));

		messageListenerTimer = metricRegisty.timer(MetricRegistry.name(
				"com.tesco", "OverallPriceElapsedTimeAndRate",
				"time-to-process-message"));

		errorCounter = metricRegisty.counter(MetricRegistry.name("com.tesco",
				"PriceMessageProcessingErrors", "total-error-count"));
	}

	public void logCrePriceProcessingEndTime() {
		priceMessagesCreTC.stop();
	}

	public void logCrePriceProcessingStartTime() {
		priceMessagesCreTC = priceMessagesCre.time();
	}

	public void logDelPriceProcessingEndTime() {
		priceMessagesDelTC.stop();
	}

	public void logDelPriceProcessingStartTime() {
		priceMessagesDelTC = priceMessagesDel.time();
	}

	public void logMessageProcessingEndTime() {
		messageTimerContext.stop();
	}

	public void logMessageProcessingStartTime() {
		messageTimerContext = messageListenerTimer.time();
	}

	public void resetMetrics() {
		metricRegisty = new MetricRegistry();
		initMetrics();
	}
}
