package com.tesco.services.utility;

import static com.tesco.services.utility.PriceConstants.COLON_SEPARATOR;
import static com.tesco.services.utility.PriceConstants.EFFECTIVE_DATE;
import static com.tesco.services.utility.PriceConstants.EVENT_TYPE;
import static com.tesco.services.utility.PriceConstants.OFFER_ID;
import static com.tesco.services.utility.PriceConstants.PROMOTION_DELETED_EVENT_TYPE;
import static com.tesco.services.utility.PriceConstants.PROMOTION_LOCATION_REMOVED_EVENT_TYPE;
import static com.tesco.services.utility.PriceConstants.PROMO_PRODUCT_ADDED;
import static com.tesco.services.utility.PriceConstants.PROMO_PRODUCT_ITEM_LIST;
import static com.tesco.services.utility.PriceConstants.TPNB_IDENTIFIER;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tesco.services.adapters.core.utils.EventMetrics;
import com.tesco.services.core.promotion.PromoItemEntity;
import com.tesco.services.core.promotion.PromoItemListEntity;
import com.tesco.services.core.promotion.PromotionEntity;
import com.tesco.services.event.core.EventTemplate;
import com.tesco.services.event.core.impl.EventData;
import com.tesco.services.event.core.impl.MapEvent;
import com.tesco.services.event.exception.EventPublishException;
import com.tesco.services.exceptions.PromoBusinessException;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;

public class CommonEventPublishingUtility {

	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper.getLogger(CommonEventPublishingUtility.class);
	private static final EventMetrics EVENTMETRICS = EventMetrics.getInstance();
	
	public static MapEvent createPromoEventData(int leadDays, String locationId, String eventType,
			String promotionId) {

		Map<String, String> headerMap = new HashMap<String, String>();
		Map<String, Object> payloadMap = new HashMap<String, Object>();

		String leadTimeDays = String.valueOf(leadDays);
		headerMap.put(PriceConstants.LOCATION_ID, locationId);
		LOGGER.info(PriceConstants.LOCATION_ID + ":" + locationId);

		headerMap.put(PriceConstants.LEAD_TIME_DAYS, leadTimeDays);
		LOGGER.info(PriceConstants.LEAD_TIME_DAYS + ":" + leadTimeDays);

		headerMap.put(PriceConstants.EVENT_TYPE, eventType);
		headerMap.put(PriceConstants.EVENT_CORR_ID, "EVENT_" + promotionId);

		payloadMap.put(PriceConstants.OFFER_ID, promotionId);

		LOGGER.info("MsgType:::" + eventType);

		MapEvent event = new MapEvent();
		
		LOGGER.info("Setting header and payload data for event messages");
		event.setHeaderData(headerMap);
		event.setPayloadData(payloadMap);

		return event;
	}

	
	
	public static MapEvent createPriceEventData(String eventType,String locationId, int leadDays,String priceChangeID ,String tpnc, String effectiveDate,String key){
		
		MapEvent event = new MapEvent();
		
		String leadTimedays = String.valueOf(leadDays);
		Map<String, Object> payloadMap = new HashMap<String, Object>();
		HashMap<String, String> headerMap = new HashMap<String, String>();

		headerMap.put(PriceConstants.EVENT_CORR_ID, "EVENT_" + key);
		headerMap.put(PriceConstants.LOCATION_ID, locationId);
		headerMap.put(PriceConstants.EVENT_TYPE, eventType);
		headerMap.put(PriceConstants.LEAD_TIME_DAYS, leadTimedays);

		payloadMap.put(PriceConstants.PRICE_REF, priceChangeID);
		payloadMap.put(PriceConstants.PRODUCT_REF, "tpnc:" + tpnc);
		payloadMap.put(PriceConstants.EVENT_EFFECTIVE_DATE, effectiveDate);
		event.setHeaderData(headerMap);
		event.setPayloadData(payloadMap);
		LOGGER.info("Setting header and payload data for Price Event messages:: "+event.toString());
		return event;
	}
	

	public static MapEvent createZoneEventData(String eventType,String countryCode,String zoneId){
		MapEvent event = new MapEvent();
		Map<String, String> headerMap = new HashMap<String, String>();
		Map<String, Object> payloadMap = new HashMap<String, Object>();		
		headerMap.put(PriceConstants.LOCATION_ID, countryCode+":"+PriceConstants.ZONE_PREFIX+":"+zoneId);
		headerMap.put(PriceConstants.LEAD_TIME_DAYS, PriceConstants.ZONE_CRE_EVNT_LTD); // LeadTime Days is always 1 for zone deletion
		headerMap.put(PriceConstants.EVENT_TYPE, eventType);
		headerMap.put(PriceConstants.EVENT_CORR_ID, PriceConstants.EVENT_PREFIX +zoneId);
		Map<String,String> jsonComplex = new HashMap<>();
		jsonComplex.put(PriceConstants.LOC_TYPE, PriceConstants.ZONE_PREFIX);
		jsonComplex.put(PriceConstants.LOC_REF, zoneId);
		payloadMap.put(PriceConstants.PRICING_LOC,jsonComplex);
		event.setHeaderData(headerMap);
		event.setPayloadData(payloadMap);
		return event;
	}
	
	
	public static MapEvent storeZoneEventData(String eventType,String countryCode,String storeId,String zoneId){
		
		
		Map<String, String> headerMap = new HashMap<String, String>();
		Map<String, Object> payloadMap = new HashMap<String, Object>();

		
		headerMap.put(PriceConstants.LOCATION_ID,
				countryCode + ":" + PriceConstants.STORE_PREFIX
				+ ":" + storeId);
		headerMap.put(PriceConstants.LEAD_TIME_DAYS,
				PriceConstants.ZONE_CRE_EVNT_LTD); // LeadTime Days is always 1 for StoreZone change
		headerMap.put(PriceConstants.EVENT_TYPE,
				PriceConstants.STORE_ZONE_CHANGE);
		headerMap.put(PriceConstants.EVENT_CORR_ID,
				PriceConstants.EVENT_PREFIX + storeId);
		Map<String,String> jsonComplex = new HashMap<>();
		jsonComplex.put(PriceConstants.LOC_TYPE, PriceConstants.STORE_PREFIX);
		jsonComplex.put(PriceConstants.LOC_REF, storeId);
		payloadMap.put(PriceConstants.PRICING_LOC,jsonComplex);
		MapEvent event = new MapEvent();
		event.setEventType(eventType);
		event.setHeaderData(headerMap);
		event.setPayloadData(payloadMap);

		return event;
	}
	
	/*
	 * This method with publish the event for the event data object
	 * (non-Javadoc)
	 * @see com.tesco.services.adapters.rpm.events.ClearanceEventHandler#
	 * publishClearanceEvent(com.tesco.event.core.impl.EventData)
	 */
	public static String publishEvent(EventTemplate eventTemplate, EventData<?> data) throws EventPublishException {
		LOGGER.info("START PUBLISHING EVENT");
		String messageId = null;
		try {
			EVENTMETRICS.logEventStartTime(data.getEventType());
			messageId = eventTemplate.publishEvent(data);
			EVENTMETRICS.logEventEndTime(data.getEventType());
		} catch (EventPublishException e) {
			EVENTMETRICS.logEventEndTime(data.getEventType());
			EVENTMETRICS.incrementErrorCounter(data.getEventType());
			LOGGER.error("Error in Event Publish", e);
			throw e;
		}
		//logOutputJSON(data);
		LOGGER.info("******END PUBLISHING EVENT*******");
		return messageId;
	}

	/**
	 * This method logs the event data as JSON string in the log
	 * @param data
	 */
	private static void logOutputJSON(EventData<?> data) {
		ObjectMapper mapper = new ObjectMapper();
		String jsonInString;
		try {
			jsonInString = mapper.writeValueAsString(data);
			LOGGER.info("EventDataJSON:" + jsonInString);
		} catch (JsonProcessingException e1) {
			LOGGER.error("Error in JSON writting", e1);
		}
	}


	/**
	 * @param prdId
	 * @param leadTimedays
	 * @param country
	 * @param locations
	 * @param key
	 * @param eventType
	 * @return
	 */
	public static MapEvent createClearanceEventData(String prdId, String leadTimedays, String country,
			List<Map<String,Object>> locations,String key, String eventType) {
		MapEvent data = new MapEvent();
		data.setEventType(eventType);
		// set header data
		data.setHeaderData(createClearanceEventDataHeader(leadTimedays, country, key, eventType));
		// set payload data
		data.setPayloadData(createClearanceEventDataPayload(prdId, locations));
		return data;
	}


	/**
	 * @param prdId
	 * @param locations
	 * @return
	 */
	private static HashMap<String, Object> createClearanceEventDataPayload(String prdId, List<Map<String,Object>> locations
			) {
		HashMap<String, Object> payloadMap = new HashMap<>();
		payloadMap.put(PriceConstants.PRODUCT_REF, prdId);
		payloadMap.put(PriceConstants.CLEARANCES, locations);
		return payloadMap;
	}

	/**
	 * @param leadTimedays
	 * @param country
	 * @param key
	 * @param eventType
	 * @param data
	 */
	private static HashMap<String, String> createClearanceEventDataHeader(String leadTimedays, String country,
			String key, String eventType) {
		HashMap<String, String> headerMap = new HashMap<>();
		headerMap.put(PriceConstants.EVENT_CORR_ID, PriceConstants.EVENT_CORR_ID_PREFIX + key);
		headerMap.put(PriceConstants.COUNTRY, country);
		headerMap.put(PriceConstants.EVENT_TYPE, eventType);
		headerMap.put(PriceConstants.LEAD_TIME_DAYS, leadTimedays);
		return headerMap;
	}
	
	public static void addOnlyLeastEffectiveDate(Map<String, DateTime> leastEffectiveDateMap, String effectiveDate,
			String offerId) {
		DateTime currentEffectiveDate = new DateTime(effectiveDate);			
		if(leastEffectiveDateMap.get(offerId) != null){
			DateTime existingEffDate = leastEffectiveDateMap.get(offerId);
			if(currentEffectiveDate.compareTo(existingEffDate) < 0){
				leastEffectiveDateMap.put(offerId, currentEffectiveDate);
			}
		}else{
			leastEffectiveDateMap.put(offerId, currentEffectiveDate);
		}
	}
	
	public static Map<String, Object> preparePromoDetailsChangedOffLevelArgumentData(PromotionEntity existingPromotionEntity,
			Map<String, DateTime> leastEffectiveDateMap, String offerId, PromotionEntity modifiedPromotionEntity) {
		Map<String, Object> argumentData = new HashMap<>();
		argumentData.put("existingPromotionThresholdEntities",
				existingPromotionEntity.getPromoThresholdEntities());
		argumentData.put("modifiedPromotionThresholdEntities", modifiedPromotionEntity.getPromoThresholdEntities());
		argumentData.put("existingPromoRewardEntities", existingPromotionEntity.getPromoRewardEntities());
		argumentData.put("modifiedPromoRewardsEntities", modifiedPromotionEntity.getPromoRewardEntities());
		argumentData.put("offerId", offerId);
		argumentData.put("offLeveleffectiveDateMap", leastEffectiveDateMap);
		return argumentData;
	}
	
	public static Map<Object, Object> preparePromoDetailsChangedProductLevelArgumentData(
			PromotionEntity existingPromotionEntity, String offerId, PromotionEntity modifiedPromotionEntity) {
		Map<Object, Object> argumentData = new HashMap<>();
		List<PromoItemEntity> modifiedPromoItemEntities = modifiedPromotionEntity.getPromoItemListEntities().get(0)
				.getPromoItems();
		List<PromoItemEntity> existingPromoItemEntities = existingPromotionEntity.getPromoItemListEntities().get(0)
				.getPromoItems();
		argumentData.put("existingPromoItemEntities", existingPromoItemEntities);
		argumentData.put("modifiedPromoItemEntities", modifiedPromoItemEntities);
		argumentData.put("offerId", offerId);
		return argumentData;
	}

	public static Map<String, Object> preparePromotionCreatedEventDataMap(PromotionEntity promotionEntity,
			String eventType, Map<String, String> newProductData) {

		String effectiveDate = promotionEntity.promoItemListEntities.get(0).getPromoItems().get(0).getEffectiveDate();
		Map<String, Object> promotionEventDataMap = new HashMap<>();

		promotionEventDataMap.put(EVENT_TYPE, eventType);
		promotionEventDataMap.put(EFFECTIVE_DATE, effectiveDate);
		promotionEventDataMap.put(OFFER_ID, promotionEntity.getOfferRef());

		if (eventType == null && newProductData.isEmpty() != true) {
			promotionEventDataMap.put(EVENT_TYPE, PROMO_PRODUCT_ADDED);
			promotionEventDataMap.put(PROMO_PRODUCT_ITEM_LIST, newProductData);

		}
		return promotionEventDataMap;

	}
	
	public static void preparePromoProductRemvoedArgumentDataForEmptyItemList(Map<String, Object> promotionEventDataMap,
			Map<String, String> promotionEffectiveDateMap, String offerId) {
		for(String eventType : promotionEventDataMap.keySet()){
			if(eventType.equals(PROMOTION_DELETED_EVENT_TYPE)|| 
					eventType.equals(PROMOTION_LOCATION_REMOVED_EVENT_TYPE)){
				Map<String,String> promotionEventData = (Map<String,String>)promotionEventDataMap.get(eventType);
				promotionEventData.put(offerId, promotionEffectiveDateMap.get(offerId));
			}
		}
	}

	public static Map<String, Object> preparePromoProductRemvoedArgumentData(
			List<PromoItemEntity> listOfDeletedPromotionItemEntities, String offerId, PromotionEntity pE) {
		String effectiveDate;
		Map<String, Object> promotionDataMap = new HashMap<>();
		effectiveDate = pE.getPromoItemListEntities().get(0).getPromoItems().get(0).getEffectiveDate();
		for (PromoItemEntity promoItemEntity : listOfDeletedPromotionItemEntities) {
			List<String> effectiveDateList = (List<String>)promotionDataMap.get(offerId);
			if(effectiveDateList==null){
				effectiveDateList = new ArrayList<String>();
			}
			effectiveDateList.add(effectiveDate+"|"+TPNB_IDENTIFIER + COLON_SEPARATOR + promoItemEntity.getItemRef());
			promotionDataMap.put(offerId,effectiveDateList);
		}
		return promotionDataMap;
	}
	
	public static Map<String, Object> getEndDateChangedMapDataPerItem(List<String> items,
			PromotionEntity promotionEntity) throws PromoBusinessException {
		Map<String, String> promotionEventMapData = new HashMap<>();
		Map<String, Object> promotionEndDateEventMapData = new HashMap<>();
		try {
			for (PromoItemListEntity promoItemListEntity : promotionEntity.getPromoItemListEntities()) {
				if (promoItemListEntity.getPromoItems() != null) {
					for (PromoItemEntity promoItemEntity : promoItemListEntity.getPromoItems()) {
						if (items.contains(promoItemEntity.getItemRef())) {
							promotionEventMapData.put(promoItemEntity.getItemRef(), promoItemEntity.getEndDate());
						}
					}

				}
			}
			promotionEndDateEventMapData.put(promotionEntity.getOfferRef(), promotionEventMapData);

		} catch (Exception e) {
			throw new PromoBusinessException(e);
		}

		return promotionEndDateEventMapData;

	}
}
