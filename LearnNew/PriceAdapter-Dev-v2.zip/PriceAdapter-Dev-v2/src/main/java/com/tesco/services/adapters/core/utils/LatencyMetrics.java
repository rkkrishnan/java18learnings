package com.tesco.services.adapters.core.utils;

import static com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility.ANY;
import static com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility.NONE;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@SuppressWarnings("serial")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonAutoDetect(fieldVisibility = ANY, getterVisibility = NONE, setterVisibility = NONE)
public class LatencyMetrics implements Serializable {

	@JsonProperty
	private String maxResponseTime;

	@JsonProperty
	private String minResponseTime;

	@JsonProperty
	private String meanResponseTime;

	@JsonProperty
	private String latencyUnit;

	public String getMaxResponseTime() {
		return maxResponseTime;
	}

	public void setMaxResponseTime(String maxResponseTime) {
		this.maxResponseTime = maxResponseTime;
	}

	public String getMinResponseTime() {
		return minResponseTime;
	}

	public void setMinResponseTime(String minResponseTime) {
		this.minResponseTime = minResponseTime;
	}

	public String getMeanResponseTime() {
		return meanResponseTime;
	}

	public void setMeanResponseTime(String meanResponseTime) {
		this.meanResponseTime = meanResponseTime;
	}

	public String getLatencyUnit() {
		return latencyUnit;
	}

	public void setLatencyUnit(String latencyUnit) {
		this.latencyUnit = latencyUnit;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((latencyUnit == null) ? 0 : latencyUnit.hashCode());
		result = prime * result
				+ ((maxResponseTime == null) ? 0 : maxResponseTime.hashCode());
		result = prime
				* result
				+ ((meanResponseTime == null) ? 0 : meanResponseTime.hashCode());
		result = prime * result
				+ ((minResponseTime == null) ? 0 : minResponseTime.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LatencyMetrics other = (LatencyMetrics) obj;
		if (latencyUnit == null) {
			if (other.latencyUnit != null)
				return false;
		} else if (!latencyUnit.equals(other.latencyUnit))
			return false;
		if (maxResponseTime == null) {
			if (other.maxResponseTime != null)
				return false;
		} else if (!maxResponseTime.equals(other.maxResponseTime))
			return false;
		if (meanResponseTime == null) {
			if (other.meanResponseTime != null)
				return false;
		} else if (!meanResponseTime.equals(other.meanResponseTime))
			return false;
		if (minResponseTime == null) {
			if (other.minResponseTime != null)
				return false;
		} else if (!minResponseTime.equals(other.minResponseTime))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "LatencyMetrics [maxResponseTime=" + maxResponseTime
				+ ", minResponseTime=" + minResponseTime
				+ ", meanResponseTime=" + meanResponseTime + ", latencyUnit="
				+ latencyUnit + "]";
	}

}
