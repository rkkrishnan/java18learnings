package com.tesco.services.adapters.zone;

import java.util.Map;

import com.tesco.services.core.ZoneEntity;
import com.tesco.services.exceptions.ZoneBusinessException;
import com.tesco.zone.core.TSLZoneGroupDesc;
import com.tesco.zone.core.TSLZoneGroupRef;

/**
 * Created by qz88 on 05/10/2015.
 */
public interface ZoneHandler {

	public void processZoneGroupCre(TSLZoneGroupDesc tslZoneGroupDesc,
			String zoneMsgType) throws ZoneBusinessException;

	public void processZoneCre(TSLZoneGroupDesc tslZoneGroupDesc,
			String zoneMsgType) throws ZoneBusinessException;

	public void processZoneGroupMod(TSLZoneGroupDesc tslZoneGroupDesc,
			String zoneMsgType) throws ZoneBusinessException;

	public void processZoneGroupDel(TSLZoneGroupRef tslZoneGroupDesc,
			String zoneMsgType) throws ZoneBusinessException;

	public void processZoneMod(TSLZoneGroupDesc tslZoneGroupDesc,
			String zoneMsgType) throws ZoneBusinessException;

	public void processZoneLocationCre(TSLZoneGroupDesc tslZoneGroupDesc,
			String zoneMsgType) throws ZoneBusinessException;

	public void processZoneDel(TSLZoneGroupRef tslZoneGroupRef)
			throws ZoneBusinessException;

	public void processLocDel(TSLZoneGroupRef tslZoneGroupRef)
			throws ZoneBusinessException;

	public Map<String, ZoneEntity> getZoneIdCountryCodeMap(
			TSLZoneGroupRef tslZoneGroupRef) throws ZoneBusinessException;

	public Map<String, ZoneEntity> getZoneIdCountryCodeForTSLZoneGroup(
			TSLZoneGroupDesc tslZoneGroupDec) throws ZoneBusinessException;

}
