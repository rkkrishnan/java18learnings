package com.tesco.services.adapters.rpm.writers.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Optional;
import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.exceptions.ColumnNotFoundException;
import com.tesco.services.adapters.core.exceptions.WriterBusinessException;
import com.tesco.services.adapters.rpm.readers.PriceServiceCSVReader;
import com.tesco.services.adapters.rpm.readers.impl.PriceServiceCSVReaderImpl;
import com.tesco.services.adapters.rpm.writers.CSVHeaders;
import com.tesco.services.adapters.rpm.writers.Writer;
import com.tesco.services.core.Store;
import com.tesco.services.core.ZoneEntity;
import com.tesco.services.core.zone.ZoneGrpEntity;
import com.tesco.services.exceptions.DataAccessException;
import com.tesco.services.exceptions.ZoneBusinessException;
import com.tesco.services.repositories.Repository;
import com.tesco.services.repositories.RepositoryImpl;
import com.tesco.services.resources.ImportResource;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.PriceConstants;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import java.io.IOException;
import java.util.*;

public class RPMZoneWriter implements Writer {

	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger("RPM Zone Import");

	private Configuration configuration;
	private String runIdentifier;
	private Repository repository;
	private ObjectMapper objectMapper;

	private ZoneEntity zoneEntity = new ZoneEntity();

	private PriceServiceCSVReader rpmZoneReader;

	@Inject
	public RPMZoneWriter(@Named("configuration") Configuration configuration,
			@Named("jsonmapper") ObjectMapper objectMapper,
			@Named("repository") Repository repository) {
		this.configuration = configuration;
		this.objectMapper = objectMapper;
		this.repository = repository;
	}

	public RPMZoneWriter(Configuration configuration,
			ObjectMapper objectMapper, RepositoryImpl repository,
			PriceServiceCSVReader rpmZoneReader) {
		this(configuration, objectMapper, repository);
		this.rpmZoneReader = rpmZoneReader;
	}

	public String getRunIdentifier() {
		return runIdentifier;
	}

	public void setRunIdentifier(String runIdentifier) {
		this.runIdentifier = runIdentifier;
	}

	public PriceServiceCSVReader createRPMZoneReader(String fileName)
			throws WriterBusinessException {

		PriceServiceCSVReader csvreader = null;
		try {
			csvreader = new PriceServiceCSVReaderImpl(
					configuration.getRpmZoneDataDump() + "/" + runIdentifier
							+ "/" + fileName, CSVHeaders.RPMZoneHeaders.HEADERS);
		} catch (IOException | ColumnNotFoundException e) {
			LOGGER.error(
					"Error occured while initializing PriceServiceCSVReader ",
					e);
			throw new WriterBusinessException(e.getMessage(), e.getCause());
		}
		return csvreader;
	}

	public void write(String fileName) throws WriterBusinessException {
		LOGGER.info("Importing data for RPM Zone data from {} ",
				configuration.getRpmClrDataDumpPath());
		if (rpmZoneReader == null) {
			this.rpmZoneReader = createRPMZoneReader(fileName);
		}
		try {
			writeRPMZoneToCB();
		} catch (ArrayIndexOutOfBoundsException exception) {
			ImportResource.setErrorString(fileName,
					"Array index out of bound Exception");
			LOGGER.error("Error importing data", exception.getMessage());
		} catch (Exception e) {
			ImportResource.setErrorString(fileName, e.toString());
			LOGGER.error("Error importing data", e);
			throw new WriterBusinessException(e.getMessage(), e.getCause());
		} finally {
			ImportResource.getImportSemaphoreForIdentifier(fileName).release();
		}
	}

	private void writeRPMZoneToCB() throws IOException, DataAccessException,
			ZoneBusinessException {

		Map<String, String> rpmZoneInfoMap;
		int recordsInsertedCount = 0;
		int recordsRejectedCount = 0;
		int recordsTotalRead = 0;

		while ((rpmZoneInfoMap = rpmZoneReader.getNext()) != null) {
			recordsTotalRead++;

			String key = setZoneEntity(rpmZoneInfoMap);
			try {
				repository.insertObject(key, zoneEntity);
				recordsInsertedCount++;
				zoneEntity = new ZoneEntity();
				updateZoneGrpToCB(rpmZoneInfoMap);
			} catch (Exception e) {
				recordsRejectedCount++;
				LOGGER.error(
						"Error occurred when inserting document into couchbase for zone: "
								+ key, e);
			}
		}

		// Added for PRIS-2203
		LOGGER.info("Zone documents inserted : " + recordsInsertedCount);
		LOGGER.info("Zone documents rejected : " + recordsRejectedCount);
		LOGGER.info("Total Zone documents read : " + recordsTotalRead);
	}

	private void updateZoneGrpToCB(Map<String, String> rpmZoneInfoMap)
			throws IOException, DataAccessException, ZoneBusinessException {

		List<String> zoneIdsInZoneGrpDoc = new ArrayList<String>();
		try {
			String zoneGrpId = rpmZoneInfoMap
					.get(CSVHeaders.RPMZoneHeaders.ZONE_GROUP_ID);
			String zoneId = rpmZoneInfoMap
					.get(CSVHeaders.RPMZoneHeaders.ZONE_ID);

			ZoneGrpEntity zoneGrpDoc = (ZoneGrpEntity) repository
					.getGenericObject(PriceConstants.ZONE_GRP_KEY + zoneGrpId,
							ZoneGrpEntity.class);

			if (!Dockyard.isSpaceOrNull(zoneGrpDoc)) {
				zoneIdsInZoneGrpDoc = zoneGrpDoc.getZoneIds();
				if (zoneIdsInZoneGrpDoc.isEmpty()) {
					zoneIdsInZoneGrpDoc = new ArrayList<String>();
				}
				if (!zoneIdsInZoneGrpDoc.contains(zoneId)) {
					zoneIdsInZoneGrpDoc.add(zoneId);
				}
				zoneGrpDoc.setZoneIds(zoneIdsInZoneGrpDoc);
				repository.insertObject(PriceConstants.ZONE_GRP_KEY
						+ zoneGrpId, zoneGrpDoc);
			} else {
				throw new ZoneBusinessException(
						"Error while updating zone group document");
			}
		} catch (Exception e) {
			throw new ZoneBusinessException(e.getMessage(), e);
		}
	}

	public String setZoneEntity(Map<String, String> rpmZoneInfoMap) {

		String date = Dockyard.getSysDate(PriceConstants.ISO_8601_FORMAT);
		String zoneId = PriceConstants.ZONE_KEY
				+ rpmZoneInfoMap.get(CSVHeaders.RPMZoneHeaders.ZONE_ID);
		String storeId = rpmZoneInfoMap
				.get(CSVHeaders.RPMZoneHeaders.STORE_IDS);

		StringTokenizer st = new StringTokenizer(storeId, "|");
		List<String> storeIds = new ArrayList<String>();
		while (st.hasMoreElements()) {
			storeIds.add(st.nextElement().toString());
		}

		if (PriceConstants.TSL_COUNTRY_GB.equals(rpmZoneInfoMap
				.get(CSVHeaders.RPMZoneHeaders.TSL_COUNTRY_CODE))) {
			zoneEntity.setOfferPrefix(PriceConstants.OFFER_PREFIX_UK);
		} else if (PriceConstants.TSL_COUNTRY_IE.equals(rpmZoneInfoMap
				.get(CSVHeaders.RPMZoneHeaders.TSL_COUNTRY_CODE))) {
			zoneEntity.setOfferPrefix(PriceConstants.OFFER_PREFIX_ROI);
		}

		zoneEntity.setZoneGroupId(rpmZoneInfoMap
				.get(CSVHeaders.RPMZoneHeaders.ZONE_GROUP_ID));
		zoneEntity.setZoneGroupName(rpmZoneInfoMap
				.get(CSVHeaders.RPMZoneHeaders.ZONE_GROUP_NAME));
		zoneEntity.setZoneGroupType(rpmZoneInfoMap
				.get(CSVHeaders.RPMZoneHeaders.ZONE_GROUP_TYPE));
		zoneEntity.setZoneId(rpmZoneInfoMap
				.get(CSVHeaders.RPMZoneHeaders.ZONE_ID));
		zoneEntity.setZoneName(rpmZoneInfoMap
				.get(CSVHeaders.RPMZoneHeaders.ZONE_NAME));
		zoneEntity.setBaseInd(rpmZoneInfoMap
				.get(CSVHeaders.RPMZoneHeaders.BASE_IND));
		zoneEntity.setCurrencyCode(rpmZoneInfoMap
				.get(CSVHeaders.RPMZoneHeaders.CURRENCY_CODE));
		zoneEntity.setTslCountryCode(rpmZoneInfoMap
				.get(CSVHeaders.RPMZoneHeaders.TSL_COUNTRY_CODE));
		zoneEntity.setCreatedDate(date);
		zoneEntity.setCreatedById(PriceConstants.ONETIME_ZONE_CREATED_BY);
		zoneEntity.setLastUpdateDate(date);
		zoneEntity.setStoreIds(storeIds);

		/**
		 * Set store entity for onetime files
		 */
		setStoreEntity(storeIds, Integer.parseInt(rpmZoneInfoMap
				.get(CSVHeaders.RPMZoneHeaders.ZONE_ID)),
				rpmZoneInfoMap.get(CSVHeaders.RPMZoneHeaders.ZONE_GROUP_TYPE),
				rpmZoneInfoMap.get(CSVHeaders.RPMZoneHeaders.CURRENCY_CODE),
				rpmZoneInfoMap.get(CSVHeaders.RPMZoneHeaders.TSL_COUNTRY_CODE));

		return zoneId;
	}

	public void setStoreEntity(List<String> storeIds, Integer zoneId,
			String zoneGrpType, String currency, String countryId) {

		Map<String, Object> storeMap = new HashMap<>();
		List<String> storeKeys = new ArrayList<>();

		for (String storeKey : storeIds) {
			storeKeys.add(PriceConstants.STORE_KEY + storeKey);
		}

		storeMap = repository.getBulk(storeKeys);
		Store storeEntity;

		for (String storeId : storeIds) {
			try {
				storeEntity = deserializeJSON(
						storeMap.get(PriceConstants.STORE_KEY + storeId),
						Store.class);

				if (storeEntity == null) {
					storeEntity = new Store();

					storeEntity.setStoreId(storeId);
					storeEntity.setPriceZoneId(Optional.<Integer> absent());
					storeEntity.setPromoZoneId(Optional.<Integer> absent());
					storeEntity.setClearanceZoneId(Optional.<Integer> absent());
				}

				storeEntity.setCurrency(currency);
				storeEntity.setCountryId(countryId);

				if (PriceConstants.PRICE_ZONE_TYPE.equals(zoneGrpType)) {
					storeEntity.setPriceZoneId(Optional.of(zoneId));
				} else if (PriceConstants.PROMO_ZONE_TYPE.equals(zoneGrpType)) {
					storeEntity.setPromoZoneId(Optional.of(zoneId));
				} else if (PriceConstants.CLEARANCE_ZONE_TYPE
						.equals(zoneGrpType)) {
					storeEntity.setClearanceZoneId(Optional.of(zoneId));
				}
				try {
					repository.insertObject(PriceConstants.STORE_KEY
							+ storeId, storeEntity); // Changed for PRIS-2203
				} catch (Exception e) {
					LOGGER.error(
							"Error occurred when inserting document into couchbase for store: "
									+ storeId, e);
				}

			} catch (IOException e) {
				LOGGER.error(
						"Exception while processing bulk request from CB : {}",
						e.getMessage());
			}
		}

	}

	private <M> M deserializeJSON(Object json, Class<M> clazz)
			throws IOException {
		return json != null ? objectMapper.readValue(json.toString(), clazz)
				: null;
	}

	public void setZoneEntity(ZoneEntity zoneEntity) {
		this.zoneEntity = zoneEntity;
	}
}
