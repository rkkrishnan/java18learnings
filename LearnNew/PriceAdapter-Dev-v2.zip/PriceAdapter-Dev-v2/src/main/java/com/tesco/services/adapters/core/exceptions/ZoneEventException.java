package com.tesco.services.adapters.core.exceptions;

public class ZoneEventException extends Exception {

	public ZoneEventException(String message) {
		super(message);
	}

	public ZoneEventException(Exception exception) {
		super(exception);
	}
	
	public ZoneEventException(String message,Exception exception) {
		super(message,exception);
	}

}
