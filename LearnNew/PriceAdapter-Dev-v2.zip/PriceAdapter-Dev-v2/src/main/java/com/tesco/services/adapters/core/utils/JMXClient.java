package com.tesco.services.adapters.core.utils;

import java.util.Map;

import com.tesco.services.exceptions.ClearanceJMXException;
import com.tesco.services.exceptions.EventJMXException;
import com.tesco.services.exceptions.PriceJMXException;
import com.tesco.services.exceptions.PromoJMXException;
import com.tesco.services.exceptions.ZoneJMXException;

public interface JMXClient {

	public Map<String, TimerMetrics> getPromotionLoadMetrics()
			throws PromoJMXException;

	public void resetPromotionMetrics() throws PromoJMXException;

	public Map<String, TimerMetrics> getPriceLoadMetrics()
			throws PriceJMXException;

	public void resetPriceMetrics() throws PriceJMXException;

	public Map<String, TimerMetrics> getZoneLoadMetrics()
			throws ZoneJMXException;

	public void resetZoneMetrics() throws ZoneJMXException;
	
	public Map<String, TimerMetrics> getMMClearanceLoadMetrics()
			throws ClearanceJMXException;

	public void resetMMClearanceMetrics() throws ClearanceJMXException;
	
	public Map<String, TimerMetrics> getRPMClearanceLoadMetrics()
			throws ClearanceJMXException;

	public void resetRPMClearanceMetrics() throws ClearanceJMXException;
	
	public Map<String, TimerMetrics> getEventLoadMetrics()
			throws EventJMXException;

	public void resetEventMetrics() throws EventJMXException;
}
