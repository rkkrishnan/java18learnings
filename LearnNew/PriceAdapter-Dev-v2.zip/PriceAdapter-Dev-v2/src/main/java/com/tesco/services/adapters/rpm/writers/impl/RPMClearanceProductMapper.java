package com.tesco.services.adapters.rpm.writers.impl;

import com.tesco.services.adapters.rpm.writers.CSVHeaders;
import com.tesco.services.core.*;
import com.tesco.services.repositories.Repository;
import com.tesco.services.repositories.RepositoryImpl;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.PriceConstants;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;
import org.slf4j.Logger;

import java.text.ParseException;
import java.util.Map;
import java.util.Set;


public class RPMClearanceProductMapper {

    private static final Logger LOGGER = (Logger) LoggerFactoryWrapper.getLogger(RPMClearanceProductMapper.class);

    private Repository repository;
    private ClearanceProduct clearanceProduct;
    private String store = "S";
    private String zone = "Z";
    
    //PRIS-1663
    private String currency;
    private String endDate;


    /**
     * Constructor RPMClearanceProductMapper
     * @param repository
     */
    public RPMClearanceProductMapper (Repository repository){this.repository = repository;
    }

    public ClearanceProduct mapRPMClearanceCreAndModPrice(Map<String, String> headerToValueMap, ClearanceProduct clearanceCreProduct, boolean isNewProduct) throws ParseException {

        String tpncHeader = CSVHeaders.RpmClearance_Cre_Mod.TPNC;
        String tpnc = headerToValueMap.get(tpncHeader);

        String sellingUOMHeader = CSVHeaders.RpmClearance_Cre_Mod.SELLING_UOM;
        String sellingUOM = headerToValueMap.get(sellingUOMHeader);

        if (isNewProduct) {
            clearanceProduct = cloneClearanceProduct(clearanceCreProduct);
        }

        setClearanceStaticValues(clearanceProduct);

        clearanceProduct.setSellingUom(sellingUOM);
        ClearanceProductVariant clearanceProductVariant = getClearanceProductVariant(clearanceProduct,tpnc);

        final String locationType = headerToValueMap.get(CSVHeaders.RpmClearance_Cre_Mod.LOCATION_TYPE);
        final String location = headerToValueMap.get(CSVHeaders.RpmClearance_Cre_Mod.LOCATION);
        final String clearanceId = headerToValueMap.get(CSVHeaders.RpmClearance_Del.CLEARANCE_ID);
        
        ClearanceByDateTime clearanceByDateTime = new ClearanceByDateTime();
        clearanceByDateTime.setEffvDateTime(Dockyard.getISO8601FormatStartDateForRpmClr(headerToValueMap.get(CSVHeaders.RpmClearance_Cre_Mod.EFFECTIVE_DATE)));
        clearanceByDateTime.setEndDateTime(Dockyard.getISO8601FormatEndDateForRPMClr(headerToValueMap.get(CSVHeaders.RpmClearance_Cre_Mod.END_DATE)));
        clearanceByDateTime.setClearanceRef(headerToValueMap.get(CSVHeaders.RpmClearance_Cre_Mod.CLEARANCE_ID));
        clearanceByDateTime.setClearancePrice(Dockyard.priceScaleRoundHalfUp(headerToValueMap.get(CSVHeaders.RpmClearance_Cre_Mod.SELLING_CURRENCY),headerToValueMap.get(CSVHeaders.RpmClearance_Cre_Mod.SELLING_PRICE)));

        if(locationType.equalsIgnoreCase(zone)){

           ClearanceZoneSaleInfo clearanceZoneSaleInfo = clearanceProductVariant.getClearanceZoneSaleInfo(location);

           if (clearanceZoneSaleInfo == null){
              clearanceZoneSaleInfo = new ClearanceZoneSaleInfo(location,
                                          getCountryCode(headerToValueMap.get(CSVHeaders.RpmClearance_Cre_Mod.SELLING_CURRENCY)),
                                          headerToValueMap.get(CSVHeaders.RpmClearance_Cre_Mod.SELLING_CURRENCY));
           }
            clearanceZoneSaleInfo.addZoneClearanceByDateTime(clearanceByDateTime);

            clearanceProductVariant.addClearanceZoneSaleInfo(clearanceZoneSaleInfo);

        } else if(locationType.equalsIgnoreCase(store)) {

            ClearanceStoreSaleInfo clearanceStoreSaleInfo = clearanceProductVariant.getClearanceStoreSaleInfo(location);
            String effectiveDateKey = Dockyard.getClearanceByDateTimeKeyFormat(Dockyard.getISO8601FormatStartDateForRpmClr(
					headerToValueMap.get(CSVHeaders.RpmClearance_Cre_Mod.EFFECTIVE_DATE)));
            endDate = null;
            
            if (clearanceStoreSaleInfo == null) {
                clearanceStoreSaleInfo = new ClearanceStoreSaleInfo(location,
                        getCountryCode(headerToValueMap.get(CSVHeaders.RpmClearance_Cre_Mod.SELLING_CURRENCY)),
                        headerToValueMap.get(CSVHeaders.RpmClearance_Cre_Mod.SELLING_CURRENCY));
				
			} else if ((headerToValueMap.get(CSVHeaders.RpmClearance_Cre_Mod.EVENT_TYPE)
					.equals(PriceConstants.RPM_CLR_MOD)) && (clearanceStoreSaleInfo.getStoreClearancePriceByDateTime().get(effectiveDateKey)!= null))
					 {
			
				endDate = clearanceStoreSaleInfo.getStoreClearancePriceByDateTime().get(effectiveDateKey).getEndDateTime();

			}
            clearanceStoreSaleInfo.addStoreClearanceByDateTime(clearanceByDateTime);

            clearanceProductVariant.addClearanceStoreSaleInfo(clearanceStoreSaleInfo);
        }

        return clearanceProduct;
    }

    public ClearanceProduct mapRPMClearanceDelPrice(Map<String, String> headerToValueMap,ClearanceProduct clearanceModProduct,Boolean isNewProduct) throws ParseException {

        if (isNewProduct) {
            clearanceProduct = cloneClearanceProduct(clearanceModProduct);
        }


        final String location = headerToValueMap.get(CSVHeaders.RpmClearance_Del.LOCATION);
        final String tpnc = headerToValueMap.get(CSVHeaders.RpmClearance_Cre_Mod.TPNC);
        final String clearanceId = headerToValueMap.get(CSVHeaders.RpmClearance_Del.CLEARANCE_ID);
        String effectiveDateToDel = null;

        ClearanceProductVariant clearanceProductVariant = clearanceProduct.getClearanceProductVariantByTPNC(tpnc);

        if(clearanceProductVariant == null ){

                LOGGER.warn("Product variant {} doesn't have CRE/MOD records. Unable to delete the record. ",tpnc);
                return null;

        }
        final String locationType = headerToValueMap.get(CSVHeaders.RpmClearance_Del.LOCATION_TYPE);
        if(locationType.equalsIgnoreCase(zone)){

            ClearanceZoneSaleInfo clearanceZoneSaleInfo = clearanceProductVariant.getClearanceZoneSaleInfo(location);
            if(clearanceZoneSaleInfo!=null) {
                Set newStoreSet = clearanceZoneSaleInfo.getZoneClearancePriceByDateTime().keySet();

                for (Object newEffvDateTime : newStoreSet) {
                    if ((clearanceZoneSaleInfo.getZoneClearancePriceByDateTimeForRpmClr(newEffvDateTime.toString()).getClearanceRef()).split("-")[1].equals(clearanceId.split("-")[1])) {
                        effectiveDateToDel = newEffvDateTime.toString();
                    }
                }
                if (effectiveDateToDel != null) {
                    clearanceZoneSaleInfo.deleteZoneClearanceByDateTimeForRPMClr(effectiveDateToDel);
                    effectiveDateToDel = null;
                }
            }else{
                    LOGGER.warn("Product variant {} doesn't have Item-Zone {} combination. Unable to delete the record. ",tpnc,location);
                    return null;
            }
        }else if(locationType.equalsIgnoreCase(store)) {

            ClearanceStoreSaleInfo clearanceStoreSaleInfo = clearanceProductVariant.getClearanceStoreSaleInfo(location);
            if (clearanceStoreSaleInfo != null) {

                Set newStoreSet = clearanceStoreSaleInfo.getStoreClearancePriceByDateTime().keySet();
                currency = clearanceStoreSaleInfo.getCurrency();

                for (Object newEffvDateTime : newStoreSet) {
                    if ((clearanceStoreSaleInfo.getStoreClearancePriceByDateTimeForRpmClr(newEffvDateTime.toString()).getClearanceRef()).split("-")[1].equals(clearanceId.split("-")[1])) {
                        effectiveDateToDel = newEffvDateTime.toString();
                      //PRIS-1663- fetch the endDate from CB.It is using to filter the events based on the endDate is expired
                        endDate = clearanceStoreSaleInfo.getStoreClearancePriceByDateTimeForRpmClr(newEffvDateTime.toString()).getEndDateTime();
                    }
                }
                if (effectiveDateToDel != null) {
                    clearanceStoreSaleInfo.deleteStoreClearanceByDateTimeForRPMClr(effectiveDateToDel);
                    effectiveDateToDel = null;
                }
            }else{

                    LOGGER.warn("Product variant {} doesn't have Item-Store {} combination. Unable to delete the record. ",tpnc,location);

                    return null;
        }

        }

        clearanceProduct.addClearanceProductVariant(clearanceProductVariant);
        return clearanceProduct;
    }

    /**
     * Method getClearanceProductVariant
     * @param clearanceProduct
     * @param tpnc
     * @return
     */
    private ClearanceProductVariant getClearanceProductVariant(ClearanceProduct clearanceProduct, String tpnc) {
        ClearanceProductVariant clearanceProductVariant = clearanceProduct.getClearanceProductVariantByTPNC(tpnc);

        if (clearanceProductVariant == null) {
            clearanceProductVariant = new ClearanceProductVariant(tpnc);
            clearanceProduct.addClearanceProductVariant(clearanceProductVariant);
        }
        return clearanceProductVariant;
    }

    /**
     * Method setClearanceStaticValues
     * @param clearanceProduct
     */
    private void setClearanceStaticValues(ClearanceProduct clearanceProduct){

        Map <String,String> cleranceStaticValues ;
        ClearanceData clearanceData = new ClearanceData();

        cleranceStaticValues = clearanceData.getRPMClearanceStaticData();

        clearanceProduct.setDocType(cleranceStaticValues.get("docType"));
        clearanceProduct.setDateTimeFormat(cleranceStaticValues.get("dateTimeFormat"));
        clearanceProduct.setCountryFormat(cleranceStaticValues.get("countryFormat"));
        clearanceProduct.setCurrencyFormat(cleranceStaticValues.get("currenrcyFormat"));
        clearanceProduct.setVersionNo(cleranceStaticValues.get("version"));
        clearanceProduct.setProdType(cleranceStaticValues.get("prodType"));
    }
    //Method getCountryCode
    private String getCountryCode(String code){
        return (("EUR").equalsIgnoreCase(code)) ? "IE" : "UK";
    }
    //Method cloneClearanceProduct
    private ClearanceProduct cloneClearanceProduct(ClearanceProduct clearanceProduct){return clearanceProduct;
    }
    ////PRIS-1663- it returns the currency of the requested product.
    public String getCurrency(){
		return currency;
    }
    ////PRIS-1663- it returns the endDate of the requested product.
    public String getendDate(){
		return endDate;
    }

}
