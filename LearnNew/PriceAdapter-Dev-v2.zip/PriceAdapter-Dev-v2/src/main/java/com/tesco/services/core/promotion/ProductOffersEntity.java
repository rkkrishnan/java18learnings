package com.tesco.services.core.promotion;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by iv16 on 1/1/2016.
 */
public class ProductOffersEntity {
	@JsonProperty("tpnb")
	private String tpnb;

	@JsonProperty("locRef")
	private String locRef;

	@JsonProperty("locType")
	private String locType;

	@JsonProperty("createDateTime")
	private String createDateTime;

	@JsonProperty("lastUpdateDateTime")
	private String lastUpdateDateTime;

	@JsonProperty("promotions")
	private Map<String,ProductOffersPromotionEntity> productOffersPromotionMap = new HashMap<>();

	@JsonProperty("tpnb")
	public String getTpnb() {
		return tpnb;
	}

	@JsonProperty("tpnb")
	public void setTpnb(String tpnb) {
		this.tpnb = tpnb;
	}

	@JsonProperty("locRef")
	public String getLocRef() {
		return locRef;
	}

	@JsonProperty("locRef")
	public void setLocRef(String locRef) {
		this.locRef = locRef;
	}

	@JsonProperty("locType")
	public String getLocType() {
		return locType;
	}

	@JsonProperty("locType")
	public void setLocType(String locType) {
		this.locType = locType;
	}

	@JsonProperty("createDateTime")
	public String getCreateDateTime() {
		return createDateTime;
	}

	@JsonProperty("createDateTime")
	public void setCreateDateTime(String createDateTime) {
		this.createDateTime = createDateTime;
	}

	@JsonProperty("lastUpdateDateTime")
	public String getLastUpdateDateTime() {
		return lastUpdateDateTime;
	}

	@JsonProperty("lastUpdateDateTime")
	public void setLastUpdateDateTime(String lastUpdateDateTime) {
		this.lastUpdateDateTime = lastUpdateDateTime;
	}

	@JsonProperty("promotions")
	public Map<String, ProductOffersPromotionEntity> getProductOffersPromotionMap() {
		return productOffersPromotionMap;
	}

	@JsonProperty("promotions")
	public void setProductOffersPromotionMap(
			Map<String, ProductOffersPromotionEntity> productOffersPromotionMap) {
		this.productOffersPromotionMap = productOffersPromotionMap;
	}

	public ProductOffersPromotionEntity getProductOffersPromotionEntity(
			String key) {
		return productOffersPromotionMap.get(key);
	}

	public void setProductOffersPromotionEntity(String key,
			ProductOffersPromotionEntity productOffersPromotionEntity) {
		this.productOffersPromotionMap.put(key, productOffersPromotionEntity);
	}

	@Override public String toString() {
		return "ProductOffersEntity{" +
				"tpnb='" + tpnb + '\'' +
				", locRef='" + locRef + '\'' +
				", locType='" + locType + '\'' +
				", createDateTime='" + createDateTime + '\'' +
				", lastUpdateDateTime='" + lastUpdateDateTime + '\'' +
				", productOffersPromotionMap=" + productOffersPromotionMap +
				'}';
	}
}
