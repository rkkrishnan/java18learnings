package com.tesco.services.adapters.price;

import java.text.ParseException;
import java.util.Map;


import com.tesco.price.core.RegPrcChgDesc;
import com.tesco.price.core.RegPrcChgRef;
import com.tesco.services.adapters.core.exceptions.PriceEventException;
import com.tesco.services.core.price.PriceEntity;
import com.tesco.services.event.core.impl.MapEvent;
import com.tesco.services.exceptions.DataAccessException;
import com.tesco.services.exceptions.PriceBusinessException;


/**
 * Created by GZ13 on 11/3/2016.
 * JIRA-PRIS-1390 .This Methods generating event for FuturePriceCreateEvent requests and publish event to EventPublisher
 */

public interface PriceEventHandler {
	
	public String processCreEvent(RegPrcChgDesc regPrcChgDesc)
			throws PriceEventException, ParseException, DataAccessException;
			
	public String processDelEvent(RegPrcChgRef priceDelMsg,Map<String, PriceEntity> mapOfPriceEntities)
			throws PriceEventException, DataAccessException;
	
	public Map<String, PriceEntity> getPriceEntityData(RegPrcChgRef regPrcChgRef)
			throws PriceBusinessException;
	
	public String processScheduledEvent(Map<String,String> priceChangeEventData)
			throws PriceEventException, DataAccessException;
		
	 
}
	


