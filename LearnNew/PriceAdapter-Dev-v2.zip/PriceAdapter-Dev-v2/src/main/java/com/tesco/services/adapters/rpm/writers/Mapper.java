package com.tesco.services.adapters.rpm.writers;

import com.tesco.services.core.Product;
import com.tesco.services.exceptions.DataAccessException;

import java.util.Map;
import java.util.Set;

/**
 * Created by wa68 on 27/06/2016.
 */
public interface Mapper {
	public void clearPromoRejList();

	public Product mapPriceZonePrice(Map<String, String> headerToValueMap,
			boolean isNewProduct);

	public Product mapPromoZonePrice(Map<String, String> headerToValueMap)
			throws DataAccessException;

	public Product mapPromotion(Map<String, String> promotionInfoMap)
			throws DataAccessException;

	public Product mapPromotionDescription(
			Map<String, String> promotionDescInfoMap)
			throws DataAccessException;

	public Set<String> getPromoRejectedProducts();
}
