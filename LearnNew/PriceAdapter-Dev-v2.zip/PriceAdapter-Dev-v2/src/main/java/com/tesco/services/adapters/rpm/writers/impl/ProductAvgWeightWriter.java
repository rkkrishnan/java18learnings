package com.tesco.services.adapters.rpm.writers.impl;

import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.exceptions.WriterBusinessException;
import com.tesco.services.adapters.rpm.writers.Writer;
import com.tesco.services.core.ProductAvgWeightDetailInfoEntity;
import com.tesco.services.core.ProductAvgWeightInfoEntity;
import com.tesco.services.repositories.Repository;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.PriceConstants;
import com.tesco.services.utility.SaxParseMessageUtil;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;
import org.slf4j.Logger;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import javax.inject.Inject;
import javax.inject.Named;
import java.io.File;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Created by PO47 on 28/10/2015.
 */
public class ProductAvgWeightWriter implements Writer {
	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(ProductAvgWeightWriter.class);
	private Configuration configuration;
	private String runIdentifier;
	private Repository repository;
	private File productAvgWeightFile;
	private Dockyard dockyard;
	private SaxParseMessageUtil saxParseMessageUtil;

	public File getProductAvgWeightFile(String fileName) {
		if (productAvgWeightFile == null) {
			productAvgWeightFile = new File(
					configuration.getProductAvgWeightDataDump() + "/"
							+ runIdentifier + "/" + fileName);

		}
		return productAvgWeightFile;
	}

	public void setProductAvgWeightFile(File productAvgWeightFile) {
		this.productAvgWeightFile = productAvgWeightFile;
	}

	public Dockyard getDockyard() {

		if (dockyard == null) {
			dockyard = new Dockyard();
		}
		return dockyard;
	}

	@Inject
	public ProductAvgWeightWriter(
			@Named("configuration") Configuration configuration,
			@Named("repository") Repository repository) {
		this.configuration = configuration;
		this.repository = repository;
	}

	public String getRunIdentifier() {
		return runIdentifier;
	}

	public void setRunIdentifier(String runIdentifier) {
		this.runIdentifier = runIdentifier;
	}

	public void write(String fileName) throws WriterBusinessException {
		String date = Dockyard.getSysDate("yyyyMMdd");
		String rejectfilepath = configuration.getRejectFilePath();

		try {
			saxParseMessageUtil = saxParseMessageUtil != null ? saxParseMessageUtil
					: SaxParseMessageUtil.getInstance();

			final ProductAvgWeightInfoEntity avgWeightInfoEntity = new ProductAvgWeightInfoEntity();

			DefaultHandler handler = new DefaultHandler() {
				String tpnb;
				boolean displayTypeTag = false;
				boolean averageWeight = false;
				boolean maximumWeight = false;
				boolean minimumWeight = false;
				boolean increment = false;

				ProductAvgWeightDetailInfoEntity avgWeightDetailInfoEntity = new ProductAvgWeightDetailInfoEntity();
				Map<String, ProductAvgWeightDetailInfoEntity> avgWeight = new HashMap<>();
				Set<String> rejectList = new HashSet<>();
				int displayType = -1;

				public void startElement(String uri, String localName,
						String qName, Attributes attributes)
						throws SAXException {

					if (qName
							.equalsIgnoreCase(PriceConstants.PRODUCT_AVG_WEIGHT_PATH)) {
						tpnb = attributes
								.getValue(PriceConstants.PRODUCT_AVG_WEIGHT_TPNB_PATH);
					}

					if (qName
							.equalsIgnoreCase(PriceConstants.PRODUCT_AVG_WEIGHT_DISPLAYTYPE_PATH)) {
						displayTypeTag = true;
					}

					if (qName
							.equalsIgnoreCase(PriceConstants.PRODUCT_AVG_WEIGHTSELECTION_PATH)) {
						averageWeight = true;
					}

					if (qName
							.equalsIgnoreCase(PriceConstants.PRODUCT_MAX_WEIGHTSELECTION_PATH)) {
						maximumWeight = true;
					}

					if (qName
							.equalsIgnoreCase(PriceConstants.PRODUCT_MIN_WEIGHTSELECTION_PATH)) {
						minimumWeight = true;
					}

					if (qName
							.equalsIgnoreCase(PriceConstants.PRODUCT_INCREMENT_WEIGHTSELECTION_PATH)) {
						increment = true;
					}
				}

				public void endElement(String uri, String localName,
						String qName) throws SAXException {
					if (qName
							.equalsIgnoreCase(PriceConstants.PRODUCT_AVG_WEIGHT_PATH)) {

						if (avgWeightDetailInfoEntity != null
								&& avgWeightDetailInfoEntity.getAvMaxWt() != null) {

							avgWeight.put(tpnb, avgWeightDetailInfoEntity);
						} else if (avgWeightDetailInfoEntity != null
								&& avgWeightDetailInfoEntity.getMinWt() != null
								&& avgWeightDetailInfoEntity.getMaxWt() != null
								&& (!Dockyard
										.isSpaceOrNull(avgWeightDetailInfoEntity
												.getIncrement()))
								&& !("0").equals(avgWeightDetailInfoEntity
										.getIncrement())
								&& (avgWeightDetailInfoEntity.getMinWt()
										.compareTo(
												avgWeightDetailInfoEntity
														.getMaxWt()) < 0 || avgWeightDetailInfoEntity
										.getMinWt().compareTo(
												avgWeightDetailInfoEntity
														.getMaxWt()) == 0)) {
							avgWeight.put(tpnb, avgWeightDetailInfoEntity);

						} else if (avgWeightDetailInfoEntity.getMinWt() != null
								&& avgWeightDetailInfoEntity.getMinWt()
										.compareTo(
												avgWeightDetailInfoEntity
														.getMaxWt()) > 0) {
							rejectList
									.add("The value contained in the Minimum Weight tag is invalid: "
											+ tpnb);
						}
						avgWeightDetailInfoEntity = new ProductAvgWeightDetailInfoEntity();
					}

					if (qName.equalsIgnoreCase(PriceConstants.SONETTO_PRODUCTS)) {
						avgWeightInfoEntity.setAvgWeight(avgWeight);
						avgWeightInfoEntity.setLastUpdateDate(Dockyard
								.getSysDate(PriceConstants.ISO_8601_FORMAT));
						avgWeightInfoEntity.setRejectedProducts(rejectList);
					}

				}

				public void characters(char ch[], int start, int length)
						throws SAXException {

					if (displayTypeTag) {
						displayType = Integer.parseInt(new String(ch, start,
								length));
						if (displayType == 1) {
							avgWeightDetailInfoEntity
									.setDisplayType(PriceConstants.SONETTO_DISPLAY_TYPE_ONE);
						} else if (displayType == 2) {
							avgWeightDetailInfoEntity
									.setDisplayType(PriceConstants.SONETTO_DISPLAY_TYPE_TWO);
						} else if (displayType == 3) {
							avgWeightDetailInfoEntity
									.setDisplayType(PriceConstants.SONETTO_DISPLAY_TYPE_THREE);
						}
						displayTypeTag = false;
					}

					if (averageWeight) {
						if (displayType == 1) {
							avgWeightDetailInfoEntity.setAvMaxWt(new String(ch,
									start, length));
						} else {
							rejectList
									.add("The Display Type contains invalid Weight selection tag in sonetto file for item: "
											+ tpnb);
						}
						averageWeight = false;
					}

					if (maximumWeight && displayType == 2) {
						avgWeightDetailInfoEntity.setAvMaxWt(new String(ch,
								start, length));

						maximumWeight = false;
					} else if (maximumWeight && displayType == 1) {
						rejectList
								.add("The Display Type contains invalid Weight selection tag in sonetto file for item: "
										+ tpnb);
					}
					if (minimumWeight) {
						if (displayType == 3) {
							avgWeightDetailInfoEntity.setMinWt(new String(ch,
									start, length));
						} else if (displayType == 1) {

							rejectList
									.add("The Display Type contains invalid Weight selection tag in sonetto file for item: "
											+ tpnb);
						} else if (displayType == 2) {

							rejectList
									.add("The Display Type contains invalid Weight selection tag in sonetto file for item: "
											+ tpnb);
						}
						minimumWeight = false;
					}

					if (maximumWeight) {
						if (displayType == 3) {
							avgWeightDetailInfoEntity.setMaxWt(new String(ch,
									start, length));
						}
						maximumWeight = false;
					}

					if (increment) {
						if (displayType == 3) {
							avgWeightDetailInfoEntity.setIncrement(new String(
									ch, start, length));
						}
						if (Dockyard.isSpaceOrNull(avgWeightDetailInfoEntity
								.getIncrement())
								|| ("0").equals(avgWeightDetailInfoEntity
										.getIncrement())

						) {
							rejectList
									.add("The value contained in the Increment tag is invalid: "
											+ tpnb);
						} else if (displayType == 1) {

							rejectList
									.add("The Display Type contains invalid Weight selection tag in sonetto file for item: "
											+ tpnb);
						} else if (displayType == 2) {

							rejectList
									.add("The Display Type contains invalid Weight selection tag in sonetto file for item: "
											+ tpnb);
						}
						increment = false;

					}

					avgWeightDetailInfoEntity
							.setUom(PriceConstants.SONETTO_UOM_VALUE);
				}

			};
			productAvgWeightFile = getProductAvgWeightFile(fileName);

			saxParseMessageUtil.saxParserForXmlData(handler,
					productAvgWeightFile);
			try {
				if (runIdentifier.equals(PriceConstants.SONETTO_ROI)) {
					repository.insertObject(
							PriceConstants.SONETTO_ROI_DOC_KEY_PREFIX,
							avgWeightInfoEntity);
					LOGGER.info("The sonetto file for ROI has been inserted successfully");
				} else if (runIdentifier.equals(PriceConstants.SONETTO_UK)) {
					repository.insertObject(
							PriceConstants.SONETTO_UK_DOC_KEY_PREFIX,
							avgWeightInfoEntity);
					LOGGER.info("The sonetto file for UK has been inserted successfully");
				}
			} catch (Exception e) {
				if (runIdentifier.equals(PriceConstants.SONETTO_ROI)) {
					LOGGER.error("The sonetto file for ROI has failed to save due to DB error: "
							+ avgWeightInfoEntity);
				} else if (runIdentifier.equals(PriceConstants.SONETTO_UK)) {
					LOGGER.error("The sonetto file for UK has failed to save due to DB error: "
							+ avgWeightInfoEntity);
				}

			}

			if (!avgWeightInfoEntity.getRejectedProducts().isEmpty()) {
				getDockyard().writeProductDetailsToFile(
						rejectfilepath + "/REJECT_FILE_" + runIdentifier + "_"
								+ date + ".log",
						avgWeightInfoEntity.getRejectedProducts());
				avgWeightInfoEntity.getRejectedProducts().clear();
			}
		} catch (Exception e) {
			LOGGER.error("Error occured in importing ProductAvgWeight", e);
			throw new WriterBusinessException(e.getMessage(), e.getCause());
		}

	}

}