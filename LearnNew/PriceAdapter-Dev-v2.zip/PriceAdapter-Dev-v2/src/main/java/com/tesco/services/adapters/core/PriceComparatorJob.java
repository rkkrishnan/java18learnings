package com.tesco.services.adapters.core;

import javax.inject.Inject;
import javax.inject.Named;

import org.slf4j.Logger;

import com.tesco.services.adapters.rpm.writers.FileProcessor;
import com.tesco.services.adapters.rpm.writers.impl.TeauthFileProcessor;
import com.tesco.services.resources.TeauthPriceChecksResource;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;

/**
 * Created by QU17 on 18/03/2015.
 */
public class PriceComparatorJob implements Import {

	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(PriceComparatorJob.class);

	private String fileName;
	private String runType;
	private FileProcessor teauthFileProcessor;

	/**
	 * @param teauthFileProcessor
	 */
	@Inject
	public PriceComparatorJob(
			@Named("teauthFileProcessor") FileProcessor teauthFileProcessor) {
		this.teauthFileProcessor = teauthFileProcessor;
	}

	public String getRunType() {
		return runType;
	}

	public void setRunType(String runType) {
		this.runType = runType;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	@Override
	public void run() {
		LOGGER.info("Firing up Price Comparisons...");
		startImportProcess();
	}

	public void startImportProcess() {
		try {
			LOGGER.info("Comparing Price from TEAUTH File {}....", fileName);
			((TeauthFileProcessor)teauthFileProcessor).setFileName(getFileName());
			((TeauthFileProcessor)teauthFileProcessor).setRunType(runType);
			teauthFileProcessor.readAndProcessFile();
		} catch (Exception exception) {
			LOGGER.error("Error while comparing prices", exception);
			TeauthPriceChecksResource.setErrorString(fileName,
					"Error in Processing Price Checks");
		} finally {
			TeauthPriceChecksResource.getPriceChecksSemaphore(fileName)
					.release();
		}
	}

	public void setTeauthFileProcessor(
			TeauthFileProcessor teauthFileProcessor) {
		this.teauthFileProcessor = teauthFileProcessor;
	}
}
