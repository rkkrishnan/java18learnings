package com.tesco.services.core;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;


public class ClearanceProductVariant implements Serializable{

    @JsonProperty
    private String tpnc;

    @JsonProperty
    private Map<String, ClearanceZoneSaleInfo> zonePrices = new HashMap<>();

    @JsonProperty
    private Map<String, ClearanceStoreSaleInfo> storeExceptions = new HashMap<>();

    public Map<String, ClearanceZoneSaleInfo> getZonePrices() {
        return zonePrices;
    }

    public Map<String, ClearanceStoreSaleInfo> getStoreExceptions() {
        return storeExceptions;
    }

    /**
     * Constructor ClearanceProductVariant
     * @param tpnc
     */

    public ClearanceProductVariant(String tpnc) {
        this.tpnc = tpnc;
    }

    /**
     * Constructor ClearanceProductVariant
     */
    public ClearanceProductVariant(){
        /**
         * Empty
         */

    }

  @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

       ClearanceProductVariant clearanceProductVariant = (ClearanceProductVariant) o;
        if ((!tpnc.equals(clearanceProductVariant.tpnc))||
                (!zonePrices.equals(clearanceProductVariant.zonePrices))||
                (!storeExceptions.equals(clearanceProductVariant.storeExceptions))) {

            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int result = tpnc.hashCode();
        result = 31 * result + zonePrices.hashCode();
        result = 31 * result + storeExceptions.hashCode();
        return result;
    }
    @Override
    public String toString() {
        return "ClearanceProductVariant{" +
               // "tpnc='" + tpnc + '\'' +
                "zonePrices :'" + zonePrices + '\''+
                ", storeExceptions :" + storeExceptions +
                '}';
    }

    public void addClearanceZoneSaleInfo(ClearanceZoneSaleInfo clearanceZoneSaleInfo) {
        zonePrices.put(clearanceZoneSaleInfo.getClearanceZoneId(), clearanceZoneSaleInfo);
    }
    public void deleteClearanceZoneSaleInfo(ClearanceZoneSaleInfo clearanceZoneSaleInfo) {
        zonePrices.remove(clearanceZoneSaleInfo.getClearanceZoneId());
    }
    public void addClearanceStoreSaleInfo(ClearanceStoreSaleInfo clearanceStoreSaleInfo) {
        storeExceptions.put(clearanceStoreSaleInfo.getclearanceStoreId(), clearanceStoreSaleInfo);
    }
    public void deleteClearanceStoreSaleInfo(ClearanceStoreSaleInfo clearanceStoreSaleInfo) {
        storeExceptions.remove(clearanceStoreSaleInfo.getclearanceStoreId());
    }

    public String getTpnc() {
        return tpnc;
    }

       public ClearanceZoneSaleInfo getClearanceZoneSaleInfo(String zoneId) {
        return zonePrices.get(zoneId);
    }
    public ClearanceZoneSaleInfo getClearanceZoneSaleInfo(int zoneId) {
        return zonePrices.get(String.valueOf(zoneId));
    }

    public ClearanceStoreSaleInfo getClearanceStoreSaleInfo(String storeId) {
        return storeExceptions.get(storeId);
    }
}
