package com.tesco.services.adapters.zone.impl;

import static com.tesco.services.utility.PriceConstants.STORE_ZONE_CHANGE;
import static com.tesco.services.utility.PriceConstants.ZONE_MSG_TYPE_DELETED;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.tesco.services.adapters.zone.ZoneEventHandler;
import com.tesco.services.repositories.Repository;
import com.tesco.services.repositories.RepositoryImpl;
import org.slf4j.Logger;

import com.tesco.services.adapters.core.exceptions.ZoneEventException;
import com.tesco.services.adapters.core.utils.EventMetrics;
import com.tesco.services.core.ZoneEntity;
import com.tesco.services.event.core.EventTemplate;
import com.tesco.services.event.core.impl.MapEvent;
import com.tesco.services.event.exception.EventPublishException;
import com.tesco.services.utility.CommonEventPublishingUtility;
import com.tesco.services.utility.PriceConstants;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;
import com.tesco.zone.core.TSLZone;
import com.tesco.zone.core.TSLZoneGroupDesc;
import com.tesco.zone.core.TSLZoneGroupRef;
import com.tesco.zone.core.TSLZoneLoc;
import com.tesco.zone.core.TSLZoneLocRef;
import com.tesco.zone.core.TSLZoneRef;

public class ZoneEventHandlerImpl implements ZoneEventHandler {

	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(ZoneEventHandlerImpl.class);
	private static final EventMetrics EVENTMETRICS = EventMetrics.getInstance();

	private EventTemplate eventTemplate;
	private Repository repository;

	public ZoneEventHandlerImpl(EventTemplate template,
			RepositoryImpl repository) {
		this.eventTemplate = template;
		this.repository = repository;
	}

	/**
	 * This method is used to create event for zone creation and zone details
	 * changed
	 * 
	 * @param tslZoneGroupDesc
	 *            tslZoneGroupDesc
	 * @param String
	 *            zoneEventType
	 * @throws ZoneEventException
	 */
	@Override
	public List<String> publishZoneEvent(TSLZoneGroupDesc tslZoneGroupDesc,
			String zoneEventType) throws ZoneEventException {
		LOGGER.debug("Inside ZoneEventHandlerImpl.publishZoneEvent.");
		List<TSLZone> tslZoneList = tslZoneGroupDesc.getTSLZone();
		List<String> messageIdList = null;
		messageIdList = new ArrayList<String>();
		for (TSLZone tslZone : tslZoneList) {
			String zoneId = String.valueOf(tslZone.getZoneId());
			String countryCode = tslZone.getCountryCode();
			MapEvent eventData = CommonEventPublishingUtility
					.createZoneEventData(zoneEventType, countryCode, zoneId);
			eventData.setEventType(zoneEventType);
			try {
				LOGGER.info("Publishing :: " + zoneEventType + " :: Event");
				EVENTMETRICS.logEventStartTime(zoneEventType);
				String messageId = eventTemplate.publishEvent(eventData);
				EVENTMETRICS.logEventEndTime(zoneEventType);

				LOGGER.info("Published :: " + zoneEventType
						+ " :: Event MessageId" + messageId);
				messageIdList.add(messageId);
			} catch (EventPublishException e) {
				EVENTMETRICS.logEventEndTime(zoneEventType);
				EVENTMETRICS.incrementErrorCounter(zoneEventType);
				String errorMsg = zoneEventType
						+ " :: Event Publication failed for Zone ID:" + zoneId;
				LOGGER.error(errorMsg, e);
				throw new ZoneEventException(errorMsg, e);
			}
		}

		return messageIdList;
	}

	/**
	 * This method is used to create event for zone deletion
	 * 
	 * @param tslZoneGroupRef
	 *            tslZoneGroupRef
	 * @Map zoneCountryCodeMap
	 * @throws ZoneEventException
	 */
	@Override
	public List<String> publishZoneDelEvent(TSLZoneGroupRef tslZoneGroupRef,
			Map<String, ZoneEntity> zoneCountryCodeMap)
			throws ZoneEventException {

		LOGGER.debug("Inside ZoneEventHandlerImpl.publishZoneDelEvent");
		List<TSLZoneRef> tslZoneRefList = tslZoneGroupRef.getTSLZoneRef();
		List<String> messageIdList = new ArrayList<String>();
		for (TSLZoneRef tslZoneRef : tslZoneRefList) {
			String zoneId = String.valueOf(tslZoneRef.getZoneId());
			ZoneEntity ze = zoneCountryCodeMap.get(zoneId);
			String countryCode = ze.getTslCountryCode();
			MapEvent event = CommonEventPublishingUtility.createZoneEventData(
					PriceConstants.ZONE_MSG_TYPE_DELETED, countryCode, zoneId);
			event.setEventType(PriceConstants.ZONE_MSG_TYPE_DELETED);
			try {
				LOGGER.info("Publishing Zone deletion Event");
				EVENTMETRICS
						.logEventStartTime(PriceConstants.ZONE_MSG_TYPE_DELETED);
				String messageId = eventTemplate.publishEvent(event);
				EVENTMETRICS
						.logEventEndTime(PriceConstants.ZONE_MSG_TYPE_DELETED);
				LOGGER.info("Published Zone deletion Event : " + messageId);
				messageIdList.add(messageId);

			} catch (EventPublishException e) {
				EVENTMETRICS.logEventEndTime(ZONE_MSG_TYPE_DELETED);
				EVENTMETRICS.incrementErrorCounter(ZONE_MSG_TYPE_DELETED);
				String errMsg = "Event Publication failed for Zone ID:"
						+ String.valueOf(tslZoneRef.getZoneId());
				LOGGER.error(errMsg, e);
				throw new ZoneEventException(errMsg, e);
			}
		}

		return messageIdList;
	}

	/**
	 * This method is used to publish events related to store sone change
	 * 
	 * @throws ZoneEventException
	 * @param TSLZoneGroupDesc
	 *            tslZoneGroupDesc
	 * @Param Map storeZoneCountryCodeMap
	 */
	@Override
	public List<String> publishStoreZoneChangeCreEvent(
			TSLZoneGroupDesc tslZoneGroupDesc,
			Map<String, ZoneEntity> storeZoneCountryCodeMap)
			throws ZoneEventException {
		LOGGER.debug("Inside ZoneEventHandlerImpl.publishStoreZoneSetupEvent");

		List<TSLZone> tslZoneList = tslZoneGroupDesc.getTSLZone();
		List<String> messageIdList = new ArrayList<String>(tslZoneList.size());
		String countryCode = null;
		for (TSLZone tslZone : tslZoneList) {
			List<TSLZoneLoc> tslZoneLocList = tslZone.getTSLZoneLoc();
			String zoneId = String.valueOf(tslZone.getZoneId());
			ZoneEntity zoneEntity = storeZoneCountryCodeMap.get(zoneId);
			countryCode = zoneEntity.getTslCountryCode();
			for (TSLZoneLoc tslZoneLoc : tslZoneLocList) {
				String storeId = String.valueOf(tslZoneLoc.getLoc());
				MapEvent event = CommonEventPublishingUtility
						.storeZoneEventData(PriceConstants.STORE_ZONE_CHANGE,
								countryCode, storeId, zoneId);
				try {
					LOGGER.info("Publishing StoreZone Change Event to Setup Store");
					EVENTMETRICS
							.logEventStartTime(PriceConstants.STORE_ZONE_CHANGE);
					String messageId = eventTemplate.publishEvent(event);
					EVENTMETRICS
							.logEventEndTime(PriceConstants.STORE_ZONE_CHANGE);
					LOGGER.info("Published StoreZone Change  Event  to Setup store messageId: "
							+ messageId);
					messageIdList.add(messageId);
				} catch (EventPublishException e) {
					EVENTMETRICS.logEventEndTime(STORE_ZONE_CHANGE);
					EVENTMETRICS.incrementErrorCounter(STORE_ZONE_CHANGE);
					String msg = "Event Publication for StoreZone Change Setup Event failed for Store ID:"
							+ storeId;
					LOGGER.error(msg, e);
					throw new ZoneEventException(msg, e);
				}
			}
		}

		return messageIdList;
	}

	/**
	 * This method is used to publish event for store remove
	 * 
	 * @throws ZoneEventException
	 * @param TSLZoneGroupRef
	 *            tslZoneGroupRef
	 * @param Map
	 *            storeZoneCountryCodeMap
	 * 
	 */

	@Override
	public List<String> publishStoreZoneChangeRemoveEvent(
			TSLZoneGroupRef tslZoneGroupRef,
			Map<String, ZoneEntity> storeZoneCountryCodeMap)
			throws ZoneEventException {
		LOGGER.debug("Inside ZoneEventHandlerImpl.publishStoreZoneRemoveEvent");

		List<TSLZoneRef> tslZoneRefList = tslZoneGroupRef.getTSLZoneRef();
		List<String> messageIdList = new ArrayList<String>(
				tslZoneRefList.size());
		for (TSLZoneRef tslZoneRef : tslZoneRefList) {
			List<TSLZoneLocRef> tslZoneLocRefList = tslZoneRef
					.getTSLZoneLocRef();
			String zoneId = String.valueOf(tslZoneRef.getZoneId());
			ZoneEntity zoneEntity = storeZoneCountryCodeMap.get(zoneId);
			String countryCode = zoneEntity.getTslCountryCode();
			for (TSLZoneLocRef tslZoneLocRef : tslZoneLocRefList) {
				String storeId = String.valueOf(tslZoneLocRef.getLoc());
				MapEvent event = CommonEventPublishingUtility
						.storeZoneEventData(PriceConstants.STORE_ZONE_CHANGE,
								countryCode, storeId, zoneId);
				try {
					LOGGER.info("Publishing StoreZone Change Event to Remove Store ");
					EVENTMETRICS
							.logEventStartTime(PriceConstants.STORE_ZONE_CHANGE);
					String messageId = eventTemplate.publishEvent(event);
					EVENTMETRICS
							.logEventEndTime(PriceConstants.STORE_ZONE_CHANGE);
					LOGGER.info("Published StoreZone Change Event messageId : "
							+ messageId);
					messageIdList.add(messageId);
				} catch (EventPublishException e) {
					EVENTMETRICS
							.logEventEndTime(PriceConstants.STORE_ZONE_CHANGE);
					EVENTMETRICS.incrementErrorCounter(STORE_ZONE_CHANGE);
					String msg = "Event Publication for StoreZone Change Event failed for Store ID:"
							+ storeId;
					LOGGER.error(msg, e);
					throw new ZoneEventException(msg, e);
				}
			}
		}

		return messageIdList;
	}
}
