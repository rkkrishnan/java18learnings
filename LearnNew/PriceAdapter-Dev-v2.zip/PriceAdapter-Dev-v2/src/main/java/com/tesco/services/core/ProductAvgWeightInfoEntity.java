package com.tesco.services.core;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.*;

/**
 * Created by PO47 on 28/10/2015.
 */
public class ProductAvgWeightInfoEntity {
	@JsonProperty
	private Map<String, ProductAvgWeightDetailInfoEntity> avgWeight = new HashMap<>();

	@JsonProperty
	private String lastUpdateDate;
	@JsonIgnore
	private Set<String> rejectedProducts;


	public Map<String, ProductAvgWeightDetailInfoEntity> getAvgWeight() {
		return avgWeight;
	}

	public void setAvgWeight(
			Map<String, ProductAvgWeightDetailInfoEntity> avgWeight) {
		this.avgWeight = avgWeight;
	}

	public String getLastUpdateDate() {
		return lastUpdateDate;
	}


	@Override public String toString() {
		return "ProductAvgWeightInfoEntity{" +
				"avgWeight=" + avgWeight +
				", lastUpdateDate='" + lastUpdateDate + '\'' +
				'}';
	}

	public void setLastUpdateDate(String lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	public void setRejectedProducts(Set<String> rejectedProducts) {
		this.rejectedProducts = rejectedProducts;
	}

	public Set<String> getRejectedProducts() {
		return rejectedProducts;
	}
}
