package com.tesco.services;

import com.couchbase.client.CouchbaseClient;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.module.afterburner.AfterburnerModule;
import com.tesco.couchbase.AsyncCouchbaseWrapper;
import com.tesco.couchbase.ConcreteCouchbaseResource;
import com.tesco.couchbase.CouchbaseResource;
import com.tesco.couchbase.CouchbaseWrapper;
import com.tesco.logging.LogConfigurator;
import com.tesco.services.adapters.core.*;
import com.tesco.services.adapters.core.utils.*;
import com.tesco.services.adapters.price.PriceEventHandler;
import com.tesco.services.adapters.price.PriceHandler;
import com.tesco.services.adapters.price.impl.PriceEventHandlerImpl;
import com.tesco.services.adapters.price.impl.PriceHandlerImpl;
import com.tesco.services.adapters.promotion.*;
import com.tesco.services.adapters.promotion.impl.MultiBuyPromotionHandler;
import com.tesco.services.adapters.promotion.impl.PromotionEventHandlerImpl;
import com.tesco.services.adapters.promotion.impl.SimplePromotionHandler;
import com.tesco.services.adapters.promotion.impl.ThresholdPromotionHandler;
import com.tesco.services.adapters.rpm.events.ClearanceEventHandler;
import com.tesco.services.adapters.rpm.events.impl.ClearanceEventHandlerImpl;
import com.tesco.services.adapters.rpm.readers.MessageRouter;
import com.tesco.services.adapters.rpm.readers.impl.PriceMessageRouter;
import com.tesco.services.adapters.rpm.readers.impl.PromotionMessageRouter;
import com.tesco.services.adapters.rpm.readers.impl.ZoneMessageRouter;
import com.tesco.services.adapters.rpm.writers.*;
import com.tesco.services.adapters.rpm.writers.impl.*;
import com.tesco.services.adapters.zone.ZoneEventHandler;
import com.tesco.services.adapters.zone.impl.ZoneEventHandlerImpl;
import com.tesco.services.adapters.zone.ZoneHandler;
import com.tesco.services.adapters.zone.impl.ZoneHandlerImpl;
import com.tesco.services.core.jms.JMSAdapterConfigurator;
import com.tesco.services.event.core.EventConfigParameter;
import com.tesco.services.event.core.EventConfiguration;
import com.tesco.services.event.core.EventFactory;
import com.tesco.services.event.core.EventTemplate;
import com.tesco.services.event.core.impl.JMSEventFactory;
import com.tesco.services.event.exception.EventConfigurationException;
import com.tesco.services.healthChecks.CouchbaseHealthCheck;
import com.tesco.services.repositories.*;
import com.tesco.services.resources.*;
import com.tesco.services.utility.PriceConstants;
import com.tesco.services.utility.WebServiceCallBuilder;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;

import io.dropwizard.Application;
import io.dropwizard.assets.AssetsBundle;
import io.dropwizard.jackson.Jackson;
import io.dropwizard.setup.Bootstrap;
import io.dropwizard.setup.Environment;
import io.swagger.jaxrs.config.BeanConfig;
import io.swagger.jaxrs.listing.SwaggerSerializers;

import org.eclipse.jetty.servlets.CrossOriginFilter;
import org.glassfish.hk2.api.ServiceLocator;
import org.glassfish.hk2.api.TypeLiteral;
import org.glassfish.hk2.utilities.ServiceLocatorUtilities;
import org.glassfish.hk2.utilities.binding.AbstractBinder;
import org.glassfish.jersey.servlet.ServletProperties;
import org.slf4j.Logger;

import javax.servlet.DispatcherType;

import java.io.IOException;
import java.net.SocketException;
import java.net.URISyntaxException;
import java.net.UnknownHostException;
import java.util.EnumSet;
import java.util.UUID;

import static com.tesco.services.utility.PriceConstants.COUCHBASE_VIEW_QUERY;

public class PriceService extends Application<Configuration> {
	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(PriceService.class);

	public static void main(String[] args) throws Exception {
		new PriceService().run(args);
	}

	@Override
	public void initialize(Bootstrap<Configuration> bootstrap) {
		bootstrap.addBundle(new AssetsBundle("/assets/", "/docs", "index.htm"));
	}

	@Override
	public void run(Configuration configuration, Environment environment)
			throws Exception {
		ServiceLocator serviceLocator = ServiceLocatorUtilities
				.createAndPopulateServiceLocator(UUID.randomUUID().toString());

		LOGGER.info("Configuring dependencies...");
		configureDependencies(serviceLocator, configuration);

		LOGGER.info("Configuring JMS");
		JMSAdapterConfigurator.configureJMS(configuration, environment,
				serviceLocator);

		LOGGER.info("Configuring Message Logger");
		LogConfigurator.init(configuration.getLoggerConfig());

		LOGGER.info("Configuring service locator for the jersey environment");
		environment
				.getApplicationContext()
				.getAttributes()
				.setAttribute(ServletProperties.SERVICE_LOCATOR, serviceLocator);

		LOGGER.info("Registering REST resources");
		registerResources(environment);

		LOGGER.info("Configuring Swagger Docs");
		configureSwagger(environment, configuration);

		LOGGER.info("Configuring health checks");
		environment.healthChecks().register(
				"CouchbaseHealthCheck",
				new CouchbaseHealthCheck(serviceLocator
						.getService(AsyncCouchbaseWrapper.class)));

		LOGGER.info("Configuring metrics");

		MMClearanceMetrics.getInstance();
		RPMClearanceMetrics.getInstance();
		PriceMetrics.getInstance();
		PromotionMetrics.getInstance();
		ZoneMetrics.getInstance();

	}

	private void registerResources(Environment environment) {
		environment.jersey().register(ImportResource.class);
		environment.jersey().register(PromotionResource.class);
		environment.jersey().register(ItemPurgeResource.class);
		environment.jersey().register(DBReplicaResource.class);
		environment.jersey().register(JMSResource.class);
		environment.jersey().register(JMXResource.class);
		environment.jersey().register(ScheduledEventResource.class);

		/* Disabled teauth process for this releease 8 */
		/* environment.jersey().register(TeauthPriceChecksResource.class); */
	}

	private void configureDependencies(ServiceLocator serviceLocator,
			final Configuration configuration) throws Exception {

		try {

			final ObjectMapper objectMapper = Jackson.newObjectMapper();
			objectMapper.registerModule(new AfterburnerModule());
			objectMapper.configure(
					DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
			objectMapper.configure(
					DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			objectMapper
					.setSerializationInclusion(JsonInclude.Include.NON_NULL);

			final CouchbaseClient couchbaseClient = new CouchbaseConnectionManager(
					configuration).getCouchbaseClient();

			final CouchbaseResource couchbaseResource = new ConcreteCouchbaseResource(
					configuration.getCouchbaseNodes(),
					configuration.getCouchbaseBucket(),
					configuration.getCouchbaseUsername(),
					configuration.getCouchbasePassword());

			ServiceLocatorUtilities.bind(serviceLocator, new AbstractBinder() {
				@Override
				protected void configure() {
					bind(configuration).named("configuration");
					bind(objectMapper).named("jsonmapper");
					bind(SwaggerSerializers.class);

					/** Repositories */

					Repository repository = new RepositoryImpl(
							couchbaseResource.getCouchbaseWrapper(),
							couchbaseResource.getAsyncCouchbaseWrapper(),
							objectMapper);

					bind(repository).to(new TypeLiteral<Repository>() {
					}).named("repository");

					bind(AsyncReadWriteProductRepository.class).named(
							"asyncProductRepo");

					bind(couchbaseResource.getAsyncCouchbaseWrapper()).to(
							AsyncCouchbaseWrapper.class).named(
							"asyncCouchbaseWrapper");
					bind(couchbaseResource.getCouchbaseWrapper()).to(
							CouchbaseWrapper.class).named("couchbaseWrapper");
					bind(couchbaseClient).named("couchclient");

					/** RPM Adapter */

					// Changes for Dropwizard upgrade
					bind(ImportJob.class).to(new TypeLiteral<Import>() {
					}).named("importJob");
					bind(RPMWriter.class).to(new TypeLiteral<Writer>() {
					}).named("rpmWriter");
					bind(ProductMapper.class).to(new TypeLiteral<Mapper>() {
					}).named("productMapper");
					bind(StoreMapper.class).named("storeMapper");
					bind(PromotionWriter.class).to(
							new TypeLiteral<PromotionMessageWriter>() {
							}).named("promotionWriter");
					bind(ImportMMJob.class).to(new TypeLiteral<Import>() {
					}).named("importMMJob");
					bind(MMWriter.class).to(new TypeLiteral<Writer>() {
					}).named("mmWriter");
					bind(ImportRPMClearanceJob.class).to(
							new TypeLiteral<Import>() {
							}).named("importRPMClearanceJob");
					bind(RPMClearanceWriter.class).to(
							new TypeLiteral<Writer>() {
							}).named("rpmClearanceWriter");
					bind(ImportRPMZoneJob.class).to(new TypeLiteral<Import>() {
					}).named("importRPMZoneJob");
					bind(RPMZoneWriter.class).to(new TypeLiteral<Writer>() {
					}).named("rpmZoneWriter");
					bind(ImportSubGroupDfltUomJob.class).to(
							new TypeLiteral<Import>() {
							}).named("importSubGroupJob");
					bind(RPMSubGroupDfltUomMapper.class).to(
							new TypeLiteral<Writer>() {
							}).named("rpmMapper");
					bind(new WebServiceCallBuilder(configuration)).named(
							"webServiceCallBuilder");
					bind(ImportPriceJob.class).to(new TypeLiteral<Import>() {
					}).named("importPriceJob");
					bind(ImportProductAvgWeightJob.class).to(
							new TypeLiteral<Import>() {
							}).named("importProductAvgWeightJob");
					bind(ProductAvgWeightWriter.class).to(
							new TypeLiteral<Writer>() {
							}).named("productAvgWeightWriter");
					bind(ImportRPMZoneGroupJob.class).to(
							new TypeLiteral<Import>() {
							}).named("importRPMZoneGroupJob");
					bind(RPMZoneGroupWriter.class).to(
							new TypeLiteral<Writer>() {
							}).named("rpmZoneGroupWriter");
					bind(ImportEstablishedPriceJob.class).to(
							new TypeLiteral<Import>() {
							}).named("importEstablishedPriceJob");
					bind(EstablishedPriceWritter.class).to(
							new TypeLiteral<Writer>() {
							}).named("establishedPriceJobWriter");
					bind(ImportFutureOfferDescJob.class).to(
							new TypeLiteral<Import>() {
							}).named("importFutureOfferDescJob");
					bind(FutureOfferDescWritter.class).to(
							new TypeLiteral<Writer>() {
							}).named("futureOfferDescWritter");
					bind(ImportItemDefaultUomJob.class).to(
							new TypeLiteral<Import>() {
							}).named("importItemDefaultUomJob");
					bind(ItemDefaultUomWriter.class).to(
							new TypeLiteral<Writer>() {
							}).named("itemDefaultUomWriter");
					bind(ImportEanJob.class).to(new TypeLiteral<Import>() {
					}).named("importEanJob");
					bind(EanSeedingWriter.class).to(new TypeLiteral<Writer>() {
					}).named("eanSeedingWriter");
					bind(PriceComparatorJob.class).to(
							new TypeLiteral<Import>() {
							}).named("priceComparatorJob");

					bind(TeauthFileProcessor.class).to(
							new TypeLiteral<FileProcessor>() {
							}).named("teauthFileProcessor");

					bind(PriceWriter.class).to(
							new TypeLiteral<PriceMessageWriter>() {
							}).named("priceWriter");
					bind(ZoneWriter.class).to(
							new TypeLiteral<ZoneMessageWriter>() {
							}).named("zoneJMSWriter");

					bind(ZoneWriter.class).named("zoneWriter");

					/** JMS message handling */
					bind(SimplePromotionHandler.class).to(
							new TypeLiteral<PromotionHandler>() {
							}).named("simplePromoHandler");
					bind(ThresholdPromotionHandler.class).to(
							new TypeLiteral<PromotionHandler>() {
							}).named("thresholdPromoHandler");
					bind(MultiBuyPromotionHandler.class).to(
							new TypeLiteral<PromotionHandler>() {
							}).named("multiBuyPromoHandler");
					bind(PriceHandlerImpl.class).to(
							new TypeLiteral<PriceHandler>() {
							}).named("priceHandler");
					bind(ZoneHandlerImpl.class).to(
							new TypeLiteral<ZoneHandler>() {
							}).named("zoneHandler");

					bind(PromotionMessageRouter.class).to(
							new TypeLiteral<MessageRouter>() {
							}).named("promoMsgRouter");
					bind(PriceMessageRouter.class).to(
							new TypeLiteral<MessageRouter>() {
							}).named("priceMsgRouter");
					bind(ZoneMessageRouter.class).to(
							new TypeLiteral<MessageRouter>() {
							}).named("zoneMsgRouter");

					bind(new JMXClientImpl(configuration, serviceLocator))
							.named("jmxClient");
					bind(WebServiceCallBuilder.class).named(
							"webServiceCallBuilder");
				}
			});

			configureEventDependencies(serviceLocator, configuration);

		} catch (URISyntaxException | IOException | InterruptedException e) {
			throw new Exception(e);
		}

	}

	private void configureSwagger(Environment environment,
			BaseConfiguration configuration) throws UnknownHostException,
			SocketException {
		environment.jersey().register(
				io.swagger.jaxrs.listing.ApiListingResource.class);
		environment.jersey().register(
				io.swagger.jaxrs.listing.SwaggerSerializers.class);

		BeanConfig swaggerConfig = new BeanConfig();
		swaggerConfig.setTitle("Price Service Import API");
		swaggerConfig.setVersion("3.0");
		swaggerConfig.setBasePath("/");
		swaggerConfig.setResourcePackage("com.tesco.services.resources");
		swaggerConfig.setScan(true);
		environment
				.servlets()
				.addFilter("CrossOriginFilter", CrossOriginFilter.class)
				.addMappingForUrlPatterns(EnumSet.allOf(DispatcherType.class),
						true, "/*");
	}

	/**
	 * This method is used to register pricing-event specific configurations
	 * 
	 * @param configuration
	 * @return
	 * @throws EventConfigurationException
	 */
	private void configureEventDependencies(ServiceLocator serviceLocator,
			final Configuration configuration)
			throws EventConfigurationException {

		EventFactory factory = new JMSEventFactory();
		try {
			EventPublisherConfiguration[] priceConfArray = configuration
					.getEventConfigs();
			EventConfiguration[] conf = new EventConfiguration[priceConfArray.length];

			int configIndex = 0;
			for (EventPublisherConfiguration publisherConfig : priceConfArray) {
				EventConfiguration config = new EventConfiguration();
				config.setConfigId(publisherConfig.getConfigId());
				config.setTopicRetryCount(publisherConfig.getRetryCount());
				config.setTopicName(publisherConfig.getTopicName());
				config.setJmsFactoryClassName(publisherConfig
						.getJmsFactoryClass());
				EventConfigParameter[] factClassParam = new EventConfigParameter[publisherConfig
						.getEventFactoryParameters().length];
				int factoryClassParamIndex = 0;
				if (publisherConfig.getEventFactoryParameters() != null) {
					for (EventFactoryParameter factoryClassParams : publisherConfig
							.getEventFactoryParameters()) {
						EventConfigParameter factoryClassCfgParam = new EventConfigParameter();
						factoryClassCfgParam.setName(factoryClassParams
								.getName());
						factoryClassCfgParam.setType(factoryClassParams
								.getType());
						factoryClassCfgParam.setValue(factoryClassParams
								.getValue());
						factoryClassCfgParam.setPrimitive(factoryClassParams
								.isPrimitive());
						factClassParam[factoryClassParamIndex] = factoryClassCfgParam;
						factoryClassParamIndex++;
					}
					config.setFactoryConstructorParameters(factClassParam);
				}

				if (publisherConfig.getEventFactoryProperties() != null) {
					EventConfigParameter[] factClassProperties = new EventConfigParameter[publisherConfig
							.getEventFactoryProperties().length];
					factoryClassParamIndex = 0;
					for (EventFactoryParameter factClassProperty : publisherConfig
							.getEventFactoryProperties()) {
						EventConfigParameter factoryClassCfgParam = new EventConfigParameter();
						factoryClassCfgParam.setName(factClassProperty
								.getName());
						factoryClassCfgParam.setType(factClassProperty
								.getType());
						factoryClassCfgParam.setValue(factClassProperty
								.getValue());
						factoryClassCfgParam.setPrimitive(factClassProperty
								.isPrimitive());
						factClassProperties[factoryClassParamIndex] = factoryClassCfgParam;
						factoryClassParamIndex++;
					}
					config.setFactoryProperties(factClassProperties);
				}
				conf[configIndex] = config;
				configIndex++;
			}
			factory.configureEventTemplate(conf);
		} catch (EventConfigurationException e) {
			LOGGER.error(
					"Fatal Error while configuring EventConfiguration!!!!!", e);
			throw e;
		}

		EventTemplate eventTemplate = factory
				.getPublishTemplate(PriceConstants.REALTIME_TEMPLATE_ID);

		ServiceLocatorUtilities.bind(serviceLocator, new AbstractBinder() {
			@Override
			protected void configure() {

				bind(eventTemplate).to(new TypeLiteral<EventTemplate>() {
				}).named("rtEventTemplate");

				// PRIS-1390-FuturePriceEventHanler Registered with container

				PriceEventHandler priceEventHandler = new PriceEventHandlerImpl(
						eventTemplate, serviceLocator
								.getService(PriceWriter.class), serviceLocator
								.getService(RepositoryImpl.class));

				bind(priceEventHandler).to(
						new TypeLiteral<PriceEventHandler>() {
						}).named("priceEventHandler");

				PromotionEventHandler promoEvtHandler = new PromotionEventHandlerImpl(
						eventTemplate, serviceLocator
								.getService(RepositoryImpl.class));

				bind(promoEvtHandler).to(
						new TypeLiteral<PromotionEventHandler>() {
						}).named("promoEvtHandler");

				ZoneEventHandler zoneEventHandler = new ZoneEventHandlerImpl(
						eventTemplate, serviceLocator
								.getService(RepositoryImpl.class));

				bind(zoneEventHandler).to(new TypeLiteral<ZoneEventHandler>() {
				}).named("zoneEventHandler");

				// PRIS-1692-National Clearance created - event publication - MM
				// clearances
				ClearanceEventHandler clearanceEventHandler = new ClearanceEventHandlerImpl(
						eventTemplate);

				bind(clearanceEventHandler).to(
						new TypeLiteral<ClearanceEventHandler>() {
						}).named("clearanceEventHandler");

				/*
				 * CouchbaseViewQuery couchbaseViewQuery = new
				 * CouchbaseViewQueryImpl();
				 * 
				 * bind(couchbaseViewQuery).to( new
				 * TypeLiteral<CouchbaseViewQuery>() {
				 * }).named(COUCHBASE_VIEW_QUERY);
				 */
			}
		});

	}

}
