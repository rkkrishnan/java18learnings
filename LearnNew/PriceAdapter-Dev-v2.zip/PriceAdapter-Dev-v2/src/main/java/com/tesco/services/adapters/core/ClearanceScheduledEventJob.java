package com.tesco.services.adapters.core;

import static com.tesco.services.resources.ScheduledEventResource.getScheduledEventSemaphoreMap;
import static com.tesco.services.utility.PriceUtility.prepareClearanceKey;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.core.Response;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.slf4j.Logger;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tesco.logging.LogWriter;
import com.tesco.logging.LoggerRepository;
import com.tesco.services.Configuration;
import com.tesco.services.CouchbaseViewConfig;
import com.tesco.services.event.core.EventTemplate;
import com.tesco.services.event.core.impl.MapEvent;
import com.tesco.services.event.exception.EventPublishException;
import com.tesco.services.repositories.views.CouchbaseViewRestImpl;
import com.tesco.services.repositories.views.WebViewTemplate;
import com.tesco.services.resources.ScheduledEventResource;
import com.tesco.services.utility.CommonEventPublishingUtility;
import com.tesco.services.utility.PriceConstants;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;

public class ClearanceScheduledEventJob extends CouchbaseViewRestImpl implements
		ScheduledEventJob {

	private static final String PAGE_SIZE = "page.size";

	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(ClearanceScheduledEventJob.class);
	final static private LogWriter REJECTLOGGER = LoggerRepository
			.getLogger("ScheduledEventRejectLogger");

	final static private String ROWS = "rows";
	final static private String VALUE = "value";
	final static private String KEY = "key";
	private Configuration configuration;
	private ObjectMapper mapper;
	private EventTemplate eventTemplate;

	private static final String COUNTRYCODE_GB = "GB";
	private static final String COUNTRYCODE_IE = "IE";
	private static final String COUNTRYCODE_UK = "UK";
	private String eventType;
	WebViewTemplate webViewTemplate;

	@Inject
	public ClearanceScheduledEventJob(
			@Named("configuration") Configuration configuration,
			@Named("jsonmapper") ObjectMapper mapper,
			@Named("rtEventTemplate") EventTemplate eventTemplate,
			String eventType) {
		super(configuration);
		this.configuration = configuration;
		this.mapper = mapper;
		this.eventTemplate = eventTemplate;
		this.eventType = eventType;
	}

	public ClearanceScheduledEventJob(Configuration configuration,
			ObjectMapper mapper, EventTemplate eventTemplate,
			WebViewTemplate webViewTemplate, String eventType) {
		super(configuration);
		this.configuration = configuration;
		this.mapper = mapper;
		this.eventTemplate = eventTemplate;
		this.webViewTemplate = webViewTemplate;
		this.eventType = eventType;
	}

	@Override
	public void run() {
		try {
			processScheduledEvents();
		} catch (Exception exception) {
			ScheduledEventResource.setErrorString(eventType,
					"Error while processing scheduled events of type["
							+ eventType + "]...");
		} finally {
			getScheduledEventSemaphoreMap(eventType).release();
		}
	}

	@Override
	public void processScheduledEvents() {
		JSONArray clearanceEndRowData = null;
		JSONObject clearanceEndDocData = null;
		String resultJsonData = null;
		int pageStartIndex = 0;

		CouchbaseViewConfig clearanceViewConfig = configuration
				.getCouchbaseViewConfig().get(eventType);

		int pageSize = Integer.parseInt(clearanceViewConfig
				.getViewQueryParams().get(PAGE_SIZE));

		String clearanceKey = prepareClearanceKey(clearanceViewConfig);

		Map<String, String> viewQueryDynamicParams = new HashMap<String, String>();
		viewQueryDynamicParams.put(PriceConstants.VIEW_QUERY_KEY, clearanceKey);

		if (webViewTemplate == null) {
			webViewTemplate = createViewTemplate(clearanceViewConfig);
		}

		HashMap<String, MapEvent> clearanceMMStoreMap = new HashMap<>();
		HashMap<String, MapEvent> clearanceRPMStoreMap = new HashMap<>();

		do {
			viewQueryDynamicParams
					.put(PriceConstants.SKIP, "" + pageStartIndex);

			Response viewQueryResponse = webViewTemplate.queryView(
					clearanceViewConfig.getViewQueryParams(),
					viewQueryDynamicParams);

			resultJsonData = viewQueryResponse.readEntity(String.class);

			if (resultJsonData != null) {
				try {
					clearanceEndDocData = new JSONObject(resultJsonData);
					clearanceEndRowData = new JSONArray(clearanceEndDocData
							.getJSONArray(ROWS).toString());
					if (clearanceEndRowData.length() > 0) {
						processPageRecordOfClearanceEndEvent(
								clearanceEndRowData, clearanceMMStoreMap,
								clearanceRPMStoreMap);
						pageStartIndex = pageStartIndex + pageSize;
					}
				} catch (JSONException | IOException exception) {
					LOGGER.error(
							"Error occured while publishing of clearnace end event ",
							exception);
				} catch (Exception exception) {
					LOGGER.error(
							"Error occured while processing clearance end event ",
							exception);
				}
			}
		} while (resultJsonData != null && clearanceEndRowData.length() > 0);
		publishDefferedCleraranceData(clearanceMMStoreMap);
		publishDefferedCleraranceData(clearanceRPMStoreMap);
	}

	@SuppressWarnings("unchecked")
	private void processPageRecordOfClearanceEndEvent(
			JSONArray clearanceEndRowData,
			HashMap<String, MapEvent> clearanceMMStoreMap,
			HashMap<String, MapEvent> clearanceRPMStoreMap)
			throws JSONException, IOException {
		for (int rowIndex = 0; rowIndex < clearanceEndRowData.length(); rowIndex++) {
			Map<String, String> clearanceJsonData = null;
			try {
				JSONObject singleRowData = clearanceEndRowData
						.getJSONObject(rowIndex);
				JSONObject clearanceJson = (JSONObject) singleRowData
						.get(VALUE);
				clearanceJsonData = mapper.readValue(clearanceJson.toString(),
						Map.class);
				String[] effectiveDateWithCountry = getEffectiveDateByCountry(singleRowData);
				MapEvent clearanceEvent = getMapEventByClearanceJsonData(
						clearanceJsonData, effectiveDateWithCountry[0], "1");
				String clearanceKey = buildClearanceKey(clearanceEvent,
						effectiveDateWithCountry[0]);
				if ((clearanceKey).contains(PriceConstants.TPNC_IDENTIFIER)) {
					groupClearanceStoreData(clearanceEvent,
							clearanceRPMStoreMap, effectiveDateWithCountry[0]);
				} else if ((clearanceKey).contains("_"
						+ PriceConstants.STORE_IN_FILE_CODE + "_")) {
					groupClearanceStoreData(clearanceEvent,
							clearanceMMStoreMap, effectiveDateWithCountry[0]);
				} else {
					CommonEventPublishingUtility.publishEvent(eventTemplate,
							clearanceEvent);
				}
			} catch (EventPublishException exception) {
				REJECTLOGGER.info(clearanceJsonData);
			}
		}

	}

	private String[] getEffectiveDateByCountry(JSONObject singleRowData)
			throws JSONException {
		String jsonKey = (String) singleRowData.get(KEY);
		String[] effectiveDateWithCountry = jsonKey.split("_");
		return effectiveDateWithCountry;
	}

	@SuppressWarnings("unchecked")
	private void groupClearanceStoreData(MapEvent clearanceEvent,
			HashMap<String, MapEvent> clearanceMap, String effectiveDate) {
		String clearanceGroupingKey = buildClearanceKey(clearanceEvent,
				effectiveDate);
		if (!clearanceMap.containsKey(clearanceGroupingKey)) {
			clearanceMap.put(clearanceGroupingKey, clearanceEvent);
		} else {
			Set<Map<String, Object>> locations = new HashSet<>(
					(List<Map<String, Object>>) clearanceMap
							.get(clearanceGroupingKey).getPayloadData()
							.get(PriceConstants.CLEARANCES));
			locations
					.add((Map<String, Object>) ((List<Map<String, Object>>) clearanceEvent
							.getPayloadData().get(PriceConstants.CLEARANCES))
							.get(0));
			List<Map<String, Object>> groupedLocations = new ArrayList<Map<String, Object>>(
					locations);
			clearanceMap.get(clearanceGroupingKey).getPayloadData()
					.put(PriceConstants.CLEARANCES, groupedLocations);
			/*
			 * List<Map<String, Object>> locations = (List<Map<String, Object>>)
			 * clearanceMap
			 * .get(clearanceGroupingKey).getPayloadData().get(PriceConstants
			 * .CLEARANCES); locations.add((Map<String, Object>)
			 * ((List<Map<String, Object>>) clearanceEvent.getPayloadData()
			 * .get(PriceConstants.CLEARANCES)).get(0));
			 */
			LOGGER.info("Grouping store data with key: " + clearanceGroupingKey);

		}
	}

	private void publishDefferedCleraranceData(
			HashMap<String, MapEvent> clearanceMap) {
		for (MapEvent clearanceEvent : clearanceMap.values()) {
			try {
				CommonEventPublishingUtility.publishEvent(eventTemplate,
						clearanceEvent);
				LOGGER.debug("Scheduled event for clearance end is published with event data : "
						+ clearanceEvent);
			} catch (EventPublishException exception) {
				LOGGER.error(
						"Error occured while publishing of clearance end event ",
						exception);
			}
		}
	}

	private MapEvent getMapEventByClearanceJsonData(
			Map<String, String> clearanceJsonData, String effectiveDate,
			String leadTime) {
		String productId = clearanceJsonData.get(PriceConstants.PRODUCT_REF);
		String country = clearanceJsonData.get(PriceConstants.COUNTRY);
		// TODO Currently country code not being supported through CSV input
		// file.
		// TODO We are hard coding codes here for time being. We should read
		// country code from input file once supported.
		String countryCode;
		if (COUNTRYCODE_UK.equalsIgnoreCase(country)) {
			countryCode = COUNTRYCODE_GB;
		} else {
			countryCode = COUNTRYCODE_IE;
		}
		String locType = clearanceJsonData.get(PriceConstants.LOC_TYPE);
		String locRef = clearanceJsonData.get(PriceConstants.LOC_REF);
		String clearanceOfferId = clearanceJsonData
				.get(PriceConstants.CLEARANCE_OFFER_ID);
		StringBuilder keyBuilder = new StringBuilder();
		String nationalOrStoreIdentifier;
		if (PriceConstants.ZONE_PREFIX.equals(locType)) {
			nationalOrStoreIdentifier = PriceConstants.NATIONAL_IN_FILE_CODE;
		} else {
			nationalOrStoreIdentifier = PriceConstants.STORE_IN_FILE_CODE;
		}
		keyBuilder.append(productId).append("_")
				.append(nationalOrStoreIdentifier).append("_").append(country)
				.append("_").append(effectiveDate).append("_")
				.append(eventType);
		List<Map<String, Object>> locations = new ArrayList<Map<String, Object>>();
		Map<String, Object> clearanceMap = new HashMap<>();
		Map<String, Object> locationMap = new HashMap<String, Object>();
		locationMap.put(PriceConstants.LOC_TYPE, locType);
		locationMap.put(PriceConstants.LOC_REF, locRef);
		clearanceMap.put(PriceConstants.PRICING_LOC, locationMap);
		clearanceMap.put(PriceConstants.CLEARANCE_OFFER_ID, clearanceOfferId);
		locations.add(clearanceMap);
		MapEvent eventData = CommonEventPublishingUtility
				.createClearanceEventData(productId, leadTime, countryCode,
						locations, keyBuilder.toString(), eventType);
		return eventData;
	}

	@SuppressWarnings("unchecked")
	private String buildClearanceKey(MapEvent clearanceEventData,
			String effectiveDate) {
		StringBuilder keyBuilder = new StringBuilder();
		String productId = (String) clearanceEventData.getPayloadData().get(
				PriceConstants.PRODUCT_REF);
		String nationalOrStoreIdentifier;
		String country = clearanceEventData.getHeaderData().get(
				PriceConstants.COUNTRY);
		List<Map<String, Object>> clearances = (List<Map<String, Object>>) clearanceEventData
				.getPayloadData().get(PriceConstants.CLEARANCES);
		Map<String, Object> locationMap = (Map<String, Object>) clearances.get(
				0).get(PriceConstants.PRICING_LOC);
		String locType = (String) locationMap.get(PriceConstants.LOC_TYPE);
		if (PriceConstants.ZONE_PREFIX.equals(locType)) {
			nationalOrStoreIdentifier = PriceConstants.NATIONAL_IN_FILE_CODE;
		} else {
			nationalOrStoreIdentifier = PriceConstants.STORE_IN_FILE_CODE;
		}
		return keyBuilder.append(productId).append("_")
				.append(nationalOrStoreIdentifier).append("_").append(country)
				.append("_").append(effectiveDate).append("_")
				.append(eventType).toString();
	}

}
