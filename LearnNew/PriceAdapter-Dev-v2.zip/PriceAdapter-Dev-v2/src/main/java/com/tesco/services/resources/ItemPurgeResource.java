package com.tesco.services.resources;

import com.couchbase.client.CouchbaseClient;
import com.couchbase.client.protocol.views.InvalidViewException;
import com.tesco.services.Configuration;
import com.tesco.services.repositories.Repository;
import com.tesco.services.repositories.RepositoryImpl;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import static com.tesco.services.resources.HTTPResponses.badRequest;

/**
 * Created by QT00 on 06/08/2014.
 * PS-114 to get view information from couchbase and process those products which are not update for more than 2 days
 */
@Path("/itempurge")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class ItemPurgeResource {

    private static final Logger LOGGER = (Logger)LoggerFactoryWrapper.getLogger(ImportResource.class);

    private Configuration configuration;
    private CouchbaseClient couchbaseClient;
    private Repository repository;


    /**
     * @param configuration
     * @param couchbaseClient
     * @param repository
     */
    @Inject
    public ItemPurgeResource(
            @Named("configuration") Configuration configuration,
            @Named("couchclient") CouchbaseClient couchbaseClient,
            @Named("repository") Repository repository) {
        this.configuration = configuration;
        this.couchbaseClient = couchbaseClient;
        this.repository = repository;
    }    

    @POST
    @Path("/")
    public Response getRoot(@Context UriInfo uriInfo) {
            LOGGER.info("message : {} {} {}",uriInfo.getRequestUri().toString(),HttpServletResponse.SC_BAD_REQUEST,HTTPResponses.INVALID_REQUEST );

        return badRequest();
    }

    @POST
    @Path("/purge")
    /**
     * Response purgeUnUpdatedItems
     */
    public Response purgeUnUpdatedItems() {
        try {
			((RepositoryImpl)repository).purgeUnUpdatedItems(couchbaseClient, configuration);
        }catch(InvalidViewException e){
                LOGGER.error("error : Item purge failed due to error {}",e);

            return Response.status(HttpServletResponse.SC_INTERNAL_SERVER_ERROR).entity("{\"error\":\"Item purge failed as View not found\"}").build();
        } catch (Exception e) {
                LOGGER.error("error : Item purge failed due to error {}",e);

            return Response.status(HttpServletResponse.SC_INTERNAL_SERVER_ERROR).entity("{\"error\":\"Item purge failed due to error\"}").build();
        }
            LOGGER.info("message : Purge operation completed");

        return Response.ok("{\"message\":\"Purge Completed\"}").build();
    }

    


}
