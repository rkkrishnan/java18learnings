package com.tesco.services.adapters.promotion;

import java.util.Map;

import com.tesco.promotion.core.PrmPrcChgDesc;
import com.tesco.services.adapters.core.exceptions.PromotionEventException;


/**
 * This interface is used to publish promotion events
 * @author jd02
 *
 */
public interface PromotionEventHandler {

	public String publishPromotionEvent(Map<String,String> promotionMapData) throws PromotionEventException;

	public void processPromotionEvents(String promoMsgType, String promoMsgForZoneId,
			String promoMsgLocType, Map<String, Object> allEventsData) throws PromotionEventException;

}
