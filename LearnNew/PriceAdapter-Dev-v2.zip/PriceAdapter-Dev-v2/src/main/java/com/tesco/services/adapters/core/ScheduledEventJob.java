package com.tesco.services.adapters.core;

public interface ScheduledEventJob extends Runnable {

	void processScheduledEvents();
}
