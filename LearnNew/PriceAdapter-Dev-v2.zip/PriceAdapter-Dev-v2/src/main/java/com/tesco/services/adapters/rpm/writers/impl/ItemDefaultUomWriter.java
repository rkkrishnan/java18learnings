package com.tesco.services.adapters.rpm.writers.impl;

import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.exceptions.ColumnNotFoundException;
import com.tesco.services.adapters.core.exceptions.WriterBusinessException;
import com.tesco.services.adapters.rpm.readers.PriceServiceCSVReader;
import com.tesco.services.adapters.rpm.readers.impl.PriceServiceRPMClearanceCSVReaderImpl;
import com.tesco.services.adapters.rpm.writers.CSVHeaders;
import com.tesco.services.adapters.rpm.writers.Writer;
import com.tesco.services.core.ItemDefaultUomSubEntity;
import com.tesco.services.repositories.Repository;
import com.tesco.services.repositories.RepositoryImpl;
import com.tesco.services.resources.ImportResource;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.PriceConstants;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import java.io.IOException;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class ItemDefaultUomWriter implements Writer {

	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger("Item Default UOM Import");

	private Configuration configuration;
	private String runIdentifier;

	public void setRepository(RepositoryImpl repository) {
		this.repository = repository;
	}

	private Repository repository;
	private PriceServiceCSVReader itemDefaultUomMappingReader;
	private Set<String> itemDefaultUomRejects;

	@Inject
	public ItemDefaultUomWriter(
			@Named("configuration") Configuration configuration,
			@Named("repository") Repository repository) {
		this.configuration = configuration;
		this.repository = repository;
	}

	public ItemDefaultUomWriter(Configuration configuration,
			RepositoryImpl repository,
			PriceServiceCSVReader itemDefaultUomMappingReader) {
		this.configuration = configuration;
		this.repository = repository;
		this.itemDefaultUomMappingReader = itemDefaultUomMappingReader;
	}

	public String getRunIdentifier() {
		return runIdentifier;
	}

	public void setRunIdentifier(String runIdentifier) {
		this.runIdentifier = runIdentifier;
	}

	public PriceServiceCSVReader createItemDefaultUomReader(String fileName)
			throws WriterBusinessException {

		PriceServiceCSVReader csvreader = null;
		try {
			csvreader = new PriceServiceRPMClearanceCSVReaderImpl(
					configuration.getRpmItemDefaultUomDump() + "/"
							+ getRunIdentifier() + "/" + fileName,
					CSVHeaders.ItemDefaultUOMHeaders.HEADERS);
		} catch (IOException | ColumnNotFoundException e) {
			LOGGER.error(
					"Error occured in initializing PriceServiceCSVReader for ItemDefaultUomWriter.",
					e);
		}
		return csvreader;
	}

	public void write(String fileName) throws WriterBusinessException {
		LOGGER.info("Importing Item Default Uom into Couchbase");
		if (itemDefaultUomMappingReader == null) {
			itemDefaultUomMappingReader = createItemDefaultUomReader(fileName);
		}
		try {
			writeItemDefaultMapping();
		} catch (Exception e) {
			ImportResource.setErrorString(runIdentifier, e.toString());
			LOGGER.error("Error importing data", e);
			throw new WriterBusinessException(e.getMessage(), e.getCause());
		} finally {
			ImportResource.getImportSemaphoreForIdentifier(fileName).release();

			if (!itemDefaultUomRejects.isEmpty()) {
				String date = Dockyard.getSysDate("yyyyMMddHHmmss");

				String rejectfilepath = configuration.getRejectFilePath();

				if (rejectfilepath != null && rejectfilepath.length() > 0) {
					new Dockyard().writeProductDetailsToFile(rejectfilepath
							+ "/REJECT_FILE_" + runIdentifier + "_" + date
							+ ".log", itemDefaultUomRejects);

				} else {
					LOGGER.error("Invalid reject file path : {}",
							rejectfilepath);
				}
				itemDefaultUomRejects.clear();

			}
		}
	}

	// Moved to sync call for PRIS-2203
	private void writeItemDefaultMapping() throws IOException {
		itemDefaultUomRejects = new HashSet<>();
		Map<String, String> itemDefaultMapping;
		int count = 0;
		int recordsInsertedCount = 0;
		int recordsRejectedCount = 0;
		int recordsTotalRead = 0;

		ItemDefaultUomSubEntity itemDefaultUomSubEntity = new ItemDefaultUomSubEntity();
		while ((itemDefaultMapping = itemDefaultUomMappingReader.getNext()) != null) {
			count++;
			recordsTotalRead++;
			String tpnb = itemDefaultMapping
					.get(CSVHeaders.ItemDefaultUOMHeaders.TPNB);

			if (!Dockyard.isSpaceOrNull(tpnb)) {
				String sellByType = itemDefaultMapping
						.get(CSVHeaders.ItemDefaultUOMHeaders.SELL_BY_TYPE);
				if (!Dockyard.isSpaceOrNull(sellByType)) {
					if (PriceConstants.SELL_BY_TYPE_INDIVIDUAL
							.equals(sellByType)
							|| PriceConstants.SELL_BY_TYPE_SINGLE
									.equals(sellByType)) {
						String defaultUom = itemDefaultMapping
								.get(CSVHeaders.ItemDefaultUOMHeaders.DEFAULT_UOM);
						String tpnbKey = PriceConstants.PRODUCT_TPNB_KEY + ":"
								+ tpnb;
						itemDefaultUomSubEntity
								.setProdRef(PriceConstants.TPNB_IDENTIFIER
										+ ":" + tpnb);
						itemDefaultUomSubEntity.setLastUpdateDate(Dockyard
								.getSysDate(PriceConstants.ISO_8601_FORMAT));
						itemDefaultUomSubEntity
								.setLastUpdatedById(PriceConstants.ITEM_DFLT_UPDATED_BY);
						itemDefaultUomSubEntity.setSellByType(sellByType);
						if (Dockyard.isSpaceOrNull(defaultUom)) {
							itemDefaultUomSubEntity.setDefaultUOM(null);
						} else {
							itemDefaultUomSubEntity.setDefaultUOM(defaultUom);
						}

						try {
							repository.insertObject(tpnbKey,
									itemDefaultUomSubEntity);
							recordsInsertedCount++;
						} catch (Exception e) {
							recordsRejectedCount++;
							itemDefaultUomRejects
									.add(Dockyard
											.getSysDate(
													PriceConstants.ISO_8601_FORMAT)
											.concat("~<ITEM DEFAULT UOM>~")
											.concat("Error"
													+ e.getMessage()
													+ " occurred when inserting document into couchbase for prodRef:")
											.concat(tpnb));
							LOGGER.error(
									"Error occurred when inserting document into couchbase for prodRef: "
											+ tpnbKey, e);
						}
					}

				} else {
					recordsRejectedCount++;
					itemDefaultUomRejects.add(Dockyard
							.getSysDate(PriceConstants.ISO_8601_FORMAT)
							.concat("~<ITEM DEFAULT UOM>~")
							.concat("The sell by type is null for the item:")
							.concat(tpnb));

				}

			} else {
				recordsRejectedCount++;
				itemDefaultUomRejects.add(Dockyard
						.getSysDate(PriceConstants.ISO_8601_FORMAT)
						.concat("~<ITEM DEFAULT UOM>~")
						.concat("The item does not exist at the line number:")
						.concat(String.valueOf(count)));
			}
		}

		// Added for PRIS-2203
		LOGGER.info("ItemDefaultUOM documents processed : "
				+ recordsInsertedCount);
		LOGGER.info("ItemDefaultUOM documents rejected : "
				+ recordsRejectedCount);
		LOGGER.info("Total ItemDefaultUOM documents read : " + recordsTotalRead);

	}

}
