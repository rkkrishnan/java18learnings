package com.tesco.services.core.promotion;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

/**
 * Created by iv16 on 1/1/2016.
 */
public class ProductOffersPromotionEntity {
	@JsonProperty("offerId")
	public String offerId;

	@JsonProperty("name")
	public String name;

	@JsonProperty("offerType")
	public String offerType;

	@JsonProperty("createDateTime")
	public String createDateTime;

	@JsonProperty("lastUpdateDateTime")
	public String lastUpdateDateTime;

	@JsonProperty("multiBuyPromoType")
	public String multiBuyPromoType  ;

	@JsonProperty("mbBuyGetListInd")
	public String mbBuyGetListInd;

	@JsonProperty("wasPrice")
	public String wasPrice;

	@JsonProperty("wasWasPrice")
	public String wasWasPrice;

	@JsonProperty("posLabelReqInd")
	public String posLabelReqInd;

	@JsonProperty("effectiveDate")
	public String effectiveDate;

	@JsonProperty("endDate")
	public String endDate;

	@JsonProperty("cfDescription1")
	public String cfDescription1;

	@JsonProperty("cfDescription2")
	public String cfDescription2;

	@JsonProperty("rpmPromoCompDetailId")
	public String rpmPromoCompDetailId;


	@JsonProperty("promoThresholds")
	public List<PromoThresholdEntity> promoThresholdEntities;

	@JsonProperty("promoRewards")
	public List<PromoRewardEntity> promoRewardEntities;

	@JsonProperty("offerId")
	public String getOfferId() {
		return offerId;
	}

	@JsonProperty("offerId")
	public void setOfferId(String offerId) {
		this.offerId = offerId;
	}

	@JsonProperty("name")
	public String getName() {
		return name;
	}

	@JsonProperty("name")
	public void setName(String name) {
		this.name = name;
	}

	@JsonProperty("offerType")
	public String getOfferType() {
		return offerType;
	}

	@JsonProperty("offerType")
	public void setOfferType(String offerType) {
		this.offerType = offerType;
	}

	@JsonProperty("createDateTime")
	public String getCreateDateTime() {
		return createDateTime;
	}

	@JsonProperty("createDateTime")
	public void setCreateDateTime(String createDateTime) {
		this.createDateTime = createDateTime;
	}

	@JsonProperty("lastUpdateDateTime")
	public String getLastUpdateDateTime() {
		return lastUpdateDateTime;
	}

	@JsonProperty("lastUpdateDateTime")
	public void setLastUpdateDateTime(String lastUpdateDateTime) {
		this.lastUpdateDateTime = lastUpdateDateTime;
	}

	@JsonProperty("multiBuyPromoType")
	public String getMultiBuyPromoType() {
		return multiBuyPromoType;
	}

	@JsonProperty("multiBuyPromoType")
	public void setMultiBuyPromoType(String multiBuyPromoType) {
		this.multiBuyPromoType = multiBuyPromoType;
	}

	@JsonProperty("wasPrice")
	public String getWasPrice() {
		return wasPrice;
	}

	@JsonProperty("wasPrice")
	public void setWasPrice(String wasPrice) {
		this.wasPrice = wasPrice;
	}

	@JsonProperty("wasWasPrice")
	public String getWasWasPrice() {
		return wasWasPrice;
	}

	@JsonProperty("wasWasPrice")
	public void setWasWasPrice(String wasWasPrice) {
		this.wasWasPrice = wasWasPrice;
	}

	@JsonProperty("posLabelReqInd")
	public String getPosLabelReqInd() {
		return posLabelReqInd;
	}

	@JsonProperty("posLabelReqInd")
	public void setPosLabelReqInd(String posLabelReqInd) {
		this.posLabelReqInd = posLabelReqInd;
	}

	@JsonProperty("effectiveDate")
	public String getEffectiveDate() {
		return effectiveDate;
	}

	@JsonProperty("effectiveDate")
	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	@JsonProperty("endDate")
	public String getEndDate() {
		return endDate;
	}

	@JsonProperty("endDate")
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	@JsonProperty("cfDescription1")
	public String getCfDescription1() {
		return cfDescription1;
	}

	@JsonProperty("cfDescription1")
	public void setCfDescription1(String cfDescription1) {
		this.cfDescription1 = cfDescription1;
	}

	@JsonProperty("cfDescription2")
	public String getCfDescription2() {
		return cfDescription2;
	}

	@JsonProperty("cfDescription2")
	public void setCfDescription2(String cfDescription2) {
		this.cfDescription2 = cfDescription2;
	}

	@JsonProperty("rpmPromoCompDetailId")
	public String getRpmPromoCompDetailId() {
		return rpmPromoCompDetailId;
	}

	@JsonProperty("rpmPromoCompDetailId")
	public void setRpmPromoCompDetailId(String rpmPromoCompDetailId) {
		this.rpmPromoCompDetailId = rpmPromoCompDetailId;
	}

	@JsonProperty("promoThresholds")
	public List<PromoThresholdEntity> getPromoThresholdEntities() {
		return promoThresholdEntities;
	}

	@JsonProperty("promoThresholds")
	public void setPromoThresholdEntities(
			List<PromoThresholdEntity> promoThresholdEntities) {
		this.promoThresholdEntities = promoThresholdEntities;
	}

	@JsonProperty("promoRewards")
	public List<PromoRewardEntity> getPromoRewardEntities() {
		return promoRewardEntities;
	}

	@JsonProperty("promoRewards")
	public void setPromoRewardEntities(
			List<PromoRewardEntity> promoRewardEntities) {
		this.promoRewardEntities = promoRewardEntities;
	}

	public String getMbBuyGetListInd() {
		return mbBuyGetListInd;
	}

	public void setMbBuyGetListInd(String mbBuyGetListInd) {
		this.mbBuyGetListInd = mbBuyGetListInd;
	}

	@Override public String toString() {
		return "ProductOffersPromotionEntity{" +
				"offerId='" + offerId + '\'' +
				", name='" + name + '\'' +
				", offerType='" + offerType + '\'' +
				", createDateTime='" + createDateTime + '\'' +
				", lastUpdateDateTime='" + lastUpdateDateTime + '\'' +
				", multiBuyPromoType='" + multiBuyPromoType + '\'' +
				", mbBuyGetListInd='" + mbBuyGetListInd + '\'' +
				", wasPrice='" + wasPrice + '\'' +
				", wasWasPrice='" + wasWasPrice + '\'' +
				", posLabelReqInd='" + posLabelReqInd + '\'' +
				", effectiveDate='" + effectiveDate + '\'' +
				", endDate='" + endDate + '\'' +
				", cfDescription1='" + cfDescription1 + '\'' +
				", cfDescription2='" + cfDescription2 + '\'' +
				", rpmPromoCompDetailId='" + rpmPromoCompDetailId + '\'' +
				", promoThresholdEntities=" + promoThresholdEntities +
				", promoRewardEntities=" + promoRewardEntities +
				'}';
	}
}
