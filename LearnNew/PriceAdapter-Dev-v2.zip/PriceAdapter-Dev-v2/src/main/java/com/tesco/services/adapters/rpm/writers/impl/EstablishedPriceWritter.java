package com.tesco.services.adapters.rpm.writers.impl;

import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.exceptions.ColumnNotFoundException;
import com.tesco.services.adapters.core.exceptions.WriterBusinessException;
import com.tesco.services.adapters.rpm.events.ClearanceEventHandler;
import com.tesco.services.adapters.rpm.events.impl.ClearanceEventData;
import com.tesco.services.adapters.rpm.readers.PriceServiceCSVReader;
import com.tesco.services.adapters.rpm.readers.impl.PriceServiceRPMClearanceCSVReaderImpl;
import com.tesco.services.adapters.rpm.writers.CSVHeaders;
import com.tesco.services.adapters.rpm.writers.Writer;
import com.tesco.services.core.*;
import com.tesco.services.event.exception.EventPublishException;
import com.tesco.services.exceptions.DataAccessException;
import com.tesco.services.repositories.Repository;
import com.tesco.services.repositories.RepositoryImpl;
import com.tesco.services.resources.ImportResource;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.PriceConstants;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import java.io.IOException;
import java.text.ParseException;
import java.util.*;

import static com.tesco.services.utility.PriceConstants.*;

/**
 * Created by QP65 on 12/11/2015.
 */
public class EstablishedPriceWritter implements Writer {

	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger("Established Price Import");

	private Configuration configuration;
	private String runIdentifier;
	private Repository repository;

	private PriceServiceCSVReader estbPriceReader;
	private Set<String> estbPriceRejTpnbs = new HashSet<>();
	private ClearanceEventHandler clearanceEventHandler;
	ClearanceEventData storeClearanceEventDataMap = new ClearanceEventData();

	@Inject
	public EstablishedPriceWritter(
			@Named("configuration") Configuration configuration,
			@Named("repository") Repository repository,
			@Named("clearanceEventHandler") ClearanceEventHandler clearanceEventHandler) {
		this.configuration = configuration;
		this.repository = repository;
		this.clearanceEventHandler = clearanceEventHandler;
	}

	public EstablishedPriceWritter(Configuration configuration,
			RepositoryImpl repository,
			ClearanceEventHandler clearanceEventHandler,
			PriceServiceCSVReader estbPriceReader) {
		this.configuration = configuration;
		this.repository = repository;
		this.clearanceEventHandler = clearanceEventHandler;
		this.estbPriceReader = estbPriceReader;
	}

	public String getRunIdentifier() {
		return runIdentifier;
	}

	public void setRunIdentifier(String runIdentifier) {
		this.runIdentifier = runIdentifier;
	}

	public PriceServiceCSVReader createEstbPriceReader(String fileName)
			throws WriterBusinessException {
		PriceServiceCSVReader csvreader = null;
		try {
			csvreader = new PriceServiceRPMClearanceCSVReaderImpl(
					configuration.getRpmClrDataDumpPath() + "/" + runIdentifier
							+ "/" + fileName,
					CSVHeaders.EstablishedPriceHeaders.HEADERS);
		} catch (IOException | ColumnNotFoundException e) {
			LOGGER.error(
					"Error occured while initializing PriceServiceCSVReader for EstablishedPriceWritter.",
					e);
			throw new WriterBusinessException(e.getMessage(), e.getCause());
		}
		return csvreader;
	}

	public void write(String fileName) throws WriterBusinessException {
		LOGGER.info("Importing Established pirce info into Couchbase");
		
		if (this.estbPriceReader == null) {
			this.estbPriceReader = createEstbPriceReader(fileName);
		}

		try {
			writeEstbPriceToCB();
		} catch (ArrayIndexOutOfBoundsException exception) {
			ImportResource.setErrorString(fileName,
					"Array index out of bound Exception");
			LOGGER.error("Error importing data", exception.getMessage());
		} catch (Exception e) {
			ImportResource.setErrorString(fileName, e.toString());
			LOGGER.error("Error importing data", e);
			throw new WriterBusinessException(e.getMessage(), e.getCause());
		} finally {
			ImportResource.getImportSemaphoreForIdentifier(fileName).release();

			if (!estbPriceRejTpnbs.isEmpty()) {
				String date = Dockyard.getSysDate("yyyyMMddHHmmss");
				String rejectfilepath = this.configuration.getRejectFilePath();
				if (rejectfilepath != null && rejectfilepath.length() > 0) {
					new Dockyard().writeProductDetailsToFile(rejectfilepath
							+ "/REJECT_FILE_" + runIdentifier + "_" + date
							+ ".log", estbPriceRejTpnbs);

				} else {
					LOGGER.error("Invalid reject file path : {}",
							rejectfilepath);
				}
				estbPriceRejTpnbs.clear();

			}

		}
	}

	private void writeEstbPriceToCB() throws IOException, ParseException,
			DataAccessException, EventPublishException {

		Map<String, String> estbPriceMappingMap;

		String prevTpnb = null;
		String curTpnb = null;
		boolean isNewTpnb = false;
		int recordsInsertedCount = 0;
		int recordsRejectedCount = 0;
		int recordsTotalRead = 0;

		ClearanceProduct clearanceProduct = null;
		ClearanceEventData zoneClearanceEventDataMap = new ClearanceEventData();
		storeClearanceEventDataMap = new ClearanceEventData();

		while ((estbPriceMappingMap = estbPriceReader.getNext()) != null) {

			recordsTotalRead++;
			curTpnb = estbPriceMappingMap.get(
					PriceConstants.ITEM_TYPE.TPNB.value()).split("-")[0];

			if (Dockyard.isSpaceOrNull(prevTpnb)
					&& !Dockyard.isSpaceOrNull(curTpnb)) {
				isNewTpnb = true;
			} else if (prevTpnb != null && !curTpnb.equals(prevTpnb)) {
				try {
					insertEstbPriceData(clearanceProduct,
							zoneClearanceEventDataMap);
					recordsInsertedCount++;
				} catch (Exception ex) {
					recordsRejectedCount++;
					estbPriceRejTpnbs
							.add(Dockyard
									.getSysDate(PriceConstants.ISO_8601_FORMAT)
									+ "~ ESTABLISHED PRICE ~ "
									+ "Line No: "
									+ estbPriceMappingMap
											.get(CSVHeaders.EstablishedPriceHeaders.LINE_NOR)
									+ "~ "
									+ "Tpnb: "
									+ curTpnb
									+ " has DB issue");
					LOGGER.error("~ ESTABLISHED PRICE ~ "
							+ "Line No: "
							+ estbPriceMappingMap
									.get(CSVHeaders.EstablishedPriceHeaders.LINE_NOR)
							+ "~ " + "Tpnb: " + curTpnb
							+ " has couchbase DB error : " + ex.getMessage());
				}
				clearanceProduct = null;
				zoneClearanceEventDataMap = new ClearanceEventData();
				isNewTpnb = true;
			}

			if (isNewTpnb) {
				clearanceProduct = (ClearanceProduct) repository
						.getGenericObject(PriceConstants.RPM_CLR_PRODUCT
								+ curTpnb, ClearanceProduct.class);
				if (clearanceProduct == null) {
					recordsRejectedCount++;
					estbPriceRejTpnbs
							.add(Dockyard
									.getSysDate(PriceConstants.ISO_8601_FORMAT)
									+ "~ ESTABLISHED PRICE ~ "
									+ "Line No: "
									+ estbPriceMappingMap
											.get(CSVHeaders.EstablishedPriceHeaders.LINE_NOR)
									+ "~ "
									+ "Tpnb: "
									+ curTpnb
									+ " is not present in Price Service");
					LOGGER.error("~ ESTABLISHED PRICE ~ "
							+ "Line No: "
							+ estbPriceMappingMap
									.get(CSVHeaders.EstablishedPriceHeaders.LINE_NOR)
							+ "~ " + "Tpnb: " + curTpnb
							+ " is not present in Price Service");
				}
			}

			if (clearanceProduct != null) {
				buildClrDataForEstbPrice(estbPriceMappingMap, curTpnb,
						clearanceProduct, zoneClearanceEventDataMap);
			}

			prevTpnb = curTpnb;
			isNewTpnb = false;

		}

		if (clearanceProduct != null) {
			try {
				insertEstbPriceData(clearanceProduct, zoneClearanceEventDataMap);
				recordsInsertedCount++;
			} catch (Exception ex) {
				recordsRejectedCount++;
				estbPriceRejTpnbs.add(Dockyard
						.getSysDate(PriceConstants.ISO_8601_FORMAT)
						+ "~ ESTABLISHED PRICE ~ "
						+ "Tpnb: "
						+ clearanceProduct.getProductId() + " has DB issue");
				LOGGER.error("~ ESTABLISHED PRICE ~ " + "Tpnb: "
						+ clearanceProduct.getProductId()
						+ " has couchbase DB error : " + ex.getMessage());
			}
			clearanceProduct = null;
			if (storeClearanceEventDataMap.size() > 0) {
				clearanceEventHandler
						.publishEventsForPreviousPriceChangeClearances(storeClearanceEventDataMap);
			}
		}

		// Added for PRIS-2203
		LOGGER.info("EstablishedPrice records inserted : "
				+ recordsInsertedCount);
		LOGGER.info("EstablishedPrice records rejected : "
				+ recordsRejectedCount);
		LOGGER.info("Total EstablishedPrice records read : " + recordsTotalRead);
	}

	private void insertEstbPriceData(ClearanceProduct clearanceProduct,
			ClearanceEventData clearanceEventDataMap) throws Exception {
		if (clearanceProduct != null) {
			repository.insertObject(PriceConstants.RPM_CLR_PRODUCT
					+ clearanceProduct.getProductId(), clearanceProduct);
			if (clearanceEventDataMap.size() > 0) {
				clearanceEventHandler
						.publishEventsForPreviousPriceChangeClearances(clearanceEventDataMap);
			}
		}
	}

	private void buildClrDataForEstbPrice(
			Map<String, String> estbPriceMappingMap, String curTpnb,
			ClearanceProduct clearanceProduct,
			ClearanceEventData zoneClearanceEventDataMap) throws ParseException {
		String curTpnc;
		String locType;
		String effDate;

		Map<String, ClearanceProductVariant> tpncToClearanceProductVariant;
		ClearanceProductVariant clearanceProductVariant;
		Map<String, ClearanceZoneSaleInfo> zonePrices;
		ClearanceZoneSaleInfo clearanceZoneSaleInfo;
		Map<String, ClearanceStoreSaleInfo> storeExceptions;
		ClearanceStoreSaleInfo clearanceStoreSaleInfo;
		ClearanceByDateTime clearanceByDateTime;
		List<EstablishedPriceInfo> establishedPriceInfos;

		tpncToClearanceProductVariant = clearanceProduct
				.getTpncToClearanceProductVariant();
		curTpnc = estbPriceMappingMap
				.get(PriceConstants.ITEM_TYPE.TPNC.value());

		if (tpncToClearanceProductVariant.keySet().contains(curTpnc)) {
			clearanceProductVariant = tpncToClearanceProductVariant
					.get(curTpnc);

			if ("1".equals(estbPriceMappingMap
					.get(CSVHeaders.EstablishedPriceHeaders.ZONE_NODE_TYPE))) {
				zonePrices = clearanceProductVariant.getZonePrices();
				locType = estbPriceMappingMap
						.get(CSVHeaders.EstablishedPriceHeaders.ZONE_ID);

				if (zonePrices != null && zonePrices.keySet().contains(locType)) {
					clearanceZoneSaleInfo = zonePrices.get(locType);
					effDate = Dockyard
							.getFormattedDate(
									estbPriceMappingMap
											.get(CSVHeaders.EstablishedPriceHeaders.EFFECTIVE_DATE),
									PriceConstants.PROMO_MSG_DATE_FORMAT,
									PriceConstants.DATE_FORMAT_YYYYMMDDHHMMSS);

					clearanceByDateTime = clearanceZoneSaleInfo
							.getZoneClearancePriceByDateTime(effDate);
					if (clearanceByDateTime != null) {
						establishedPriceInfos = setEstbPriceInfoForClrObj(estbPriceMappingMap);
						if (establishedPriceInfos != null) {
							clearanceByDateTime
									.setEstablishedPriceInfos(establishedPriceInfos);
							prepareZoneClearanceEventData(estbPriceMappingMap,
									clearanceProduct, zoneClearanceEventDataMap);
						}
					} else {
						estbPriceRejTpnbs
								.add(Dockyard
										.getSysDate(PriceConstants.ISO_8601_FORMAT)
										+ "~ ESTABLISHED PRICE ~ "
										+ "Line No: "
										+ estbPriceMappingMap
												.get(CSVHeaders.EstablishedPriceHeaders.LINE_NOR)
										+ "~ "
										+ "Tpnb: "
										+ curTpnb
										+ " Tpnc: "
										+ curTpnc
										+ " Zone: "
										+ locType
										+ " No clearance for "
										+ effDate
										+ " in Price Service");
						LOGGER.error("~ ESTABLISHED PRICE ~ "
								+ "Line No: "
								+ estbPriceMappingMap
										.get(CSVHeaders.EstablishedPriceHeaders.LINE_NOR)
								+ "~ " + "Tpnb: " + curTpnb + " Tpnc: "
								+ curTpnc + " Zone: " + locType
								+ " No clearance for " + effDate
								+ " in Price Service");
					}

				} else {
					estbPriceRejTpnbs
							.add(Dockyard
									.getSysDate(PriceConstants.ISO_8601_FORMAT)
									+ "~ ESTABLISHED PRICE ~ "
									+ "Line No: "
									+ estbPriceMappingMap
											.get(CSVHeaders.EstablishedPriceHeaders.LINE_NOR)
									+ "~ "
									+ "Tpnb: "
									+ curTpnb
									+ " Tpnc: "
									+ curTpnc
									+ " Zone: "
									+ locType
									+ " is not available in Price Service");
					LOGGER.error("~ ESTABLISHED PRICE ~ "
							+ "Line No: "
							+ estbPriceMappingMap
									.get(CSVHeaders.EstablishedPriceHeaders.LINE_NOR)
							+ "~ " + "For Tpnb: " + curTpnb + " Tpnc: "
							+ curTpnc + " Zone: " + locType
							+ " is not available in Price Service");
				}
			} else if ("0".equals(estbPriceMappingMap
					.get(CSVHeaders.EstablishedPriceHeaders.ZONE_NODE_TYPE))) {
				storeExceptions = clearanceProductVariant.getStoreExceptions();
				locType = estbPriceMappingMap
						.get(CSVHeaders.EstablishedPriceHeaders.LOCATION);

				if (storeExceptions != null
						&& storeExceptions.keySet().contains(locType)) {
					clearanceStoreSaleInfo = storeExceptions.get(locType);
					effDate = Dockyard
							.getFormattedDate(
									estbPriceMappingMap
											.get(CSVHeaders.EstablishedPriceHeaders.EFFECTIVE_DATE),
									PriceConstants.PROMO_MSG_DATE_FORMAT,
									PriceConstants.DATE_FORMAT_YYYYMMDDHHMMSS);
					clearanceByDateTime = clearanceStoreSaleInfo
							.getStoreClearancePriceByDateTime(effDate);

					if (clearanceByDateTime != null) {
						establishedPriceInfos = setEstbPriceInfoForClrObj(estbPriceMappingMap);
						if (establishedPriceInfos != null) {
							clearanceByDateTime
									.setEstablishedPriceInfos(establishedPriceInfos);
							prepareStoreClearanceEventData(estbPriceMappingMap,
									clearanceProduct,
									storeClearanceEventDataMap);
						}

					} else {
						estbPriceRejTpnbs
								.add(Dockyard
										.getSysDate(PriceConstants.ISO_8601_FORMAT)
										+ "~ ESTABLISHED PRICE ~ "
										+ "Line No: "
										+ estbPriceMappingMap
												.get(CSVHeaders.EstablishedPriceHeaders.LINE_NOR)
										+ "~ "
										+ "Tpnb: "
										+ curTpnb
										+ " Tpnc: "
										+ curTpnc
										+ " Store: "
										+ locType
										+ " No clearance for "
										+ effDate
										+ " in Price Service");
						LOGGER.error("~ ESTABLISHED PRICE ~ "
								+ "Line No: "
								+ estbPriceMappingMap
										.get(CSVHeaders.EstablishedPriceHeaders.LINE_NOR)
								+ "~ " + "For Tpnb: " + curTpnb + " Tpnc: "
								+ curTpnc + " Store: " + locType
								+ " No clearance for " + effDate
								+ " in Price Service");
					}

				} else {
					estbPriceRejTpnbs
							.add(Dockyard
									.getSysDate(PriceConstants.ISO_8601_FORMAT)
									+ "~ ESTABLISHED PRICE ~ "
									+ "Line No: "
									+ estbPriceMappingMap
											.get(CSVHeaders.EstablishedPriceHeaders.LINE_NOR)
									+ "~ "
									+ "Tpnb: "
									+ curTpnb
									+ " Tpnc: "
									+ curTpnc
									+ " Store: "
									+ locType
									+ " is not available in Price Service");
					LOGGER.error("~ ESTABLISHED PRICE ~ "
							+ "Line No: "
							+ estbPriceMappingMap
									.get(CSVHeaders.EstablishedPriceHeaders.LINE_NOR)
							+ "~ " + "Tpnb: " + curTpnb + " Tpnc: " + curTpnc
							+ " Store: " + locType
							+ " is not available in Price Service");
				}
			}

		} else {
			estbPriceRejTpnbs.add(Dockyard
					.getSysDate(PriceConstants.ISO_8601_FORMAT)
					+ "~ ESTABLISHED PRICE ~ "
					+ "Line No: "
					+ estbPriceMappingMap
							.get(CSVHeaders.EstablishedPriceHeaders.LINE_NOR)
					+ "~ "
					+ "Tpnb: "
					+ curTpnb
					+ " Tpnc: "
					+ curTpnc
					+ " is not available in Price Service");
			LOGGER.error("~ ESTABLISHED PRICE ~ "
					+ "Line No: "
					+ estbPriceMappingMap
							.get(CSVHeaders.EstablishedPriceHeaders.LINE_NOR)
					+ "~ " + "Tpnb: " + curTpnb + " Tpnc: " + curTpnc
					+ " is not available in Price Service");
		}
	}

	private List<EstablishedPriceInfo> setEstbPriceInfoForClrObj(
			Map<String, String> estbPriceMappingMap) throws ParseException {
		String estbPricePh1;
		String estbPricePh2;
		String estbPricePh3;
		EstablishedPriceInfo establishedPriceInfo1;
		EstablishedPriceInfo establishedPriceInfo2;
		EstablishedPriceInfo establishedPriceInfo3;
		List<EstablishedPriceInfo> establishedPriceInfos = new ArrayList<>();

		estbPricePh1 = estbPriceMappingMap
				.get(CSVHeaders.EstablishedPriceHeaders.TSL_ESTABLISHED_PRICE_PH1);
		estbPricePh2 = estbPriceMappingMap
				.get(CSVHeaders.EstablishedPriceHeaders.TSL_ESTABLISHED_PRICE_PH2);
		estbPricePh3 = estbPriceMappingMap
				.get(CSVHeaders.EstablishedPriceHeaders.TSL_ESTABLISHED_PRICE_PH3);

		if (estbPricePh1 != null && !estbPricePh1.isEmpty()) {
			establishedPriceInfo1 = new EstablishedPriceInfo();
			establishedPriceInfo1.setPhase("1");
			establishedPriceInfo1
					.setPrevPrice(estbPriceMappingMap
							.get(CSVHeaders.EstablishedPriceHeaders.TSL_ESTABLISHED_PRICE_PH1));
			establishedPriceInfo1
					.setStartDate(Dockyard.getFormattedDate(
							estbPriceMappingMap
									.get(CSVHeaders.EstablishedPriceHeaders.P1_START_DATE),
							PriceConstants.PROMO_MSG_DATE_FORMAT,
							PriceConstants.ISO_8601_FORMAT));
			establishedPriceInfo1
					.setEndDate(Dockyard.getFormattedDate(
							estbPriceMappingMap
									.get(CSVHeaders.EstablishedPriceHeaders.P1_END_DATE),
							PriceConstants.PROMO_MSG_DATE_FORMAT,
							PriceConstants.ISO_8601_FORMAT));

			establishedPriceInfos.add(establishedPriceInfo1);
		}

		if (estbPricePh2 != null && !estbPricePh2.isEmpty()) {
			establishedPriceInfo2 = new EstablishedPriceInfo();
			establishedPriceInfo2.setPhase("2");
			establishedPriceInfo2
					.setPrevPrice(estbPriceMappingMap
							.get(CSVHeaders.EstablishedPriceHeaders.TSL_ESTABLISHED_PRICE_PH2));
			establishedPriceInfo2
					.setStartDate(Dockyard.getFormattedDate(
							estbPriceMappingMap
									.get(CSVHeaders.EstablishedPriceHeaders.P2_START_DATE),
							PriceConstants.PROMO_MSG_DATE_FORMAT,
							PriceConstants.ISO_8601_FORMAT));
			establishedPriceInfo2
					.setEndDate(Dockyard.getFormattedDate(
							estbPriceMappingMap
									.get(CSVHeaders.EstablishedPriceHeaders.P2_END_DATE),
							PriceConstants.PROMO_MSG_DATE_FORMAT,
							PriceConstants.ISO_8601_FORMAT));

			establishedPriceInfos.add(establishedPriceInfo2);
		}

		if (estbPricePh3 != null && !estbPricePh3.isEmpty()) {
			establishedPriceInfo3 = new EstablishedPriceInfo();
			establishedPriceInfo3.setPhase("3");
			establishedPriceInfo3
					.setPrevPrice(estbPriceMappingMap
							.get(CSVHeaders.EstablishedPriceHeaders.TSL_ESTABLISHED_PRICE_PH3));
			establishedPriceInfo3
					.setStartDate(Dockyard.getFormattedDate(
							estbPriceMappingMap
									.get(CSVHeaders.EstablishedPriceHeaders.P3_START_DATE),
							PriceConstants.PROMO_MSG_DATE_FORMAT,
							PriceConstants.ISO_8601_FORMAT));
			establishedPriceInfo3
					.setEndDate(Dockyard.getFormattedDate(
							estbPriceMappingMap
									.get(CSVHeaders.EstablishedPriceHeaders.P3_END_DATE),
							PriceConstants.PROMO_MSG_DATE_FORMAT,
							PriceConstants.ISO_8601_FORMAT));
			establishedPriceInfos.add(establishedPriceInfo3);
		}

		if (estbPricePh1.isEmpty() && estbPricePh2.isEmpty()
				&& estbPricePh3.isEmpty()) {
			estbPriceRejTpnbs.add(Dockyard
					.getSysDate(PriceConstants.ISO_8601_FORMAT)
					+ "~ ESTABLISHED PRICE ~ "
					+ "Line No: "
					+ estbPriceMappingMap
							.get(CSVHeaders.EstablishedPriceHeaders.LINE_NOR)
					+ "~ "
					+ "No establish price for Tpnb: "
					+ estbPriceMappingMap.get(PriceConstants.ITEM_TYPE.TPNB
							.value())
					+ " Tpnc: "
					+ estbPriceMappingMap.get(PriceConstants.ITEM_TYPE.TPNC
							.value()));
			LOGGER.error("~ ESTABLISHED PRICE ~ "
					+ "Line No: "
					+ estbPriceMappingMap
							.get(CSVHeaders.EstablishedPriceHeaders.LINE_NOR)
					+ "~ "
					+ "No establish price for Tpnb: "
					+ estbPriceMappingMap.get(PriceConstants.ITEM_TYPE.TPNB
							.value())
					+ " Tpnc: "
					+ estbPriceMappingMap.get(PriceConstants.ITEM_TYPE.TPNC
							.value()));
		}
		return !establishedPriceInfos.isEmpty() ? establishedPriceInfos : null;
	}

	/*
	 * This method prepare Event Data for RPM Established Zone clearances
	 */
	private void prepareZoneClearanceEventData(
			Map<String, String> estblishedPriceMap,
			ClearanceProduct clearanceProduct,
			ClearanceEventData clearanceEventDataMap) throws ParseException {

		Set<String> zoneClearanceSet = null;
		String locationType = ZONE_PREFIX;
		String currentTpnc = estblishedPriceMap
				.get(CSVHeaders.EstablishedPriceHeaders.TPNC);
		String locationId = estblishedPriceMap
				.get(CSVHeaders.EstablishedPriceHeaders.ZONE_ID);
		ClearanceZoneSaleInfo zoneData = clearanceProduct
				.getTpncToClearanceProductVariant().get(currentTpnc)
				.getZonePrices().get(locationId);
		String country = zoneData.getCountryCode();

		// TODO Currently country code reading from CB have 'UK'nstead of
		// 'GB.This check will be applicable only up to the CB Doc updation
		// from UK to GB will complete

		if (country.equals(LOC_REF_COUNTRY)) {
			country = LOC_REF_COUNTRYCODE_UK;
		}
		String effectiveDate = Dockyard.getFormattedDate(estblishedPriceMap
				.get(CSVHeaders.EstablishedPriceHeaders.EFFECTIVE_DATE),
				PROMO_MSG_DATE_FORMAT, DATE_FORMAT_YYYYMMDDHHMMSS);

		String clearanceId = zoneData.getZoneClearancePriceByDateTime(
				effectiveDate).getClearanceRef();

		StringBuilder keyBuilder = buildKeyforClearnaceEventMap(
				estblishedPriceMap, effectiveDate, locationType, country);

		zoneClearanceSet = createClearanceEventDataSet(clearanceEventDataMap,
				keyBuilder);

		zoneClearanceSet.add(locationType + "_" + locationId + "_"
				+ clearanceId);
		clearanceEventDataMap.put(keyBuilder.toString(), zoneClearanceSet);

	}

	/*
	 * This method prepare and grouping event data for RPM Established store
	 * clearances.
	 */
	private void prepareStoreClearanceEventData(
			Map<String, String> estblishedPriceMap,
			ClearanceProduct clearanceProduct,
			ClearanceEventData clearanceEventDataMap) throws ParseException {

		Set<String> storeClearanceSet = null;
		String locationType = STORE_PREFIX;
		String currentTpnc = estblishedPriceMap
				.get(CSVHeaders.EstablishedPriceHeaders.TPNC);
		String locationId = estblishedPriceMap
				.get(CSVHeaders.EstablishedPriceHeaders.LOCATION);
		ClearanceStoreSaleInfo storData = clearanceProduct
				.getTpncToClearanceProductVariant().get(currentTpnc)
				.getStoreExceptions().get(locationId);
		String country = storData.getCountryCode();

		// TODO Currently country code reading from CB have 'UK'nstead of
		// 'GB.This check will be applicable only up to the CB Doc updation
		// from UK to GB will complete
		if (country.equals(LOC_REF_COUNTRY)) {
			country = LOC_REF_COUNTRYCODE_UK;
		}
		String effectiveDate = Dockyard.getFormattedDate(estblishedPriceMap
				.get(CSVHeaders.EstablishedPriceHeaders.EFFECTIVE_DATE),
				PROMO_MSG_DATE_FORMAT, DATE_FORMAT_YYYYMMDDHHMMSS);

		String clearanceId = storData.getStoreClearancePriceByDateTime(
				effectiveDate).getClearanceRef();

		StringBuilder keyBuilder = buildKeyforClearnaceEventMap(
				estblishedPriceMap, effectiveDate, locationType, country);

		storeClearanceSet = createClearanceEventDataSet(clearanceEventDataMap,
				keyBuilder);

		storeClearanceSet.add(locationType + "_" + locationId + "_"
				+ clearanceId);
		clearanceEventDataMap.put(keyBuilder.toString(), storeClearanceSet);

	}

	private Set<String> createClearanceEventDataSet(
			Map<String, Set<String>> clearanceDataEventMap,
			StringBuilder keyBuilder) {

		Set<String> clearancePayLoadDataSet;
		if (clearanceDataEventMap.containsKey(keyBuilder.toString())) {

			clearancePayLoadDataSet = clearanceDataEventMap.get(keyBuilder
					.toString());
		} else {
			clearancePayLoadDataSet = new HashSet<String>();
		}
		return clearancePayLoadDataSet;
	}

	private StringBuilder buildKeyforClearnaceEventMap(
			Map<String, String> estbPriceMappingMap, String effectiveDate,
			String locationType, String country) throws ParseException {

		StringBuilder keyBuilder = new StringBuilder();
		String currentTpnc = estbPriceMappingMap
				.get(CSVHeaders.EstablishedPriceHeaders.TPNC);

		keyBuilder.append(PriceConstants.TPNC_IDENTIFIER + ":" + currentTpnc)
				.append("_").append(locationType).append("_")
				.append(effectiveDate).append("_").append(country);

		LOGGER.debug("keyBuilder :" + keyBuilder.toString());

		return keyBuilder;
	}

}
