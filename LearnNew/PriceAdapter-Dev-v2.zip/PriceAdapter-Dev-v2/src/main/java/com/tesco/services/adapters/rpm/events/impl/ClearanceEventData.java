package com.tesco.services.adapters.rpm.events.impl;

import java.util.HashMap;
import java.util.Set;

public class ClearanceEventData extends HashMap<String, Set<String>>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
