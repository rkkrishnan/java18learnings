package com.tesco.services.adapters.promotion.impl;

import com.tesco.promotion.core.PrmPrcChgDtl;
import com.tesco.promotion.core.PrmPrcChgDtlRef;
import com.tesco.promotion.core.PrmPrcChgSmp;
import com.tesco.services.adapters.promotion.PromotionHandler;
import com.tesco.services.adapters.rpm.writers.PromotionMessageWriter;
import com.tesco.services.core.ZoneEntity;
import com.tesco.services.core.promotion.*;
import com.tesco.services.exceptions.DataAccessException;
import com.tesco.services.exceptions.PromoBusinessException;
import com.tesco.services.repositories.Repository;
import com.tesco.services.repositories.RepositoryImpl;
import com.tesco.services.utility.*;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;
import org.apache.commons.lang3.ArrayUtils;
import org.joda.time.DateTime;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.tesco.services.utility.PriceConstants.*;

/**
 * Created by iv16 on 5/15/2015.
 */
public class SimplePromotionHandler implements PromotionHandler {
	private Repository repository;
	private PromotionMessageWriter promotionWriter;
	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(SimplePromotionHandler.class);
	private static PromotionJmsLog PROMOMSGCOUNTER = PromotionJmsLogImpl
			.getInstance();

	@Inject
	public SimplePromotionHandler(
			@Named("repository") Repository repository,
			@Named("promotionWriter") PromotionMessageWriter promotionWriter) {
		this.repository = repository;
		this.promotionWriter = promotionWriter;
	}

	@Override
	public Map<String, Object> processCreMessage(
			PromotionEntity promotionEntity, List<PrmPrcChgDtl> prmPrcChgDtls,
			String promoMsgForZoneId, String msgState, String msgOfferType,
			String promoMsgLocType) throws PromoBusinessException {
		Map<String, Object> allEventsDataMap = new HashMap<>();
		Map<String, Object> promotionCreatedMap = new HashMap<>();
		Map<String, PromotionEntity> promotionEntityMap = new HashMap<>();

		for (PrmPrcChgDtl prmPrcChgDtl : prmPrcChgDtls) {
			try {
				createEntity(prmPrcChgDtl, promoMsgForZoneId, msgState,
						msgOfferType, promoMsgLocType, promotionEntityMap);
			} catch (DataAccessException e) {
				throw new PromoBusinessException(e.getMessage(), e);
			}
		}

		try {
			for (String offerId : promotionEntityMap.keySet()) {
				PromotionEntity pE = promotionEntityMap.get(offerId);
				if (!Dockyard.isSpaceOrNull(pE)) {
					String eventType = verifyPromotionOrLocationExist(pE);
					this.promotionWriter.writePromoEntityFromMessage(pE);
					/**
					 * Creating new ProdOffer Doc to support the Future dated
					 * promotions in PriceService
					 */
					Map<String, String> newProductData = promotionWriter
							.writeProdOfferDoc(pE);
					promotionCreatedMap = CommonEventPublishingUtility
							.preparePromotionCreatedEventDataMap(pE, eventType,
									newProductData);

				}
			}

		} catch (Exception e) {
			throw new PromoBusinessException(e.getMessage(), e);
		}
		allEventsDataMap
				.put(PriceConstants.PROMOTION_CREATED_LOCATION_ADDED_PRODUCT_ADDED_KEY,
						promotionCreatedMap);
		return allEventsDataMap;
	}

	private String getCurrencyForLoc(String zoneId) throws DataAccessException {
		String currency = null;
		ZoneEntity zoneEntity = (ZoneEntity) repository
				.getGenericObject(PriceConstants.ZONE_ENTITY_KEY + zoneId,
						ZoneEntity.class);
		if (zoneEntity != null) {
			currency = zoneEntity.getCurrencyCode();
		}
		return currency;
	}

	private void mapPromoCompDisplayIdToPromoCompDtlId(
			String promoCompDisplayId, String promoCompDtlId)
			throws PromoBusinessException {
		try {

			repository.insertObject(PriceConstants.PROMO_DETAIL_ID_KEY
					+ promoCompDtlId, promoCompDisplayId);
			PROMOMSGCOUNTER.updateCounterForCreMsg(PROMOTION_LOOKUP_DOCUMENT);

		} catch (Exception e) {
			LOGGER.error("Look up document couldn't be inserted for simple promotion due to DB error for detailId: "
					+ promoCompDtlId);
			throw new PromoBusinessException(e.getMessage(), e);
		}

	}

	@Override
	public Map<String, Object> processDelMessage(
			List<PrmPrcChgDtlRef> prmPrcChgDtlRefs, String promoMsgForZoneId)
			throws PromoBusinessException {
		Map<String, Object> promotionEventDataMap = null;
		Map<String, String> promotionEffectiveDateMap = new HashMap<String, String>();
		List<PromoItemListEntity> promoItemListEntities = null;
		List<PromoItemEntity> promoItemEntityList = null;
		Map<String, PromotionEntity> promotionEntityMap = new HashMap<>();
		List<String> delDetailIdList = new ArrayList<>();
		List<PromoItemEntity> listOfDeletedPromotionItemEntities = new ArrayList<>();
		String effectiveDate = "";
		for (PrmPrcChgDtlRef prmPrcChgDtlRef : prmPrcChgDtlRefs) {
			String promoCompDtlId = prmPrcChgDtlRef.getPromoCompDetailId()
					.toString();
			String promoCompDisplayId = repository
					.getMappedData(PriceConstants.PROMO_DETAIL_ID_KEY
							+ promoCompDtlId);

			if (!Dockyard.isSpaceOrNull(promoCompDisplayId)) {
				delDetailIdList.add(promoCompDtlId);
				PromotionEntity promotionEntityToBeDeleted;
				promotionEntityToBeDeleted = promotionEntityMap
						.get(promoCompDisplayId);
				if (Dockyard.isSpaceOrNull(promotionEntityToBeDeleted)) {
					try {
						promotionEntityToBeDeleted = (PromotionEntity) repository
								.getGenericObject(
										PriceConstants.PROMOTION_DOC_KEY_PREFIX
												+ promoCompDisplayId
												+ "_"
												+ promoMsgForZoneId,
										PromotionEntity.class);
					} catch (DataAccessException e) {
						throw new PromoBusinessException(e.getMessage(), e);
					}
				}
				if (!Dockyard.isSpaceOrNull(promotionEntityToBeDeleted)) {
					String itemFromDelMsg = prmPrcChgDtlRef
							.getPrmPrcChgSmpDtlRef().getItem().toString();
					itemFromDelMsg = itemFromDelMsg.startsWith("0") ? itemFromDelMsg
							: "0" + itemFromDelMsg; // this
													// line
													// should
													// be
													// removed
					promoItemListEntities = promotionEntityToBeDeleted
							.getPromoItemListEntities();
					promoItemEntityList = promoItemListEntities.get(0)
							.getPromoItems();
					int indexOfItemEntityToBeRemoved = -1;
					boolean isItemEntityExist = false;
					for (PromoItemEntity promoItemEntity : promoItemEntityList) {
						indexOfItemEntityToBeRemoved++;
						if (promoItemEntity.getItemRef().equals(itemFromDelMsg)
								&& promoItemEntity.getRpmPromoCompDetailId()
										.equals(promoCompDtlId)) {
							isItemEntityExist = true;
							promotionEntityToBeDeleted.lastUpdateDate = Dockyard
									.getSysDate(PriceConstants.ISO_8601_FORMAT);
							listOfDeletedPromotionItemEntities
									.add(promoItemEntity);
							break;
						}
					}
					if (isItemEntityExist) {
						promoItemEntityList
								.remove(indexOfItemEntityToBeRemoved);
					} else {
						LOGGER.info(
								"Item Entity for Item {} from Del Msg not present in {}",
								itemFromDelMsg,
								PriceConstants.PROMOTION_DOC_KEY_PREFIX
										+ promoCompDisplayId + "_"
										+ promoMsgForZoneId);
					}
					promotionEntityMap.put(promoCompDisplayId,
							promotionEntityToBeDeleted);

					/**
					 * Deleting ProdOffer Doc which are processed in DEL message
					 */
					effectiveDate = promotionWriter.deleteProdOfferDoc(
							itemFromDelMsg, promoMsgForZoneId,
							promoCompDisplayId);
					promotionEffectiveDateMap.put(promoCompDisplayId,
							effectiveDate);

				} else {
					LOGGER.info("Document {} not found",
							PriceConstants.PROMOTION_DOC_KEY_PREFIX
									+ promoCompDisplayId + "_"
									+ promoMsgForZoneId);
				}

			} else {
				LOGGER.info(
						"Mapping Promo Comp Display Id not found for Promo Comp Detail ID {}",
						promoCompDtlId);
			}
		}
		try {
			for (String offerId : promotionEntityMap.keySet()) {
				PromotionEntity pE = promotionEntityMap.get(offerId);
				if (pE.getPromoItemListEntities().get(0).getPromoItems()
						.isEmpty()) {
					promotionEventDataMap = this.promotionWriter
							.deletePromoEntity(pE);
					CommonEventPublishingUtility
							.preparePromoProductRemvoedArgumentDataForEmptyItemList(
									promotionEventDataMap,
									promotionEffectiveDateMap, offerId);
				} else {
					promotionEventDataMap = new HashMap<String, Object>();
					this.promotionWriter.writePromoEntityFromMessage(pE);
					Map<String, Object> promotionDataMap = CommonEventPublishingUtility
							.preparePromoProductRemvoedArgumentData(
									listOfDeletedPromotionItemEntities,
									offerId, pE);
					promotionEventDataMap.put(
							PROMOTION_PRODUCT_REMOVED_EVENT_TYPE,
							promotionDataMap);
				}
			}
			/*
			 * Delete all the detail-id look-up documents which has come for
			 * delete
			 */
			this.promotionWriter.deleteDetailDisplayMapping(delDetailIdList);

		} catch (Exception e) {
			throw new PromoBusinessException(e.getMessage(), e);
		}
		return promotionEventDataMap;
	}

	@Override
	public Map<String, Object> processModMessage(
			PromotionEntity promotionEntity, List<PrmPrcChgDtl> prmPrcChgDtls,
			String promoMsgForZoneId, String msgState, String msgOfferType,
			String promoMsgLocType)
			throws PromoBusinessException {
		Map<String, Object> allEventsDataMap = new HashMap<>();
		Map<String, Object> promotionCreatedMap = new HashMap<>();
		Map<String, Object> promotionDetailsChangedOfferLevelEventMap = new HashMap<>();
		Map<String, Object> promotionDetailsChangedProductLevelEventMap = new HashMap<>();
		Map<String, Object> promotionEventMapData = new HashMap<>();
		Map<String, Object> promotionEndDateEventMapData = new HashMap<>();
		PromotionEntity existingPromotionEntity;
		boolean isEndDateChaged = false;
		try {
			existingPromotionEntity = promotionEntity.deepCopy();
		} catch (Exception e) {
			throw new PromoBusinessException(e.getMessage(), e);
		}
		Map<String, DateTime> leastEffectiveDateMap = new HashMap<>();
		Map<String, PromotionEntity> promotionEntityMap = new HashMap<>();
		List<PromoItemListEntity> promoItemListEntities;
		List<PromoItemEntity> promoItemEntities;
		String effectiveDate;
		String endDate;

		promoItemEntities = promotionEntity.getPromoItemListEntities().get(0)
				.getPromoItems();

		promoItemListEntities = promotionEntity.getPromoItemListEntities();
		List<String> compDtlIdList = new ArrayList<String>();

		/** Get all the detail ids from Couchbase documents */
		for (PromoItemEntity promoItemEntity : promoItemEntities) {
			compDtlIdList.add(promoItemEntity.getRpmPromoCompDetailId());
		}
		for (PrmPrcChgDtl prmPrcChgDtl : prmPrcChgDtls) {
			String dtlIdFromXml = prmPrcChgDtl.getPromoCompDetailId()
					.toString();
			String state = prmPrcChgDtl.getTslState();
			effectiveDate = getDate(prmPrcChgDtl.getStartDate().getYear()
					.toString(), prmPrcChgDtl.getStartDate().getMonth()
					.toString(), prmPrcChgDtl.getStartDate().getDay()
					.toString(), prmPrcChgDtl.getStartDate().getHour()
					.toString(), prmPrcChgDtl.getStartDate().getMinute()
					.toString(), prmPrcChgDtl.getStartDate().getSecond()
					.toString());
			String offerId = promotionEntity.getOfferRef();
			CommonEventPublishingUtility.addOnlyLeastEffectiveDate(
					leastEffectiveDateMap, effectiveDate, offerId);
			endDate = getDate(prmPrcChgDtl.getEndDate().getYear().toString(),
					prmPrcChgDtl.getEndDate().getMonth().toString(),
					prmPrcChgDtl.getEndDate().getDay().toString(), prmPrcChgDtl
							.getEndDate().getHour().toString(), prmPrcChgDtl
							.getEndDate().getMinute().toString(), prmPrcChgDtl
							.getEndDate().getSecond().toString());

			/** This case is for item addition -active and approved. */
			if (state.equalsIgnoreCase(PriceConstants.PROMO_MSG_RAW_NEW_STATE)
					&& !compDtlIdList.contains(dtlIdFromXml)) {
				promotionEntity.lastUpdateDate = Dockyard
						.getSysDate(PriceConstants.ISO_8601_FORMAT);
				PrmPrcChgSmp prmPrcChgSmp = prmPrcChgDtl.getPrmPrcChgSmp();

				PromoItemEntity promoItemEntity = new PromoItemEntity();
				promoItemEntity.effectiveDate = effectiveDate;
				promoItemEntity.endDate = endDate;
				promoItemEntity.itemType = PriceConstants.PROMO_ITEM_TYPE;
				promoItemEntity.itemRef = prmPrcChgSmp.getItem();

				promoItemEntity.setWasPrice(null);
				promoItemEntity.setWasWasPrice(null);

				if (prmPrcChgSmp.getTslPosLabelReqInd() != null) {
					if (PriceConstants.POS_LABEL_ONE.equals(prmPrcChgSmp
							.getTslPosLabelReqInd().toString())) {
						promoItemEntity
								.setPosLabelReqInd(PriceConstants.POS_LABEL_Y);
					} else {
						promoItemEntity
								.setPosLabelReqInd(PriceConstants.POS_LABEL_N);
					}
				} else {
					promoItemEntity
							.setPosLabelReqInd(PriceConstants.POS_LABEL_N);
				}
				if (prmPrcChgDtl.getPromoCompDetailId() != null) {
					promoItemEntity.setRpmPromoCompDetailId(prmPrcChgDtl
							.getPromoCompDetailId().toString());
				}
				promoItemEntities.add(promoItemEntity);
				promotionEntity.setPromoItemListEntities(promoItemListEntities);
				promotionEntityMap.put(promotionEntity.getOfferRef(),
						promotionEntity);
				mapPromoCompDisplayIdToPromoCompDtlId(
						prmPrcChgDtl.getTslPromoCompDisplayId(), prmPrcChgDtl
								.getPromoCompDetailId().toString());
			}
			/**
			 * This case is for ACTIVE item cancellation-Change only the item
			 * end date.
			 */
			else if (state
					.equalsIgnoreCase(PriceConstants.PROMO_MSG_RAW_CANCELLED_STATE)
					&& compDtlIdList.contains(dtlIdFromXml)) {
				promotionEntity.lastUpdateDate = Dockyard
						.getSysDate(PriceConstants.ISO_8601_FORMAT);

				for (PromoItemListEntity promoItemListEntity : promotionEntity
						.getPromoItemListEntities()) {
					if (promoItemListEntity.getPromoItems() != null) {
						for (PromoItemEntity promoItemEntity : promoItemListEntity
								.getPromoItems()) {
							if (promoItemEntity.getRpmPromoCompDetailId()
									.equals(dtlIdFromXml)) {
								promoItemEntity.setEndDate(endDate);
								if (!isEndDateChaged) {
									isEndDateChaged = true;
									promotionEventMapData.put(OFFER_ID,
											promotionEntity.getOfferRef());
									promotionEventMapData.put(END_DATE,
											promoItemEntity.getEndDate());
									promotionEventMapData.put(
											PROD_REF,
											TPNB_IDENTIFIER
													+ ":"
													+ promoItemEntity
															.getItemRef());
									promotionEndDateEventMapData.put(
											promotionEntity.getOfferRef(),
											promotionEventMapData);

								}
								break;

							}

						}
					}

				}
				promotionEntityMap.put(promotionEntity.getOfferRef(),
						promotionEntity);

			} else if ((state
					.equalsIgnoreCase(PriceConstants.PROMO_MSG_RAW_NEW_STATE)
					|| state.equalsIgnoreCase(PriceConstants.PROMO_MSG_APPROVED_STATE) || state
						.equalsIgnoreCase(PriceConstants.PROMO_MSG_RAW_REAPPROVED_STATE))
					&& compDtlIdList.contains(dtlIdFromXml)) {
				/*
				 * Save the previous createdate to update the newly updated Doc
				 */
				String createDateFromPrev = promotionEntity.createdDate;
				try {
					createEntity(prmPrcChgDtl, promoMsgForZoneId, msgState,
							msgOfferType, promoMsgLocType, promotionEntityMap);
				}
				catch(DataAccessException e){
					throw new PromoBusinessException(e.getMessage(), e);
				}

				promotionEntityMap.get(promotionEntity.getOfferRef()).createdDate = createDateFromPrev;

			}

		}
		allEventsDataMap.put(PROMOTION_ENDDATE_CHANGED,
				promotionEndDateEventMapData);
		try {
			for (String offerId : promotionEntityMap.keySet()) {
				PromotionEntity pE = promotionEntityMap.get(offerId);
				if (!Dockyard.isSpaceOrNull(pE)) {

					/*
					 * PRIS-2010 Get cfDescription1 , cfDescription2 from
					 * existing promotion
					 */
					pE.setCfDescription1(promotionEntity.getCfDescription1());
					pE.setCfDescription2(promotionEntity.getCfDescription2());

					String eventType = verifyPromotionOrLocationExist(pE);
					this.promotionWriter.writePromoEntityFromMessage(pE);

					Map<String, Object> argumentData = CommonEventPublishingUtility
							.preparePromoDetailsChangedOffLevelArgumentData(
									existingPromotionEntity,
									leastEffectiveDateMap, offerId, pE);
					promotionDetailsChangedOfferLevelEventMap.put(offerId,
							argumentData);

					/**
					 * Creating new ProdOffer Doc to support the Future dated
					 * promotions in PriceService
					 */
					Map<String, String> newProductData = promotionWriter
							.writeProdOfferDoc(pE);
					promotionCreatedMap = CommonEventPublishingUtility
							.preparePromotionCreatedEventDataMap(pE, eventType,
									newProductData);
					Map<Object, Object> argumentDataPrdLevel = CommonEventPublishingUtility
							.preparePromoDetailsChangedProductLevelArgumentData(
									existingPromotionEntity, offerId, pE);
					promotionDetailsChangedProductLevelEventMap.put(offerId,
							argumentDataPrdLevel);

				}
			}

		} catch (Exception e) {
			throw new PromoBusinessException(e.getMessage(), e);
		}
		allEventsDataMap.put(PROMOTION_DETAILS_CHANGED_OFFER_LEVEL_KEY,
				promotionDetailsChangedOfferLevelEventMap);
		allEventsDataMap.put(PROMOTION_DETAILS_CHANGED_PRODUCT_LEVEL_KEY,
				promotionDetailsChangedProductLevelEventMap);
		allEventsDataMap.put(
				PROMOTION_CREATED_LOCATION_ADDED_PRODUCT_ADDED_KEY,
				promotionCreatedMap);
		return allEventsDataMap;
	}

	public String getDate(String year, String month, String day, String hrs,
			String mins, String secs) {
		String parsedDay = day.length() == 1 ? "0" + day : day;
		String parsedMonth = month.length() == 1 ? "0" + month : month;
		String parsedHrs = hrs.length() == 1 ? "0" + hrs : hrs;
		String parsedMins = mins.length() == 1 ? "0" + mins : mins;
		String parsedSecs = secs.length() == 1 ? "0" + secs : secs;

		String date = year + parsedMonth + parsedDay + parsedHrs + parsedMins
				+ parsedSecs;
		try {
			date = Dockyard.getFormattedDate(date,
					PriceConstants.PROMO_MSG_DATE_FORMAT,
					PriceConstants.ISO_8601_FORMAT);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date;
	}

	private int[] setThrRewardRefs(int size) {
		int[] refs = {};
		for (int i = 0; i < size; i++) {
			refs = ArrayUtils.add(refs, i);
		}
		return refs;
	}

	private void createEntity(PrmPrcChgDtl prmPrcChgDtl,
			String promoMsgForZoneId, String msgState, String msgOfferType,
			String promoMsgLocType,
			Map<String, PromotionEntity> promotionEntityMap)
			throws PromoBusinessException,DataAccessException {

		List<PromoThresholdEntity> promoThresholdEntities = new ArrayList<>();
		List<PromoRewardEntity> promoRewardEntities = new ArrayList<>();
		List<PromoItemListEntity> promoItemListEntities = new ArrayList<>();
		List<PromoItemEntity> promoItemEntities;
		PromoItemListEntity promoItemBuyListEntity = new PromoItemListEntity();
		PromoItemListEntity promoItemGetListEntity = new PromoItemListEntity();
		PromotionEntity promotionEntityFromMap = promotionEntityMap
				.get(prmPrcChgDtl.getTslPromoCompDisplayId());
		PrmPrcChgSmp prmPrcChgSmp = prmPrcChgDtl.getPrmPrcChgSmp();
		String effectiveDate = getDate(prmPrcChgDtl.getStartDate().getYear()
				.toString(), prmPrcChgDtl.getStartDate().getMonth().toString(),
				prmPrcChgDtl.getStartDate().getDay().toString(), prmPrcChgDtl
						.getStartDate().getHour().toString(), prmPrcChgDtl
						.getStartDate().getMinute().toString(), prmPrcChgDtl
						.getStartDate().getSecond().toString());
		String endDate = getDate(
				prmPrcChgDtl.getEndDate().getYear().toString(), prmPrcChgDtl
						.getEndDate().getMonth().toString(), prmPrcChgDtl
						.getEndDate().getDay().toString(), prmPrcChgDtl
						.getEndDate().getHour().toString(), prmPrcChgDtl
						.getEndDate().getMinute().toString(), prmPrcChgDtl
						.getEndDate().getSecond().toString());
		if (promotionEntityFromMap != null) {

			PromoItemEntity promoItemEntity = new PromoItemEntity();
			promoItemEntity.effectiveDate = effectiveDate;
			promoItemEntity.endDate = endDate;
			promoItemEntity.itemType = PriceConstants.PROMO_ITEM_TYPE;
			promoItemEntity.itemRef = prmPrcChgSmp.getItem();

			if (prmPrcChgSmp.getTslWasPrice() != null) {
				promoItemEntity.setWasPrice(prmPrcChgSmp.getTslWasPrice());
			}

			if (prmPrcChgSmp.getTslWasWasPrice() != null) {
				promoItemEntity
						.setWasWasPrice(prmPrcChgSmp.getTslWasWasPrice());
			}
			if (prmPrcChgSmp.getTslPosLabelReqInd() != null) {
				if (PriceConstants.POS_LABEL_ONE.equals(prmPrcChgSmp
						.getTslPosLabelReqInd().toString())) {
					promoItemEntity
							.setPosLabelReqInd(PriceConstants.POS_LABEL_Y);
				} else {
					promoItemEntity
							.setPosLabelReqInd(PriceConstants.POS_LABEL_N);
				}
			} else {
				promoItemEntity.setPosLabelReqInd(PriceConstants.POS_LABEL_N);
			}
			if (prmPrcChgDtl.getPromoCompDetailId() != null) {
				promoItemEntity.setRpmPromoCompDetailId(prmPrcChgDtl
						.getPromoCompDetailId().toString());
			}

			List<PromoItemEntity> newPromoItemEntity = new ArrayList<>();
			newPromoItemEntity.add(promoItemEntity);

			promoItemListEntities = promotionEntityFromMap
					.getPromoItemListEntities();
			PromoItemListEntity availablePromoItemListEntity = promoItemListEntities
					.get(0);

			promoItemEntities = availablePromoItemListEntity.getPromoItems();
			promoItemEntities.add(promoItemEntity);
			availablePromoItemListEntity.setPromoItems(promoItemEntities);
			promoItemListEntities.set(0, availablePromoItemListEntity);
			promotionEntityFromMap
					.setPromoItemListEntities(promoItemListEntities);
			promotionEntityMap.put(promotionEntityFromMap.getOfferRef(),
					promotionEntityFromMap);
			mapPromoCompDisplayIdToPromoCompDtlId(
					prmPrcChgDtl.getTslPromoCompDisplayId(), prmPrcChgDtl
							.getPromoCompDetailId().toString());
		} else {
			promotionEntityFromMap = new PromotionEntity();
			promotionEntityFromMap.offerRef = prmPrcChgDtl
					.getTslPromoCompDisplayId();
			promotionEntityFromMap.offerType = msgOfferType;
			promotionEntityFromMap.state = msgState;
			promotionEntityFromMap.name = prmPrcChgDtl.getPromoCompDesc();
			promotionEntityFromMap.tillRollDescription = prmPrcChgDtl
					.getTslCompLevelTillDesc();
			promotionEntityFromMap.locType = promoMsgLocType;
			promotionEntityFromMap.locRef = promoMsgForZoneId;
			promotionEntityFromMap.createdById = PriceConstants.PROMO_CREATED_ID_RPM;
			promotionEntityFromMap.createdDate = Dockyard
					.getSysDate(PriceConstants.ISO_8601_FORMAT);
			promotionEntityFromMap.lastUpdatedById = PriceConstants.PROMO_CREATED_ID_RPM;
			promotionEntityFromMap.lastUpdateDate = Dockyard
					.getSysDate(PriceConstants.ISO_8601_FORMAT);

			PromoThresholdEntity promoThresholdEntity = new PromoThresholdEntity();
			promoThresholdEntity.thresholdType = PriceConstants.SIMPLE_PROMO_THR_TYPE;
			promoThresholdEntity.thresholdAmount = PriceConstants.SIMPLE_PROMO_THR_AMT;
			promoThresholdEntity.thresholdCurrency = getCurrencyForLoc(promoMsgForZoneId);
			promoThresholdEntity.thresholdQty = PriceConstants.SIMPLE_PROMO_THR_QTY;
			promoThresholdEntities.add(promoThresholdEntity);
			promotionEntityFromMap
					.setPromoThresholdEntities(promoThresholdEntities);

			PromoRewardEntity promoRewardEntity = new PromoRewardEntity();

			promoRewardEntity.changeType = prmPrcChgSmp.getPrmChgType();

			promoRewardEntity.changeQty = PriceConstants.DEFAULT_PROMO_CHANGE_QTY;

			if (PriceConstants.PROMO_CHG_TYPES.AMT.value().equals(
					prmPrcChgSmp.getPrmChgType())
					|| PriceConstants.PROMO_CHG_TYPES.FXD.value().equals(
							prmPrcChgSmp.getPrmChgType())
					|| PriceConstants.PROMO_CHG_TYPES.NO_CHG.value().equals(
							prmPrcChgSmp.getPrmChgType())) {
				promoRewardEntity.changeAmount = prmPrcChgSmp.getPrmChgValue();
			}
			if (PriceConstants.PROMO_CHG_TYPES.PCT.value().equals(
					prmPrcChgSmp.getPrmChgType())) {
				/** Multiply by 100 because RPM gives data with decimal */
				promoRewardEntity.changePercent = prmPrcChgSmp.getPrmChgValue() * 100;
			}
			promoRewardEntity.changeUom = prmPrcChgSmp.getPrmChgUom();

			if (PriceConstants.PROMO_CHANGE_UOM
					.equals(promoRewardEntity.changeUom)) {
				promoRewardEntity.changeUom = null;
			}
			promoRewardEntity.changeCurrency = getCurrencyForLoc(promoMsgForZoneId);
			promoRewardEntities.add(promoRewardEntity);
			promotionEntityFromMap.setPromoRewardEntities(promoRewardEntities);

			promoItemBuyListEntity.listType = PriceConstants.PROMO_ITEM_LIST_BUY_TYPE;

			int[] thresholdRefs = setThrRewardRefs(promotionEntityFromMap
					.getPromoThresholdEntities().size());
			promoItemBuyListEntity.setThresholdRefs(thresholdRefs);
			promoItemEntities = new ArrayList<>();

			PromoItemEntity promoItemEntity = new PromoItemEntity();
			promoItemEntity.effectiveDate = effectiveDate;
			promoItemEntity.endDate = endDate;
			promoItemEntity.itemType = PriceConstants.PROMO_ITEM_TYPE;
			promoItemEntity.itemRef = prmPrcChgSmp.getItem();

			if (prmPrcChgSmp.getTslWasPrice() != null) {
				promoItemEntity.setWasPrice(prmPrcChgSmp.getTslWasPrice());
			}

			if (prmPrcChgSmp.getTslWasWasPrice() != null) {
				promoItemEntity
						.setWasWasPrice(prmPrcChgSmp.getTslWasWasPrice());
			}
			if (prmPrcChgSmp.getTslPosLabelReqInd() != null) {
				if (PriceConstants.POS_LABEL_ONE.equals(prmPrcChgSmp
						.getTslPosLabelReqInd().toString())) {
					promoItemEntity
							.setPosLabelReqInd(PriceConstants.POS_LABEL_Y);
				} else {
					promoItemEntity
							.setPosLabelReqInd(PriceConstants.POS_LABEL_N);
				}
			} else {
				promoItemEntity.setPosLabelReqInd(PriceConstants.POS_LABEL_N);
			}
			if (prmPrcChgDtl.getPromoCompDetailId() != null) {
				promoItemEntity.setRpmPromoCompDetailId(prmPrcChgDtl
						.getPromoCompDetailId().toString());
			}

			promoItemEntities.add(promoItemEntity);
			promoItemBuyListEntity.setPromoItems(promoItemEntities);
			promoItemListEntities.add(promoItemBuyListEntity);

			promoItemGetListEntity.listType = PriceConstants.PROMO_ITEM_LIST_GET_TYPE;
			int[] rewardsRefs = setThrRewardRefs(promotionEntityFromMap
					.getPromoRewardEntities().size());
			promoItemGetListEntity.setRewardRefs(rewardsRefs);
			promoItemListEntities.add(promoItemGetListEntity);

			promotionEntityFromMap
					.setPromoItemListEntities(promoItemListEntities);
			promotionEntityMap.put(promotionEntityFromMap.getOfferRef(),
					promotionEntityFromMap);
			mapPromoCompDisplayIdToPromoCompDtlId(
					prmPrcChgDtl.getTslPromoCompDisplayId(), prmPrcChgDtl
							.getPromoCompDetailId().toString());
		}
	}

	private String verifyPromotionOrLocationExist(
			PromotionEntity promotionEntity) throws PromoBusinessException {

		String offerId = promotionEntity.getOfferRef();
		String locRef = promotionEntity.getLocRef();
		String locType = promotionEntity.getLocType();
		PromotionMasterEntity masterDoc = null;
		PromotionEntity existingPromotionEntity = null;
		String eventType = null;
		try {
			masterDoc = (PromotionMasterEntity) repository
					.getGenericObject(PROMOTION_DOC_KEY_PREFIX + offerId,
							PromotionMasterEntity.class);

			existingPromotionEntity = (PromotionEntity) repository
					.getGenericObject(PROMOTION_DOC_KEY_PREFIX + offerId + "_"
							+ locType + locRef, PromotionEntity.class);

		} catch (DataAccessException e) {
			throw new PromoBusinessException(e);
		}

		if (masterDoc == null) {
			eventType = PROMOTION_MSG_TYPE_CRE;

		} else if (existingPromotionEntity == null) {
			eventType = PROMO_LOC_ADDED;
		}
		return eventType;

	}

}
