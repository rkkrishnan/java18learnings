package com.tesco.services.adapters.rpm.writers.impl;

import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.exceptions.WriterBusinessException;
import com.tesco.services.adapters.rpm.writers.Writer;
import com.tesco.services.core.Ean;
import com.tesco.services.repositories.Repository;
import com.tesco.services.resources.TeauthPriceChecksResource;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.PriceConstants;
import com.tesco.services.utility.WebServiceCallBuilder;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;
import io.dropwizard.servlets.assets.ResourceNotFoundException;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Response;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

/**
 *
 * The class <code>EanSeedingWriter</code> is responsible for seeding EAN-TPNC
 * data to couchbase if the EAN is present in Product Service
 */
public class EanSeedingWriter implements Writer {

	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger("EAN Seeding");

	private Configuration configuration;
	private String filePath;

	private Repository repository;
	private BufferedReader bufferedReader;
	private WebServiceCallBuilder webServiceCallBuilder;

	private Response response;

	public void setResponse(Response response) {
		this.response = response;
	}

	private List<String> eanList = new ArrayList<>();
	private Set<String> rejectedEans = new HashSet();

	private Dockyard dockyard;
	private String storeId;

	public Dockyard getDockyard() {

		if (dockyard == null) {
			dockyard = new Dockyard();
		}
		return dockyard;
	}

	public void setDockyard(Dockyard dockyard) {
		this.dockyard = dockyard;
	}

	public BufferedReader getBufferedReader() throws IOException {
		if (this.bufferedReader == null) {
			if (filePath != null && filePath.length() > 0) {
				File f = new File(filePath);
				FileReader fileReader = new FileReader(f);
				this.bufferedReader = new BufferedReader(fileReader);
			} else {
				LOGGER.error("reject file : {} does not exist", filePath);
				throw new IOException("Invalid file name");
			}
		}
		return this.bufferedReader;
	}

	public void setBufferedReader(BufferedReader bufferedReader) {
		this.bufferedReader = bufferedReader;
	}

	/**
	 * @param configuration
	 * @param webServiceCallBuilder
	 * @param repository
	 */

	@Inject
	public EanSeedingWriter(
			@Named("configuration") Configuration configuration,
			@Named("webServiceCallBuilder") WebServiceCallBuilder webServiceCallBuilder,
			@Named("repository") Repository repository) {
		this.configuration = configuration;
		this.repository = repository;
		this.webServiceCallBuilder = webServiceCallBuilder;
	}

	public Repository getRepository() {
		return repository;
	}

	public void setRepository(Repository repository) {
		this.repository = repository;
	}

	public void setWebServiceCallBuilder(
			WebServiceCallBuilder webServiceCallBuilder) {
		this.webServiceCallBuilder = webServiceCallBuilder;
	}

	public void init(String filePath) {
		this.filePath = filePath;
		String fileName = filePath.substring(filePath.lastIndexOf('/') + 1);
		this.storeId = fileName.split("_")[0];
		this.storeId = this.storeId.substring(this.storeId.length() - 4);
	}

	public void write(String filePath) throws WriterBusinessException {
		init(filePath);
		LOGGER.info("Seeding the EAN from TEAUTH file into Couchbase");
		try {
			writeEanTpncMaping();
		} catch (StringIndexOutOfBoundsException exception) {

			TeauthPriceChecksResource.setErrorString(filePath,
					"String index out of bound Exception");
			LOGGER.error("Error seeding EAN from TEAUTH file...",
					exception.getMessage());
		} catch (Exception e) {

			TeauthPriceChecksResource.setErrorString(filePath, e.getMessage());
			LOGGER.error("Error seeding EAN from TEAUTH file...", e);
		}
	}

	private void writeEanTpncMaping() throws IOException, ServletException {

		String line = null;

		while ((line = getBufferedReader().readLine()) != null) {
			if (!(line.startsWith("10") || line.startsWith("90"))
					&& line.length() != 0) {
				processLine(line);
				if (eanList.size() == PriceConstants.PRODUCT_SERVICE_CALL_LIMIT) {
					callProductService((List<String>) eanList);
					eanList.clear();
				}
			}
		}

		if (!eanList.isEmpty()) {

			callProductService((List<String>) eanList);
		}
		eanList.clear();
		// Write the non found EAN details to reject file
		if (!rejectedEans.isEmpty()) {
			String date = Dockyard.getSysDate("yyyyMMddHHmmss");
			getDockyard().writeProductDetailsToFile(
					configuration.getRejectFilePath()
							+ "/REJECT_FILE_eanseeding_" + date + ".log",
					rejectedEans);
		}
		rejectedEans.clear();
	}

	/**
	 *
	 * @param line
	 *            This method will read a single line & set the ean value to the
	 *            list The index value is fixed and should not be changed
	 */
	private void processLine(String line) {
		eanList.add(line.substring(2, 15).trim());
		eanList.add(line.substring(39, 52).trim());
	}

	/**
	 *
	 * @param eanList
	 *            contains list of EANs processed from file The method
	 *            callProductService will make call to Product Service get call
	 *            (with MAX 20 EAN) to get the corresponding TPNCs for EAN
	 */

	private void callProductService(List<String> eanList)
			throws ResourceNotFoundException, ServletException {
		String productServiceUrl;
		productServiceUrl = createProductServiceUrl(eanList);

		try {
			response = webServiceCallBuilder
					.getResponseFromProdServices(productServiceUrl);

			if (response.getStatus() == HttpServletResponse.SC_NOT_FOUND) {
				throw new ResourceNotFoundException(
						new Exception(
								"The URL trying to reach could not be found on the server."));
			}

			if (response.getStatus() == HttpServletResponse.SC_INTERNAL_SERVER_ERROR) {
				throw new ServletException("HTTP 500 - Internal Server Error");
			}

			if (response.getStatus() == HttpServletResponse.SC_OK) {

				Map actualProductPriceInfo = response.readEntity(Map.class);
				for (Object innermap : (List<String>) actualProductPriceInfo
						.get(PriceConstants.PRODUCT_SERVICE_RESPONSE_PRODUCTS)) {
					if (innermap != null) {
						String tpnc = null;
						String ean = null;

						if (((HashMap) innermap)
								.get(PriceConstants.PRODUCT_SERVICE_RESPONSE_GTIN14) != null) {
							ean = ((HashMap) innermap)
									.get(PriceConstants.PRODUCT_SERVICE_RESPONSE_GTIN14)
									.toString();
						} else {
							LOGGER.warn(
									"EAN mapping not found for TPNC {} - store {}",
									((HashMap) innermap)
											.get(PriceConstants.PRODUCT_SERVICE_RESPONSE_TPNC)
											.toString(), storeId);
							rejectedEans
									.add("EAN mapping not found for TPNC"
											+ ((HashMap) innermap)
													.get(PriceConstants.PRODUCT_SERVICE_RESPONSE_TPNC)
													.toString() + "- store "
											+ storeId);
						}

						if (((HashMap) innermap)
								.get(PriceConstants.PRODUCT_SERVICE_RESPONSE_TPNC) != null) {
							tpnc = ((HashMap) innermap)
									.get(PriceConstants.PRODUCT_SERVICE_RESPONSE_TPNC)
									.toString();
						} else {
							LOGGER.warn("TPNC mapping not available in product service - store "
									+ storeId + " item EAN" + ean);
							rejectedEans
									.add("TPNC mapping not available in product service - store "
											+ storeId + " item EAN" + ean);
						}

						if (ean != null && tpnc != null) {
							insertEanTpncMappingToCouchbase(
									ean.substring(1, 14), tpnc);
						}
					}
				}

				for (Object list : (List) actualProductPriceInfo
						.get(PriceConstants.PRODUCT_SERVICE_RESPONSE_MISSING_SET)) {
					LOGGER.warn(
							"TEAUTH Invalid EAN, not available in product service - store {} item ean {}",
							storeId, list.toString());
					rejectedEans
							.add("TEAUTH Invalid EAN, not available in product service - store "
									+ storeId + " item EAN " + list.toString());
				}
			} else {
				LOGGER.warn("The status code from Product Service is {}",
						response.getStatus());
				TeauthPriceChecksResource.setErrorString(
						filePath,
						"The status code from Product Service is {}"
								+ response.getStatus());
			}

		} catch (Exception e) {
			TeauthPriceChecksResource.setErrorString(filePath, e.getMessage());
			LOGGER.error("Error seeding EAN from TEAUTH file...", e);
		}
	}

	/**
	 *
	 * @param ean
	 *            holds the EAN number
	 * @param tpnc
	 *            holds corresponding TPNC for EAN number The method
	 *            insertEanTpncMappingToCouchbase will insert EAN document into
	 *            PriceService couchbase bucket
	 */
	public void insertEanTpncMappingToCouchbase(String ean, String tpnc)
			throws Exception {

		final String sysdate = Dockyard.getSysDate("yyyyMMdd");
		Ean eanObject = new Ean(tpnc);
		eanObject.setLastUpdatedDate(sysdate);

		repository.insertObject(PriceConstants.EAN_KEY_PREFIX + ean,
				eanObject);
	}

	/**
	 *
	 * @param eanList
	 * @return url for product service get call contain n numbers of EAN
	 */

	public String createProductServiceUrl(List<String> eanList) {
		String url = configuration.getproductServiceUrl();
		for (int i = 0; i < eanList.size(); i++) {
			url = url + "gtin=" + eanList.get(i) + "&";
		}
		return url + "fields=TPNC&fields=GTIN14";
	}
}
