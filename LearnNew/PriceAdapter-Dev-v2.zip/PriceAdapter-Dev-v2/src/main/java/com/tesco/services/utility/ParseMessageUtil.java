package com.tesco.services.utility;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by QZ88 on 09/12/2014.
 */
public class ParseMessageUtil {

	private static ParseMessageUtil messageParseUtil = null;

	public static ParseMessageUtil getInstance() {
		if (messageParseUtil == null) {
			messageParseUtil = new ParseMessageUtil();
		}
		return messageParseUtil;
	}

	private ParseMessageUtil() {
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		throw new CloneNotSupportedException(
				"Cannot clone singleton ParseMessageUtil object");
	}

	public String getNodeData(String text, String expression)
			throws IOException, SAXException, ParserConfigurationException,
			XPathExpressionException {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		InputSource is = new InputSource(new StringReader(text));
		Document bbcDoc = builder.parse(is);
		XPath xpath = XPathFactory.newInstance().newXPath();
		NodeList linkNodes = (NodeList) xpath
				.evaluate(expression, bbcDoc, XPathConstants.NODESET);
		return linkNodes.item(0).getLastChild().getNodeValue();
	}

	public Document getDocument(InputStream streamData)
			throws ParserConfigurationException, IOException, SAXException {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		InputSource is = new InputSource(streamData);
		Document productAvgWeightDoc = builder.parse(is);
		return productAvgWeightDoc;
	}

	public List<String> getNodeData(Document doc, String expression)
			throws XPathExpressionException {
		XPath xpath = XPathFactory.newInstance().newXPath();
		NodeList linkNodes = (NodeList) xpath
				.evaluate(expression, doc, XPathConstants.NODESET);
		List<String> nodes = new ArrayList<>();
		for(int i = 0; i< linkNodes.getLength(); i++){
			nodes.add(linkNodes.item(i).getLastChild().getNodeValue());
		}
		return nodes;
	}

	public String getNodeDataAvgWeight(Document doc, String expression)
			throws XPathExpressionException {
		XPath xpath = XPathFactory.newInstance().newXPath();
		String avgWeight = (String) xpath
				.evaluate(expression, doc, XPathConstants.STRING);
		return avgWeight;
	}

	public Object getMappedObjectForXmlData(Class classToBeMapped,
			String textData) throws JAXBException {
		StringReader promoDetailReader = new StringReader(textData);
		JAXBContext jaxbContextForPromoDetail = JAXBContext
				.newInstance(classToBeMapped);
		Unmarshaller unmarshallerPromoDetail = jaxbContextForPromoDetail
				.createUnmarshaller();
		return unmarshallerPromoDetail.unmarshal(promoDetailReader);
	}
}
