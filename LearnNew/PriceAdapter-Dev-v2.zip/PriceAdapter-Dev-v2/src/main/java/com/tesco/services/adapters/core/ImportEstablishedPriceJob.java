package com.tesco.services.adapters.core;

import javax.inject.Inject;
import javax.inject.Named;

import org.slf4j.Logger;

import com.tesco.services.Configuration;
import com.tesco.services.adapters.rpm.writers.impl.EstablishedPriceWritter;
import com.tesco.services.adapters.rpm.writers.Writer;
import com.tesco.services.resources.ImportResource;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;

public class ImportEstablishedPriceJob implements Import {

	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(ImportEstablishedPriceJob.class);

	private Configuration configuration;
	private String runIdentifier;
	private String fileName;
	private Writer establishedPriceJobWriter;

	@Inject
	public ImportEstablishedPriceJob(
			@Named("configuration") Configuration configuration,
			@Named("establishedPriceJobWriter") Writer establishedPriceJobWriter) {
		this.configuration = configuration;
		this.establishedPriceJobWriter = establishedPriceJobWriter;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getRunIdentifier() {
		return runIdentifier;
	}

	public void setRunIdentifier(String runIdentifier) {
		this.runIdentifier = runIdentifier;
	}

	@Override
	public void run() {
		LOGGER.info("Firing up imports for Established Price data for {}",
				runIdentifier);
		startImportProcess();
	}

	public void startImportProcess() {
		try {
			LOGGER.info("Importing data for Established Price data from {} ",
					configuration.getRpmClrDataDumpPath());
			((EstablishedPriceWritter) establishedPriceJobWriter)
					.setRunIdentifier(getRunIdentifier());
			establishedPriceJobWriter.write(getFileName());
			LOGGER.info("Successfully completed imports for Established Price data");
		} catch (Exception exception) {
			LOGGER.error("Error importing Onetime Established Price data..",
					exception);
			ImportResource.setErrorString(fileName,
					"Error importing Onetime Established Price data..");
		} finally {
			ImportResource.getImportSemaphoreForIdentifier(fileName).release();
		}
	}
}
