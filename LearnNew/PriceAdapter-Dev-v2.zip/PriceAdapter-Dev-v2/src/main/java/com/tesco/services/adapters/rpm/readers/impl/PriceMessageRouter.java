package com.tesco.services.adapters.rpm.readers.impl;

import com.tesco.price.core.RegPrcChgDesc;
import com.tesco.price.core.RegPrcChgRef;
import com.tesco.price.util.PriceMsgHelper;
import com.tesco.services.adapters.core.exceptions.PriceEventException;
import com.tesco.services.adapters.core.utils.PriceMetrics;
import com.tesco.services.adapters.price.PriceEventHandler;
import com.tesco.services.adapters.price.PriceHandler;
import com.tesco.services.adapters.rpm.readers.MessageRouter;
import com.tesco.services.core.price.PriceEntity;
import com.tesco.services.exceptions.DataAccessException;
import com.tesco.services.exceptions.MessageRouterException;
import com.tesco.services.exceptions.PriceBusinessException;
import com.tesco.services.utility.ParseMessageUtil;
import com.tesco.services.utility.PriceConstants;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;
import org.slf4j.Logger;
import org.xml.sax.SAXException;

import javax.inject.Inject;
import javax.inject.Named;
import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;
import java.io.IOException;
import java.text.ParseException;
import java.util.Map;

/**
 * Created by qp65 on 9/3/2015.
 */
public class PriceMessageRouter implements MessageRouter {

	private PriceHandler priceHandler;
	private ParseMessageUtil parseMessageUtil;
	private PriceMetrics priceMetrics = PriceMetrics.getInstance();
	private boolean isMetricsEnabled = false;
	/**
	 * JIRA- PRIS-1390 -FuturePriceEventHandler Declaration. It handles the
	 * event generating and publishing for FuturePriceCreateEvent
	 */
	private PriceEventHandler priceEventHandler;

	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(PriceMessageRouter.class);

	@Inject
	public PriceMessageRouter(
			@Named("priceHandler") PriceHandler priceHandler,
			@Named("priceEventHandler") PriceEventHandler priceEventHandler) {
		this.priceHandler = priceHandler;
		isMetricsEnabled = true;
		this.priceEventHandler = priceEventHandler;
	}

	@Override
	public void route(String message) throws MessageRouterException {

		String priceMsgType = null;
		Map<String, PriceEntity> priceEntityData;

		try {

			if (isMetricsEnabled) {
				priceMetrics.logMessageProcessingStartTime();
			}

			parseMessageUtil = parseMessageUtil != null ? parseMessageUtil
					: ParseMessageUtil.getInstance();
			priceMsgType = parseMessageUtil.getNodeData(message,
					PriceConstants.PROMO_MSG_TYPE_PATH);
			String priceDescData = parseMessageUtil.getNodeData(message,
					PriceConstants.PROMO_MSG_DATA_PATH);
			priceDescData = priceDescData.trim();
			if (PriceConstants.PRICE_MSG_TYPE_CRE.equals(priceMsgType)) {

				PriceMsgHelper.validatePriceMsgSchema(priceDescData, "cre");
				RegPrcChgDesc priceCreMsg = (RegPrcChgDesc) parseMessageUtil
						.getMappedObjectForXmlData(RegPrcChgDesc.class,
								priceDescData);

				if (isMetricsEnabled) {
					priceMetrics.logCrePriceProcessingStartTime();
				}
				priceHandler.processCre(priceCreMsg);

				/*
				 * PriceChangeCreated event started
				 */
				LOGGER.info("PriceChangeCreated event started");

				priceEventHandler.processCreEvent(priceCreMsg);

				// Event Firing point end....
				LOGGER.info("PriceChangeCreated event finished");
				/*
				 * PriceChangeCreated event finished
				 */
				if (isMetricsEnabled) {
					priceMetrics.logCrePriceProcessingEndTime();
				}

			} else if (PriceConstants.PRICE_MSG_TYPE_DEL.equals(priceMsgType)) {

				PriceMsgHelper.validatePriceMsgSchema(priceDescData, "del");
				RegPrcChgRef priceDelMsg = (RegPrcChgRef) parseMessageUtil
						.getMappedObjectForXmlData(RegPrcChgRef.class,
								priceDescData);

				if (isMetricsEnabled) {
					priceMetrics.logDelPriceProcessingStartTime();
				}

				LOGGER.info("Effective Date reading from couchbase before deleting started..................");
				/*
				 * This method read the effective dates of the requested
				 * products from CB.
				 */

				priceEntityData = priceEventHandler
						.getPriceEntityData(priceDelMsg);

				LOGGER.info("Effective Date reading from couchbase before deleting end..................");

				priceHandler.processDel(priceDelMsg);

				/*
				 * PriceChangeDeleted event started
				 */
				LOGGER.info("PriceChangeDeleted event started");

				priceEventHandler.processDelEvent(priceDelMsg, priceEntityData);

				// Event Firing point end....
				LOGGER.info("PriceChangeDeleted event finished");
				/*
				 * PriceChangeDeleted event finished
				 */
				if (isMetricsEnabled) {
					priceMetrics.logDelPriceProcessingEndTime();
				}

			} else {
				throw new MessageRouterException("Invalid Message tyoe --> "
						+ priceMsgType);
			}

			if (isMetricsEnabled) {
				priceMetrics.logMessageProcessingEndTime();
			}

		} catch (IOException | ParserConfigurationException | JAXBException
				| PriceBusinessException | XPathExpressionException
				| SAXException | PriceEventException | ParseException | DataAccessException e) {

			if (isMetricsEnabled) {
				priceMetrics.logMessageProcessingEndTime();
			}

			if (PriceConstants.PRICE_MSG_TYPE_DEL.equals(priceMsgType)
					&& isMetricsEnabled) {
				priceMetrics.logDelPriceProcessingEndTime();
			} else if (PriceConstants.PRICE_MSG_TYPE_CRE.equals(priceMsgType)
					&& isMetricsEnabled) {
				priceMetrics.logCrePriceProcessingEndTime();
			}

			if (isMetricsEnabled) {
				priceMetrics.incrementErrorCount();
			}

			throw new MessageRouterException(e.getMessage(), e);

		}
	}

}
