package com.tesco.services.adapters.rpm.writers.impl;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Optional;
import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.exceptions.ColumnNotFoundException;
import com.tesco.services.adapters.core.exceptions.WriterBusinessException;
import com.tesco.services.adapters.core.utils.RPMClearanceMetrics;
import com.tesco.services.adapters.rpm.events.impl.ClearanceEventData;
import com.tesco.services.adapters.rpm.events.ClearanceEventHandler;
import com.tesco.services.adapters.rpm.readers.PriceServiceCSVReader;
import com.tesco.services.adapters.rpm.readers.impl.PriceServiceRPMClearanceCSVReaderImpl;
import com.tesco.services.adapters.rpm.writers.*;
import com.tesco.services.core.*;
import com.tesco.services.event.exception.EventPublishException;
import com.tesco.services.exceptions.DataAccessException;
import com.tesco.services.repositories.Repository;
import com.tesco.services.resources.ImportResource;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.PriceConstants;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;
import org.joda.time.DateTime;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import java.io.*;
import java.nio.file.Files;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.tesco.services.utility.PriceConstants.COLON_SEPARATOR;
import static com.tesco.services.utility.PriceConstants.UNDERSCORE_SEPARATOR;

public class RPMClearanceWriter implements
		com.tesco.services.adapters.rpm.writers.Writer {

	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger("RPM Clearance Import");
	private static final RPMClearanceMetrics RPMCLEARANCEMETRICS = RPMClearanceMetrics
			.getInstance();

	public String lastProductId = "";
	private BufferedWriter bufferedWriter;
	private Configuration configuration;
	private FileWriter fileWriter;
	private String identifiedFailedProduct = "";
	private String oneTimeRunType = PriceConstants.RUN_IDENT_RPMONETIME;
	private Repository repository;
	private PriceServiceCSVReader rpmClearanceCreReader;
	private PriceServiceCSVReader rpmClearanceDelReader;
	private PriceServiceCSVReader rpmClearanceModReader;
	private ClearanceEventHandler clearanceEventHandler;

	private ClearanceEventData clearanceDataEventMap;

	private String runIdentifier;

	private Dockyard dockyard;

	public Dockyard getDockyard() {
		if (dockyard == null) {
			dockyard = new Dockyard();
		}
		return dockyard;
	}

	public void setDockyard(Dockyard dockyard) {
		this.dockyard = dockyard;
	}

	public void setRunIdentifier(String runIdentifier) {
		this.runIdentifier = runIdentifier;
	}

	Optional<ClearanceProduct> currentClearanceProduct;
	String productTpnb;
	FileReader reader;
	HashSet<String> rejectedProducts = new HashSet<>();
	File rpmClrFailedDatafile;
	File rpmClrFailedEventMapfile;
	BufferedReader rpmClrFailedFileReader = null;

	/**
	 * @param configuration
	 * @param repository
	 */
	@Inject
	public RPMClearanceWriter(
			@Named("configuration") Configuration configuration,
			@Named("repository") Repository repository,
			@Named("clearanceEventHandler") ClearanceEventHandler clearanceEventHandler) {
		this.configuration = configuration;
		this.repository = repository;
		this.clearanceEventHandler = clearanceEventHandler;
	}

	public RPMClearanceWriter(Configuration configuration,
			Repository repository,
			ClearanceEventHandler clearanceEventHandler,
			PriceServiceCSVReader rpmClearanceCreReader,
			PriceServiceCSVReader rpmClearanceDelReader,
			PriceServiceCSVReader rpmClearanceModReader) {
		this.configuration = configuration;
		this.repository = repository;
		this.clearanceEventHandler = clearanceEventHandler;
		this.rpmClearanceCreReader = rpmClearanceCreReader;
		this.rpmClearanceDelReader = rpmClearanceDelReader;
		this.rpmClearanceModReader = rpmClearanceModReader;
	}

	public PriceServiceCSVReader createRpmClearanceReader(String readerType)
			throws WriterBusinessException {
		PriceServiceCSVReader csvreader = null;
		try {
			if (PriceConstants.CRE_CSV_READER.equals(readerType)) {
				csvreader = new PriceServiceRPMClearanceCSVReaderImpl(
						configuration.getRpmClrDataDumpPath() + "/"
								+ runIdentifier + "/"
								+ configuration.getRpmClrCreFileName(),
						CSVHeaders.RpmClearance_Cre_Mod.HEADERS);
			} else if (PriceConstants.MOD_CSV_READER.equals(readerType)) {

				csvreader = new PriceServiceRPMClearanceCSVReaderImpl(
						configuration.getRpmClrDataDumpPath() + "/"
								+ runIdentifier + "/"
								+ configuration.getRpmClrModFileName(),
						CSVHeaders.RpmClearance_Cre_Mod.HEADERS);

			} else if (PriceConstants.DEL_CSV_READER.equals(readerType)) {
				csvreader = new PriceServiceRPMClearanceCSVReaderImpl(
						configuration.getRpmClrDataDumpPath() + "/"
								+ runIdentifier + "/"
								+ configuration.getRpmClrDelFileName(),
						CSVHeaders.RpmClearance_Del.HEADERS);
			}
		} catch (IOException | ColumnNotFoundException e) {
			LOGGER.error("Error Occurred in createRpmClearanceReader ", e);
			throw new WriterBusinessException(e.getMessage(), e.getCause());
		}
		return csvreader;
	}

	public BufferedWriter getBufferedWriter(FileWriter fileWriter) {
		if (bufferedWriter == null) {
			bufferedWriter = new BufferedWriter(fileWriter);

		}
		return bufferedWriter;
	}

	public void setBufferedWriter(BufferedWriter bufferedWriter) {
		this.bufferedWriter = bufferedWriter;
	}

	/**
	 * Method getfailedProductInProviousRunIfExist
	 *
	 * @return String
	 * @throws IOException
	 */
	public String getfailedProductInProviousRunIfExist() throws IOException {
		rpmClrFailedDatafile = getRpmClrFailedDatafile(configuration
				.getRpmClrImportFailedFile()
				+ "/RR_RPM_"
				+ runIdentifier
				+ ".txt");

		String line;

		String failedProduct = "";
		try {
			reader = getReader(rpmClrFailedDatafile);
			rpmClrFailedFileReader = getRpmClrFailedFileReader(reader);
			while ((line = rpmClrFailedFileReader.readLine()) != null) {
				failedProduct = line;
			}
			rpmClrFailedFileReader.close();
		} catch (FileNotFoundException e) {
			return null;
		} catch (IOException e) {
			LOGGER.error("Failed to read the file  ", e);
			return null;
		}
		return failedProduct;
	}

	public FileWriter getFileWriter(File rpmClrFailedDatafile)
			throws IOException {
		if (fileWriter == null) {
			fileWriter = new FileWriter(rpmClrFailedDatafile);
		}
		return fileWriter;
	}

	public FileReader getReader(File rpmClrFailedDatafile)
			throws FileNotFoundException {
		if (reader == null) {
			reader = new FileReader(rpmClrFailedDatafile);
		}

		return reader;
	}

	public File getRpmClrFailedDatafile(String path) {
		if (rpmClrFailedDatafile == null) {
			rpmClrFailedDatafile = new File(path);
		}
		return rpmClrFailedDatafile;
	}

	public File getRpmClrFailedEventMapfile(String path) {
		if (rpmClrFailedEventMapfile == null) {
			rpmClrFailedEventMapfile = new File(path);
		}
		return rpmClrFailedEventMapfile;
	}

	public BufferedReader getRpmClrFailedFileReader(FileReader fileReader) {

		if (rpmClrFailedFileReader == null) {
			rpmClrFailedFileReader = new BufferedReader(fileReader);
		}
		return rpmClrFailedFileReader;
	}

	public void setFileWriter(FileWriter fileWriter) {
		this.fileWriter = fileWriter;
	}

	public void setRepository(Repository repository) {
		this.repository = repository;
	}

	public void setReader(FileReader reader) {
		this.reader = reader;
	}

	public void setRpmClrFailedDatafile(File rpmClrFailedDatafile) {
		this.rpmClrFailedDatafile = rpmClrFailedDatafile;
	}

	public void setRpmClrFailedFileReader(BufferedReader rpmClrFailedFileReader) {
		this.rpmClrFailedFileReader = rpmClrFailedFileReader;
	}

	public void initRPMClearanceReaders() throws WriterBusinessException {
		try {
			LOGGER.info("Initializing RPM Clearance readers");
			this.rpmClearanceCreReader = createRpmClearanceReader(PriceConstants.CRE_CSV_READER);

			this.rpmClearanceModReader = createRpmClearanceReader(PriceConstants.MOD_CSV_READER);

			this.rpmClearanceDelReader = createRpmClearanceReader(PriceConstants.DEL_CSV_READER);
		} catch (WriterBusinessException e) {
			LOGGER.error(
					"Error occured while initializing RPM clearance readers", e);
			throw new WriterBusinessException(e.getMessage(), e.getCause());
		}
	}

	// Method write
	public void write(String fileName) throws WriterBusinessException {

		LOGGER.info("Importing data for RPM Clearance from {} ",
				configuration.getRpmClrDataDumpPath());
		if (rpmClearanceModReader == null || rpmClearanceCreReader == null
				|| rpmClearanceDelReader == null) {
			initRPMClearanceReaders();
		}
		try {
			String failedProduct = getfailedProductInProviousRunIfExist();
			if (failedProduct != null && failedProduct.length() != 0) {
				identifiedFailedProduct = failedProduct.split("_")[0];
				String module = failedProduct.split("_")[1];

				LOGGER.info("Product :" + identifiedFailedProduct
						+ " failed in Last Run for " + runIdentifier
						+ " Import will restart from this product");

				deletefailedProductInProviousRun();

				if ("cre".equals(module)) {
					writeCreDataPrices();
				} else if ("mod".equals(module)) {
					writeModDataPrices();
				} else if ("del".equals(module)) {
					writeDelData();
				}

			} else {
				writeCreDataPrices();
				writeModDataPrices();
				writeDelData();
				deletefailedProductInProviousRun();
				deletefailedEventMapFileInPreviousRun();
				LOGGER.info("Successfully imported data for " + new Date());
			}
		} catch (ArrayIndexOutOfBoundsException exception) {
			ImportResource.setErrorString(runIdentifier,
					"Array index out of bound Exception");
			try {
				writeFailedProductDetailsToFile();
				// Writing the Event data map to file in case of failure.
				writeFailedProductDetailsMapToFile(clearanceDataEventMap);

			} // Catch IOException
			catch (IOException e) {
				LOGGER.error("Error creating errorfile for " + runIdentifier, e);

			}
			LOGGER.error("Error importing data", exception);

		} catch (Exception exception) {
			ImportResource.setErrorString(runIdentifier, exception.toString());
			try {
				writeFailedProductDetailsToFile();
				// Writing the Event data map to file in case of failure.
				writeFailedProductDetailsMapToFile(clearanceDataEventMap);

			} catch (IOException e) {

				LOGGER.error("Error creating errorfile for " + runIdentifier, e);

			}

			LOGGER.error("Error importing data", exception);

		} finally {
			if (!rejectedProducts.isEmpty()) {
				ImportResource.getImportSemaphoreForIdentifier(runIdentifier)
						.release();

				String date = Dockyard.getSysDate("yyyyMMddHHmmss");
				String rejectfilepath = this.configuration.getRejectFilePath();

				if (rejectfilepath != null && rejectfilepath.length() > 0) {
					getDockyard().writeProductDetailsToFile(
							rejectfilepath + "/REJECT_FILE_" + runIdentifier
									+ "_" + date + ".log", rejectedProducts);
				} else {
					LOGGER.error("Invalid reject file path : {}",
							rejectfilepath);
				}
				rejectedProducts.clear();

			}
		}
	}

	/**
	 * Method deletefailedProductInProviousRun
	 */
	private void deletefailedProductInProviousRun() {
		try {
			rpmClrFailedDatafile = getRpmClrFailedDatafile(configuration
					.getRpmClrImportFailedFile()
					+ "/RR_RPM_"
					+ runIdentifier
					+ ".txt");
			if (rpmClrFailedDatafile.exists()) {
				Files.deleteIfExists(rpmClrFailedDatafile.toPath());
				LOGGER.info(rpmClrFailedDatafile.getName() + " is deleted ");
			} else {
				LOGGER.info(rpmClrFailedDatafile + " does not exist to delete ");
			}
		} catch (Exception e) {
			LOGGER.error(" file delete failed ", e);
		}
	}

	private Optional<ClearanceProduct> getClearanceProduct(String tpnb) {
		String key = PriceConstants.CLEARANCE_KEY_PREFIX + tpnb;
		ClearanceProduct product = null;
		try {
			product = (ClearanceProduct) repository.getGenericObject(key,ClearanceProduct.class);
		} catch (DataAccessException e) {
			LOGGER.error("Error occurred in getting ClearanceProduct."+e);
		}

		return (product != null) ? Optional.of(product) : Optional
				.<ClearanceProduct> absent();
	}

	/**
	 * Method insertDataForClearance
	 *
	 * @param clearanceProduct
	 */
	private void insertDataForClearance(ClearanceProduct clearanceProduct)
			throws Exception {
		String key = PriceConstants.CLEARANCE_KEY_PREFIX + clearanceProduct.getProductId();
		repository.insertObject(key, clearanceProduct);
	}

	/**
	 * Method removeExpiredClearance This function will iterate the document and
	 * remove the expired clearance field.
	 *
	 * @param clearanceProduct
	 *            and msgType (Cre/Mod/Del)
	 */
	private ClearanceProduct removeExpiredClearance(
			ClearanceProduct clearanceProduct, String msgType)
			throws ParseException {

		List<String> effDateZoneList = new ArrayList<>();
		List<String> zoneKeyList = new ArrayList<>();
		List<String> effDateStoreList = new ArrayList<>();
		List<String> storeKeyList = new ArrayList<>();
		List<String> tpncKeyList = new ArrayList<>();

		Calendar cal = Calendar.getInstance();
		SimpleDateFormat dateFormatFromCb = new SimpleDateFormat(
				"yyyy-MM-dd'T'HH:mm:ss");
		Date currDate = dateFormatFromCb.parse(dateFormatFromCb.format(cal
				.getTime()));

		for (String tpncKey : clearanceProduct
				.getTpncToClearanceProductVariant().keySet()) {

			ClearanceProductVariant clearanceProductVariant = clearanceProduct
					.getClearanceProductVariantByTPNC(tpncKey);
			if (clearanceProductVariant == null) {
				LOGGER.warn(
						"Product variant {} doesn't have CRE/MOD records. Unable to delete the record. ",
						tpncKey);
				return null;
			}

			for (String zoneKey : clearanceProductVariant.getZonePrices()
					.keySet()) {
				ClearanceZoneSaleInfo clearanceZoneSaleInfo = clearanceProductVariant
						.getClearanceZoneSaleInfo(zoneKey);
				if (clearanceZoneSaleInfo != null) {
					Set<Map.Entry<String, ClearanceByDateTime>> newZoneCollection = clearanceZoneSaleInfo
							.getZoneClearancePriceByDateTime().entrySet();

					for (Map.Entry<String, ClearanceByDateTime> newEndDateTime : newZoneCollection) {
						Date endDate = dateFormatFromCb.parse(newEndDateTime
								.getValue().getEndDateTime());
						long diffDays = (currDate.getTime() - endDate.getTime())
								/ (24 * 60 * 60 * 1000);
						if (diffDays > this.configuration
								.getClearanceExpiredays()) {
							effDateZoneList.add(newEndDateTime.getKey());
						}
					}
					clearanceZoneSaleInfo.getZoneClearancePriceByDateTime()
							.keySet().removeAll(effDateZoneList);
					effDateZoneList.clear();
				} else {
					LOGGER.warn(
							"Product variant {} doesn't have Item/Zone data. Unable to delete the expired record. ",
							tpncKey);
					return null;
				}

				if (clearanceZoneSaleInfo.getZoneClearancePriceByDateTime()
						.isEmpty() && ("DEL").equals(msgType)) {
					zoneKeyList.add(zoneKey);
				}
			}

			clearanceProductVariant.getZonePrices().keySet()
					.removeAll(zoneKeyList);
			zoneKeyList.clear();

			for (String storeKey : clearanceProductVariant.getStoreExceptions()
					.keySet()) {
				ClearanceStoreSaleInfo clearanceStoreSaleInfo = clearanceProductVariant
						.getClearanceStoreSaleInfo(storeKey);
				if (clearanceStoreSaleInfo != null) {
					Set<Map.Entry<String, ClearanceByDateTime>> newStoreCollection = clearanceStoreSaleInfo
							.getStoreClearancePriceByDateTime().entrySet();

					for (Map.Entry<String, ClearanceByDateTime> newEndDateTime : newStoreCollection) {
						Date endDate = dateFormatFromCb.parse(newEndDateTime
								.getValue().getEndDateTime());
						long diffDays = (currDate.getTime() - endDate.getTime())
								/ (24 * 60 * 60 * 1000);
						if (diffDays > this.configuration
								.getClearanceExpiredays()) {
							effDateStoreList.add(newEndDateTime.getKey());
						}
					}
					clearanceStoreSaleInfo.getStoreClearancePriceByDateTime()
							.keySet().removeAll(effDateStoreList);
					effDateStoreList.clear();
				} else {
					LOGGER.warn(
							"Product variant {} doesn't have Item/Store data. Unable to delete the expired record. ",
							tpncKey);
					return null;
				}

				if (clearanceStoreSaleInfo.getStoreClearancePriceByDateTime()
						.isEmpty() && ("DEL").equals(msgType)) {
					storeKeyList.add(storeKey);
				}
			}

			clearanceProductVariant.getStoreExceptions().keySet()
					.removeAll(storeKeyList);
			storeKeyList.clear();

			if (clearanceProductVariant.getZonePrices().isEmpty()
					&& clearanceProductVariant.getStoreExceptions().isEmpty()
					&& ("DEL").equals(msgType)) {
				tpncKeyList.add(tpncKey);
			}
		}

		clearanceProduct.getTpncToClearanceProductVariant().keySet()
				.removeAll(tpncKeyList);
		tpncKeyList.clear();

		if (clearanceProduct.getTpncToClearanceProductVariant().isEmpty()
				&& ("DEL").equals(msgType)) {
			repository.deleteProduct("CLRPROD_"
					+ clearanceProduct.getProductId());

			LOGGER.info("Expired Product " + clearanceProduct.getProductId()
					+ " deleted...!!");
			return null;
		}

		return clearanceProduct;
	}

	/**
	 * Method writeCreDataPrices
	 * 
	 * @return
	 * @throws EventPublishException
	 * @throws Exception
	 */

	private void writeCreDataPrices() throws IOException, ParseException,
			EventPublishException {

		Map<String, String> productInfoMap;
		final RPMClearanceProductMapper rpmClearanceProductMapper = new RPMClearanceProductMapper(
				repository);
		ClearanceProduct clearanceProduct = new ClearanceProduct();
		String prevItem = null;
		String curItem = null;
		String currency = null;
		boolean isNewProduct = false;
		boolean continueLoop = false;
		int recordsInsertedCount = 0;
		int recordsRejectedCount = 0;
		int recordsTotalRead = 0;

		boolean isLoadfmfailedEventMapfile = false;

		clearanceDataEventMap = new ClearanceEventData();

		while ((productInfoMap = rpmClearanceCreReader.getNext()) != null) {

			RPMCLEARANCEMETRICS.logMessageProcessingStartTime();
			RPMCLEARANCEMETRICS.logCreClearanceProcessingStartTime();
			recordsTotalRead++;
			String tpnb = productInfoMap
					.get(CSVHeaders.RpmClearance_Cre_Mod.TPNB);
			String endDate = productInfoMap
					.get(CSVHeaders.RpmClearance_Cre_Mod.END_DATE);
			if (endDate != null && endDate.length() != 0) {
				if (identifiedFailedProduct == null
						|| (identifiedFailedProduct != null && identifiedFailedProduct
								.length() == 0)
						|| (identifiedFailedProduct != null && tpnb
								.contains(identifiedFailedProduct))
						|| continueLoop) {
					lastProductId = tpnb + "_" + "cre";
					continueLoop = true;
					curItem = productInfoMap.get(
							CSVHeaders.RpmClearance_Cre_Mod.TPNB).split("-")[0];

					// PRIS-1662- Reading the map from filein case of failure
					if (!isLoadfmfailedEventMapfile
							&& (curItem.equals(identifiedFailedProduct))) {
						clearanceDataEventMap = readFailedProductDetailsMapFromFile();
						deletefailedEventMapFileInPreviousRun();
						isLoadfmfailedEventMapfile = true;

					}
					if (Dockyard.isSpaceOrNull(prevItem)
							&& !Dockyard.isSpaceOrNull(curItem)) {
						isNewProduct = true;
					} else if (prevItem != null && !curItem.equals(prevItem)) {
						if (clearanceProduct.getProductId() != null) {
							if (!oneTimeRunType.equalsIgnoreCase(runIdentifier)) {
								clearanceProduct = removeExpiredClearance(
										clearanceProduct, "CRE");
							}
							try {
								insertDataForClearance(clearanceProduct);
								recordsInsertedCount++;
							} catch (Exception ex) {
								recordsRejectedCount++;
								LOGGER.warn(
										"Couchbase Error.. Cannot create Clearance Record.",
										tpnb);
								rejectedProducts.add(tpnb + "|COUCHBASE ERROR");
								RPMCLEARANCEMETRICS.incrementCreErrorCount();
							}

						}
						isNewProduct = true;
					}
					// Check if isNewProduct
					if (isNewProduct) {
						if (!oneTimeRunType.equalsIgnoreCase(runIdentifier)) {
							currentClearanceProduct = getClearanceProduct(curItem
									.split("-")[0]);
						} else {
							currentClearanceProduct = Optional
									.of(new ClearanceProduct(
											curItem.split("-")[0]));
						}
					}

						clearanceProduct = rpmClearanceProductMapper
								.mapRPMClearanceCreAndModPrice(
										productInfoMap,
										currentClearanceProduct.isPresent() ? currentClearanceProduct
												.get() : new ClearanceProduct(
												curItem.split("-")[0]),
										isNewProduct);

						// PRIS-1662-Below method to populate the data from file
						// to map for clearance Event Handler
						if (isEligibleToSendEventDataBasedOnExpiryDate(endDate,
								runIdentifier)) {
							populateRPMClearanceDataEventMap(productInfoMap,
									currency, endDate, clearanceDataEventMap);
						}
					prevItem = curItem;
					isNewProduct = false;
				}
			} else {
				recordsRejectedCount++;
				LOGGER.warn(
						"Product {} not processed as there is no end date.",
						tpnb);
				rejectedProducts.add(tpnb + "|NULL END DATE");
				RPMCLEARANCEMETRICS.incrementCreErrorCount();
			}
			RPMCLEARANCEMETRICS.logCreClearanceProcessingEndTime();
			RPMCLEARANCEMETRICS.logMessageProcessingEndTime();

		}

		if (clearanceProduct.getProductId() != null) {

			if (!oneTimeRunType.equalsIgnoreCase(runIdentifier)) {
				clearanceProduct = removeExpiredClearance(clearanceProduct,
						"CRE");
			}
			try {
				insertDataForClearance(clearanceProduct);
				recordsInsertedCount++;
			} catch (Exception ex) {
				recordsRejectedCount++;
				LOGGER.warn(
						"Couchbase Error.. Cannot create Clearance Record.",
						clearanceProduct.getProductId());
				rejectedProducts.add(clearanceProduct.getProductId()
						+ "|COUCHBASE ERROR");
				RPMCLEARANCEMETRICS.incrementCreErrorCount();

			}
		}

		// PRIS-1662 -Below method send the data read from file to clearence
		// Event Handler
		if (clearanceDataEventMap.size() > 0) {
			clearanceEventHandler
					.publishEventsForClearances(clearanceDataEventMap);
		}

		// Added for PRIS-2203
		LOGGER.info("CRE Clearance documents processed : "
				+ recordsInsertedCount);
		LOGGER.info("CRE Clearance documents rejected : "
				+ recordsRejectedCount);
		LOGGER.info("CRE Clearance total documents read : " + recordsTotalRead);

	}

	/**
	 * Method writeDelData
	 * 
	 * @return
	 * @throws Exception
	 */
	private void writeDelData() throws Exception {

		Map<String, String> productInfoMap;
		final RPMClearanceProductMapper rpmClearanceProductMapper = new RPMClearanceProductMapper(
				repository);
		ClearanceProduct clearanceProduct = new ClearanceProduct();
		String prevItem = null;
		String curItem = null;
		boolean isNewProduct = false;
		boolean continueLoop = false;
		boolean isLoadfmfailedEventMapfile = false;
		clearanceDataEventMap = new ClearanceEventData();
		int recordsInsertedCount = 0;
		int recordsRejectedCount = 0;
		int recordsTotalRead = 0;

		while ((productInfoMap = rpmClearanceDelReader.getNext()) != null) {

			RPMCLEARANCEMETRICS.logMessageProcessingStartTime();
			RPMCLEARANCEMETRICS.logDelClearanceProcessingStartTime();

			recordsTotalRead++;
			String tpnb = productInfoMap
					.get(CSVHeaders.RpmClearance_Cre_Mod.TPNB);
			String location = productInfoMap
					.get(CSVHeaders.RpmClearance_Del.LOCATION);
			String tpnc = productInfoMap
					.get(CSVHeaders.RpmClearance_Cre_Mod.TPNC);

			if (identifiedFailedProduct == null
					|| (identifiedFailedProduct != null && identifiedFailedProduct
							.length() == 0)
					|| (identifiedFailedProduct != null && tpnb
							.contains(identifiedFailedProduct)) || continueLoop) {
				continueLoop = true;
				lastProductId = tpnb + "_" + "del";
				curItem = productInfoMap.get(
						CSVHeaders.RpmClearance_Cre_Mod.TPNB).split("-")[0];
				if (!isLoadfmfailedEventMapfile
						&& (curItem.equals(identifiedFailedProduct))) {
					clearanceDataEventMap = readFailedProductDetailsMapFromFile();
					deletefailedEventMapFileInPreviousRun();
					isLoadfmfailedEventMapfile = true;
				}
				if (Dockyard.isSpaceOrNull(prevItem)
						&& !Dockyard.isSpaceOrNull(curItem)) {
					isNewProduct = true;
				} else if (prevItem != null && !curItem.equals(prevItem)) {
					if (clearanceProduct != null
							&& clearanceProduct.getProductId() != null) {
						clearanceProduct = removeExpiredClearance(
								clearanceProduct, "DEL");
						if (clearanceProduct != null) {
							try {
								insertDataForClearance(clearanceProduct);
								recordsInsertedCount++;
							} catch (Exception ex) {
								recordsRejectedCount++;
								LOGGER.warn(
										"Couchbase Error.. Cannot create Clearance Record.",
										tpnb);
								rejectedProducts.add(tpnb + "|COUCHBASE ERROR");
								RPMCLEARANCEMETRICS.incrementDelErrorCount();

							}
						}
					}
					isNewProduct = true;
				}

				if (isNewProduct) {
					currentClearanceProduct = getClearanceProduct(curItem
							.split("-")[0]);
				}

				if (currentClearanceProduct.isPresent()) {
					ClearanceProduct newClearanceProduct = rpmClearanceProductMapper
							.mapRPMClearanceDelPrice(productInfoMap,
									currentClearanceProduct.get(), isNewProduct);
					if (Dockyard.isSpaceOrNull(newClearanceProduct)) {
						LOGGER.warn(
								"Product {} not processed as item/location or tpnc not found to delete.",
								tpnb);
						rejectedProducts.add(tpnb + "|TPNC :" + tpnc
								+ " - LOCATION :" + location
								+ " NOT FOUND TO DELETE or TPNC: " + tpnc
								+ " NOT FOUND TO DELETE");
						recordsRejectedCount++;
						RPMCLEARANCEMETRICS.incrementDelErrorCount();
					} else {
						clearanceProduct = newClearanceProduct;
					}

					String currency = rpmClearanceProductMapper.getCurrency();
					String endDate = rpmClearanceProductMapper.getendDate();
					// PRIS-1662-Below method to populate the data from file to
					// map for clearance Event Handler

					if (isEligibleToSendEventDataBasedOnExpiryDate(endDate)
							&& newClearanceProduct != null) {
						populateRPMClearanceDataEventMap(productInfoMap,
								currency, clearanceDataEventMap);
					}

				} else {

					LOGGER.warn(
							"Product {} doesn't have CRE/MOD records. Unable to delete the record. ",
							tpnb);
					rejectedProducts.add(tpnb
							+ "| NO CLR PRODUCT IDENTIFIED TO DELETE");
					recordsRejectedCount++;
					RPMCLEARANCEMETRICS.incrementDelErrorCount();
				}
				prevItem = curItem;
				isNewProduct = false;
			}
			RPMCLEARANCEMETRICS.logDelClearanceProcessingEndTime();
			RPMCLEARANCEMETRICS.logMessageProcessingEndTime();

		}

		if (clearanceProduct != null && clearanceProduct.getProductId() != null) {

			clearanceProduct = removeExpiredClearance(clearanceProduct, "DEL");
			if (clearanceProduct != null) {
				try {
					insertDataForClearance(clearanceProduct);
					recordsInsertedCount++;
				} catch (Exception ex) {
					recordsRejectedCount++;
					LOGGER.warn(
							"Couchbase Error.. Cannot create Clearance Record.",
							clearanceProduct.getProductId());
					rejectedProducts.add(clearanceProduct.getProductId()
							+ "|COUCHBASE ERROR");
					RPMCLEARANCEMETRICS.incrementDelErrorCount();

				}
			}
		}

		// PRIS-1663 -Below method send the data read from file to clearence
		// Event Handler
		if (clearanceDataEventMap.size() > 0) {
			clearanceEventHandler
					.publishEventsForClearances(clearanceDataEventMap);
		}

		// Added for PRIS-2203
		LOGGER.info("DEL Clearance documents processed : "
				+ recordsInsertedCount);
		LOGGER.info("DEL Clearance documents rejected : "
				+ recordsRejectedCount);
		LOGGER.info("DEL Clearance total documents read : " + recordsTotalRead);

	}

	/**
	 * Method writeFailedProductDetailsToFile
	 *
	 * @throws IOException
	 */
	private void writeFailedProductDetailsToFile() throws IOException {
		rpmClrFailedDatafile = getRpmClrFailedDatafile(configuration
				.getRpmClrImportFailedFile()
				+ "/RR_RPM_"
				+ runIdentifier
				+ ".txt");

		fileWriter = getFileWriter(rpmClrFailedDatafile);
		bufferedWriter = getBufferedWriter(fileWriter);

		bufferedWriter.write(lastProductId);
		bufferedWriter.flush();
		bufferedWriter.close();
	}

	/**
	 * Method writeModDataPrices
	 *
	 * @throws IOException
	 * @throws ParseException
	 * @throws EventPublishException
	 */
	private void writeModDataPrices() throws IOException, ParseException,
			EventPublishException {

		Map<String, String> productInfoMap;
		final RPMClearanceProductMapper rpmClearanceProductMapper = new RPMClearanceProductMapper(
				repository);
		ClearanceProduct clearanceProduct = new ClearanceProduct();
		String prevItem = null;
		String curItem = null;
		String currency = null;
		boolean isNewProduct = false;
		boolean continueLoop = false;
		boolean isLoadfmfailedEventMapfile = false;
		clearanceDataEventMap = new ClearanceEventData();
		int recordsInsertedCount = 0;
		int recordsRejectedCount = 0;
		int recordsTotalRead = 0;

		while ((productInfoMap = rpmClearanceModReader.getNext()) != null) {

			RPMCLEARANCEMETRICS.logMessageProcessingStartTime();
			RPMCLEARANCEMETRICS.logModClearanceProcessingStartTime();

			recordsTotalRead++;
			String tpnb = productInfoMap
					.get(CSVHeaders.RpmClearance_Cre_Mod.TPNB);
			String endDate = productInfoMap
					.get(CSVHeaders.RpmClearance_Cre_Mod.END_DATE);

			if (endDate.length() != 0) {
				if (identifiedFailedProduct == null
						|| (identifiedFailedProduct != null && identifiedFailedProduct
								.length() == 0)
						|| (identifiedFailedProduct != null && tpnb
								.contains(identifiedFailedProduct))
						|| continueLoop) {
					lastProductId = tpnb + "_" + "mod";
					continueLoop = true;
					curItem = productInfoMap.get(
							CSVHeaders.RpmClearance_Cre_Mod.TPNB).split("-")[0];
					// PRIS-1639- Reading the map from filein case of failure
					if (!isLoadfmfailedEventMapfile
							&& (curItem.equals(identifiedFailedProduct))) {
						clearanceDataEventMap = readFailedProductDetailsMapFromFile();
						deletefailedEventMapFileInPreviousRun();
						isLoadfmfailedEventMapfile = true;

					}
					if (Dockyard.isSpaceOrNull(prevItem)
							&& !Dockyard.isSpaceOrNull(curItem)) {
						isNewProduct = true;
					} else if (prevItem != null && !curItem.equals(prevItem)) {
						if (clearanceProduct.getProductId() != null) {
							if (!oneTimeRunType.equalsIgnoreCase(runIdentifier)) {

								clearanceProduct = removeExpiredClearance(
										clearanceProduct, "MOD");
							}
							try {
								insertDataForClearance(clearanceProduct);
								recordsInsertedCount++;
							} catch (Exception ex) {
								recordsRejectedCount++;
								LOGGER.warn(
										"Couchbase Error.. Cannot create Clearance Record.",
										tpnb);
								rejectedProducts.add(tpnb + "|COUCHBASE ERROR");
								RPMCLEARANCEMETRICS.incrementModErrorCount();

							}
						}
						isNewProduct = true;
					}

					// Check if isNewProduct

					if (isNewProduct) {
						currentClearanceProduct = getClearanceProduct(curItem
								.split("-")[0]);
					}

					if (currentClearanceProduct.isPresent()) {
						clearanceProduct = rpmClearanceProductMapper
								.mapRPMClearanceCreAndModPrice(productInfoMap,
										currentClearanceProduct.get(),
										isNewProduct);

					} else {

							ClearanceProduct newClearanceProduct = new ClearanceProduct(
									curItem.split("-")[0]);
							clearanceProduct = rpmClearanceProductMapper
									.mapRPMClearanceCreAndModPrice(
											productInfoMap,
											newClearanceProduct, isNewProduct);

					}

					// PRIS-1639-Below method to populate the data from file to
					// map, used by clearance Event Handler
					String oldClearanceEndDate = rpmClearanceProductMapper
							.getendDate();

					if ((isEligibleToSendEventDataBasedOnExpiryDate(endDate,
							runIdentifier))
							&& ((oldClearanceEndDate == null) || (isClearanceEndDateChanged(
									oldClearanceEndDate, endDate)))) {

						populateRPMClearanceDataEventMap(productInfoMap,
								currency, oldClearanceEndDate,
								clearanceDataEventMap);
					}

					prevItem = curItem;
					isNewProduct = false;
				}
			} else {
				LOGGER.warn(
						"Product {} not processed as there is no end date.",
						tpnb);
				rejectedProducts.add(tpnb + "|NULL END DATE");
				recordsRejectedCount++;
				RPMCLEARANCEMETRICS.incrementModErrorCount();
			}
			RPMCLEARANCEMETRICS.logModClearanceProcessingEndTime();
			RPMCLEARANCEMETRICS.logMessageProcessingEndTime();

		}

		if (clearanceProduct.getProductId() != null) {

			if (!oneTimeRunType.equalsIgnoreCase(runIdentifier)) {
				clearanceProduct = removeExpiredClearance(clearanceProduct,
						"MOD");

			}
			try {
				insertDataForClearance(clearanceProduct);
				recordsInsertedCount++;
			} catch (Exception ex) {
				recordsRejectedCount++;
				LOGGER.warn(
						"Couchbase Error.. Cannot create Clearance Record.",
						clearanceProduct.getProductId());
				rejectedProducts.add(clearanceProduct.getProductId()
						+ "|COUCHBASE ERROR");
				RPMCLEARANCEMETRICS.incrementModErrorCount();

			}
		}

		// PRIS-1639 -Below method send the data read from file to clearance
		// Event Handler
		if (clearanceDataEventMap.size() > 0) {
			clearanceEventHandler
					.publishEventsForClearances(clearanceDataEventMap);
		}

		// Added for PRIS-2203
		LOGGER.info("MOD Clearance documents processed : "
				+ recordsInsertedCount);
		LOGGER.info("MOD Clearance documents rejected : "
				+ recordsRejectedCount);
		LOGGER.info("MOD Clearance total documents read : " + recordsTotalRead);
	}

	/*
	 * PRIS1662-RPMClearanceCreated This method populate the map with necessary
	 * event data and doing the grouping based on productid and
	 * effectiveDate.After the file clerance data wrote to CB, the Event
	 * Publisher will take the data from the map and publish all the event.
	 */
	private static void populateRPMClearanceDataEventMap(
			Map<String, String> productInfoMap, String currency,
			String oldClearanceEndDate,
			Map<String, Set<String>> clearanceDataEventMap)
			throws ParseException {
		Set<String> storeClearanceSet = null;

		StringBuilder keyBuilder = buildKeyforRPMClearance(productInfoMap,
				oldClearanceEndDate);

		if (clearanceDataEventMap.containsKey(keyBuilder.toString())) {

			storeClearanceSet = clearanceDataEventMap
					.get(keyBuilder.toString());
		} else {
			storeClearanceSet = new HashSet<String>();
		}

		StringBuilder dataSetKey = new StringBuilder();
		dataSetKey.append(productInfoMap
				.get(CSVHeaders.RpmClearance_Cre_Mod.LOCATION_TYPE));
		dataSetKey.append(UNDERSCORE_SEPARATOR);
		dataSetKey.append(productInfoMap
				.get(CSVHeaders.RpmClearance_Cre_Mod.LOCATION));
		dataSetKey.append(UNDERSCORE_SEPARATOR);
		dataSetKey.append(productInfoMap
				.get(CSVHeaders.RpmClearance_Cre_Mod.CLEARANCE_ID));
		storeClearanceSet.add(dataSetKey.toString());
		clearanceDataEventMap.put(keyBuilder.toString(), storeClearanceSet);
		currency = null;
	}

	/*
	 * PRIS1663-RPMClearanceDeleted This method populate the map with necessary
	 * event data, which is published after file operation to CB
	 */

	private static void populateRPMClearanceDataEventMap(
			Map<String, String> productInfoMap, String currency,
			Map<String, Set<String>> clearanceDataEventMap)
			throws ParseException {

		Set<String> storeClearanceSet = null;
		String oldClearance = null;
		StringBuilder keyBuilder = buildKeyforRPMClearance(productInfoMap,
				oldClearance, currency);

		if (clearanceDataEventMap.containsKey(keyBuilder.toString())) {

			storeClearanceSet = clearanceDataEventMap
					.get(keyBuilder.toString());
		} else {
			storeClearanceSet = new HashSet<String>();
		}

		StringBuilder dataSetKey = new StringBuilder();
		dataSetKey.append(productInfoMap
				.get(CSVHeaders.RpmClearance_Del.LOCATION_TYPE));
		dataSetKey.append(UNDERSCORE_SEPARATOR);
		dataSetKey.append(productInfoMap
				.get(CSVHeaders.RpmClearance_Del.LOCATION));
		dataSetKey.append(UNDERSCORE_SEPARATOR);
		dataSetKey.append(productInfoMap
				.get(CSVHeaders.RpmClearance_Del.CLEARANCE_ID));
		storeClearanceSet.add(dataSetKey.toString());
		clearanceDataEventMap.put(keyBuilder.toString(), storeClearanceSet);

	}

	/**
	 * @param endDate
	 * @param runIdentifier
	 * @return
	 * @throws ParseException
	 */
	private boolean isEligibleToSendEventDataBasedOnExpiryDate(String endDate,
			String runIdentifier) throws ParseException {
		if (!oneTimeRunType.equalsIgnoreCase(runIdentifier)) {
			DateTime dateTime = new DateTime();
			String endDateFormat = Dockyard
					.getISO8601FormatStartDateForRpmClr(endDate);
			SimpleDateFormat dateFormatFromCb = new SimpleDateFormat(
					"yyyy-MM-dd'T'HH:mm:ss");
			Date endDateofClearance = dateFormatFromCb.parse(endDateFormat);
			Date currDate = dateFormatFromCb.parse(dateFormatFromCb
					.format(dateTime.toDate().getTime()));
			long diffDays = (currDate.getTime() - endDateofClearance.getTime())
					/ (24 * 60 * 60 * 1000);
			return diffDays < configuration.getClearanceExpiredays();
		} else {
			return true;
		}
	}

	/**
	 * @param productInfoMap
	 * @return
	 * @throws ParseException
	 *             This method prepare key to clearanceDataEventMap in case of
	 *             Del, which is used for clearance message grouping
	 */
	private static StringBuilder buildKeyforRPMClearance(
			Map<String, String> productInfoMap, String oldClearanceEndDate,
			String currency) throws ParseException {

		StringBuilder keyBuilder = new StringBuilder();
		oldClearanceEndDate = null;
		String tpnc = productInfoMap.get(CSVHeaders.RpmClearance_Del.TPNC);
		DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");
		Calendar cal = Calendar.getInstance();
		String keyDate = dateFormat.format(cal.getTime());
		String keyDateformat = Dockyard
				.getISO8601FormatStartDateForRpmClr(keyDate);
		String locationType = productInfoMap
				.get(CSVHeaders.RpmClearance_Del.LOCATION_TYPE);

		keyBuilder
				.append(PriceConstants.TPNC_IDENTIFIER + COLON_SEPARATOR + tpnc)
				.append(UNDERSCORE_SEPARATOR).append(locationType)
				.append(UNDERSCORE_SEPARATOR).append(keyDateformat)
				.append(UNDERSCORE_SEPARATOR).append(currency)
				.append(UNDERSCORE_SEPARATOR)
				.append(PriceConstants.DELETE_ACTION_FILE_CODE);
		LOGGER.info("keyBuilder :" + keyBuilder.toString());

		return keyBuilder;
	}

	private boolean isEligibleToSendEventDataBasedOnExpiryDate(String endDate)
			throws ParseException {

		if (endDate == null) {
			return true;
		} else {
			DateTime dateTime = new DateTime();
			SimpleDateFormat dateFormatFromCb = new SimpleDateFormat(
					"yyyy-MM-dd'T'HH:mm:ss");
			Date endDateofClearance = dateFormatFromCb.parse(endDate);
			Date currDate = dateFormatFromCb.parse(dateFormatFromCb
					.format(dateTime.toDate().getTime()));
			long diffDays = (currDate.getTime() - endDateofClearance.getTime())
					/ (24 * 60 * 60 * 1000);
			return diffDays < configuration.getClearanceExpiredays();
		}
	}

	private static StringBuilder buildKeyforRPMClearance(
			Map<String, String> productInfoMap, String oldClearanceEndDate)
			throws ParseException {
		StringBuilder keyBuilder = new StringBuilder();
		String tpnc = productInfoMap.get(CSVHeaders.RpmClearance_Cre_Mod.TPNC);
		String currency = productInfoMap
				.get(CSVHeaders.RpmClearance_Cre_Mod.SELLING_CURRENCY);
		String effectiveDate = Dockyard
				.getISO8601FormatStartDateForRpmClr(productInfoMap
						.get(CSVHeaders.RpmClearance_Cre_Mod.EFFECTIVE_DATE));
		String locationType = productInfoMap
				.get(CSVHeaders.RpmClearance_Cre_Mod.LOCATION_TYPE);

		// For Cre
		if ((productInfoMap.get(CSVHeaders.RpmClearance_Cre_Mod.EVENT_TYPE)
				.equals(PriceConstants.RPM_CLR_CRE))
				|| (productInfoMap.get(
						CSVHeaders.RpmClearance_Cre_Mod.EVENT_TYPE).equals(
						PriceConstants.RPM_CLR_MOD) && oldClearanceEndDate == null)) {

			keyBuilder
					.append(PriceConstants.TPNC_IDENTIFIER + COLON_SEPARATOR
							+ tpnc).append(UNDERSCORE_SEPARATOR)
					.append(locationType).append(UNDERSCORE_SEPARATOR)
					.append(effectiveDate).append(UNDERSCORE_SEPARATOR)
					.append(currency).append(UNDERSCORE_SEPARATOR)
					.append(PriceConstants.INSERT_ACTION_FILE_CODE);

		}
		// For Mod
		else if (productInfoMap.get(CSVHeaders.RpmClearance_Cre_Mod.EVENT_TYPE)
				.equals(PriceConstants.RPM_CLR_MOD)
				&& oldClearanceEndDate != null) {

			keyBuilder
					.append(PriceConstants.TPNC_IDENTIFIER + COLON_SEPARATOR
							+ tpnc)
					.append(UNDERSCORE_SEPARATOR)
					.append(locationType)
					.append(UNDERSCORE_SEPARATOR)
					.append(oldClearanceEndDate)
					.append(UNDERSCORE_SEPARATOR)
					.append(currency)
					.append(UNDERSCORE_SEPARATOR)
					.append(PriceConstants.UPDATE_CLR_END_DATE_ACTION_FILE_CODE);
		}

		LOGGER.info("keyBuilder :" + keyBuilder.toString());
		return keyBuilder;
	}

	/**
	 * Method writeFailedProductDetailsMapToFile This method write the
	 * clearanceDataEventMap to the file
	 * 
	 * @throws IOException
	 */
	private void writeFailedProductDetailsMapToFile(
			Map<String, Set<String>> clearanceEventMap) throws IOException {

		rpmClrFailedEventMapfile = getRpmClrFailedEventMapfile(configuration
				.getRpmClrImportFailedFile()
				+ "/RR_RPM_EVENTMAP_"
				+ runIdentifier + ".txt");

		ObjectMapper mapper = new ObjectMapper();
		mapper.writeValue(rpmClrFailedEventMapfile, clearanceEventMap);
	}

	/**
	 * Method readFailedProductDetailsMapFromFile This method populate the
	 * clearanceDataEventMap from the file
	 * 
	 * @throws IOException
	 * @throws JsonMappingException
	 * @throws JsonParseException
	 * @throws Exception
	 */
	private ClearanceEventData readFailedProductDetailsMapFromFile()
			throws JsonParseException, JsonMappingException, IOException {

		ClearanceEventData clearanceFailedDataEventMap = new ClearanceEventData();
		rpmClrFailedEventMapfile = getRpmClrFailedEventMapfile(configuration
				.getRpmClrImportFailedFile()
				+ "/RR_RPM_EVENTMAP_"
				+ runIdentifier + ".txt");
		ObjectMapper mapper = new ObjectMapper();

		clearanceFailedDataEventMap = mapper.readValue(
				rpmClrFailedEventMapfile,
				new TypeReference<ClearanceEventData>() {
				});

		return clearanceFailedDataEventMap;
	}

	/**
	 * Method deletefailedProductInProviousRun
	 */
	private void deletefailedEventMapFileInPreviousRun() {
		try {

			rpmClrFailedEventMapfile = getRpmClrFailedEventMapfile(configuration
					.getRpmClrImportFailedFile()
					+ "/RR_RPM_EVENTMAP_"
					+ runIdentifier + ".txt");
			if (rpmClrFailedEventMapfile.exists()) {
				Files.deleteIfExists(rpmClrFailedEventMapfile.toPath());
				LOGGER.info(rpmClrFailedEventMapfile.getName() + " is deleted ");
			} else {
				LOGGER.info(rpmClrFailedEventMapfile
						+ " does not exist to delete ");
			}
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * @param oldClearanceEndDate
	 * @param newClearanceEndDateChanged
	 * @return
	 * @throws ParseException
	 */
	public static boolean isClearanceEndDateChanged(String oldClearanceEndDate,
			String newClearanceEndDateChanged) throws ParseException {
		String newEndDatewithTime = Dockyard
				.getISO8601FormatEndDateForRPMClr(newClearanceEndDateChanged);
		return !oldClearanceEndDate.equals(newEndDatewithTime);
	}

}
