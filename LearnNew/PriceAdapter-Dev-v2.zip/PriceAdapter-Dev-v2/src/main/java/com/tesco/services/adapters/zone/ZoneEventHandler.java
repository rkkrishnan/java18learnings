package com.tesco.services.adapters.zone;

import java.util.List;
import java.util.Map;

import com.tesco.services.adapters.core.exceptions.ZoneEventException;
import com.tesco.services.core.ZoneEntity;
import com.tesco.zone.core.TSLZoneGroupDesc;
import com.tesco.zone.core.TSLZoneGroupRef;

public interface ZoneEventHandler {


	public List<String> publishZoneEvent(TSLZoneGroupDesc tslZoneGroupDesc,String zoneEventType) throws ZoneEventException;
	public List<String> publishZoneDelEvent(TSLZoneGroupRef tslZoneGroupRef, Map<String,ZoneEntity> zoneCountryCodeMap) throws ZoneEventException;
	
	List<String> publishStoreZoneChangeCreEvent(TSLZoneGroupDesc tslZoneGroupDesc,Map<String,ZoneEntity> storeZoneCountryCodeMap ) throws ZoneEventException;
	List<String> publishStoreZoneChangeRemoveEvent(TSLZoneGroupRef tslZoneGroupRef,Map<String,ZoneEntity> storeZoneCountryCodeMap) throws ZoneEventException;
	
}

