package com.tesco.services.adapters.core;

import com.tesco.services.Configuration;
import com.tesco.services.adapters.rpm.writers.impl.RPMSubGroupDfltUomMapper;
import com.tesco.services.adapters.rpm.writers.Writer;
import com.tesco.services.resources.ImportResource;
import com.tesco.services.utility.PriceConstants;
import com.tesco.services.utility.WebServiceCallBuilder;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Response;
import java.net.URI;

public class ImportSubGroupDfltUomJob implements Import {

	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(ImportSubGroupDfltUomJob.class);

	private Configuration configuration;
	private String runIdentifier;
	private String fileName;
	private Writer rpmMapper;
	private WebServiceCallBuilder serviceClient;

	public void setServiceClient(WebServiceCallBuilder serviceClient) {
		this.serviceClient = serviceClient;
	}

	/**
	 * @param configuration
	 */
	@Inject
	public ImportSubGroupDfltUomJob(
			@Named("configuration") Configuration configuration,
			@Named("webServiceCallBuilder") WebServiceCallBuilder serviceClient,
			@Named("rpmMapper") Writer rpmMapper) {
		this.configuration = configuration;
		this.serviceClient = serviceClient;
		this.rpmMapper = rpmMapper;
	}

	public String getRunIdentifier() {
		return runIdentifier;
	}

	public void setRunIdentifier(String runIdentifier) {
		this.runIdentifier = runIdentifier;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	@Override
	public void run() {
		LOGGER.info(
				"Firing up imports for SubGroup Default Mapping for OneTime{}",
				runIdentifier);
		startImportProcess();

	}

	@Override
	public void startImportProcess() {
		try {
			LOGGER.info("Importing data for SubGroup Default from {} ",
					configuration.getRpmSubgroupDataDumpPath());
			((RPMSubGroupDfltUomMapper)rpmMapper).setRunIdentifier(runIdentifier);
			rpmMapper.write(fileName);
			String[] serviceServerTypes = configuration
					.getServiceServerUrlTypes();
			for (String serverType : serviceServerTypes) {
				String serviceUrl = serverType
						.concat(PriceConstants.REFRESH_URL_SUBGROUP);

				URI refreshUrl = serviceClient
						.getResourceURIToRefreshService(serviceUrl);
				Response response = serviceClient.callRemoteServer(refreshUrl);
				if (response.getStatus() == HttpServletResponse.SC_OK) {
					LOGGER.info("Sub group refresh completed ..");
				} else {
					throw new Exception("Sub group Refresh failed !!");
				}
			}
			LOGGER.info("Successfully completed imports for SubGroup Default");
		} catch (Exception exception) {
			LOGGER.error("Error importing ..", exception);
			ImportResource.setErrorString(runIdentifier,
					"Error importing Onetime SubGroup Default Mapping..");
		} finally {
			ImportResource.getImportSemaphoreForIdentifier(fileName).release();
		}
	}
}
