package com.tesco.services.exceptions;

/**
 * Created by wr38 on 26/05/2016.
 */
public class ZoneJMXException extends Exception {

	public ZoneJMXException() {
		// TODO Auto-generated constructor stub
	}

	public ZoneJMXException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ZoneJMXException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public ZoneJMXException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ZoneJMXException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}
}
