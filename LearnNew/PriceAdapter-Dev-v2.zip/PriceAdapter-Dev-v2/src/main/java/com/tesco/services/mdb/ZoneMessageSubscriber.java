package com.tesco.services.mdb;

import java.util.HashSet;
import java.util.Set;

import javax.inject.Inject;
import javax.inject.Named;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;
import javax.jms.TopicSession;

import org.slf4j.Logger;
import org.xml.sax.SAXException;

import com.tesco.logging.LogWriter;
import com.tesco.logging.LoggerRepository;
import com.tesco.services.Configuration;
import com.tesco.services.adapters.rpm.readers.MessageRouter;
import com.tesco.services.core.jms.JMSTopicTransactionHandler;
import com.tesco.services.exceptions.MessageRouterException;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.PriceConstants;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;

/**
 * Created by qz88 on 05/10/2015.
 */
public class ZoneMessageSubscriber extends JMSTopicTransactionHandler implements
		MessageListener {

	private static final String ZONE_MESSAGE_LOGGER = "ZoneMessageLogger";
	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(ZoneMessageSubscriber.class);

	private static final LogWriter MSGLOGGER = LoggerRepository
			.getLogger(ZONE_MESSAGE_LOGGER);

	@Inject
	@Named("zoneMsgRouter")
	private MessageRouter zoneMessageRouter;

	@Inject
	@Named("configuration")
	private Configuration configuration;

	private Dockyard dockyard;

	private int retryCount;
	private TopicSession topicSession;

	public ZoneMessageSubscriber() {
		setTopicSession(getTopicSession());
		setRetryCount(getRetryCount());
	}

	public void setRetryCount(int retryCount) {
		this.retryCount = retryCount;
	}

	public void setTopicSession(TopicSession topicSession) {
		this.topicSession = topicSession;
	}

	public void setZoneMessageRouter(MessageRouter zoneMessageRouter) {
		this.zoneMessageRouter = zoneMessageRouter;
	}

	public void setConfiguration(Configuration configuration) {
		this.configuration = configuration;
	}

	public Dockyard getDockyard() {
		if (dockyard == null) {
			dockyard = new Dockyard();
		}
		return dockyard;
	}

	@Override
	public void onMessage(Message message) {
		String text = null;
		if (message instanceof TextMessage) {
			TextMessage textMessage = (TextMessage) message;
			try {
				text = textMessage.getText();
				LOGGER.info("Message Received : {}", text);
				/*
				 * Added For PRIS-2005 & PRIS-2020 ,Save the price messages if
				 * captureMessages is set to true
				 */
				if (textMessage.getIntProperty("JMSXDeliveryCount") == 1) {
					MSGLOGGER.info(Dockyard.getSysDate(
							PriceConstants.ISO_8601_FORMAT).concat(" - ")
							+ text);
				}
				zoneMessageRouter.route(text);

				/** Once the message is successfully consumed then commit. */
				topicSession.commit();

			} catch (MessageRouterException e) {
				LOGGER.error("error   : {} -> {}", e.getCause(), e.getMessage());
				LOGGER.error("Trace For the error", e.getCause());

				try {
					if (e.getCause() instanceof SAXException) {
						topicSession.commit();
						Set<String> errorMessage = new HashSet<>();
						errorMessage.add(text);
						LOGGER.info("Max retries attempts reached. Logging message to error file");
						getDockyard().writeProductDetailsToFile(
								this.configuration.getRejectFilePath() + "/"
										+ PriceConstants.ZONE_REJ_FILE + "_"
										+ Dockyard.getSysDate("yyyyMMdd")
										+ ".log", errorMessage);

					} else {
						if (textMessage.getIntProperty("JMSXDeliveryCount") <= retryCount) {
							LOGGER.error("Retrying "
									+ textMessage
											.getIntProperty("JMSXDeliveryCount")
									+ " out of " + getRetryCount() + " ...");
							topicSession.rollback();
						} else {
							Set<String> errorMessage = new HashSet<>();
							errorMessage.add(text);
							LOGGER.info("Max retries attempts reached. Logging message to error file");
							getDockyard().writeProductDetailsToFile(
									this.configuration.getRejectFilePath()
											+ "/"
											+ PriceConstants.ZONE_REJ_FILE
											+ "_"
											+ Dockyard.getSysDate("yyyyMMdd")
											+ ".log", errorMessage);

							topicSession.commit();
						}

					}
				} catch (JMSException e1) {
					LOGGER.error(
							"error : {Error in retry procedure after exception } -> {} {}",
							e1.getCause(), e1.getMessage());
				}

			} catch (JMSException e) {
				LOGGER.error(
						"error   : {Error when getting data from the message object} -> {}",
						e.getCause(), e.getMessage());
				LOGGER.error("Trace For the error", e.getCause());
			}

		} else {
			LOGGER.info("Message Received: {}", message);
		}
	}
}
