package com.tesco.services.adapters.core;

import com.tesco.services.adapters.rpm.writers.impl.PromotionWriter;
import com.tesco.services.Configuration;
import com.tesco.services.adapters.rpm.writers.Writer;
import com.tesco.services.resources.PromotionResource;
import com.tesco.services.utility.PriceConstants;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;
import org.slf4j.Logger;
import javax.inject.Inject;
import javax.inject.Named;

/**
 * This class validates the run identifier and fetches the file path .
 */
public class ImportPromotionJob implements Import {

	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(ImportPromotionJob.class);

	private Configuration configuration;
	private Writer promotionWriter;
	private String fileName;
	private String runIdentifier;

	/**
	 * @param configuration
	 * @param promotionWriter
	 */
	@Inject
	public ImportPromotionJob(
			@Named("configuration") Configuration configuration,
			@Named("promotionWriter") Writer promotionWriter) {
		this.configuration = configuration;
		this.promotionWriter = promotionWriter;
	}

	public String getRunIdentifier() {
		return runIdentifier;
	}

	public void setRunIdentifier(String runIdentifier) {
		this.runIdentifier = runIdentifier;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	@Override
	public void run() {
		LOGGER.info("Firing up Promotion imports for {}", runIdentifier);
		startImportProcess();
	}

	public void startImportProcess() {
		try {
			LOGGER.info("Importing data for onetime promotion from {} ",
					configuration.getPromotionFilePath());
			((PromotionWriter) promotionWriter)
					.setRunIdentifier(getRunIdentifier());
			promotionWriter.write(fileName);
			LOGGER.info(
					"Successfully completed imports for RPM Onetime Promotion data");

			if (runIdentifier.equalsIgnoreCase(
					PriceConstants.PROMOTION_IMPORT_TYPES.ONETIME.value())) {
				LOGGER.info("Importing data Promotion OneTime....");

			}
		} catch (Exception exception) {
			LOGGER.error(
					"Error importing onetime Promotion data :",
					exception);
			PromotionResource.setErrorString(fileName, "Error importing onetime Promotion data");
		} finally {
			PromotionResource.getImportSemaphoreForIdentifier(fileName).release();
		}
	}
}
