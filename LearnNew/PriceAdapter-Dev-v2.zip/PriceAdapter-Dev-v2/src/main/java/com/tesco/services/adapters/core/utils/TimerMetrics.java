package com.tesco.services.adapters.core.utils;

import static com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility.ANY;
import static com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility.NONE;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@SuppressWarnings("serial")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonAutoDetect(fieldVisibility = ANY, getterVisibility = NONE, setterVisibility = NONE)
public class TimerMetrics implements Serializable {
	@JsonProperty
	private String count;
	@JsonProperty
	private LatencyMetrics latency;
	@JsonProperty
	private RateMetrics throughput;

	public String getCount() {
		return count;
	}

	public void setCount(String count) {
		this.count = count;
	}

	public LatencyMetrics getLatency() {
		return latency;
	}

	public void setLatency(LatencyMetrics latency) {
		this.latency = latency;
	}

	public RateMetrics getThroughput() {
		return throughput;
	}

	public void setThroughput(RateMetrics throughput) {
		this.throughput = throughput;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((count == null) ? 0 : count.hashCode());
		result = prime * result + ((latency == null) ? 0 : latency.hashCode());
		result = prime * result
				+ ((throughput == null) ? 0 : throughput.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TimerMetrics other = (TimerMetrics) obj;
		if (count == null) {
			if (other.count != null)
				return false;
		} else if (!count.equals(other.count))
			return false;
		if (latency == null) {
			if (other.latency != null)
				return false;
		} else if (!latency.equals(other.latency))
			return false;
		if (throughput == null) {
			if (other.throughput != null)
				return false;
		} else if (!throughput.equals(other.throughput))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "TimerMetrics [count=" + count + ", latency=" + latency
				+ ", throughput=" + throughput + "]";
	}

}
