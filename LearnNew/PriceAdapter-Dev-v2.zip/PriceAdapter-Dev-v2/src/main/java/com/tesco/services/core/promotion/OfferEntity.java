package com.tesco.services.core.promotion;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import static com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility.ANY;
import static com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility.NONE;

/**
 * @author a185
 */
@SuppressWarnings("serial")
@JsonAutoDetect(fieldVisibility = ANY, getterVisibility = NONE,
		setterVisibility = NONE)
public class OfferEntity implements Serializable {

	@JsonProperty("offerRef")
	private String offerRef;

	@JsonProperty("offerLocRef")
	private Map<String, OfferLocRefEntity> offerLocRef = new HashMap<>();


	@JsonProperty("offerLocRef")
	public Map<String, OfferLocRefEntity> getOfferLocRef() {
		return offerLocRef;
	}

	@JsonProperty("offerLocRef")
	public void setOfferLocRef(Map<String, OfferLocRefEntity> offerLocRef) {
		this.offerLocRef = offerLocRef;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OfferEntity other = (OfferEntity) obj;

		if (offerLocRef == null) {
			if (other.offerLocRef != null)
				return false;
		} else if (!offerLocRef.equals(other.offerLocRef))
			return false;
		if (offerRef == null) {
			if (other.offerRef != null)
				return false;
		} else if (!offerRef.equals(other.offerRef))
			return false;
		return true;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((offerLocRef == null) ? 0 : offerLocRef.hashCode());
		result = prime * result
				+ ((offerRef == null) ? 0 : offerRef.hashCode());
		return result;
	}

	@JsonProperty("offerRef")
	public void setOfferRef(String offerRef) {
		this.offerRef = offerRef;
	}

	@Override
	public String toString() {
		return "OfferEntity [offerRef=" + offerRef + ", offerLocRef="
				+ offerLocRef + "]";
	}

}
