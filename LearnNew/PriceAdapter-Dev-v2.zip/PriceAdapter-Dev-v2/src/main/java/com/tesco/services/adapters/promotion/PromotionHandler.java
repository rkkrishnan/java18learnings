package com.tesco.services.adapters.promotion;


import com.tesco.promotion.core.PrmPrcChgDtl;
import com.tesco.promotion.core.PrmPrcChgDtlRef;
import com.tesco.services.core.promotion.PromotionEntity;
import com.tesco.services.exceptions.DataAccessException;
import com.tesco.services.exceptions.PromoBusinessException;

import java.util.List;
import java.util.Map;

public interface PromotionHandler {
    public Map<String, Object> processCreMessage(PromotionEntity promotionEntity, List<PrmPrcChgDtl> prmPrcChgDtl,
			String promoMsgForZoneId, String msgState, String msgOfferType,
			String promoMsgLocType)
			throws PromoBusinessException, DataAccessException;


    public Map<String, Object> processDelMessage(List<PrmPrcChgDtlRef> prmPrcChgDtlRefs,
			String promoMsgForZoneId) throws PromoBusinessException;

	public Map<String, Object> processModMessage(PromotionEntity promotionEntity,
			List<PrmPrcChgDtl> prmPrcChgDtl, String promoMsgForZoneId,
			String msgState, String msgOfferType, String promoMsgLocType)
			throws PromoBusinessException, DataAccessException;

}
