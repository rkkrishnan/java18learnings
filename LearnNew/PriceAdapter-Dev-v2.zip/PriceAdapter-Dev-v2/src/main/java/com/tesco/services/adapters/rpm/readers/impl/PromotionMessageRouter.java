package com.tesco.services.adapters.rpm.readers.impl;

import java.io.IOException;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;

import com.tesco.services.adapters.rpm.readers.MessageRouter;
import com.tesco.services.repositories.Repository;
import com.tesco.services.repositories.RepositoryImpl;
import org.slf4j.Logger;
import org.xml.sax.SAXException;

import com.tesco.promotion.core.PrmPrcChgDesc;
import com.tesco.promotion.core.PrmPrcChgDtl;
import com.tesco.promotion.core.PrmPrcChgDtlRef;
import com.tesco.promotion.core.PrmPrcChgRef;
import com.tesco.services.adapters.core.exceptions.PromotionEventException;
import com.tesco.services.adapters.core.utils.PromotionMetrics;
import com.tesco.services.adapters.promotion.PromotionEventHandler;
import com.tesco.services.adapters.promotion.PromotionHandler;
import com.tesco.services.core.promotion.PromotionEntity;
import com.tesco.services.exceptions.MessageRouterException;
import com.tesco.services.exceptions.PromoBusinessException;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.ParseMessageUtil;
import com.tesco.services.utility.PriceConstants;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;

/**
 * This class will identify the Type of Promo Message and Processes the same
 */
public class PromotionMessageRouter implements MessageRouter {

	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(PromotionMessageRouter.class);

	private PromotionHandler simplePromotionHandler;
	private PromotionHandler thresholdPromotionHandler;
	private PromotionHandler multibuyPromotionHandler;
	private ParseMessageUtil parseMessageUtil;
	private PromotionMetrics promotionMetrics = PromotionMetrics.getInstance();
	private Repository repository;
	private boolean isMetricsEnabled = false;
	private PromotionEventHandler promotionEventHandler;

	@Inject
	public PromotionMessageRouter(
			@Named("simplePromoHandler") PromotionHandler simplePromotionHandler,
			@Named("thresholdPromoHandler") PromotionHandler thresholdPromotionHandler,
			@Named("multiBuyPromoHandler") PromotionHandler multibuyPromotionHandler,
			@Named("repository") Repository repository,
			@Named("promoEvtHandler") PromotionEventHandler promotionEventHandler) {
		this.simplePromotionHandler = simplePromotionHandler;
		this.thresholdPromotionHandler = thresholdPromotionHandler;
		this.multibuyPromotionHandler = multibuyPromotionHandler;
		this.repository = repository;
		isMetricsEnabled = true;
		this.promotionEventHandler = promotionEventHandler;
	}

	@Override
	public void route(String text) throws MessageRouterException {

		String promoMsgType = null;
		String promoMsgState = null;
		String promoMsgForZoneId = null;
		String promoMsgOfferType = null;
		String promoMsgLocType = null;
		Map<String, Object> allEventsData = null;

		try {
			if (isMetricsEnabled) {
				promotionMetrics.logMessageProcessingStartTime();
			}

			parseMessageUtil = parseMessageUtil != null ? parseMessageUtil
					: ParseMessageUtil.getInstance();
			promoMsgType = parseMessageUtil.getNodeData(text,
					PriceConstants.PROMO_MSG_TYPE_PATH);
			String promoDescData = parseMessageUtil.getNodeData(text,
					PriceConstants.PROMO_MSG_DATA_PATH);

			if (PriceConstants.PROMO_MSG_TYPE_DEL.equals(promoMsgType)) {

				PrmPrcChgRef promotionsToBeDeleted = (PrmPrcChgRef) parseMessageUtil
						.getMappedObjectForXmlData(PrmPrcChgRef.class,
								promoDescData);
				promoMsgForZoneId = promotionsToBeDeleted.getTslZoneId()
						.toString();
				promoMsgLocType = promotionsToBeDeleted.getLocType();
				String promoMsgForZoneIdAndType = promoMsgLocType
						+ promoMsgForZoneId;
				for (PrmPrcChgDtlRef prmPrcChgDtlRef : promotionsToBeDeleted
						.getPrmPrcChgDtlRef()) {

					if (Dockyard.isSpaceOrNull(promoMsgOfferType)
							&& Dockyard.isSpaceOrNull(promoMsgState)) {
						promoMsgOfferType = getOfferTypeForDeleteMsg(prmPrcChgDtlRef);
					}
					if (PriceConstants.PROMO_SIMPLE_OFFER_TYPE
							.equals(promoMsgOfferType)) {
						if (isMetricsEnabled) {
							promotionMetrics
									.logSimpleDelPromoProcessingStartTime();
						}
						allEventsData = simplePromotionHandler
								.processDelMessage(promotionsToBeDeleted
										.getPrmPrcChgDtlRef(),
										promoMsgForZoneIdAndType);
						if (isMetricsEnabled) {
							promotionMetrics
									.logSimpleDelPromoProcessingEndTime();
						}
					}
					if (PriceConstants.PROMO_THRESHOLD_OFFER_TYPE
							.equals(promoMsgOfferType)) {
						if (isMetricsEnabled) {
							promotionMetrics
									.logThresholdDelPromoProcessingStartTime();
						}
						allEventsData = thresholdPromotionHandler
								.processDelMessage(promotionsToBeDeleted
										.getPrmPrcChgDtlRef(),
										promoMsgForZoneIdAndType);
						if (isMetricsEnabled) {
							promotionMetrics
									.logThresholdDelPromoProcessingEndTime();
						}
					}
					if (PriceConstants.PROMO_MB_OFFER_TYPE
							.equals(promoMsgOfferType)) {
						if (isMetricsEnabled) {
							promotionMetrics
									.logMultibuyDelPromoProcessingStartTime();
						}
						allEventsData = multibuyPromotionHandler
								.processDelMessage(promotionsToBeDeleted
										.getPrmPrcChgDtlRef(),
										promoMsgForZoneIdAndType);
						if (isMetricsEnabled) {
							promotionMetrics
									.logMultibuyDelPromoProcessingEndTime();
						}
					}
					break;
				}

			} else {

				PrmPrcChgDesc promotions = (PrmPrcChgDesc) parseMessageUtil
						.getMappedObjectForXmlData(PrmPrcChgDesc.class,
								promoDescData);
				promoMsgForZoneId = promotions.getTslZoneId().toString();
				promoMsgLocType = promotions.getLocType();

				for (PrmPrcChgDtl prmPrcChgDtl : promotions.getPrmPrcChgDtl()) {
					if (Dockyard.isSpaceOrNull(promoMsgOfferType)
							&& Dockyard.isSpaceOrNull(promoMsgState)) {
						promoMsgOfferType = getOfferTypeForDetail(prmPrcChgDtl);
						promoMsgState = getPromoStateForDetail(prmPrcChgDtl
								.getTslState());
					}
					if (PriceConstants.PROMO_SIMPLE_OFFER_TYPE
							.equals(promoMsgOfferType)) {
						if (isMetricsEnabled) {
							promotionMetrics
									.logSimpleCreModPromoProcessingStartTime();
						}
						if (!("0").equals(prmPrcChgDtl.getPrmPrcChgSmp()
								.getMerchType().toString())) {
							throw new MessageRouterException(
									"Invalid Message - with non zero merch type - Simple promotion");
						}
						PromotionEntity promotionEntity = (PromotionEntity) repository
								.getGenericObject(
										PriceConstants.PROMOTION_DOC_KEY_PREFIX
												+ prmPrcChgDtl
														.getTslPromoCompDisplayId()
												+ "_" + promoMsgLocType
												+ promoMsgForZoneId,
										PromotionEntity.class);
						if ((PriceConstants.PROMO_MSG_TYPE_CRE
								.equals(promoMsgType) && promotionEntity != null)
								|| (PriceConstants.PROMO_MSG_TYPE_MOD
										.equals(promoMsgType) && promotionEntity != null)) {
							allEventsData = simplePromotionHandler
									.processModMessage(promotionEntity,
											promotions.getPrmPrcChgDtl(),
											promoMsgForZoneId, promoMsgState,
											promoMsgOfferType, promoMsgLocType);
						} else {
							allEventsData = simplePromotionHandler
									.processCreMessage(promotionEntity,
											promotions.getPrmPrcChgDtl(),
											promoMsgForZoneId, promoMsgState,
											promoMsgOfferType, promoMsgLocType);
						}
						if (isMetricsEnabled) {
							promotionMetrics
									.logSimpleCreModPromoProcessingEndTime();
						}

					}
					if (PriceConstants.PROMO_THRESHOLD_OFFER_TYPE
							.equals(promoMsgOfferType)) {
						if (isMetricsEnabled) {
							promotionMetrics
									.logThresholdCreModPromoProcessingStartTime();
						}
						PromotionEntity promotionEntity = (PromotionEntity) repository
								.getGenericObject(
										PriceConstants.PROMOTION_DOC_KEY_PREFIX
												+ prmPrcChgDtl
														.getTslPromoCompDisplayId()
												+ "_" + promoMsgLocType
												+ promoMsgForZoneId,
										PromotionEntity.class);
						if ((PriceConstants.PROMO_MSG_TYPE_CRE
								.equals(promoMsgType) || PriceConstants.PROMO_MSG_TYPE_MOD
								.equals(promoMsgType))
								&& promotionEntity != null) {
							// Mod
							allEventsData = thresholdPromotionHandler
									.processModMessage(promotionEntity,
											promotions.getPrmPrcChgDtl(),
											promoMsgForZoneId, promoMsgState,
											promoMsgOfferType, promoMsgLocType);
						} else {

							allEventsData = thresholdPromotionHandler
									.processCreMessage(promotionEntity,
											promotions.getPrmPrcChgDtl(),
											promoMsgForZoneId, promoMsgState,
											promoMsgOfferType, promoMsgLocType);
						}
						if (isMetricsEnabled) {
							promotionMetrics
									.logThresholdCreModPromoProcessingEndTime();
						}

					}
					if (PriceConstants.PROMO_MB_OFFER_TYPE
							.equals(promoMsgOfferType)) {
						if (isMetricsEnabled) {
							promotionMetrics
									.logMultibuyCreModPromoProcessingStartTime();
						}
						PromotionEntity promotionEntity = (PromotionEntity) repository
								.getGenericObject(
										PriceConstants.PROMOTION_DOC_KEY_PREFIX
												+ prmPrcChgDtl
														.getTslPromoCompDisplayId()
												+ "_" + promoMsgLocType
												+ promoMsgForZoneId,
										PromotionEntity.class);
						allEventsData = multibuyPromotionHandler
								.processCreMessage(promotionEntity,
										promotions.getPrmPrcChgDtl(),
										promoMsgForZoneId, promoMsgState,
										promoMsgOfferType, promoMsgLocType);
						if (isMetricsEnabled) {
							promotionMetrics
									.logMultibuyCreModPromoProcessingEndTime();
						}
					}
					break;
				}

			}
			if (allEventsData != null) {
				promotionEventHandler.processPromotionEvents(promoMsgType,
						promoMsgForZoneId, promoMsgLocType, allEventsData);
			}

		} catch (IOException | ParserConfigurationException | JAXBException
				| XPathExpressionException | SAXException
				| PromoBusinessException | PromotionEventException e) {
			if (isMetricsEnabled) {
				promotionMetrics.logMessageProcessingEndTime();
			}
			if (PriceConstants.PROMO_MSG_TYPE_DEL.equals(promoMsgType)) {
				if (PriceConstants.PROMO_SIMPLE_OFFER_TYPE
						.equals(promoMsgOfferType) && isMetricsEnabled) {

					promotionMetrics.logSimpleDelPromoProcessingEndTime();

				} else if (PriceConstants.PROMO_THRESHOLD_OFFER_TYPE
						.equals(promoMsgOfferType) && isMetricsEnabled) {

					promotionMetrics.logThresholdDelPromoProcessingEndTime();

				} else if (PriceConstants.PROMO_MB_OFFER_TYPE
						.equals(promoMsgOfferType) && isMetricsEnabled) {

					promotionMetrics.logMultibuyDelPromoProcessingEndTime();
				}
			} else {
				if (PriceConstants.PROMO_SIMPLE_OFFER_TYPE
						.equals(promoMsgOfferType) && isMetricsEnabled) {

					promotionMetrics.logSimpleCreModPromoProcessingEndTime();

				} else if (PriceConstants.PROMO_THRESHOLD_OFFER_TYPE
						.equals(promoMsgOfferType) && isMetricsEnabled) {

					promotionMetrics.logThresholdCreModPromoProcessingEndTime();

				} else if (PriceConstants.PROMO_MB_OFFER_TYPE
						.equals(promoMsgOfferType) && isMetricsEnabled) {
					promotionMetrics.logMultibuyCreModPromoProcessingEndTime();

				}
			}

			if (isMetricsEnabled) {
				promotionMetrics.incrementErrorCount();
			}

			throw new MessageRouterException(e.getMessage(), e);
		} catch (Exception e) {
			if (PriceConstants.PROMO_MSG_TYPE_DEL.equals(promoMsgType)) {
				if (PriceConstants.PROMO_SIMPLE_OFFER_TYPE
						.equals(promoMsgOfferType) && isMetricsEnabled) {
					promotionMetrics.logSimpleDelPromoProcessingEndTime();
				} else if (PriceConstants.PROMO_THRESHOLD_OFFER_TYPE
						.equals(promoMsgOfferType) && isMetricsEnabled) {

					promotionMetrics.logThresholdDelPromoProcessingEndTime();
				} else if (PriceConstants.PROMO_MB_OFFER_TYPE
						.equals(promoMsgOfferType) && isMetricsEnabled) {
					promotionMetrics.logMultibuyDelPromoProcessingEndTime();
				}
			} else {
				if (PriceConstants.PROMO_SIMPLE_OFFER_TYPE
						.equals(promoMsgOfferType) && isMetricsEnabled) {
					promotionMetrics.logSimpleCreModPromoProcessingEndTime();
				} else if (PriceConstants.PROMO_THRESHOLD_OFFER_TYPE
						.equals(promoMsgOfferType) && isMetricsEnabled) {
					promotionMetrics.logThresholdCreModPromoProcessingEndTime();
				} else if (PriceConstants.PROMO_MB_OFFER_TYPE
						.equals(promoMsgOfferType) && isMetricsEnabled) {
					promotionMetrics.logMultibuyCreModPromoProcessingEndTime();
				}
			}

			if (isMetricsEnabled) {
				promotionMetrics.incrementErrorCount();
			}
			throw new MessageRouterException(e.getMessage(), e);
		}
		if (isMetricsEnabled) {
			promotionMetrics.logMessageProcessingEndTime();
		}

	}

	public String getOfferTypeForDetail(PrmPrcChgDtl promotionDtl) {
		String offerType;
		if (promotionDtl.getPrmPrcChgSmp() != null) {
			offerType = PriceConstants.PROMO_SIMPLE_OFFER_TYPE;
		} else if (promotionDtl.getPrmPrcChgThr() != null) {
			offerType = PriceConstants.PROMO_THRESHOLD_OFFER_TYPE;
		} else {
			offerType = PriceConstants.PROMO_MB_OFFER_TYPE;
		}
		return offerType;
	}

	public String getOfferTypeForDeleteMsg(PrmPrcChgDtlRef prmPrcChgDtlRef) {
		String offerType;
		if (prmPrcChgDtlRef.getPrmPrcChgSmpDtlRef() != null) {
			offerType = PriceConstants.PROMO_SIMPLE_OFFER_TYPE;
		} else if (prmPrcChgDtlRef.getPrmPrcChgThrDtlRef() != null) {
			offerType = PriceConstants.PROMO_THRESHOLD_OFFER_TYPE;
		} else {
			offerType = PriceConstants.PROMO_MB_OFFER_TYPE;
		}
		return offerType;
	}

	public String getPromoStateForDetail(String promoMsgState) {
		String promoState = "";
		if (promoMsgState.equals(PriceConstants.PROMO_MSG_RAW_NEW_STATE)
				|| promoMsgState
						.equals(PriceConstants.PROMO_MSG_RAW_REAPPROVED_STATE)) {
			promoState = PriceConstants.PROMO_MSG_APPROVED_STATE;
		}
		if (promoMsgState.equals(PriceConstants.PROMO_MSG_RAW_CANCELLED_STATE)) {
			/*
			 * If the state is cancelled also we considered as approved since we
			 * maintain only approved state.
			 */
			promoState = PriceConstants.PROMO_MSG_APPROVED_STATE;
		}
		if (promoMsgState.equals(PriceConstants.PROMO_MSG_RAW_DELETED_STATE)) {
			promoState = PriceConstants.PROMO_MSG_DELETED_STATE;
		}
		return promoState;
	}

	public void setParseMessageUtil(ParseMessageUtil parseMessageUtil) {
		this.parseMessageUtil = parseMessageUtil;
	}

}
