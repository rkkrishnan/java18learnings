package com.tesco.services.utility;

import com.tesco.services.Configuration;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;
import org.slf4j.Logger;

import java.io.*;
import java.nio.file.Files;

/**
 * Created by QU17 on 18/03/2015.
 */
public class FileOperations {
    private static final Logger LOGGER = (Logger) LoggerFactoryWrapper.getLogger(FileOperations.class);
    File file;
    FileReader fileReader;
    BufferedReader bufferedReader;
    FileWriter fileWriter;

    public void setBufferedWriter(BufferedWriter bufferedWriter) {
        this.bufferedWriter = bufferedWriter;
    }

    public void setFileWriter(FileWriter fileWriter) {
        this.fileWriter = fileWriter;
    }

    BufferedWriter bufferedWriter;

    public BufferedReader getBufferedReader(FileReader reader) {
        if(bufferedReader ==null){
           bufferedReader =new BufferedReader(reader) ;

        }
        return bufferedReader;
    }

    public void setBufferedReader(BufferedReader bufferedReader) {
        this.bufferedReader = bufferedReader;
    }


    public File getFile(String path) {
        if (file == null) {
            file = new File(path);
        }
        return file;
    }

    public void setFile(File file) {
        this.file = file;
    }

    public FileReader getFileReader(File failedDatafile ) throws FileNotFoundException {

        if (fileReader == null) {
            fileReader = new FileReader(failedDatafile);
        }
        return fileReader;
    }
    public FileWriter getFileWriter(File file) throws IOException{
        if(fileWriter == null){
            fileWriter = new FileWriter(file);
        }
        return fileWriter;
    }

    public BufferedWriter getBufferedWriter(FileWriter writer) {
        if(bufferedWriter ==null){
            bufferedWriter =new BufferedWriter(writer) ;

        }
        return bufferedWriter;
    }

    public void setFileReader(FileReader fileReader) {
        this.fileReader = fileReader;
    }

    public String getfailedProductInProviousRunIfExist(Configuration configuration,String fileName) throws IOException {
        file = getFile(configuration.getMmClrImportFailedFile() + "/" + fileName);
        String line;

        String failedProduct = "";
        try {
            fileReader = getFileReader(file);
            bufferedReader = getBufferedReader(fileReader);
            while ((line = bufferedReader.readLine()) != null) {
                failedProduct = line;
            }
            bufferedReader.close();
        } catch (Exception e) {
            LOGGER.error("Failed to read the file : {} ErrorMsg : {}" , fileName,e.toString());
            return null;

        }
        return failedProduct;
    }

    public void deletefailedProductInProviousRun(Configuration configuration,String fileName) {
        try {
            File f = new File(configuration.getMmClrImportFailedFile() + "/"+fileName);
            if (f.exists()) {
                Files.deleteIfExists(f.toPath());

                LOGGER.info(f.getName() + " is deleted ");

            } else {

                LOGGER.info(f + " does not exist to delete ");

            }
        } catch (Exception e) {

            LOGGER.error(" file delete failed ");

        }
    }
    public void writeFailedProductDetailsToFile(Configuration configuration,String fileName,String item) throws IOException{
        file = getFile(configuration.getMmClrImportFailedFile()+"/"+fileName);
        fileWriter = getFileWriter(file);
        bufferedWriter = getBufferedWriter(fileWriter);
        bufferedWriter.write(item);
        bufferedWriter.flush();
        bufferedWriter.close();
    }
}
