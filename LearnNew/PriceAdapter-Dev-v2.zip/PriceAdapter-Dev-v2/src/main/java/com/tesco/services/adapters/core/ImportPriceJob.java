package com.tesco.services.adapters.core;

import javax.inject.Inject;
import javax.inject.Named;

import org.slf4j.Logger;

import com.tesco.services.adapters.core.exceptions.WriterBusinessException;
import com.tesco.services.adapters.rpm.writers.impl.PriceWriter;
import com.tesco.services.adapters.rpm.writers.Writer;
import com.tesco.services.resources.ImportResource;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;

/**
 * Created by iv16 on 8/9/2015.
 */
public class ImportPriceJob implements Import {

	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(ImportPriceJob.class);

	private Writer priceWriter;
	private String fileName;
	private String runIdentifier;

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getRunIdentifier() {
		return runIdentifier;
	}

	public void setRunIdentifier(String runIdentifier) {
		this.runIdentifier = runIdentifier;
	}

	@Inject
	public ImportPriceJob(@Named("priceWriter") Writer priceWriter) {
		this.priceWriter = priceWriter;
	}

	@Override
	public void run() {
		LOGGER.info("Firing up Price onetime imports...");
		startImportProcess();

	}

	@Override
	public void startImportProcess() {
		try {
			((PriceWriter)priceWriter).setRunIdentifier(getRunIdentifier());
			priceWriter.write(getFileName());
		} catch (WriterBusinessException e) {
			LOGGER.error("Error importing Price onetime data", e);
			ImportResource.setErrorString(fileName,
					"Error importing Price onetime data");
		} finally {
			ImportResource.getImportSemaphoreForIdentifier(fileName).release();
		}
	}

}

