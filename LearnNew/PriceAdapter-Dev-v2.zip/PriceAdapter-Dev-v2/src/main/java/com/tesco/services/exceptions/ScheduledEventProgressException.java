package com.tesco.services.exceptions;

import static com.tesco.services.utility.PriceConstants.EVENT_ERROR_MESSAGE;
import static javax.ws.rs.core.MediaType.APPLICATION_JSON;
import static javax.ws.rs.core.Response.status;
import static javax.ws.rs.core.Response.Status.CONFLICT;
import static javax.ws.rs.core.Response.Status.NOT_FOUND;
import javax.ws.rs.WebApplicationException;

public class ScheduledEventProgressException extends WebApplicationException {

	private static final long serialVersionUID = 9069167254378610315L;

	public ScheduledEventProgressException() {
		super(status(CONFLICT).entity(EVENT_ERROR_MESSAGE).type(APPLICATION_JSON).build());
	}

	public ScheduledEventProgressException(String errorMessage) {
		super(status(NOT_FOUND).entity(errorMessage).type(APPLICATION_JSON).build());
	}

}
