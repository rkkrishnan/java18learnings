package com.tesco.services.adapters.core;

import com.tesco.services.Configuration;
import com.tesco.services.adapters.rpm.writers.impl.ProductAvgWeightWriter;
import com.tesco.services.adapters.rpm.writers.Writer;
import com.tesco.services.resources.ImportResource;
import com.tesco.services.utility.PriceConstants;
import com.tesco.services.utility.WebServiceCallBuilder;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Response;
import java.net.URI;

/**
 * Created by PO47 on 28/10/2015.
 */

public class ImportProductAvgWeightJob implements Import {
	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(ImportProductAvgWeightJob.class);

	private Writer productAvgWeightWriter;
	private String fileName;
	private Configuration configuration;
	private WebServiceCallBuilder serviceClient;
	private String runIdentifier;

	public String getRunIdentifier() {
		return runIdentifier;
	}

	public void setRunIdentifier(String runIdentifier) {
		this.runIdentifier = runIdentifier;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public void setServiceClient(WebServiceCallBuilder serviceClient) {
		this.serviceClient = serviceClient;
	}

	@Inject
	public ImportProductAvgWeightJob(
			@Named("productAvgWeightWriter") Writer productAvgWeightWriter,
			@Named("configuration") Configuration configuration,
			@Named("webServiceCallBuilder") WebServiceCallBuilder serviceClient) {
		this.productAvgWeightWriter = productAvgWeightWriter;
		this.configuration = configuration;
		this.serviceClient = serviceClient;
	}

	@Override
	public void run() {
		LOGGER.info("Firing up Product avg weight imports...");
		startImportProcess();

	}

	public void startImportProcess() {
		try {
			((ProductAvgWeightWriter)productAvgWeightWriter).setRunIdentifier(getRunIdentifier());
			productAvgWeightWriter.write(getFileName());
			String[] serviceServerTypes = configuration
					.getServiceServerUrlTypes();
			for (String serverType : serviceServerTypes) {
				String serviceUrl = serverType
						.concat(PriceConstants.REFRESH_URL_PRODUCT_AVG_WEIGHT);

				URI refreshUrl = serviceClient
						.getResourceURIToRefreshService(serviceUrl);
				Response response = serviceClient.callRemoteServer(refreshUrl);
				if (response.getStatus() == HttpServletResponse.SC_OK) {

					LOGGER.info(
							"Product Avg Weight for UK/ROI refresh completed ..");
				} else {
					throw new Exception(
							"Product Avg Weight  Refresh failed !!");
				}
			}

		} catch (Exception e) {
			LOGGER.error("Error importing Product avg weight", e);
			ImportResource.setErrorString(fileName,
					"Error importing Product avg weight");
		} finally {
			ImportResource.getImportSemaphoreForIdentifier(fileName).release();
		}
	}
}
