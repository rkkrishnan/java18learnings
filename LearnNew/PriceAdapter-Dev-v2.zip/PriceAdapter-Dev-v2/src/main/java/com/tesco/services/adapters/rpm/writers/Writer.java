package com.tesco.services.adapters.rpm.writers;

import com.tesco.services.adapters.core.exceptions.WriterBusinessException;

/**
 * Created by wa68 on 27/06/2016.
 */
public interface Writer {

	public void write(String fileName) throws WriterBusinessException;
}
