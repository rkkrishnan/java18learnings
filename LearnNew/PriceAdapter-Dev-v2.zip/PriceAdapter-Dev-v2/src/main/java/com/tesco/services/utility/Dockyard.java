package com.tesco.services.utility;

import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;

import org.joda.time.DateTime;
import org.slf4j.Logger;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Currency;
import java.util.Date;
import java.util.Set;

/**
 * Created by Nibedita on 06/08/2014.
 */
public class Dockyard {

	public Dockyard() {
	}

	private BufferedWriter bufferedWriter = null;

	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(Dockyard.class);

	public void setBufferedWriter(BufferedWriter buffWriter) {
		bufferedWriter = buffWriter;
	}

	public BufferedWriter getBufferedWriter(String filename)
			throws IOException {
		if (filename != null && filename.length() > 0) {
			File f = new File(filename);
			FileWriter fileWriter = new FileWriter(f, true);
			return new BufferedWriter(fileWriter);
		} else {
			LOGGER.error("reject file : {} does not exist", filename);
			throw new IOException("Invalid file name");
		}
	}

	/* To get the sysdate with the required format */
	public static String getSysDate(String dateFormatIn) {
		DateFormat dateFormat = new SimpleDateFormat(dateFormatIn);
		DateTime dateTime = new DateTime();
		Date date = dateTime.toDate();
		return dateFormat.format(date);

	}

	/* To check null */
	public static boolean isSpaceOrNull(Object obj) {
		if (obj == null) {
			return true;
		} else if (obj.toString().trim().isEmpty()) {
			return true;
		}
		return false;
	}

	/* To check Null and replace old char with new */
	public static String replaceOldValCharWithNewVal(String value,
			String oldChar, String newChar) {

		if (!Dockyard.isSpaceOrNull(value) && value.contains(oldChar)) {
			return value.replace(oldChar, newChar);
		} else {
			return value;
		}

	}

	/**
	 * This will Scale the price based on the currency provided based on ISO4217
	 * format.
	 *
	 * @param currency - based on currency scale of the BigDecimal value to be
	 *                 returned
	 * @param price    - amount which needs to be rounded off.
	 * @return - returns String value
	 */
	public static String priceScaleRoundHalfUp(String currency, String price) {
		String roundedPrice = null;
		if (("EU ").equalsIgnoreCase(currency)) {
			currency = "EUR";
		}
		if (!isSpaceOrNull(price) && !isSpaceOrNull(currency)) {
			Currency cur = Currency.getInstance(currency);
			roundedPrice = String.valueOf(new BigDecimal(price).setScale(
					cur.getDefaultFractionDigits(), BigDecimal.ROUND_HALF_UP));
		}
		return roundedPrice;
	}

	public static String getISO8601FormatStartDate(String StartDate)
			throws ParseException {
		SimpleDateFormat dateFormatFromFiles = new SimpleDateFormat("yyyyMMdd");
		SimpleDateFormat isodateformat = new SimpleDateFormat(
				"yyyy-MM-dd'T'HH:mm:ss");
		Date date1 = dateFormatFromFiles.parse(StartDate);

		return isodateformat.format(date1);
	}

	public static String getISO8601FormatEndDate(String endDate)
			throws ParseException {
		SimpleDateFormat dateFormatFromFiles = new SimpleDateFormat(
				"yyyyMMdd HH:mm:ss");
		String date = endDate;
		date = date + " 23:59:59";
		SimpleDateFormat isodateformat = new SimpleDateFormat(
				"yyyy-MM-dd'T'HH:mm:ss");
		Date date1 = dateFormatFromFiles.parse(date);

		return isodateformat.format(date1);
	}

	public static String getClearanceByDateTimeKeyFormat(String date)
			throws ParseException {

		SimpleDateFormat dateFormatFromFiles = new SimpleDateFormat(
				"yyyy-MM-dd'T'HH:mm:ss");
		SimpleDateFormat isodateformat = new SimpleDateFormat("yyyyMMddHHmmss");
		Date date1 = dateFormatFromFiles.parse(date);

		return isodateformat.format(date1);
	}

	/* Added for PS-386 -- Start */
	public static String getISO8601FormatStartDateForRpmClr(String StartDate)
			throws ParseException {
		SimpleDateFormat dateFormatFromFiles = new SimpleDateFormat(
				"dd-MMM-yy");
		SimpleDateFormat isodateformat = new SimpleDateFormat(
				"yyyy-MM-dd'T'HH:mm:ss");
		Date date1 = dateFormatFromFiles.parse(StartDate);

		return isodateformat.format(date1);
	}

	public static String getISO8601FormatEndDateForRPMClr(String endDate)
			throws ParseException {
		SimpleDateFormat dateFormatFromFiles = new SimpleDateFormat(
				"dd-MMM-yy HH:mm:ss");
		String date = endDate;
		date = date + " 23:59:59";
		SimpleDateFormat isodateformat = new SimpleDateFormat(
				"yyyy-MM-dd'T'HH:mm:ss");
		Date date1 = dateFormatFromFiles.parse(date);

		return isodateformat.format(date1);
	}

	public static String getClearanceByDateTimeKeyFormatForRpmClr(String date)
			throws ParseException {

		SimpleDateFormat dateFormatFromFiles = new SimpleDateFormat(
				"yyyy-MM-dd'T'HH:mm:ss");
		SimpleDateFormat isodateformat = new SimpleDateFormat("yyyyMMddHHmmss");
		Date date1 = dateFormatFromFiles.parse(date);

		return isodateformat.format(date1);
	}

	/* Added for PS-386 -- End */

	/**
	 * Function will return true if the system date is between the passed dates.
	 */
	public static Boolean checkActiveaClear(String effDate, String endDate)
			throws ParseException {
		SimpleDateFormat dateFormatFromKey = new SimpleDateFormat(
				"yyyy-MM-dd'T'HH:mm:ss");
		Date leffDate = dateFormatFromKey.parse(effDate);
		Date lendDate = dateFormatFromKey.parse(endDate);

		Calendar cal = Calendar.getInstance();
		Date sysdate = cal.getTime();
		if (!sysdate.after(leffDate) || !sysdate.before(lendDate)) {
			return false;
		}
		return true;

	}

	/**
	 * To calculate lowest of numbers
	 */
	public static String lowestOfTwoNum(String a, String b) {
		if (isSpaceOrNull(a)) {
			return b;
		} else if (isSpaceOrNull(b)) {
			return a;
		} else {
			return (Float.parseFloat(a) > Float.parseFloat(b)) ? b : a;
		}

	}

	/**
	 * @param sourceDate Source Date
	 * @param iFormat    Source Date format
	 * @param oFormat    Expected Date format
	 * @return Date string in the expected format
	 * @throws ParseException
	 */
	public static String getFormattedDate(String sourceDate, String iFormat,
			String oFormat) throws ParseException {
		SimpleDateFormat inputformat = new SimpleDateFormat(iFormat);
		SimpleDateFormat outputformat = new SimpleDateFormat(oFormat);
		return outputformat.format(inputformat.parse(sourceDate));
	}

	public void writeProductDetailsToFile(String fileName,
			Set<String> products) {
		try {
			if (bufferedWriter == null) {
				bufferedWriter = getBufferedWriter(fileName);
			}
			for (String productId : products) {
				bufferedWriter.write(productId);
				bufferedWriter.newLine();
			}
		} catch (IOException e) {
			LOGGER.error("Caught exception {}", e.getMessage());
		} finally {
			try {
				if (bufferedWriter != null) {
					bufferedWriter.flush();
					bufferedWriter.close();
					bufferedWriter = null;
				}
			} catch (IOException ioe) {
				LOGGER.error("Error closing IO Stream " + ioe);
			}
		}
	}

	public static String leftPadZero(String sourceStr, int size) {
		int srcStringSize = sourceStr.length();
		if (size == srcStringSize) {
			return sourceStr;
		}
		if (size > srcStringSize) {
			int numberofZeroToPad = size - srcStringSize;
			for (int i = 0; i < numberofZeroToPad; i++) {
				sourceStr = "0" + sourceStr;
			}
		}
		return sourceStr;
	}

	public static boolean isWithinRange(Date testDate, Date fromDate,
			Date toDate) {

		return org.apache.commons.lang.time.DateUtils
				.truncate(testDate, Calendar.DAY_OF_MONTH).getTime()
				>= org.apache.commons.lang.time.DateUtils
				.truncate(fromDate, Calendar.DAY_OF_MONTH).getTime() &&
				org.apache.commons.lang.time.DateUtils
						.truncate(testDate, Calendar.DAY_OF_MONTH).getTime()
						<= org.apache.commons.lang.time.DateUtils
						.truncate(toDate, Calendar.DAY_OF_MONTH).getTime();

	}

}