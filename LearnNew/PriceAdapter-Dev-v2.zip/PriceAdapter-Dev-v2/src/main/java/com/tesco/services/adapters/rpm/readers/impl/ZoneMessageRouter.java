package com.tesco.services.adapters.rpm.readers.impl;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;

import com.tesco.services.adapters.rpm.readers.MessageRouter;
import org.slf4j.Logger;
import org.xml.sax.SAXException;

import com.tesco.services.adapters.core.exceptions.ZoneEventException;
import com.tesco.services.adapters.core.utils.ZoneMetrics;
import com.tesco.services.adapters.zone.ZoneEventHandler;
import com.tesco.services.adapters.zone.ZoneHandler;
import com.tesco.services.core.ZoneEntity;
import com.tesco.services.exceptions.MessageRouterException;
import com.tesco.services.exceptions.ZoneBusinessException;
import com.tesco.services.utility.ParseMessageUtil;
import com.tesco.services.utility.PriceConstants;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;
import com.tesco.zone.core.TSLZoneGroupDesc;
import com.tesco.zone.core.TSLZoneGroupRef;

/**
 * Created by qz88 on 05/10/2015.
 */
public class ZoneMessageRouter implements MessageRouter {

	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(ZoneMessageRouter.class);

	private ZoneHandler zoneHandler;
	private ParseMessageUtil parseMessageUtil;
	private ZoneEventHandler zoneEventHandler;
	private boolean isMetricsEnabled = false;
	private ZoneMetrics zoneMetrics = ZoneMetrics.getInstance();

	List<String> messageIds = null;

	@Inject
	public ZoneMessageRouter(@Named("zoneHandler") ZoneHandler zoneHandler,
			@Named("zoneEventHandler") ZoneEventHandler zoneEventHandler) {
		this.zoneHandler = zoneHandler;
		this.zoneEventHandler = zoneEventHandler;
		this.isMetricsEnabled = true;
	}

	@Override
	public void route(String message) throws MessageRouterException {
		String zoneMsgType = null;
		try {
			if (isMetricsEnabled) {
				zoneMetrics.logMessageProcessingStartTime();
			}
			parseMessageUtil = parseMessageUtil != null ? parseMessageUtil
					: ParseMessageUtil.getInstance();
			zoneMsgType = parseMessageUtil.getNodeData(message,
					PriceConstants.PROMO_MSG_TYPE_PATH);
			String zoneDescData = parseMessageUtil.getNodeData(message,
					PriceConstants.PROMO_MSG_DATA_PATH);
			if (PriceConstants.ZONE_GRP_MSG_TYPE_CRE.equals(zoneMsgType)) {
				if (isMetricsEnabled) {
					zoneMetrics.logCreZoneGroupProcessingStartTime();
				}

				TSLZoneGroupDesc zoneCreMsg = (TSLZoneGroupDesc) parseMessageUtil
						.getMappedObjectForXmlData(TSLZoneGroupDesc.class,
								zoneDescData);

				zoneHandler.processZoneGroupCre(zoneCreMsg, zoneMsgType);
				if (isMetricsEnabled) {
					zoneMetrics.logCreZoneGroupProcessingEndTime();
				}

				// JIRA- PRIS-1483 (Zone creation event publishing) START

				LOGGER.info("Publish Event for Zone creation- Start");
				messageIds = zoneEventHandler.publishZoneEvent(zoneCreMsg,
						PriceConstants.ZONE_MSG_TYPE_CREATED);
				LOGGER.info("Publish Event for Zone creation- End");
				LOGGER.info("MessageIDs returned after Zone creation Event Publish:"
						+ messageIds);

			} else if (PriceConstants.ZONE_GRP_MSG_TYPE_MOD.equals(zoneMsgType)) {

				if (isMetricsEnabled) {
					zoneMetrics.logModZoneGroupProcessingStartTime();
				}

				TSLZoneGroupDesc zoneCreMsg = (TSLZoneGroupDesc) parseMessageUtil
						.getMappedObjectForXmlData(TSLZoneGroupDesc.class,
								zoneDescData);

				zoneHandler.processZoneGroupMod(zoneCreMsg, zoneMsgType);

				if (isMetricsEnabled) {
					zoneMetrics.logModZoneGroupProcessingEndTime();
				}

			} else if (PriceConstants.ZONE_GRP_MSG_TYPE_DEL.equals(zoneMsgType)) {

				if (isMetricsEnabled) {
					zoneMetrics.logDelZoneGroupProcessingStartTime();
				}

				TSLZoneGroupRef zoneGrpDelMsg = (TSLZoneGroupRef) parseMessageUtil
						.getMappedObjectForXmlData(TSLZoneGroupRef.class,
								zoneDescData);

				zoneHandler.processZoneGroupDel(zoneGrpDelMsg, zoneMsgType);

				if (isMetricsEnabled) {
					zoneMetrics.logDelZoneGroupProcessingEndTime();
				}

			} else if (PriceConstants.ZONE_MSG_TYPE_CRE.equals(zoneMsgType)) {

				if (isMetricsEnabled) {
					zoneMetrics.logCreZoneProcessingStartTime();
				}
				TSLZoneGroupDesc zoneCreMsg = (TSLZoneGroupDesc) parseMessageUtil
						.getMappedObjectForXmlData(TSLZoneGroupDesc.class,
								zoneDescData);

				zoneHandler.processZoneCre(zoneCreMsg, zoneMsgType);

				LOGGER.info("End of processing zone message cre..checking zone event handler "
						+ zoneEventHandler);

				// JIRA- PRIS-1483 (Zone creation event publishing) START

				LOGGER.info("Publish Event for Zone creation- Start");
				messageIds = zoneEventHandler.publishZoneEvent(zoneCreMsg,
						PriceConstants.ZONE_MSG_TYPE_CREATED);
				LOGGER.info("Publish Event for Zone creation- End");
				LOGGER.info("MessageIDs returned after Zone creation Event Publish:"
						+ messageIds);
				// JIRA- PRIS-1483 (Zone creation event publishing) END

				if (isMetricsEnabled) {
					zoneMetrics.logCreZoneProcessingEndTime();
				}

			} else if (PriceConstants.ZONE_MSG_TYPE_MOD.equals(zoneMsgType)) {
				if (isMetricsEnabled) {
					zoneMetrics.logModZoneProcessingStartTime();
				}

				TSLZoneGroupDesc zoneModificationMsg = (TSLZoneGroupDesc) parseMessageUtil
						.getMappedObjectForXmlData(TSLZoneGroupDesc.class,
								zoneDescData);

				zoneHandler.processZoneMod(zoneModificationMsg, zoneMsgType);
				// JIRA- PRIS-1635 (Zone details change event publishing) START
				LOGGER.info("Publish Event for Zone modification- Start");
				messageIds = zoneEventHandler.publishZoneEvent(
						zoneModificationMsg,
						PriceConstants.ZONE_MSG_TYPE_DTLS_CHANGED);
				LOGGER.info("Publish Event for Zone modification- End");
				LOGGER.info("MessageIDs returned after Zone modification Event Publish:"
						+ messageIds);
				// JIRA- PRIS-1635 (Zone details change event publishing) END

				if (isMetricsEnabled) {
					zoneMetrics.logModZoneProcessingEndTime();
				}

			} else if (PriceConstants.ZONE_LOC_MSG_TYPE_CRE.equals(zoneMsgType)) {
				if (isMetricsEnabled) {
					zoneMetrics.logCreZoneLocProcessingStartTime();
				}

				TSLZoneGroupDesc storeZoneCreMsg = (TSLZoneGroupDesc) parseMessageUtil
						.getMappedObjectForXmlData(TSLZoneGroupDesc.class,
								zoneDescData);
				Map<String, ZoneEntity> storeZoneCountryCode = zoneHandler
						.getZoneIdCountryCodeForTSLZoneGroup(storeZoneCreMsg);

				zoneHandler
						.processZoneLocationCre(storeZoneCreMsg, zoneMsgType);
				// JIRA- PRIS-1636 (StoreZone change event publishing-New Store
				// Setup) START

				LOGGER.info("Publish Event for StoreZone Change<New Store>- Start");
				messageIds = zoneEventHandler.publishStoreZoneChangeCreEvent(
						storeZoneCreMsg, storeZoneCountryCode);
				LOGGER.info("Publish Event for StoreZone Change<New Store>- End");
				LOGGER.info("MessageIDs returned after StoreZone Change Event Publish:"
						+ messageIds);
				// JIRA- PRIS-1636 (Zone creation event publishing-New Store
				// Setup) END

				if (isMetricsEnabled) {
					zoneMetrics.logCreZoneLocProcessingEndTime();
				}

			} else if (PriceConstants.ZONE_MSG_TYPE_DEL.equals(zoneMsgType)) {
				if (isMetricsEnabled) {
					zoneMetrics.logDelZoneProcessingStartTime();
				}
				TSLZoneGroupRef zoneDelMsg = (TSLZoneGroupRef) parseMessageUtil
						.getMappedObjectForXmlData(TSLZoneGroupRef.class,
								zoneDescData);
				Map<String, ZoneEntity> zoneCountryCodeMap = zoneHandler
						.getZoneIdCountryCodeMap(zoneDelMsg);
				zoneHandler.processZoneDel(zoneDelMsg);
				// JIRA- PRIS-1484 (Zone deletion event publishing) START
				LOGGER.info("Publish Event for Zone deletion- Start");
				messageIds = zoneEventHandler.publishZoneDelEvent(zoneDelMsg,
						zoneCountryCodeMap);
				LOGGER.info("Publish Event for Zone deletion- End");
				LOGGER.info("MessageIDs returned after Zone deletion Event Publish:"
						+ messageIds);
				// JIRA- PRIS-1484 (Zone deletion event publishing) END

				if (isMetricsEnabled) {
					zoneMetrics.logDelZoneProcessingEndTime();
				}

			} else if (PriceConstants.ZONE_LOC_MSG_TYPE_DEL.equals(zoneMsgType)) {
				if (isMetricsEnabled) {
					zoneMetrics.logDelZoneLocProcessingStartTime();
				}

				TSLZoneGroupRef storeZoneRemoveMsg = (TSLZoneGroupRef) parseMessageUtil
						.getMappedObjectForXmlData(TSLZoneGroupRef.class,
								zoneDescData);
				Map<String, ZoneEntity> storeZoneCountryCodeMap = zoneHandler
						.getZoneIdCountryCodeMap(storeZoneRemoveMsg);
				zoneHandler.processLocDel(storeZoneRemoveMsg);
				// JIRA- PRIS-1636 (StoreZone change event publishing-Existing
				// store remove) START

				LOGGER.info("Publish Event for StoreZone Change<Store removed>- Start");
				messageIds = zoneEventHandler
						.publishStoreZoneChangeRemoveEvent(storeZoneRemoveMsg,
								storeZoneCountryCodeMap);
				LOGGER.info("Publish Event for StoreZone Change<Store removed>- End");
				LOGGER.info("MessageIDs returned after StoreZone Change Event Publish:"
						+ messageIds);

				// JIRA- PRIS-1636 (StoreZone change event publishing-Existing
				// store remove) END

				if (isMetricsEnabled) {
					zoneMetrics.logDelZoneLocProcessingEndTime();
				}

			} else {
				throw new MessageRouterException("Invalid Message type --> "
						+ zoneMsgType);
			}

		} catch (IOException | ParserConfigurationException | JAXBException
				| ZoneBusinessException | XPathExpressionException
				| SAXException | ZoneEventException e) {

			if (isMetricsEnabled) {
				zoneMetrics.logMessageProcessingEndTime();
			}

			if (PriceConstants.ZONE_MSG_TYPE_CRE.equals(zoneMsgType)
					&& isMetricsEnabled) {
				zoneMetrics.logCreZoneProcessingEndTime();
			} else if (PriceConstants.ZONE_MSG_TYPE_MOD.equals(zoneMsgType)
					&& isMetricsEnabled) {
				zoneMetrics.logModZoneProcessingEndTime();
			} else if (PriceConstants.ZONE_MSG_TYPE_DEL.equals(zoneMsgType)
					&& isMetricsEnabled) {
				zoneMetrics.logDelZoneProcessingEndTime();
			} else if (PriceConstants.ZONE_GRP_MSG_TYPE_CRE.equals(zoneMsgType)
					&& isMetricsEnabled) {
				zoneMetrics.logCreZoneGroupProcessingEndTime();
			} else if (PriceConstants.ZONE_GRP_MSG_TYPE_MOD.equals(zoneMsgType)
					&& isMetricsEnabled) {
				zoneMetrics.logModZoneGroupProcessingEndTime();
			} else if (PriceConstants.ZONE_GRP_MSG_TYPE_DEL.equals(zoneMsgType)
					&& isMetricsEnabled) {
				zoneMetrics.logDelZoneGroupProcessingEndTime();
			} else if (PriceConstants.ZONE_LOC_MSG_TYPE_CRE.equals(zoneMsgType)
					&& isMetricsEnabled) {
				zoneMetrics.logCreZoneLocProcessingEndTime();
			} else if (PriceConstants.ZONE_LOC_MSG_TYPE_DEL.equals(zoneMsgType)
					&& isMetricsEnabled) {
				zoneMetrics.logDelZoneLocProcessingEndTime();
			}

			if (isMetricsEnabled) {
				zoneMetrics.incrementErrorCount();
			}
			throw new MessageRouterException(e.getMessage(), e);
		} catch (Exception e) {
			throw new MessageRouterException(e.getMessage(), e);
		}
	}
}
