package com.tesco.services.core.promotion;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by iv16 on 5/5/2015.
 */
public class PromoItemEntity implements Serializable {

    public void setItemRef(String itemRef) {
		this.itemRef = itemRef;
	}

	@JsonProperty("@type")
    public String type;

    @JsonProperty("itemType")
    public String itemType;

    @JsonProperty("itemRef")
    public String itemRef;

    @JsonProperty("effectiveDate")
    public String effectiveDate;

    @JsonProperty("endDate")
    public String endDate;

    @JsonProperty("wasPrice")
    public String wasPrice;

    @JsonProperty("wasWasPrice")
    public String wasWasPrice;

    @JsonProperty("posLabelReqInd")
    public String posLabelReqInd;

    @JsonProperty("rpmPromoCompDetailId")
    public String rpmPromoCompDetailId;

    public String getWasPrice() {
        return wasPrice;
    }

    public void setWasPrice(String wasPrice) {
        this.wasPrice = wasPrice;
    }

    public String getWasWasPrice() {
        return wasWasPrice;
    }

    public void setWasWasPrice(String wasWasPrice) {
        this.wasWasPrice = wasWasPrice;
    }

    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getItemType() {
        return itemType;
    }

    public String getEndDate() {
        return endDate;
    }
    public String getEffectiveDate() {
        return effectiveDate;
    }
    public String getItemRef() {
        return itemRef;
    }

    public String getPosLabelReqInd() {
        return posLabelReqInd;
    }

    public void setPosLabelReqInd(String posLabelReqInd) {
        this.posLabelReqInd = posLabelReqInd;
    }

    public String getRpmPromoCompDetailId() {
        return rpmPromoCompDetailId;
    }

    public void setRpmPromoCompDetailId(String rpmPromoCompDetailId) {
        this.rpmPromoCompDetailId = rpmPromoCompDetailId;
    }

    @Override
    public String toString() {
        return "PromoItemEntity{" +
                "type='" + type + '\'' +
                ", itemType='" + itemType + '\'' +
                ", itemRef='" + itemRef + '\'' +
                ", effectiveDate='" + effectiveDate + '\'' +
                ", endDate='" + endDate + '\'' +
                ", wasPrice='" + wasPrice + '\'' +
                ", wasWasPrice='" + wasWasPrice + '\'' +
                ", posLabelReqInd='" + posLabelReqInd + '\'' +
                ", rpmPromoCompDetailId='" + rpmPromoCompDetailId + '\'' +
                '}';
    }

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((effectiveDate == null) ? 0 : effectiveDate.hashCode());
		result = prime * result + ((endDate == null) ? 0 : endDate.hashCode());
		result = prime * result + ((itemRef == null) ? 0 : itemRef.hashCode());
		result = prime * result + ((itemType == null) ? 0 : itemType.hashCode());
		result = prime * result + ((posLabelReqInd == null) ? 0 : posLabelReqInd.hashCode());
		result = prime * result + ((rpmPromoCompDetailId == null) ? 0 : rpmPromoCompDetailId.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		result = prime * result + ((wasPrice == null) ? 0 : wasPrice.hashCode());
		result = prime * result + ((wasWasPrice == null) ? 0 : wasWasPrice.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PromoItemEntity other = (PromoItemEntity) obj;
		if (effectiveDate == null) {
			if (other.effectiveDate != null)
				return false;
		} else if (!effectiveDate.equals(other.effectiveDate))
			return false;
		if (endDate == null) {
			if (other.endDate != null)
				return false;
		} else if (!endDate.equals(other.endDate))
			return false;
		if (itemRef == null) {
			if (other.itemRef != null)
				return false;
		} else if (!itemRef.equals(other.itemRef))
			return false;
		if (itemType == null) {
			if (other.itemType != null)
				return false;
		} else if (!itemType.equals(other.itemType))
			return false;
		if (posLabelReqInd == null) {
			if (other.posLabelReqInd != null)
				return false;
		} else if (!posLabelReqInd.equals(other.posLabelReqInd))
			return false;
		if (rpmPromoCompDetailId == null) {
			if (other.rpmPromoCompDetailId != null)
				return false;
		} else if (!rpmPromoCompDetailId.equals(other.rpmPromoCompDetailId))
			return false;
		if (type == null) {
			if (other.type != null)
				return false;
		} else if (!type.equals(other.type))
			return false;
		if (wasPrice == null) {
			if (other.wasPrice != null)
				return false;
		} else if (!wasPrice.equals(other.wasPrice))
			return false;
		if (wasWasPrice == null) {
			if (other.wasWasPrice != null)
				return false;
		} else if (!wasWasPrice.equals(other.wasWasPrice))
			return false;
		return true;
	}
}