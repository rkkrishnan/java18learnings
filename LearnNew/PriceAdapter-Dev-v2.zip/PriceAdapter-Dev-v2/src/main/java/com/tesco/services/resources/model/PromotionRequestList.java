package com.tesco.services.resources.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

/*Promotion RequestList class*/
@ApiModel
public class PromotionRequestList {

    @JsonProperty
    @ApiModelProperty(required = true)
    private List<PromotionRequest> promotions;

    public List<PromotionRequest> getPromotions() {

        return promotions;
    }

    public void setPromotions(List<PromotionRequest> promotions) {

        this.promotions = promotions;
    }
}
