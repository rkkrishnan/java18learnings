package com.tesco.services.utility;

import java.net.URI;
import java.util.Set;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;

import com.tesco.services.Configuration;

/**
 * Created by QU17 on 18/03/2015.
 */
public class WebServiceCallBuilder {

	private Configuration configuration;

	public void setClient(Client client) {
		this.client = client;
	}

	private Client client;

	public WebServiceCallBuilder(Configuration configuration) {
		this.configuration = configuration;
		this.client = ClientBuilder.newClient();
	}

	/**
	 * This will call the remote server and get the response for List of
	 * Products
	 * 
	 * @param uriPath
	 *            URI path to call remote server
	 * @return
	 */
	public Response callRemoteServerToPostListData(URI uriPath,
			Set<String> productIds) {
		Client client = ClientBuilder.newClient();
		WebTarget target = client.target(uriPath);
		return target.request().accept(MediaType.APPLICATION_JSON)
				.post(Entity.entity(productIds, MediaType.APPLICATION_JSON));
	}

	/**
	 * This will give URI based on parameters passed
	 * 
	 * @param identifier
	 *            TPNB/TPNC identifier like "/TPNB or /TPNC"
	 * @param store
	 *            Store identifier like "?store=", If store not required then
	 *            pass null
	 * @param storeId
	 *            Store Id, If store not required then pass null
	 * @return Returns URI based on parameters passed, If store is not required
	 *         then pass null in place of store
	 */
	public URI getResourceURIForListData(String identifier, String store,
			String storeId) {
		String version = configuration.getTeauthServiceVersion();
		String remoteServerUrl = configuration.getPriceServiceUrl();
		String root = PriceConstants.GET_CALL_ROOT;
		if (store != null) {
			return UriBuilder.fromUri(
					String.format(remoteServerUrl + "%s/%s/%s?%s=%s", version,
							root, identifier, store, storeId)).build();
		}
		return UriBuilder.fromUri(
				String.format(remoteServerUrl + "%s/%s/%s", version, root,
						identifier)).build();
	}

	public Response getResponseFromRemoteServerForProductsListWithStore(
			Set<String> productSet, String storeId) {
		URI requestProductStoreUri = getResourceURIForListData(
				PriceConstants.TPNC_IDENTIFIER,
				PriceConstants.STORE_IDENTIFIER, storeId);
		Response clientResponse = callRemoteServerToPostListData(
				requestProductStoreUri, productSet);
		return clientResponse;
	}

	public Response getResponseFromProdServices(String productServiceUrl) {
		WebTarget resource = client.target(productServiceUrl);
		return resource.request().get();
	}

	public URI getResourceURIToRefreshService(String refreshServiceUrl) {
		return UriBuilder.fromUri(String.format(refreshServiceUrl)).build();

	}

	public Response callRemoteServer(URI uriPath) throws Exception {
		Client client = ClientBuilder.newClient();
		WebTarget target = client.target(uriPath);
		return target.request().accept(MediaType.APPLICATION_JSON).get();
	}

}
