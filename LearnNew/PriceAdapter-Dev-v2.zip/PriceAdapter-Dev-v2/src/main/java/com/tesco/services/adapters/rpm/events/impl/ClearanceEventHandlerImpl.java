package com.tesco.services.adapters.rpm.events.impl;

import com.tesco.services.adapters.rpm.events.ClearanceEventHandler;
import com.tesco.services.event.core.EventTemplate;
import com.tesco.services.event.core.impl.MapEvent;
import com.tesco.services.event.exception.EventPublishException;
import com.tesco.services.leadtime.core.LeadTimeUtility;
import com.tesco.services.utility.CommonEventPublishingUtility;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.PriceConstants;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;
import org.joda.time.DateTime;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import java.text.ParseException;
import java.util.*;

/**
 * This class will handle the clearance events
 **/

public class ClearanceEventHandlerImpl implements ClearanceEventHandler {

	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper.getLogger(ClearanceEventHandlerImpl.class);


	private static final String COUNTRYCODE_GB = "GB";
	private static final String COUNTRYCODE_IE = "IE";

	private EventTemplate eventTemplate;

	@Inject
	public ClearanceEventHandlerImpl(
			@Named("rtEventTemplate") EventTemplate eventTemplate) {
		this.eventTemplate = eventTemplate;
	}

	/*
	 * This method iterates over the provided map and publishes message to the
	 * topic for each entry (non-Javadoc)
	 * 
	 * @see com.tesco.services.adapters.rpm.events.ClearanceEventHandler#
	 * publishEventsForClearances(java.util.Map)
	 */
	public void publishEventsForClearances(ClearanceEventData clearanceEventsDataMap)
			throws ParseException, EventPublishException {

		for (String key : clearanceEventsDataMap.keySet()) {

			String leadTime = "";
			String countryCode = "";
			String eventType = "";
			Set<String> locationAndClearanceIdSet = clearanceEventsDataMap.get(key);

			// TODO Currently country code not being supported through CSV input
			// file.
			// TODO We are hard coding codes here for time being. We should read
			// country code from input file once supported.
			if ((PriceConstants.CURRENCY_CODE_GBP).equalsIgnoreCase(getCountry(key))) {
				countryCode = COUNTRYCODE_GB;
			} else {
				countryCode = COUNTRYCODE_IE;
			}

			LOGGER.debug("Publishing Clearance Event of the productId: {} Started", getProductId(key));

			List<Map<String, Object>> locations = prepareGroupedEventData(locationAndClearanceIdSet);

			if (PriceConstants.INSERT_ACTION_FILE_CODE.equalsIgnoreCase(getAction(key))) {
				leadTime = processEffectiveOrEndDate(getEffectiveDate(key));
				eventType = PriceConstants.CLEARANCE_CREATED_EVENT_TYPE;
			} else if (PriceConstants.DELETE_ACTION_FILE_CODE.equalsIgnoreCase(getAction(key))) {
				leadTime = "0";
				eventType = PriceConstants.CLEARANCE_DELETED_EVENT_TYPE;
			} else if (PriceConstants.UPDATE_CLR_END_DATE_ACTION_FILE_CODE.equalsIgnoreCase(getAction(key))) {
				leadTime = processEffectiveOrEndDate(getEffectiveDate(key));
				eventType = PriceConstants.CLEARANCE_END_DATE_CHANGED_EVENT_TYPE;
			}

			MapEvent eventData = CommonEventPublishingUtility.createClearanceEventData(getProductId(key), leadTime,
					countryCode, locations, key, eventType);

			CommonEventPublishingUtility.publishEvent(eventTemplate, eventData);
			LOGGER.debug(" Clearance Event of the productId: {} Published Succesfully", getProductId(key));
		}

	}

	private List<Map<String, Object>> prepareGroupedEventData(Set<String> locationAndClearanceIdSet) {

		List<Map<String, Object>> locations = new ArrayList<Map<String, Object>>();
		for (String locationAndClearanceId : locationAndClearanceIdSet) {
			String[] clearanceEventDetails = locationAndClearanceId.split("_");
			Map<String, Object> priceLocationMap = new HashMap<>();
			Map<String, Object> locationMap = new HashMap<String, Object>();
			locationMap.put(PriceConstants.LOC_TYPE, clearanceEventDetails[0]);
			locationMap.put(PriceConstants.LOC_REF, clearanceEventDetails[1]);
			priceLocationMap.put(PriceConstants.PRICING_LOC, locationMap);
			priceLocationMap.put(PriceConstants.CLEARANCE_OFFER_ID, clearanceEventDetails[2]);
			locations.add(priceLocationMap);
		}
		return locations;

	}

	private String processEffectiveOrEndDate(String effectiveOrEndDate) throws ParseException {
		String leadTime;
		String formattedEffectiveOrEndDate = Dockyard.getFormattedDate(effectiveOrEndDate,
				PriceConstants.DATE_FORMAT_YYYYMMDDHHMMSS, PriceConstants.ISO_8601_FORMAT);
		DateTime effectiveOrEndDateTime = new DateTime(formattedEffectiveOrEndDate);
		DateTime publicationDate = new DateTime(Dockyard.getSysDate(PriceConstants.ISO_8601_FORMAT));
		leadTime = String.valueOf(LeadTimeUtility.getLeadTime(effectiveOrEndDateTime, publicationDate));
		return leadTime;
	}

	@Override
	public void publishEventsForPreviousPriceChangeClearances(ClearanceEventData clearanceEventMap)
			throws ParseException, EventPublishException {

		for (String key : clearanceEventMap.keySet()) {

			Set<String> locationAndClearanceIdSet = clearanceEventMap.get(key);

			LOGGER.debug("Publishing Clearance Event of the productId: {} Started", getProductId(key));

			List<Map<String, Object>> locations = prepareGroupedEventData(locationAndClearanceIdSet);


			MapEvent eventData = CommonEventPublishingUtility.createClearanceEventData(getProductId(key),
					processEffectiveOrEndDate(getEffectiveDate(key)), getCountry(key), locations, key,
					PriceConstants.CLEARANCE_PREV_PRICE_CHANGE_EVENT_TYPE);

			CommonEventPublishingUtility.publishEvent(eventTemplate, eventData);


			LOGGER.debug(" Clearance Event of the productId: {} Published Succesfully", getProductId(key));

		}

	}

	private String getProductId(String key) {
		return key.split("_")[0];
	}

	private String getEffectiveDate(String key) {
		return key.split("_")[2];
	}

	private String getCountry(String key) {
		return key.split("_")[3];
	}

	private String getAction(String key) {
		return key.split("_")[4];
	}
}