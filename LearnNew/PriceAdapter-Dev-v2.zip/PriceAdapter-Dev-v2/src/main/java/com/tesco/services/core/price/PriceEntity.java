package com.tesco.services.core.price;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.validation.constraints.NotNull;
import java.util.HashMap;
import java.util.Map;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PriceEntity {

	@JsonProperty("prodType")
	private String prodType;

	@JsonProperty("prodRef")
	private String prodRef;

	@JsonProperty("locRef")
	private String locRef;

	@JsonProperty("locType")
	private String locType;

	@JsonProperty("lastUpdateDate")
	private String lastUpdateDate;

	@JsonProperty("tpncToProductVariant")
	private Map<String,ProductVariant> tpncToProductVariant;


	@JsonProperty("prodType")
	public String getProdType() {
		return prodType;
	}

	@JsonProperty("prodType")
	public void setProdType(String prodType) {
		this.prodType = prodType;
	}

	@JsonProperty("prodRef")
	public String getProdRef() {
		return prodRef;
	}

	@JsonProperty("prodRef")
	public void setProdRef(String prodRef) {
		this.prodRef = prodRef;
	}

	@JsonProperty("locRef")
	public String getLocRef() {
		return locRef;
	}

	@JsonProperty("locRef")
	public void setLocRef(String locRef) {
		this.locRef = locRef;
	}

	@JsonProperty("locType")
	public String getLocType() {
		return locType;
	}

	@JsonProperty("locType")
	public void setLocType(String locType) {
		this.locType = locType;
	}

	@JsonProperty("lastUpdateDate")
	public String getLastUpdateDate() {
		return lastUpdateDate;
	}

	@JsonProperty("lastUpdateDate")
	public void setLastUpdateDate(String lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	@JsonProperty("tpncToProductVariant")
	public Map<String, ProductVariant> getTpncToProductVariant() {
		if(tpncToProductVariant == null){
			tpncToProductVariant = new HashMap<>();
		}
		return tpncToProductVariant;
	}

	@JsonProperty("tpncToProductVariant")
	public void setTpncToProductVariant(
			Map<String, ProductVariant> tpncToProductVariant) {
		this.tpncToProductVariant = tpncToProductVariant;
	}

	@Override public String toString() {
		return "PriceEntity{" +
				"prodType='" + prodType + '\'' +
				", prodRef='" + prodRef + '\'' +
				", locRef='" + locRef + '\'' +
				", locType='" + locType + '\'' +
				", lastUpdateDate='" + lastUpdateDate + '\'' +
				", tpncToProductVariant=" + tpncToProductVariant +
				'}';
	}
}
