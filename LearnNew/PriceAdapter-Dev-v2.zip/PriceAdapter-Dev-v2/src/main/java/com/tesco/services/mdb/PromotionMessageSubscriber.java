package com.tesco.services.mdb;

import java.util.HashSet;
import java.util.Set;

import javax.inject.Inject;
import javax.inject.Named;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;
import javax.jms.TopicSession;

import org.slf4j.Logger;

import com.tesco.logging.LogWriter;
import com.tesco.logging.LoggerRepository;
import com.tesco.services.Configuration;
import com.tesco.services.adapters.rpm.readers.MessageRouter;
import com.tesco.services.core.jms.JMSTopicTransactionHandler;
import com.tesco.services.exceptions.MessageRouterException;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.PriceConstants;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;

/**
 * @author a185
 */
public class PromotionMessageSubscriber extends JMSTopicTransactionHandler implements
		MessageListener {

	private static final String PROMO_MESSAGE_LOGGER = "PromoMessageLogger";
	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(PromotionMessageSubscriber.class);
	private static final LogWriter MSGLOGGER = LoggerRepository
			.getLogger(PROMO_MESSAGE_LOGGER);

	@Inject
	@Named("promoMsgRouter")
	private MessageRouter promotionMessageRouter;

	@Inject
	@Named("configuration")
	private Configuration configuration;

	private Dockyard dockyard;

	private int retryCount;
	private TopicSession topicSession;

	public PromotionMessageSubscriber() {
		setTopicSession(getTopicSession());
		setRetryCount(getRetryCount());
	}

	@Override
	public void setRetryCount(int retryCount) {
		this.retryCount = retryCount;
	}

	@Override
	public void setTopicSession(TopicSession topicSession) {
		this.topicSession = topicSession;
	}

	public void setPromotionMessageRouter(MessageRouter promotionMessageRouter) {
		this.promotionMessageRouter = promotionMessageRouter;
	}

	public void setConfiguration(Configuration configuration) {
		this.configuration = configuration;
	}

	public Dockyard getDockyard() {
		if (dockyard == null) {
			dockyard = new Dockyard();
		}
		return dockyard;
	}

	@Override
	public void onMessage(Message message) {
		String text = null;

		if (message instanceof TextMessage) {
			TextMessage textMessage = (TextMessage) message;
			try {
				text = textMessage.getText();
				LOGGER.info("Message Received : {}", text);
				/*
				 * Added For PRIS-2005 & PRIS-2020 Save the promotion messages
				 * if captureMessages is set to true
				 */
				if (textMessage.getIntProperty("JMSXDeliveryCount") == 1) {
					MSGLOGGER.info(Dockyard.getSysDate(
							PriceConstants.ISO_8601_FORMAT).concat(" - ")
							+ text);
				}
				promotionMessageRouter.route(text);

				/** Once the message is successfully consumed then commit. */
				topicSession.commit();

			} catch (MessageRouterException | JMSException e) {
				LOGGER.error("error   : {} -> {}", e.getCause(), e.getMessage());
				LOGGER.error("Trace For the error", e.getCause());
				try {
					if (textMessage.getIntProperty("JMSXDeliveryCount") <= retryCount) {

						LOGGER.error("Retrying "
								+ textMessage
										.getIntProperty("JMSXDeliveryCount")
								+ " out of " + retryCount + " ...");
						topicSession.rollback();
					} else {
						Set<String> errorMessage = new HashSet<>();
						errorMessage.add(text);
						LOGGER.info("Max retries attempts reached. Logging message to error file");
						getDockyard().writeProductDetailsToFile(
								this.configuration.getRejectFilePath()
										+ "/REJECT_FILE_FailedMsgs" + "_"
										+ Dockyard.getSysDate("yyyyMMdd")
										+ ".log", errorMessage);
						topicSession.commit();
					}

				} catch (JMSException e1) {
					LOGGER.error(
							"error : {Error in retry procedure after exception } -> {} {}",
							e1.getCause(), e1.getMessage());
				}

			}

		} else {
			LOGGER.info("Message Received: {}", message);
		}
	}
}
