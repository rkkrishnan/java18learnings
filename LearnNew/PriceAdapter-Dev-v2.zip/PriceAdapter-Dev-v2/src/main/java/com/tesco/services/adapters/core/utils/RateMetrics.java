package com.tesco.services.adapters.core.utils;

import static com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility.ANY;
import static com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility.NONE;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@SuppressWarnings("serial")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonAutoDetect(fieldVisibility = ANY, getterVisibility = NONE, setterVisibility = NONE)
public class RateMetrics implements Serializable {
	@JsonProperty
	private String oneMinuteRate;
	@JsonProperty
	private String fiveMinuteRate;
	@JsonProperty
	private String fifteenMinuteRate;
	@JsonProperty
	private String meanRate;
	@JsonProperty
	private String rateUnit;

	public String getOneMinuteRate() {
		return oneMinuteRate;
	}

	public void setOneMinuteRate(String oneMinuteRate) {
		this.oneMinuteRate = oneMinuteRate;
	}

	public String getFiveMinuteRate() {
		return fiveMinuteRate;
	}

	public void setFiveMinuteRate(String fiveMinuteRate) {
		this.fiveMinuteRate = fiveMinuteRate;
	}

	public String getFifteenMinuteRate() {
		return fifteenMinuteRate;
	}

	public void setFifteenMinuteRate(String fifteenMinuteRate) {
		this.fifteenMinuteRate = fifteenMinuteRate;
	}

	public String getMeanRate() {
		return meanRate;
	}

	public void setMeanRate(String meanRate) {
		this.meanRate = meanRate;
	}

	public String getRateUnit() {
		return rateUnit;
	}

	public void setRateUnit(String rateUnit) {
		this.rateUnit = rateUnit;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((fifteenMinuteRate == null) ? 0 : fifteenMinuteRate
						.hashCode());
		result = prime * result
				+ ((fiveMinuteRate == null) ? 0 : fiveMinuteRate.hashCode());
		result = prime * result
				+ ((meanRate == null) ? 0 : meanRate.hashCode());
		result = prime * result
				+ ((oneMinuteRate == null) ? 0 : oneMinuteRate.hashCode());
		result = prime * result
				+ ((rateUnit == null) ? 0 : rateUnit.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RateMetrics other = (RateMetrics) obj;
		if (fifteenMinuteRate == null) {
			if (other.fifteenMinuteRate != null)
				return false;
		} else if (!fifteenMinuteRate.equals(other.fifteenMinuteRate))
			return false;
		if (fiveMinuteRate == null) {
			if (other.fiveMinuteRate != null)
				return false;
		} else if (!fiveMinuteRate.equals(other.fiveMinuteRate))
			return false;
		if (meanRate == null) {
			if (other.meanRate != null)
				return false;
		} else if (!meanRate.equals(other.meanRate))
			return false;
		if (oneMinuteRate == null) {
			if (other.oneMinuteRate != null)
				return false;
		} else if (!oneMinuteRate.equals(other.oneMinuteRate))
			return false;
		if (rateUnit == null) {
			if (other.rateUnit != null)
				return false;
		} else if (!rateUnit.equals(other.rateUnit))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "RateMetrics [OneMinuteRate=" + oneMinuteRate
				+ ", FiveMinuteRate=" + fiveMinuteRate + ", FifteenMinuteRate="
				+ fifteenMinuteRate + ", MeanRate=" + meanRate + ", RateUnit="
				+ rateUnit + "]";
	}

}
