package com.tesco.services.exceptions;

/**
 * Created by iv16 on 9/1/2015.
 */
public class PriceBusinessException extends Exception {
	public PriceBusinessException() {
		// TODO Auto-generated constructor stub
	}

	public PriceBusinessException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public PriceBusinessException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public PriceBusinessException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public PriceBusinessException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
