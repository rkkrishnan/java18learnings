package com.tesco.services.exceptions;

/**
 * Created by QU17 on 30/11/2014.
 * This Exception class will be thrown when Rpm Clr import run identifier is invalid
 */
public class InvalidClrRunIdentifierException extends Exception{
    public InvalidClrRunIdentifierException(String message){
        super(message);
    }

}

