package com.tesco.services.adapters.rpm.writers.impl;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.MappingJsonFactory;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tesco.promotion.core.PrmPrcChgDtlRef;
import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.exceptions.WriterBusinessException;
import com.tesco.services.adapters.rpm.writers.PromotionMessageWriter;
import com.tesco.services.core.promotion.*;
import com.tesco.services.exceptions.DataAccessException;
import com.tesco.services.exceptions.ProductEncodeException;
import com.tesco.services.exceptions.PromoBusinessException;
import com.tesco.services.repositories.Repository;
import com.tesco.services.resources.PromotionResource;
import com.tesco.services.utility.*;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;

import org.apache.commons.lang3.SerializationUtils;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

import static com.tesco.services.utility.PriceConstants.*;
import static org.apache.commons.lang.StringUtils.isBlank;
import static org.apache.commons.lang.StringUtils.isNumeric;

public class PromotionWriter implements PromotionMessageWriter {
	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(PromotionWriter.class);

	private static PromotionJmsLog PROMOMSGCOUNTER = PromotionJmsLogImpl
			.getInstance();
	private Configuration configuration;
	private Repository repository;
	private ObjectMapper objectMapper;

	BufferedReader promotionFileReader;
	private String runIdentifier;
	private Dockyard dockyard;
	private PromotionEntity promotionEntityFromMessage;
	private Set<String> rejectedProducts;

	private Map<String, String> newProductData;

	private File onetimePromoFile;
	int promotionMasterInsertedCount = 0;
	int promotionMasterRejectedCount = 0;
	int lookupRecordsInserted = 0;
	int lookupRecordsRejected = 0;
	int prodRefRecordsInserted = 0;
	int prodRefRecordsRejected = 0;
	int hierarchyRecordsInserted = 0;
	int hierarchyRecordsRejected = 0;
	int promotionRecordsInsertedCount = 0;
	int promotionRecordsRejectedCount = 0;

	@Inject
	public PromotionWriter(@Named("configuration") Configuration configuration,
			@Named("repository") Repository repository,
			@Named("jsonmapper") ObjectMapper objectMapper) {
		this.configuration = configuration;
		this.repository = repository;
		this.objectMapper = objectMapper;
	}

	public Map<String, PromotionHierarchyEntity> constructHierarchy(
			PromotionEntity promotionEntity) throws PromoBusinessException {
		PromotionHierarchyEntity hierarchyPromoEntity = null;
		Map<String, PromotionHierarchyEntity> promoHierarchyDocMap = new HashMap<String, PromotionHierarchyEntity>();

		for (PromoItemListEntity promoItemListEntity : promotionEntity
				.getPromoItemListEntities()) {

			boolean isBuyListType = false;

			if (PriceConstants.PROMO_ITEM_LIST_BUY_TYPE
					.equals(promoItemListEntity.getListType())) {
				isBuyListType = true;
			}

			if (promoItemListEntity.getPromoItems() != null) {

				for (PromoItemEntity promoItemEntity : promoItemListEntity
						.getPromoItems()) {
					if (PriceConstants.HIERARCHY_LIST.contains(promoItemEntity
							.getItemType().toUpperCase())) {
						String tescoItemRef = promoItemEntity.itemRef;
						promoItemEntity.setItemRef(tescoItemRef);

						if (isBuyListType) {
							try {
								hierarchyPromoEntity = (PromotionHierarchyEntity) repository
										.getGenericObject(
												PriceConstants.HIERARCHY_PROMO_PREFIX
														+ promoItemEntity.itemRef,
												PromotionHierarchyEntity.class);
							} catch (DataAccessException e) {
								throw new PromoBusinessException(e);
							}

							if (hierarchyPromoEntity == null) {
								hierarchyPromoEntity = new PromotionHierarchyEntity();
								hierarchyPromoEntity
										.setHierarchyId(tescoItemRef);
								hierarchyPromoEntity
										.setCreatedById(PriceConstants.JMS_RPM);

								hierarchyPromoEntity
										.setCreatedDate(Dockyard
												.getSysDate(PriceConstants.ISO_8601_FORMAT));

								hierarchyPromoEntity
										.setLastUpdatedById(PriceConstants.JMS_RPM);

								hierarchyPromoEntity
										.setLastUpdateDate(Dockyard
												.getSysDate(PriceConstants.ISO_8601_FORMAT));
							}
							PromotionHierarchyEntity origPromotionHierarchyEntity = (PromotionHierarchyEntity) SerializationUtils
									.clone(hierarchyPromoEntity);

							OfferEntity offerEntity = hierarchyPromoEntity
									.getPromotions().get(
											PriceConstants.OFFER_PREFIX
													+ promotionEntity
															.getOfferRef());

							if (offerEntity == null) {
								offerEntity = new OfferEntity();
							}

							offerEntity.setOfferRef(promotionEntity
									.getOfferRef());

							OfferLocRefEntity offerLocRefEntity = new OfferLocRefEntity();

							if (offerEntity.getOfferLocRef() == null) {
								offerEntity = new OfferEntity();
							}
							offerEntity.getOfferLocRef().put(
									PriceConstants.ZONE_PREFIX
											+ promotionEntity.getLocRef(),
									offerLocRefEntity);

							if (offerLocRefEntity == null) {
								offerLocRefEntity = new OfferLocRefEntity();
							}
							offerLocRefEntity.setEffectiveDate(promoItemEntity
									.getEffectiveDate());
							offerLocRefEntity.setEndDate(promoItemEntity
									.getEndDate());
							hierarchyPromoEntity.getPromotions().put(
									PriceConstants.OFFER_PREFIX
											+ promotionEntity.getOfferRef(),
									offerEntity);
							if (!origPromotionHierarchyEntity
									.equals(hierarchyPromoEntity)) {
								hierarchyPromoEntity
										.setLastUpdateDate(Dockyard
												.getSysDate(PriceConstants.ISO_8601_FORMAT));

							}

							hierarchyPromoEntity.getPromotions().put(
									PriceConstants.OFFER_PREFIX
											+ promotionEntity.getOfferRef(),
									offerEntity);
							promoHierarchyDocMap.put("PROMOHIER_"
									+ tescoItemRef, hierarchyPromoEntity);

						}

					}

				}
			}

		}

		return promoHierarchyDocMap;
	}

	public PromotionMasterEntity constructMaster(PromotionEntity pe,
			Set zoneLoc, PromotionMasterEntity masterJson) {
		String createdDate;
		String createdById;
		Set prevLoc = new HashSet();
		if (masterJson != null) {
			createdDate = masterJson.getCreatedDate();
			createdById = masterJson.getCreatedById();
			prevLoc = masterJson.getOfferLocRef();
			Iterator itPrevLoc = prevLoc.iterator();
			while (itPrevLoc.hasNext()) {
				zoneLoc.add(itPrevLoc.next().toString());
			}

		} else {
			createdDate = Dockyard.getSysDate(PriceConstants.ISO_8601_FORMAT);
			createdById = pe.createdById;
		}
		PromotionMasterEntity pme = new PromotionMasterEntity();
		pme.setOfferType(pe.getOfferType());
		pme.setCreatedDate(createdDate);
		pme.setCreatedById(createdById);
		pme.setOfferType(pe.getOfferType());
		pme.setOfferLocRef(zoneLoc);
		if (masterJson != null) {
			if (!masterJson.getOfferLocRef().containsAll(pme.getOfferLocRef())) {
				pme.setLastUpdateDate(pe.lastUpdateDate);
				pme.setLastUpdatedById(pe.lastUpdatedById);
			} else {
				pme.setLastUpdateDate(masterJson.getLastUpdateDate());
				pme.setLastUpdatedById(masterJson.getLastUpdatedById());
			}
		} else {
			pme.setLastUpdateDate(pe.lastUpdateDate);
			pme.setLastUpdatedById(pe.lastUpdatedById);
		}
		pme.setEffectiveDate("");
		pme.setEndDate("");
		return pme;

	}

	private void createAndInsertProdOfferDoc(PromotionEntity promotionEntity,
			PromoItemEntity promoItemEntity, int[] thresholdRefs)
			throws PromoBusinessException {

		ProductOffersEntity productOffersEntity = null;
		boolean isNewProduct = false;
		String tpnb = promoItemEntity.getItemRef();
		String loc = promotionEntity.getLocRef();

		String createdId = promotionEntity.getCreatedById();
		String effectiveDate = promoItemEntity.getEffectiveDate();
		/*
		 * PRIS-2010 Get cfDescription1 , cfDescription2 from existing promotion
		 */
		String cfDescription1 = promotionEntity.getCfDescription1();
		String cfDescription2 = promotionEntity.getCfDescription2();

		try {
			productOffersEntity = (ProductOffersEntity) repository
					.getGenericObject(PriceConstants.PROD_OFFERS + tpnb + "_Z"
							+ loc, ProductOffersEntity.class);
		} catch (DataAccessException e) {
			throw new PromoBusinessException(e);
		}

		if (productOffersEntity == null) {
			productOffersEntity = new ProductOffersEntity();

			productOffersEntity.setTpnb(tpnb);
			productOffersEntity.setLocRef(loc);
			productOffersEntity.setLocType("Z");
			productOffersEntity.setCreateDateTime(Dockyard
					.getSysDate(PriceConstants.ISO_8601_FORMAT));
			isNewProduct = true;
		}

		ProductOffersPromotionEntity productOffersPromotionEntity = new ProductOffersPromotionEntity();

		productOffersEntity.setLastUpdateDateTime(Dockyard
				.getSysDate(PriceConstants.ISO_8601_FORMAT));

		productOffersPromotionEntity.setOfferId(promotionEntity.getOfferRef());
		productOffersPromotionEntity.setName(promotionEntity.name);
		productOffersPromotionEntity.setOfferType(promotionEntity
				.getOfferType());
		productOffersPromotionEntity
				.setCreateDateTime(promotionEntity.createdDate);
		productOffersPromotionEntity
				.setLastUpdateDateTime(promotionEntity.lastUpdateDate);
		productOffersPromotionEntity
				.setMultiBuyPromoType(promotionEntity.multiBuyPromoType);
		productOffersPromotionEntity
				.setMbBuyGetListInd(PriceConstants.PROMO_ITEM_BUY_TYPE);
		productOffersPromotionEntity.setWasPrice(promoItemEntity.getWasPrice());
		productOffersPromotionEntity.setWasWasPrice(promoItemEntity
				.getWasWasPrice());
		productOffersPromotionEntity.setPosLabelReqInd(promoItemEntity
				.getPosLabelReqInd());
		productOffersPromotionEntity.setEffectiveDate(promoItemEntity
				.getEffectiveDate());
		productOffersPromotionEntity.setEndDate(promoItemEntity.getEndDate());
		productOffersPromotionEntity.setCfDescription1(cfDescription1);
		productOffersPromotionEntity.setCfDescription2(cfDescription2);
		productOffersPromotionEntity.setRpmPromoCompDetailId(promoItemEntity
				.getRpmPromoCompDetailId());

		List<PromoThresholdEntity> promoThresholdEntities = new ArrayList<>();

		if (thresholdRefs.length == 1) {
			promoThresholdEntities.add(promotionEntity
					.getPromoThresholdEntities().get(thresholdRefs[0]));
		} else {
			for (int i = 0; i < thresholdRefs.length; i++) {
				promoThresholdEntities.add(promotionEntity
						.getPromoThresholdEntities().get(i));
			}
		}

		productOffersPromotionEntity
				.setPromoThresholdEntities(promoThresholdEntities);

		productOffersPromotionEntity.setPromoRewardEntities(promotionEntity
				.getPromoRewardEntities());

		productOffersEntity.setProductOffersPromotionEntity(
				productOffersPromotionEntity.getOfferId(),
				productOffersPromotionEntity);

		try {
			repository.insertObject(PriceConstants.PROD_OFFERS + tpnb
					+ "_Z" + loc, productOffersEntity);
			if (createdId.equals(PROMOTION_ONETIME)) {
				prodRefRecordsInserted++;
			} else {
				PROMOMSGCOUNTER
						.updateCounterForCreMsg(PROMOTION_PRODOFFERS_DOCUMENT);
			}

		} catch (Exception e) {
			if (createdId.equals(PROMOTION_ONETIME)) {
				prodRefRecordsRejected++;
				LOGGER.error("Error occurred when inserting document into couchbase for onetime prodRef: "
						+ tpnb + "is rejected");
				rejectedProducts
						.add(Dockyard
								.getSysDate(PriceConstants.ISO_8601_FORMAT)
								.concat("~<ONETIME PROMOTION>~")
								.concat("CB Error  when inserting document into couchbase for onetime promotion: ")
								.concat(tpnb));
			} else {
				LOGGER.error("Error occurred when inserting document into couchbase for jms prodRef: "
						+ tpnb + "is rejected");
				rejectedProducts
						.add(Dockyard
								.getSysDate(PriceConstants.ISO_8601_FORMAT)
								.concat("~<JMS PROMOTION>~")
								.concat("CB Error  when inserting document into couchbase for jms promotion: ")
								.concat(tpnb));
			}
		}

		LOGGER.debug("Prod Offer Document " + PriceConstants.PROD_OFFERS + tpnb
				+ "_Z" + loc + " successfully.");

		if (isNewProduct == true) {
			newProductData.put(tpnb, effectiveDate);
		}

	}

	private void createAndInsertProdOfferDocForGetList(
			PromotionEntity promotionEntity, PromoItemEntity promoItemEntity,
			int[] rewardsRefs, String effectiveDate, String endDate)
			throws PromoBusinessException {
		ProductOffersEntity productOffersEntity = null;
		boolean isNewProduct = false;
		String tpnb = promoItemEntity.getItemRef();
		String loc = promotionEntity.getLocRef();
		String createId = promotionEntity.getCreatedById();

		/*
		 * PRIS-2010 Get cfDescription1 , cfDescription2 from existing promotion
		 */
		String cfDescription1 = promotionEntity.getCfDescription1();
		String cfDescription2 = promotionEntity.getCfDescription2();

		try {
			productOffersEntity = (ProductOffersEntity) repository
					.getGenericObject(PriceConstants.PROD_OFFERS + tpnb + "_Z"
							+ loc, ProductOffersEntity.class);
		} catch (DataAccessException e) {
			throw new PromoBusinessException(e);
		}

		if (productOffersEntity == null) {
			productOffersEntity = new ProductOffersEntity();

			productOffersEntity.setTpnb(tpnb);
			productOffersEntity.setLocRef(loc);
			productOffersEntity.setLocType("Z");
			productOffersEntity.setCreateDateTime(Dockyard
					.getSysDate(PriceConstants.ISO_8601_FORMAT));
			isNewProduct = true;
		}

		ProductOffersPromotionEntity productOffersPromotionEntity = new ProductOffersPromotionEntity();

		productOffersEntity.setLastUpdateDateTime(Dockyard
				.getSysDate(PriceConstants.ISO_8601_FORMAT));

		productOffersPromotionEntity.setOfferId(promotionEntity.getOfferRef());
		productOffersPromotionEntity.setName(promotionEntity.name);
		productOffersPromotionEntity.setOfferType(promotionEntity
				.getOfferType());
		productOffersPromotionEntity
				.setCreateDateTime(promotionEntity.createdDate);
		productOffersPromotionEntity
				.setLastUpdateDateTime(promotionEntity.lastUpdateDate);
		productOffersPromotionEntity
				.setMultiBuyPromoType(promotionEntity.multiBuyPromoType);
		productOffersPromotionEntity
				.setMbBuyGetListInd(PriceConstants.PROMO_ITEM_GET_TYPE);
		productOffersPromotionEntity.setWasPrice(promoItemEntity.getWasPrice());
		productOffersPromotionEntity.setWasWasPrice(promoItemEntity
				.getWasWasPrice());
		productOffersPromotionEntity.setPosLabelReqInd(promoItemEntity
				.getPosLabelReqInd());

		productOffersPromotionEntity.setEffectiveDate(effectiveDate);
		productOffersPromotionEntity.setEndDate(endDate);
		productOffersPromotionEntity.setCfDescription1(cfDescription1);
		productOffersPromotionEntity.setCfDescription2(cfDescription2);
		productOffersPromotionEntity.setRpmPromoCompDetailId(promoItemEntity
				.getRpmPromoCompDetailId());

		List<PromoRewardEntity> promoRewardEntities = new ArrayList<>();

		if (rewardsRefs.length == 1) {
			promoRewardEntities.add(promotionEntity.getPromoRewardEntities()
					.get(rewardsRefs[0]));
		} else {
			for (int i = 0; i < rewardsRefs.length; i++) {
				promoRewardEntities.add(promotionEntity
						.getPromoRewardEntities().get(i));
			}
		}

		productOffersPromotionEntity
				.setPromoRewardEntities(promoRewardEntities);

		productOffersPromotionEntity.setPromoThresholdEntities(promotionEntity
				.getPromoThresholdEntities());

		productOffersEntity.setProductOffersPromotionEntity(
				productOffersPromotionEntity.getOfferId(),
				productOffersPromotionEntity);

		try {
			repository.insertObject(PriceConstants.PROD_OFFERS + tpnb
					+ "_Z" + loc, productOffersEntity);
			if (createId.equals(PROMOTION_ONETIME)) {
				prodRefRecordsInserted++;
			} else {
				PROMOMSGCOUNTER
						.updateCounterForCreMsg(PROMOTION_PRODOFFERS_DOCUMENT);
			}
		} catch (Exception e) {
			if (createId.equals(PROMOTION_ONETIME)) {
				prodRefRecordsRejected++;
				LOGGER.error("Error occurred when inserting document into couchbase for onetime prodRef: "
						+ tpnb + "is rejected");
				rejectedProducts
						.add(Dockyard
								.getSysDate(PriceConstants.ISO_8601_FORMAT)
								.concat("~<ONETIME PROMOTION>~")
								.concat("CB Error  when inserting document into couchbase for onetime promotion: ")
								.concat(tpnb));
			} else {
				LOGGER.error("Error occurred when inserting document into couchbase for jms prodRef: "
						+ tpnb + "is rejected");
				rejectedProducts
						.add(Dockyard
								.getSysDate(PriceConstants.ISO_8601_FORMAT)
								.concat("~<JMS PROMOTION>~")
								.concat("CB Error  when inserting document into couchbase for jms promotion: ")
								.concat(tpnb));
			}
		}

		LOGGER.debug("Prod Offer Document " + PriceConstants.PROD_OFFERS + tpnb
				+ "_Z" + loc + " successfully.");

		if (isNewProduct == true) {
			newProductData.put(tpnb, effectiveDate);
		}

	}

	public void deleteDetailDisplayMapping(List<String> promoCompDetailIds)
			throws Exception {
		for (String promoCompDetailId : promoCompDetailIds) {
			repository.deleteProduct(PriceConstants.PROMO_DETAIL_ID_KEY
					+ promoCompDetailId);
			PROMOMSGCOUNTER
					.updateCounterForModMsg(DELETE_PROMOTION_LOOKUP_DOCUMENT);

			LOGGER.info(
					"Promotion mapping document deleted successfully for offer Detail Id {}",
					promoCompDetailId);
		}
	}

	public PromotionEntity deleteHierarchyDocs(String promoMsgForZoneId,
			String promoCompDisplayId, String hierDockey,
			PrmPrcChgDtlRef prmPrcChgDtlRef) throws Exception {
		PromotionEntity promotionToBeEdited = null;
		try {
			PromotionHierarchyEntity hierarchyEntityDoc = (PromotionHierarchyEntity) repository
					.getGenericObject(hierDockey,
							PromotionHierarchyEntity.class);
			Map<String, OfferEntity> offerMap = hierarchyEntityDoc
					.getPromotions();
			offerMap.get(PriceConstants.OFFER_PREFIX + promoCompDisplayId)
					.getOfferLocRef().remove(promoMsgForZoneId);
			hierarchyEntityDoc.lastUpdateDate = Dockyard
					.getSysDate(PriceConstants.ISO_8601_FORMAT);
			if (offerMap.get(PriceConstants.OFFER_PREFIX + promoCompDisplayId)
					.getOfferLocRef().isEmpty()) {
				offerMap.remove(PriceConstants.OFFER_PREFIX
						+ promoCompDisplayId);

			}
			if (!(Dockyard.isSpaceOrNull(offerMap) || offerMap.isEmpty())) {
				hierarchyEntityDoc.setPromotions(offerMap);
				repository.insertObject(hierDockey,
						hierarchyEntityDoc);
			} else {
				repository.deleteProduct(hierDockey);
				PROMOMSGCOUNTER
						.updateCounterForModMsg(DELETE_PROMOTION_HIERARCHY_DOCUMENT);
			}

			if (!Dockyard.isSpaceOrNull(promoCompDisplayId)) {
				if (Dockyard.isSpaceOrNull(promotionToBeEdited)) {
					promotionToBeEdited = (PromotionEntity) repository
							.getGenericObject(
									PriceConstants.PROMOTION_DOC_KEY_PREFIX
											+ promoCompDisplayId
											+ "_"
											+ promoMsgForZoneId,
									PromotionEntity.class);
				}

				if (!Dockyard.isSpaceOrNull(promotionToBeEdited)) {
					List<PromoItemListEntity> promoItemListEntities;
					List<PromoItemEntity> promoItemEntityList;
					String detailIdFromDelMsg = prmPrcChgDtlRef
							.getPromoCompDetailId().toString();
					promoItemListEntities = promotionToBeEdited
							.getPromoItemListEntities();
					promoItemEntityList = promoItemListEntities.get(0)
							.getPromoItems();
					int indexOfDetailIdToBeRemoved = -1;
					boolean isItemEntityExist = false;
					for (PromoItemEntity promoItemEntity : promoItemEntityList) {
						indexOfDetailIdToBeRemoved++;
						if (promoItemEntity.getRpmPromoCompDetailId().equals(
								detailIdFromDelMsg)) {
							isItemEntityExist = true;
							promotionToBeEdited.lastUpdateDate = Dockyard
									.getSysDate(PriceConstants.ISO_8601_FORMAT);
							break;
						}
					}
					if (isItemEntityExist) {
						promoItemEntityList.remove(indexOfDetailIdToBeRemoved);
					} else {
						LOGGER.info(
								"Detail Entity for subclass {} from Del Msg not present in {}",
								detailIdFromDelMsg,
								PriceConstants.PROMOTION_DOC_KEY_PREFIX
										+ promoCompDisplayId + "_"
										+ promoMsgForZoneId);
					}

				}
			}
		} catch (Exception e) {
			throw new PromoBusinessException(e.getMessage(), e);
		}
		return promotionToBeEdited;
	}

	public void deleteMultiBuyLookup(String offerId, String promoCompDetailId,
			Repository repository) throws PromoBusinessException {

		try {
			PromotionMasterEntity promotionMasterEntity = (PromotionMasterEntity) repository
					.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
							+ offerId, PromotionMasterEntity.class);

			/*
			 * When Master doc is empty it returns null, when Master is null
			 * delete LookUp
			 */
			if (promotionMasterEntity == null) {
				repository
						.deleteProduct(PriceConstants.PROMO_DETAIL_ID_KEY
								+ promoCompDetailId);
				PROMOMSGCOUNTER
						.updateCounterForModMsg(DELETE_PROMOTION_LOOKUP_DOCUMENT);
			}
			LOGGER.info(
					"Promotion mapping document deleted successfully for offer Detail Id {}",
					promoCompDetailId);
		} catch (DataAccessException e) {
			throw new PromoBusinessException(e);
		}

	}

	public String deleteProdOfferDoc(String item, String zoneId,
			String promoCompDisplayId) throws PromoBusinessException {

		String prodKey = PriceConstants.PROD_OFFERS + item + "_" + zoneId;
		ProductOffersEntity productOffersEntity;
		String effectiveDate = "";

		try {
			productOffersEntity = (ProductOffersEntity) repository
					.getGenericObject(prodKey, ProductOffersEntity.class);

			if (productOffersEntity == null) {
				LOGGER.info(
						"Product Offer Document is not present for the Item {}",
						item);
			} else {

				if (productOffersEntity
						.getProductOffersPromotionEntity(promoCompDisplayId) != null) {
					effectiveDate = productOffersEntity
							.getProductOffersPromotionEntity(promoCompDisplayId)
							.getEffectiveDate();
					productOffersEntity.getProductOffersPromotionMap().remove(
							promoCompDisplayId);

					if (productOffersEntity.getProductOffersPromotionMap()
							.size() == 0) {
						repository.deleteProduct(prodKey);
						PROMOMSGCOUNTER
								.updateCounterForModMsg(DELETE_PRODOFFERS_DOCUMENT);
						LOGGER.info("Product offer {} Document is deleted for",
								prodKey, promoCompDisplayId);
					} else {
						repository.insertObject(prodKey,
								productOffersEntity);
					}
				} else {
					LOGGER.info(
							"In Product offer {} promotion {} is not present to delete",
							prodKey, promoCompDisplayId);
					rejectedProducts
							.add("Promotion is not present for the offerId: "
									+ promoCompDisplayId);
				}

			}
		} catch (Exception e) {
			throw new PromoBusinessException(e);
		}
		return effectiveDate;

	}

	public Map<String, Object> deletePromoEntity(
			PromotionEntity promotionEntityForMsg)
			throws PromoBusinessException {

		Map<String, Object> promotionEventDataMap = null;
		try {
			String offerId = promotionEntityForMsg.getOfferRef();
			String locType = promotionEntityForMsg.getLocType();
			String locRef = promotionEntityForMsg.getLocRef();
			repository
					.deleteProduct(PriceConstants.PROMOTION_DOC_KEY_PREFIX
							+ offerId + "_" + locType + locRef);
			PROMOMSGCOUNTER.updateCounterForModMsg(DELETE_PROMOTION_DOCUMENT);

			promotionEventDataMap = deleteZoneInMasterDocument(offerId,
					locType, locRef, repository);

			LOGGER.info(
					"Promotion document deleted successfully for offer Display Id {} and Zone {}",
					offerId, locRef);

		} catch (Exception e) {
			throw new PromoBusinessException(e.getMessage(), e);
		}
		return promotionEventDataMap;

	}

	public Map<String, Object> deleteZoneInMasterDocument(String offerId,
			String locType, String locRef, Repository repository)
			throws PromoBusinessException {
		Map<String, Object> promotionEventDataMap = new HashMap<>();
		try {
			PromotionMasterEntity promotionMasterEntity = (PromotionMasterEntity) repository
					.getGenericObject(PriceConstants.PROMOTION_DOC_KEY_PREFIX
							+ offerId, PromotionMasterEntity.class);
			String promoDocKey = PriceConstants.PROMOTION_DOC_KEY_PREFIX
					+ offerId + "_" + locType + locRef;
			if (promotionMasterEntity != null) {
				String locRefToBeRemoved = "";
				boolean isLocRefExist = false;
				for (String offerLocRef : promotionMasterEntity
						.getOfferLocRef()) {
					if (offerLocRef.equals(promoDocKey)) {
						isLocRefExist = true;
						locRefToBeRemoved = offerLocRef;
						break;
					}
				}
				if (isLocRefExist) {
					promotionMasterEntity.getOfferLocRef().remove(
							locRefToBeRemoved);
				} else {
					LOGGER.info(
							"Promotion Master Document does not contain loc Ref  {} ",
							promoDocKey);
				}
				Map<String, String> promotionDataMap = new HashMap<>();
				promotionDataMap.put(offerId, null);
				if (promotionMasterEntity.getOfferLocRef().isEmpty()) {
					repository
							.deleteProduct(PriceConstants.PROMOTION_DOC_KEY_PREFIX
									+ offerId);
					PROMOMSGCOUNTER
							.updateCounterForModMsg(DELETE_PROMOTION_MASTER_DOCUMENT);
					LOGGER.info(
							"Promotion Master Document deleted successfully for offer Id {} ",
							offerId);
					promotionEventDataMap.put(PROMOTION_DELETED_EVENT_TYPE,
							promotionDataMap);
				} else {
					writeOfferLocMapping(promotionMasterEntity,
							PriceConstants.PROMOTION_DOC_KEY_PREFIX + offerId);
					promotionEventDataMap.put(
							PROMOTION_LOCATION_REMOVED_EVENT_TYPE,
							promotionDataMap);
				}
			} else {
				LOGGER.info(
						"Promotion Master Document not found for Offer {} ",
						offerId);
			}
		} catch (DataAccessException e) {
			throw new PromoBusinessException(e);
		}
		return promotionEventDataMap;
	}

	public Dockyard getDockyard() {

		if (dockyard == null) {
			dockyard = new Dockyard();
		}
		return dockyard;
	}

	public File getOnetimePromoFile(String fileName) {
		if (onetimePromoFile == null) {
			onetimePromoFile = new File(configuration.getPromotionFilePath()
					+ "/" + runIdentifier + "/" + fileName);
		}
		return onetimePromoFile;
	}

	public BufferedReader getPromotionFileReader(FileReader reader) {
		if (promotionFileReader == null) {
			promotionFileReader = new BufferedReader(reader);
		}
		return promotionFileReader;
	}

	public String getRunIdentifier() {
		return runIdentifier;
	}

	/**
	 * @param promotionEntity
	 * @return
	 * @throws IOException
	 */
	public boolean processHierarchyPromotions(PromotionEntity promotionEntity,
			Map<String, PromotionHierarchyEntity> hierarchyPromos, String source)
			throws PromoBusinessException {

		String tescoItemRef = null;
		PromotionHierarchyEntity hierarchyPromoEntity = null;
		boolean isHierachyMsgProcessed = true;

		for (PromoItemListEntity promoItemListEntity : promotionEntity
				.getPromoItemListEntities()) {

			boolean isBuyListType = false;

			if (PriceConstants.PROMO_ITEM_LIST_BUY_TYPE
					.equals(promoItemListEntity.getListType())) {
				isBuyListType = true;
			}

			if (promoItemListEntity.getPromoItems() != null) {

				for (PromoItemEntity promoItemEntity : promoItemListEntity
						.getPromoItems()) {
					if (PriceConstants.HIERARCHY_LIST.contains(promoItemEntity
							.getItemType().toUpperCase())) {
						List<String> hierarchy = new LinkedList<String>();
						StringTokenizer hierarchyTokens = new StringTokenizer(
								promoItemEntity.getItemRef(), "-");
						while (hierarchyTokens.hasMoreTokens()) {
							hierarchy.add(hierarchyTokens.nextToken());
						}

						if (hierarchy.size() < 3) {
							for (int i = hierarchy.size(); i < 3; i++) {
								hierarchy.add(null);
							}
						}

						try {
							tescoItemRef = PriceUtility.convertRMStoTesco(
									hierarchy.get(0), hierarchy.get(1),
									hierarchy.get(2));
						} catch (ProductEncodeException e1) {
							hierarchyRecordsRejected++;
							LOGGER.error(
									"The promotion with offer ID : {} and Zone : {} is skipped",
									promotionEntity.getOfferRef(),
									promotionEntity.getLocType()
											+ promotionEntity.getLocRef());
							if (rejectedProducts == null) {
								rejectedProducts = new HashSet<>();
							}
							rejectedProducts.add("Promotion:"
									+ promotionEntity.offerRef
									+ "| is incomplete");
							isHierachyMsgProcessed = false;
							tescoItemRef = null;
							break;
						}

						promoItemEntity.setItemRef(tescoItemRef);

						if (isBuyListType) {
							try {
								hierarchyPromoEntity = (PromotionHierarchyEntity) repository
										.getGenericObject(
												PriceConstants.HIERARCHY_PROMO_PREFIX
														+ tescoItemRef,
												PromotionHierarchyEntity.class);
							} catch (DataAccessException e) {
								throw new PromoBusinessException(e);
							}
							if (hierarchyPromoEntity == null) {
								hierarchyPromoEntity = new PromotionHierarchyEntity();

								hierarchyPromoEntity
										.setHierarchyId(tescoItemRef);
								if (source.equals(PriceConstants.ONE_TIME_RPM)) {
									hierarchyPromoEntity
											.setCreatedById(PriceConstants.ONE_TIME_RPM);
								}
								if (source.equals(PriceConstants.JMS_RPM)) {
									hierarchyPromoEntity
											.setCreatedById(PriceConstants.JMS_RPM);
								}
								hierarchyPromoEntity
										.setCreatedDate(Dockyard
												.getSysDate(PriceConstants.ISO_8601_FORMAT));
								if (source.equals(PriceConstants.ONE_TIME_RPM)) {
									hierarchyPromoEntity
											.setLastUpdatedById(PriceConstants.ONE_TIME_RPM);
								}
								if (source.equals(PriceConstants.JMS_RPM)) {
									hierarchyPromoEntity
											.setLastUpdatedById(PriceConstants.JMS_RPM);
								}
								hierarchyPromoEntity
										.setLastUpdateDate(Dockyard
												.getSysDate(PriceConstants.ISO_8601_FORMAT));
							}

							OfferEntity offerEntity = hierarchyPromoEntity
									.getPromotions().get(
											PriceConstants.OFFER_PREFIX
													+ promotionEntity
															.getOfferRef());

							if (offerEntity == null) {
								offerEntity = new OfferEntity();
							}
							offerEntity.setOfferRef(promotionEntity
									.getOfferRef());

							OfferLocRefEntity offerLocRefEntity = new OfferLocRefEntity();

							offerLocRefEntity.setEffectiveDate(promoItemEntity
									.getEffectiveDate());
							offerLocRefEntity.setEndDate(promoItemEntity
									.getEndDate());
							offerEntity.getOfferLocRef().put(
									PriceConstants.ZONE_PREFIX
											+ promotionEntity.getLocRef(),
									offerLocRefEntity);
							hierarchyPromoEntity.getPromotions().put(
									PriceConstants.OFFER_PREFIX
											+ promotionEntity.getOfferRef(),
									offerEntity);

							hierarchyPromos.put(
									PriceConstants.HIERARCHY_PROMO_PREFIX
											+ tescoItemRef,
									hierarchyPromoEntity);
						}

					}

				}
			}
			if (!isHierachyMsgProcessed) {
				break;
			}

		}

		return isHierachyMsgProcessed;
	}

	/**
	 * @param promotionEntity
	 * @return
	 */
	private boolean processOfferLookupOneTime(PromotionEntity promotionEntity)
			throws Exception {

		for (PromoItemListEntity promoItemListEntity : promotionEntity
				.getPromoItemListEntities()) {

			if (!PriceConstants.PROMO_ITEM_LIST_BUY_TYPE
					.equals(promoItemListEntity.getListType())) {
				continue;
			}

			if (promoItemListEntity.getPromoItems() != null) {

				for (PromoItemEntity promoItemEntity : promoItemListEntity
						.getPromoItems()) {

					try {
						repository.insertObject(
								PriceConstants.PROMO_DETAIL_ID_KEY
										+ promoItemEntity
										.getRpmPromoCompDetailId(),
								promotionEntity.getOfferRef());
						lookupRecordsInserted++;
					} catch (Exception e) {
						lookupRecordsRejected++;
						LOGGER.error(
								"Error in method processOfferLookupOneTime(PromotionEntity) : {}",
								e);
						return false;

					}

				}
			}
		}
		return true;
	}

	/**
	 * @param hierarchyPromos
	 * @return
	 */
	public boolean saveHierarchyPromotions(
			Map<String, PromotionHierarchyEntity> hierarchyPromos) {
		Iterator<String> hierarchPromoKeys = hierarchyPromos.keySet()
				.iterator();
		while (hierarchPromoKeys.hasNext()) {
			String hierarchyPromoKey = hierarchPromoKeys.next().toString();
			try {
				repository.insertObject(hierarchyPromoKey,
						hierarchyPromos.get(hierarchyPromoKey));
				PROMOMSGCOUNTER
						.updateCounterForCreMsg(PROMOTION_HIERARCHY_DOCUMENT);
			} catch (Exception e) {
				LOGGER.error("Error occurred when inserting document into couchbase for JMS Hierarchy: "
						+ hierarchyPromoKey + "is rejected");
				rejectedProducts
						.add(Dockyard
								.getSysDate(PriceConstants.ISO_8601_FORMAT)
								.concat("~<JMS HIERARCHY PROMOTION>~")
								.concat("CB Error  when inserting document into couchbase for onetime Hierarchy: ")
								.concat(hierarchyPromoKey));
				return false;
			}
		}
		return true;
	}

	// Save hierarchy promos for onetime
	public Map<String, Integer> saveHierarchyPromotionsOneTime(
			Map<String, PromotionHierarchyEntity> hierarchyPromos) {
		int insertedCount = 0;
		int rejectedCount = 0;

		Map<String, Integer> countMap = new HashMap<String, Integer>();
		Iterator<String> hierarchPromoKeys = hierarchyPromos.keySet()
				.iterator();
		while (hierarchPromoKeys.hasNext()) {
			String hierarchyPromoKey = hierarchPromoKeys.next().toString();
			try {
				repository.insertObject(hierarchyPromoKey,
						hierarchyPromos.get(hierarchyPromoKey));
				insertedCount++;
				countMap.put(PriceConstants.HIERARCHY_PROMOTION_INSERTED_COUNT,
						insertedCount);

			} catch (Exception e) {
				rejectedCount++;
				LOGGER.error("Error occurred when inserting document into couchbase for onetime Hierarchy: "
						+ hierarchyPromoKey + "is rejected");
				rejectedProducts
						.add(Dockyard
								.getSysDate(PriceConstants.ISO_8601_FORMAT)
								.concat("~<ONETIME PROMOTION>~")
								.concat("CB Error  when inserting document into couchbase for onetime Hierarchy: ")
								.concat(hierarchyPromoKey));
				countMap.put(PriceConstants.HIERARCHY_PROMOTION_REJECTED_COUNT,
						rejectedCount);
			}
		}
		return countMap;
	}

	public void setOnetimePromoFile(File onetimePromoFile) {
		this.onetimePromoFile = onetimePromoFile;
	}

	public void setPromotionFileReader(BufferedReader promotionFileReader) {
		this.promotionFileReader = promotionFileReader;
	}

	public void setRunIdentifier(String runIdentifier) {
		this.runIdentifier = runIdentifier;
	}

	private boolean validatePromotionDoc(PromotionEntity promotionEntity) {
		boolean isValid = true;
		String offerId = promotionEntity.getOfferRef();
		String zoneId = promotionEntity.getLocRef();
		if (offerId == null || isBlank(offerId)) {

			LOGGER.error("offerId is null for a promotion.Therefore it has been skipped.");
			rejectedProducts
					.add("offerId is null for a promotion Message with Offer "
							+ promotionEntity.tillRollDescription
							+ " Therefore it has been skipped.");
			isValid = false;
			return isValid;
		}
		if (promotionEntity.getOfferType() == null
				|| isBlank(promotionEntity.getOfferType())) {
			LOGGER.error("Offertype is null for a promotion with offer id "
					+ offerId + " zone:" + zoneId);
			rejectedProducts
					.add("Offertype is null for a promotion with offer id "
							+ offerId + " zone:" + zoneId);

			isValid = false;
		}
		if (promotionEntity.getState() == null
				|| !promotionEntity.getState().equalsIgnoreCase(
						PriceConstants.PROMOTION_STATE)) {
			LOGGER.error("The state of the promotion is not "
					+ PriceConstants.PROMOTION_STATE + "  with offer id"
					+ offerId + " zone:" + zoneId);
			rejectedProducts.add("The state of the promotion is not "
					+ PriceConstants.PROMOTION_STATE + "  with offer id"
					+ offerId);

			isValid = false;
		}

		if (!promotionEntity.getOfferType().equals(
				PriceConstants.PROMO_SIMPLE_OFFER_TYPE)
				&& (promotionEntity.getExternalPromoId() == null || isBlank(promotionEntity
						.getExternalPromoId()))) {
			LOGGER.error("ExtrenalPromoId is null for a promotion with offer id "
					+ offerId + " zone:" + zoneId);
			rejectedProducts
					.add("ExtrenalPromoId is null for a promotion with offer id "
							+ offerId + " zone:" + zoneId);

			isValid = false;
		}
		if (promotionEntity.getPromoRewardEntities() != null) {
			for (PromoRewardEntity promoRewardEntity : promotionEntity
					.getPromoRewardEntities()) {
				if (promoRewardEntity.getChangeType() == null
						|| isBlank(promoRewardEntity.getChangeType())) {
					LOGGER.error("ChangeType is null in promoRewards with offer id "
							+ offerId + " zone:" + zoneId);
					rejectedProducts
							.add("ChangeType is null in promoRewards with offer id "
									+ offerId + " zone:" + zoneId);
					isValid = false;
				}

			}
		}
		if (promotionEntity.getLocType() == null
				|| isBlank(promotionEntity.getLocType())) {
			LOGGER.error("LocType is null in PromoLocations with offer id "
					+ offerId);
			rejectedProducts
					.add("LocType is null in PromoLocations with offer id "
							+ offerId);

			isValid = false;
		}
		if (promotionEntity.getLocRef() == null
				|| isBlank(promotionEntity.getLocRef())) {
			LOGGER.error("LocRef is null in PromoLocations with offer id "
					+ offerId);
			rejectedProducts
					.add("LocRef is null in PromoLocations with offer id "
							+ offerId);

			isValid = false;
		}
		if (promotionEntity.getPromoItemListEntities() != null) {
			for (PromoItemListEntity promoItemListEntity : promotionEntity
					.getPromoItemListEntities()) {
				if (PriceConstants.PROMO_ITEM_LIST_BUY_TYPE
						.equals(promoItemListEntity.getListType())) {

					for (PromoItemEntity promoItemEntity : promoItemListEntity
							.getPromoItems()) {
						if (promoItemEntity.getEffectiveDate() == null
								|| isBlank(promoItemEntity.getEffectiveDate())) {
							LOGGER.error("Effective date is null in promoItems with offer id "
									+ offerId + " zone:" + zoneId);
							rejectedProducts
									.add("Effective date is null in promoItems with offer id "
											+ offerId + " zone:" + zoneId);

							isValid = false;
						}
						if (promoItemEntity.getEndDate() == null
								|| isBlank(promoItemEntity.getEndDate())) {
							LOGGER.error("EndDate is null in promoItems with offer id "
									+ offerId + " zone:" + zoneId);
							rejectedProducts
									.add("EndDate is null in promoItems with offer id "
											+ offerId + " zone:" + zoneId);

							isValid = false;
						}
						if (promoItemEntity.getItemType() == null
								|| isBlank(promoItemEntity.getItemType())) {
							LOGGER.error("ItemType is null in promoItems with offer id "
									+ offerId + " zone:" + zoneId);
							rejectedProducts
									.add("ItemType is null in promoItems with offer id "
											+ offerId + " zone:" + zoneId);

							isValid = false;
						}
						if (promoItemEntity.getItemRef() == null
								|| isBlank(promoItemEntity.getItemRef())) {
							LOGGER.error("ItemRef is null in promoItems with offer id "
									+ offerId + " zone:" + zoneId);
							rejectedProducts
									.add("ItemRef is null in promoItems with offer id "
											+ offerId + " zone:" + zoneId);

							isValid = false;
						}
						if (promoItemEntity.getPosLabelReqInd() == null
								|| isBlank(promoItemEntity.getPosLabelReqInd())) {
							LOGGER.error("PosLabelReqInd is null in promoItems with offer id "
									+ offerId + " zone:" + zoneId);
							rejectedProducts
									.add("PosLabelReqInd is null in promoItems with offer id "
											+ offerId + " zone:" + zoneId);

							isValid = false;
						} else if (!PriceConstants.POS_LABEL_Y
								.equals(promoItemEntity.getPosLabelReqInd())
								&& !PriceConstants.POS_LABEL_N
										.equals(promoItemEntity
												.getPosLabelReqInd())) {
							LOGGER.error("PosLabelReqInd is invalid in promoItems with offer id "
									+ offerId + " zone:" + zoneId);
							rejectedProducts
									.add("PosLabelReqInd is invalid in promoItems with offer id "
											+ offerId + " zone:" + zoneId);

							isValid = false;
						}

						if (promoItemEntity.getRpmPromoCompDetailId() == null
								|| isBlank(promoItemEntity
										.getRpmPromoCompDetailId())) {
							LOGGER.error("RpmPromoCompDetailId is null in promoItems with offer id "
									+ offerId + " zone:" + zoneId);
							rejectedProducts
									.add("pull RpmPromoCompDetailId is null in promoItems with offer id "
											+ offerId + " zone:" + zoneId);

							isValid = false;
						}

					}
				}
			}
		}

		return isValid;
	}

	public void write(String fileName) throws WriterBusinessException {
		LOGGER.info("Importing Promotions into Couchbase");
		try {
			onetimePromoFile = getOnetimePromoFile(fileName);
			writePromotion(true);
		} catch (PromoBusinessException e) {
			LOGGER.error(
					"Error occured during importing of onetimepromo fille", e);
			throw new WriterBusinessException(e.getMessage(), e.getCause());
		} finally {
			PromotionResource.getImportSemaphoreForIdentifier(fileName)
					.release();
		}
	}

	public void writeHierarchyDoc(
			PromotionHierarchyEntity promotionHierarchyEntity, String key)
			throws PromoBusinessException {

		try {
			repository.insertObject(key, promotionHierarchyEntity);
		} catch (Exception e) {
			throw new PromoBusinessException(e.getMessage(), e);
		}
	}

	public void writeOfferLocMapping(
			PromotionMasterEntity promotionMasterEntity, String key)
			throws PromoBusinessException {
		String createId = promotionMasterEntity.getCreatedById();

		try {
			repository.insertObject(key, promotionMasterEntity);
			if (createId.equals(PriceConstants.ONE_TIME_RPM)) {
				promotionMasterInsertedCount++;
			} else {
				PROMOMSGCOUNTER
						.updateCounterForCreMsg(PROMOTION_MASTER_DOCUMENT);
			}

		} catch (Exception e) {
			LOGGER.error("Error occurred when inserting document into couchbase for regular promotion: "
					+ key + "is rejected");
			rejectedProducts
					.add(Dockyard
							.getSysDate(PriceConstants.ISO_8601_FORMAT)
							.concat("~<JMS PROMOTION>~")
							.concat("CB Error  when inserting document into couchbase for regular promotion: ")
							.concat(key));

			throw new PromoBusinessException(e.getMessage(), e);
		}
	}

	public Map<String, String> writeProdOfferDoc(PromotionEntity promotionEntity)
			throws PromoBusinessException {

		newProductData = new HashMap<String, String>();
		List<PromoItemListEntity> promoItemListEntities;
		promoItemListEntities = promotionEntity.getPromoItemListEntities();
		String effectiveDate = promoItemListEntities.get(0).getPromoItems()
				.get(0).getEffectiveDate();
		String endDate = promoItemListEntities.get(0).getPromoItems().get(0)
				.getEndDate();

		for (PromoItemListEntity promoItemListEntity : promoItemListEntities) {
			if (PriceConstants.PROMO_ITEM_LIST_BUY_TYPE
					.equals(promoItemListEntity.getListType())) {
				List<PromoItemEntity> promoItems = promoItemListEntity
						.getPromoItems();
				for (PromoItemEntity promoItemEntity : promoItems) {
					if (isNumeric(promoItemEntity.getItemRef())) {
						createAndInsertProdOfferDoc(promotionEntity,
								promoItemEntity,
								promoItemListEntity.getThresholdRefs());
					} else {
						prodRefRecordsRejected++;
						LOGGER.info(
								"This promotion {} is Hierarchy Promotion. Hence PROD OFFER doc will not be created.",
								promotionEntity.getOfferRef());
					}

				}
			} else if (PriceConstants.PROMO_ITEM_LIST_GET_TYPE
					.equals(promoItemListEntity.getListType())
					&& (promoItemListEntity.getPromoItems() != null)) {
				List<PromoItemEntity> promoItems = promoItemListEntity
						.getPromoItems();
				for (PromoItemEntity promoItemEntity : promoItems) {
					if (isNumeric(promoItemEntity.getItemRef())) {
						createAndInsertProdOfferDocForGetList(promotionEntity,
								promoItemEntity,
								promoItemListEntity.getRewardRefs(),
								effectiveDate, endDate);
					} else {
						prodRefRecordsRejected++;
						LOGGER.info(
								"This promotion {} is Hierarchy Promotion. Hence PROD OFFER doc will not be created.",
								promotionEntity.getOfferRef());
					}

				}

			}

		}
		return newProductData;

	}

	public void writePromoEntityFromMessage(
			PromotionEntity promotionEntityForMsg)
			throws PromoBusinessException {

		try {
			promotionEntityFromMessage = promotionEntityForMsg;
			writePromotion(false);
		} catch (Exception e) {
			LOGGER.error("Error occurred when inserting document into couchbase for onetime prodRef: "
					+ promotionEntityForMsg + "is rejected");
			throw new PromoBusinessException(e.getMessage(), e);
		}

	}

	private void writePromotion(boolean isOneTimeImport)
			throws PromoBusinessException {
		String rejectfilepath = configuration.getRejectFilePath();
		String date = Dockyard.getSysDate("yyyyMMdd");
		rejectedProducts = new HashSet<>();
		Set<String> zoneLoc = null;
		PromotionMasterEntity masterDoc = null;
		String source = null;
		JsonParser jsonParser = null;

		try {
			if (isOneTimeImport) {
				FileReader reader = null;
				if(onetimePromoFile != null) {
					 reader = new FileReader(onetimePromoFile);
				}
				promotionFileReader = getPromotionFileReader(reader);
				Map<String, PromotionHierarchyEntity> hierarchyPromosOneTime = null;

				JsonFactory jsonFactory = new MappingJsonFactory();
				jsonParser = jsonFactory.createJsonParser(promotionFileReader);

				int counter = 0;
				JsonToken token = jsonParser.nextToken();
				if (token != JsonToken.START_ARRAY) {
					LOGGER.error("Root should be an array token ']': quiting.");
					PromotionResource.setErrorString(runIdentifier,
							"File doesnot start with array token ']' ");
					return;
				}
				while (jsonParser.nextToken() != JsonToken.END_ARRAY) {
					hierarchyPromosOneTime = new HashMap<String, PromotionHierarchyEntity>();
					zoneLoc = new HashSet<String>();

					counter++;
					JsonNode rootNode = jsonParser.readValueAsTree();

					String promotionEntityString = rootNode.toString();
					PromotionEntity promotionEntity = objectMapper.readValue(
							promotionEntityString, PromotionEntity.class);
					String offerId = promotionEntity.getOfferRef();
					String locRef = promotionEntity.getLocRef();
					String locType = promotionEntity.getLocType();

					for (PromoThresholdEntity promoThresholdEntity : promotionEntity
							.getPromoThresholdEntities()) {
						if (PriceConstants.PROMO_THR_TYPES.QTY.value().equals(
								promoThresholdEntity.thresholdType)) {
							promoThresholdEntity.thresholdAmount = PriceConstants.PROMO_CHANGE_AMT_FOR_QTY_THR;
						}
						if (PriceConstants.PROMO_THR_TYPES.AMT.value().equals(
								promoThresholdEntity.thresholdType)) {

							promoThresholdEntity.thresholdQty = PriceConstants.PROMO_CHANGE_QTY_FOR_AMT_THR;

						}
					}
					promotionEntity.setPromoThresholdEntities(promotionEntity
							.getPromoThresholdEntities());

					for (PromoRewardEntity promoRewardEntity : promotionEntity
							.getPromoRewardEntities()) {
						promoRewardEntity.changeQty = PriceConstants.DEFAULT_PROMO_CHANGE_QTY;
						if (PriceConstants.PROMO_CHG_TYPES.AMT.value().equals(
								promoRewardEntity.changeType)
								|| PriceConstants.PROMO_CHG_TYPES.FXD.value()
										.equals(promoRewardEntity.changeType)) {
							promoRewardEntity.changePercent = PriceConstants.PROMO_CHANGE_PERCENT_FOR_FIXED_AMOUNT;
						}
						if (PriceConstants.PROMO_CHG_TYPES.PCT.value().equals(
								promoRewardEntity.changeType)) {
							promoRewardEntity.changeAmount = PriceConstants.PROMO_CHANGE_AMT_FOR_PRCNTGE_TYPE;
						}
						if (PriceConstants.PROMO_CHANGE_UOM
								.equals(promoRewardEntity.changeUom)) {
							promoRewardEntity.changeUom = null;
						}
					}

					promotionEntity.setPromoRewardEntities(promotionEntity
							.getPromoRewardEntities());

					if (!validatePromotionDoc(promotionEntity)) {
						promotionRecordsRejectedCount++;
						if (offerId != null && !isBlank(offerId)) {
							LOGGER.error("The promotion with offer ID "
									+ promotionEntity.getOfferRef()
									+ " is skipped");
							rejectedProducts.add("Promotion:" + offerId
									+ "| is incomplete");
						} else {
							LOGGER.error("Promotion object " + counter
									+ "is skipped");
							rejectedProducts.add("Promotion object:" + counter
									+ "| is incomplete");
						}

						continue;
					}
					source = PriceConstants.ONE_TIME_RPM;
					if (!processHierarchyPromotions(promotionEntity,
							hierarchyPromosOneTime, source)) {
						continue;
					} else {
						Map countMap = saveHierarchyPromotionsOneTime(hierarchyPromosOneTime);
						if (countMap
								.get(PriceConstants.HIERARCHY_PROMOTION_INSERTED_COUNT) != null) {
							hierarchyRecordsInserted = hierarchyRecordsInserted
									+ (Integer) (countMap
											.get(PriceConstants.HIERARCHY_PROMOTION_INSERTED_COUNT));
						}
						if (countMap
								.get(PriceConstants.HIERARCHY_PROMOTION_REJECTED_COUNT) != null) {
							hierarchyRecordsRejected = hierarchyRecordsRejected
									+ (Integer) (countMap
											.get(PriceConstants.HIERARCHY_PROMOTION_REJECTED_COUNT));

							continue;
						}

					}
					try {
						repository.insertObject(
								PriceConstants.PROMOTION_DOC_KEY_PREFIX
										+ offerId + "_" + locType + locRef,

								promotionEntity);
						promotionRecordsInsertedCount++;
					} catch (Exception e) {
						promotionRecordsRejectedCount++;
						LOGGER.error("Error occurred when inserting document into couchbase for onetime promotion: "
								+ offerId + "is rejected");
						rejectedProducts
								.add(Dockyard
										.getSysDate(
												PriceConstants.ISO_8601_FORMAT)
										.concat("~<ONETIME PROMOTION>~")
										.concat("CB Error  when inserting document into couchbase for onetime promotion: ")
										.concat(offerId));

					}

					zoneLoc.add(PriceConstants.PROMOTION_DOC_KEY_PREFIX
							+ offerId + "_" + locType + locRef);
					try {
						masterDoc = (PromotionMasterEntity) repository
								.getGenericObject(
										PriceConstants.PROMOTION_DOC_KEY_PREFIX
												+ offerId,
										PromotionMasterEntity.class);
					} catch (DataAccessException e) {
						throw new PromoBusinessException(e);
					}
					PromotionMasterEntity promotionMasterEntity = constructMaster(
							promotionEntity, zoneLoc, masterDoc);
					promotionMasterEntity
							.setCreatedById(PriceConstants.ONE_TIME_RPM);
					try {
						writeOfferLocMapping(promotionMasterEntity,
								PriceConstants.PROMOTION_DOC_KEY_PREFIX
										.concat(offerId));
						promotionMasterInsertedCount++;
					} catch (Exception e) {
						promotionMasterRejectedCount++;
						LOGGER.error("Error occurred when inserting document into couchbase for promotion: "
								+ offerId + "is rejected");
						rejectedProducts
								.add(Dockyard
										.getSysDate(
												PriceConstants.ISO_8601_FORMAT)
										.concat("~<ONETIME PROMOTION>~")
										.concat("CB Error  when inserting document into couchbase for promotion: ")
										.concat(offerId));

					}
					try {
						if (processOfferLookupOneTime(promotionEntity)) {
							LOGGER.debug(
									"Lookup document inserted for offer : {} successfully!",
									promotionEntity.getOfferRef());
						} else {
							lookupRecordsRejected++;
							rejectedProducts
									.add("Error to insert lookup document: "
											+ promotionEntity.getOfferRef()
											+ "is got rejected.");
							LOGGER.error("Error occured while creating promoton lookup document for one time load");
						}
					} catch (Exception e) {
						lookupRecordsRejected++;
						rejectedProducts
								.add("Error to insert lookup document: "
										+ promotionEntity.getOfferRef()
										+ "is got rejected.");
						LOGGER.error(
								"Error in method processOfferLookupOneTime(PromotionEntity) : {}"
										+ promotionEntity.getOfferRef(), e);

					}

					/**
					 * Creating new ProdOffer Doc to support the Future dated
					 * promotions in PriceService
					 */
					try {
						writeProdOfferDoc(promotionEntity);
						prodRefRecordsInserted++;
					} catch (Exception e) {
						prodRefRecordsRejected++;
						LOGGER.error("Error occurred when inserting document into couchbase for onetime prodRef: "
								+ promotionEntity.getOfferRef() + "is rejected");
						rejectedProducts
								.add(Dockyard
										.getSysDate(
												PriceConstants.ISO_8601_FORMAT)
										.concat("~<ONETIME PROMOTION>~")
										.concat("CB Error  when inserting document into couchbase for onetime prodRef: ")
										.concat(promotionEntity.getOfferRef()));

					}

				}
				/** Close the json parser after processing */
				jsonParser.close();
				LOGGER.info("Promotion documents for onetime inserted : "
						+ promotionRecordsInsertedCount);
				LOGGER.info("Promotion documents for onetime rejected : "
						+ promotionRecordsRejectedCount);
				LOGGER.info("Promotion Offer documents for onetime inserted : "
						+ promotionMasterInsertedCount);
				LOGGER.info("Promotion Offer documents for onetime rejected : "
						+ promotionMasterRejectedCount);
				LOGGER.info("Look up documents for onetime inserted : "
						+ lookupRecordsInserted);
				LOGGER.info("Look up documents for onetime rejected : "
						+ lookupRecordsRejected);
				LOGGER.info("Hierarchy documents for onetime inserted : "
						+ hierarchyRecordsInserted);
				LOGGER.info("Hierarchy documents for onetime rejected : "
						+ hierarchyRecordsRejected);
				LOGGER.info("Prodref document for onetime is inserted: "
						+ prodRefRecordsInserted);
				LOGGER.info("Prodref document for onetime is rejected: "
						+ prodRefRecordsRejected);
				LOGGER.info("Total promotion documents for onetime read : "
						+ counter);

			} else {
				zoneLoc = new HashSet<String>();
				String offerId = promotionEntityFromMessage.getOfferRef();
				String locRef = promotionEntityFromMessage.getLocRef();
				String locType = promotionEntityFromMessage.getLocType();
				Map<String, PromotionHierarchyEntity> hierarchyPromosMsg = new HashMap<String, PromotionHierarchyEntity>();
				if (offerId != null && !isBlank(offerId)) {
					if (!validatePromotionDoc(promotionEntityFromMessage)) {
						LOGGER.error("The promotion with offer ID " + offerId
								+ " is skipped");
					} else {
						String merch = promotionEntityFromMessage
								.getPromoItemListEntities().get(0)
								.getPromoItems().get(0).getItemType()
								.toString();
						if (!Dockyard.isSpaceOrNull(merch)
								&& !("TPNB".equalsIgnoreCase(merch))) {

							hierarchyPromosMsg = constructHierarchy(promotionEntityFromMessage);
							saveHierarchyPromotions(hierarchyPromosMsg);
						}
						try {
							repository.insertObject(
									PriceConstants.PROMOTION_DOC_KEY_PREFIX
											+ offerId + "_" + locType + locRef,
									promotionEntityFromMessage);
							PROMOMSGCOUNTER
									.updateCounterForCreMsg(PROMOTION_DOCUMENT);
						} catch (Exception e) {

							LOGGER.error("Error occurred when inserting document into couchbase for regular promotion: "
									+ offerId + "is rejected");
							rejectedProducts
									.add(Dockyard
											.getSysDate(
													PriceConstants.ISO_8601_FORMAT)
											.concat("~<JMS PROMOTION>~")
											.concat("CB Error  when inserting document into couchbase for regular promotion: ")
											.concat(offerId));

						}
						LOGGER.info(
								"Promotion Msg Object Inserted for OfferId: {} Zone: {}",
								offerId, locRef);
						zoneLoc.add(PriceConstants.PROMOTION_DOC_KEY_PREFIX
								+ offerId + "_" + locType + locRef);
						try {
							masterDoc = (PromotionMasterEntity) repository
									.getGenericObject(
											PriceConstants.PROMOTION_DOC_KEY_PREFIX
													+ offerId,
											PromotionMasterEntity.class);
						} catch (DataAccessException e) {
							LOGGER.error("Error occurred when inserting document into couchbase for regular promotion: "
									+ offerId + "is rejected");
							rejectedProducts
									.add(Dockyard
											.getSysDate(
													PriceConstants.ISO_8601_FORMAT)
											.concat("~<JMS PROMOTION MASTER>~")
											.concat("CB Error  when inserting document into couchbase for regular promotion: ")
											.concat(offerId));
							throw new PromoBusinessException(e);
						}

						PromotionMasterEntity promotionMasterEntity = constructMaster(
								promotionEntityFromMessage, zoneLoc, masterDoc);
						writeOfferLocMapping(promotionMasterEntity,
								PriceConstants.PROMOTION_DOC_KEY_PREFIX
										.concat(offerId));
					}

				} else {
					LOGGER.error("The promotion Msg Object Doesn't have Offer Id");
					rejectedProducts
							.add("The promotion Msg Object Doesn't have Offer Id");
				}

			}
		} catch (IOException e) {
			throw new PromoBusinessException(e.getMessage(), e);
		} finally {
			/** Close the json parser after processing */

			try {
				if (jsonParser != null) {
					jsonParser.close();
				}
			} catch (IOException e) {
				throw new PromoBusinessException(e.getMessage(), e);
			}
		}

		if (!rejectedProducts.isEmpty()) {
			getDockyard().writeProductDetailsToFile(
					rejectfilepath + "/REJECT_FILE_PROMOTION_" + date + ".log",
					rejectedProducts);
			rejectedProducts.clear();
		}

	}

	public void writeUpdatedThresholdDocumentToCB(PromotionEntity pE)
			throws PromoBusinessException, JsonProcessingException {

		String offerId = pE.getOfferRef();
		String locRef = pE.getLocRef();
		String locType = pE.getLocType();
		try {
			repository.insertObject(
					PriceConstants.PROMOTION_DOC_KEY_PREFIX + offerId + "_"
							+ locType + locRef, pE);
		} catch (Exception e) {
			LOGGER.error("Promotion couldn't be inserted for Threshold promotion due to DB error for offerId: "
					+ offerId);
		}
	}
}