package com.tesco.services.adapters.rpm.writers;

public interface CSVHeaders {

    static interface Price {
        String ITEM = "ITEM";
        String TPNC = "TPNC";
        String PRICE_ZONE_ID = "PRICE_ZONE_ID";
        String PRICE_ZONE_PRICE = "SELLING_RETAIL";
        /**Added/Modified By Nibedita/Mukund - PS-112
         * Given the  price End Point,When the price rest calls are requested, then the response JSON should contain selling UOM for the tpnc line with IDL  */
        String SELLING_UOM = "SELLING_UOM";
        String[] PRICE_ZONE_HEADERS = {ITEM,TPNC, PRICE_ZONE_ID, PRICE_ZONE_PRICE,SELLING_UOM};

        String PROMO_ZONE_ID = "PROMO_ZONE_ID";
        String PROMO_ZONE_PRICE = "SIMPLE_PROMO_RETAIL";
        String[] PROMO_ZONE_HEADERS = {ITEM, TPNC, PROMO_ZONE_ID, PROMO_ZONE_PRICE};
    }

    static interface StoreZone {
        String STORE_ID = "STORE";
        String ZONE_ID = "ZONE_ID";
        String CURRENCY_CODE = "CURRENCY_CODE";
        String ZONE_TYPE = "ZONE_TYPE";
        String[] HEADERS = {STORE_ID, ZONE_ID, CURRENCY_CODE, ZONE_TYPE};
    }

    static interface PromoExtract {
        String ITEM = "ITEM";
        String TPNC = "TPNC";
        String ZONE_ID = "ZONE_ID";
        String OFFER_ID = "OFFER_ID";
        String OFFER_NAME = "OFFER_NAME";
        String START_DATE = "EFFECTIVE_DATE";
        String END_DATE = "END_DATE";
        String[] HEADERS = {ITEM, TPNC, ZONE_ID, OFFER_ID, OFFER_NAME, START_DATE, END_DATE};
    }

    static interface PromoDescExtract {
        //BUG PS-179header changed to "bpr_tpn"
        String ITEM = "bpr_tpn";
        String ZONE_ID = "promo_zone";
        String OFFER_ID = "offer_id";
        String DESC1 = "desc_1";
        String DESC2 = "desc_2";
		String START_DATE = "start_date";
        String END_DATE="end_date";
        String EFFECTIVE_DATE ="effv_dttm";
        String[] HEADERS = {ITEM, ZONE_ID, OFFER_ID, DESC1, DESC2, START_DATE,END_DATE,EFFECTIVE_DATE};
    }

    /*Added for PS-386 -- Start*/
    static interface RpmClearance_Cre_Mod {
        String REC_DESCRIPTOR = "REC_DESCRIPTOR";
        String LINE_NOR = "LINE_NOR";
        String EVENT_TYPE = "EVENT_TYPE";
        String CLEARANCE_ID = "CLEARANCE_ID";
        String TPNB = "TPNB";
        String TPNC = "TPNC";
        String LOCATION = "LOCATION";
        String LOCATION_TYPE = "LOCATION_TYPE";
        String EFFECTIVE_DATE = "EFFECTIVE_DATE";
        String END_DATE = "END_DATE";
        String SELLING_PRICE = "SELLING_PRICE";
        String SELLING_UOM = "SELLING_UOM";
        String SELLING_CURRENCY = "SELLING_CURRENCY";
        String[] HEADERS = {REC_DESCRIPTOR, LINE_NOR, EVENT_TYPE,CLEARANCE_ID, TPNB, TPNC, LOCATION, LOCATION_TYPE, EFFECTIVE_DATE, END_DATE, SELLING_PRICE, SELLING_UOM, SELLING_CURRENCY};
    }

    static interface RpmClearance_Del {
        String REC_DESCRIPTOR = "REC_DESCRIPTOR";
        String LINE_NOR = "LINE_NOR";
        String CLEARANCE_ID = "CLEARANCE_ID";
        String TPNB = "TPNB";
        String LOCATION = "LOCATION";
        String LOCATION_TYPE = "LOCATION_TYPE";
        String TPNC = "TPNC";
        String[] HEADERS = {REC_DESCRIPTOR, LINE_NOR, CLEARANCE_ID, TPNB, LOCATION, LOCATION_TYPE, TPNC};
    }
    /*Added for PS-386 -- End*/

    static interface RPMZoneHeaders {
        String ZONE_GROUP_ID = "ZONE_GROUP_ID";
        String ZONE_GROUP_NAME = "ZONE_GROUP_NAME";
        String ZONE_GROUP_TYPE = "ZONE_GROUP_TYPE";
        String ZONE_ID = "ZONE_ID";
        String ZONE_NAME = "ZONE_NAME";
        String BASE_IND = "BASE_IND";
        String CURRENCY_CODE = "CURRENCY_CODE";
        String TSL_COUNTRY_CODE = "TSL_COUNTRY_CODE";
		String STORE_IDS = "STORE_IDS";
        String[] HEADERS = {ZONE_GROUP_ID, ZONE_GROUP_NAME, ZONE_GROUP_TYPE, ZONE_ID, ZONE_NAME, BASE_IND, CURRENCY_CODE, TSL_COUNTRY_CODE, STORE_IDS};
    }

	static interface SubGroupDefaultUOMHeaders {
		String SUB_GROUP = "SUB_GROUP";
		String DEFAULT_UOM = "DEFAULT_UOM";
		String CONTENT_UOM = "CONTENT_UOM";
		String CONVERSTION_FACTOR = "CONVERSTION_FACTOR";
		String[] HEADERS = {SUB_GROUP, DEFAULT_UOM, CONTENT_UOM, CONVERSTION_FACTOR};
	}

	static interface ItemDefaultUOMHeaders {
		String TPNB = "TPNB";
		String SELL_BY_TYPE = "SELLBYTYPE";
		String DEFAULT_UOM = "DEFAULTUOM";
		String[] HEADERS = {TPNB, SELL_BY_TYPE, DEFAULT_UOM};
	}

	static interface RPMZoneGroupHeaders {
		String ZONE_GROUP_ID = "ZONE_GROUP_ID";
		String ZONE_GROUP_NAME = "ZONE_GROUP_NAME";
		String ZONE_GROUP_TYPE = "ZONE_GROUP_TYPE";
		String[] HEADERS = {ZONE_GROUP_ID, ZONE_GROUP_NAME, ZONE_GROUP_TYPE};
	}

	static interface EstablishedPriceHeaders {

		String FDETL = "FDETL";
		String LINE_NOR = "LINE_NOR";
		String TPNB = "TPNB";
		String TPNC = "TPNC";
		String ZONE_NODE_TYPE = "ZONE_NODE_TYPE";
		String ZONE_ID = "ZONE_ID";
		String LOCATION = "LOCATION";
		String EFFECTIVE_DATE = "EFFECTIVE_DATE";
		String OUT_OF_STOCK_DATE = "OUT_OF_STOCK_DATE";
		String TSL_ESTABLISHED_PRICE_PH1 = "TSL_ESTABLISHED_PRICE_PH1";
		String P1_START_DATE = "P1_START_DATE";
		String P1_END_DATE = "P1_END_DATE";
		String TSL_ESTABLISHED_PRICE_PH2 = "TSL_ESTABLISHED_PRICE_PH2";
		String P2_START_DATE = "P2_START_DATE";
		String P2_END_DATE = "P2_END_DATE";
		String TSL_ESTABLISHED_PRICE_PH3 = "TSL_ESTABLISHED_PRICE_PH3";
		String P3_START_DATE = "P3_START_DATE";
		String P3_END_DATE = "P3_END_DATE";

		String[] HEADERS = { FDETL, LINE_NOR, TPNB, TPNC, ZONE_NODE_TYPE,
				ZONE_ID, LOCATION, EFFECTIVE_DATE, OUT_OF_STOCK_DATE,
				TSL_ESTABLISHED_PRICE_PH1, P1_START_DATE, P1_END_DATE,
				TSL_ESTABLISHED_PRICE_PH2, P2_START_DATE, P2_END_DATE,
				TSL_ESTABLISHED_PRICE_PH3, P3_START_DATE, P3_END_DATE };
	}

}
