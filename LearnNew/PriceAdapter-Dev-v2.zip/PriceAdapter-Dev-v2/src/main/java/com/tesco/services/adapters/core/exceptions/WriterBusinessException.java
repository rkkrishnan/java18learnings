package com.tesco.services.adapters.core.exceptions;

/**
 * Created by wa68 on 27/06/2016.
 */
@SuppressWarnings("serial")
public class WriterBusinessException extends Exception {

	public WriterBusinessException() {
	}

	public WriterBusinessException(String message) {
		super(message);
	}

	public WriterBusinessException(Throwable cause) {
		super(cause);
	}

	public WriterBusinessException(String message, Throwable cause) {
		super(message, cause);
	}

	public WriterBusinessException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}
}
