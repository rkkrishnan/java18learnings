package com.tesco.services.adapters.rpm.writers;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tesco.promotion.core.PrmPrcChgDtlRef;
import com.tesco.services.core.promotion.PromotionEntity;
import com.tesco.services.exceptions.PromoBusinessException;
import com.tesco.services.repositories.Repository;

import java.util.List;
import java.util.Map;

/**
 * Created by PO47 on 12/07/2016.
 */
public interface PromotionMessageWriter extends Writer {

	public void writePromoEntityFromMessage(
			PromotionEntity promotionEntityForMsg)
			throws PromoBusinessException;

	public Map<String, String> writeProdOfferDoc(PromotionEntity promotionEntity)
			throws PromoBusinessException;

	public String deleteProdOfferDoc(String item, String zoneId,
			String promoCompDisplayId) throws PromoBusinessException;

	public Map<String, Object> deletePromoEntity(PromotionEntity promotionEntityForMsg)
			throws PromoBusinessException;

	public void deleteDetailDisplayMapping(List<String> promoCompDetailIds) throws Exception;

	public PromotionEntity deleteHierarchyDocs(String promoMsgForZoneId,
			String promoCompDisplayId, String hierDockey,
			PrmPrcChgDtlRef prmPrcChgDtlRef) throws Exception;

	public void writeUpdatedThresholdDocumentToCB(PromotionEntity pE)
			throws PromoBusinessException, JsonProcessingException;

	public Map<String, Object> deleteZoneInMasterDocument(String offerId, String locType,
			String locRef, Repository repository)
			throws PromoBusinessException;

	public void deleteMultiBuyLookup(String offerId, String promoCompDetailId,
			Repository repository) throws PromoBusinessException;


}
