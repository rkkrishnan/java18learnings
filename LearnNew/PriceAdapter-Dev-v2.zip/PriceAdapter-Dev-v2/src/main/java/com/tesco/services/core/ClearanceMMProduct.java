package com.tesco.services.core;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import static com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility.ANY;
import static com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility.NONE;

/**
 * Object for MM Clearnce product
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonAutoDetect(fieldVisibility = ANY, getterVisibility = NONE, setterVisibility = NONE)
public class ClearanceMMProduct implements Serializable {
    @JsonProperty
    private String docType;

    @JsonProperty
    private String versionNo;

    @JsonProperty
    private String dateTimeFormat;

    @JsonProperty
    private String currencyFormat;

    @JsonProperty
    private String countryFormat;

    @JsonProperty
    private String productId;

    @JsonProperty
    private String prodType;

    @JsonProperty
    private String sellingUom;

    @JsonProperty
    private Map<String, ClearanceZoneSaleInfo> zonePrices = new HashMap<>();

    @JsonProperty
    private Map<String, ClearanceStoreSaleInfo> storeExceptions = new HashMap<>();

/** This function will return product Id from MM clearance product*/
    public ClearanceMMProduct(String productId) {
        this.productId = productId;
    }
    public ClearanceMMProduct() {

    }



    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        ClearanceMMProduct clearanceProduct = (ClearanceMMProduct) o;

        if ((!docType.equals(clearanceProduct.docType))||
                (!versionNo.equals(clearanceProduct.versionNo))||
                (!dateTimeFormat.equals(clearanceProduct.dateTimeFormat))||
                (!currencyFormat.equals(clearanceProduct.currencyFormat))||
                (!countryFormat.equals(clearanceProduct.countryFormat)) ||
                (!productId.equals(clearanceProduct.productId)) ||
                (!prodType.equals(clearanceProduct.prodType)) ||
                (!sellingUom.equals(clearanceProduct.sellingUom))||
                (!zonePrices.equals(clearanceProduct.zonePrices))||
                (!storeExceptions.equals(clearanceProduct.storeExceptions))
               ){
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int result = docType.hashCode();
        result = 31 * result + versionNo.hashCode();
        result = 31 * result + dateTimeFormat.hashCode();
        result = 31 * result + currencyFormat.hashCode();
        result = 31 * result + countryFormat.hashCode();
        result = 31 * result + productId.hashCode();
        result = 31 * result + prodType.hashCode();
        result = 31 * result + sellingUom.hashCode();
        result = 31 * result + zonePrices.hashCode();
        result = 31 * result + storeExceptions.hashCode();
        return result;
    }

    @Override
    public String toString() {
        return "Product{" +
                "docType='" + docType + '\'' +
                ", versionNo='" + versionNo + '\'' +
                ", dateTimeFormat='" + dateTimeFormat + '\'' +
                ", currencyFormat='" + currencyFormat + '\'' +
                ", countryFormat='" + countryFormat + '\'' +
                ", productId=" + productId +
                ", prodType='" + prodType + '\'' +
                ", sellingUom=" + sellingUom +'\''+
                ", zonePrices :'" + zonePrices + '\''+
                ", storeExceptions :" + storeExceptions +'}';
    }

    public String getDocType() {
        return docType;
    }

    public String getVersionNo() {
        return versionNo;
    }

    public String getDateTimeFormat() {
        return dateTimeFormat;
    }

    public String getCurrencyFormat() {
        return currencyFormat;
    }

    public String getCountryFormat() {
        return countryFormat;
    }

    public String getProductId() {
        return productId;
    }

    public String getProdType() {
        return prodType;
    }

    public String getSellingUom() {
        return sellingUom;
    }

    public Map<String, ClearanceZoneSaleInfo> getZonePrices() {
        return zonePrices;
    }

    public Map<String, ClearanceStoreSaleInfo> getStoreExceptions() {
        return storeExceptions;
    }

    /**
     * Method setDocType
     * @param docType
     */
    public void setDocType(String docType) {
        this.docType = docType;
    }

    /**
     * Method setVersionNo
     * @param versionNo
     */
    public void setVersionNo(String versionNo) {
        this.versionNo = versionNo;
    }

    /**
     * Method setDateTimeFormat
     * @param dateTimeFormat
     */
    public void setDateTimeFormat(String dateTimeFormat) {
        this.dateTimeFormat = dateTimeFormat;
    }

    /**
     * Method setCurrencyFormat
     * @param currencyFormat
     */
    public void setCurrencyFormat(String currencyFormat) {
        this.currencyFormat = currencyFormat;
    }

    /**
     * Method setCountryFormat
     * @param countryFormat
     */
    public void setCountryFormat(String countryFormat) {
        this.countryFormat = countryFormat;
    }

    /**
     * Method setProdType
     * @param prodType
     */
    public void setProdType(String prodType) {
        this.prodType = prodType;
    }

    public void setSellingUom(String sellingUom) {
        this.sellingUom = sellingUom;
    }

    public void addClearanceZoneSaleInfo(ClearanceZoneSaleInfo clearanceZoneSaleInfo) {
        zonePrices.put(clearanceZoneSaleInfo.getClearanceZoneId(), clearanceZoneSaleInfo);
    }

    public void addClearanceStoreSaleInfo(ClearanceStoreSaleInfo clearanceStoreSaleInfo) {
        storeExceptions.put(clearanceStoreSaleInfo.getclearanceStoreId(), clearanceStoreSaleInfo);
    }


    public ClearanceZoneSaleInfo getClearanceZoneSaleInfo(String zoneId) {
        return zonePrices.get(zoneId);
    }
    /** Overloaded function to return zonePrices when queried with zoneId of type int*/
    public ClearanceZoneSaleInfo getClearanceZoneSaleInfo(int zoneId) {
        return zonePrices.get(String.valueOf(zoneId));
    }
    public ClearanceStoreSaleInfo getClearanceStoreSaleInfo(String storeId) {
        return storeExceptions.get(storeId);
    }
}
