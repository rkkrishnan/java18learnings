package com.tesco.services.resources;

import static com.tesco.services.resources.HTTPResponses.notAValidRequest;
import static javax.ws.rs.core.Response.ok;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Semaphore;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.tesco.services.adapters.core.Import;
import org.slf4j.Logger;

import com.tesco.couchbase.AsyncCouchbaseWrapper;
import com.tesco.couchbase.CouchbaseWrapper;
import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.ImportEanJob;
import com.tesco.services.adapters.core.PriceComparatorJob;
import com.tesco.services.exceptions.ImportInProgressException;
import com.tesco.services.exceptions.InvalidClrRunIdentifierException;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;

/**
 * Price checks Resource Gathers KL File information. Queries Product Services
 * for TPNCs Compare KL Price with Price Service Price
 */
@Path("/price/check")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class PriceChecksResource {
	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(PriceChecksResource.class);
	public static Map<String, Semaphore> semaphore = new HashMap<>();

	public static Semaphore getPriceChecksSemaphore(String runIdentifier) {
		return semaphore.get(runIdentifier);
	}

	public static Map<String, String> errorString = new HashMap<>();

	public static String getErrorString(String runIdentifier) {
		return errorString.get(runIdentifier);
	}

	public static void setErrorString(String runIdentifier, String error) {
		errorString.put(runIdentifier, error);
	}

	private Configuration configuration;
	private Import priceComparatorJob;
	private Import importEanJob;

	/**
	 * Constructor PriceChecksResource
	 *
	 * @param configuration
	 * @param importEanJob
	 * @param priceComparatorJob
	 */
	@Inject
	public PriceChecksResource(
			@Named("configuration") Configuration configuration,
			@Named("importEanJob") Import importEanJob,
			@Named("priceComparatorJob") Import priceComparatorJob) {
		this.configuration = configuration;
		this.priceComparatorJob = priceComparatorJob;
		this.importEanJob = importEanJob;
	}

	/**
	 * Response importEan
	 */
	@POST
	@Path("/importEan/{runType}/{fileName}")
	public Response importEan(@PathParam("runType") String runType,
			@PathParam("fileName") String fileName) {
		if (semaphore.get(fileName) == null) {
			semaphore.put(fileName, new Semaphore(1));
		}
		if (!semaphore.get(fileName).tryAcquire()) {
			LOGGER.info("Ean Import already running");
			throw new ImportInProgressException();
		}

		boolean isValidRun = false;

		try {
			String[] teauthRunTypes = configuration.getTeauthRunTypes();
			for (String rtype : teauthRunTypes) {
				if (rtype.equalsIgnoreCase(runType)) {
					isValidRun = true;
				}
			}
			if (isValidRun) {
				Thread thread = new Thread(getImportEanJob(runType, fileName));
				thread.start();
			} else {
				throw new InvalidClrRunIdentifierException(
						"Not a Valid Run Identifier");
			}

		} catch (Exception e) {
			LOGGER.error("error : Ean Import Failed {} {} ", Response
					.serverError().build().getStatusInfo().getStatusCode(),
					Response.serverError().build().getStatusInfo()
							.getReasonPhrase());

			return Response.serverError().build();
		}
		return ok("{\"message\":\"Import Ean Job Started.\"}").build();
	}

	/**
	 * Response priceCompare
	 */
	@POST
	@Path("/comparePrice/{runType}/{fileName}")
	public Response comparePrice(@PathParam("runType") String runType,
			@PathParam("fileName") String fileName) {
		if (semaphore.get(fileName) == null) {
			semaphore.put(fileName, new Semaphore(1));
		}
		if (!semaphore.get(fileName).tryAcquire()) {
			LOGGER.info("Price Comparison already running");
			throw new ImportInProgressException();
		}
		boolean isValidRun = false;
		try {
			String[] teauthRunTypes = configuration.getTeauthRunTypes();
			for (String rtype : teauthRunTypes) {
				if (rtype.equalsIgnoreCase(runType)) {
					isValidRun = true;
				}
			}
			if (isValidRun) {
				Thread thread = new Thread(
						getPriceComparatorJob(runType, fileName));
				thread.start();
			} else {
				throw new InvalidClrRunIdentifierException(
						"Not a Valid Run Identifier");
			}

		} catch (InvalidClrRunIdentifierException e) {
			getPriceChecksSemaphore(fileName).release();
			LOGGER.error(
					"error : Price checks failed due to Invalid Run Type - {} {}",
					notAValidRequest().getStatusInfo().getStatusCode(),
					notAValidRequest().getStatusInfo().getReasonPhrase());
			return notAValidRequest();
		} catch (Exception e) {
			LOGGER.error("error : Price checks Failed {} {} ", Response
					.serverError().build().getStatusInfo().getStatusCode(),
					Response.serverError().build().getStatusInfo()
							.getReasonPhrase());

			return Response.serverError().build();
		}
		return ok("{\"message\":\"Price Comparison Job Started.\"}").build();
	}

	@GET
	@Path("/checksInProgress/{fileName}")
	public Response isChecksInProgressForFilename(
			@PathParam("fileName") String fileName) {

		if (semaphore.get(fileName).availablePermits() < 1) {
			return Response.ok("{\"import\":\"progress\"}").build();
		} else if (getErrorString(fileName) != null) {
			return Response.ok(
					String.format(
							"{\"import\":\"aborted\",\n \"error\":\"%s\"}",
							getErrorString(fileName))).build();
		} else {
			return Response.ok("{\"import\":\"completed\"}").build();
		}
	}

	public Import getImportEanJob(String runType, String fileName) {
		((ImportEanJob)importEanJob).setRunType(runType);
		((ImportEanJob)importEanJob).setFileName(fileName);
		return importEanJob;
	}

	public Import getPriceComparatorJob(String runType, String fileName) {
		((PriceComparatorJob)priceComparatorJob).setRunType(runType);
		((PriceComparatorJob)priceComparatorJob).setFileName(fileName);
		return priceComparatorJob;
	}
}