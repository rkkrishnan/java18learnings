package com.tesco.services.adapters.core;

import com.tesco.services.Configuration;
import com.tesco.services.adapters.rpm.writers.Writer;
import com.tesco.services.resources.TeauthPriceChecksResource;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;

/**
 * Created by QU17 on 18/03/2015.
 */
public class ImportEanJob implements Import {


    private static final Logger LOGGER = (Logger) LoggerFactoryWrapper.getLogger(ImportEanJob.class);

    private Configuration configuration;
    private String fileName;
    private String runType;
    private Writer eanSeedingWriter;

    /**
     * @param configuration
     * @param eanSeedingWriter
     */
    @Inject
    public ImportEanJob(@Named("configuration") Configuration configuration,
            @Named("eanSeedingWriter") Writer eanSeedingWriter) {

        this.configuration = configuration;
        this.eanSeedingWriter = eanSeedingWriter;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getRunType() {
        return runType;
    }

    public void setRunType(String runType) {
        this.runType = runType;
    }

    @Override
    public void run() {
            LOGGER.info("Firing up EAN imports...");
            startImportProcess();
    }

    /**
     *  Method :startImportProcess() - Identifies the file based on file name and reads the file
     */
    public void startImportProcess() {
        LOGGER.info("Importing data from TEAUTH File {}....",fileName);
        String filePath = configuration.getTeauthFilePath()+"/"+runType+"/"+fileName;

        LOGGER.info("Seeding data for EAN-TPNC combination from {} ",
                configuration.getTeauthFilePath());
        try {
            eanSeedingWriter.write(filePath);
            LOGGER.info("Successfully completed EAN import job...");
        } catch (Exception e) {
            LOGGER.error("Error occured in importing EAN data.",e);
            TeauthPriceChecksResource.setErrorString(fileName, "error importing EAN data");
        } finally{
            TeauthPriceChecksResource.getPriceChecksSemaphore(fileName).release();
        }
    }
}
