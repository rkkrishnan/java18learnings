package com.tesco.services.adapters.rpm.writers.impl;

import com.google.common.base.Optional;
import com.tesco.services.adapters.rpm.writers.CSVHeaders;
import com.tesco.services.core.Store;
import com.tesco.services.exceptions.DataAccessException;
import com.tesco.services.repositories.Repository;
import com.tesco.services.utility.PriceConstants;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.Map;

/**
 * Creates the data for the stores available in store_zone csv.
 */
public class StoreMapper {
	public static final int PRICE_ZONE_TYPE = 1;
	public static final int PROMO_ZONE_TYPE = 2;
	public static final int CLEARANCE_ZONE_TYPE = 3;

	private Repository repository;

	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger("StoreMapper");

	@Inject
	public StoreMapper(@Named("repository") Repository repository) {
		this.repository = repository;
	}

	/**
	 * <p>
	 * To Get the zone id based on the zone type
	 * </p>
	 * 
	 * @param storeInfoMap
	 * @return
	 */
	public Store map(Map<String, String> storeInfoMap) {
		String storeId = storeInfoMap.get(CSVHeaders.StoreZone.STORE_ID);
		Store store = null;
		try {
			store = (Store) repository.getGenericObject(PriceConstants.STORE_KEY+String.valueOf(storeId),Store.class);
		} catch (DataAccessException e) {
			LOGGER.error(
					"Error occurred while getting store for key: " + storeId);
		}
		if(store == null) {
			store = new Store(storeId, storeInfoMap
					.get(CSVHeaders.StoreZone.CURRENCY_CODE), "");
		}
		int zoneId = Integer.parseInt(storeInfoMap
				.get(CSVHeaders.StoreZone.ZONE_ID));
		int zoneType = Integer.parseInt(storeInfoMap
				.get(CSVHeaders.StoreZone.ZONE_TYPE));

		if (zoneType == PRICE_ZONE_TYPE) {
			store.setPriceZoneId(Optional.of(zoneId));
		}
		if (zoneType == PROMO_ZONE_TYPE) {
			store.setPromoZoneId(Optional.of(zoneId));
		}
		if (zoneType == CLEARANCE_ZONE_TYPE) {
			store.setClearanceZoneId(Optional.of(zoneId));
		}
		return store;
	}

	/**
	 * @param storeInfoMap
	 * @return
	 */
	public Store mapStore(final Map<String, String> storeInfoMap) {
		final String storeId = storeInfoMap.get(CSVHeaders.StoreZone.STORE_ID);
		Store storeToBeInserted = null;

		try {
			storeToBeInserted = (Store) repository.getGenericObject(PriceConstants.STORE_KEY+String.valueOf(storeId), Store.class);
		} catch (DataAccessException e) {
			LOGGER.error(
					"Error occurred while getting store for key: " + storeId);
		}

		if (storeToBeInserted == null) {
			storeToBeInserted = new Store(storeId,
					storeInfoMap.get(CSVHeaders.StoreZone.CURRENCY_CODE), "");
			int zoneId = Integer.parseInt(storeInfoMap
					.get(CSVHeaders.StoreZone.ZONE_ID));
			int zoneType = Integer.parseInt(storeInfoMap
					.get(CSVHeaders.StoreZone.ZONE_TYPE));

			if (zoneType == PRICE_ZONE_TYPE) {
				storeToBeInserted.setPriceZoneId(Optional.of(zoneId));
			}
			if (zoneType == PROMO_ZONE_TYPE) {
				storeToBeInserted.setPromoZoneId(Optional.of(zoneId));
			}
			if (zoneType == CLEARANCE_ZONE_TYPE) {
				storeToBeInserted.setClearanceZoneId(Optional.of(zoneId));
			}
		} else {
			int zoneId = Integer.parseInt(storeInfoMap
					.get(CSVHeaders.StoreZone.ZONE_ID));
			int zoneType = Integer.parseInt(storeInfoMap
					.get(CSVHeaders.StoreZone.ZONE_TYPE));

			if (zoneType == PRICE_ZONE_TYPE) {
				storeToBeInserted.setPriceZoneId(Optional.of(zoneId));
			}
			if (zoneType == PROMO_ZONE_TYPE) {
				storeToBeInserted.setPromoZoneId(Optional.of(zoneId));
			}
			if (zoneType == CLEARANCE_ZONE_TYPE) {
				storeToBeInserted.setClearanceZoneId(Optional.of(zoneId));
			}
		}
		return storeToBeInserted;
	}
}
