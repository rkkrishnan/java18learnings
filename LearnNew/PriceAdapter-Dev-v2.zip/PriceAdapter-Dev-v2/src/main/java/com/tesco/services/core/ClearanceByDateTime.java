package com.tesco.services.core;

import static com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility.ANY;
import static com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility.NONE;
import io.swagger.annotations.ApiModel;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;


@SuppressWarnings("serial")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonAutoDetect(fieldVisibility = ANY, getterVisibility = NONE, setterVisibility = NONE)
@ApiModel(value = "A Clearance is special pricing for a product")
public class ClearanceByDateTime implements Serializable {

    @JsonProperty
    private String effvDateTime;

    @JsonProperty
    private String endDateTime;

    @JsonProperty
    private String clearanceRef;

    @JsonProperty
    private String clearancePrice;

	@JsonProperty("prevPrice")
	public List<EstablishedPriceInfo> establishedPriceInfos;

    //Method to get EffectiveDateTime
    public String getEffvDateTime() {
        return effvDateTime;
    }

    /**
     * Method setEffvDateTime
     * @param effvDateTime
     */
    public void setEffvDateTime(String effvDateTime) {
        this.effvDateTime = effvDateTime;
    }

    //Method getEndDateTime
    public String getEndDateTime() {
        return endDateTime;
    }
    //Method setEndDateTime
    public void setEndDateTime(String endDateTime) {
        this.endDateTime = endDateTime;
    }

    public String getClearanceRef() {
        return clearanceRef;
    }

    public void setClearanceRef(String clearanceRef) {
        this.clearanceRef = clearanceRef;
    }

    public String getClearancePrice() {
        return clearancePrice;
    }

    public void setClearancePrice(String clearancePrice) {
        this.clearancePrice = clearancePrice;
    }

	public List<EstablishedPriceInfo> getEstablishedPriceInfos() {
		return establishedPriceInfos;
	}

	public void setEstablishedPriceInfos(
			List<EstablishedPriceInfo> establishedPriceInfos) {
		this.establishedPriceInfos = establishedPriceInfos;
	}

	public void setEstablishedPriceInfo(EstablishedPriceInfo establishedPriceInfo){
		this.establishedPriceInfos.add(establishedPriceInfo);
	}

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }

        ClearanceByDateTime clearanceByDateTime = (ClearanceByDateTime) o;


        if (effvDateTime != null ? !effvDateTime.equals(clearanceByDateTime.effvDateTime) : clearanceByDateTime.effvDateTime != null){
            return false;
        }
        if (endDateTime != null ? !endDateTime.equals(clearanceByDateTime.endDateTime) : clearanceByDateTime.endDateTime != null){
            return false;
        }
        if (clearanceRef != null ? !clearanceRef.equals(clearanceByDateTime.clearanceRef) : clearanceByDateTime.clearanceRef != null){
            return false;
        }
        if (clearancePrice != null ? !clearancePrice.equals(clearanceByDateTime.clearancePrice) : clearanceByDateTime.clearancePrice != null){
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int result = effvDateTime != null ? effvDateTime.hashCode() : 0;
        result = 31 * result + (endDateTime != null ? endDateTime.hashCode() : 0);
        result = 31 * result + (clearanceRef != null ? clearanceRef.hashCode() : 0);
        result = 31 * result + (clearancePrice != null ? clearancePrice.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "ClearancePriceByDateTime{" +
                "effvDateTime='" + effvDateTime + '\'' +
                ", endDateTime='" + endDateTime + '\'' +
                ", clearanceRef='" + clearanceRef + '\'' +
                ", clearancePrice='" + clearancePrice + '\'' +
                '}';
    }
}
