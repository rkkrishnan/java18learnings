package com.tesco.services.adapters.promotion.impl;

import com.tesco.promotion.core.PrmPrcChgDtl;
import com.tesco.promotion.core.PrmPrcChgDtlRef;
import com.tesco.promotion.core.PrmPrcChgThr;
import com.tesco.promotion.core.PrmPrcChgThrDtl;
import com.tesco.services.Configuration;
import com.tesco.services.adapters.promotion.PromotionHandler;
import com.tesco.services.adapters.rpm.writers.PromotionMessageWriter;
import com.tesco.services.core.ZoneEntity;
import com.tesco.services.core.promotion.*;
import com.tesco.services.exceptions.DataAccessException;
import com.tesco.services.exceptions.ProductEncodeException;
import com.tesco.services.exceptions.PromoBusinessException;
import com.tesco.services.repositories.Repository;
import com.tesco.services.repositories.RepositoryImpl;
import com.tesco.services.utility.*;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;
import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.joda.time.DateTime;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.tesco.services.utility.PriceConstants.*;
import static org.apache.commons.lang.StringUtils.isNumeric;

/**
 * Created by qu17 on 5/26/2015.
 */
public class ThresholdPromotionHandler implements PromotionHandler {
	private Repository repository;
	private PromotionMessageWriter promotionWriter;
	private Configuration configuration;
	private static PromotionJmsLog PROMOMSGCOUNTER = PromotionJmsLogImpl
			.getInstance();

	@Inject
	public ThresholdPromotionHandler(
			@Named("repository") Repository repository,
			@Named("promotionWriter") PromotionMessageWriter promotionWriter,
			@Named("configuration") Configuration configuration)
			throws PromoBusinessException {
		this.repository = repository;
		this.promotionWriter = promotionWriter;
		this.configuration = configuration;
	}

	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(ThresholdPromotionHandler.class);

	@Override
	public Map<String, Object> processCreMessage(
			PromotionEntity promotionEntity, List<PrmPrcChgDtl> prmPrcChgDtls,
			String promoMsgForZoneId, String msgState, String msgOfferType,
			String promoMsgLocType) throws PromoBusinessException {
		Map<String, PromotionEntity> promotionEntityMap = new HashMap<>();
		Map<String, Object> allEventsDataMap = new HashMap<>();
		Map<String, Object> promotionCreatedMap = new HashMap<>();

		try {
			for (PrmPrcChgDtl prmPrcChgDtl : prmPrcChgDtls) {
				createEntity(prmPrcChgDtl, promoMsgForZoneId, msgState,
						msgOfferType, promoMsgLocType, promotionEntityMap);
			}

			for (String offerId : promotionEntityMap.keySet()) {
				PromotionEntity pE = promotionEntityMap.get(offerId);
				if (!Dockyard.isSpaceOrNull(pE)) {
					String eventType = verifyPromotionOrLocationExist(pE);
					this.promotionWriter.writePromoEntityFromMessage(pE);

					/**
					 * Creating new ProdOffer Doc to support the Future dated
					 * promotions in PriceService
					 */
					Map<String, String> newProductData = promotionWriter
							.writeProdOfferDoc(pE);
					promotionCreatedMap = CommonEventPublishingUtility
							.preparePromotionCreatedEventDataMap(pE, eventType,
									newProductData);

				}
			}

		} catch (Exception e) {
			throw new PromoBusinessException(e.getMessage(), e);
		}
		allEventsDataMap.put(
				PROMOTION_CREATED_LOCATION_ADDED_PRODUCT_ADDED_KEY,
				promotionCreatedMap);
		return allEventsDataMap;

	}

	private String getCurrencyForLoc(String zoneId) throws DataAccessException {
		String currency = null;
		ZoneEntity zoneEntity = (ZoneEntity) repository
				.getGenericObject(PriceConstants.ZONE_ENTITY_KEY + zoneId,
						ZoneEntity.class);
		if (zoneEntity != null) {
			currency = zoneEntity.getCurrencyCode();
		}
		return currency;
	}

	private void mapPromoCompDisplayIdToPromoCompDtlId(
			String promoCompDisplayId, String promoCompDtlId)
			throws PromoBusinessException {
		try {
			repository.insertObject(PriceConstants.PROMO_DETAIL_ID_KEY
					+ promoCompDtlId, promoCompDisplayId);
			PROMOMSGCOUNTER.updateCounterForCreMsg(PROMOTION_LOOKUP_DOCUMENT);
		} catch (Exception e) {

			LOGGER.error("Look up document couldn't be inserted for threshold promotion due to DB error for detailId: "
					+ promoCompDtlId);
			throw new PromoBusinessException(e.getMessage(), e);
		}
	}

	@Override
	public Map<String, Object> processDelMessage(
			List<PrmPrcChgDtlRef> prmPrcChgDtlRefs, String promoMsgForZoneId)
			throws PromoBusinessException {

		List<PromoItemListEntity> promoItemListEntities;
		List<PromoItemEntity> promoItemEntityList;
		Map<String, PromotionEntity> promotionEntityMap = new HashMap<>();
		List<String> delDetailIdList = new ArrayList<>();
		Map<String, Object> promotionEventDataMap = null;
		String effectiveDate = "";
		Map<String, String> promotionEffectiveDateMap = new HashMap<String, String>();
		List<PromoItemEntity> listOfDeletedPromotionItemEntities = new ArrayList<>();
		for (PrmPrcChgDtlRef prmPrcChgDtlRef : prmPrcChgDtlRefs) {
			String promoCompDtlId = prmPrcChgDtlRef.getPromoCompDetailId()
					.toString();
			String section = prmPrcChgDtlRef.getPrmPrcChgThrDtlRef().getDept() != null ? prmPrcChgDtlRef
					.getPrmPrcChgThrDtlRef().getDept().toString()
					: null;

			String classs = prmPrcChgDtlRef.getPrmPrcChgThrDtlRef().getClazz() != null ? prmPrcChgDtlRef
					.getPrmPrcChgThrDtlRef().getClazz().toString()
					: null;
			String subclass = prmPrcChgDtlRef.getPrmPrcChgThrDtlRef()
					.getSubclass() != null ? prmPrcChgDtlRef
					.getPrmPrcChgThrDtlRef().getSubclass().toString() : null;
			String merchType = prmPrcChgDtlRef.getPrmPrcChgThrDtlRef()
					.getMerchType().toString();
			String promoCompDisplayId = repository
					.getMappedData(PriceConstants.PROMO_DETAIL_ID_KEY
							+ promoCompDtlId);
			if (!("0").equals(merchType)) {
				try {
					delDetailIdList.add(promoCompDtlId);

					String hierDockey = PriceConstants.HIERARCHY_PROMO_PREFIX
							.concat(PriceUtility.convertRMStoTesco(section,
									classs, subclass));

					PromotionEntity promotionToBeDeleted = null;

					promotionToBeDeleted = promotionWriter.deleteHierarchyDocs(
							promoMsgForZoneId, promoCompDisplayId, hierDockey,
							prmPrcChgDtlRef);

					promotionEntityMap.put(promoCompDisplayId,
							promotionToBeDeleted);

				} catch (ProductEncodeException pe) {
					throw new PromoBusinessException(
							"Error while converting the hierarchy from RMS to Tesco"
									+ pe.getMessage());
				} catch (Exception e) {
					throw new PromoBusinessException(e.getMessage(), e);
				}
			} else {
				if (!Dockyard.isSpaceOrNull(promoCompDisplayId)) {
					delDetailIdList.add(promoCompDtlId);
					PromotionEntity promotionEntityToBeDeleted;
					promotionEntityToBeDeleted = promotionEntityMap
							.get(promoCompDisplayId);
					if (Dockyard.isSpaceOrNull(promotionEntityToBeDeleted)) {
						try {
							promotionEntityToBeDeleted = (PromotionEntity) repository
									.getGenericObject(
											PriceConstants.PROMOTION_DOC_KEY_PREFIX
													+ promoCompDisplayId
													+ "_"
													+ promoMsgForZoneId,
											PromotionEntity.class);
						} catch (DataAccessException e) {
							throw new PromoBusinessException(e.getMessage(), e);
						}
					}
					if (!Dockyard.isSpaceOrNull(promotionEntityToBeDeleted)) {
						String itemFromDelMsg = prmPrcChgDtlRef
								.getPrmPrcChgThrDtlRef().getItem().toString();
						itemFromDelMsg = itemFromDelMsg.startsWith("0") ? itemFromDelMsg
								: "0" + itemFromDelMsg; /*
														 * this line should be
														 * removed
														 */
						promoItemListEntities = promotionEntityToBeDeleted
								.getPromoItemListEntities();
						promoItemEntityList = promoItemListEntities.get(0)
								.getPromoItems();
						int indexOfItemEntityToBeRemoved = -1;
						boolean isItemEntityExist = false;
						for (PromoItemEntity promoItemEntity : promoItemEntityList) {
							indexOfItemEntityToBeRemoved++;
							if (promoItemEntity.getItemRef().equals(
									itemFromDelMsg)
									&& promoItemEntity
											.getRpmPromoCompDetailId().equals(
													promoCompDtlId)) {
								isItemEntityExist = true;
								promotionEntityToBeDeleted.lastUpdateDate = Dockyard
										.getSysDate(PriceConstants.ISO_8601_FORMAT);
								listOfDeletedPromotionItemEntities
										.add(promoItemEntity);
								break;
							}
						}
						if (isItemEntityExist) {
							promoItemEntityList
									.remove(indexOfItemEntityToBeRemoved);
						} else {
							LOGGER.info(
									"Item Entity for Item {} from Del Msg not present in {}",
									itemFromDelMsg,
									PriceConstants.PROMOTION_DOC_KEY_PREFIX
											+ promoCompDisplayId + "_"
											+ promoMsgForZoneId);
						}
						promotionEntityMap.put(promoCompDisplayId,
								promotionEntityToBeDeleted);

						/**
						 * Deleting ProdOffer Doc which are processed in DEL
						 * message
						 */
						if (isNumeric(itemFromDelMsg)) {
							promotionWriter.deleteProdOfferDoc(itemFromDelMsg,
									promoMsgForZoneId, promoCompDisplayId);
						}

					} else {
						LOGGER.info("Document {} not found",
								PriceConstants.PROMOTION_DOC_KEY_PREFIX
										+ promoCompDisplayId + "_"
										+ promoMsgForZoneId);
					}

				} else {
					LOGGER.info(
							"Mapping Promo Comp Display Id not found for Promo Comp Detail ID {}",
							promoCompDtlId);
				}
			}
			try {
				for (String offerId : promotionEntityMap.keySet()) {
					PromotionEntity pE = promotionEntityMap.get(offerId);
					if (pE.getPromoItemListEntities().get(0).getPromoItems()
							.isEmpty()) {
						promotionEventDataMap = promotionWriter
								.deletePromoEntity(pE);
						CommonEventPublishingUtility
								.preparePromoProductRemvoedArgumentDataForEmptyItemList(
										promotionEventDataMap,
										promotionEffectiveDateMap, offerId);
					} else {
						this.promotionWriter
								.writeUpdatedThresholdDocumentToCB(pE);
						promotionEventDataMap = new HashMap<String, Object>();
						Map<String, Object> promotionDataMap = CommonEventPublishingUtility
								.preparePromoProductRemvoedArgumentData(
										listOfDeletedPromotionItemEntities,
										offerId, pE);
						promotionEventDataMap.put(
								PROMOTION_PRODUCT_REMOVED_EVENT_TYPE,
								promotionDataMap);
					}
				}
				/*
				 * Delete all the detail-id look-up documents which has come for
				 * delete
				 */
				this.promotionWriter
						.deleteDetailDisplayMapping(delDetailIdList);

			} catch (Exception e) {
				throw new PromoBusinessException(e.getMessage(), e);
			}
		}
		return promotionEventDataMap;
	}

	@Override
	public Map<String, Object> processModMessage(
			PromotionEntity promotionEntity, List<PrmPrcChgDtl> prmPrcChgDtls,
			String promoMsgForZoneId, String msgState, String msgOfferType,
			String promoMsgLocType) throws PromoBusinessException {
		Map<String, Object> allEventsDataMap = new HashMap<>();
		Map<String, Object> promotionCreatedMap = new HashMap<>();
		Map<String, Object> promotionDetailsChangedOfferLevelEventMap = new HashMap<>();
		Map<String, Object> promotionDetailsChangedProductLevelEventMap = new HashMap<>();
		Map<String, Object> promotionEndDateChangedMapData = new HashMap<>();
		Map<String, Object> promotionEndDateEventMapData = new HashMap<>();

		PromotionEntity existingPromotionEntity;

		Map<String, DateTime> leastEffectiveDateMap = new HashMap<>();
		Map<String, PromotionEntity> promotionEntityMap = new HashMap<>();
		List<PromoItemListEntity> promoItemListEntities;
		List<PromoItemEntity> promoItemEntities;
		SimpleDateFormat dateFormat = new SimpleDateFormat(
				PriceConstants.DATE_FORMAT_FOR_PROMOTION_END_DATE);
		String effectiveDate = null;
		String endDate = null;
		Calendar cal = Calendar.getInstance();
		Date sysDate = cal.getTime();
		Date incrementDateByOne = DateUtils.addDays(sysDate,
				configuration.getDaysToEndThresholdPromo());
		String formatDate = dateFormat.format(incrementDateByOne);
		String endDateThreshold = formatDate
				.concat(PriceConstants.APPEND_HOURS_MIN_SEC_TO_END_DATE);

		boolean isEndDateChaged = false;
		try {
			existingPromotionEntity = promotionEntity.deepCopy();
		} catch (Exception e) {
			throw new PromoBusinessException(e.getMessage(), e);
		}

		try {

			promoItemEntities = promotionEntity.getPromoItemListEntities()
					.get(0).getPromoItems();
			promoItemListEntities = promotionEntity.getPromoItemListEntities();
			List<String> compDtlIdList = new ArrayList<String>();
			for (PromoItemEntity promoItemEntity : promoItemEntities) {
				compDtlIdList.add(promoItemEntity.getRpmPromoCompDetailId()
						.toString());
			}
			for (PrmPrcChgDtl prmPrcChgDtl : prmPrcChgDtls) {
				String dtlIdFromXml = prmPrcChgDtl.getPromoCompDetailId()
						.toString();
				String state = prmPrcChgDtl.getTslState();

				effectiveDate = getDate(prmPrcChgDtl.getStartDate().getYear()
						.toString(), prmPrcChgDtl.getStartDate().getMonth()
						.toString(), prmPrcChgDtl.getStartDate().getDay()
						.toString(), prmPrcChgDtl.getStartDate().getHour()
						.toString(), prmPrcChgDtl.getStartDate().getMinute()
						.toString(), prmPrcChgDtl.getStartDate().getSecond()
						.toString());
				String offerId = promotionEntity.getOfferRef();
				CommonEventPublishingUtility.addOnlyLeastEffectiveDate(
						leastEffectiveDateMap, effectiveDate, offerId);
				endDate = getDate(prmPrcChgDtl.getEndDate().getYear()
						.toString(), prmPrcChgDtl.getEndDate().getMonth()
						.toString(), prmPrcChgDtl.getEndDate().getDay()
						.toString(), prmPrcChgDtl.getEndDate().getHour()
						.toString(), prmPrcChgDtl.getEndDate().getMinute()
						.toString(), prmPrcChgDtl.getEndDate().getSecond()
						.toString());

				/** This case is for item addition -active and approved. */
				if (state
						.equalsIgnoreCase(PriceConstants.PROMO_MSG_RAW_NEW_STATE)
						&& !compDtlIdList.contains(dtlIdFromXml)) {
					promotionEntity.lastUpdateDate = Dockyard
							.getSysDate(PriceConstants.ISO_8601_FORMAT);
					PrmPrcChgThr prmPrcChgThr = prmPrcChgDtl.getPrmPrcChgThr();

					PromoItemEntity promoItemEntity = new PromoItemEntity();
					promoItemEntity.effectiveDate = effectiveDate;
					promoItemEntity.endDate = endDate;
					if (!("0").equals(prmPrcChgDtl.getPrmPrcChgThr()
							.getMerchType().toString())) {

						if (!Dockyard.isSpaceOrNull(prmPrcChgDtl
								.getPrmPrcChgThr().getDept())
								&& !Dockyard.isSpaceOrNull(prmPrcChgDtl
										.getPrmPrcChgThr().getClazz())
								&& !Dockyard.isSpaceOrNull(prmPrcChgDtl
										.getPrmPrcChgThr().getSubclass())) {
							promoItemEntity.itemType = PriceConstants.SUBCLASS_STR;

							promoItemEntity.itemRef = PriceUtility
									.convertRMStoTesco(prmPrcChgThr.getDept()
											.toString(), prmPrcChgThr
											.getClazz().toString(),
											prmPrcChgThr.getSubclass()
													.toString());

						} else if (!Dockyard.isSpaceOrNull(prmPrcChgDtl
								.getPrmPrcChgThr().getDept())
								&& !Dockyard.isSpaceOrNull(prmPrcChgDtl
										.getPrmPrcChgThr().getClazz())
								&& Dockyard.isSpaceOrNull(prmPrcChgDtl
										.getPrmPrcChgThr().getSubclass())) {
							promoItemEntity.itemType = PriceConstants.CLASS_STR;
							promoItemEntity.itemRef = PriceUtility
									.convertRMStoTesco(prmPrcChgThr.getDept()
											.toString(), prmPrcChgThr
											.getClazz().toString(), null);
						} else if (!Dockyard.isSpaceOrNull(prmPrcChgDtl
								.getPrmPrcChgThr().getDept())
								&& Dockyard.isSpaceOrNull(prmPrcChgDtl
										.getPrmPrcChgThr().getClazz())
								&& Dockyard.isSpaceOrNull(prmPrcChgDtl
										.getPrmPrcChgThr().getSubclass())) {
							promoItemEntity.itemType = PriceConstants.SECTION_STR;
							promoItemEntity.itemRef = PriceUtility
									.convertRMStoTesco(prmPrcChgThr.getDept()
											.toString(), null, null);
						}

					} else {
						promoItemEntity.itemType = PriceConstants.PROMO_ITEM_TYPE;
						promoItemEntity.itemRef = prmPrcChgThr.getItem();
					}
					promoItemEntity.setWasPrice(null);
					promoItemEntity.setWasWasPrice(null);

					if (prmPrcChgThr.getTslPosLabelReqInd() != null) {
						if (PriceConstants.POS_LABEL_ONE.equals(prmPrcChgThr
								.getTslPosLabelReqInd().toString())) {
							promoItemEntity
									.setPosLabelReqInd(PriceConstants.POS_LABEL_Y);
						} else {
							promoItemEntity
									.setPosLabelReqInd(PriceConstants.POS_LABEL_N);
						}
					} else {
						promoItemEntity
								.setPosLabelReqInd(PriceConstants.POS_LABEL_N);
					}
					if (prmPrcChgDtl.getPromoCompDetailId() != null) {
						promoItemEntity.setRpmPromoCompDetailId(prmPrcChgDtl
								.getPromoCompDetailId().toString());
					}
					promoItemEntities.add(promoItemEntity);
					promotionEntity
							.setPromoItemListEntities(promoItemListEntities);
					promotionEntityMap.put(promotionEntity.getOfferRef(),
							promotionEntity);
					mapPromoCompDisplayIdToPromoCompDtlId(
							prmPrcChgDtl.getTslPromoCompDisplayId(),
							prmPrcChgDtl.getPromoCompDetailId().toString());

					/**
					 * This case is for active item cancellation-Change only the
					 * item end date.
					 */
				} else if (state
						.equalsIgnoreCase(PriceConstants.PROMO_MSG_RAW_CANCELLED_STATE)
						&& compDtlIdList.contains(dtlIdFromXml)) {
					promotionEntity.lastUpdateDate = Dockyard
							.getSysDate(PriceConstants.ISO_8601_FORMAT);

					for (PromoItemListEntity promoItemListEntity : promotionEntity
							.getPromoItemListEntities()) {
						if (promoItemListEntity.getPromoItems() != null) {
							for (PromoItemEntity promoItemEntity : promoItemListEntity
									.getPromoItems()) {
								if (promoItemEntity.getRpmPromoCompDetailId()
										.equals(dtlIdFromXml)) {
									promoItemEntity
											.setEndDate(endDateThreshold);
									if (!isEndDateChaged) {
										isEndDateChaged = true;
										promotionEndDateChangedMapData.put(
												OFFER_ID,
												promotionEntity.getOfferRef());
										promotionEndDateChangedMapData.put(
												END_DATE,
												promoItemEntity.getEndDate());
										promotionEndDateChangedMapData.put(
												PROD_REF,
												TPNB_IDENTIFIER
														+ ":"
														+ promoItemEntity
																.getItemRef());
										promotionEndDateEventMapData.put(
												promotionEntity.getOfferRef(),
												promotionEndDateChangedMapData);
									}
									break;
								}
							}
						}
					}
					promotionEntityMap.put(promotionEntity.getOfferRef(),
							promotionEntity);

				} else if ((state
						.equalsIgnoreCase(PriceConstants.PROMO_MSG_RAW_NEW_STATE)
						|| state.equalsIgnoreCase(PriceConstants.PROMO_MSG_APPROVED_STATE) || state
							.equalsIgnoreCase(PriceConstants.PROMO_MSG_RAW_REAPPROVED_STATE))
						&& compDtlIdList.contains(dtlIdFromXml)) {
					String createdDateFromPrev = promotionEntity.createdDate;
					createEntity(prmPrcChgDtl, promoMsgForZoneId, msgState,
							msgOfferType, promoMsgLocType, promotionEntityMap);
					promotionEntityMap.get(promotionEntity.getOfferRef()).createdDate = createdDateFromPrev;

				}
			}
			allEventsDataMap.put(PROMOTION_ENDDATE_CHANGED,
					promotionEndDateEventMapData);

			for (String offerId : promotionEntityMap.keySet()) {
				PromotionEntity pE = promotionEntityMap.get(offerId);

				if (!Dockyard.isSpaceOrNull(pE)) {

					/*
					 * PRIS-2010 Get cfDescription1 , cfDescription2 from
					 * existing promotion
					 */
					pE.setCfDescription1(promotionEntity.getCfDescription1());
					pE.setCfDescription2(promotionEntity.getCfDescription2());

					String eventType = verifyPromotionOrLocationExist(pE);
					this.promotionWriter.writePromoEntityFromMessage(pE);

					Map<String, Object> argumentData = CommonEventPublishingUtility
							.preparePromoDetailsChangedOffLevelArgumentData(
									existingPromotionEntity,
									leastEffectiveDateMap, offerId, pE);
					promotionDetailsChangedOfferLevelEventMap.put(offerId,
							argumentData);

					/**
					 * Creating new ProdOffer Doc to support the Future dated
					 * promotions in PriceService
					 */
					Map<String, String> newProductData = promotionWriter
							.writeProdOfferDoc(pE);
					promotionCreatedMap = CommonEventPublishingUtility
							.preparePromotionCreatedEventDataMap(pE, eventType,
									newProductData);
					Map<Object, Object> argumentDataPrdLevel = CommonEventPublishingUtility
							.preparePromoDetailsChangedProductLevelArgumentData(
									existingPromotionEntity, offerId, pE);
					promotionDetailsChangedProductLevelEventMap.put(offerId,
							argumentDataPrdLevel);
				}
			}

		} catch (Exception e) {
			throw new PromoBusinessException(e.getMessage(), e);
		}
		allEventsDataMap.put(PROMOTION_DETAILS_CHANGED_OFFER_LEVEL_KEY,
				promotionDetailsChangedOfferLevelEventMap);
		allEventsDataMap.put(PROMOTION_DETAILS_CHANGED_PRODUCT_LEVEL_KEY,
				promotionDetailsChangedProductLevelEventMap);
		allEventsDataMap.put(
				PROMOTION_CREATED_LOCATION_ADDED_PRODUCT_ADDED_KEY,
				promotionCreatedMap);
		return allEventsDataMap;
	}

	public String getDate(String year, String month, String day, String hrs,
			String mins, String secs) {
		String parsedDay = day.length() == 1 ? "0" + day : day;
		String parsedMonth = month.length() == 1 ? "0" + month : month;
		String parsedHrs = hrs.length() == 1 ? "0" + hrs : hrs;
		String parsedMins = mins.length() == 1 ? "0" + mins : mins;
		String parsedSecs = secs.length() == 1 ? "0" + secs : secs;

		String date = year + parsedMonth + parsedDay + parsedHrs + parsedMins
				+ parsedSecs;
		try {
			date = Dockyard.getFormattedDate(date,
					PriceConstants.PROMO_MSG_DATE_FORMAT,
					PriceConstants.ISO_8601_FORMAT);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date;
	}

	private int[] setThrRewardRefs(int size) {
		int[] refs = {};
		for (int i = 0; i < size; i++) {
			refs = ArrayUtils.add(refs, i);
		}
		return refs;
	}

	private void createEntity(PrmPrcChgDtl prmPrcChgDtl,
			String promoMsgForZoneId, String msgState, String msgOfferType,
			String promoMsgLocType,
			Map<String, PromotionEntity> promotionEntityMap)
			throws PromoBusinessException, ProductEncodeException {
		PromotionEntity promotionEntityFromMap = promotionEntityMap
				.get(prmPrcChgDtl.getTslPromoCompDisplayId());
		PrmPrcChgThr prmPrcChgThr = prmPrcChgDtl.getPrmPrcChgThr();
		PromotionEntity promotionEntity;
		List<PromoItemListEntity> promoItemListEntities;
		List<PromoThresholdEntity> promoThresholdEntities;
		List<PromoRewardEntity> promoRewardEntities;

		List<PromoItemEntity> promoItemEntities;
		try {
			String effectiveDate = getDate(prmPrcChgDtl.getStartDate()
					.getYear().toString(), prmPrcChgDtl.getStartDate()
					.getMonth().toString(), prmPrcChgDtl.getStartDate()
					.getDay().toString(), prmPrcChgDtl.getStartDate().getHour()
					.toString(),

			prmPrcChgDtl.getStartDate().getMinute().toString(), prmPrcChgDtl
					.getStartDate().getSecond().toString());
			String endDate = getDate(prmPrcChgDtl.getEndDate().getYear()
					.toString(), prmPrcChgDtl.getEndDate().getMonth()
					.toString(), prmPrcChgDtl.getEndDate().getDay().toString(),
					prmPrcChgDtl.getEndDate().getHour().toString(),
					prmPrcChgDtl.getEndDate().getMinute().toString(),
					prmPrcChgDtl.getEndDate().getSecond().toString());

			if (promotionEntityFromMap != null) {

				promotionEntity = promotionEntityFromMap;

				PromoItemEntity promoItemEntity = new PromoItemEntity();
				promoItemEntity.effectiveDate = effectiveDate;
				promoItemEntity.endDate = endDate;
				if (!("0").equals(prmPrcChgDtl.getPrmPrcChgThr().getMerchType()
						.toString())) {
					if (!Dockyard.isSpaceOrNull(prmPrcChgDtl.getPrmPrcChgThr()
							.getDept())
							&& !Dockyard.isSpaceOrNull(prmPrcChgDtl
									.getPrmPrcChgThr().getClazz())
							&& !Dockyard.isSpaceOrNull(prmPrcChgDtl
									.getPrmPrcChgThr().getSubclass())) {
						promoItemEntity.itemType = PriceConstants.SUBCLASS_STR;
						promoItemEntity.itemRef = PriceUtility
								.convertRMStoTesco(prmPrcChgThr.getDept()
										.toString(), prmPrcChgThr.getClazz()
										.toString(), prmPrcChgThr.getSubclass()
										.toString());
					} else if (!Dockyard.isSpaceOrNull(prmPrcChgDtl
							.getPrmPrcChgThr().getDept())
							&& !Dockyard.isSpaceOrNull(prmPrcChgDtl
									.getPrmPrcChgThr().getClazz())
							&& Dockyard.isSpaceOrNull(prmPrcChgDtl
									.getPrmPrcChgThr().getSubclass())) {
						promoItemEntity.itemType = PriceConstants.CLASS_STR;
						promoItemEntity.itemRef = PriceUtility
								.convertRMStoTesco(prmPrcChgThr.getDept()
										.toString(), prmPrcChgThr.getClazz()
										.toString(), null);
					} else if (!Dockyard.isSpaceOrNull(prmPrcChgDtl
							.getPrmPrcChgThr().getDept())
							&& Dockyard.isSpaceOrNull(prmPrcChgDtl
									.getPrmPrcChgThr().getClazz())
							&& Dockyard.isSpaceOrNull(prmPrcChgDtl
									.getPrmPrcChgThr().getSubclass())) {
						promoItemEntity.itemType = PriceConstants.SECTION_STR;
						promoItemEntity.itemRef = PriceUtility
								.convertRMStoTesco(prmPrcChgThr.getDept()
										.toString(), null, null);
					}

				} else {
					promoItemEntity.itemType = PriceConstants.PROMO_ITEM_TYPE;
					promoItemEntity.itemRef = prmPrcChgThr.getItem();
				}
				if (prmPrcChgThr.getTslPosLabelReqInd() != null) {
					if (PriceConstants.POS_LABEL_ONE.equals(prmPrcChgThr
							.getTslPosLabelReqInd().toString())) {
						promoItemEntity
								.setPosLabelReqInd(PriceConstants.POS_LABEL_Y);
					} else {
						promoItemEntity
								.setPosLabelReqInd(PriceConstants.POS_LABEL_N);
					}
				} else {
					promoItemEntity
							.setPosLabelReqInd(PriceConstants.POS_LABEL_N);
				}
				if (prmPrcChgDtl.getPromoCompDetailId() != null) {
					promoItemEntity.setRpmPromoCompDetailId(prmPrcChgDtl
							.getPromoCompDetailId().toString());
				}

				List<PromoItemEntity> newPromoItemEntity = new ArrayList<>();
				newPromoItemEntity.add(promoItemEntity);

				promoItemListEntities = promotionEntity
						.getPromoItemListEntities();
				PromoItemListEntity availablePromoItemListEntity = promoItemListEntities
						.get(0);

				promoItemEntities = availablePromoItemListEntity
						.getPromoItems();
				promoItemEntities.add(promoItemEntity);
				availablePromoItemListEntity.setPromoItems(promoItemEntities);
				promoItemListEntities.set(0, availablePromoItemListEntity);
				promotionEntity.setPromoItemListEntities(promoItemListEntities);
				promotionEntityMap.put(promotionEntity.getOfferRef(),
						promotionEntity);
				mapPromoCompDisplayIdToPromoCompDtlId(
						prmPrcChgDtl.getTslPromoCompDisplayId(), prmPrcChgDtl
								.getPromoCompDetailId().toString());

			} else {

				promotionEntity = new PromotionEntity();
				promotionEntity.offerRef = prmPrcChgDtl
						.getTslPromoCompDisplayId();
				promotionEntity.offerType = msgOfferType;
				promotionEntity.state = msgState;
				promotionEntity.name = prmPrcChgDtl.getPromoCompDesc();
				promotionEntity.externalPromoId = prmPrcChgDtl
						.getTslExtPromoId() != null ? prmPrcChgDtl
						.getTslExtPromoId().toString() : null;
				promotionEntity.tillRollDescription = prmPrcChgDtl
						.getTslCompLevelTillDesc();
				promotionEntity.locType = promoMsgLocType;
				promotionEntity.locRef = promoMsgForZoneId;
				promotionEntity.createdById = PriceConstants.PROMO_CREATED_ID_RPM;
				promotionEntity.createdDate = Dockyard
						.getSysDate(PriceConstants.ISO_8601_FORMAT);
				promotionEntity.lastUpdatedById = PriceConstants.PROMO_CREATED_ID_RPM;
				promotionEntity.lastUpdateDate = Dockyard
						.getSysDate(PriceConstants.ISO_8601_FORMAT);

				promoThresholdEntities = new ArrayList<>();
				promoRewardEntities = new ArrayList<>();
				for (PrmPrcChgThrDtl prmPrcChgThrDtl : prmPrcChgThr
						.getPrmPrcChgThrDtl()) {
					PromoThresholdEntity promoThresholdEntity = new PromoThresholdEntity();
					PromoRewardEntity promoRewardEntity = new PromoRewardEntity();

					promoThresholdEntity.thresholdType = prmPrcChgThr
							.getThresholdType();
					if (PriceConstants.PROMO_THR_TYPES.AMT.value().equals(
							prmPrcChgThr.getThresholdType())) {
						promoThresholdEntity.thresholdAmount = prmPrcChgThrDtl
								.getThresholdValue().doubleValue();
					}
					promoThresholdEntity.thresholdCurrency = getCurrencyForLoc(promoMsgForZoneId);
					if (PriceConstants.PROMO_THR_TYPES.QTY.value().equals(
							prmPrcChgThr.getThresholdType())) {
						promoThresholdEntity.thresholdQty = prmPrcChgThrDtl
								.getThresholdValue().intValue();
					}

					promoRewardEntity.changeType = prmPrcChgThr.getPrmChgType();
					promoRewardEntity.changeQty = PriceConstants.DEFAULT_PROMO_CHANGE_QTY;

					if (PriceConstants.PROMO_CHG_TYPES.AMT.value().equals(
							prmPrcChgThr.getPrmChgType())
							|| PriceConstants.PROMO_CHG_TYPES.FXD.value()
									.equals(prmPrcChgThr.getPrmChgType())
							|| PriceConstants.PROMO_CHG_TYPES.NO_CHG.value()
									.equals(prmPrcChgThr.getPrmChgType())
							|| PriceConstants.PROMO_CHG_TYPES.CLB_CRD.value()
									.equals(prmPrcChgThr.getPrmChgType())) {
						promoRewardEntity.changeAmount = prmPrcChgThrDtl
								.getPrmChgValue();
					}

					if (PriceConstants.PROMO_CHG_TYPES.PCT.value().equals(
							prmPrcChgThr.getPrmChgType())) {
						/**
						 * Multiply by 100 because RPM gives data with decimal
						 */
						promoRewardEntity.changePercent = prmPrcChgThrDtl
								.getPrmChgValue() * 100;
					}
					promoRewardEntity.voucherNumber = prmPrcChgThrDtl
							.getTslVoucherNumber();
					promoRewardEntity.voucherDescription = prmPrcChgThrDtl
							.getTslVoucherDesc();
					promoRewardEntity.changeCurrency = getCurrencyForLoc(promoMsgForZoneId);
					promoRewardEntity.changeUom = null;
					promoThresholdEntities.add(promoThresholdEntity);
					promoRewardEntities.add(promoRewardEntity);
				}
				promotionEntity
						.setPromoThresholdEntities(promoThresholdEntities);
				promotionEntity.setPromoRewardEntities(promoRewardEntities);
				effectiveDate = getDate(prmPrcChgDtl.getStartDate().getYear()
						.toString(), prmPrcChgDtl.getStartDate().getMonth()
						.toString(), prmPrcChgDtl.getStartDate().getDay()
						.toString(), prmPrcChgDtl.getStartDate().getHour()
						.toString(), prmPrcChgDtl.getStartDate().getMinute()
						.toString(), prmPrcChgDtl.getStartDate().getSecond()
						.toString());
				endDate = getDate(prmPrcChgDtl.getEndDate().getYear()
						.toString(), prmPrcChgDtl.getEndDate().getMonth()
						.toString(), prmPrcChgDtl.getEndDate().getDay()
						.toString(), prmPrcChgDtl.getEndDate().getHour()
						.toString(), prmPrcChgDtl.getEndDate().getMinute()
						.toString(), prmPrcChgDtl.getEndDate().getSecond()
						.toString());

				promoItemListEntities = new ArrayList<>();
				PromoItemListEntity promoItemBuyListEntity = new PromoItemListEntity();
				promoItemBuyListEntity.listType = PriceConstants.PROMO_ITEM_LIST_BUY_TYPE;
				int[] thresholdRefs = setThrRewardRefs(promotionEntity
						.getPromoThresholdEntities().size());
				promoItemEntities = new ArrayList<>();

				PromoItemEntity promoItemEntity = new PromoItemEntity();
				promoItemEntity.effectiveDate = effectiveDate;
				promoItemEntity.endDate = endDate;
				if (!prmPrcChgDtl.getPrmPrcChgThr().getMerchType().toString()
						.equals("0")) {
					if (!Dockyard.isSpaceOrNull(prmPrcChgDtl.getPrmPrcChgThr()
							.getDept())
							&& !Dockyard.isSpaceOrNull(prmPrcChgDtl
									.getPrmPrcChgThr().getClazz())
							&& !Dockyard.isSpaceOrNull(prmPrcChgDtl
									.getPrmPrcChgThr().getSubclass())) {
						promoItemEntity.itemType = PriceConstants.SUBCLASS_STR;
						promoItemEntity.itemRef = PriceUtility
								.convertRMStoTesco(prmPrcChgThr.getDept()
										.toString(), prmPrcChgThr.getClazz()
										.toString(), prmPrcChgThr.getSubclass()
										.toString());
					} else if (!Dockyard.isSpaceOrNull(prmPrcChgDtl
							.getPrmPrcChgThr().getDept())
							&& !Dockyard.isSpaceOrNull(prmPrcChgDtl
									.getPrmPrcChgThr().getClazz())
							&& Dockyard.isSpaceOrNull(prmPrcChgDtl
									.getPrmPrcChgThr().getSubclass())) {
						promoItemEntity.itemType = PriceConstants.CLASS_STR;
						promoItemEntity.itemRef = PriceUtility
								.convertRMStoTesco(prmPrcChgThr.getDept()
										.toString(), prmPrcChgThr.getClazz()
										.toString(), null);
					} else if (!Dockyard.isSpaceOrNull(prmPrcChgDtl
							.getPrmPrcChgThr().getDept())
							&& Dockyard.isSpaceOrNull(prmPrcChgDtl
									.getPrmPrcChgThr().getClazz())
							&& Dockyard.isSpaceOrNull(prmPrcChgDtl
									.getPrmPrcChgThr().getSubclass())) {
						promoItemEntity.itemType = PriceConstants.SECTION_STR;
						promoItemEntity.itemRef = PriceUtility
								.convertRMStoTesco(prmPrcChgThr.getDept()
										.toString(), null, null);
					}

				} else {
					promoItemEntity.itemType = PriceConstants.PROMO_ITEM_TYPE;
					promoItemEntity.itemRef = prmPrcChgThr.getItem();
				}

				if (prmPrcChgThr.getTslPosLabelReqInd() != null) {
					if (PriceConstants.POS_LABEL_ONE.equals(prmPrcChgThr
							.getTslPosLabelReqInd().toString())) {
						promoItemEntity
								.setPosLabelReqInd(PriceConstants.POS_LABEL_Y);
					} else {
						promoItemEntity
								.setPosLabelReqInd(PriceConstants.POS_LABEL_N);
					}
				} else {
					promoItemEntity
							.setPosLabelReqInd(PriceConstants.POS_LABEL_N);
				}
				if (prmPrcChgDtl.getPromoCompDetailId() != null) {
					promoItemEntity.setRpmPromoCompDetailId(prmPrcChgDtl
							.getPromoCompDetailId().toString());
				}

				promoItemEntities.add(promoItemEntity);
				promoItemBuyListEntity.setPromoItems(promoItemEntities);
				promoItemBuyListEntity.setThresholdRefs(thresholdRefs);
				promoItemListEntities.add(promoItemBuyListEntity);

				PromoItemListEntity promoItemGetListEntity = new PromoItemListEntity();
				promoItemGetListEntity.listType = PriceConstants.PROMO_ITEM_LIST_GET_TYPE;

				int[] rewardRefs = setThrRewardRefs(promotionEntity
						.getPromoRewardEntities().size());
				promoItemGetListEntity.setRewardRefs(rewardRefs);
				promoItemListEntities.add(promoItemGetListEntity);

				promotionEntity.setPromoItemListEntities(promoItemListEntities);

				promotionEntityMap.put(promotionEntity.getOfferRef(),
						promotionEntity);
				mapPromoCompDisplayIdToPromoCompDtlId(
						prmPrcChgDtl.getTslPromoCompDisplayId(), prmPrcChgDtl
								.getPromoCompDetailId().toString());
			}

		} catch (ProductEncodeException | DataAccessException pe) {
			throw new PromoBusinessException(new ProductEncodeException(pe));
		}

	}

	private String verifyPromotionOrLocationExist(
			PromotionEntity promotionEntity) throws PromoBusinessException {
		String offerId = promotionEntity.getOfferRef();
		String locRef = promotionEntity.getLocRef();
		String locType = promotionEntity.getLocType();
		PromotionMasterEntity masterDoc = null;
		PromotionEntity existingPromotionEntity = null;
		String eventType = null;
		try {
			masterDoc = (PromotionMasterEntity) repository
					.getGenericObject(PROMOTION_DOC_KEY_PREFIX + offerId,
							PromotionMasterEntity.class);

			existingPromotionEntity = (PromotionEntity) repository
					.getGenericObject(PROMOTION_DOC_KEY_PREFIX + offerId + "_"
							+ locType + locRef, PromotionEntity.class);

		} catch (DataAccessException e) {
			throw new PromoBusinessException(e);
		}

		if (masterDoc == null) {
			eventType = PROMOTION_MSG_TYPE_CRE;

		} else if (existingPromotionEntity == null) {
			eventType = PROMO_LOC_ADDED;
		}
		return eventType;

	}

}