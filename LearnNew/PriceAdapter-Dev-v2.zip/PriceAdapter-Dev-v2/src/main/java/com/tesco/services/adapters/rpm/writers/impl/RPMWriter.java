package com.tesco.services.adapters.rpm.writers.impl;

import com.tesco.couchbase.CouchbaseWrapper;
import com.tesco.couchbase.listeners.Listener;
import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.exceptions.ColumnNotFoundException;
import com.tesco.services.adapters.core.exceptions.WriterBusinessException;
import com.tesco.services.adapters.rpm.readers.PriceServiceCSVReader;
import com.tesco.services.adapters.rpm.readers.impl.PriceServiceCSVReaderImpl;
import com.tesco.services.adapters.rpm.writers.CSVHeaders;
import com.tesco.services.adapters.rpm.writers.Mapper;
import com.tesco.services.adapters.rpm.writers.Writer;
import com.tesco.services.adapters.sonetto.SonettoPromotionXMLReader;
import com.tesco.services.core.Product;
import com.tesco.services.core.Store;
import com.tesco.services.repositories.Repository;
import com.tesco.services.repositories.RepositoryImpl;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.PriceConstants;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;
import io.dropwizard.configuration.ConfigurationException;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class RPMWriter implements Writer {

	private Mapper productMapper;

	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger("RPM Import");

	private static String rpmWriteStatus;

	private Dockyard dockyard;

	public Dockyard getDockyard() {

		if (dockyard == null) {
			dockyard = new Dockyard();
		}
		return dockyard;
	}

	private StringBuilder sb;

	public void setDockyard(Dockyard dockyard) {
		this.dockyard = dockyard;
	}

	@SuppressWarnings("rawtypes")
	private Listener listener;

	private String sonettoPromotionsXMLFilePath;

	private Configuration configuration;

	private CouchbaseWrapper couchbaseWrapper;

	private Repository repository;

	private PriceServiceCSVReader rpmPriceReader;

	private PriceServiceCSVReader rpmPromoPriceReader;

	private PriceServiceCSVReader storeZoneReader;

	private PriceServiceCSVReader rpmPromotionReader;

	private PriceServiceCSVReader rpmPromotionDescReader;

	private SonettoPromotionXMLReader sonettoPromotionXMLReader;


	@Inject
	public RPMWriter(@Named("configuration") Configuration configuration,
			@Named("couchbaseWrapper") CouchbaseWrapper couchbaseWrapper,
			@Named("repository") Repository repository,
			@Named("productMapper") Mapper productMapper)
			throws WriterBusinessException {
		this.configuration = configuration;
		this.couchbaseWrapper = couchbaseWrapper;
		this.repository = repository;
		this.productMapper = productMapper;
	}

	public RPMWriter(Configuration configuration,
			CouchbaseWrapper couchbaseWrapper,
			RepositoryImpl repository,
			Mapper productMapper,
			PriceServiceCSVReader rpmPriceReader,
			PriceServiceCSVReader rpmPromoPriceReader,
			PriceServiceCSVReader storeZoneReader,
			PriceServiceCSVReader rpmPromotionReader,
			PriceServiceCSVReader rpmPromotionDescReader,
			SonettoPromotionXMLReader sonettoPromotionXMLReader) {
		this.configuration = configuration;
		this.couchbaseWrapper = couchbaseWrapper;
		this.repository = repository;
		this.productMapper = productMapper;
		this.rpmPriceReader = rpmPriceReader;
		this.rpmPromoPriceReader = rpmPromoPriceReader;
		this.storeZoneReader = storeZoneReader;
		this.rpmPromotionReader = rpmPromotionReader;
		this.rpmPromotionDescReader = rpmPromotionDescReader;
		this.sonettoPromotionXMLReader = sonettoPromotionXMLReader;
	}

	/**
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public Listener<Void, Exception> getListener() {
		listener = new Listener<Void, Exception>() {
			@Override
			public void onComplete(Void aVoid) {
				// it will be implemented later if any requirement comes
				rpmWriteStatus = "done";
				LOGGER.info("Data Insert of {} Completed", sb.toString());
			}

			@Override
			public void onException(Exception e) {
				// it will be implemented later if any requirement comes
				rpmWriteStatus = "failed";
				LOGGER.error("Error Inserting data of {} ErrorMsg {}",
						sb.toString(), e);
			}
		};
		return listener;
	}

	/**
	 * @return
	 * @throws IOException
	 * @throws ColumnNotFoundException
	 */
	public PriceServiceCSVReader getRpmPriceReader()
			throws WriterBusinessException {
		try {
			rpmPriceReader = new PriceServiceCSVReaderImpl(
					configuration.getRPMPriceZoneDataPath(),
					CSVHeaders.Price.PRICE_ZONE_HEADERS);
		} catch (IOException | ColumnNotFoundException e) {
			LOGGER.error("Error occurred in getRpmPriceReader ", e);
			throw new WriterBusinessException(e.getMessage(), e.getCause());
		}
		return rpmPriceReader;
	}

	/**
	 * @return
	 * @throws IOException
	 * @throws ColumnNotFoundException
	 */
	public PriceServiceCSVReader getRpmPromoPriceReader()
			throws WriterBusinessException {

		try {
			rpmPromoPriceReader = new PriceServiceCSVReaderImpl(
					configuration.getRPMPromoZoneDataPath(),
					CSVHeaders.Price.PROMO_ZONE_HEADERS);
		} catch (IOException | ColumnNotFoundException e) {
			LOGGER.error("Error occurred in getRpmPromoPriceReader ", e);
			throw new WriterBusinessException(e.getMessage(), e.getCause());
		}
		return rpmPromoPriceReader;
	}

	/**
	 * @return
	 * @throws IOException
	 * @throws ColumnNotFoundException
	 */
	public PriceServiceCSVReader getRpmPromotionDescReader()
			throws WriterBusinessException {
		try {
			rpmPromotionDescReader = new PriceServiceCSVReaderImpl(
					configuration.getRPMPromoDescExtractDataPath(),
					CSVHeaders.PromoDescExtract.HEADERS);
		} catch (IOException | ColumnNotFoundException e) {
			LOGGER.error("Error occurred in getRpmPromotionDescReader ", e);
			throw new WriterBusinessException(e.getMessage(), e.getCause());
		}
		return rpmPromotionDescReader;
	}

	/**
	 * @return
	 * @throws IOException
	 * @throws ColumnNotFoundException
	 */
	public PriceServiceCSVReader getRpmPromotionReader()
			throws WriterBusinessException {
		try {
			rpmPromotionReader = new PriceServiceCSVReaderImpl(
					configuration.getRPMPromoExtractDataPath(),
					CSVHeaders.PromoExtract.HEADERS);
		} catch (IOException | ColumnNotFoundException e) {
			LOGGER.error("Error occurred in getRpmPromotionReader ", e);
			throw new WriterBusinessException(e.getMessage(), e.getCause());
		}
		return rpmPromotionReader;
	}

	/**
	 * @return
	 * @throws ConfigurationException
	 */
	public String getSonettoPromotionsXMLFilePath()
			throws ConfigurationException {

		sonettoPromotionsXMLFilePath = configuration
				.getSonettoPromotionXSDDataPath();

		return sonettoPromotionsXMLFilePath;
	}

	/**
	 * @return
	 * @throws ConfigurationException
	 */
	public SonettoPromotionXMLReader getSonettoPromotionXMLReader()
			throws ConfigurationException {

		sonettoPromotionXMLReader = new SonettoPromotionXMLReader(
				configuration.getSonettoShelfImageUrl(),
				configuration.getSonettoPromotionXSDDataPath());

		return sonettoPromotionXMLReader;
	}

	/**
	 * @return
	 * @throws ConfigurationException
	 * @throws IOException
	 * @throws ColumnNotFoundException
	 */
	public PriceServiceCSVReader getStoreZoneReader()
			throws WriterBusinessException {

		try {
			storeZoneReader = new PriceServiceCSVReaderImpl(
					configuration.getRPMStoreDataPath(),
					CSVHeaders.StoreZone.HEADERS);
		} catch (IOException | ColumnNotFoundException | ConfigurationException e) {
			LOGGER.error("Error occurred in getStoreZoneReader", e);
			throw new WriterBusinessException(e.getMessage(), e.getCause());
		}
		return storeZoneReader;
	}

	public void setRepository(RepositoryImpl repository) {
		this.repository = repository;
	}

	public void init() throws WriterBusinessException {
		try {
			this.rpmPriceReader = getRpmPriceReader();
			this.rpmPromoPriceReader = getRpmPromoPriceReader();
			this.storeZoneReader = getStoreZoneReader();
			this.rpmPromotionReader = getRpmPromotionReader();
			this.rpmPromotionDescReader = getRpmPromotionDescReader();
			this.sonettoPromotionsXMLFilePath = getSonettoPromotionsXMLFilePath();
			this.sonettoPromotionXMLReader = getSonettoPromotionXMLReader();
		} catch (ConfigurationException e) {
			LOGGER.error(
					"ConfigurationException occurred in initializing RPM file readers.",
					e);
			throw new WriterBusinessException(e.getMessage(), e.getCause());
		}
	}

	/**
	 * @throws WriterBusinessException
	 */
	public void write(String fileName) throws WriterBusinessException {
		LOGGER.info("Importing price zone prices into Couchbase");
		try {
			if(rpmPriceReader == null || rpmPromoPriceReader == null || storeZoneReader == null || rpmPromotionReader == null || rpmPromotionDescReader == null || sonettoPromotionXMLReader == null) {
				init();
			}
			writePriceZonePrices();
			writePromoZonePrices();
			writePromotions();
			writePromotionsDesc();
		} catch (Exception e) {
			LOGGER.error("Error occured while importing price zone prices: ", e);
			throw new WriterBusinessException(e.getMessage(), e.getCause());
		}
		// writeStoreZones();
	}

	/**
	 * @param product
	 * @param mapTpnbTpnc
	 */
	@SuppressWarnings("rawtypes")
	private void insertData(Product product, Map mapTpnbTpnc) throws Exception {
		sb = new StringBuilder("Price Zone for Product : ");
		sb.append(product.getTPNB());
		repository.insertObject(
				PriceConstants.PRODUCT_KEY_PREFIX + product.getTPNB(), product);
		for (Object set : mapTpnbTpnc.keySet()) {
			String item = set.toString();
			sb = new StringBuilder("TPNB/TPNC Mapping for TPNB : ");
			sb.append(product.getTPNB());
			repository
					.mapLookUps(mapTpnbTpnc.get(item).toString(), item);
		}

	}

	/*
	 * PS-238 Modified By Nibedita - Code has been changed in order to insert
	 * the product once for all ,after building for all available zone and
	 * variants - Start
	 */
	private void writePriceZonePrices() throws Exception {
		Map<String, String> productInfoMap;
		final String sysdate = Dockyard.getSysDate("yyyyMMdd");
		Product product = new Product();
		String prevItem = null;
		String curItem = null;
		boolean isNewProduct = false;
		Map<String, String> mapTpnbTpnc = new HashMap<String, String>();
		while ((productInfoMap = rpmPriceReader.getNext()) != null) {
			curItem = productInfoMap.get("ITEM").split("-")[0];
			if (Dockyard.isSpaceOrNull(prevItem)
					&& !Dockyard.isSpaceOrNull(curItem)) {
				isNewProduct = true;
			} else if (prevItem != null && !curItem.equals(prevItem)) {
				insertData(product, mapTpnbTpnc);
				mapTpnbTpnc.clear();
				isNewProduct = true;
			}
			product = productMapper.mapPriceZonePrice(productInfoMap,
					isNewProduct);
			product.setLast_updated_date(sysdate);
			mapTpnbTpnc.put(productInfoMap.get("ITEM"),
					productInfoMap.get("TPNC"));
			prevItem = curItem;
			isNewProduct = false;
		}
		if (!Dockyard.isSpaceOrNull(mapTpnbTpnc) && !mapTpnbTpnc.isEmpty()) {
			insertData(product, mapTpnbTpnc);
			mapTpnbTpnc.clear();
		}

	}

	/**
	 * @throws IOException
	 */
	private void writePromotions() throws Exception {
		Map<String, String> promotionInfoMap;

		while ((promotionInfoMap = rpmPromotionReader.getNext()) != null) {
			final Product product = productMapper
					.mapPromotion(promotionInfoMap);
			if (product != null) {
				sb = new StringBuilder("Promotions for Product : ");
				sb.append(product.getTPNB());
				repository.insertObject(
						PriceConstants.PRODUCT_KEY_PREFIX + product.getTPNB(),
						product);
			}
		}
		if (!productMapper.getPromoRejectedProducts().isEmpty()) {
			writePricePromoRejectionsToFile(productMapper,
					PriceConstants.PROMO_EXTRACT_REJ_FILE);
		}
	}

	/**
	 * @throws IOException
	 */
	private void writePromotionsDesc() throws Exception {
		Map<String, String> promotionDescInfoMap;
		while ((promotionDescInfoMap = rpmPromotionDescReader.getNext()) != null) {
			final Product product = productMapper
					.mapPromotionDescription(promotionDescInfoMap);
			if (product != null) {
				sb = new StringBuilder("Promotions Decs for Product : ");
				sb.append(product.getTPNB());
				repository.insertObject(
						PriceConstants.PRODUCT_KEY_PREFIX + product.getTPNB(),
						product);
			}
		}
	}

	/*
	 * PS-238 Modified By Nibedita - Code has been changed in order to insert
	 * the product once for all ,after building for all available zone and
	 * variants - End
	 */
	private void writePromoZonePrices() throws Exception {
		Map<String, String> productInfoMap;
		while ((productInfoMap = rpmPromoPriceReader.getNext()) != null) {
			final Product product = productMapper
					.mapPromoZonePrice(productInfoMap);
			if (product != null) {
				sb = new StringBuilder("Promo Zone for Product : ");
				sb.append(product.getTPNB());
				repository.insertObject(
						PriceConstants.PRODUCT_KEY_PREFIX + product.getTPNB(),
						product);
			}
		}
		if (!productMapper.getPromoRejectedProducts().isEmpty()) {
			writePricePromoRejectionsToFile(productMapper,
					PriceConstants.PROMO_ZONE_REJ_FILE);
		}
	}

	/**
	 * @throws IOException
	 */
	@SuppressWarnings("unused")
	private void writeStoreZones() throws Exception {
		Map<String, String> storeInfoMap;
		StoreMapper storeMapper = new StoreMapper(repository);
		while ((storeInfoMap = storeZoneReader.getNext()) != null) {
			final Store store = storeMapper.map(storeInfoMap);
			sb = new StringBuilder("Store for Store Id : ");
			sb.append(store.getStoreId());
			repository.insertObject(
					PriceConstants.STORE_KEY + store.getStoreId(), store);
		}
	}

	/**
	 * Writes the Rejected Product details to File
	 */
	private void writePricePromoRejectionsToFile(Mapper productMapper,
			String rejType) {
		String date = Dockyard.getSysDate("yyyyMMddHHmmss");
		String rejFilePath = this.configuration.getRejectFilePath();
		LOGGER.info("rej file creation for writePromoZonePrices : {}",
				rejFilePath + "/REJECT_FILE_" + rejType + date + ".log");
		getDockyard().writeProductDetailsToFile(
				rejFilePath + "/REJECT_FILE_" + rejType + "_" + date + ".log",
				productMapper.getPromoRejectedProducts());
		productMapper.clearPromoRejList();

	}

	public static String getRpmWriteStatus() {
		return rpmWriteStatus;
	}
}
