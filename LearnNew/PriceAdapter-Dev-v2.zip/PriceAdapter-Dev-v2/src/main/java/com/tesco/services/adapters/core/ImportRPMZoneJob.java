package com.tesco.services.adapters.core;

import javax.inject.Inject;
import javax.inject.Named;

import org.slf4j.Logger;

import com.tesco.services.adapters.core.exceptions.WriterBusinessException;
import com.tesco.services.adapters.rpm.writers.impl.RPMZoneWriter;
import com.tesco.services.adapters.rpm.writers.Writer;
import com.tesco.services.resources.ImportResource;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;

public class ImportRPMZoneJob implements Import {

	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(ImportRPMZoneJob.class);

	private String runIdentifier;
	private Writer rpmZoneWriter;
	private String fileName;

	@Inject
	public ImportRPMZoneJob(
			@Named("rpmZoneWriter") Writer rpmZoneWriter) {
		this.rpmZoneWriter = rpmZoneWriter;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getRunIdentifier() {
		return runIdentifier;
	}

	public void setRunIdentifier(String runIdentifier) {
		this.runIdentifier = runIdentifier;
	}

	@Override
	public void run() {
		LOGGER.info("Firing up imports for RPM Onetime Zone data for {}",
				runIdentifier);
		startImportProcess();
	}

	@Override
	public void startImportProcess() {
		try {
			((RPMZoneWriter) rpmZoneWriter)
					.setRunIdentifier(getRunIdentifier());
			rpmZoneWriter.write(fileName);
			LOGGER.info(
					"Successfully completed imports for RPM Onetime Zone data");
		} catch (WriterBusinessException exception) {
			LOGGER.error("Error importing Onetime RPM Zone data..", exception);
			ImportResource.setErrorString(fileName,
					"Error importing Onetime RPM Zone data..");
		} finally {
			ImportResource.getImportSemaphoreForIdentifier(fileName).release();
		}
	}
}
