package com.tesco.services.adapters.core;

import static com.tesco.services.resources.ScheduledEventResource.getScheduledEventSemaphoreMap;
import static com.tesco.services.utility.PriceConstants.SCHEDULED_FUTURE_PRICE_MSG_TYPE_CRE;
import static com.tesco.services.utility.PriceUtility.getCouchbaseViewKeyForEffectiveDate;
import static com.tesco.services.utility.sl4j.LoggerFactoryWrapper.getLogger;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.core.Response;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.slf4j.Logger;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tesco.logging.LogWriter;
import com.tesco.logging.LoggerRepository;
import com.tesco.services.Configuration;
import com.tesco.services.CouchbaseViewConfig;
import com.tesco.services.adapters.core.exceptions.PriceEventException;
import com.tesco.services.adapters.price.PriceEventHandler;
import com.tesco.services.repositories.views.CouchbaseViewRestImpl;
import com.tesco.services.repositories.views.WebViewTemplate;
import com.tesco.services.resources.ScheduledEventResource;
import com.tesco.services.utility.PriceConstants;

public class PriceChangeScheduledEventJob extends CouchbaseViewRestImpl
		implements ScheduledEventJob {

	private static final String PAGE_SIZE = "page.size";
	final static private Logger LOGGER = getLogger(PriceChangeScheduledEventJob.class);
	final static private LogWriter REJECTLOGGER = LoggerRepository
			.getLogger("ScheduledEventRejectLogger");
	final static private String ROWS = "rows";
	final static private String VALUE = "value";
	private PriceEventHandler priceEventHandler;
	private Configuration configuration;
	private ObjectMapper mapper;

	private WebViewTemplate webViewTemplate;

	@Inject
	public PriceChangeScheduledEventJob(
			@Named("configuration") Configuration configuration,
			@Named("jsonmapper") ObjectMapper mapper,
			@Named("priceEventHandler") PriceEventHandler priceEventHandler) {
		super(configuration);
		this.configuration = configuration;
		this.mapper = mapper;
		this.priceEventHandler = priceEventHandler;
	}

	public PriceChangeScheduledEventJob(Configuration configuration,
			ObjectMapper mapper, PriceEventHandler priceEventHandler,
			WebViewTemplate webViewTemplate) {
		super(configuration);
		this.configuration = configuration;
		this.mapper = mapper;
		this.priceEventHandler = priceEventHandler;
		this.webViewTemplate = webViewTemplate;
	}

	@Override
	public void run() {
		try {
			processScheduledEvents();
		} catch (Exception exception) {
			ScheduledEventResource
					.setErrorString(SCHEDULED_FUTURE_PRICE_MSG_TYPE_CRE,
							"Error while processing scheduled events of type PriceChange ...");
		} finally {
			getScheduledEventSemaphoreMap(SCHEDULED_FUTURE_PRICE_MSG_TYPE_CRE)
					.release();
		}
	}

	@Override
	public void processScheduledEvents() {
		String resultJsonData = null;
		int pageStartIndex = 0;
		int numberOfRecordsProcessed = 0;

		CouchbaseViewConfig scheduledPriceChangeViewConfig = configuration
				.getCouchbaseViewConfig().get(
						SCHEDULED_FUTURE_PRICE_MSG_TYPE_CRE);

		int pageSize = Integer.parseInt(scheduledPriceChangeViewConfig
				.getViewQueryParams().get(PAGE_SIZE));

		String documentKey = getCouchbaseViewKeyForEffectiveDate(scheduledPriceChangeViewConfig);

		Map<String, String> viewQueryDynamicParams = new HashMap<String, String>();
		viewQueryDynamicParams.put(PriceConstants.VIEW_QUERY_KEY, documentKey);

		if (webViewTemplate == null) {
			webViewTemplate = createViewTemplate(scheduledPriceChangeViewConfig);
		}

		do {
			viewQueryDynamicParams
					.put(PriceConstants.SKIP, "" + pageStartIndex);

			Response viewQueryResponse = webViewTemplate.queryView(
					scheduledPriceChangeViewConfig.getViewQueryParams(),
					viewQueryDynamicParams);

			resultJsonData = viewQueryResponse.readEntity(String.class);

			if (resultJsonData != null) {
				numberOfRecordsProcessed = processPageRecordOfPriceChangeEvent(resultJsonData);
				pageStartIndex = pageStartIndex + pageSize;
			}

		} while (resultJsonData != null && numberOfRecordsProcessed > 0);
	}

	@SuppressWarnings("unchecked")
	private int processPageRecordOfPriceChangeEvent(String resultJsonData) {
		JSONArray priceChangeRowData = null;
		JSONObject priceChangeDocData = null;
		try {
			if (resultJsonData != null) {
				priceChangeDocData = new JSONObject(resultJsonData);
				priceChangeRowData = new JSONArray(priceChangeDocData
						.getJSONArray(ROWS).toString());

			}
			Map<String, String> priceChangeMapData = null;
			for (int rowIndex = 0; rowIndex < priceChangeRowData.length(); rowIndex++) {
				try {
					JSONObject pageRowData = priceChangeRowData
							.getJSONObject(rowIndex);
					JSONObject eventDataEntityJson = (JSONObject) pageRowData
							.get(VALUE);
					priceChangeMapData = mapper.readValue(
							eventDataEntityJson.toString(), Map.class);
					priceEventHandler.processScheduledEvent(priceChangeMapData);
				} catch (PriceEventException exception) {
					REJECTLOGGER.info(priceChangeMapData);
				}
			}
		} catch (JSONException | IOException exception) {
			LOGGER.error(
					"Error occured while publishing of price change event ",
					exception);

		} catch (Exception exception) {
			LOGGER.error("Error occured while processing event ", exception);
		}
		return priceChangeRowData.length();
	}

}
