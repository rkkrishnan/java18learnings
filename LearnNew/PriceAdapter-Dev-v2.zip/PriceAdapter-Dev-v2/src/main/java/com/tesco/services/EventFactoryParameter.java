package com.tesco.services;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EventFactoryParameter {

	@JsonProperty("type")
	private String type;

	@JsonProperty("name")
	private String name;

	@JsonProperty("value")
	private String value;

	@JsonProperty("primitive")
	private boolean primitive;

	public String getType() {
		return type;
	}

	public String getName() {
		return name;
	}

	public String getValue() {
		return value;
	}

	public boolean isPrimitive() {
		return primitive;
	}

}
