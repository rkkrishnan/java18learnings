package com.tesco.services.utility;

import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;

/**
 * Created by yp21 on 14/06/2016.
 */
public class PromotionJmsLogImpl implements PromotionJmsLog {
	private static final org.slf4j.Logger LOGGER = (org.slf4j.Logger) LoggerFactoryWrapper
			.getLogger(PromotionJmsLogImpl.class);
	private static long promotionCount = 0;
	private static long promotionHierarchyCount = 0;
	private static long promotionMasterCount = 0;
	private static long prodOfferCount = 0;
	private static long lookupCount = 0;
	private static long prodOfferDeleteCount = 0;
	private static long promotionDeleteCount = 0;
	private static long promotionMasterDeleteCount = 0;
	private static long promotionLookUpDeleteCount = 0;
	private static long promotionHierarchyDeleteCount = 0;

	private static PromotionJmsLog promotionMsgCounter = null;

	private PromotionJmsLogImpl() {
	}

	public static synchronized PromotionJmsLog getInstance() {
		if (promotionMsgCounter == null) {
			promotionMsgCounter = new PromotionJmsLogImpl();
		}
		return promotionMsgCounter;
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		throw new CloneNotSupportedException("Not allowed to clone");
	}

	@Override
	public void updateCounterForCreMsg(String docType) {
		if (docType.equals(PriceConstants.PROMOTION_DOCUMENT)) {
			promotionCount++;
		}
		if (docType.equals(PriceConstants.PROMOTION_LOOKUP_DOCUMENT)) {
			lookupCount++;
		}
		if (docType.equals(PriceConstants.PROMOTION_MASTER_DOCUMENT)) {
			promotionMasterCount++;
		}
		if (docType.equals(PriceConstants.PROMOTION_PRODOFFERS_DOCUMENT)) {
			prodOfferCount++;
		}
		if (docType.equals(PriceConstants.PROMOTION_HIERARCHY_DOCUMENT)) {
			promotionHierarchyCount++;
		}

	}

	@Override
	public void updateCounterForModMsg(String docType) {
		if (docType.equals(PriceConstants.DELETE_PRODOFFERS_DOCUMENT)) {
			prodOfferDeleteCount++;
		}
		if (docType.equals(PriceConstants.DELETE_PROMOTION_DOCUMENT)) {
			promotionDeleteCount++;
		}
		if (docType.equals(PriceConstants.DELETE_PROMOTION_MASTER_DOCUMENT)) {
			promotionMasterDeleteCount++;
		}
		if (docType.equals(PriceConstants.DELETE_PROMOTION_LOOKUP_DOCUMENT)) {
			promotionLookUpDeleteCount++;
		}
		if (docType.equals(PriceConstants.DELETE_PROMOTION_HIERARCHY_DOCUMENT)) {
			promotionHierarchyDeleteCount++;
		}

	}

	@Override
	public String printMetricsSnasphot() {
		return "{\"promotionCount\":" + promotionCount + ",\"promotionHierarchyCount\":" + promotionHierarchyCount
				+ ",\"promotionMasterCount\":" + promotionMasterCount + ",\"prodOfferCount\":" + prodOfferCount
				+ ",\"lookupCount\":" + lookupCount + ",\"prodOfferDeleteCount\":" + prodOfferDeleteCount
				+ ",\"promotionDeleteCount\":" + promotionDeleteCount + ",\"promotionMasterDeleteCount\":"
				+ promotionMasterDeleteCount + ",\"promotionLookUpDeleteCount\":" + promotionLookUpDeleteCount
				+ ",\"promotionHierarchyDeleteCount\":" + promotionHierarchyDeleteCount + "}";
	}

	@Override
	public void resetMetricsSnapshot() {
		promotionCount = 0;
		promotionHierarchyCount = 0;
		promotionMasterCount = 0;
		prodOfferCount = 0;
		lookupCount = 0;
		prodOfferDeleteCount = 0;
		promotionDeleteCount = 0;
		promotionMasterDeleteCount = 0;
		promotionLookUpDeleteCount = 0;
		promotionHierarchyDeleteCount = 0;
	}

}
