package com.tesco.services.adapters.rpm.writers.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tesco.couchbase.AsyncCouchbaseWrapper;
import com.tesco.couchbase.CouchbaseWrapper;
import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.exceptions.WriterBusinessException;
import com.tesco.services.adapters.rpm.writers.FileProcessor;
import com.tesco.services.core.Ean;
import com.tesco.services.exceptions.DataAccessException;
import com.tesco.services.repositories.Repository;
import com.tesco.services.repositories.RepositoryImpl;
import com.tesco.services.resources.TeauthPriceChecksResource;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.FileOperations;
import com.tesco.services.utility.PriceConstants;
import com.tesco.services.utility.WebServiceCallBuilder;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;
import io.dropwizard.servlets.assets.ResourceNotFoundException;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Response;
import java.io.*;
import java.util.*;

/**
 * Created by QU17 on 18/03/2015.
 */
public class TeauthFileProcessor implements FileProcessor {
	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(TeauthFileProcessor.class);
	private Configuration configuration;
	private CouchbaseWrapper couchbaseWrapper;
	private AsyncCouchbaseWrapper asyncCouchbaseWrapper;
	private String fileName;
	private String identifiedFailedLine = "";
	private Dockyard dockyard;
	private FileOperations fileOperations;
	private String lastLine;
	private BufferedReader teauthReader;
	private Repository repository;
	private WebServiceCallBuilder webServiceCallBuilder;
	private Response clientResponse;
	private Map<String, String> tpncToEanMapFromProdServices = new LinkedHashMap<>();
	private String runType;

	public void setFileOperations(FileOperations fileOperations) {
		this.fileOperations = fileOperations;
	}

	public Set<String> getPriceCheckFileDetails() {
		return priceCheckFileDetails;
	}

	public void setPriceCheckFileDetails(Set<String> priceCheckFileDetails) {
		this.priceCheckFileDetails = priceCheckFileDetails;
	}

	Set<String> priceCheckFileDetails = new LinkedHashSet<>();
	String storeId;
	int linesCount = 1;

	public void setWebServiceCallBuilder(
			WebServiceCallBuilder webServiceCallBuilder) {
		this.webServiceCallBuilder = webServiceCallBuilder;
	}

	public String getRunType() {
		return runType;
	}

	public void setRunType(String runType) {
		this.runType = runType;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	/**
	 * @param configuration
	 * @param couchbaseWrapper
	 * @param asyncCouchbaseWrapper
	 */
	@Inject
	public TeauthFileProcessor(
			@Named("configuration") Configuration configuration,
			@Named("couchbaseWrapper") CouchbaseWrapper couchbaseWrapper,
			@Named("asyncCouchbaseWrapper") AsyncCouchbaseWrapper asyncCouchbaseWrapper,
			@Named("webServiceCallBuilder") WebServiceCallBuilder webServiceCallBuilder) {
		this.configuration = configuration;
		this.couchbaseWrapper = couchbaseWrapper;
		this.asyncCouchbaseWrapper = asyncCouchbaseWrapper;
		this.webServiceCallBuilder = webServiceCallBuilder;

	}

	public TeauthFileProcessor(Configuration configuration,
			CouchbaseWrapper couchbaseWrapper,
			AsyncCouchbaseWrapper asyncCouchbaseWrapper,
			WebServiceCallBuilder webServiceCallBuilder,
			BufferedReader teauthReader) {
		this.configuration = configuration;
		this.couchbaseWrapper = couchbaseWrapper;
		this.asyncCouchbaseWrapper = asyncCouchbaseWrapper;
		this.webServiceCallBuilder = webServiceCallBuilder;
		this.teauthReader = teauthReader;

	}

	public void clearpriceCheckFileDetails() {
		priceCheckFileDetails.clear();
	}

	public void initTeauthReader() throws WriterBusinessException {
		String filePath = configuration.getTeauthFilePath() + "/" + runType
				+ "/" + fileName;
		fileOperations = getFileOperationsInstance();
		File teauthfile = fileOperations.getFile(filePath);
		FileReader reader = null;
		try {
			reader = fileOperations.getFileReader(teauthfile);
			teauthReader = fileOperations.getBufferedReader(reader);
		} catch (FileNotFoundException e) {
			LOGGER.error("Error occured in initializing teauthReader.", e);
			throw new WriterBusinessException(e.getMessage(), e.getCause());
		}
	}

	public void readAndProcessFile() throws WriterBusinessException {

		if (teauthReader == null) {
			initTeauthReader();
		}

		fileOperations = getFileOperationsInstance();
		storeId = fileName.split("_")[0];
		storeId = storeId.substring(storeId.length() - 4);
		priceCheckFileDetails.add("TEAUTH validation started - store "
				+ storeId);

		try {
			String failedProduct = fileOperations
					.getfailedProductInProviousRunIfExist(configuration,
							"/RR_TEAUTH_" + fileName + ".txt");
			if (failedProduct != null && failedProduct.length() != 0) {
				identifiedFailedLine = failedProduct;
				LOGGER.info("Ean :" + identifiedFailedLine
						+ " failed in Last Run from  " + fileName
						+ " Check process restart from this product");
				fileOperations.deletefailedProductInProviousRun(configuration,
						"/RR_TEAUTH_" + fileName + ".txt");
			}
			comparePrices();
		} catch (IOException e) {
			LOGGER.error(
					"Exception occurred in getting failedProduct details of previous run.",
					e);
			throw new WriterBusinessException(e.getMessage(), e.getCause());
		} catch (Exception exception) {
			TeauthPriceChecksResource.setErrorString(fileName,
					exception.toString());
			try {
				fileOperations.writeFailedProductDetailsToFile(configuration,
						"/RR_TEAUTH_" + fileName + ".txt", lastLine);
			} catch (IOException e) {

				LOGGER.error(
						"Error while creating Error/Reject file for  file : {} ErrorMsg : {}",
						fileName, exception.toString());
			}

			LOGGER.error(
					"Error while Processing Price Checks for file : {} ErrorMsg : {}",
					fileName, exception.toString());

		} finally {
			priceCheckFileDetails.add("TEAUTH validation ended - store "
					+ storeId);
			TeauthPriceChecksResource.getPriceChecksSemaphore(fileName)
					.release();
			if (!priceCheckFileDetails.isEmpty()) {
				String date = Dockyard.getSysDate("yyyyMMddHHmmss");
				getDockyard().writeProductDetailsToFile(
						configuration.getRejectFilePath()
								+ "/PRICE_CHECK_FILE_" + fileName + "_" + date
								+ ".log", priceCheckFileDetails);
				if (configuration.getRejectFilePath() != null) {
					clearpriceCheckFileDetails();
				}
			}
		}
	}

	private FileOperations getFileOperationsInstance() {
		if (fileOperations == null) {
			fileOperations = new FileOperations();
		}
		return fileOperations;

	}

	private void comparePrices() throws IOException {
		String line;
		String curLine;
		boolean continueLoop = false;
		Set<String[]> eanDataSet = new LinkedHashSet<>();
		repository = new RepositoryImpl(couchbaseWrapper,
				asyncCouchbaseWrapper, new ObjectMapper());
		while ((line = teauthReader.readLine()) != null) {
			if (!(line.startsWith("1")) && line.length() != 0) {
				curLine = line;
				lastLine = curLine;
				if (identifiedFailedLine.length() == 0
						|| curLine.equals(identifiedFailedLine) || continueLoop) {
					continueLoop = true;
					if (linesCount < PriceConstants.TEAUTH_RECORD_COUNT_LIMIT
							&& !line.startsWith("9")) {
						String[] eanData = { line.substring(2, 39),
								line.substring(39, 76) };
						eanDataSet.add(eanData);
						linesCount++;
					} else {
						linesCount = 1;
						eanLineProcessor(eanDataSet);
						eanDataSet = new LinkedHashSet<>();
					}
				}
			}
		}
		teauthReader.close();
		LOGGER.info("Successfully Compared Prices for {}", fileName);

	}

	public Dockyard getDockyard() {

		if (dockyard == null) {
			dockyard = new Dockyard();
		}
		return dockyard;
	}

	public void eanLineProcessor(Set<String[]> eanDetailsSet) {
		Map<String, String> eanToAuthPriceMap = new LinkedHashMap<>();
		Set<String> eanKeySet = new LinkedHashSet<>();
		try {
			for (String[] eansInline : eanDetailsSet) {
				for (int i = 0; i < eansInline.length; i++) {
					String eanDetails = eansInline[i];
					String ean = eanDetails.substring(0, 13).replace(" ", "0");
					String authPrice = eanDetails.substring(21, 29);
					eanKeySet.add(PriceConstants.EAN_KEY_PREFIX + ean);
					eanToAuthPriceMap.put(ean, authPrice);
				}
			}
			Map<String, Map<String, String>> tpncMapList = getTpncMapListForEans(eanKeySet);
			Map<String, String> tpncMap = tpncMapList
					.get(PriceConstants.GET_PRICE_LIST_DATA);
			if (!tpncMap.isEmpty()) {
				Set<String> tpncKeySet = tpncMap.keySet();
				clientResponse = webServiceCallBuilder
						.getResponseFromRemoteServerForProductsListWithStore(
								tpncKeySet, storeId);
				if (clientResponse.getStatus() == HttpServletResponse.SC_OK) {
					Map<String, Object> actualResponse = clientResponse
							.readEntity(Map.class);
					comparePricesAndWriteToCollectionOnMismatches(
							actualResponse, eanToAuthPriceMap, tpncMap);
				} else {
					String errorMsg = clientResponse.readEntity(String.class);
					LOGGER.info(
							"Get Price for List Failed - store : {}  Tpncs : {} Message from PS : {} ",
							storeId, tpncKeySet, errorMsg);
					priceCheckFileDetails
							.add("Get Price for List Failed - store : "
									+ storeId + " || Tpncs : " + tpncKeySet
									+ " || Message from PS : " + errorMsg);

				}
			}
			Map<String, String> eanNotFoundMap = tpncMapList
					.get(PriceConstants.GET_PRICE_LIST_ERRORS);
			if (!eanNotFoundMap.isEmpty()) {
				processMissedEansInPriceServices(eanNotFoundMap);
			}
			if (!tpncToEanMapFromProdServices.isEmpty()) {
				Set<String> tpncKeySet = tpncToEanMapFromProdServices.keySet();
				clientResponse = webServiceCallBuilder
						.getResponseFromRemoteServerForProductsListWithStore(
								tpncKeySet, storeId);
				if (clientResponse.getStatus() == HttpServletResponse.SC_OK) {
					Map<String, Object> actualResponse = clientResponse
							.readEntity(Map.class);
					comparePricesAndWriteToCollectionOnMismatches(
							actualResponse, eanToAuthPriceMap,
							tpncToEanMapFromProdServices);
				} else {
					String errorMsg = clientResponse.readEntity(String.class);
					LOGGER.info(
							"Get Price for List Failed - store : {}  Tpncs : {} Message from PS : {} ",
							storeId, tpncKeySet, errorMsg);
					priceCheckFileDetails
							.add("Get Price for List Failed - store : "
									+ storeId + " || Tpncs : " + tpncKeySet
									+ " || Message from PS : " + errorMsg);

				}
			}

		} catch (Exception e) {
			for (String[] eansInline : eanDetailsSet) {
				for (int i = 0; i < eansInline.length; i++) {
					String eanDetails = eansInline[i];
					String ean = eanDetails.substring(0, 13).replace(" ", "0");
					LOGGER.error("Processing error: {}{}{}", ean, ": ",
							e.toString(), e);
					priceCheckFileDetails
							.add("TEAUTH File Check failed for Ean  " + ean
									+ " || Error Message : " + e.toString());
				}
			}

		} finally {
			tpncToEanMapFromProdServices.clear();
		}
	}

	private void comparePricesAndWriteToCollectionOnMismatches(
			Map<String, Object> actualResponse, Map<String, String> eanMap,
			Map<String, String> tpncMap) {

		String authPriceFromResponse;
		String authPriceFromTeauthFile;
		List<Map<String, Object>> actualDataList = (List) actualResponse
				.get(PriceConstants.GET_PRICE_LIST_DATA);
		for (Map<String, Object> actualDataMap : actualDataList) {
			final Set<Map<String, Object>> variants = new HashSet(
					(Collection) actualDataMap.get(PriceConstants.VARIANTS));
			for (Map<String, Object> variantInfo : variants) {
				authPriceFromResponse = (String) variantInfo
						.get(PriceConstants.AUTH_PRICE);
				authPriceFromTeauthFile = eanMap.get(tpncMap.get(
						variantInfo.get(PriceConstants.TPNC_IDENTIFIER)).split(
						"_")[1]);
				if (!authPriceFromResponse.trim().equals(
						authPriceFromTeauthFile.trim())) {
					String ean = tpncMap.get(
							variantInfo.get(PriceConstants.TPNC_IDENTIFIER))
							.split("_")[1];
					String tpnc = (String) variantInfo
							.get(PriceConstants.TPNC_IDENTIFIER);
					priceCheckFileDetails.add("TEAUTH Price error - store : "
							+ storeId + " || item ean : " + ean + " || tpnc : "
							+ tpnc + " || TEAUTH price : "
							+ authPriceFromTeauthFile.trim()
							+ " || Price service price : "
							+ authPriceFromResponse.trim());
					LOGGER.info(
							"TEAUTH Price error - store : {} || item ean : {} || tpnc : {} || TEAUTH price : {} || Price service price : {}",
							storeId, ean, tpnc, authPriceFromTeauthFile.trim(),
							authPriceFromResponse.trim());

				}
			}
		}
		List<Map<String, Object>> actualErrorList = (List) actualResponse
				.get(PriceConstants.GET_PRICE_LIST_ERRORS);
		for (Map<String, Object> actualErrorMap : actualErrorList) {
			String ean = tpncMap.get(
					actualErrorMap.get(PriceConstants.ERROR_PROD_ID))
					.split("_")[1];
			String errorMsg = (String) actualErrorMap
					.get(PriceConstants.ERROR_MESSAGE);
			priceCheckFileDetails
					.add("TEAUTH Item not in price service - store : "
							+ storeId + " || item ean : " + ean
							+ " || Message from PS : " + errorMsg);
			LOGGER.info(
					"TEAUTH Item not in price service - store : {} || item ean : {} || Message from PS : {}",
					storeId, ean, errorMsg);
		}
	}

	public void processMissedEansInPriceServices(
			Map<String, String> eansNotFoundMap) {
		Set<String> eanKeys = eansNotFoundMap.keySet();
		List<String> eanListForProdServices = new ArrayList<>();
		for (String ean : eanKeys) {
			eanListForProdServices.add(ean.split("_")[1]);
			if (eanListForProdServices.size() == PriceConstants.PRODUCT_SERVICE_CALL_LIMIT) {
				callProductService(eanListForProdServices);
				eanListForProdServices.clear();
			}
		}
		if (!eanListForProdServices.isEmpty()) {
			callProductService(eanListForProdServices);
			eanListForProdServices.clear();
		}
	}

	/**
	 *
	 * @param eanList
	 *            contains list of EANs processed from file The method
	 *            callProductService will make call to Product Service get call
	 *            (with MAX 20 EAN) to get the corresponding TPNCs for EAN
	 */

	public void callProductService(List<String> eanList) {
		String productServiceUrl;
		productServiceUrl = createProductServiceUrl(eanList);
		String tpnc = null;
		String ean = null;

		try {

			clientResponse = webServiceCallBuilder
					.getResponseFromProdServices(productServiceUrl);

			if (clientResponse.getStatus() == HttpServletResponse.SC_NOT_FOUND) {
				throw new ResourceNotFoundException(new Exception(
						"The URL trying to reach could not be found on the server. URL : "
								+ productServiceUrl));
			}

			if (clientResponse.getStatus() == HttpServletResponse.SC_INTERNAL_SERVER_ERROR) {
				throw new ServletException(
						"HTTP 500 - Internal Server Error. URL : "
								+ productServiceUrl);
			}

			if (clientResponse.getStatus() == HttpServletResponse.SC_OK) {

				Map actualProductPriceInfo = clientResponse
						.readEntity(Map.class);
				for (Object innermap : (List<String>) actualProductPriceInfo
						.get(PriceConstants.PRODUCT_SERVICE_RESPONSE_PRODUCTS)) {
					if (innermap != null) {
						tpnc = null;
						ean = null;
						if (((HashMap) innermap)
								.get(PriceConstants.PRODUCT_SERVICE_RESPONSE_GTIN14) != null) {
							ean = ((HashMap) innermap)
									.get(PriceConstants.PRODUCT_SERVICE_RESPONSE_GTIN14)
									.toString();
						} else {
							LOGGER.warn(
									"EAN mapping not found for TPNC {} - store {}",
									((HashMap) innermap)
											.get(PriceConstants.PRODUCT_SERVICE_RESPONSE_TPNC)
											.toString(), storeId);
							priceCheckFileDetails
									.add("EAN mapping not found for TPNC : "
											+ ((HashMap) innermap)
													.get(PriceConstants.PRODUCT_SERVICE_RESPONSE_TPNC)
													.toString() + " - store : "
											+ storeId);
						}

						if (((HashMap) innermap)
								.get(PriceConstants.PRODUCT_SERVICE_RESPONSE_TPNC) != null) {
							tpnc = ((HashMap) innermap)
									.get(PriceConstants.PRODUCT_SERVICE_RESPONSE_TPNC)
									.toString();
						} else {
							LOGGER.warn(
									"TPNC mapping not available in product service - store {} item EAN {}",
									storeId, ean);
							priceCheckFileDetails
									.add("TPNC mapping not available in product service - store :"
											+ storeId + ":: item EAN :" + ean);
						}

						if (ean != null && tpnc != null) {
							insertEanTpncMappingToCouchbase(
									ean.substring(1, 14), tpnc);
						}
					}
				}

				for (Object list : (List) actualProductPriceInfo
						.get(PriceConstants.PRODUCT_SERVICE_RESPONSE_MISSING_SET)) {
					LOGGER.warn(
							"TEAUTH Invalid EAN, not available in product service - store {} item ean {}",
							storeId, list.toString());
					priceCheckFileDetails
							.add("TEAUTH Invalid EAN, not available in product service - store "
									+ storeId + " item ean " + list.toString());
				}
			} else {
				LOGGER.warn("The status code from Product Service is {}",
						clientResponse.getStatus());
				TeauthPriceChecksResource.setErrorString(fileName,
						"The status code from Product Service is {}"
								+ clientResponse.getStatus());
			}

		} catch (Exception e) {
			priceCheckFileDetails
					.add("TEAUTH EAN Seeding Failed :: Error Msg : "
							+ e.toString());
			LOGGER.error(
					"Error seeding EAN from TEAUTH file {} :: Error Msg {}",
					fileName, ean, e);
		}
	}

	public Map<String, String> getTpncToEanMapFromProdServices() {
		return tpncToEanMapFromProdServices;
	}

	/**
	 *
	 * @param ean
	 *            holds the EAN number
	 * @param tpnc
	 *            holds corresponding TPNC for EAN number The method
	 *            insertEanTpncMappingToCouchbase will insert EAN document into
	 *            PriceService couchbase bucket
	 */
	private void insertEanTpncMappingToCouchbase(String ean, String tpnc)
			throws Exception {

		final String sysdate = Dockyard.getSysDate("yyyyMMdd");
		Ean eanObject = new Ean(tpnc);
		eanObject.setLastUpdatedDate(sysdate);
		if (repository == null) {
			repository = new RepositoryImpl(couchbaseWrapper,
					asyncCouchbaseWrapper, new ObjectMapper());
		}
		tpncToEanMapFromProdServices
				.put(tpnc, PriceConstants.EAN_KEY_PREFIX + ean);
		repository
				.insertObject(PriceConstants.EAN_KEY_PREFIX + ean, eanObject);
	}

	/**
	 *
	 * @param eanList
	 * @return url for product service get call contain n numbers of EAN
	 */

	public String createProductServiceUrl(List<String> eanList) {
		String url = configuration.getproductServiceUrl();
		for (int i = 0; i < eanList.size(); i++) {
			url = url + "gtin=" + eanList.get(i) + "&";
		}
		return url + "fields=TPNC&fields=GTIN14";
	}

	public Map<String, Map<String, String>> getTpncMapListForEans(
			Set<String> eans) {
		Map<String, String> tpncNotFoundMap = new LinkedHashMap<>();
		Map<String, String> tpncMap = new LinkedHashMap<>();
		Map<String, Map<String, String>> tpncMapList = new LinkedHashMap<>();
		Ean ean  = null;
		for (String item : eans) {
			try {
				ean = (Ean) repository.getGenericObject(item,Ean.class);
			} catch (DataAccessException e) {
				LOGGER.error("Error occurred in getting Ean object for key:"+item);
			}
			if (ean != null) {

				String tpnc = ean.getTpnc();
				if (tpnc != null) {
					tpncMap.put(tpnc, item);
				} else {
					tpncNotFoundMap.put(item, "Not Found in Price Services");
				}
			} else {
				tpncNotFoundMap.put(item, "Not Found in Price Services");

			}

		}
		tpncMapList.put(PriceConstants.GET_PRICE_LIST_DATA, tpncMap);
		tpncMapList.put(PriceConstants.GET_PRICE_LIST_ERRORS, tpncNotFoundMap);

		return tpncMapList;
	}

	public void setRepository(RepositoryImpl repository) {
		this.repository = repository;
	}
}
