package com.tesco.services.adapters.core.utils;

import com.codahale.metrics.Counter;
import com.codahale.metrics.JmxReporter;
import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.Timer;
import com.codahale.metrics.Timer.Context;

public class PromotionMetrics {

	static PromotionMetrics promotionMetrics;

	private static MetricRegistry metricRegisty;

	private static Timer simplePromoMessagesCreMod;

	Context simplePromoMessagesCreModTC;
	private static Timer simplePromoMessagesDel;

	Context simplePromoMessagesDelTC;
	private static Timer thresholdMessagesCreMod;

	Context thresholdMessagesCreModTC;
	private static Timer thresholdMessagesDel;

	Context thresholdMessagesDelTC;
	private static Timer multibuyPromoMessagesCreMod;

	Context multibuyPromoMessagesCreModTC;
	private static Timer multibuyPromoMessagesDel;

	Context multibuyPromoMessagesDelTC;
	private static Timer messageListenerTimer;

	Context messageTimerContext;
	private static Counter errorCounter;

	private PromotionMetrics(MetricRegistry myMetricRegisty) {
		metricRegisty = myMetricRegisty;
	}

	public static synchronized PromotionMetrics getInstance() {
		if (promotionMetrics == null) {
			metricRegisty = new MetricRegistry();
			promotionMetrics = new PromotionMetrics(metricRegisty);
			JmxReporter.forRegistry(metricRegisty).build();
			init();
		}
		return promotionMetrics;
	}

	public static MetricRegistry getMetricRegisty() {
		return metricRegisty;
	}

	public void incrementErrorCount() {
		errorCounter.inc();
	}

	private static void init() {
		simplePromoMessagesCreMod = metricRegisty.timer(MetricRegistry.name(
				"com.tesco", "SimplePromotionElapsedTimeAndRate",
				"time-to-process-cre-mod-message"));

		simplePromoMessagesDel = metricRegisty.timer(MetricRegistry.name(
				"com.tesco", "SimplePromotionElapsedTimeAndRate",
				"time-to-process-del-message"));

		thresholdMessagesCreMod = metricRegisty.timer(MetricRegistry.name(
				"com.tesco", "ThresholdPromotionElapsedTimeAndRate",
				"time-to-process-cre-mod-message"));

		thresholdMessagesDel = metricRegisty.timer(MetricRegistry.name(
				"com.tesco", "ThresholdPromotionElapsedTimeAndRate",
				"time-to-process-del-message"));

		multibuyPromoMessagesCreMod = metricRegisty.timer(MetricRegistry.name(
				"com.tesco", "MultibuyPromotionElapsedTimeAndRate",
				"time-to-process-cre-mod-message"));

		multibuyPromoMessagesDel = metricRegisty.timer(MetricRegistry.name(
				"com.tesco", "MultibuyPromotionElapsedTimeAndRate",
				"time-to-process-del-message"));

		messageListenerTimer = metricRegisty.timer(MetricRegistry.name(
				"com.tesco", "OverallPromotionElapsedTimeAndRate",
				"time-to-process-message"));

		errorCounter = metricRegisty.counter(MetricRegistry.name("com.tesco",
				"PromotionMessageProcessingErrors", "total-error-count"));

	}

	public void logMessageProcessingEndTime() {
		messageTimerContext.stop();
	}

	public void logMessageProcessingStartTime() {
		messageTimerContext = messageListenerTimer.time();
	}

	public void logMultibuyCreModPromoProcessingEndTime() {
		multibuyPromoMessagesCreModTC.stop();
	}

	public void logMultibuyCreModPromoProcessingStartTime() {
		multibuyPromoMessagesCreModTC = multibuyPromoMessagesCreMod.time();
	}

	public void logMultibuyDelPromoProcessingEndTime() {
		multibuyPromoMessagesDelTC.stop();
	}

	public void logMultibuyDelPromoProcessingStartTime() {
		multibuyPromoMessagesDelTC = multibuyPromoMessagesDel.time();
	}

	public void logSimpleCreModPromoProcessingEndTime() {
		simplePromoMessagesCreModTC.stop();
	}

	public void logSimpleCreModPromoProcessingStartTime() {
		simplePromoMessagesCreModTC = simplePromoMessagesCreMod.time();
	}

	public void logSimpleDelPromoProcessingEndTime() {
		simplePromoMessagesDelTC.stop();
	}

	public void logSimpleDelPromoProcessingStartTime() {
		simplePromoMessagesDelTC = simplePromoMessagesDel.time();
	}

	public void logThresholdCreModPromoProcessingEndTime() {
		thresholdMessagesCreModTC.stop();
	}

	public void logThresholdCreModPromoProcessingStartTime() {
		thresholdMessagesCreModTC = thresholdMessagesCreMod.time();
	}

	public void logThresholdDelPromoProcessingEndTime() {
		thresholdMessagesDelTC.stop();
	}

	public void logThresholdDelPromoProcessingStartTime() {
		thresholdMessagesDelTC = thresholdMessagesDel.time();
	}

	public void resetMetrics() {
		metricRegisty = new MetricRegistry();
		init();
	}
}
