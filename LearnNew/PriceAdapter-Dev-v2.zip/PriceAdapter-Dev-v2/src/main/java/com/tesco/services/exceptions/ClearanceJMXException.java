package com.tesco.services.exceptions;


public class ClearanceJMXException extends Exception {
    public ClearanceJMXException() {
        // TODO Auto-generated constructor stub
    }

    public ClearanceJMXException(String message) {
        super(message);
        // TODO Auto-generated constructor stub
    }

    public ClearanceJMXException(Throwable cause) {
        super(cause);
        // TODO Auto-generated constructor stub
    }

    public ClearanceJMXException(String message, Throwable cause) {
        super(message, cause);
        // TODO Auto-generated constructor stub
    }

    public ClearanceJMXException(String message, Throwable cause,
                                  boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
        // TODO Auto-generated constructor stub
    }
}
