package com.tesco.services.adapters.rpm.writers.impl;

import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.exceptions.ColumnNotFoundException;
import com.tesco.services.adapters.core.exceptions.WriterBusinessException;
import com.tesco.services.adapters.rpm.readers.PriceServiceCSVReader;
import com.tesco.services.adapters.rpm.readers.impl.PriceServiceRPMClearanceCSVReaderImpl;
import com.tesco.services.adapters.rpm.writers.CSVHeaders;
import com.tesco.services.adapters.rpm.writers.Writer;
import com.tesco.services.core.SubGroupContentEntity;
import com.tesco.services.repositories.Repository;
import com.tesco.services.repositories.RepositoryImpl;
import com.tesco.services.resources.ImportResource;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.PriceConstants;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import static org.apache.commons.lang.StringUtils.isNumeric;

public class RPMSubGroupDfltUomMapper implements Writer {

	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger("RPM SubGroup Default UOM Import");

	private Configuration configuration;
	private String runIdentifier;
	private Repository repository;
	private PriceServiceCSVReader rpmUOMMappingReader;
	private Dockyard dockyard;
	private SubGroupContentEntity subGroupEntity = new SubGroupContentEntity();

	@Inject
	public RPMSubGroupDfltUomMapper(
			@Named("configuration") Configuration configuration,
			@Named("repository") Repository repository) {
		this.configuration = configuration;
		this.repository = repository;
	}

	public RPMSubGroupDfltUomMapper(Configuration configuration,
			RepositoryImpl repository,
			PriceServiceCSVReader rpmUOMMappingReader) {
		this.configuration = configuration;
		this.repository = repository;
		this.rpmUOMMappingReader = rpmUOMMappingReader;
	}

	public String getRunIdentifier() {
		return runIdentifier;
	}

	public void setRunIdentifier(String runIdentifier) {
		this.runIdentifier = runIdentifier;
	}

	public PriceServiceCSVReader createSubGroupDefaultUOMReader(String fileName)
			throws WriterBusinessException {

		PriceServiceCSVReader csvreader = null;

		try {
			csvreader = new PriceServiceRPMClearanceCSVReaderImpl(
					configuration.getRpmSubgroupDataDumpPath() + "/"
							+ runIdentifier + "/" + fileName,
					CSVHeaders.SubGroupDefaultUOMHeaders.HEADERS);
		} catch (IOException | ColumnNotFoundException e) {
			LOGGER.error(
					"Error occured while initializing PriceServiceCSVReader", e);
			throw new WriterBusinessException(e.getMessage(), e.getCause());
		}
		return csvreader;
	}

	public void write(String fileName) throws WriterBusinessException {
		LOGGER.info("Importing Converstion factor into Couchbase");

		if (rpmUOMMappingReader == null) {
			this.rpmUOMMappingReader = createSubGroupDefaultUOMReader(fileName);
		}

		try {
			writeUOMMappingToCB();

		} catch (ArrayIndexOutOfBoundsException exception) {
			ImportResource.setErrorString(runIdentifier,
					"Array index out of bound Exception");
			LOGGER.error("Error importing data", exception.getMessage());
		} catch (Exception e) {
			ImportResource.setErrorString(runIdentifier, e.toString());
			LOGGER.error("Error importing data", e);
			throw new WriterBusinessException(e.getMessage(), e.getCause());
		} finally {
			ImportResource.getImportSemaphoreForIdentifier(fileName).release();
		}
	}

	private void writeUOMMappingToCB() throws IOException {
		String key = PriceConstants.SUBGRP_DFLT_UOM_KEY;
		Map<String, String> rpmUomMappingMap;
		Map<String, String> mappingEntity = new HashMap<String, String>();
		Set<String> rejectList = new HashSet<>();
		String rejectFilePath = configuration.getRejectFilePath();
		String date = Dockyard.getSysDate("yyyyMMddHHmmss");
		int recordsInsertedCount = 0;
		int recordsRejectedCount = 0;
		int recordsTotalRead = 0;

		while ((rpmUomMappingMap = rpmUOMMappingReader.getNext()) != null) {
			recordsTotalRead++;
			String key1 = null;
			String subGroup = rpmUomMappingMap
					.get(CSVHeaders.SubGroupDefaultUOMHeaders.SUB_GROUP);
			String contentUom = rpmUomMappingMap
					.get(CSVHeaders.SubGroupDefaultUOMHeaders.CONTENT_UOM);
			String dfltUom = rpmUomMappingMap
					.get(CSVHeaders.SubGroupDefaultUOMHeaders.DEFAULT_UOM);
			String conversionFactor = rpmUomMappingMap
					.get(CSVHeaders.SubGroupDefaultUOMHeaders.CONVERSTION_FACTOR);
			if (!Dockyard.isSpaceOrNull(subGroup)
					&& !Dockyard.isSpaceOrNull(dfltUom)
					&& !Dockyard.isSpaceOrNull(contentUom)) {
				key1 = subGroup.concat("-").concat(dfltUom).concat("-")
						.concat(contentUom);
			}

			if (!Dockyard.isSpaceOrNull(key1)
					&& !Dockyard.isSpaceOrNull(conversionFactor)
					&& isNumeric(conversionFactor)) {
				mappingEntity.put(key1, conversionFactor);
			}

			else {
				recordsRejectedCount++;
				rejectList.add(Dockyard
						.getSysDate(PriceConstants.ISO_8601_FORMAT)
						.concat("~<SUBGROUP DEFAULT UOM>~")
						.concat("All fields Should be present for SUBGROUP:")
						.concat(subGroup).concat(" Where content uom :")
						.concat(contentUom).concat(" Where default uom :")
						.concat(dfltUom).concat(" Where conversion factor :")
						.concat(conversionFactor));
			}

		}

		subGroupEntity.setSubgroup(mappingEntity);
		subGroupEntity
				.setLastUpdatedById(PriceConstants.ONETIME_SUBGRP_DFLT_UPDATED_BY);
		subGroupEntity.setLastUpdateDate(Dockyard
				.getSysDate(PriceConstants.ISO_8601_FORMAT));
		subGroupEntity.setRejectedProducts(rejectList);

		try {
			repository.insertObject(key, subGroupEntity);
			recordsInsertedCount++;
		} catch (Exception e) {
			recordsRejectedCount++;
			LOGGER.error(
					"Error occurred when inserting document into couchbase for sub group default: "
							+ key, e);
			rejectList
					.add(Dockyard
							.getSysDate(PriceConstants.ISO_8601_FORMAT)
							.concat("~<SUBGROUP DEFAULT UOM>~")
							.concat("DB Error  when inserting document into couchbase for sub group default: ")
							.concat(key));
			subGroupEntity.setRejectedProducts(rejectList);
		}
		if (!subGroupEntity.getRejectedProducts().isEmpty()) {
			getDockyard().writeProductDetailsToFile(
					rejectFilePath + "/REJECT_FILE_" + runIdentifier + "_"
							+ date + ".log",
					subGroupEntity.getRejectedProducts());
			subGroupEntity.getRejectedProducts().clear();
		}

		// Added for PRIS-2203
		LOGGER.info("SubGroupDefault documents inserted : "
				+ recordsInsertedCount);
		LOGGER.info("SubGroupDefault rows rejected : " + recordsRejectedCount);
		LOGGER.info("Total SubGroupDefault rows read : " + recordsTotalRead);

	}

	public Dockyard getDockyard() {
		if (dockyard == null) {
			dockyard = new Dockyard();
		}
		return dockyard;
	}

	public void setSubGroupEntity(SubGroupContentEntity subGroupEntity) {
		this.subGroupEntity = subGroupEntity;
	}
}
