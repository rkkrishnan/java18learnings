package com.tesco.services.adapters.rpm.readers.impl;

import static com.tesco.services.adapters.core.utils.ExtractionUtils.getHeaderIndex;
import static java.util.Arrays.asList;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.tesco.services.adapters.rpm.readers.PriceServiceCSVReader;
import org.slf4j.Logger;

import au.com.bytecode.opencsv.CSVReader;

import com.tesco.services.adapters.core.exceptions.ColumnNotFoundException;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;

/**
 * Created by QP65 on 14/11/2014.
 */
public class PriceServiceRPMClearanceCSVReaderImpl implements
		PriceServiceCSVReader {

	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(PriceServiceCSVReaderImpl.class);

	private final CSVReader csvReader;
	private Map<String, Integer> headerIndex = new HashMap<>();

	/**
	 * <p>
	 * For reading the header information from csv files
	 * </p>
	 * 
	 * @param filePath
	 * 
	 * @throws java.io.IOException
	 * @throws com.tesco.services.adapters.core.exceptions.ColumnNotFoundException
	 */
	public PriceServiceRPMClearanceCSVReaderImpl(String filePath,
			String... headers) throws IOException, ColumnNotFoundException {
		this(new CSVReader(new InputStreamReader(new FileInputStream(filePath),
				"UTF-8"), '|'), headers);
	}

	public PriceServiceRPMClearanceCSVReaderImpl(CSVReader csvReader,
			String... headers) throws IOException, ColumnNotFoundException {

		this.csvReader = csvReader;
		List<String> headersInCSVFile = asList(headers);

		for (String header : headers) {
			headerIndex.put(header, getHeaderIndex(headersInCSVFile, header));
		}
	}

	@Override
	public Map<String, String> getNext() throws IOException {
		String[] nextLine = csvReader.readNext();

		if (nextLine == null) {
			csvReader.close();
			return null;
		}

		Map<String, String> headerToValue = new HashMap<>();

		for (String header : headerIndex.keySet()) {
			headerToValue.put(header, nextLine[headerIndex.get(header)]);
		}

		return headerToValue;
	}
}
