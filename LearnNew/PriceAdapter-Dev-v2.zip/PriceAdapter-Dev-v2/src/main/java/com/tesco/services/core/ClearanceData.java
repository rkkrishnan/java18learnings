package com.tesco.services.core;

import com.tesco.services.utility.Dockyard;

import java.io.Serializable;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;

/**
 * This class will substring the Line item data for MM clearance file and also sets static variables to Clearance documents
 */
public class ClearanceData implements Serializable{
    String docType = "datedPrice";
    String dateTimeFormat = "ISO8601";
    String countryFormat = "ISO3166";
    String currenrcyFormat = "ISO4217";
    String version = "1.0";
    String prodType = "tpnb";
    String productId="" ;
    String storeId="";
    String zoneId="";
    String effevDate="" ;
    String chargeType="" ;
    String action="" ;
    String currencyCode="" ;
    String clearancePrice="" ;
    String sourceSystem="" ;
    String endDate="" ;
    String eventRef="" ;
    String mkdwnRef="";
    String eventPhase="" ;
    String sellingUom="";

    public String getDocType() {
        return docType;
    }

    public void setDocType(String docType) {
        this.docType = docType;
    }

    public String getDateTimeFormat() {
        return dateTimeFormat;
    }

    public void setDateTimeFormat(String dateTimeFormat) {
        this.dateTimeFormat = dateTimeFormat;
    }

    public String getCountryFormat() {
        return countryFormat;
    }

    public void setCountryFormat(String countryFormat) {
        this.countryFormat = countryFormat;
    }

    public String getCurrenrcyFormat() {
        return currenrcyFormat;
    }

    public void setCurrenrcyFormat(String currenrcyFormat) {
        this.currenrcyFormat = currenrcyFormat;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getProdType() {
        return prodType;
    }

    public void setProdType(String prodType) {
        this.prodType = prodType;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getStoreId() {
        return storeId;
    }

    public void setStoreId(String storeId) {
        this.storeId = storeId;
    }

    public String getZoneId() {
        return zoneId;
    }

    /**
     * Method setZoneId
     * @param zoneId
     */
    public void setZoneId(String zoneId) {
        this.zoneId = zoneId;
    }

    public String getEffevDate() {
        return effevDate;
    }

    /**
     * Method setEffevDate
     * @param effevDate
     */
    public void setEffevDate(String effevDate) {
        this.effevDate = effevDate;
    }

    public String getChargeType() {
        return chargeType;
    }

    /**
     * Method setChargeType
     * @param chargeType
     */
    public void setChargeType(String chargeType) {
        this.chargeType = chargeType;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public String getClearancePrice() {
        return clearancePrice;
    }

    public void setClearancePrice(String clearancePrice) {
        this.clearancePrice = clearancePrice;
    }

    public String getSourceSystem() {
        return sourceSystem;
    }

    public void setSourceSystem(String sourceSystem) {
        this.sourceSystem = sourceSystem;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getEventRef() {
        return eventRef;
    }

    public void setEventRef(String eventRef) {
        this.eventRef = eventRef;
    }

    public String getMkdwnRef() {
        return mkdwnRef;
    }

    public void setMkdwnRef(String mkdwnRef) {
        this.mkdwnRef = mkdwnRef;
    }

    public String getEventPhase() {
        return eventPhase;
    }

    public void setEventPhase(String eventPhase) {
        this.eventPhase = eventPhase;
    }

    public String getSellingUom() {
        return sellingUom;
    }

    public void setSellingUom(String sellingUom) {
        this.sellingUom = sellingUom;
    }

    /**
     * Method getClearanceDataWithStore
     * @param line
     * @return
     * @throws ParseException
     */
    public ClearanceData getClearanceDataWithStore(String line) throws ParseException {

     ClearanceData clearanceData = new ClearanceData();
        clearanceData.setDocType(docType);
        clearanceData.setCountryFormat(countryFormat);
        clearanceData.setCurrenrcyFormat(currenrcyFormat);
        clearanceData.setDateTimeFormat(dateTimeFormat);
        clearanceData.setVersion(version);
        clearanceData.setProdType(prodType);
        clearanceData.setProductId(line.substring(1,10));
        clearanceData.setStoreId(line.substring(14,19).trim());
        clearanceData.setEffevDate(Dockyard.getISO8601FormatStartDate(line.substring(19,27)));
        clearanceData.setChargeType(line.substring(27,28));
        clearanceData.setAction(line.substring(28,29));
        clearanceData.setCurrencyCode(line.substring(29,32));
        clearanceData.setClearancePrice(Dockyard.priceScaleRoundHalfUp(line.substring(29,32),line.substring(32,42)));
        clearanceData.setSourceSystem(line.substring(42,44));
        clearanceData.setEndDate(Dockyard.getISO8601FormatEndDate(line.substring(44,52)));

        return clearanceData;
    }

    /*Added for PS-386 -- Start*/

    /**
     * Method getRPMClearanceStaticData
     * @return Map
     */
    public Map<String,String> getRPMClearanceStaticData(){

        Map<String,String> rpmClearanceData = new HashMap<>();
        rpmClearanceData.put("docType",getDocType());
        rpmClearanceData.put("dateTimeFormat",getDateTimeFormat());
        rpmClearanceData.put("countryFormat",getCountryFormat());
        rpmClearanceData.put("currenrcyFormat",getCurrenrcyFormat());
        rpmClearanceData.put("version",getVersion());
        rpmClearanceData.put("prodType",getProdType());

        return rpmClearanceData;
    }
    /*Added for PS-386 -- End*/
}
