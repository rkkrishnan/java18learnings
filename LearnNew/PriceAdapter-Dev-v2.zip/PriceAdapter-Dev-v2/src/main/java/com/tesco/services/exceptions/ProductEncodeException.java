package com.tesco.services.exceptions;

public class ProductEncodeException extends Exception {

	public ProductEncodeException() {
		// TODO Auto-generated constructor stub
	}

	public ProductEncodeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ProductEncodeException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public ProductEncodeException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ProductEncodeException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
