package com.tesco.services.adapters.price.impl;

import com.tesco.price.core.RegPrcChgDesc;
import com.tesco.price.core.RegPrcChgDtl;
import com.tesco.price.core.RegPrcChgDtlRef;
import com.tesco.price.core.RegPrcChgRef;
import com.tesco.services.adapters.core.exceptions.PriceEventException;
import com.tesco.services.adapters.core.utils.EventMetrics;
import com.tesco.services.adapters.price.PriceEventHandler;
import com.tesco.services.adapters.rpm.writers.PriceMessageWriter;
import com.tesco.services.adapters.rpm.writers.impl.PriceWriter;
import com.tesco.services.core.ZoneEntity;
import com.tesco.services.core.price.PriceByDateTime;
import com.tesco.services.core.price.PriceEntity;
import com.tesco.services.core.price.ProductVariant;
import com.tesco.services.event.core.EventTemplate;
import com.tesco.services.event.core.impl.MapEvent;
import com.tesco.services.event.exception.EventPublishException;
import com.tesco.services.exceptions.DataAccessException;
import com.tesco.services.exceptions.PriceBusinessException;
import com.tesco.services.leadtime.core.LeadTimeUtility;
import com.tesco.services.repositories.Repository;
import com.tesco.services.repositories.RepositoryImpl;
import com.tesco.services.utility.CommonEventPublishingUtility;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.PriceConstants;
import com.tesco.services.utility.PriceUtility;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;

import org.joda.time.DateTime;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.tesco.services.utility.PriceConstants.*;

/**
 * Created by GZ13 on 11/3/2016. JIRA-PRIS-1390 .
 */

public class PriceEventHandlerImpl implements PriceEventHandler {

	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(PriceEventHandlerImpl.class);
	private static final EventMetrics EVENTMETRICS = EventMetrics.getInstance();

	private EventTemplate eventTemplate;
	private PriceMessageWriter priceWriter;
	private Repository repository;

	@Inject
	public PriceEventHandlerImpl(@Named("rtEventTemplate")EventTemplate eventTemplate,
			@Named("priceWriter") PriceMessageWriter priceWriter,
			@Named("repository") Repository repository) {
		this.eventTemplate = eventTemplate;
		this.priceWriter = priceWriter;
		this.repository = repository;
	}

	@Override
	public String processCreEvent(RegPrcChgDesc regularPriceChangeDescription)
			throws PriceEventException, ParseException, DataAccessException {
		LOGGER.info("Start processing PriceChangeCreated Event ...........................");
		String countryCode = null;
		String locationType = regularPriceChangeDescription.getLocType();
		String location = String.valueOf(regularPriceChangeDescription
				.getLocation());
		String messageId = null;
		LOGGER.info("EventType :" + PriceConstants.FUTURE_PRICE_MSG_TYPE_CRE);
		ZoneEntity zoneEntity = (ZoneEntity) repository
				.getGenericObject(PriceConstants.ZONE_KEY + location,
						ZoneEntity.class);
		countryCode = zoneEntity.getTslCountryCode();
		String locationId = countryCode + ":" + locationType + ":" + location;
		LOGGER.info("LocationID :" + locationId);
		List<RegPrcChgDtl> listOfPriceDetails = regularPriceChangeDescription
				.getRegPrcChgDtl();

		for (RegPrcChgDtl priceDetail : listOfPriceDetails) {
			String tpnc = priceDetail.getTslConsumerUnit();
			String priceChangeID = String.valueOf(priceDetail
					.getPriceChangeId());
			try {
				int leadDays = getLeadTime(priceDetail);
				LOGGER.info("Lead Time :" + leadDays);
				if (leadDays > 0) {
					MapEvent eventData = processPriceCreEventData(priceDetail,
							locationType, location,
							PriceConstants.FUTURE_PRICE_MSG_TYPE_CRE,
							locationId, leadDays);
					LOGGER.info("START PUBLISHING EVENT");
					EVENTMETRICS
							.logEventStartTime(PriceConstants.FUTURE_PRICE_MSG_TYPE_CRE);
					messageId = eventTemplate.publishEvent(eventData);
					EVENTMETRICS
							.logEventEndTime(PriceConstants.FUTURE_PRICE_MSG_TYPE_CRE);
					LOGGER.info("******END PUBLISHING EVENT*******");
				} else {
					LOGGER.info(
							"PriceChangeCreated event request for the ProductID: {} with PriceChangeID: {} is not able to process because the LeadTimeDays:{} < 1",
							tpnc, priceChangeID, leadDays);
				}
			} catch (ParseException | EventPublishException e) {
				EVENTMETRICS
						.logEventEndTime(PriceConstants.FUTURE_PRICE_MSG_TYPE_CRE);
				EVENTMETRICS
						.incrementErrorCounter(PriceConstants.FUTURE_PRICE_MSG_TYPE_CRE);
				String errMsg = "Error occured in event publishing";
				LOGGER.error(errMsg + e);
				throw new PriceEventException(errMsg, e);
			}
		}
		return messageId;
	}

	@Override
	public String processScheduledEvent(Map<String, String> priceChangeMapData)
			throws PriceEventException, DataAccessException {
		String messageId = null;
		MapEvent eventData = createEventData(priceChangeMapData);
		try {
			EVENTMETRICS.logEventStartTime(eventData.getEventType());
			messageId = eventTemplate.publishEvent(eventData);
			EVENTMETRICS.logEventEndTime(eventData.getEventType());
			LOGGER.debug("Scheduled event for price change is published with event data : "
					+ eventData);
		} catch (EventPublishException publishException) {
			EVENTMETRICS.logEventEndTime(eventData.getEventType());
			EVENTMETRICS.incrementErrorCounter(eventData.getEventType());
			String errorMessage = "Failed to publish price change event :";
			LOGGER.error(errorMessage, publishException);
			throw new PriceEventException(errorMessage, publishException);
		}
		return messageId;
	}

	private static MapEvent processPriceCreEventData(RegPrcChgDtl priceDetail,
			String locationType, String location, String eventType,
			String locationId, int leadDays) throws ParseException {

		MapEvent event = new MapEvent();
		String tpnc = priceDetail.getTslConsumerUnit();
		String priceChangeID = String.valueOf(priceDetail.getPriceChangeId());
		String key = PriceConstants.PRICE_DOC_KEY_PREFIX
				.concat(priceDetail.getItem().split("-")[0]).concat("_")
				.concat(locationType).concat(location);

		String effectiveDateformat = getEffectiveDateFormat(priceDetail);

		String effectiveDate = Dockyard.getFormattedDate(effectiveDateformat,
				PriceConstants.DATE_FORMAT_YYYYMMDDHHMMSS,
				PriceConstants.ISO_8601_FORMAT);
		effectiveDate = PriceUtility
				.replaceOffsetDesignatorForZeroWithNumerals(effectiveDate);
		LOGGER.info("effectiveDate :" + effectiveDate);

		event = CommonEventPublishingUtility.createPriceEventData(eventType,
				locationId, leadDays, priceChangeID, tpnc, effectiveDate, key);
		event.setEventType(PriceConstants.PRICE_MSG_TYPE_CRE);
		LOGGER.info(
				"Header Entry :CorrelationId: {},LocationId:{},EventType:{},LeadTimeDays:{}",
				key, locationId, eventType, leadDays);
		LOGGER.info(
				"Payload Entry :priceChangeId: {},tpnc:{},effectiveDate: {}",
				priceChangeID, tpnc, effectiveDate);

		return event;
	}

	@Override
	public String processDelEvent(RegPrcChgRef regPrcChgRef,
			Map<String, PriceEntity> mapOfPriceEntities)
			throws PriceEventException, DataAccessException {
		LOGGER.info("Start processing PriceChangeDeleted Event ...........................");

		String countryCode = null;
		String locationType = regPrcChgRef.getLocType();
		String location = String.valueOf(regPrcChgRef.getLocation());
		String messageId = null;
		MapEvent data = new MapEvent();
		data.setEventType(PriceConstants.PRICE_MSG_TYPE_DEL);
		ZoneEntity zoneEntity = (ZoneEntity) repository
				.getGenericObject(PriceConstants.ZONE_KEY + location,
						ZoneEntity.class);
		countryCode = zoneEntity.getTslCountryCode();
		String locationId = countryCode + ":" + locationType + ":" + location;
		LOGGER.info("LocationID :" + locationId);

		List<RegPrcChgDtlRef> listOfPriceDetails = regPrcChgRef
				.getRegPrcChgDtlRef();
		for (RegPrcChgDtlRef priceDetail : listOfPriceDetails) {
			try {
				String priceChangeID = String.valueOf(priceDetail
						.getPriceChangeId());
				PriceEntity priceEntity = getPriceEntity(mapOfPriceEntities,
						priceDetail, locationType, location, priceChangeID);
				if (priceEntity == null) {
					continue;
				}
				String effectiveDateStr = getDelEffectiveDate(priceDetail,
						priceEntity, priceChangeID);

				MapEvent eventData = processPriceDelEventData(priceDetail,
						PriceConstants.FUTURE_PRICE_MSG_TYPE_DEL, locationId,
						locationType, location, effectiveDateStr);
				if (eventData != null) {

					LOGGER.info("START PUBLISHING EVENT");
					EVENTMETRICS
							.logEventStartTime(PriceConstants.FUTURE_PRICE_MSG_TYPE_DEL);

					messageId = eventTemplate.publishEvent(eventData);
					EVENTMETRICS
							.logEventEndTime(PriceConstants.FUTURE_PRICE_MSG_TYPE_DEL);

					LOGGER.info("******END PUBLISHING EVENT*******");
				}
			} catch (ParseException | EventPublishException e) {
				EVENTMETRICS
						.logEventEndTime(PriceConstants.FUTURE_PRICE_MSG_TYPE_DEL);
				EVENTMETRICS
						.incrementErrorCounter(PriceConstants.FUTURE_PRICE_MSG_TYPE_DEL);
				LOGGER.error("Error occured in event publishing" + e);
				throw new PriceEventException(e);
			}

		}
		return messageId;

	}

	private static MapEvent processPriceDelEventData(
			RegPrcChgDtlRef priceDetail, String eventType, String locationId,
			String locationType, String location, String effectiveDateStr)
			throws ParseException {
		MapEvent event = null;

		String tpnc = priceDetail.getTslConsumerUnit();
		String priceChangeID = String.valueOf(priceDetail.getPriceChangeId());
		String key = PriceConstants.PRICE_DOC_KEY_PREFIX
				.concat(priceDetail.getItem().split("-")[0]).concat("_")
				.concat(locationType).concat(location);

		DateTime effectiveDate = new DateTime(effectiveDateStr);
		DateTime publicationDate = new DateTime(
				Dockyard.getSysDate(PriceConstants.ISO_8601_FORMAT));
		int leadDays = LeadTimeUtility.getLeadTime(effectiveDate,
				publicationDate);

		if (leadDays > 0) {

			event = CommonEventPublishingUtility.createPriceEventData(
					eventType, locationId, leadDays, priceChangeID, tpnc,
					effectiveDateStr, key);
			event.setEventType(PriceConstants.PRICE_MSG_TYPE_DEL);

			LOGGER.info(
					"Header Entry :CorrelationId: {},LocationId:{},EventType:{},LeadTimeDays:{}",
					key, locationId, eventType, leadDays);
			LOGGER.info(
					"Payload Entry :priceChangeId: {},tpnc:{},effectiveDate: {}",
					priceChangeID, tpnc, effectiveDate);

		} else {
			LOGGER.info(
					"PriceChangeDeleted event request for the ProductID: {} with PriceChangeID: {} is not able to process because the LeadTimeDays:{} < 1",
					tpnc, priceChangeID, leadDays);

		}

		return event;
	}

	@Override
	public Map<String, PriceEntity> getPriceEntityData(RegPrcChgRef regPrcChgRef)
			throws PriceBusinessException {
		{
			Map<String, PriceEntity> mapOfPriceEntities;
			List<RegPrcChgDtlRef> listOfPriceDetails = regPrcChgRef
					.getRegPrcChgDtlRef();
			String locType = regPrcChgRef.getLocType().toString();
			String loc = String.valueOf(regPrcChgRef.getLocation());

			List<String> docKeys = new ArrayList<>();

			try {

				for (RegPrcChgDtlRef priceDetail : listOfPriceDetails) {
					String item = priceDetail.getItem().split("-")[0];
					docKeys.add(PriceConstants.PRICE_DOC_KEY_PREFIX
							.concat(item).concat("_").concat(locType)
							.concat(loc));
				}
				mapOfPriceEntities = priceWriter.getBulkDeserialized(docKeys,
						PriceEntity.class);

			} catch (Exception e) {
				throw new PriceBusinessException(e.getMessage(), e);
			}

			return mapOfPriceEntities;
		}
	}

	private PriceEntity getPriceEntity(
			Map<String, PriceEntity> mapOfPriceEntities,
			RegPrcChgDtlRef priceDetail, String locationType, String location,
			String priceChangeID) {
		String item = priceDetail.getItem().split("-")[0];
		String key = PriceConstants.PRICE_DOC_KEY_PREFIX.concat(item)
				.concat("_").concat(locationType).concat(location);

		PriceEntity priceEntity = mapOfPriceEntities.get(key);
		if (priceEntity == null) {
			LOGGER.error(
					"No REGPRICE document found item {}, hence no event will generate to delete price change id {}",
					item, priceChangeID);

		}
		return mapOfPriceEntities.get(key);
	}

	private String getDelEffectiveDate(RegPrcChgDtlRef priceDetail,
			PriceEntity priceEntity, String priceChangeID) {

		String tpnc = priceDetail.getTslConsumerUnit();
		String item = priceDetail.getItem().split("-")[0];
		ProductVariant tpncToProductVariant = priceEntity
				.getTpncToProductVariant().get(tpnc);
		if (tpncToProductVariant == null) {
			LOGGER.info(
					"TPNC: {} is not found for item: {} during delete process,so not able to generate event for this request",
					tpnc, item);
		}
		String effectiveDateStr = null;
		for (Map.Entry<String, PriceByDateTime> entry : tpncToProductVariant
				.getEffectiveDate().entrySet()) {
			if (entry.getValue().getPriceRef().equals(priceChangeID)) {
				effectiveDateStr = entry.getValue().getEffvDateTime();
			}
		}
		effectiveDateStr = PriceUtility
				.replaceOffsetDesignatorForZeroWithNumerals(effectiveDateStr);
		return effectiveDateStr;
	}

	private static int getLeadTime(RegPrcChgDtl priceDetail)
			throws ParseException {

		String effectiveDateformat = getEffectiveDateFormat(priceDetail);

		String publicationDate = Dockyard
				.getSysDate(PriceConstants.ISO_8601_FORMAT);

		String effectiveDate = Dockyard.getFormattedDate(effectiveDateformat,
				PriceConstants.DATE_FORMAT_YYYYMMDDHHMMSS,
				PriceConstants.ISO_8601_FORMAT);
		effectiveDate = PriceUtility
				.replaceOffsetDesignatorForZeroWithNumerals(effectiveDate);
		LOGGER.info("publicationDate : {} and effectiveDate : {}",
				publicationDate, effectiveDate);

		DateTime effDateObj = new DateTime(effectiveDate);
		DateTime pubDateObj = new DateTime(publicationDate);
		return LeadTimeUtility.getLeadTime(effDateObj, pubDateObj);

	}

	private static String getEffectiveDateFormat(RegPrcChgDtl priceDetail)
			throws ParseException {
		String effectiveDateformat = PriceUtility.getDate(priceDetail
				.getEffectiveDate().getYear().toString(), priceDetail
				.getEffectiveDate().getMonth().toString(), priceDetail
				.getEffectiveDate().getDay().toString(), priceDetail
				.getEffectiveDate().getHour().toString(), priceDetail
				.getEffectiveDate().getMinute().toString(), priceDetail
				.getEffectiveDate().getSecond().toString());
		return effectiveDateformat;
	}

	private MapEvent createEventData(Map<String, String> priceChangeMap)
			throws DataAccessException {
		MapEvent eventData = new MapEvent();
		Map<String, Object> priceChangePayloadMap = new HashMap<String, Object>();
		Map<String, String> priceChangeHeaderMap = new HashMap<String, String>();
		String correlationKey = buildCorrelationId(priceChangeMap);
		String locationId = buildLocation(priceChangeMap);
		priceChangeHeaderMap.put(EVENT_CORR_ID, EVENT_PREFIX + correlationKey);
		priceChangeHeaderMap.put(LOCATION_ID, locationId);
		priceChangeHeaderMap.put(EVENT_TYPE,
				SCHEDULED_FUTURE_PRICE_MSG_TYPE_CRE);
		priceChangeHeaderMap.put(LEAD_TIME_DAYS, SCHEDULED_EVENT_LEAD_DAY);
		priceChangePayloadMap.put(PRICE_REF,
				priceChangeMap.get(PriceConstants.PRICE_REF));
		priceChangePayloadMap.put(PRODUCT_REF,
				"tpnc:" + priceChangeMap.get(TPNC_IDENTIFIER));
		eventData.setPayloadData(priceChangePayloadMap);
		eventData.setHeaderData(priceChangeHeaderMap);
		eventData.setEventType(SCHEDULED_FUTURE_PRICE_MSG_TYPE_CRE);
		LOGGER.debug(
				"Scheduled event for price change is published with event data {}",
				eventData);

		return eventData;
	}

	private String buildCorrelationId(Map<String, String> priceChangeMap) {
		StringBuilder keyBuilder = new StringBuilder();
		String correlationKey = keyBuilder.append(PRICE_DOC_KEY_PREFIX)
				.append(priceChangeMap.get(PROD_REF).split("-")[0])
				.append(priceChangeMap.get(LOC_TYPE))
				.append(priceChangeMap.get(LOC_REF)).toString();
		return correlationKey;
	}

	private String buildLocation(Map<String, String> priceChangeMap)
			throws DataAccessException {
		StringBuilder buildLocationId = new StringBuilder();
		ZoneEntity zoneEntity = (ZoneEntity) repository.getGenericObject(ZONE_KEY
				+ priceChangeMap.get(LOC_REF), ZoneEntity.class);
		String countryCode = zoneEntity.getTslCountryCode();
		String locationId = buildLocationId.append(countryCode)
				.append(":" + priceChangeMap.get(LOC_TYPE))
				.append(":" + priceChangeMap.get(LOC_REF)).toString();

		return locationId;
	}
}
