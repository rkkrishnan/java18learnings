package com.tesco.services.core;

import java.util.Map;
//Interface ProductPriceVisitor
public interface ProductPriceVisitor {
    public void visit(Product product);
    public void visit(ProductVariant productVariant);
    public void visit(ProductVariant productVariant,String tpnb);
}
