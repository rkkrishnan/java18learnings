package com.tesco.services.resources.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import com.fasterxml.jackson.annotation.JsonProperty;

@ApiModel
public class PromotionRequest {

    @JsonProperty
    @ApiModelProperty(required = true)
    private String offerId;

    @JsonProperty
    @ApiModelProperty(required = true)
    private String itemNumber;

    @JsonProperty
    @ApiModelProperty(required = true)
    private int zoneId;

    public String getOfferId() {
        return offerId;
    }

    public String getItemNumber() {
        return itemNumber;
    }

    public int getZoneId() {
        return zoneId;
    }

    /**
     * Method setOfferId
     * @param offerId
     */
    public void setOfferId(String offerId) {
        this.offerId = offerId;
    }

    /**
     * Method setItemNumber
     * @param itemNumber
     */
    public void setItemNumber(String itemNumber) {
        this.itemNumber = itemNumber;
    }

    /**
     * Method setZoneId
     * @param zoneId
     */
    public void setZoneId(int zoneId) {
        this.zoneId = zoneId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        PromotionRequest that = (PromotionRequest) o;

        if (itemNumber != null ? !itemNumber.equals(that.itemNumber) : that.itemNumber != null) {
            return false;
        }
        if (offerId != null ? !offerId.equals(that.offerId) : that.offerId != null) {
            return false;
        }
        if (zoneId != that.zoneId) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        int result = offerId != null ? offerId.hashCode() : 0;
        result = 31 * result + (itemNumber != null ? itemNumber.hashCode() : 0);
        result = 31 * result + zoneId;
        return result;
    }
}
