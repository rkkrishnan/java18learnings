package com.tesco.services.adapters.core;

import java.util.Date;

import javax.inject.Inject;
import javax.inject.Named;

import org.slf4j.Logger;

import com.tesco.services.adapters.core.exceptions.WriterBusinessException;
import com.tesco.services.adapters.rpm.writers.Writer;
import com.tesco.services.resources.ImportResource;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;

public class ImportJob implements Import {

	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(ImportJob.class);

	// changes for Dropwizard upgrade
	private Writer rpmWriter;

	@Inject
	public ImportJob(@Named("rpmWriter") Writer rpmWriter) {
		this.rpmWriter = rpmWriter;
	}
	//

	private static String errorString = null;

	public static String getErrorString() {
		return errorString;
	}

	public static void setErrorString(String errorString) {
		ImportJob.errorString = errorString;
	}

	@Override
	public void run() {
		LOGGER.info("Firing up imports...");
		startImportProcess();
	}

	public void startImportProcess() {
		try {
			LOGGER.info("Importing data from RPM....");
			rpmWriter.write(null);
			LOGGER.info("Successfully imported data for " + new Date());
		} catch (ArrayIndexOutOfBoundsException exception) {
			setErrorString("Array index out of bound Exception");
			LOGGER.error("Error importing data", exception);
		} catch (WriterBusinessException exception) {
			setErrorString("Import exception occured");
			LOGGER.error("Error importing data", exception);
		} finally {
			ImportResource.getImportSemaphore().release();
		}
	}
}
