package com.tesco.services.resources;

import static com.tesco.services.utility.PriceConstants.CLEARANCE_END_EVENT_TYPE;
import static com.tesco.services.utility.PriceConstants.CLEARANCE_END_SCHEDULED_THREAD;
import static com.tesco.services.utility.PriceConstants.CLEARANCE_START_EVENT_TYPE;
import static com.tesco.services.utility.PriceConstants.CLEARANCE_START_SCHEDULED_THREAD;
import static com.tesco.services.utility.PriceConstants.PRICE_SCHEDULED_THREAD;
import static com.tesco.services.utility.PriceConstants.PROMOTION_END_SCHEDULED_THREAD;
import static com.tesco.services.utility.PriceConstants.PROMOTION_START_PRODUCT_SCHEDULED_THREAD;
import static com.tesco.services.utility.PriceConstants.PROMOTION_START_SCHEDULED_THREAD;
import static com.tesco.services.utility.PriceConstants.SCHEDULED_EVENT_ADMIN;
import static com.tesco.services.utility.PriceConstants.SCHEDULED_FUTURE_PRICE_MSG_TYPE_CRE;
import static com.tesco.services.utility.PriceConstants.SCHEDULED_PROMOTION_END_EVENT_TYPE;
import static com.tesco.services.utility.PriceConstants.SCHEDULED_PROMOTION_START_EVENT_TYPE;
import static com.tesco.services.utility.PriceConstants.SCHEDULED_PROMOTION_START_PRODUCT_EVENT_TYPE;
import static com.tesco.services.utility.PriceConstants.SUCCESS_MESSAGE;
import static com.tesco.services.utility.PriceConstants.SUCCESS_MESSAGE_CLEARANCE_END;
import static com.tesco.services.utility.PriceConstants.SUCCESS_MESSAGE_CLEARANCE_START;
import static com.tesco.services.utility.PriceConstants.SUCCESS_MESSAGE_PROMOTION_END;
import static com.tesco.services.utility.PriceConstants.SUCCESS_MESSAGE_PROMOTION_START;
import static com.tesco.services.utility.sl4j.LoggerFactoryWrapper.getLogger;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Semaphore;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.configuration.ConfigurationException;
import org.slf4j.Logger;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.ClearanceScheduledEventJob;
import com.tesco.services.adapters.core.PriceChangeScheduledEventJob;
import com.tesco.services.adapters.core.PromotionScheduledEventJob;
import com.tesco.services.adapters.core.ScheduledEventJob;
import com.tesco.services.adapters.price.PriceEventHandler;
import com.tesco.services.adapters.promotion.PromotionEventHandler;
import com.tesco.services.event.core.EventTemplate;
import com.tesco.services.exceptions.ScheduledEventProgressException;

@Path(SCHEDULED_EVENT_ADMIN)
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class ScheduledEventResource {
	private static final Logger LOGGER = (Logger) getLogger(ScheduledEventResource.class);
	private Configuration configuration;
	private ObjectMapper jsonMapper;
	private PriceEventHandler priceEventHandler;
	private EventTemplate eventTemplate;
	private static final String PUBLISH_PRICE_CHANGE_EVENT = "/publishPriceChangeEvent";
	private static final String PUBLISH_CLEARANCE_END_EVENT = "/publishClearanceEndEvent";
	private static final String PUBLISH_CLEARANCE_START_EVENT = "/publishClearanceStartEvent";
	private static final String PUBLISH_PROMOTION_START_ZONELEVEL = "/publishZoneLevelPromotionStart";
	private static final String PUBLISH_PROMOTION_END_ZONELEVEL = "/publishZoneLevelPromotionEnd";
	private static final String PUBLISH_PROMOTION_START_PRODUCT = "/publishPromotionStartProduct";
	private static final String SCHEDULED_PROCESS_INPROGRESS = "/scheduledEventJobStatus/{eventType}";
	private PromotionEventHandler promotionEventHandler;

	private static final Map<String, Semaphore> scheduledEventSemaphoreMap = new HashMap<>();
	private static Map<String, String> errorString = new HashMap<>();

	public static Semaphore getScheduledEventSemaphoreMap(String runIdentifier) {
		return scheduledEventSemaphoreMap.get(runIdentifier);
	}

	@Inject
	public ScheduledEventResource(
			@Named("configuration") Configuration configuration,
			@Named("jsonmapper") ObjectMapper jsonMapper,
			@Named("priceEventHandler") PriceEventHandler priceEventHandler,
			@Named("promoEvtHandler") PromotionEventHandler promotionEventHandler,
			@Named("rtEventTemplate") EventTemplate eventTemplate) {
		this.configuration = configuration;
		this.jsonMapper = jsonMapper;
		this.priceEventHandler = priceEventHandler;
		this.promotionEventHandler = promotionEventHandler;
		this.eventTemplate = eventTemplate;
	}

	@GET
	@Path(PUBLISH_PRICE_CHANGE_EVENT)
	public Response processPriceChangeEvents() {
		if (scheduledEventSemaphoreMap.get(SCHEDULED_FUTURE_PRICE_MSG_TYPE_CRE) == null) {
			scheduledEventSemaphoreMap.put(SCHEDULED_FUTURE_PRICE_MSG_TYPE_CRE,
					new Semaphore(1));
		}
		if (!scheduledEventSemaphoreMap
				.get(SCHEDULED_FUTURE_PRICE_MSG_TYPE_CRE).tryAcquire()) {
			LOGGER.debug("Scheduled price change Event publication is already in progress ....");
			throw new ScheduledEventProgressException();
		}
		try {
			Thread scheduledThread = new Thread(getPriceChangeEventJob(),
					PRICE_SCHEDULED_THREAD);
			scheduledThread.start();

		} catch (Exception exception) {
			LOGGER.error("Schedule price change event publication Failed {} ",
					500, exception);
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
					.entity(Response.serverError()).build();
		}
		return Response.status(Response.Status.OK).entity(SUCCESS_MESSAGE)
				.build();
	}

	private ScheduledEventJob getPriceChangeEventJob()
			throws ConfigurationException {
		ScheduledEventJob priceChangeEventJob = new PriceChangeScheduledEventJob(
				configuration, jsonMapper, priceEventHandler);
		return priceChangeEventJob;
	}

	@GET
	@Path(PUBLISH_CLEARANCE_END_EVENT)
	public Response processClearanceEndEvents() {
		if (scheduledEventSemaphoreMap.get(CLEARANCE_END_EVENT_TYPE) == null) {
			scheduledEventSemaphoreMap.put(CLEARANCE_END_EVENT_TYPE,
					new Semaphore(1));
		}
		if (!scheduledEventSemaphoreMap.get(CLEARANCE_END_EVENT_TYPE)
				.tryAcquire()) {
			LOGGER.debug("Scheduled clearance end event publication is already in progress ....");
			throw new ScheduledEventProgressException();
		}
		try {
			Thread scheduledThread = new Thread(
					getClearanceEndScheduledEventJob(),
					CLEARANCE_END_SCHEDULED_THREAD);
			scheduledThread.start();

		} catch (Exception exception) {
			LOGGER.error(
					"Schedule clearance end event publication Failed {} {} ",
					500, exception);
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
					.entity(Response.serverError()).build();
		}
		return Response.status(Response.Status.OK)
				.entity(SUCCESS_MESSAGE_CLEARANCE_END).build();
	}

	@GET
	@Path(PUBLISH_CLEARANCE_START_EVENT)
	public Response processClearanceStartEvents() {
		if (scheduledEventSemaphoreMap.get(CLEARANCE_START_EVENT_TYPE) == null) {
			scheduledEventSemaphoreMap.put(CLEARANCE_START_EVENT_TYPE,
					new Semaphore(1));
		}
		if (!scheduledEventSemaphoreMap.get(CLEARANCE_START_EVENT_TYPE)
				.tryAcquire()) {
			LOGGER.debug("Scheduled clearance start event publication is already in progress ....");
			throw new ScheduledEventProgressException();
		}
		try {
			Thread scheduledThread = new Thread(
					getClearanceStartScheduledEventJob(),
					CLEARANCE_START_SCHEDULED_THREAD);
			scheduledThread.start();

		} catch (Exception exception) {
			LOGGER.error(
					"Schedule clearance start event publication Failed {} {} ",
					500, exception);
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
					.entity(Response.serverError()).build();
		}
		return Response.status(Response.Status.OK)
				.entity(SUCCESS_MESSAGE_CLEARANCE_START).build();
	}

	@GET
	@Path(PUBLISH_PROMOTION_START_ZONELEVEL)
	public Response processPromotionStartEvents() {
		if (scheduledEventSemaphoreMap
				.get(SCHEDULED_PROMOTION_START_EVENT_TYPE) == null) {
			scheduledEventSemaphoreMap.put(
					SCHEDULED_PROMOTION_START_EVENT_TYPE, new Semaphore(1));
		}
		if (!scheduledEventSemaphoreMap.get(
				SCHEDULED_PROMOTION_START_EVENT_TYPE).tryAcquire()) {
			LOGGER.debug("Scheduled zone level promotion start event publication is already in progress ..");
			throw new ScheduledEventProgressException();
		}
		try {
			Thread scheduledThread = new Thread(getPromotionStartEventJob(),
					PROMOTION_START_SCHEDULED_THREAD);
			scheduledThread.start();

		} catch (Exception exception) {
			LOGGER.error(
					"Schedule zone level promotion start event publication Failed {} {} ",
					500, exception);
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
					.entity(Response.serverError()).build();
		}
		return Response.status(Response.Status.OK)
				.entity(SUCCESS_MESSAGE_PROMOTION_START).build();
	}

	@GET
	@Path(PUBLISH_PROMOTION_END_ZONELEVEL)
	public Response processPromotionEndEvents() {
		if (scheduledEventSemaphoreMap.get(SCHEDULED_PROMOTION_END_EVENT_TYPE) == null) {
			scheduledEventSemaphoreMap.put(SCHEDULED_PROMOTION_END_EVENT_TYPE,
					new Semaphore(1));
		}
		if (!scheduledEventSemaphoreMap.get(SCHEDULED_PROMOTION_END_EVENT_TYPE)
				.tryAcquire()) {
			LOGGER.debug("Scheduled zone level promotion end event publication is already in progress ..");
			throw new ScheduledEventProgressException();
		}
		try {
			Thread scheduledThread = new Thread(getPromotionEndEventJob(),
					PROMOTION_END_SCHEDULED_THREAD);
			scheduledThread.start();

		} catch (Exception exception) {
			LOGGER.error(
					"Schedule zone level promotion end event publication Failed {} {} ",
					500, exception);
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
					.entity(Response.serverError()).build();
		}
		return Response.status(Response.Status.OK)
				.entity(SUCCESS_MESSAGE_PROMOTION_END).build();
	}

	@GET
	@Path(PUBLISH_PROMOTION_START_PRODUCT)
	public Response processPromotionStartProductEvents() {
		if (scheduledEventSemaphoreMap
				.get(SCHEDULED_PROMOTION_START_PRODUCT_EVENT_TYPE) == null) {
			scheduledEventSemaphoreMap.put(
					SCHEDULED_PROMOTION_START_PRODUCT_EVENT_TYPE,
					new Semaphore(1));
		}
		if (!scheduledEventSemaphoreMap.get(
				SCHEDULED_PROMOTION_START_PRODUCT_EVENT_TYPE).tryAcquire()) {
			LOGGER.debug("Scheduled  promotion start product event publication is already in progress ..");
			throw new ScheduledEventProgressException();
		}
		try {
			Thread scheduledThread = new Thread(
					getPromotionStartProductEventJob(),
					PROMOTION_START_PRODUCT_SCHEDULED_THREAD);
			scheduledThread.start();

		} catch (Exception exception) {
			LOGGER.error(
					"Schedule zone level promotion start event publication Failed {} {} ",
					500, exception);
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
					.entity(Response.serverError()).build();
		}
		return Response.status(Response.Status.OK).entity(SUCCESS_MESSAGE)
				.build();
	}

	@GET
	@Path(SCHEDULED_PROCESS_INPROGRESS)
	public Response isScheduledJobInProgressForEventType(
			@PathParam("eventType") String eventType) {

		Semaphore semaphore = scheduledEventSemaphoreMap.get(eventType);
		if (semaphore == null) {
			return Response.ok("{\"import\":\"No Process\"}").build();
		} else if (semaphore.availablePermits() < 1) {
			return Response.ok("{\"import\":\"progress\"}").build();
		} else if (getErrorString(eventType) != null) {
			return Response.ok(
					String.format(
							"{\"import\":\"aborted\",\n \"error\":\"%s\"}",
							getErrorString(eventType))).build();
		} else {
			return Response.ok("{\"import\":\"completed\"}").build();
		}
	}

	private ScheduledEventJob getClearanceEndScheduledEventJob()
			throws ConfigurationException {
		ClearanceScheduledEventJob clearanceEndEventJob = new ClearanceScheduledEventJob(
				configuration, jsonMapper, eventTemplate,
				CLEARANCE_END_EVENT_TYPE);
		return clearanceEndEventJob;
	}

	private ScheduledEventJob getClearanceStartScheduledEventJob()
			throws ConfigurationException {
		ClearanceScheduledEventJob clearanceEndEventJob = new ClearanceScheduledEventJob(
				configuration, jsonMapper, eventTemplate,
				CLEARANCE_START_EVENT_TYPE);
		return clearanceEndEventJob;
	}

	private ScheduledEventJob getPromotionStartEventJob()
			throws ConfigurationException {
		ScheduledEventJob promotionStartEventJob = new PromotionScheduledEventJob(
				configuration, jsonMapper, promotionEventHandler,
				SCHEDULED_PROMOTION_START_EVENT_TYPE);
		return promotionStartEventJob;
	}

	private ScheduledEventJob getPromotionEndEventJob()
			throws ConfigurationException {
		ScheduledEventJob promotionEndEventJob = new PromotionScheduledEventJob(
				configuration, jsonMapper, promotionEventHandler,
				SCHEDULED_PROMOTION_END_EVENT_TYPE);
		return promotionEndEventJob;
	}

	private ScheduledEventJob getPromotionStartProductEventJob()
			throws ConfigurationException {
		ScheduledEventJob promotionStartProductEventJob = new PromotionScheduledEventJob(
				configuration, jsonMapper, promotionEventHandler,
				SCHEDULED_PROMOTION_START_PRODUCT_EVENT_TYPE);
		return promotionStartProductEventJob;
	}

	public static String getErrorString(String eventType) {
		return errorString.get(eventType);
	}

	public static void setErrorString(String eventType, String error) {
		errorString.put(eventType, error);
	}

	public static Semaphore addScheduledEventSemaphore(String eventType,
			Semaphore semaphore) {
		return scheduledEventSemaphoreMap.put(eventType, semaphore);
	}

	public static Semaphore removeScheduledEventSemaphore(String eventType) {
		return scheduledEventSemaphoreMap.remove(eventType);
	}
}
