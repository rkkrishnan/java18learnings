package com.tesco.services;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EventPublisherConfiguration {

	@JsonProperty("jms.config.id")
	private String configId;

	@JsonProperty("jms.topic.name")
	private String topicName;

	@JsonProperty("jms.retry.count")
	private Integer retryCount;

	@JsonProperty("jms.factory.class")
	private String jmsFactoryClass;

	@JsonProperty("jms.factory.class.parameters")
	private EventFactoryParameter[] eventFactoryParameters;

	@JsonProperty("jms.factory.class.properties")
	private EventFactoryParameter[] eventFactoryProperties;

	public String getConfigId() {
		return configId;
	}

	public String getTopicName() {
		return topicName;
	}

	public Integer getRetryCount() {
		return retryCount;
	}

	public String getJmsFactoryClass() {
		return jmsFactoryClass;
	}

	public EventFactoryParameter[] getEventFactoryParameters() {
		return eventFactoryParameters;
	}

	public EventFactoryParameter[] getEventFactoryProperties() {
		return eventFactoryProperties;
	}

}
