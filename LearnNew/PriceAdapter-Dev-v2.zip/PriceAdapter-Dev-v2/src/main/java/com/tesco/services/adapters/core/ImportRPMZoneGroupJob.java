package com.tesco.services.adapters.core;

import com.tesco.services.Configuration;
import com.tesco.services.adapters.rpm.writers.impl.RPMZoneGroupWriter;
import com.tesco.services.adapters.rpm.writers.Writer;
import com.tesco.services.resources.ImportResource;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;

/**
 * Created by qp65 on 11/5/2015.
 */
public class ImportRPMZoneGroupJob implements Import {

	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(ImportRPMZoneJob.class);

	private Configuration configuration;
	private String fileName;
	private Writer rpmZoneGroupWriter;

	/**
	 * @param configuration
	 * @param rpmZoneGroupWriter
	 */
	@Inject
	public ImportRPMZoneGroupJob(
			@Named("configuration") Configuration configuration,
			@Named("rpmZoneGroupWriter") Writer rpmZoneGroupWriter) {
		this.configuration = configuration;
		this.rpmZoneGroupWriter = rpmZoneGroupWriter;
	}

	public String getRunIdentifier() {
		return runIdentifier;
	}

	public void setRunIdentifier(String runIdentifier) {
		this.runIdentifier = runIdentifier;
	}

	private String runIdentifier;

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}


	@Override
	public void run() {
		LOGGER.info("Firing up imports for RPM Onetime Zone Group data for {}",
				runIdentifier);
		startImportProcess();
	}

	public void startImportProcess() {
		try {
			LOGGER.info("Importing data for RPM Zone Group data from {} ",
					configuration.getRpmClrDataDumpPath());
			((RPMZoneGroupWriter) rpmZoneGroupWriter)
					.setRunIdentifier(getRunIdentifier());
			rpmZoneGroupWriter.write(fileName);
			LOGGER.info(
					"Successfully completed imports for RPM Onetime Zone Group data");
		} catch (Exception exception) {
			LOGGER.error("Error importing Onetime RPM Zone Group data..",
					exception);
			ImportResource.setErrorString(fileName,
					"Error importing Onetime RPM Zone Group data..");
		} finally {
			ImportResource.getImportSemaphoreForIdentifier(fileName).release();
		}
	}
}
