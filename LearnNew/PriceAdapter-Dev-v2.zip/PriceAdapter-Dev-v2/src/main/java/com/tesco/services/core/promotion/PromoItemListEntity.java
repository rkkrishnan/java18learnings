package com.tesco.services.core.promotion;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
@JsonIgnoreProperties(ignoreUnknown = true)
public class PromoItemListEntity implements Serializable {
    @JsonProperty("@type")
    public String type;

    @JsonProperty("listType")
    public String listType;

    @JsonProperty("thresholdRefs")
    public int[] thresholdRefs;

	@JsonProperty("rewardRefs")
    public int[] rewardRefs;

    @JsonProperty("promoItems")
    public List<PromoItemEntity> promoItems;

    public List<PromoItemEntity> getPromoItems() {
        return promoItems;
    }

    public void setPromoItems(List<PromoItemEntity> promoItems) {
        this.promoItems = promoItems;
    }

    public void addPromoItem(PromoItemEntity promoItem) {
        if(this.promoItems == null){
            this.promoItems = new ArrayList<>();
        }
        this.promoItems.add(promoItem);
    }

    public void removeItemEntity(PromoItemEntity promoItemEntity){
        promoItems.remove(promoItemEntity);
    }

    public String getListType() {
        return listType;
    }

    public int[] getThresholdRefs() {
        return thresholdRefs;
    }

    public void setThresholdRefs(int[] thresholdRefs) {
        this.thresholdRefs = thresholdRefs;
    }

    public void setRewardRefs(int[] rewardRefs) {
        this.rewardRefs = rewardRefs;
    }

	public int[] getRewardRefs() {
		return rewardRefs;
	}

    @Override
    public String toString() {
        return "PromoItemListEntity{" +
                "type='" + type + '\'' +
                ", listType='" + listType + '\'' +
                ", thresholdRefs=" + Arrays.toString(thresholdRefs) +
                ", promoItems=" + promoItems +
                '}';
    }
}
