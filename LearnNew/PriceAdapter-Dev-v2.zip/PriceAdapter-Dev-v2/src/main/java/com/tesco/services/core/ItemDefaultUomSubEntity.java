package com.tesco.services.core;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;

import static com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility.ANY;
import static com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility.NONE;

@JsonAutoDetect(fieldVisibility = ANY, getterVisibility = NONE,
		setterVisibility = NONE)
public class ItemDefaultUomSubEntity implements Serializable {

	@JsonProperty
	private String sellByType;

	@JsonProperty
	private String defaultUOM;

	@Override
	public String toString() {
		return "ItemDefaultUomSubEntity{" +
				"prodRef='" + prodRef + '\'' +
				", sellByType='" + sellByType + '\'' +
				", defaultUOM='" + defaultUOM + '\'' +
				", lastUpdatedById='" + lastUpdatedById + '\'' +
				", lastUpdateDate='" + lastUpdateDate + '\'' +
				'}';
	}

	public String getSellByType() {
		return sellByType;
	}

	public String getDefaultUOM() {
		return defaultUOM;
	}

	public void setSellByType(String sellByType) {
		this.sellByType = sellByType;
	}

	public void setDefaultUOM(String defaultUOM) {
		this.defaultUOM = defaultUOM;
	}

	@JsonProperty
	private String prodRef;

	@JsonProperty
	private String lastUpdatedById;

	@JsonProperty
	private String lastUpdateDate;

	public String getProdRef() { return prodRef; }

	public void setProdRef(String prodRef) { this.prodRef = prodRef; }

	public String getLastUpdatedById() { return lastUpdatedById; }

	public void setLastUpdatedById(String lastUpdatedById) { this.lastUpdatedById = lastUpdatedById; }

	public String getLastUpdateDate() { return lastUpdateDate; }

	public void setLastUpdateDate(String lastUpdateDate) { this.lastUpdateDate = lastUpdateDate; }
}
