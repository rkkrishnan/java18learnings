package com.tesco.services.resources;

import static com.tesco.services.resources.ResourceResponse.RESPONSE_TYPE;
import io.swagger.annotations.Api;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import org.slf4j.Logger;

import com.tesco.services.core.jms.JMSAdapterStateManager;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;

/**
 * @author a185
 *
 */
@Path("/admin/jms")
@Api(value = "/admin/jms")
@Produces(RESPONSE_TYPE)
public class JMSResource {
	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(JMSResource.class);

	private JMSAdapterStateManager jmsAdapterStateManager;

	@Inject
	public JMSResource(@Named("jmsStateManager") JMSAdapterStateManager injectedJmsAdapterStateManager) {
		this.jmsAdapterStateManager = injectedJmsAdapterStateManager;
	}

	/**
	 * @param command
	 * @param configId
	 * @param uriInfo
	 * @return
	 */
	@GET
	@Path("/{command}/{configid}")
	public Response get(@PathParam("command") String command,
			@PathParam("configid") String configId, @Context UriInfo uriInfo) {
		LOGGER.debug("Enter JMS State Controller get()");
		String commandStatus = "Invalid Command";

		if ("start".equals(command)) {
			commandStatus = jmsAdapterStateManager.startJMSReceiver(configId);
		} else if ("stop".equals(command)) {
			commandStatus = jmsAdapterStateManager.stopJMSReceiver(configId);
		} else if ("status".equals(command)) {
			commandStatus = jmsAdapterStateManager
					.getJMSReceiverStatus(configId);
		} else {
			commandStatus = "Invalid Command";
		}

		LOGGER.debug("Exit JMS State Controller get()");
		return Response.ok(commandStatus).build();
	}
}
