package com.tesco.services.adapters.rpm.writers.impl;

import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.exceptions.ColumnNotFoundException;
import com.tesco.services.adapters.core.exceptions.WriterBusinessException;
import com.tesco.services.adapters.promotion.PromotionEventHandler;
import com.tesco.services.adapters.rpm.readers.PriceServiceCSVReader;
import com.tesco.services.adapters.rpm.readers.impl.PriceServiceCSVReaderImpl;
import com.tesco.services.adapters.rpm.writers.CSVHeaders;
import com.tesco.services.adapters.rpm.writers.Writer;
import com.tesco.services.core.promotion.ProductOffersEntity;
import com.tesco.services.core.promotion.ProductOffersPromotionEntity;
import com.tesco.services.core.promotion.PromotionEntity;
import com.tesco.services.exceptions.DataAccessException;
import com.tesco.services.leadtime.core.LeadTimeUtility;
import com.tesco.services.repositories.Repository;
import com.tesco.services.repositories.RepositoryImpl;
import com.tesco.services.resources.ImportResource;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.PriceConstants;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;
import org.joda.time.DateTime;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.tesco.services.utility.PriceConstants.*;

/**
 * Created by QP65 on 12/11/2015.
 */

public class FutureOfferDescWritter implements Writer {

	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(FutureOfferDescWritter.class);

	private Configuration configuration;
	private String runIdentifier;
	private Repository repository;
	private Set<String> futureOfferRejects;
	private PriceServiceCSVReader futureOfferdescReader;
	private PromotionEventHandler promotionEventHandler;

	public final static String PROUCT_OFFER_REJECT_COUNTER_KEY = "PRODUCT_OFFER_REJECT";
	public final static String PROUCT_OFFER_UPDATE_COUNTER_KEY = "PRODUCT_OFFER_UPDATE";
	private final static String CSV_FILE_INPUT_DATE_FORMAT = "MMM dd yyyy HH:mm";

	@Inject
	public FutureOfferDescWritter(
			@Named("configuration") Configuration configuration,
			@Named("repository") Repository repository,
			@Named("promoEvtHandler") PromotionEventHandler promotionEventHandler) {
		this.configuration = configuration;
		this.repository = repository;
		this.promotionEventHandler = promotionEventHandler;
	}

	public FutureOfferDescWritter(Configuration configuration,
			RepositoryImpl repository,
			PriceServiceCSVReader futureOfferdescReader,
			PromotionEventHandler promotionEventHandler) {
		this.configuration = configuration;
		this.repository = repository;
		this.futureOfferdescReader = futureOfferdescReader;
		this.promotionEventHandler = promotionEventHandler;
	}

	public String getRunIdentifier() {
		return runIdentifier;
	}

	public void setRunIdentifier(String runIdentifier) {
		this.runIdentifier = runIdentifier;
	}

	public PriceServiceCSVReader createFutureOfferDesceReader(String fileName)
			throws WriterBusinessException {

		PriceServiceCSVReader csvreader = null;
		try {
			csvreader = new PriceServiceCSVReaderImpl(
					configuration.getPromotionFilePath() + "/" + runIdentifier
							+ "/" + fileName,
					CSVHeaders.PromoDescExtract.HEADERS);
		} catch (IOException | ColumnNotFoundException e) {
			LOGGER.error(
					"Error occured in creating PriceServiceCSVReader for FutureOfferDescWritter.",
					e);
			throw new WriterBusinessException(e.getMessage(), e.getCause());
		}
		return csvreader;
	}

	public void write(String fileName) throws WriterBusinessException {
		if (futureOfferdescReader == null) {
			futureOfferdescReader = createFutureOfferDesceReader(fileName);
		}

		LOGGER.info("Importing Future offer description");

		try {
			writeFutureOfferDesc(fileName);
		} catch (ArrayIndexOutOfBoundsException exception) {
			ImportResource.setErrorString(fileName,
					"Array index out of bound Exception");
			LOGGER.error("Error importing data", exception.getMessage());
		} catch (Exception e) {
			ImportResource.setErrorString(fileName, e.toString());
			LOGGER.error("Error importing data", e);
		} finally {
			ImportResource.getImportSemaphoreForIdentifier(fileName).release();

			if (!futureOfferRejects.isEmpty()) {
				String date = Dockyard.getSysDate("yyyyMMddHHmmss");

				String rejectfilepath = configuration.getRejectFilePath();

				if (rejectfilepath != null && rejectfilepath.length() > 0) {
					new Dockyard().writeProductDetailsToFile(rejectfilepath
							+ "/REJECT_FILE_" + runIdentifier + "_" + date
							+ ".log", futureOfferRejects);

				} else {
					LOGGER.error("Invalid reject file path : {}",
							rejectfilepath);
				}
				futureOfferRejects.clear();
			}
		}
	}

	private void writeFutureOfferDesc(String fileName) throws IOException,
			ParseException, DataAccessException {

		Map<String, String> futureOfferDescLineMap;

		String curOfferId = null;
		String cfDesc1 = null;
		String cfDesc2 = null;
		String offerStartDate = null;
		String effectiveDate = null;
		String zoneId = null;
		String offerEndDate = null;
		SimpleDateFormat dateFormat = new SimpleDateFormat(
				PriceConstants.DATE_FORMAT);
		Calendar cal = Calendar.getInstance();
		Date sysDate = cal.getTime();
		cal.setTime(dateFormat.parse(Dockyard
				.getSysDate(PriceConstants.DATE_FORMAT)));
		cal.add(Calendar.DATE,
				PriceConstants.FUTURE_OFFER_DESC_RANGE.RANGE_BEGIN.value());
		Date rangeFromDate = cal.getTime();
		cal.add(Calendar.DATE,
				PriceConstants.FUTURE_OFFER_DESC_RANGE.RANGE_END.value()
						- PriceConstants.FUTURE_OFFER_DESC_RANGE.RANGE_BEGIN
								.value());
		Date rangeEndDate = cal.getTime();

		List<String> itemZoneList = new ArrayList<>();
		futureOfferRejects = new HashSet<>();

		int totalRowsRead = 0;
		int totalRowsUpdatedSuccessfully = 0;
		int totalPromotionOfferUpdated = 0;
		int totalProdOfferUpdated = 0;
		int promotionOfferRejected = 0;
		int prodOfferRejected = 0;
		int skippedDueToDateValidation = 0;

		while ((futureOfferDescLineMap = futureOfferdescReader.getNext()) != null) {
			totalRowsRead++;
			/** Strip offerId of the first Char Eg:'A123456' */
			curOfferId = futureOfferDescLineMap.get(
					CSVHeaders.PromoDescExtract.OFFER_ID).substring(
					1,
					futureOfferDescLineMap.get(
							CSVHeaders.PromoDescExtract.OFFER_ID).length());

			zoneId = futureOfferDescLineMap
					.get(CSVHeaders.PromoDescExtract.ZONE_ID);
			effectiveDate = futureOfferDescLineMap
					.get(CSVHeaders.PromoDescExtract.EFFECTIVE_DATE);
			cfDesc1 = futureOfferDescLineMap
					.get(CSVHeaders.PromoDescExtract.DESC1);
			cfDesc2 = futureOfferDescLineMap
					.get(CSVHeaders.PromoDescExtract.DESC2);
			offerStartDate = futureOfferDescLineMap
					.get(CSVHeaders.PromoDescExtract.START_DATE);
			offerEndDate = futureOfferDescLineMap
					.get(CSVHeaders.PromoDescExtract.END_DATE);

			if (PriceConstants.FUTURE_OFFER_DESC.equals(runIdentifier)) {
				if (Dockyard.isWithinRange(dateFormat.parse(offerStartDate),
						rangeFromDate, rangeEndDate)
						|| Dockyard.isWithinRange(sysDate,
								dateFormat.parse(offerStartDate),
								dateFormat.parse(offerEndDate))) {
					// Added for PRIS-2007 Support change to cf desc while
					// product is on promo
					itemZoneList.add(futureOfferDescLineMap.get(
							CSVHeaders.PromoDescExtract.ITEM).split("-")[0]
							.concat("_")
							.concat("Z")
							.concat(futureOfferDescLineMap
									.get(CSVHeaders.PromoDescExtract.ZONE_ID)));

				} else {
					skippedDueToDateValidation++;
				}
			} else {
				if (Dockyard.isWithinRange(sysDate,
						dateFormat.parse(offerStartDate),
						dateFormat.parse(offerEndDate))) {

					itemZoneList.add(futureOfferDescLineMap.get(
							CSVHeaders.PromoDescExtract.ITEM).split("-")[0]
							.concat("_")
							.concat("Z")
							.concat(futureOfferDescLineMap
									.get(CSVHeaders.PromoDescExtract.ZONE_ID)));
				}
			}

			if (!itemZoneList.isEmpty()) {
				try {
					processFutureOfferDescPromotionEntity(curOfferId, cfDesc1,
							cfDesc2, zoneId, effectiveDate);
					totalPromotionOfferUpdated++;
					Map<String, Integer> counterMap = processFutureOfferDescProductOfferEntity(
							curOfferId, itemZoneList, cfDesc1, cfDesc2);
					if (counterMap.get(PROUCT_OFFER_REJECT_COUNTER_KEY) != null) {
						int rejectedProdOffer = (Integer) counterMap
								.get(PROUCT_OFFER_REJECT_COUNTER_KEY);
						prodOfferRejected = prodOfferRejected
								+ rejectedProdOffer;
					}
					if (counterMap.get(PROUCT_OFFER_UPDATE_COUNTER_KEY) != null) {
						totalProdOfferUpdated = totalProdOfferUpdated
								+ (Integer) counterMap
										.get(PROUCT_OFFER_UPDATE_COUNTER_KEY);
						totalRowsUpdatedSuccessfully++;
					}
				} catch (Exception e) {
					promotionOfferRejected++;
				}
			}
			itemZoneList.clear();

		}
		// Added for PRIS-2203

		LOGGER.info("FileName: " + fileName
				+ " Future offer promotion entity documents updated : "
				+ totalPromotionOfferUpdated);
		LOGGER.info("FileName: " + fileName
				+ " Future offer product offer documents updated : "
				+ totalProdOfferUpdated);
		LOGGER.info("FileName: " + fileName
				+ " Future offer promotion entity documents rejected : "
				+ promotionOfferRejected);
		LOGGER.info("FileName: " + fileName
				+ " Future offer product offer documents rejected : "
				+ prodOfferRejected);
		LOGGER.info("FileName: " + fileName
				+ " Total rows for future offer updated : "
				+ totalRowsUpdatedSuccessfully);
		LOGGER.info("FileName: " + fileName + " Skipped future offer rows : "
				+ skippedDueToDateValidation);
		LOGGER.info("FileName: " + fileName + " Total future offer rows : "
				+ totalRowsRead);
	}

	public void processFutureOfferDescPromotionEntity(String offerId,
			String cfDesc1, String cfDesc2, String zoneId, String effectiveDate)
			throws Exception {

		String promoKey = PriceConstants.PROMOTION_DOC_KEY_PREFIX + offerId
				+ "_Z" + zoneId;

		PromotionEntity promotionEntity = (PromotionEntity) repository
				.getGenericObject(promoKey, PromotionEntity.class);

		if (promotionEntity == null) {
			LOGGER.info(
					"Promotion document for offer id :{} for Zone :{} is not present in Couchbase",
					offerId, zoneId);
			futureOfferRejects.add(Dockyard
					.getSysDate(PriceConstants.ISO_8601_FORMAT)
					.concat("~<FUTURE OFFER DESC>~")
					.concat("Promotion document for offer id:").concat(offerId)
					.concat(" for zone :").concat(zoneId)
					.concat(" is not present in couchbase"));
			throw new Exception("Promotion document for offer id " + offerId
					+ " for zone :" + zoneId + " is not present in couchbase");

		}

		promotionEntity.setCfDescription1(cfDesc1);
		promotionEntity.setCfDescription2(cfDesc2);
		promotionEntity.setLastUpdateDate(Dockyard.getSysDate(ISO_8601_FORMAT));
		savePromotion(promoKey, promotionEntity);
		Map<String, String> promotionMapData = new HashMap<>();
		promotionMapData.put(OFFER_ID, offerId);
		promotionMapData.put(LOC_REF, promotionEntity.getLocRef());
		promotionMapData.put(LOC_TYPE, promotionEntity.getLocType());
		promotionMapData.put(EVENT_TYPE, PROMOTION_DETAILS_CHANGED_EVENT_TYPE);
		promotionMapData.put(LEAD_TIME_DAYS, getleadTimeDays(effectiveDate));

		promotionEventHandler.publishPromotionEvent(promotionMapData);
	}

	public Map<String, Integer> processFutureOfferDescProductOfferEntity(
			String offerId, List<String> itemZoneList, String cfDesc1,
			String cfDesc2) throws DataAccessException {

		int noOfRecordsRejected = 0;
		int noOfRecordsInserted = 0;
		Map<String, Integer> counter = new HashMap<>();

		/** Update the prodoffers document */
		for (String itemZone : itemZoneList) {
			String docKey = PriceConstants.PROD_OFFERS.concat(itemZone);
			ProductOffersEntity productOffersEntity = (ProductOffersEntity) repository
					.getGenericObject(docKey, ProductOffersEntity.class);
			if (productOffersEntity == null) {
				LOGGER.info(
						"Product offer document for item zone {} is not present..!!",
						docKey);
				futureOfferRejects.add(Dockyard
						.getSysDate(PriceConstants.ISO_8601_FORMAT)
						.concat("~<FUTURE OFFER DESC>~").concat(docKey)
						.concat(" document not present in couchbase"));
				noOfRecordsRejected++;
				counter.put(PROUCT_OFFER_REJECT_COUNTER_KEY,
						noOfRecordsRejected);
				continue;
			}
			productOffersEntity.setLastUpdateDateTime(Dockyard
					.getSysDate(PriceConstants.ISO_8601_FORMAT));
			ProductOffersPromotionEntity productOffersPromotionEntity = productOffersEntity
					.getProductOffersPromotionMap().get(offerId);
			if (productOffersPromotionEntity == null) {
				LOGGER.info(
						"Offer details for offer:{} is not present in the product offer document:{}",
						offerId, docKey);
				futureOfferRejects.add(Dockyard
						.getSysDate(PriceConstants.ISO_8601_FORMAT)
						.concat("~<FUTURE OFFER DESC>~").concat("offer: ")
						.concat(offerId).concat(" is not found in document ")
						.concat(docKey));
				noOfRecordsRejected++;
				counter.put(PROUCT_OFFER_REJECT_COUNTER_KEY,
						noOfRecordsRejected);
				continue;

			}
			productOffersPromotionEntity.setCfDescription1(cfDesc1);
			productOffersPromotionEntity.setCfDescription2(cfDesc2);
			productOffersPromotionEntity.setLastUpdateDateTime(Dockyard
					.getSysDate(PriceConstants.ISO_8601_FORMAT));
			/** Insert into couchbase */
			try {
				savePromotion(docKey, productOffersEntity);
				noOfRecordsInserted++;
				counter.put(PROUCT_OFFER_UPDATE_COUNTER_KEY,
						noOfRecordsInserted);
			} catch (DataAccessException e) {
				noOfRecordsRejected++;
				counter.put(PROUCT_OFFER_REJECT_COUNTER_KEY,
						noOfRecordsRejected);
			}
		}
		return counter;
	}

	private void savePromotion(final String key, Object object)
			throws DataAccessException {

		if (object != null) {
			try {
				repository.insertObject(key, object);
			} catch (Exception e) {
				LOGGER.error(e.getMessage());
				futureOfferRejects.add(Dockyard
						.getSysDate(PriceConstants.ISO_8601_FORMAT)
						.concat("~<FUTURE OFFER DESC>~")
						.concat("Future offer description for offer id:")
						.concat(key).concat(" is rejected."));
				throw new DataAccessException(e);
			}
		}
	}

	private String getleadTimeDays(String effectiveDate) throws ParseException {
		SimpleDateFormat csvDateFormat = new SimpleDateFormat(
				CSV_FILE_INPUT_DATE_FORMAT);
		SimpleDateFormat requiredOutputDateFormat = new SimpleDateFormat(
				ISO_8601_FORMAT);
		Date inputDate = csvDateFormat.parse(effectiveDate);
		String outputDateString = requiredOutputDateFormat.format(inputDate);
		DateTime effectiveDateTime = new DateTime(outputDateString);
		DateTime publicationDate = new DateTime(
				Dockyard.getSysDate(ISO_8601_FORMAT));
		String leadTime = String.valueOf(LeadTimeUtility.getLeadTime(
				effectiveDateTime, publicationDate));
		LOGGER.debug(
				"lead time days calculated for customer friendly description: {}",
				leadTime);
		return leadTime;
	}
}
