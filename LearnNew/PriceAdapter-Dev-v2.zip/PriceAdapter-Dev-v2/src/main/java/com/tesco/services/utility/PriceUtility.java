package com.tesco.services.utility;

import static com.tesco.services.utility.PriceConstants.COLON_ENCODE;
import static com.tesco.services.utility.PriceConstants.COLON_SEPARATOR;
import static com.tesco.services.utility.PriceConstants.PLUS_ENCODE;
import static com.tesco.services.utility.PriceConstants.PLUS_SEPARATOR;
import static com.tesco.services.utility.PriceConstants.UNDERSCORE_SEPARATOR;
import static org.joda.time.DateTimeZone.forID;

import java.text.ParseException;

import org.joda.time.DateTime;
import org.slf4j.Logger;

import com.tesco.services.CouchbaseViewConfig;
import com.tesco.services.exceptions.ProductEncodeException;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;

/**
 * Created by QZ88 on 24/06/2015.
 */
public class PriceUtility {

	private static final String COUNTRY = "country";

	private static final String OFFSET = "offset";

	private static final String EFFECTIVEDAY = "effectiveday";

	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(PriceUtility.class);

	private static final String[] ALPHABET_INDEX = { "", "A", "B", "C", "D",
			"E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q",
			"R", "S", "T", "U", "V", "W", "X", "Y", "Z" };

	/**
	 * @param section
	 * @param classs
	 * @param subclass
	 * @return
	 * @throws com.tesco.services.exceptions.ProductEncodeException
	 */
	public static String convertRMStoTesco(String section, String classs,
			String subclass) throws ProductEncodeException {

		if (!isValidForConversion(section, classs, subclass)) {
			throw new ProductEncodeException(
					"RMS to Tesco format conversion exception");
		}

		String encodedSection = encode(Dockyard.leftPadZero(section, 4),
				PriceConstants.SECTION);
		String encodedClass = classs != null ? encode(
				Dockyard.leftPadZero(classs, 2), PriceConstants.CLASS) : "";
		String encodedSubclass = subclass != null ? encode(
				Dockyard.leftPadZero(subclass, 2), PriceConstants.SUBCLASS)
				: "";

		return encodedSection.concat(encodedClass).concat(encodedSubclass);
	}

	/**
	 * @param section
	 * @param classs
	 * @param subclass
	 * @return
	 * @throws com.tesco.services.exceptions.ProductEncodeException
	 */
	private static boolean isValidForConversion(String section, String classs,
			String subclass) throws ProductEncodeException {
		if (Dockyard.isSpaceOrNull(section) && Dockyard.isSpaceOrNull(classs)
				&& Dockyard.isSpaceOrNull(subclass)) {
			return false;
		}

		if ((Dockyard.isSpaceOrNull(section) || Dockyard.isSpaceOrNull(classs))
				&& !Dockyard.isSpaceOrNull(subclass)) {
			return false;
		}

		if (!Dockyard.isSpaceOrNull(classs) && Dockyard.isSpaceOrNull(section)) {
			return false;
		}

		if (!isValidSection(section)) {
			return false;
		}

		if (!Dockyard.isSpaceOrNull(classs) && !isValidClassOrSubClass(classs)) {
			return false;
		}

		if (!Dockyard.isSpaceOrNull(subclass)
				&& !isValidClassOrSubClass(subclass)) {
			return false;
		}

		return true;

	}

	/**
	 * @param section
	 * @return
	 */
	private static boolean isValidSection(String section) {
		if (section != null && section.contains(" ")) {
			return false;
		} else if (section != null
				&& (section.length() > 4 || section.length() < 3)) {
			return false;
		}

		int sectionPartIndex = Integer.parseInt(Dockyard
				.leftPadZero(section, 4).substring(0, 2));
		if (sectionPartIndex > 26) {
			return false;
		}

		try {
			int val = Integer.parseInt(section);
			if (val == 0) {
				return false;
			}
		} catch (NumberFormatException e) {
			return false;
		}

		return true;
	}

	/**
	 * @param classs
	 * @return
	 */
	private static boolean isValidClassOrSubClass(String classs) {
		if (classs != null && classs.contains(" ")) {
			return false;
		} else if (classs != null && classs.length() > 2) {
			return false;
		}

		int classsIndex = Integer.parseInt(Dockyard.leftPadZero(classs, 2));
		if (classsIndex > 26) {
			return false;
		}

		try {
			int val = Integer.parseInt(classs);
			if (val == 0) {
				return false;
			}
		} catch (NumberFormatException e) {
			return false;
		}

		return true;
	}

	/**
	 * @param input
	 * @param type
	 * @return
	 */
	private static String encode(String input, int type) {
		String encodedData = null;
		switch (type) {
		case PriceConstants.SECTION: {
			encodedData = ALPHABET_INDEX[Integer
					.parseInt(input.substring(0, 2))]
					.concat(input.substring(2));
			break;
		}
		case PriceConstants.CLASS: {
			encodedData = ALPHABET_INDEX[Integer.parseInt(input)];
			break;
		}
		case PriceConstants.SUBCLASS: {
			encodedData = ALPHABET_INDEX[Integer.parseInt(input)];
			break;
		}
		default: {
			encodedData = null;
			break;
		}
		}
		return encodedData;
	}

	/**
	 * This method is used to read Date String from XML files
	 * 
	 * @param year
	 * @param month
	 * @param day
	 * @param hrs
	 * @param mins
	 * @param secs
	 * @return
	 * @throws ParseException
	 */
	public static String getDate(String year, String month, String day,
			String hrs, String mins, String secs) throws ParseException {
		String parsedDay = day.length() == 1 ? "0" + day : day;
		String parsedMonth = month.length() == 1 ? "0" + month : month;
		String parsedHrs = hrs.length() == 1 ? "0" + hrs : hrs;
		String parsedMins = mins.length() == 1 ? "0" + mins : mins;
		String parsedSecs = secs.length() == 1 ? "0" + secs : secs;

		String date = year + parsedMonth + parsedDay + parsedHrs + parsedMins
				+ parsedSecs;
		try {
			date = Dockyard.getFormattedDate(date,
					PriceConstants.PROMO_MSG_DATE_FORMAT,
					PriceConstants.ISO_8601_FORMAT);
		} catch (ParseException e) {
			LOGGER.error("Error while parsing the date", e);
			throw e;
		}
		return date;
	}

	public static String replaceOffsetDesignatorForZeroWithNumerals(String Date) {

		String formattedDate = Date.replaceAll("Z", "+00:00");

		return formattedDate;
	}

	/*
	 * public static String getCouchBaseViewRestServiceUrl( Configuration
	 * configuration, int pageStartindex, String documentKey, Map<String,
	 * String> viewName, String staleStateValue, String eventType) {
	 * StringBuilder urlBuilder = new StringBuilder(); int recordPerPage =
	 * configuration.getPageSizeLimit(); String baseUrl =
	 * configuration.getViewUrl(); urlBuilder =
	 * urlBuilder.append(baseUrl).append(viewName.get(eventType))
	 * .append(STALE_STATE).append(staleStateValue)
	 * .append(VIEW_QUERY_KEY).append(documentKey)
	 * .append(CONNECTION_TIMEOUT).append(LIMIT + recordPerPage) .append(SKIP +
	 * pageStartindex); LOGGER.info("Scheduled Event REST Endpoint : " +
	 * urlBuilder.toString()); return urlBuilder.toString(); }
	 */

	public static String getCouchbaseViewKeyForEffectiveDate(
			CouchbaseViewConfig viewConfig) {
		DateTime currentDate = new DateTime();
		DateTime effectiveDate = null;
		DateTime currentDateWithOfset = currentDate.withZone(forID(viewConfig
				.getViewAdditionalProperties().get(OFFSET)));

		effectiveDate = currentDateWithOfset.plusDays(Integer
				.parseInt(viewConfig.getViewAdditionalProperties().get(
						EFFECTIVEDAY)));

		DateTime truncatedMonth = effectiveDate.dayOfMonth().roundFloorCopy();
		String effectiveStartDay = replaceZwithNumeralsOffset(
				truncatedMonth.toString(),
				viewConfig.getViewAdditionalProperties().get(OFFSET))
				.replaceAll(COLON_SEPARATOR, COLON_ENCODE).replace(
						PLUS_SEPARATOR, PLUS_ENCODE);
		return effectiveStartDay;
	}

	public static String prepareClearanceKey(CouchbaseViewConfig viewConfig) {
		DateTime currentDate = new DateTime();
		DateTime currentDateWithOffset = currentDate.withZone(forID(viewConfig
				.getViewAdditionalProperties().get(OFFSET)));
		DateTime effectiveDate = null;

		effectiveDate = currentDateWithOffset.plusDays(Integer
				.parseInt(viewConfig.getViewAdditionalProperties().get(
						EFFECTIVEDAY)));

		String effectiveEndDate = effectiveDate.toLocalDate().toString();
		return effectiveEndDate + UNDERSCORE_SEPARATOR
				+ viewConfig.getViewAdditionalProperties().get(COUNTRY);
	}

	private static String replaceZwithNumeralsOffset(String Date, String offSet) {
		String formattedDate = Date.replace("Z", offSet);
		return formattedDate;
	}

}
