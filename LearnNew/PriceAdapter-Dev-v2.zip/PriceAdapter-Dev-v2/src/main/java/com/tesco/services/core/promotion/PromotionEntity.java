package com.tesco.services.core.promotion;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PromotionEntity implements Serializable {

    @JsonProperty("@type")
    public String type;

    @JsonProperty("offerRef")
    public String offerRef;

    @JsonProperty("offerType")
    public String offerType;

    @JsonProperty("multi_buy_promo_type")
    public String multiBuyPromoType;

    @JsonProperty("locRef")
    public String locRef;

    @JsonProperty("locType")
    public String locType;

    @JsonProperty("state")
    public String state;

    @JsonProperty("name")
    public String name;


    @JsonProperty("externalPromoId")
    public String externalPromoId;

    @JsonProperty("tillRollDescription")
    public String tillRollDescription;

    @JsonProperty("couponTriggeredInd")
    public Boolean couponTriggeredInd;

    @JsonProperty("couponNumber")
    public String couponNumber;

    @JsonProperty("couponDescription")
    public String couponDescription;

    @JsonProperty("createdDate")
    public String createdDate;

	@JsonProperty("createdById")
    public String createdById;

    @JsonProperty("lastUpdateDate")
    public String lastUpdateDate;

    @JsonProperty("lastUpdatedById")
    public String lastUpdatedById;

    @JsonProperty("cfDescription1")
    private String cfDescription1;

    @JsonProperty("cfDescription2")
    private String cfDescription2;

    @JsonProperty("promoThresholds")
    public List<PromoThresholdEntity> promoThresholdEntities;

    @JsonProperty("promoRewards")
    public List<PromoRewardEntity> promoRewardEntities;

    @JsonProperty("promoItemLists")
    public List<PromoItemListEntity> promoItemListEntities;

    public String getOfferRef() {
        return offerRef;
    }

    public String getOfferType() {
        return offerType;
    }

    public String getState() {
        return state;
    }

    public String getExternalPromoId() {
        return externalPromoId;
    }

    public String getLocRef() {
        return locRef;
    }

    public String getLocType() {
        return locType;
    }

	public String getCreatedById() {
		return createdById;
	}

    public List<PromoItemListEntity> getPromoItemListEntities() {
        return promoItemListEntities;
    }

    public List<PromoThresholdEntity> getPromoThresholdEntities() {
        return promoThresholdEntities;
    }

    public void setPromoThresholdEntities(List<PromoThresholdEntity> promoThresholdEntities) {
        this.promoThresholdEntities = promoThresholdEntities;
    }

    public void addPromoThresholdEntity(PromoThresholdEntity promoThresholdEntity) {
        if (this.promoThresholdEntities == null) {
            this.promoThresholdEntities = new ArrayList<>();
        }
        this.promoThresholdEntities.add(promoThresholdEntity);
    }

    public void setPromoItemListEntities(List<PromoItemListEntity> promoItemListEntities) {
        this.promoItemListEntities = promoItemListEntities;
    }

    public List<PromoRewardEntity> getPromoRewardEntities() {
        return promoRewardEntities;
    }

    public void setPromoRewardEntities(List<PromoRewardEntity> promoRewardEntities) {
        this.promoRewardEntities = promoRewardEntities;
    }

    public void addPromoRewardEntities(PromoRewardEntity promoRewardEntities) {
        if (this.promoRewardEntities == null) {
            this.promoRewardEntities = new ArrayList<>();
        }
        this.promoRewardEntities.add(promoRewardEntities);
    }

    public String getLastUpdateDate() {
        return lastUpdateDate;
    }

    public void setLastUpdateDate(String lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    @JsonProperty("cfDescription1")
    public String getCfDescription1() {
        return cfDescription1;
    }

    @JsonProperty("cfDescription1")
    public void setCfDescription1(String cfDescription1) {
        this.cfDescription1 = cfDescription1;
    }

    @JsonProperty("cfDescription2")
    public String getCfDescription2() {
        return cfDescription2;
    }

    @JsonProperty("cfDescription2")
    public void setCfDescription2(String cfDescription2) {
        this.cfDescription2 = cfDescription2;
    }

    @Override
    public String toString() {
        return "PromotionEntity{" +
                "type='" + type + '\'' +
                ", offerRef='" + offerRef + '\'' +
                ", offerType='" + offerType + '\'' +
                ", multiBuyPromoType='" + multiBuyPromoType + '\'' +
                ", locRef='" + locRef + '\'' +
                ", locType='" + locType + '\'' +
                ", state='" + state + '\'' +
                ", name='" + name + '\'' +
                ", externalPromoId='" + externalPromoId + '\'' +
                ", tillRollDescription='" + tillRollDescription + '\'' +
                ", couponTriggeredInd=" + couponTriggeredInd +
                ", couponNumber='" + couponNumber + '\'' +
                ", couponDescription='" + couponDescription + '\'' +
                ", createdDate='" + createdDate + '\'' +
                ", createdById='" + createdById + '\'' +
                ", lastUpdateDate='" + lastUpdateDate + '\'' +
                ", lastUpdatedById='" + lastUpdatedById + '\'' +
                ", cfDescription1='" + cfDescription1 + '\'' +
                ", cfDescription2='" + cfDescription2 + '\'' +
                ", promoThresholdEntities=" + promoThresholdEntities +
                ", promoRewardEntities=" + promoRewardEntities +
                ", promoItemListEntities=" + promoItemListEntities +
                '}';
    }
    
	public PromotionEntity deepCopy() throws Exception {
		// Serialization of object
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		ObjectOutputStream out = new ObjectOutputStream(bos);
		out.writeObject(this);
		// De-serialization of object
		ByteArrayInputStream bis = new ByteArrayInputStream(bos.toByteArray());
		ObjectInputStream in = new ObjectInputStream(bis);
		PromotionEntity copied = (PromotionEntity) in.readObject();
		in.close();
		out.close();
		bis.close();
		bos.close();
		return copied;
	}
}

