package com.tesco.services.adapters.core.utils;

public interface MetricsConstants {
	String COUNT = "Count";

	String MAX_RESPONSE_TIME = "Max";
	String MIN_RESPONSE_TIME = "Min";
	String MEAN_RESPONSE_TIME = "Mean";
	String RESPONSE_TIME_UNIT = "LatencyUnit";

	String RESPONSE_RATE_IN_A_MINUTE = "OneMinuteRate";
	String RESPONSE_RATE_IN_FIVE_MINUTES = "FiveMinuteRate";
	String RESPONSE_RATE_IN_FIFTEEN_MINUTES = "FifteenMinuteRate";
	String MEAN_RESPONSE_RATE = "MeanRate";
	String RESPONSE_RATE_UNIT = "RateUnit";
}
