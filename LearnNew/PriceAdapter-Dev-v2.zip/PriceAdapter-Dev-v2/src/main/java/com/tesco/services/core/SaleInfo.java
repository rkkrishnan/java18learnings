package com.tesco.services.core;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import static com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility.ANY;
import static com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility.NONE;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonAutoDetect(fieldVisibility = ANY, getterVisibility = NONE, setterVisibility = NONE)
public class SaleInfo implements Serializable {
    @JsonProperty
    private int zoneId;
    @JsonProperty
    private String price;

    public SaleInfo(int zoneId, String price) {
        this.zoneId = zoneId;
        this.price = price;
    }
    public SaleInfo() {
        // Empty Constructor
    }

    public int getZoneId() {
        return zoneId;
    }

    public String getPrice() {
        return price;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        SaleInfo saleInfo = (SaleInfo) o;
        /*Modified by Pallavi as part of sonar start*/
        if ((zoneId != saleInfo.zoneId)||(price != null ? !price.equals(saleInfo.price) : saleInfo.price != null)){
            return false;
        }
    /*Modified by Pallavi as part of sonar end*/
        return true;
    }

    @Override
    public int hashCode() {
        int result = zoneId;
        result = 31 * result + (price != null ? price.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "SaleInfo{" +
                "zoneId=" + zoneId +
                ", price='" + price + '\'' +
                '}';
    }

}
