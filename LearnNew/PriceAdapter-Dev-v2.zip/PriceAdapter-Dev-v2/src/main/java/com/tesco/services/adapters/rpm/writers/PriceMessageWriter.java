package com.tesco.services.adapters.rpm.writers;

import com.tesco.services.adapters.core.exceptions.WriterBusinessException;
import com.tesco.services.core.price.PriceEntity;
import com.tesco.services.exceptions.PriceBusinessException;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Created by wa68 on 05/07/2016.
 */
public interface PriceMessageWriter extends Writer {

	public <M> Map getBulkDeserialized(List<String> keys, Class<M> clazz)
			throws WriterBusinessException;

	public void writePrice(Map<String, PriceEntity> mapOfPriceEntities);

	public void deletePriceEntity(PriceEntity priceEntityMessage)
			throws PriceBusinessException;

	public void writeUpdatePriceEntityDoc(PriceEntity priceEntityMsg);

	public void writeRejects(Set rejectedProducts);
}
