package com.tesco.services;

import io.dropwizard.configuration.ConfigurationException;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.tesco.logging.LoggerConfig;

/*Configuration class*/

public class Configuration extends BaseConfiguration {

	@JsonProperty("clearance.expire.days")
	private Integer clearanceExpiredays;

	@JsonProperty("couchbase.designdoc.design.name")
	private String couchBaseDesignDocName;

	@JsonProperty("couchbase.designdoc.view.name")
	private String couchBaseViewName;

	@JsonProperty
	private String importScript;

	@JsonProperty("priceservice.import.cmhopos.replaceChar")
	private boolean isCmhoposReplaceChar;

	@JsonProperty("priceservice.price.last_updated_days")
	private Integer lastUpdatedPurgeDays;

	@JsonProperty("memchache.bucket")
	private String memchacheBucket;

	@JsonProperty("priceservice.promo.end_date_for_threshold_when_cancelled")
	private int daysToEndThresholdPromo;

	@JsonProperty("priceservice.promo.end_date_for_multibuy_when_cancelled")
	private int daysToEndMultibuyPromo;

	@JsonProperty("memchache.password")
	private String memchachePassword;

	@JsonProperty("memchache.username")
	private String memchacheUsername;

	@JsonProperty("mm.clr.data.file.name")
	private String mmClrFileName;

	/* MM clearance files path */
	@JsonProperty("mm.clr.data.dump")
	private String mmClrFilePath;

	@JsonProperty("mm.clr.import.failed.file")
	private String mmClrImportFailedFile;

	@JsonProperty("mm.clr.types")
	private String[] mmClrTypes;

	@JsonProperty("couchbase.designdoc.view.pageno")
	private Integer paginationCount;

	@JsonProperty("price.service.url")
	private String priceServiceUrl;

	/* Added for PS-368 -- Start */
	@JsonProperty("product.purge.tpnb")
	private String[] productPurgeTpnb;

	@JsonProperty("product.service.url")
	private String productServiceUrl;

	@JsonProperty("reject.file.path")
	private String rejectFilePath;

	/* Added for PS-386 -- Start */
	@JsonProperty("rpm.cre.data.dump")
	private String rpmClearanceCrePath;

	@JsonProperty("rpm.del.data.dump")
	private String rpmClearanceDelPath;

	@JsonProperty("rpm.mod.data.dump")
	private String rpmClearanceModPath;

	@JsonProperty("rpm.clr.cre.file")
	private String rpmClrCreFileName;

	@JsonProperty("rpm.clr.data.dump")
	private String rpmClrDataDumpPath;

	@JsonProperty("rpm.clr.del.file")
	private String rpmClrDelFileName;

	@JsonProperty("avg.weight.file.name")
	private String avgWeightFileName;

	@JsonProperty("rpm.clr.import.failed.file")
	private String rpmClrImportFailedFile;

	@JsonProperty("rpm.clr.mod.file")
	private String rpmClrModFileName;

	@JsonProperty("rpm.clr.types")
	private String[] rpmClrTypes;

	/* RPM extracts files path */
	@JsonProperty("rpm.price.zone.data.dump")
	private String rpmPriceZoneDataPath;

	@JsonProperty("rpm.promo.desc.extract.data.dump")
	private String rpmPromoDescExtractDataPath;

	@JsonProperty("rpm.promo.extract.data.dump")
	private String rpmPromoExtractDataPath;

	@JsonProperty("rpm.promo.zone.data.dump")
	private String rpmPromoZoneDataPath;

	@JsonProperty("rpm.store.data.dump")
	private String rpmStoreDataPath;

	/* Sonetto files' path */
	@JsonProperty("sonetto.promotions.data.dump")
	private String sonettoPromotionXMLDataPath;

	@JsonProperty("sonetto.promotions.xsd")
	private String sonettoPromotionXSDDataPath;

	@JsonProperty("sonetto.shelfUrl")
	private String sonettoShelfImageUrl;

	@JsonProperty("teauth.file.path")
	private String teauthFilePath;

	@JsonProperty("teauth.memchache.mode")
	private boolean teauthMemchacheMode;

	@JsonProperty("teauth.run.types")
	private String[] teauthRunTypes;

	@JsonProperty("teauth.service.version")
	private String teauthServiceVersion;

	@JsonProperty("version")
	private String version;

	@JsonProperty("promo.data.dump")
	private String promotionFilePath;

	@JsonProperty("price.data.dump")
	private String priceFilePath;

	@JsonProperty("promo.onetime.file")
	private String promotionOneTImeFileName;

	@JsonProperty("rpm.zone.data.dump")
	private String rpmZoneDataDump;

	@JsonProperty("jmx.connector.serviceurl")
	private String jmxServiceUrl;

	@JsonProperty("jmx.connector.uid")
	private String jmxConnectorUid;

	@JsonProperty("jmx.connector.pwd")
	private String jmxConnectorPwd;

	@JsonProperty("rpm.subgroup.data.dump")
	private String rpmSubgroupDataDumpPath;

	@JsonProperty("sonetto.product.avg.weight.uk.data.dump")
	private String productAvgWeightDataDump;

	@JsonProperty("sonetto.product.avg.weight.roi.data.dump")
	private String productAvgWeightRoiDataDump;

	@JsonProperty("service.server.url.types")
	private String[] serviceServerUrlTypes;

	// Property for setting event topic
	@JsonProperty("eventPublishJMS")
	private EventPublisherConfiguration[] eventConfigs;

	@JsonProperty("rpm.item.default.uom.dump")
	private String rpmItemDefaultUomDump;

	@JsonProperty("logger")
	private LoggerConfig loggerConfig;

	public String getJmxServiceUrl() {
		return jmxServiceUrl;
	}

	public String getJmxConnectorUid() {
		return jmxConnectorUid;
	}

	public String getJmxConnectorPwd() {
		return jmxConnectorPwd;
	}

	public String getRpmZoneDataDump() {
		return rpmZoneDataDump;
	}

	public Integer getClearanceExpiredays() {
		return clearanceExpiredays;
	}

	public String getCouchBaseDesignDocName() {
		return couchBaseDesignDocName;
	}

	public String getCouchBaseViewName() {
		return couchBaseViewName;
	}

	public String getImportScript() {
		return importScript;
	}

	public int getDaysToEndThresholdPromo() {
		return daysToEndThresholdPromo;
	}

	public int getDaysToEndMultibuyPromo() {
		return daysToEndMultibuyPromo;
	}

	public Integer getLastUpdatedPurgeDays() {
		return lastUpdatedPurgeDays;
	}

	public String getMemchacheBucket() {
		return memchacheBucket;
	}

	public String getMemchachePassword() {
		return memchachePassword;
	}

	public String getMemchacheUsername() {
		return memchacheUsername;
	}

	public String getMmClrFileName() {
		return mmClrFileName;
	}

	public String getAvgWeightFileName() {
		return avgWeightFileName;
	}

	public String getMmClrFilePath() {
		return mmClrFilePath;
	}

	public String getMmClrImportFailedFile() {
		return mmClrImportFailedFile;
	}

	public String[] getMmClrTypes() {
		return mmClrTypes;
	}

	public Integer getPaginationCount() {
		return paginationCount;
	}

	public String getPriceServiceUrl() {
		return priceServiceUrl;
	}

	public String[] getProductPurgeTpnb() {
		return productPurgeTpnb;
	}

	public String getproductServiceUrl() {
		return productServiceUrl;
	}

	public String getPromotionFilePath() {
		return promotionFilePath;
	}

	public String getPriceFilePath() {
		return priceFilePath;
	}

	public String getPromotionOneTImeFileName() {
		return promotionOneTImeFileName;
	}

	public String getRejectFilePath() {
		return rejectFilePath;
	}

	public String getRpmClearanceCrePath() {
		return rpmClearanceCrePath;
	}

	public String getRpmClearanceDelPath() {
		return rpmClearanceDelPath;
	}

	public String getRpmClearanceModPath() {
		return rpmClearanceModPath;
	}

	public String getRpmClrCreFileName() {
		return rpmClrCreFileName;
	}

	public String getRpmClrDataDumpPath() {
		return rpmClrDataDumpPath;
	}

	public String getRpmClrDelFileName() {
		return rpmClrDelFileName;
	}

	public String getRpmClrImportFailedFile() {
		return rpmClrImportFailedFile;
	}

	public String getRpmClrModFileName() {
		return rpmClrModFileName;
	}

	public String[] getRpmClrTypes() {
		return rpmClrTypes;
	}

	public String getRPMPriceZoneDataPath() {
		return rpmPriceZoneDataPath;
	}

	public String getRPMPromoDescExtractDataPath() {
		return rpmPromoDescExtractDataPath;
	}

	/*
	 * Added by Sushil PS-114 to configure couchbase's design doc and view name-
	 * Start
	 */

	public String getRPMPromoExtractDataPath() {
		return rpmPromoExtractDataPath;
	}

	public String getRPMPromoZoneDataPath() {
		return rpmPromoZoneDataPath;
	}

	public String getRPMStoreDataPath() throws ConfigurationException {
		return rpmStoreDataPath;
	}

	public String getSonettoPromotionsXMLDataPath()
			throws ConfigurationException {
		return sonettoPromotionXMLDataPath;
	}

	public String getSonettoPromotionXSDDataPath()
			throws ConfigurationException {
		return sonettoPromotionXSDDataPath;
	}

	public String getSonettoShelfImageUrl() throws ConfigurationException {
		return sonettoShelfImageUrl;
	}

	public String getTeauthFilePath() {
		return teauthFilePath;
	}

	public String[] getTeauthRunTypes() {
		return teauthRunTypes;
	}

	/* Added for PS-386 -- End */

	public String getTeauthServiceVersion() {
		return teauthServiceVersion;
	}

	public String getVersion() {
		return version;
	}

	public boolean isCmhoposReplaceChar() {
		return isCmhoposReplaceChar;
	}

	public boolean isTeauthMemchacheMode() {
		return teauthMemchacheMode;
	}

	public boolean setCmhoposReplaceChar(boolean isCmhoposReplaceChar) {
		return isCmhoposReplaceChar;
	}

	public String getRpmSubgroupDataDumpPath() {
		return rpmSubgroupDataDumpPath;
	}

	public String getProductAvgWeightDataDump() {
		return productAvgWeightDataDump;
	}

	public void setProductAvgWeightDataDump(String productAvgWeightDataDump) {
		this.productAvgWeightDataDump = productAvgWeightDataDump;
	}

	public String getProductAvgWeightRoiDataDump() {
		return productAvgWeightRoiDataDump;
	}

	public void setProductAvgWeightRoiDataDump(
			String productAvgWeightRoiDataDump) {
		this.productAvgWeightRoiDataDump = productAvgWeightRoiDataDump;
	}

	public String[] getServiceServerUrlTypes() {
		return serviceServerUrlTypes;
	}

	public EventPublisherConfiguration[] getEventConfigs() {
		return eventConfigs;
	}

	public String getRpmItemDefaultUomDump() {
		return rpmItemDefaultUomDump;
	}

	public void setRpmItemDefaultUomDump(String rpmItemDefaultUomDump) {
		this.rpmItemDefaultUomDump = rpmItemDefaultUomDump;
	}

	public LoggerConfig getLoggerConfig() {
		return loggerConfig;
	}

}
