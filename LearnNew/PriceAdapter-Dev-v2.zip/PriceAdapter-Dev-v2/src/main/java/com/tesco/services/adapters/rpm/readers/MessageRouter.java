package com.tesco.services.adapters.rpm.readers;

import com.tesco.services.exceptions.MessageRouterException;

/**
 * Created by iv16 on 5/18/2015.
 */
public interface MessageRouter {

	public void route(String message) throws MessageRouterException;

}
