package com.tesco.services.adapters.rpm.writers.impl;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tesco.services.Configuration;
import com.tesco.services.adapters.core.exceptions.WriterBusinessException;
import com.tesco.services.adapters.core.utils.MMClearanceMetrics;
import com.tesco.services.adapters.rpm.events.impl.ClearanceEventData;
import com.tesco.services.adapters.rpm.events.ClearanceEventHandler;
import com.tesco.services.core.*;
import com.tesco.services.event.exception.EventPublishException;
import com.tesco.services.repositories.Repository;
import com.tesco.services.repositories.RepositoryImpl;
import com.tesco.services.resources.ImportResource;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.PriceConstants;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;
import org.joda.time.DateTime;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import java.io.*;
import java.nio.file.Files;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * This class will process the MM clearance file and also enable
 * restart-ability. Method :writeMMClearancePrice() - Reads the MM Clearance
 * file line by line. Header and footer will not be processed. Method
 * :insertClearanceProductIfEligible() - Inserts the MM clearance document to CB
 * Method :getfailedProductInProviousRunIfExist() - Fetches failed product from
 * previous run failed file Method :deletefailedProductInProviousRun() - Deletes
 * the failed products file Method :writeFailedProductDetailsToFile() - Creates
 * failed product file based on run Identifier when ever import fails
 **/
public class MMWriter implements
		com.tesco.services.adapters.rpm.writers.Writer {
	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger("MM Import");
	private static final MMClearanceMetrics MMCLEARANCEMETRICS = MMClearanceMetrics
			.getInstance();

	private Configuration configuration;
	private BufferedReader mmClrFileReader;
	private Repository repository;
	private String runIdentifier;
	private String lastProductId = "";
	private String identifiedFailedProduct = "";
	private ClearanceProductMapper clearanceProductMapper;
	File failedFile;
	File failedClearanceMapFile;
	FileWriter fileWriter;
	FileReader fileReader;
	BufferedReader mmClrFailedFileReader;
	private Dockyard dockyard;
	BufferedWriter bufferedWriter;
	private ClearanceEventHandler clearanceEventHandler = null;
	ClearanceEventData mmClearanceEventMap = new ClearanceEventData();

	public String getRunIdentifier() {
		return runIdentifier;
	}

	public void setRunIdentifier(String runIdentifier) {
		this.runIdentifier = runIdentifier;
	}

	public FileReader getFileReader(File rpmClrFailedDatafile)
			throws FileNotFoundException {
		if (fileReader == null) {
			fileReader = new FileReader(rpmClrFailedDatafile);
		}
		return fileReader;
	}

	public void setFileReader(FileReader fileReader) {
		this.fileReader = fileReader;
	}

	public BufferedReader getMmClrFailedFileReader(FileReader fileReader) {
		if (mmClrFailedFileReader == null) {
			mmClrFailedFileReader = new BufferedReader(fileReader);
		}
		return mmClrFailedFileReader;
	}

	public void setMmClrFailedFileReader(BufferedReader mmClrFailedFileReader) {
		this.mmClrFailedFileReader = mmClrFailedFileReader;
	}

	public BufferedWriter getBufferedWriter(FileWriter fileWriter) {
		if (bufferedWriter == null) {
			bufferedWriter = new BufferedWriter(fileWriter);

		}
		return bufferedWriter;
	}

	public void setBufferedWriter(BufferedWriter bufferedWriter) {
		this.bufferedWriter = bufferedWriter;
	}

	public void setFileWriter(FileWriter fileWriter) {
		this.fileWriter = fileWriter;
	}

	public FileWriter getFileWriter(File rpmClrFailedDatafile)
			throws IOException {
		if (fileWriter == null) {
			fileWriter = new FileWriter(rpmClrFailedDatafile);
		}
		return fileWriter;
	}

	public File getFailedFile(String path) {
		if (failedFile == null) {
			failedFile = new File(path);
		}
		return failedFile;
	}

	public void setFailedFile(File failedFile) {
		this.failedFile = failedFile;
	}

	public File getMMFailedMapFile(String path) {
		if (failedClearanceMapFile == null) {
			failedClearanceMapFile = new File(path);
		}
		return failedClearanceMapFile;
	}

	public Dockyard getDockyard() {

		if (dockyard == null) {
			dockyard = new Dockyard();
		}
		return dockyard;
	}

	public void setDockyard(Dockyard dockyard) {
		this.dockyard = dockyard;
	}

	/**
	 * Constructor MMWriter
	 *
	 * @param configuration
	 * @param repository
	 */

	@Inject
	public MMWriter(@Named("configuration") Configuration configuration,
			@Named("repository") Repository repository,
			@Named("clearanceEventHandler")ClearanceEventHandler clearanceEventHandler) {
		this.configuration = configuration;
		this.repository = repository;
		this.clearanceEventHandler = clearanceEventHandler;
	}

	public MMWriter(Configuration configuration,
			RepositoryImpl repository,
			BufferedReader mmClrFileReader,
			ClearanceEventHandler clearanceEventHandler,
			ClearanceProductMapper clearanceProductMapper) {
		this.configuration = configuration;
		this.repository = repository;
		this.mmClrFileReader = mmClrFileReader;
		this.clearanceEventHandler = clearanceEventHandler;
		this.clearanceProductMapper = clearanceProductMapper;
	}

	public BufferedReader getMmClrFileReader() throws IOException {
		String filePath = configuration.getMmClrFilePath() + "/"
				+ runIdentifier + "/" + configuration.getMmClrFileName();
		File mmDatafile = new File(filePath);
		FileReader reader = new FileReader(mmDatafile);
		BufferedReader mmClrFileReader = new BufferedReader(reader);
		return mmClrFileReader;
	}

	public void write(String fileName) throws WriterBusinessException {

		LOGGER.info("Importing MM clearance prices into Couchbase");
		try {
			if (mmClrFileReader == null) {
				mmClrFileReader = getMmClrFileReader();
				clearanceProductMapper = new ClearanceProductMapper(
						repository);
			}

			String failedProduct = getfailedProductInProviousRunIfExist();
			if (failedProduct != null && failedProduct.length() != 0) {
				identifiedFailedProduct = failedProduct;
				LOGGER.info("Product :" + identifiedFailedProduct
						+ " failed in Last Run for MM " + runIdentifier
						+ " Import will restart from this product");
				deletefailedProductInProviousRun();
				writeMMClearancePrice();
				deletefailedProductDetailsMapFile();
			} else {
				writeMMClearancePrice();
				deletefailedProductInProviousRun();
				deletefailedProductDetailsMapFile();
				LOGGER.info("Successfully imported MM data for " + new Date());
			}
		} catch (StringIndexOutOfBoundsException exception) {
			ImportResource.setErrorString(runIdentifier,
					"String index out of bound Exception");
			try {
				writeFailedProductDetailsToFile();
				writeFailedProductDetailsMapToFile(mmClearanceEventMap);
			} catch (IOException e) {
				LOGGER.error(
						"Error creating errorfile for MM " + runIdentifier, e);
			}

			LOGGER.error("Error importing MM data", exception);

		} catch (Exception exception) {
			ImportResource.setErrorString(runIdentifier, exception.toString());
			try {
				writeFailedProductDetailsToFile();
				writeFailedProductDetailsMapToFile(mmClearanceEventMap);
			} catch (IOException e) {

				LOGGER.error(
						"Error creating errorfile for MM " + runIdentifier, e);
			}

			LOGGER.error("Error importing MM data", exception);

		} finally {
			ImportResource.getImportSemaphoreForIdentifier(runIdentifier)
					.release();
			HashSet<String> productsWithoutPrice = clearanceProductMapper
					.getProductsWithoutPrice();
			if (!productsWithoutPrice.isEmpty()) {
				String date = Dockyard.getSysDate("yyyyMMddHHmmss");
				getDockyard().writeProductDetailsToFile(
						configuration.getRejectFilePath() + "/REJECT_FILE_"
								+ runIdentifier + "_" + date + ".log",
						productsWithoutPrice);
				clearanceProductMapper.setClearanceMMProduct();
			}
		}
	}

	private void writeMMClearancePrice() throws IOException, ParseException,
			EventPublishException {
		ClearanceMMProduct clearanceProduct = new ClearanceMMProduct();
		boolean loadFailedMapFromFile = false;
		String line;
		String prevItem = null;
		String curItem = null;
		boolean isNewProduct = false;
		boolean continueLoop = false;
		// instantiate Map , PRIS-1692-National Clearance created - event
		// publication - MM clearances
		ClearanceEventData nationalClearanceDataEventMap = new ClearanceEventData();
		int recordsTotalProcessed = 0;
		while ((line = mmClrFileReader.readLine()) != null) {
			recordsTotalProcessed++;
			MMCLEARANCEMETRICS.logMessageProcessingStartTime();

			if (!(line.startsWith("0") || line.startsWith("9"))
					&& line.length() != 0) {
				curItem = line.substring(1, 10);
				lastProductId = curItem;
				if (identifiedFailedProduct.length() == 0
						|| curItem.equals(identifiedFailedProduct)
						|| continueLoop) {
					ClearanceData clearanceData = new ClearanceData();
					clearanceData = clearanceData
							.getClearanceDataWithStore(line);
					if (clearanceData.getChargeType().equals(
							PriceConstants.STORE_IN_FILE_CODE)
							&& !loadFailedMapFromFile
							&& curItem.equals(identifiedFailedProduct)) {
						mmClearanceEventMap = readFailedProductDetailsMapFromFile();
						loadFailedMapFromFile = true;
					}
					continueLoop = true;
					if (Dockyard.isSpaceOrNull(prevItem)
							&& !Dockyard.isSpaceOrNull(curItem)) {
						isNewProduct = true;
					} else if (prevItem != null && !curItem.equals(prevItem)) {
						isNewProduct = true;

						try {
							insertClearanceProductIfEligible(clearanceProduct,
									nationalClearanceDataEventMap);
							// Reset event data list for sending the clearance
							// events , PRIS-1692-National Clearance created -
							// event
							// publication - MM clearances
							nationalClearanceDataEventMap = new ClearanceEventData();
						} catch (Exception ex) {
							ImportResource.setErrorString(runIdentifier,
									ex.toString());
							try {
								writeFailedProductDetailsToFile();
							} catch (IOException e) {
								LOGGER.error("Error creating errorfile for MM "
										+ runIdentifier, e);
							}
							LOGGER.error("Error importing MM data", ex);
						}
					}
					clearanceProduct = clearanceProductMapper
							.mapLineDataToClearanceMMProduct(line,
									isNewProduct, runIdentifier);
					if (clearanceData.getChargeType().equals(
							PriceConstants.STORE_IN_FILE_CODE)) {
						processClearanceEvents(clearanceProduct, line,
								mmClearanceEventMap, clearanceData);
					} else {
						processClearanceEvents(clearanceProduct, line,
								nationalClearanceDataEventMap, clearanceData);
					}
					prevItem = curItem;
					isNewProduct = false;
				}
			}
			MMCLEARANCEMETRICS.logMessageProcessingEndTime();

		}
		try {
			insertClearanceProductIfEligible(clearanceProduct,
					nationalClearanceDataEventMap);
			if (mmClearanceEventMap.size() > 0) {
				clearanceEventHandler
						.publishEventsForClearances(mmClearanceEventMap);
			}
		} catch (Exception ex) {
			ImportResource.setErrorString(runIdentifier, ex.toString());
			try {
				writeFailedProductDetailsToFile();
			} catch (IOException e) {
				LOGGER.error(
						"Error creating errorfile for MM " + runIdentifier, e);
			}

			LOGGER.error("Error importing MM data", ex);
		}
		mmClrFileReader.close();
		// Added for PRIS-2203
		LOGGER.info("MM Clearance documents processed : "
				+ recordsTotalProcessed);
	}

	private void processClearanceEvents(ClearanceMMProduct clearanceProduct,
			String line, Map<String, Set<String>> mmClearanceDataEventMap,
			ClearanceData clearanceData) throws ParseException {
		if (clearanceProduct != null
				&& (isMMClearanceCreateCase(clearanceData)
						|| isMMClearanceDeleteCase(clearanceData) || isMMClearanceEndDateChangedCase(clearanceData))) {
			populateMMClearanceEventDataMap(line, mmClearanceDataEventMap);
		}
	}

	private String getfailedProductInProviousRunIfExist() throws IOException {
		failedFile = getFailedFile(configuration.getMmClrImportFailedFile()
				+ "/RR_MM_" + runIdentifier + ".txt");
		String line;

		String failedProduct = "";
		try {
			fileReader = getFileReader(failedFile);
			mmClrFailedFileReader = getMmClrFailedFileReader(fileReader);
			while ((line = mmClrFailedFileReader.readLine()) != null) {
				failedProduct = line;
			}
			mmClrFailedFileReader.close();
		} catch (FileNotFoundException e) {
			return null;
		} catch (IOException e) {
			LOGGER.error("Failed to read the file  ", e);
			return null;
		}
		return failedProduct;
	}

	public void insertClearanceProductIfEligible(
			ClearanceMMProduct clearanceProduct,
			ClearanceEventData clearanceDataEventMap) throws Exception {
		/** Remove all the expired clearances based on end-date */
		if ((clearanceProduct != null)
				&& removeExpiredAndEmptyClearance(clearanceProduct,
						clearanceDataEventMap)) {
			repository.insertObject(
					PriceConstants.CLEARANCE_MM_PRODUCT_KEY_PREFIX
							+ clearanceProduct.getProductId(), clearanceProduct);
			// Trigger the clearance events
			if (clearanceDataEventMap.size() > 0) {
				clearanceEventHandler
						.publishEventsForClearances(clearanceDataEventMap);
			}
		}
	}

	/**
	 * Function will return TRUE if the expired clearances are deleted but the
	 * document is not empty and should be inserted into CB Function will return
	 * FALSE if the expired clearances are deleted and document is empty with no
	 * zone-clearance and Store-exceptions and no need to insert the document in
	 * couchbase
	 */
	private boolean removeExpiredAndEmptyClearance(
			ClearanceMMProduct clearanceProduct,
			ClearanceEventData clearanceDataEventMap)
			throws EventPublishException {
		try {
			if (!runIdentifier.equals(PriceConstants.RUN_IDENT_MMONDEMAND)) {
				List<String> effDateListZone = new ArrayList<>();
				List<String> zoneKeyList = new ArrayList<>();
				List<String> effDateListStore = new ArrayList<>();
				List<String> storeKeyList = new ArrayList<>();
				/** Iterate over Zone clearances for deletions */
				for (String zoneKey : clearanceProduct.getZonePrices().keySet()) {
					ClearanceZoneSaleInfo clearanceZoneSaleInfo = clearanceProduct
							.getZonePrices().get(zoneKey);
					for (String effDateKey : clearanceZoneSaleInfo
							.getZoneClearancePriceByDateTime().keySet()) {
						ClearanceByDateTime clearanceByDateTime = clearanceZoneSaleInfo
								.getZoneClearancePriceByDateTime().get(
										effDateKey);

						Calendar cal = Calendar.getInstance();
						SimpleDateFormat dateFormatFromCb = new SimpleDateFormat(
								"yyyy-MM-dd'T'HH:mm:ss");

						Date effDate = dateFormatFromCb
								.parse(clearanceByDateTime.getEndDateTime());
						Date currDate = dateFormatFromCb.parse(dateFormatFromCb
								.format(cal.getTime()));
						long diffDays = (currDate.getTime() - effDate.getTime())
								/ (24 * 60 * 60 * 1000);
						if (diffDays > configuration.getClearanceExpiredays()) {
							effDateListZone.add(effDateKey);

						}

					}

					clearanceZoneSaleInfo.getZoneClearancePriceByDateTime()
							.keySet().removeAll(effDateListZone);
					effDateListZone.clear();

					if (clearanceZoneSaleInfo.getZoneClearancePriceByDateTime()
							.isEmpty()) {
						zoneKeyList.add(zoneKey);
					}

				}
				clearanceProduct.getZonePrices().keySet()
						.removeAll(zoneKeyList);
				zoneKeyList.clear();

				/**
				 * Iterate over store level clearance for deleting store level
				 * expired clerances.
				 */
				for (String storeKey : clearanceProduct.getStoreExceptions()
						.keySet()) {
					ClearanceStoreSaleInfo clearanceStoreSaleInfo = clearanceProduct
							.getStoreExceptions().get(storeKey);

					for (String effDateKey : clearanceStoreSaleInfo
							.getStoreClearancePriceByDateTime().keySet()) {
						ClearanceByDateTime clearanceByDateTime = clearanceStoreSaleInfo
								.getStoreClearancePriceByDateTime().get(
										effDateKey);
						Calendar cal = Calendar.getInstance();
						SimpleDateFormat dateFormatFromCb = new SimpleDateFormat(
								"yyyy-MM-dd'T'HH:mm:ss");

						Date endDate = dateFormatFromCb
								.parse(clearanceByDateTime.getEndDateTime());
						Date currDate = dateFormatFromCb.parse(dateFormatFromCb
								.format(cal.getTime()));
						long diffDays = (currDate.getTime() - endDate.getTime())
								/ (24 * 60 * 60 * 1000);
						if (diffDays > configuration.getClearanceExpiredays()) {
							effDateListStore.add(effDateKey);

						}
					}
					clearanceStoreSaleInfo.getStoreClearancePriceByDateTime()
							.keySet().removeAll(effDateListStore);
					effDateListStore.clear();
					if (clearanceStoreSaleInfo
							.getStoreClearancePriceByDateTime().isEmpty()) {
						storeKeyList.add(storeKey);
					}
				}
				clearanceProduct.getStoreExceptions().keySet()
						.removeAll(storeKeyList);
				storeKeyList.clear();
				/**
				 * Remove the whole document if there are no zone and
				 * store-exclusion clearances
				 */
				if (clearanceProduct.getZonePrices().isEmpty()
						&& clearanceProduct.getStoreExceptions().isEmpty()) {

					repository.deleteProduct("CLRMMPROD_"
							+ clearanceProduct.getProductId());
					// Trigger the clearance events in case when clearance doc
					// deleted from database
					if (clearanceDataEventMap != null
							&& !clearanceDataEventMap.isEmpty()) {
						clearanceEventHandler
								.publishEventsForClearances(clearanceDataEventMap);
					}
					return false;
				}
			}
		} catch (ParseException e) {
			LOGGER.error("Error while parsing the date : " + e.getMessage());
		}
		return true;
	}

	private void deletefailedProductInProviousRun() {
		try {
			failedFile = getFailedFile(configuration.getMmClrImportFailedFile()
					+ "/RR_MM_" + runIdentifier + ".txt");
			if (failedFile.exists()) {
				Files.deleteIfExists(failedFile.toPath());
				LOGGER.info(failedFile.getName() + " is deleted ");
			} else {
				LOGGER.info(failedFile + " does not exist to delete ");
			}
		} catch (Exception e) {
			LOGGER.error(" file delete failed ", e);
		}
	}

	private void writeFailedProductDetailsToFile() throws IOException {
		failedFile = getFailedFile(configuration.getMmClrImportFailedFile()
				+ "/RR_MM_" + runIdentifier + ".txt");
		fileWriter = getFileWriter(failedFile);
		bufferedWriter = getBufferedWriter(fileWriter);
		bufferedWriter.write(lastProductId);
		bufferedWriter.flush();
		bufferedWriter.close();
	}

	/**
	 * @param clearanceData
	 * @param runIdentifier
	 * @return
	 * @throws ParseException
	 */
	private boolean isEligibleToSendEventDataBasedOnExpiryDate(
			ClearanceData clearanceData, String runIdentifier)
			throws ParseException {
		if (!runIdentifier.equals(PriceConstants.RUN_IDENT_MMONDEMAND)) {
			DateTime dateTime = new DateTime();
			SimpleDateFormat dateFormatFromCb = new SimpleDateFormat(
					"yyyy-MM-dd'T'HH:mm:ss");
			Date endDate = dateFormatFromCb.parse(clearanceData.getEndDate());
			Date currDate = dateFormatFromCb.parse(dateFormatFromCb
					.format(dateTime.toDate().getTime()));
			long diffDays = (currDate.getTime() - endDate.getTime())
					/ (24 * 60 * 60 * 1000);
			return diffDays <= configuration.getClearanceExpiredays();
		} else {
			return true;
		}

	}

	/*
	 * This method will populate the clearance data from the first String
	 * argument to the provided Map
	 * 
	 * @see com.tesco.services.adapters.rpm.events.ClearanceEventHandler#
	 * populateClearanceDataEventMap(java.lang.String, java.util.Map)
	 */
	private void populateMMClearanceEventDataMap(String line,
			Map<String, Set<String>> clearanceEventRecord)
			throws ParseException {
		ClearanceData clearanceData = new ClearanceData();
		Set<String> storeOrNationalLoc = null;
		clearanceData = clearanceData.getClearanceDataWithStore(line);
		String clearanceKey;
		if (PriceConstants.UPDATE_ACTION_FILE_CODE.equals(clearanceData
				.getAction())
				&& clearanceProductMapper.getOldClearanceEndDate() != null) {
			clearanceKey = buildKey(clearanceData,
					clearanceProductMapper.getOldClearanceEndDate());
		} else if (PriceConstants.UPDATE_ACTION_FILE_CODE.equals(clearanceData
				.getAction())
				&& clearanceProductMapper.getOldClearanceEndDate() == null) {
			clearanceData.setAction(PriceConstants.INSERT_ACTION_FILE_CODE);
			clearanceKey = buildKey(clearanceData, null);
		} else {
			clearanceKey = buildKey(clearanceData, null);
		}
		if (clearanceEventRecord.containsKey(clearanceKey)) {
			storeOrNationalLoc = clearanceEventRecord.get(clearanceKey);
		} else {
			storeOrNationalLoc = new HashSet<String>();
		}

		if (PriceConstants.NATIONAL_IN_FILE_CODE.equalsIgnoreCase(clearanceData
				.getChargeType())) {
			String zoneId = "";
			// TODO Currently country code not being supported through CSV input
			// file.
			// TODO We are hard coding codes here for time being. We should read
			// country code from input file once supported.
			if ((PriceConstants.CURRENCY_CODE_GBP)
					.equalsIgnoreCase(clearanceData.getCurrencyCode().trim())) {
				zoneId = "20";
			} else {
				zoneId = "21";
			}
			storeOrNationalLoc.add("Z" + "_" + zoneId + "_"
					+ clearanceData.getSourceSystem());
		} else if (PriceConstants.STORE_IN_FILE_CODE
				.equalsIgnoreCase(clearanceData.getChargeType())) {
			String nationalOrStoreIdentifier = PriceConstants.STORE_IN_FILE_CODE;
			storeOrNationalLoc.add(nationalOrStoreIdentifier + "_"
					+ clearanceData.getStoreId() + "_"
					+ clearanceData.getSourceSystem());
		}
		clearanceEventRecord.put(clearanceKey, storeOrNationalLoc);
	}

	private String buildKey(ClearanceData clearanceData,
			String oldClearanceEndDate) throws ParseException {
		if (Dockyard.isSpaceOrNull(oldClearanceEndDate)) {
			StringBuilder keyBuilder = new StringBuilder();
			keyBuilder
					.append(PriceConstants.TPNB_IDENTIFIER + ":"
							+ clearanceData.getProductId()).append("_")
					.append(clearanceData.getChargeType()).append("_")
					.append(clearanceData.getEffevDate()).append("_")
					.append(clearanceData.getCurrencyCode().trim()).append("_")
					.append(clearanceData.getAction());
			return keyBuilder.toString();
		} else {
			String action = "";
			if (isClearanceEndDateChanged(oldClearanceEndDate,
					clearanceData.getEndDate())) {
				action = PriceConstants.UPDATE_CLR_END_DATE_ACTION_FILE_CODE;
			} else {
				action = clearanceData.getAction();
			}
			StringBuilder keyBuilder = new StringBuilder();
			SimpleDateFormat dateFormatFromFiles = new SimpleDateFormat(
					"yyyy-MM-dd'T'HH:mm:ss");
			SimpleDateFormat isodateformat = new SimpleDateFormat("yyyyMMdd");
			Date formattedDate = dateFormatFromFiles.parse(oldClearanceEndDate);
			keyBuilder
					.append(PriceConstants.TPNB_IDENTIFIER + ":"
							+ clearanceData.getProductId())
					.append("_")
					.append(clearanceData.getChargeType())
					.append("_")
					.append(Dockyard.getISO8601FormatStartDate(isodateformat
							.format(formattedDate))).append("_")
					.append(clearanceData.getCurrencyCode().trim()).append("_")
					.append(action);
			return keyBuilder.toString();
		}

	}

	/**
	 * Method writeFailedProductDetailsMapToFile This method write the
	 * clearanceEventMap to the file
	 * 
	 * @throws IOException
	 */
	private void writeFailedProductDetailsMapToFile(
			Map<String, Set<String>> clearanceEventMap) throws IOException {
		failedClearanceMapFile = getMMFailedMapFile(configuration
				.getMmClrImportFailedFile()
				+ "/RR_MM_EVENTMAP_"
				+ runIdentifier + ".txt");
		ObjectMapper mapper = new ObjectMapper();
		mapper.writeValue(failedClearanceMapFile, clearanceEventMap);
	}

	/**
	 * Method readFailedProductDetailsMapFromFile This method read the
	 * clearanceEventMap from the file
	 * 
	 * @throws Exception
	 */
	private ClearanceEventData readFailedProductDetailsMapFromFile()
			throws IOException {
		failedClearanceMapFile = getMMFailedMapFile(configuration
				.getMmClrImportFailedFile()
				+ "/RR_MM_EVENTMAP_"
				+ runIdentifier + ".txt");
		ClearanceEventData clearanceFailedDataEventMap = new ClearanceEventData();
		ObjectMapper mapper = new ObjectMapper();
		clearanceFailedDataEventMap = mapper.readValue(failedClearanceMapFile,
				new TypeReference<ClearanceEventData>() {
				});
		return clearanceFailedDataEventMap;
	}

	/**
	 * Deletes the failedProductDetailsMapFile
	 */
	private void deletefailedProductDetailsMapFile() {
		try {
			failedClearanceMapFile = getMMFailedMapFile(configuration
					.getMmClrImportFailedFile()
					+ "/RR_MM_EVENTMAP_"
					+ runIdentifier + ".txt");
			if (failedClearanceMapFile.exists()) {
				Files.deleteIfExists(failedClearanceMapFile.toPath());
				LOGGER.info(failedClearanceMapFile.getName() + " is deleted ");
			} else {
				LOGGER.info(failedClearanceMapFile
						+ " does not exist to delete ");
			}
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	private boolean isMMClearanceCreateCase(ClearanceData clearanceData)
			throws ParseException {
		return PriceConstants.INSERT_ACTION_FILE_CODE
				.equalsIgnoreCase(clearanceData.getAction())
				&& isEligibleToSendEventDataBasedOnExpiryDate(clearanceData,
						runIdentifier);
	}

	private boolean isMMClearanceDeleteCase(ClearanceData clearanceData)
			throws ParseException {
		return PriceConstants.DELETE_ACTION_FILE_CODE
				.equalsIgnoreCase(clearanceData.getAction())
				&& !runIdentifier.equals(PriceConstants.RUN_IDENT_MMONDEMAND)
				&& isEligibleToSendEventDataBasedOnExpiryDate(clearanceData,
						runIdentifier);
	}

	private boolean isMMClearanceEndDateChangedCase(ClearanceData clearanceData)
			throws ParseException {
		return PriceConstants.UPDATE_ACTION_FILE_CODE
				.equalsIgnoreCase(clearanceData.getAction())
				&& (clearanceProductMapper.getOldClearanceEndDate() != null
						&& isClearanceEndDateChanged(
								clearanceProductMapper.getOldClearanceEndDate(),
								clearanceData.getEndDate()) || clearanceProductMapper != null
						&& clearanceProductMapper.getOldClearanceEndDate() == null)
				&& isEligibleToSendEventDataBasedOnExpiryDate(clearanceData,
						runIdentifier);
	}

	private boolean isClearanceEndDateChanged(String oldClearanceEndDate,
			String newClearanceEndDateChanged) {
		return !oldClearanceEndDate.equals(newClearanceEndDateChanged);
	}
}