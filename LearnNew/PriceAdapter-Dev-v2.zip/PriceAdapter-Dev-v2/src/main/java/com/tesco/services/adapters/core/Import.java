package com.tesco.services.adapters.core;

/**
 * Created by wa68 on 27/06/2016.
 */
public interface Import extends Runnable{
	public void startImportProcess();
}
