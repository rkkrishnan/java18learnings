package com.tesco.services.repositories;

import com.google.common.base.Optional;
import com.tesco.services.exceptions.DataAccessException;

import java.util.List;
import java.util.Map;

/**
 * Created by yp21 on 26/07/2016.
 */
public interface Repository<T> {

	public Object getGenericObject(String key, final Class clazz) throws
			DataAccessException;

	public Optional<T> getGenericObject(String key, Class clazz, boolean isOptional)
			throws DataAccessException;

	public Map<String,Object> getBulk(List<String> docKeys);

	public void insertObject(String key, Object object) throws Exception;

	public void deleteProduct(String key);

	public String getMappedData(String key);

	public void mapLookUps(String primary, String secondary);


	}
