package com.tesco.services.adapters.promotion.impl;

import com.tesco.services.adapters.core.exceptions.PromotionEventException;
import com.tesco.services.adapters.core.utils.EventMetrics;
import com.tesco.services.adapters.promotion.PromotionEventHandler;
import com.tesco.services.core.ZoneEntity;
import com.tesco.services.core.promotion.PromoItemEntity;
import com.tesco.services.core.promotion.PromoRewardEntity;
import com.tesco.services.core.promotion.PromoThresholdEntity;
import com.tesco.services.event.core.EventTemplate;
import com.tesco.services.event.core.impl.MapEvent;
import com.tesco.services.event.exception.EventPublishException;
import com.tesco.services.exceptions.DataAccessException;
import com.tesco.services.leadtime.core.LeadTimeUtility;
import com.tesco.services.repositories.Repository;
import com.tesco.services.repositories.RepositoryImpl;
import com.tesco.services.utility.Dockyard;
import com.tesco.services.utility.PriceConstants;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;
import org.joda.time.DateTime;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import java.text.ParseException;
import java.util.*;

import static com.tesco.services.utility.PriceConstants.*;
import static java.lang.String.valueOf;

public class PromotionEventHandlerImpl implements PromotionEventHandler {

	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(PromotionEventHandlerImpl.class);
	private static final EventMetrics EVENTMETRICS = EventMetrics.getInstance();

	private EventTemplate eventTemplate;
	private Repository repository;

	@Inject
	public PromotionEventHandlerImpl(@Named("rtEventTemplate")EventTemplate template,
			@Named("repository") Repository repository) {
		this.eventTemplate = template;
		this.repository = repository;
	}

	@Override
	public String publishPromotionEvent(Map<String, String> promotionMapData)
			throws PromotionEventException {
		String messageId = null;
		MapEvent eventData = createEventData(promotionMapData);
		try {
			EVENTMETRICS.logEventStartTime(eventData.getEventType());
			messageId = eventTemplate.publishEvent(eventData);
			EVENTMETRICS.logEventEndTime(eventData.getEventType());
			LOGGER.debug("{} event is published with event data :{} ",
					eventData.getEventType(), eventData);
		} catch (EventPublishException publishException) {
			EVENTMETRICS.logEventEndTime(eventData.getEventType());
			EVENTMETRICS.incrementErrorCounter(eventData.getEventType());
			String errorMessage = String.format("Failed to publish %1 event :",
					eventData.getEventType());
			LOGGER.error(errorMessage, publishException);
			throw new PromotionEventException(errorMessage, publishException);
		}
		return messageId;
	}

	private MapEvent createEventData(Map<String, String> promotionMapData) {
		MapEvent eventDataEntity = new MapEvent();
		Map<String, Object> payloadData = new HashMap<>();
		Map<String, String> headerData = new HashMap<>();
		try {
			String offerId = promotionMapData.get(OFFER_ID);
			payloadData.put(OFFER_ID, offerId);
			if (promotionMapData.containsKey(PROD_REF)) {
				payloadData.put(PROD_REF, promotionMapData.get(PROD_REF));
			}
			String locationId = buildPromotionLocationId(promotionMapData);
			headerData.put(LOCATION_ID, locationId);
			String eventType = promotionMapData.get(EVENT_TYPE);
			headerData.put(EVENT_TYPE, promotionMapData.get(EVENT_TYPE));
			String leadTimeDays = promotionMapData.get(LEAD_TIME_DAYS);
			if (leadTimeDays != null) {
				headerData.put(LEAD_TIME_DAYS, leadTimeDays);
			} else {
				int leadDays = calculateLeadTime(promotionMapData, offerId);
				headerData.put(LEAD_TIME_DAYS, String.valueOf(leadDays));
			}
			if (promotionMapData.containsKey(PROD_REF)) {
				headerData.put(EVENT_CORR_ID,
						EVENT_PREFIX + promotionMapData.get(OFFER_ID) + "_"
								+ promotionMapData.get(PROD_REF));
			} else {
				headerData.put(EVENT_CORR_ID,
						EVENT_PREFIX + promotionMapData.get(OFFER_ID));
			}
			eventDataEntity.setPayloadData(payloadData);
			eventDataEntity.setHeaderData(headerData);
			eventDataEntity.setEventType(eventType);

		} catch (Exception exception) {
			LOGGER.error("Error while creating entity of event data {}",
					exception);
		}
		return eventDataEntity;
	}

	private String buildPromotionLocationId(Map<String, String> promotionMapData)
			throws DataAccessException {
		StringBuilder buildLocationId = new StringBuilder();
		String location = valueOf(promotionMapData.get(LOC_REF));
		ZoneEntity zoneEntity = (ZoneEntity) repository.getGenericObject(ZONE_KEY
				+ location, ZoneEntity.class);
		String countryCode = zoneEntity.getTslCountryCode();
		String locationId = buildLocationId.append(countryCode)
				.append(COLON_SEPARATOR).append(promotionMapData.get(LOC_TYPE))
				.append(COLON_SEPARATOR).append(location).toString();
		return locationId;
	}

	private int calculateLeadTime(Map<String, String> promotionMapData,
			String offerId) throws ParseException {
		DateTime promoEffectiveDateObj = new DateTime(
				promotionMapData.get(PriceConstants.EFFECTIVE_DATE));
		String promoPublicationDate = Dockyard
				.getSysDate(PriceConstants.ISO_8601_FORMAT);
		try {
			promoPublicationDate = Dockyard.getFormattedDate(
					promoPublicationDate,
					PriceConstants.DATE_FORMAT_YYYYMMDDHHMMSS,
					PriceConstants.ISO_8601_FORMAT);
		} catch (ParseException pe) {
			LOGGER.error(
					"Promotion Publication date conversion failed for PROMOTION ID:{}",
					offerId, pe);
			throw pe;
		}

		DateTime promoPublicationDateObj = new DateTime(promoPublicationDate);
		int leadDays = LeadTimeUtility.getLeadTime(promoEffectiveDateObj,
				promoPublicationDateObj);
		return leadDays;
	}

	private String processPromotionDetailsChangedOfferLevel(
			String promoMsgForZoneId, String promoMsgLocType,
			Map<String, Object> argumentData) throws PromotionEventException {
		String offerid = (String) argumentData.get("offerId");
		LOGGER.debug(
				"PromotionDetailsChanged message processing start at offer level for offerId:{} ",
				offerid);
		String messageId = null;
		List<PromoThresholdEntity> existingPromotionThresholdEntities = (List<PromoThresholdEntity>) argumentData
				.get("existingPromotionThresholdEntities");
		List<PromoThresholdEntity> modifiedPromotionThresholdEntities = (List<PromoThresholdEntity>) argumentData
				.get("modifiedPromotionThresholdEntities");
		List<PromoRewardEntity> existingPromoRewardEntities = (List<PromoRewardEntity>) argumentData
				.get("existingPromoRewardEntities");
		List<PromoRewardEntity> modifiedPromoRewardsEntities = (List<PromoRewardEntity>) argumentData
				.get("modifiedPromoRewardsEntities");

		if (isThresholdEntityDetailsChanged(existingPromotionThresholdEntities,
				modifiedPromotionThresholdEntities)
				|| isRewardEntityDetailsChanged(existingPromoRewardEntities,
						modifiedPromoRewardsEntities)) {
			Map<String, String> promotionMapData = new HashMap<>();
			promotionMapData.put(LOC_REF, promoMsgForZoneId);
			promotionMapData.put(LOC_TYPE, promoMsgLocType);
			promotionMapData.put(OFFER_ID, offerid);
			promotionMapData.put(EVENT_TYPE,
					PROMOTION_DETAILS_CHANGED_EVENT_TYPE);
			Map<String, DateTime> offLeveleffectiveDateMap = (Map<String, DateTime>) argumentData
					.get("offLeveleffectiveDateMap");
			promotionMapData.put(EFFECTIVE_DATE,
					offLeveleffectiveDateMap.get(offerid).toString());
			messageId = publishPromotionEvent(promotionMapData);
		}
		return messageId;
	}

	private boolean isThresholdEntityDetailsChanged(
			List<PromoThresholdEntity> existingPromotionThresholdEntities,
			List<PromoThresholdEntity> modifiedThresholdPromotionEntities) {
		Set<PromoThresholdEntity> existing = new HashSet<>(
				existingPromotionThresholdEntities);
		Set<PromoThresholdEntity> modified = new HashSet<>(
				modifiedThresholdPromotionEntities);
		return !existing.equals(modified);
	}

	private boolean isRewardEntityDetailsChanged(
			List<PromoRewardEntity> existingPromoRewardsEntities,
			List<PromoRewardEntity> modifiedPromoRewardsEntities) {
		Set<PromoRewardEntity> existing = new HashSet<>(
				existingPromoRewardsEntities);
		Set<PromoRewardEntity> modified = new HashSet<>(
				modifiedPromoRewardsEntities);
		return !existing.equals(modified);
	}

	public void processPromotionEvents(String promoMsgType,
			String promoMsgForZoneId, String promoMsgLocType,
			Map<String, Object> allEventsData) throws PromotionEventException {
		for (String eventKey : allEventsData.keySet()) {
			if (PROMOTION_DETAILS_CHANGED_OFFER_LEVEL_KEY.equals(eventKey)) {
				proceesAndPublishPromoDetailsChangedOfferLevel(promoMsgType,
						promoMsgForZoneId, promoMsgLocType, allEventsData);
			} else if (PROMOTION_DETAILS_CHANGED_PRODUCT_LEVEL_KEY
					.equals(eventKey)) {
				proceesAndPublishPromoDetailsChangedProductLevel(promoMsgType,
						promoMsgForZoneId, promoMsgLocType, allEventsData);
			} else if (PROMOTION_CREATED_LOCATION_ADDED_PRODUCT_ADDED_KEY
					.equals(eventKey)) {
				processAndPublishPromotionOrLocationOrProductAddedEvent(
						promoMsgType, promoMsgForZoneId, promoMsgLocType,
						allEventsData);
			} else if (PROMOTION_ENDDATE_CHANGED.equals(eventKey)) {
				proceesAndPublishPromotionEndDateChanged(promoMsgType,
						promoMsgForZoneId, promoMsgLocType, allEventsData);
			} else if (PROMOTION_DELETED_EVENT_TYPE.equals(eventKey)
					|| PROMOTION_LOCATION_REMOVED_EVENT_TYPE.equals(eventKey)
					|| PROMOTION_PRODUCT_REMOVED_EVENT_TYPE.equals(eventKey)) {
				processAndPublishPromotionOrLocationOrProductRemovedEvent(
						promoMsgForZoneId, promoMsgLocType, allEventsData);
			} else if (PROMOTION_ENDDATE_CHANGED_PER_ITEM.equals(eventKey)) {
				proceesAndPublishPromotionEndDateChangedPerItem(promoMsgType,
						promoMsgForZoneId, promoMsgLocType, allEventsData);
			}
		}

	}

	private void processAndPublishPromotionOrLocationOrProductRemovedEvent(
			String promoMsgForZoneId, String promoMsgLocType,
			Map<String, Object> allEventsData) throws PromotionEventException {
		for (String eventName : allEventsData.keySet()) {
			Map<String, Object> promoDataMap = (Map<String, Object>) allEventsData
					.get(eventName);
			Map<String, String> promotionEventDataMap = new HashMap<>();
			promotionEventDataMap.put(EVENT_TYPE, eventName);
			promotionEventDataMap.put(LOC_REF, promoMsgForZoneId);
			promotionEventDataMap.put(LOC_TYPE, promoMsgLocType);
			for (String offerId : promoDataMap.keySet()) {
				promotionEventDataMap.put(OFFER_ID, offerId);
				if (eventName.equals(PROMOTION_PRODUCT_REMOVED_EVENT_TYPE)) {
					List<String> effectiveDateAndTpnbList = (List<String>) promoDataMap
							.get(offerId);
					for (String effectiveDateAndTpnb : effectiveDateAndTpnbList) {
						String[] effectiveDateArray = effectiveDateAndTpnb
								.split("\\|");
						promotionEventDataMap.put(EFFECTIVE_DATE,
								effectiveDateArray[0]);
						promotionEventDataMap.put(PRODUCT_REF,
								effectiveDateArray[1]);
						publishPromotionEvent(promotionEventDataMap);
					}
				} else {
					String effectiveDate = (String) promoDataMap.get(offerId);
					promotionEventDataMap.put(EFFECTIVE_DATE, effectiveDate);
					publishPromotionEvent(promotionEventDataMap);
				}
			}
		}

	}

	private void proceesAndPublishPromotionEndDateChanged(String promoMsgType,
			String promoMsgForZoneId, String promoMsgLocType,
			Map<String, Object> allEventsData) throws PromotionEventException {

		Map<String, String> promotionMapData = new HashMap<>();
		Map<String, Object> promotionEnddateChangedMapData = (Map<String, Object>) allEventsData
				.get(PROMOTION_ENDDATE_CHANGED);
		if (promotionEnddateChangedMapData != null) {
			for (String offerId : promotionEnddateChangedMapData.keySet()) {
				Map<String, Object> promotionEndDateMap = (Map<String, Object>) promotionEnddateChangedMapData
						.get(offerId);
				promotionMapData.put(LOC_REF, promoMsgForZoneId);
				promotionMapData.put(LOC_TYPE, promoMsgLocType);
				promotionMapData.put(OFFER_ID, offerId);
				promotionMapData.put(EVENT_TYPE, PROMOTION_ENDDATE_CHANGED);
				promotionMapData.put(EFFECTIVE_DATE,
						promotionEndDateMap.get(PriceConstants.END_DATE)
								.toString());
				promotionMapData.put(PROD_REF, promotionEndDateMap
						.get(PROD_REF).toString());
				String messageId = publishPromotionEvent(promotionMapData);
				LOGGER.debug(
						"Message Id for the promotion end date changed publish event :",
						messageId);
			}
		}

	}

	private void proceesAndPublishPromotionEndDateChangedPerItem(
			String promoMsgType, String promoMsgForZoneId,
			String promoMsgLocType, Map<String, Object> allEventsData)
			throws PromotionEventException {

		Map<String, String> promotionMapData = new HashMap<>();
		Map<String, Object> promotionEnddateChangedMapData = (Map<String, Object>) allEventsData
				.get(PROMOTION_ENDDATE_CHANGED_PER_ITEM);
		if (promotionEnddateChangedMapData != null) {
			for (String offerId : promotionEnddateChangedMapData.keySet()) {
				Map<String, Object> promotionEndDateMap = (Map<String, Object>) promotionEnddateChangedMapData
						.get(offerId);
				for (String itemRef : promotionEndDateMap.keySet()) {
					promotionMapData.put(LOC_REF, promoMsgForZoneId);
					promotionMapData.put(LOC_TYPE, promoMsgLocType);
					promotionMapData.put(OFFER_ID, offerId);
					promotionMapData.put(EVENT_TYPE, PROMOTION_ENDDATE_CHANGED);
					promotionMapData.put(EFFECTIVE_DATE, promotionEndDateMap
							.get(itemRef).toString());
					promotionMapData.put(PROD_REF, TPNB_IDENTIFIER + ":"
							+ itemRef);
					String messageId = publishPromotionEvent(promotionMapData);
					LOGGER.debug(
							"Message Id for the promotion end date changed publish event :",
							messageId);
				}

			}
		}

	}

	private void proceesAndPublishPromoDetailsChangedOfferLevel(
			String promoMsgType, String promoMsgForZoneId,
			String promoMsgLocType, Map<String, Object> allEventsData)
			throws PromotionEventException {
		Map<String, Object> promotionDetailsChangedOfferLevelEventMap = (Map<String, Object>) allEventsData
				.get(PROMOTION_DETAILS_CHANGED_OFFER_LEVEL_KEY);
		if (promotionDetailsChangedOfferLevelEventMap != null) {
			for (String offerId : promotionDetailsChangedOfferLevelEventMap
					.keySet()) {
				Map<String, Object> argumentData = (Map<String, Object>) promotionDetailsChangedOfferLevelEventMap
						.get(offerId);
				if (PriceConstants.PROMO_MSG_TYPE_MOD.equals(promoMsgType)
						|| (PROMO_MSG_TYPE_CRE.equals(promoMsgType)
								&& argumentData.get("msgOfferType") != null && PROMO_MB_OFFER_TYPE
									.equals(argumentData.get("msgOfferType")))) {
					processPromotionDetailsChangedOfferLevel(promoMsgForZoneId,
							promoMsgLocType, argumentData);
				}
			}
		}
	}

	private void proceesAndPublishPromoDetailsChangedProductLevel(
			String promoMsgType, String promoMsgForZoneId,
			String promoMsgLocType, Map<String, Object> allEventsData)
			throws PromotionEventException {
		Map<String, Object> promotionDetailsChangedOfferLevelEventMap = (Map<String, Object>) allEventsData
				.get(PROMOTION_DETAILS_CHANGED_PRODUCT_LEVEL_KEY);
		if (promotionDetailsChangedOfferLevelEventMap != null) {
			for (String offerId : promotionDetailsChangedOfferLevelEventMap
					.keySet()) {
				Map<Object, Object> argumentData = (Map<Object, Object>) promotionDetailsChangedOfferLevelEventMap
						.get(offerId);
				if (PROMO_MSG_TYPE_MOD.equals(promoMsgType)
						|| (PROMO_MSG_TYPE_CRE.equals(promoMsgType)
								&& argumentData.get("msgOfferType") != null && PROMO_MB_OFFER_TYPE
									.equals(argumentData.get("msgOfferType")))) {
					argumentData.put("promoMsgForZoneId", promoMsgForZoneId);
					argumentData.put("promoMsgLocType", promoMsgLocType);
					processPromotionDetailsChangedProductLevel(argumentData);
				}
			}
		}
	}

	private void processPromotionDetailsChangedProductLevel(
			Map<Object, Object> argumentData) throws PromotionEventException {
		String offerid = (String) argumentData.get("offerId");
		List<PromoItemEntity> existingPromoItemEntities = (List<PromoItemEntity>) argumentData
				.get("existingPromoItemEntities");
		List<PromoItemEntity> modifiedPromoItemEntities = (List<PromoItemEntity>) argumentData
				.get("modifiedPromoItemEntities");
		for (PromoItemEntity existingPromoItemEntity : existingPromoItemEntities) {
			checkAndSendEventIfProductWasPricesChanged(argumentData, offerid,
					modifiedPromoItemEntities, existingPromoItemEntity);
		}
	}

	private void checkAndSendEventIfProductWasPricesChanged(
			Map<Object, Object> argumentData, String offerid,
			List<PromoItemEntity> modifiedPromoItemEntities,
			PromoItemEntity existingPromoItemEntity)
			throws PromotionEventException {
		String existingItemRef = existingPromoItemEntity.getItemRef();
		LOGGER.debug(
				"PromotionDetailsChanged message processing start at product level for tpnb:{} ",
				existingItemRef);
		for (PromoItemEntity modifiedPromoItemEntity : modifiedPromoItemEntities) {
			if (modifiedPromoItemEntity.getItemRef().equals(existingItemRef)
					&& (isWasPriceChanged(existingPromoItemEntity,
							modifiedPromoItemEntity) || isWasWasPriceChanged(
							existingPromoItemEntity, modifiedPromoItemEntity))) {
				Map<String, String> promotionMapData = new HashMap<>();
				promotionMapData.put(LOC_REF,
						(String) argumentData.get("promoMsgForZoneId"));
				promotionMapData.put(LOC_TYPE,
						(String) argumentData.get("promoMsgLocType"));
				promotionMapData.put(OFFER_ID, offerid);
				promotionMapData.put(EVENT_TYPE,
						PROMOTION_DETAILS_CHANGED_EVENT_TYPE);
				promotionMapData.put(EFFECTIVE_DATE,
						modifiedPromoItemEntity.getEffectiveDate());
				promotionMapData.put(PROD_REF, PriceConstants.TPNB_IDENTIFIER
						+ ":" + modifiedPromoItemEntity.getItemRef());
				publishPromotionEvent(promotionMapData);
			}

		}
	}

	private boolean isWasPriceChanged(PromoItemEntity existingPromoItemEntity,
			PromoItemEntity modifiedPromoItemEntity) {
		boolean isWasPriceChanged = false;
		String oldWasPrice = existingPromoItemEntity.getWasPrice();
		String newWasPrice = modifiedPromoItemEntity.getWasPrice();
		if ((oldWasPrice != null && newWasPrice != null && !oldWasPrice
				.equals(newWasPrice))
				|| (oldWasPrice == null && newWasPrice != null)
				|| (oldWasPrice != null && newWasPrice == null)) {
			isWasPriceChanged = true;
		}
		return isWasPriceChanged;
	}

	private boolean isWasWasPriceChanged(
			PromoItemEntity existingPromoItemEntity,
			PromoItemEntity modifiedPromoItemEntity) {
		boolean isWasWasPriceChanged = false;
		String oldWasWasPrice = existingPromoItemEntity.getWasWasPrice();
		String newWasWasPrice = modifiedPromoItemEntity.getWasWasPrice();
		if ((oldWasWasPrice != null && newWasWasPrice != null && !oldWasWasPrice
				.equals(newWasWasPrice))
				|| (oldWasWasPrice == null && newWasWasPrice != null)
				|| (oldWasWasPrice != null && newWasWasPrice == null)) {
			isWasWasPriceChanged = true;
		}
		return isWasWasPriceChanged;
	}

	private void processAndPublishPromotionOrLocationOrProductAddedEvent(
			String promoMsgType, String promoMsgForZoneId,
			String promoMsgLocType, Map<String, Object> allEventsData)
			throws PromotionEventException {

		Map<String, String> promotionEventDataMap = new HashMap<>();
		Map<String, Object> promoDataMap = (Map<String, Object>) allEventsData
				.get(PROMOTION_CREATED_LOCATION_ADDED_PRODUCT_ADDED_KEY);
		if (promoDataMap != null) {

			String eventType = (String) promoDataMap.get(EVENT_TYPE);
			Map<String, String> newProductItems = (Map<String, String>) promoDataMap
					.get(PROMO_PRODUCT_ITEM_LIST);

			if (eventType != null && eventType != PROMO_PRODUCT_ADDED) {
				promotionEventDataMap = prepareEventDataForPromotionCreated(
						promoMsgForZoneId, promoMsgLocType,
						promotionEventDataMap, promoDataMap);
				promotionEventDataMap.put(EFFECTIVE_DATE,
						(String) promoDataMap.get(EFFECTIVE_DATE));
				publishPromotionEvent(promotionEventDataMap);

			}
			if (eventType != null && eventType.equals(PROMO_PRODUCT_ADDED)) {

				for (String prodRef : newProductItems.keySet()) {
					promotionEventDataMap = prepareEventDataForPromotionCreated(
							promoMsgForZoneId, promoMsgLocType,
							promotionEventDataMap, promoDataMap);
					promotionEventDataMap.put(EFFECTIVE_DATE,
							newProductItems.get(prodRef));
					promotionEventDataMap.put(PRODUCT_REF,
							PriceConstants.TPNB_IDENTIFIER + ":" + prodRef);
					publishPromotionEvent(promotionEventDataMap);

				}
			}
		}

	}

	private Map<String, String> prepareEventDataForPromotionCreated(
			String promoMsgForZoneId, String promoMsgLocType,
			Map<String, String> promotionEventDataMap,
			Map<String, Object> promoDataMap) {
		promotionEventDataMap.put(LOC_REF, promoMsgForZoneId);
		promotionEventDataMap.put(LOC_TYPE, promoMsgLocType);
		promotionEventDataMap
				.put(OFFER_ID, (String) promoDataMap.get(OFFER_ID));
		promotionEventDataMap.put(EVENT_TYPE,
				(String) promoDataMap.get(EVENT_TYPE));
		return promotionEventDataMap;
	}

}
