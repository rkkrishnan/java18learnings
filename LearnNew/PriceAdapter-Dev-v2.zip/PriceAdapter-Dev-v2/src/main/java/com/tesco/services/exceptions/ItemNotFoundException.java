package com.tesco.services.exceptions;

public class ItemNotFoundException extends Exception {
    /**
     * Constructor ItemNotFoundException
     * @param message
     */
    public ItemNotFoundException(String message){
        super(message);
    }
}
