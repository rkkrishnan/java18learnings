package com.tesco.services.resources;

import com.tesco.services.adapters.core.Import;
import com.tesco.services.adapters.core.ImportPromotionJob;
import com.tesco.services.core.Promotion;
import com.tesco.services.exceptions.ImportInProgressException;
import com.tesco.services.exceptions.InvalidClrRunIdentifierException;
import com.tesco.services.resources.model.PromotionRequest;
import com.tesco.services.resources.model.PromotionRequestList;
import com.tesco.services.utility.PriceConstants;
import com.tesco.services.utility.sl4j.LoggerFactoryWrapper;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import javax.validation.Valid;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import java.util.*;
import java.util.concurrent.Semaphore;

import static com.google.common.base.Predicates.notNull;
import static com.google.common.collect.Iterables.filter;
import static com.google.common.collect.Lists.newArrayList;
import static com.tesco.services.resources.HTTPResponses.*;
import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

@Path("/promotion")
@Api(value = "/promotion", description = "Promotional Price Endpoints")
@Produces(ResourceResponse.RESPONSE_TYPE)
public class PromotionResource {

	private static final Logger LOGGER = (Logger) LoggerFactoryWrapper
			.getLogger(PromotionResource.class);

	public static Semaphore importSemaphore = new Semaphore(1);
	public static Map<String, String> errorString = new HashMap<>();
	public static Map<String, Semaphore> importSemaphoreForIdentifier = new HashMap<>();

	public static String getErrorString(String runIdentifier) {
		return errorString.get(runIdentifier);
	}

	public static void setErrorString(String runIdentifier, String error) {
		errorString.put(runIdentifier, error);
	}

	public static Semaphore getImportSemaphoreForIdentifier(
			String runIdentifier) {
		return importSemaphoreForIdentifier.get(runIdentifier);
	}

	public static Semaphore getImportSemaphore() {
		return importSemaphore;
	}

	public static Map<String, Semaphore> getImportSemaphoreForIdentifier() {
		return importSemaphoreForIdentifier;
	}

	//DropWizard upgrade changes
	private Import importPromotionJob;

	@Inject
	public PromotionResource(
			@Named("importPromotionJob") Import importPromotionJob){
		this.importPromotionJob = importPromotionJob;
	}

	@POST
	@Path("/find")
	@ApiOperation(
			value = "Find promotional prices by OfferID - ZoneId - ItemNumber (product's base tPNB)")
	@ApiResponses(value = { @ApiResponse(code = 500,
			message = "Error processing your request") })
	@Consumes(APPLICATION_JSON)
	/**
	 * Response getByOfferId
	 */
	public Response getByOfferId(
			@Valid PromotionRequestList promotionRequestList) {

		Set<PromotionRequest> uniqueRequests = new HashSet<>(
				promotionRequestList.getPromotions());
		List<PromotionRequest> uniquePromotionRequest = newArrayList(
				uniqueRequests);

		Set<Promotion> results = new HashSet<>();

		for (PromotionRequest promotionRequest : uniquePromotionRequest) {
			List<Promotion> promotions = getPromotionsByOfferIdZoneIdAndItemNumber();

			List<Promotion> nonNullPromotions = newArrayList(filter(promotions,
					notNull()));
			results.addAll(nonNullPromotions);
		}

		return ok(results);
	}

	@GET
	@Path("/")
	public Response getRoot() {
		return badRequest();
	}

	@POST
	@Path("/importpromotion/{runIdentifier}/{fileName}")
	public Response importPromotionOnetime(
			@PathParam("runIdentifier") String runIdentifier,
			@PathParam("fileName") String filename) {
		if (importSemaphoreForIdentifier.get(filename) == null) {
			importSemaphoreForIdentifier.put(filename, new Semaphore(1));
		}
		if (!importSemaphoreForIdentifier.get(filename).tryAcquire()) {
			LOGGER.info("Import already running");
			throw new ImportInProgressException();
		}
		try {

			Thread thread = new Thread(getImportPromotionJob(runIdentifier,
					filename));
			thread.start();

		} catch (InvalidClrRunIdentifierException e) {
			getImportSemaphoreForIdentifier(filename).release();
			LOGGER.error(
					"error : Import Promotion Job not Started due to invalid Run Identifier- {} {}",
					notAValidRequest().getStatusInfo().getStatusCode(),
					notAValidRequest().getStatusInfo().getReasonPhrase());
			return notAValidRequest();

		}
		return Response.ok(
				"{\"message\":\"Import for Onetime promotion Job Started.\"}")
				.build();
	}

	/**
	 * Response isImportInProgress
	 */
	@GET
	@Path("/importInProgress/{runIdentifier}/{filename}")
	public Response isImportInProgress(
			@PathParam("runIdentifier") String runIdentifier,
			@PathParam("filename") String fileName) {

		if (importSemaphoreForIdentifier.get(fileName) == null) {
			return Response.ok("{\"import\":\"Not Running\"}").build();
		}
		if (importSemaphoreForIdentifier.get(fileName).availablePermits() < 1) {
			return Response.ok("{\"import\":\"progress\"}").build();
		} else if (PromotionResource.getErrorString(fileName) != null) {

			return Response.ok(
					String.format(
							"{\"import\":\"aborted\",\n \"error\":\"%s\"}",
							PromotionResource.getErrorString(fileName)))
					.build();
		} else {
			return Response.ok("{\"import\":\"completed\"}").build();
		}
	}

	/**
	 * @param runIdentifier
	 * @return
	 * @throws InvalidClrRunIdentifierException
	 */
	public Import getImportPromotionJob(String runIdentifier,
			String fileName)
			throws InvalidClrRunIdentifierException {
		boolean isValidRun = false;
		setErrorString(fileName, null);

		List runTypes = PriceConstants.PROMOTION_IMPORT_TYPES
				.getPromotionTypes();
		for (Object runType : runTypes) {
			if (runType.toString().equalsIgnoreCase(runIdentifier)) {
				isValidRun = true;
			}
		}
		if (!isValidRun) {
			throw new InvalidClrRunIdentifierException(
					"Not a Valid Run Identifier");

		}
		((ImportPromotionJob)importPromotionJob).setRunIdentifier(runIdentifier);
		((ImportPromotionJob)importPromotionJob).setFileName(fileName);
		return importPromotionJob;
	}

	public List<Promotion> getPromotionsByOfferIdZoneIdAndItemNumber() {
		return Collections.emptyList();
	}
}
