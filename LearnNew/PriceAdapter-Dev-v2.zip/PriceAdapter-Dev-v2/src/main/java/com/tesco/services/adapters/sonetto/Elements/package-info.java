//Package Information
@XmlSchema(
        namespace = "urn:tesco.com:schemas:grocery:2.0",
        elementFormDefault = XmlNsForm.QUALIFIED)
package com.tesco.services.adapters.sonetto.Elements;
//import
import javax.xml.bind.annotation.XmlNsForm;
import javax.xml.bind.annotation.XmlSchema;