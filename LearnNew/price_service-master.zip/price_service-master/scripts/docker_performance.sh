#!/bin/bash
script_dir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
. $script_dir/docker_include.sh
OPT="-e PRICE_URL=http://${repo}/price-service-4.0-SNAPSHOT-all.jar"

create_network
start_server
build
start_price
start_builder
check_price_is_running

echo "Running Tests"
echo "============="
echo
run_tests

