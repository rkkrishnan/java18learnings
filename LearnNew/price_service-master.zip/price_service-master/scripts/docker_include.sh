#!/bin/bash
set -e
[ -n "${DEBUG}" ] && set -x
network=${NETWORK:-"net.1"}
price=price
repo=repo
builder=builder
run_in=${RUN_IN:-"docker exec -it $builder"}

docker_kill(){
  docker kill  $1 &>/dev/null || echo -n ""
  docker rm  $1 &>/dev/null || echo -n ""
}

cleanup(){
    docker_kill $repo
    docker_kill $price
    docker_kill builder
    docker network disconnect ${network} `hostname` &> /dev/null || echo "done `hostname` "
    docker network rm $network &>/dev/null || echo -n ""
}


start_server(){
   docker run -d --net $network --name $repo -v `pwd`/build/libs:/usr/share/nginx/html nginx >/dev/null || exit 1
}

build(){
    echo "Building workspace"
    echo "=================="
    echo
    ./gradlew -x test -x bdd build  || exit 1
}

start_price(){
   docker run -d --name $price --net $network  $OPT -e VERSION=$PRICE_VERSION  ${DOCKER_REPO}price:latest >/dev/null|| exit 1
   docker logs $price
}

start_builder(){
 docker run -dit \
  --name builder \
  --net $network \
  -v `pwd`:/home/ec2-user/workspace \
  -v ~/.gradle:/home/ec2-user/.gradle \
  -e GRADLE_OPTS="-Dgradle.user.home=/home/ec2-user/.gradle" \
  ${DOCKER_REPO}builder >/dev/null || exit 1
}

display_message(){
 echo "====================================="
 echo " Building in docker"
 echo "===================="
 echo " price: $price"
 echo " network: $network"
 echo " repo:$repo"
 echo "====================================="
 echo
}

run_tests(){
 $run_in /bin/bash -c "cd /home/ec2-user/workspace; ./gradlew -DHOST=http://$price:8080 -x test -x bdd gatling" || exit 1

}

check_price_is_running(){
  $run_in ping -c 1 -t 1 $price >/dev/null || exit 1
}

create_network(){
  docker network create $network >/dev/null || exit 1
}

connect_to_network(){
  docker network connect $network `hostname`
}

display_message
trap cleanup EXIT
cleanup