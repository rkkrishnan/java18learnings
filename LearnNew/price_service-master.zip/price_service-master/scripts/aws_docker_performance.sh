#!/bin/bash
#
#  This is the script used in aws to start up the performance test using all the docker containers.
#
script_dir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
NETWORK="net.$EXECUTOR_NUMBER"
RUN_IN=" "

if [ -z ${PRICE_VERSION} ]; then echo "ERROR: PRICE_VERSION needs to be defined"; exit 1; fi
if [ -z ${DOCKER_REPO} ]; then echo "ERROR: DOCKER_REPO needs to be defined for AWS"; exit 1; fi
. $script_dir/docker_include.sh

create_network
connect_to_network
start_price
check_price_is_running

echo "Running Tests"
echo "============="
echo
./gradlew -x test -x bdd gatling

