package com.tesco.price;

import io.vertx.core.AsyncResult;
import io.vertx.core.DeploymentOptions;
import io.vertx.core.Handler;
import io.vertx.core.Vertx;
import io.vertx.rx.java.ObservableFuture;
import io.vertx.rx.java.RxHelper;
import rx.Observable;

import java.io.IOException;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

public class TestManager {

    private final Vertx vertx = Vertx.vertx();

    public void setUp() {
        observe(handler -> deploy(new DeploymentOptions(), handler)).timeout(10, TimeUnit.SECONDS).toBlocking().first();
    }

    private void deploy(DeploymentOptions options, Handler<AsyncResult<String>> handler) {
        vertx.deployVerticle(Price.class.getName(), options, handler);
    }

    private Observable<String> observe(Consumer<Handler<AsyncResult<String>>> call) {
        ObservableFuture<java.lang.String> future = RxHelper.observableFuture();
        call.accept(future.toHandler());
        return future;
    }

    public void shutDown() {
        vertx.close();
    }

}
