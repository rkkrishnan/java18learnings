package com.tesco.price.cuke

import cucumber.api.CucumberOptions
import cucumber.api.junit.Cucumber
import org.junit.runner.RunWith

@RunWith(classOf[Cucumber])
@CucumberOptions(
  monochrome = true,
  features = Array("src/test/resources/com/tesco/price/cuke"),
  plugin = Array("json:build/test-results/cucumber.json"),
  glue = Array("com.tesco.price.cuke"))
class CucumberTests