package com.tesco.price.cuke

import com.tesco.price.cuke.bdd.Verticle
import cucumber.api.Scenario
import cucumber.api.scala.{EN, ScalaDsl}
import org.junit.Assert._

class Quote extends ScalaDsl with EN {

  //Maybe a shared session type object.
  private val vars = collection.mutable.Map[String, Any]()
  private val RESPONSE: String = "RESPONSE"

  When("""^I send a request to (.*)$""") { (url: String) =>
    vars(RESPONSE) = this.send(url)
  }

  Then("^I receive a quoteId") { () =>
    assertTrue(vars(RESPONSE).asInstanceOf[String].nonEmpty)
  }

  Before("~@foo") { scenario: Scenario =>
    this.startUp()
  }

  After("~@foo") { scenario: Scenario =>
    this.shutDown()
  }

}
