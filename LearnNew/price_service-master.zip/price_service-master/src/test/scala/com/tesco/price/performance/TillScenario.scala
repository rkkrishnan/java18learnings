package com.tesco.price.performance

import io.gatling.core.Predef._
import io.gatling.http.Predef._

import scala.concurrent.duration._
import scala.util.Properties

class TillScenario extends Simulation {
  val host = Properties.propOrElse("price_service", "http://localhost:8080")
  val numberUsers: Int = Properties.propOrElse("num_users", "100").toInt
  val idleTime: Int = Properties.propOrElse("idle_time_s", "1").toInt
  val rampTimeSeconds: Int = Properties.propOrElse("ramp_time_s", "0").toInt
  val quotesPerUser: Int = Properties.propOrElse("quotes_per_user", "10000").toInt

  val httpConf = http
    .doNotTrackHeader("1")
    .acceptLanguageHeader("en-US,en;q=0.5")
    .acceptEncodingHeader("gzip, deflate")
    .userAgentHeader("Mozilla/5.0 (Windows NT 5.1; rv:31.0) Gecko/20100101 Firefox/31.0")
    .warmUp(host + "/v4/quote")
    .baseURL(host)
    .acceptHeader("application/json")

  val scn = scenario("Till Scenario")
    .repeat(quotesPerUser, "loop_count") {
      exec(http("get_quote")
        .get("/v4/quote")
        .check(status.is(200))
        .check(jsonPath("$..quote_id").saveAs("quote_id"))
      )
    }

  setUp(
    scn.inject(nothingFor(idleTime seconds), rampUsers(numberUsers) over (rampTimeSeconds seconds), atOnceUsers(numberUsers)))
    .protocols(httpConf)
    .assertions(global.successfulRequests.perMillion.is(1000000))
    .assertions(global.responseTime.max.lessThan(2000))
    .assertions(global.responseTime.percentile1.lessThan(50))
    .assertions(global.responseTime.percentile4.lessThan(150))
}
