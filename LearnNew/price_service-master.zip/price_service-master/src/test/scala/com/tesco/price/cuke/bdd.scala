package com.tesco.price.cuke

import com.tesco.price.TestManager
import cucumber.api.scala.ScalaDsl

package object bdd {

  val manager = new TestManager()

  implicit class Verticle(s: ScalaDsl) {
    def startUp() = manager.setUp()

    def shutDown() = manager.shutDown()

    def send(url: String): String = scala.io.Source.fromURL(s"http://localhost:8080$url").mkString
  }

}
