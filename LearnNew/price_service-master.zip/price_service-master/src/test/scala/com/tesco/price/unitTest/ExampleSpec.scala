package com.tesco.price.unitTest

import org.scalatest._

class ExampleSpec extends FeatureSpec with GivenWhenThen {

  feature("This a prove of concept of acceptance test") {

    info("As a developer I want to see this stuff works!")

    scenario("Remove 1 element form list") {

      Given("a non-empty list ")
      val list = List(1, 2, 3)

      When("when I remove 1 element")
      val result = list.drop(1)

      Then("the size of the list is 2")
      assert(result.size === 2)

    }

  }
}