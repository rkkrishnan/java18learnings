package com.tesco.price;

import io.vertx.core.Handler;
import io.vertx.core.http.HttpServerResponse;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.RoutingContext;

class Quote implements Handler<RoutingContext> {
    @Override
    public void handle(RoutingContext event) {
        HttpServerResponse response = event.response();
        response.putHeader("content-type", "application/json");
        response.end(new JsonObject().put("quote_id", "NEW_QUOTE").encode());
    }
}
