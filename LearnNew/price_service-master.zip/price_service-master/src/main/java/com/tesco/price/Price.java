package com.tesco.price;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.AsyncResult;
import io.vertx.core.Future;
import io.vertx.core.Handler;
import io.vertx.core.http.HttpServer;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.handler.StaticHandler;

import static io.vertx.core.http.HttpMethod.GET;

@SuppressWarnings("WeakerAccess")
public class Price extends AbstractVerticle {
    static final int PORT = 8080;

    @Override
    public void start(Future<Void> started) {
        startupVertxServer(result ->
        {
            if (result.succeeded()) {
                started.complete();
            } else {
                started.fail(result.cause());
            }
        });
    }

    private void startupVertxServer(Handler<AsyncResult<HttpServer>> asyncResultHandler) {
        vertx.createHttpServer().requestHandler(getRouter()::accept).listen(PORT, asyncResultHandler);
    }

    private Router getRouter() {
        Router router = Router.router(vertx);
        router.route(GET, "/v4/quote").handler(new Quote());
        router.route(GET, "/api").handler(Redirect.priceSwagger());
        router.route().handler(StaticHandler.create());
        return router;
    }

}