package com.tesco.price;

import io.vertx.core.Handler;
import io.vertx.core.http.HttpHeaders;
import io.vertx.ext.web.RoutingContext;

class Redirect implements Handler<RoutingContext> {
    private final String redirectLocation;

    private Redirect(String redirectLocation) {
        this.redirectLocation = redirectLocation;
    }

    static Handler<RoutingContext> priceSwagger() {
        return new Redirect("/api-console/index.html?url=/api/swagger.yaml");
    }

    private void redirect(RoutingContext event, String value) {
        event.response()
                .setStatusCode(302)
                .putHeader(HttpHeaders.LOCATION, value)
                .end();
    }

    @Override
    public void handle(RoutingContext event) {
        redirect(event, redirectLocation);
    }
}
