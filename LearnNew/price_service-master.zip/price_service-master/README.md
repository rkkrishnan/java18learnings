# Price Service
# Building
## targets
- **gatling**: Build everyting run all tests and the Performance tests
- **build**: Test and build everything
- **test**: Run all unit tests and java tests
- **scalaTest**: Run all scala unit and spec tests *--info* option will turn on the Std out output.
- **bdd**: Run all the bdd tests 
- **shadowJar**: Generate the Combined runnable jar, running all tests and building everything
  

